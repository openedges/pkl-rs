import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import org.pkl.core.util.StringUtils;

public class WhitespaceBitset {
  static void mark(byte[] bits, int code) { bits[code >>> 3] |= (byte) (1 << (code & 7)); }
  static String csv(List<Integer> values) {
    var out = new StringBuilder();
    for (int code : values) {
      if (!out.isEmpty()) out.append(',');
      out.append(String.format("%04X", code));
    }
    return out.toString();
  }
  public static void main(String[] args) throws Exception {
    if (args.length != 1) throw new IllegalArgumentException("output directory required");
    Path out = Path.of(args[0]);
    if (Files.exists(out)) throw new IllegalArgumentException("fresh output directory required");
    Files.createDirectory(out);
    byte[] pkl = new byte[8192], jdkString = new byte[8192], jdkCharacter = new byte[8192];
    List<Integer> pklSet = new ArrayList<>(), jdkStringSet = new ArrayList<>(), jdkCharacterSet = new ArrayList<>();
    for (int code = 0; code <= 0xFFFF; code++) {
      char ch = (char) code;
      String one = String.valueOf(ch);
      boolean p = StringUtils.isWhitespace(ch);
      if (p != StringUtils.isBlank(one)) throw new IllegalStateException("Pkl character/string mismatch at " + code);
      boolean s = one.isBlank();
      boolean c = Character.isWhitespace(code);
      if (p) { mark(pkl, code); pklSet.add(code); }
      if (s) { mark(jdkString, code); jdkStringSet.add(code); }
      if (c) { mark(jdkCharacter, code); jdkCharacterSet.add(code); }
    }
    if (!StringUtils.isBlank("") || !"".isBlank()) throw new IllegalStateException("empty string mismatch");
    Files.write(out.resolve("pkl-whitespace-bmp.bitset.bin"), pkl);
    Files.write(out.resolve("jdk-string-isblank-bmp.bitset.bin"), jdkString);
    Files.write(out.resolve("jdk-character-whitespace-bmp.bitset.bin"), jdkCharacter);
    String text = "Pkl count=" + pklSet.size() + " codepoints=" + csv(pklSet) + "\n"
      + "JDK String count=" + jdkStringSet.size() + " codepoints=" + csv(jdkStringSet) + "\n"
      + "JDK Character count=" + jdkCharacterSet.size() + " codepoints=" + csv(jdkCharacterSet) + "\n";
    Files.writeString(out.resolve("summary.txt"), text);
    System.out.print(text);
  }
}
