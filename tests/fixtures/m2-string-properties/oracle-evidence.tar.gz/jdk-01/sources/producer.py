"""Capture Pkl StringUtils and pinned JDK whitespace bitsets separately from public Pkl calls."""
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUTPUT = ROOT / "target/m2/stage67-string-blank-jdk-01"
HELPER = HERE / "WhitespaceBitset.java"
PKL_SOURCE = ROOT / "external/pkl/pkl-core/src/main/java/org/pkl/core/util/StringUtils.java"
JDK_ENTRIES = (
    "java.base/java/lang/String.java", "java.base/java/lang/StringLatin1.java",
    "java.base/java/lang/StringUTF16.java", "java.base/java/lang/Character.java",
    "java.base/java/lang/CharacterData.java", "java.base/java/lang/CharacterDataLatin1.java",
)


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def identity(path):
    path = Path(path)
    return {"bytes": path.stat().st_size, "sha256": sha(path)}


def save(path, obj):
    Path(path).write_text(json.dumps(obj, sort_keys=True, indent=2) + "\n")


def file_hashes(root):
    return {p.relative_to(root).as_posix(): identity(p) for p in root.rglob("*") if p.is_file()}


def main():
    if Path.cwd().resolve() != ROOT or OUTPUT.exists():
        raise ValueError("fresh Stage67 direct JDK output required")
    lock = json.loads((ROOT / "oracle.lock.json").read_bytes())
    if lock["version"] != "0.32.0":
        raise ValueError("oracle version differs")
    jar = ROOT / ".cache/oracle" / lock["artifact"]["filename"]
    if sha(jar) != lock["artifact"]["sha256"]:
        raise ValueError("oracle jar differs")
    java = Path(os.environ.get("PKL_ORACLE_JAVA", "/usr/bin/java")).resolve()
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C",
           "TZ": "UTC", "TERM": "dumb", "NO_COLOR": "1", "COLUMNS": "80"}
    OUTPUT.mkdir()
    source_paths = [Path(__file__), HELPER, PKL_SOURCE, ROOT / "oracle.lock.json", ROOT / "references.lock"]
    before = {p.relative_to(ROOT).as_posix(): identity(p) for p in source_paths}
    settings = subprocess.run([str(java), "-XshowSettings:properties", "-version"], cwd=OUTPUT,
                              env=env, capture_output=True, timeout=60)
    (OUTPUT / "java-identity.stdout.bin").write_bytes(settings.stdout)
    (OUTPUT / "java-identity.stderr.bin").write_bytes(settings.stderr)
    if settings.returncode:
        raise ValueError("pinned JDK identity failed; raw retained")
    props = dict(re.findall(r"^\s+([\w.]+) = (.*)$", settings.stderr.decode(), re.M))
    for name, value in lock["jdk"]["properties"].items():
        if props.get(name) != value:
            raise ValueError("pinned JDK property differs: " + name)
    home = Path(props["java.home"])
    srczip = home / "lib/src.zip"
    jdk = {"executable": str(java), "executable_identity": identity(java),
           "modules_identity": identity(home / "lib/modules"), "release_identity": identity(home / "release"),
           "source_archive_identity": identity(srczip), "properties": props}
    jdk_before = identity(srczip)
    with zipfile.ZipFile(srczip) as archive:
        for name in JDK_ENTRIES:
            path = OUTPUT / "jdk-sources" / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(archive.read(name))
    shutil.copyfile(PKL_SOURCE, OUTPUT / "StringUtils.java")
    shutil.copyfile(HELPER, OUTPUT / "WhitespaceBitset.java")
    provenance = {"schema": 1, "scope": "Direct internal Pkl StringUtils versus pinned JDK BMP whitespace; separate from public Pkl API string calls",
                  "host": platform.uname()._asdict(), "python": sys.version,
                  "oracle_lock": identity(ROOT / "oracle.lock.json"), "references_lock": identity(ROOT / "references.lock"),
                  "jar": identity(jar), "jdk": jdk, "environment": env,
                  "source_before": before, "jdk_source_entries": file_hashes(OUTPUT / "jdk-sources"),
                  "sessions": [], "candidate_compatibility_passes_claimed": 0}
    save(OUTPUT / "provenance.json", provenance)
    options = [*lock["jvm_options"], f"-Duser.home={env['HOME']}", f"-Djava.io.tmpdir={env['TMPDIR']}"]
    for repeat in range(2):
        folder = OUTPUT / f"repeat-{repeat}"
        folder.mkdir()
        result = folder / "bits"
        command = [str(java), *options, "-cp", str(jar), str(OUTPUT / "WhitespaceBitset.java"), str(result)]
        start = time.time()
        p = subprocess.Popen(command, cwd=OUTPUT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate(timeout=120)
        (folder / "process.stdout.bin").write_bytes(stdout)
        (folder / "process.stderr.bin").write_bytes(stderr)
        row = {"repeat": repeat, "pid": p.pid, "command": command, "cwd": str(OUTPUT),
               "started_epoch": start, "finished_epoch": time.time(), "exit_code": p.returncode,
               "stdout": identity(folder / "process.stdout.bin"), "stderr": identity(folder / "process.stderr.bin"),
               "files": file_hashes(folder)}
        provenance["sessions"].append(row)
        save(OUTPUT / "provenance.json", provenance)
        if p.returncode:
            raise ValueError("direct whitespace Java helper failed; raw retained")
    first = file_hashes(OUTPUT / "repeat-0")
    second = file_hashes(OUTPUT / "repeat-1")
    provenance["raw_equal"] = first == second
    provenance["source_after"] = {p.relative_to(ROOT).as_posix(): identity(p) for p in source_paths}
    provenance["jar_after"] = identity(jar)
    provenance["jdk_source_after"] = identity(srczip)
    provenance["stable"] = before == provenance["source_after"] and provenance["jar"] == provenance["jar_after"] and jdk_before == provenance["jdk_source_after"]
    provenance["complete"] = provenance["stable"] and provenance["raw_equal"]
    save(OUTPUT / "provenance.json", provenance)
    if not provenance["complete"]:
        raise ValueError("direct whitespace Java result unstable")
    print((OUTPUT / "repeat-0/bits/summary.txt").read_text(), end="")

if __name__ == "__main__":
    main()
