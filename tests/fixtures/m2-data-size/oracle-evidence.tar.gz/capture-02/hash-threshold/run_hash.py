from pathlib import Path
import hashlib,json,subprocess
H=Path(__file__).resolve().parent;O=H.parent;ROOT=O.parents[2]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
main=json.loads((O/'provenance.json').read_bytes());lock=json.loads((ROOT/'oracle.lock.json').read_bytes());env=main['environment'];java=main['jdk']['executable'];jar=main['artifact'];assert sha(java)==main['jdk']['executable_sha256'] and sha(jar)==main['artifact_sha256']
options=lock['jvm_options']+[f'-Duser.home={env["HOME"]}',f'-Djava.io.tmpdir={env["TMPDIR"]}']
inputfiles=[H/'input/module.pkl',H/'input/queries.tsv',H/'input/cases.json',H/'run_hash.py',O/'DataSizeOracle.java'];before={str(p.relative_to(O)):sha(p) for p in inputfiles};runs=[]
for repeat in range(2):
 out=H/f'repeat-{repeat}';out.mkdir(exist_ok=False);cmd=[java,*options,'-cp',jar,str(O/'DataSizeOracle.java'),str(out),str(H/'input'),'file:///stage57/datasize-hash-threshold.pkl']
 proc=subprocess.Popen(cmd,cwd=H,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=proc.communicate(timeout=600);(out/'process.stdout.bin').write_bytes(stdout);(out/'process.stderr.bin').write_bytes(stderr)
 runs.append({'repeat':repeat,'pid':proc.pid,'command':cmd,'cwd':str(H),'exit_code':proc.returncode,'stdout_sha256':sha(out/'process.stdout.bin'),'stderr_sha256':sha(out/'process.stderr.bin')});print(json.dumps({'repeat':repeat,'exit_code':proc.returncode,'stdout_bytes':len(stdout),'stderr_bytes':len(stderr)}),flush=True)
 if proc.returncode!=0:break
comparisons={}
if len(runs)==2:
 def files(p):return {x.relative_to(p).as_posix():sha(x) for x in p.rglob('*') if x.is_file()}
 a=files(H/'repeat-0');b=files(H/'repeat-1');comparisons={'raw_equal':a==b,'files':len(a),'differences':[n for n in sorted(set(a)|set(b)) if a.get(n)!=b.get(n)]}
report={'scope':'Additive Java DataSize Map/Set hash threshold observations.','main_provenance_sha256':sha(O/'provenance.json'),'input_before':before,'input_after':{str(p.relative_to(O)):sha(p) for p in inputfiles},'runs':runs,'comparison':comparisons};report['complete']=len(runs)==2 and all(x['exit_code']==0 for x in runs) and report['input_before']==report['input_after'] and comparisons.get('raw_equal')
(H/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps({'complete':report['complete'],'files':comparisons.get('files')}))
if not report['complete']:raise SystemExit(1)
