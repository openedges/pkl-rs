from pathlib import Path
import hashlib,json,os,subprocess,time
S=Path(__file__).resolve().parent;O=S.parent;ROOT=S.parents[3]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lock=json.loads((ROOT/'oracle.lock.json').read_bytes());main=json.loads((O/'provenance.json').read_bytes())
java=Path(main['jdk']['executable']);jar=Path(main['artifact']);assert sha(java)==main['jdk']['executable_sha256'] and sha(jar)==main['artifact_sha256']
env=main['environment'];options=lock['jvm_options']+[f'-Duser.home={env["HOME"]}',f'-Djava.io.tmpdir={env["TMPDIR"]}']
paths=[S/'input/module.pkl',S/'input/queries.tsv',S/'input/cases.json',S/'DataSizeSymbolOracle.java',S/'run_identity.py',O/'DataSizeOracle.java']
before={str(p.relative_to(O)):sha(p) for p in paths};runs=[]
for kind in ['language-identity','public-symbol']:
 for repeat in range(2):
  out=S/kind/f'repeat-{repeat}';out.mkdir(parents=True,exist_ok=False)
  if kind=='language-identity':cmd=[str(java),*options,'-cp',str(jar),str(O/'DataSizeOracle.java'),str(out),str(S/'input'),'file:///stage57/datasize-identity-supplement.pkl']
  else:cmd=[str(java),*options,'-cp',str(jar),str(S/'DataSizeSymbolOracle.java'),str(out),str(S/'input/module.pkl')]
  p=subprocess.Popen(cmd,cwd=S,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=p.communicate(timeout=600)
  (out/'process.stdout.bin').write_bytes(stdout);(out/'process.stderr.bin').write_bytes(stderr)
  runs.append({'kind':kind,'repeat':repeat,'pid':p.pid,'command':cmd,'cwd':str(S),'environment':env,'exit_code':p.returncode,'stdout_sha256':sha(out/'process.stdout.bin'),'stderr_sha256':sha(out/'process.stderr.bin'),'file_count':sum(x.is_file() for x in out.rglob('*'))})
  print(json.dumps({'kind':kind,'repeat':repeat,'exit_code':p.returncode,'stdout_bytes':len(stdout),'stderr_bytes':len(stderr)}),flush=True)
  if p.returncode!=0:break
 if runs[-1]['exit_code']!=0:break
after={str(p.relative_to(O)):sha(p) for p in paths};comparison={}
for kind in ['language-identity','public-symbol']:
 a=S/kind/'repeat-0';b=S/kind/'repeat-1'
 if a.is_dir() and b.is_dir():
  def files(p):return {x.relative_to(p).as_posix():sha(x) for x in p.rglob('*') if x.is_file()}
  x,y=files(a),files(b);comparison[kind]={'raw_equal':x==y,'files':len(x),'differences':[n for n in sorted(set(x)|set(y)) if x.get(n)!=y.get(n)]}
result={'schema':1,'scope':'Additive actual public Java identity observations; distinct input/JVMs, original -02 main capture untouched.','main_provenance_sha256':sha(O/'provenance.json'),'input_before':before,'input_after':after,'stable':before==after,'artifact_sha256':sha(jar),'jdk':main['jdk'],'runs':runs,'comparison':comparison}
result['complete']=len(runs)==4 and all(x['exit_code']==0 for x in runs) and all(x['raw_equal'] for x in comparison.values()) and result['stable']
(S/'report.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'complete':result['complete'],'comparison':comparison}),flush=True)
if not result['complete']:raise SystemExit(1)
