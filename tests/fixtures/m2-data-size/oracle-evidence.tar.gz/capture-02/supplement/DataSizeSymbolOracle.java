import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import org.pkl.core.DataSize;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
public final class DataSizeSymbolOracle {
  public static void main(String[] args) throws Exception {
    if(args.length!=2) throw new IllegalArgumentException("OUTPUT MODULE");
    Path out=Path.of(args[0]);
    var source=ModuleSource.create(URI.create("file:///stage57/datasize-identity-supplement.pkl"),Files.readString(Path.of(args[1])));
    try(var evaluator=EvaluatorBuilder.preconfigured().setModuleCacheDir(null).setColor(false)
      .setPowerAssertionsEnabled(false).setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      DataSize a=(DataSize)evaluator.evaluateExpression(source,"1.mb");
      DataSize b=(DataSize)evaluator.evaluateExpression(source,"2.mb");
      DataSize c=(DataSize)evaluator.evaluateExpression(source,"1.kb");
      String first=(String)evaluator.evaluateExpression(source,"1.mb.unit");
      String second=(String)evaluator.evaluateExpression(source,"2.mb.unit");
      String other=(String)evaluator.evaluateExpression(source,"1.kb.unit");
      StringBuilder text=new StringBuilder();
      text.append("export-data-reference=").append(a==b).append('\n');
      text.append("export-same-unit-enum-reference=").append(a.getUnit()==b.getUnit()).append('\n');
      text.append("export-same-symbol-reference=").append(a.getUnit().getSymbol()==b.getUnit().getSymbol()).append('\n');
      text.append("public-property-same-symbol-reference=").append(first==second).append('\n');
      text.append("public-property-vs-export-symbol-reference=").append(first==a.getUnit().getSymbol()).append('\n');
      text.append("public-property-different-unit-reference=").append(first==other).append('\n');
      text.append("public-property-value=").append(first).append('\n');
      text.append("public-property-other-value=").append(other).append('\n');
      Files.write(out.resolve("symbols.bin"),text.toString().getBytes(StandardCharsets.UTF_8));
      System.out.print("symbol-observation-complete\n");
    }
  }
}
