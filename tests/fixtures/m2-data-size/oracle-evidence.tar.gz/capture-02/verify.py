from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parent;S=O/'supplement'
read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r=read(O/'provenance.json');m=read(O/'cases.json');sup=read(S/'report.json')
assert r['complete'] and r['stable'] and r['repetition_raw_equal'] and r['repetition_file_set_equal'] and r['repetition_files']==8415
assert m['repetitions']==2 and len(m['rows'])==255 and len({x['id'] for x in m['rows']})==255
assert r['input_before']==r['input_after'] and r['source_before']==r['source_after'] and r['artifact_sha256']==r['artifact_after_sha256']
assert sha(Path(r['artifact']))==r['artifact_sha256']=='c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059'
assert sha(Path(r['jdk']['executable']))==r['jdk']['executable_sha256']
assert sha(Path(r['jdk']['properties']['java.home'])/'lib/modules')==r['jdk']['modules_sha256']
assert sha(Path(r['jdk']['properties']['java.home'])/'release')==r['jdk']['release_sha256']
for n,h in r['input_before'].items():assert sha(O/n)==h,n
for n,h in r['source_before'].items():assert sha(ROOT/n)==h,n
assert (O/'queries.tsv').read_text()==''.join(x['id']+'\t'+x['expression']+'\n' for x in m['rows'])
textfields=['expression','value.error','value.error-class','value.java-type','value.payload-error','value.text','value.raw-bits-hex','value.unit','value.hash','value.repeat-reference','value.repeat-equals','value.repeat-hash-equals','string.stdout','string.stderr','string.error-class']
statusfields=['value.status','value.payload-status','string.status']
expected={f+'.bin' for f in statusfields}|{f+suffix for f in textfields for suffix in ['.bin','.code-units.bin']}
assert len(expected)==33
statuses=defaultdict(Counter);java_types=Counter();errors=[];raw_bits=[];processes=[]
for repeat in range(2):
 folder=O/f'repeat-{repeat}';entry=r['repetitions'][repeat];assert entry['repeat']==repeat and entry['exit_code']==0 and entry['query_directories']==255
 assert sha(folder/'process.stdout.bin')==entry['stdout_sha256'] and sha(folder/'process.stderr.bin')==entry['stderr_sha256']
 assert (folder/'process.stderr.bin').read_bytes()==b''
 lines=[];success=Counter();exports=0
 for i,row in enumerate(m['rows']):
  d=folder/f'{i:03d}-{row["id"]}';assert d.is_dir();assert {x.name for x in d.iterdir() if x.is_file()}==expected,(repeat,row['id'])
  for f in textfields:
   byte=(d/(f+'.bin')).read_bytes();units=(d/(f+'.code-units.bin')).read_bytes();assert len(units)%2==0
   parsed=units.decode('utf-16-be',errors='surrogatepass');assert parsed.encode('utf-8',errors='replace')==byte,(repeat,row['id'],f)
  assert (d/'expression.bin').read_bytes()==row['expression'].encode()
  vs=(d/'value.status.bin').read_text();ss=(d/'string.status.bin').read_text();ps=(d/'value.payload-status.bin').read_text()
  assert vs in ['success\n','error\n','oracle-error\n','api-exception\n']
  assert ss in ['success\n','error\n','oracle-error\n','api-exception\n']
  assert ps in ['success\n','not-applicable\n','error\n','oracle-error\n','api-exception\n']
  assert ps=='not-applicable\n' if vs!='success\n' else ps!='not-applicable\n'
  if vs=='success\n':assert (d/'value.error.bin').read_bytes()==b'' and (d/'value.error-class.bin').read_bytes()==b''
  if ss=='success\n':assert (d/'string.stderr.bin').read_bytes()==b'' and (d/'string.error-class.bin').read_bytes()==b''
  if vs!='success\n':assert (d/'value.java-type.bin').read_bytes()==b''
  if ss!='success\n':assert (d/'string.stdout.bin').read_bytes()==b''
  typ=(d/'value.java-type.bin').read_text();java_types[typ]+=1
  if typ=='org.pkl.core.DataSize':
   bits=(d/'value.raw-bits-hex.bin').read_text();unit=(d/'value.unit.bin').read_text();assert re.fullmatch(r'[0-9a-f]{16}',bits) and unit in ['b','kb','kib','mb','mib','gb','gib','tb','tib','pb','pib']
   assert (d/'value.hash.bin').read_text().lstrip('-').isdigit()
   assert (d/'value.repeat-reference.bin').read_text() in ['true','false']
   assert (d/'value.repeat-equals.bin').read_text() in ['true','false']
   assert (d/'value.repeat-hash-equals.bin').read_text() in ['true','false']
   exports+=1
   if repeat==0:raw_bits.append({'id':row['id'],'expression':row['expression'],'raw_bits_hex':bits,'unit':unit,'java_hash':int((d/'value.hash.bin').read_text()),'export_repeat_reference':(d/'value.repeat-reference.bin').read_text(),'export_repeat_equals':(d/'value.repeat-equals.bin').read_text()})
  else:assert all((d/(f+'.bin')).read_bytes()==b'' for f in ['value.raw-bits-hex','value.unit','value.hash','value.repeat-reference','value.repeat-equals','value.repeat-hash-equals'])
  statuses[row['group']][(vs.strip(),ss.strip(),ps.strip())]+=1
  if repeat==0 and (vs!='success\n' or ss!='success\n'):errors.append({'id':row['id'],'group':row['group'],'expression':row['expression'],'value_status':vs.strip(),'string_status':ss.strip(),'error_sha256':sha(d/'string.stderr.bin'),'error_class':(d/'string.error-class.bin').read_text()})
  success['value']+=vs=='success\n';success['string']+=ss=='success\n'
  lines.extend([f'query-enter={row["id"]}',f'value-enter={row["id"]}',f'value-exit={row["id"]} status={vs.strip()} payload={ps.strip()}',f'string-enter={row["id"]}',f'string-exit={row["id"]} status={ss.strip()}',f'query-exit={row["id"]}'])
 lines.append(f'closed rows=255 value-success={success["value"]} value-error={255-success["value"]} string-success={success["string"]} string-error={255-success["string"]} datasize-export={exports}')
 assert (folder/'process.stdout.bin').read_bytes()==('\n'.join(lines)+'\n').encode()
 processes.append({'repeat':repeat,'pid':entry['pid'],'exit_code':entry['exit_code'],'stdout_sha256':entry['stdout_sha256'],'stderr_sha256':entry['stderr_sha256'],'value_success':success['value'],'value_nonpass':255-success['value'],'string_success':success['string'],'string_nonpass':255-success['string'],'exported_datasize':exports,'raw_files':255*33+2})

def file_hashes(folder):return {x.relative_to(folder).as_posix():sha(x) for x in folder.rglob('*') if x.is_file()}
a=file_hashes(O/'repeat-0');b=file_hashes(O/'repeat-1');assert a==b and len(a)==8417
assert sup['complete'] and sup['stable'] and all(x['raw_equal'] for x in sup['comparison'].values()) and sup['main_provenance_sha256']==sha(O/'provenance.json')
for n,h in sup['input_before'].items():assert sha(O/n)==h
assert sup['input_before']==sup['input_after']
for kind,expected_count in [('language-identity',398),('public-symbol',3)]:
 x=file_hashes(S/kind/'repeat-0');y=file_hashes(S/kind/'repeat-1');assert x==y and len(x)==expected_count
 for z in sup['runs']:
  if z['kind']==kind:assert z['exit_code']==0 and sha(S/kind/f'repeat-{z["repeat"]}'/'process.stdout.bin')==z['stdout_sha256'] and sha(S/kind/f'repeat-{z["repeat"]}'/'process.stderr.bin')==z['stderr_sha256']
H=O/'hash-threshold';hr=read(H/'report.json');assert hr['complete'] and hr['main_provenance_sha256']==sha(O/'provenance.json') and hr['comparison']['raw_equal'] and hr['comparison']['files']==398
assert hr['input_before']==hr['input_after']
for n,h in hr['input_before'].items():assert sha(O/n)==h
hash_rows=read(H/'input/cases.json')['rows'];assert len(hash_rows)==12
for repeat in range(2):
 folder=H/f'repeat-{repeat}';assert file_hashes(folder)==file_hashes(H/'repeat-0') and len(file_hashes(folder))==398
 for i,row in enumerate(hash_rows):
  d=folder/f'{i:03d}-{row["id"]}';assert {x.name for x in d.iterdir() if x.is_file()}==expected
  assert (d/'expression.bin').read_bytes()==row['expression'].encode()
  assert (d/'value.status.bin').read_bytes()==b'success\n' and (d/'string.status.bin').read_bytes()==b'success\n'
hash_outputs={row['id']:(H/'repeat-0'/f'{i:03d}-{row["id"]}'/'string.stdout.bin').read_text() for i,row in enumerate(hash_rows)}

result={'scope':'Offline audit of actual Java public API DataSize acquisition; no guest/test/build rerun or Rust candidate.','main_provenance_sha256':sha(O/'provenance.json'),'supplement_report_sha256':sha(S/'report.json'),'hash_threshold_report_sha256':sha(H/'report.json'),'oracle_artifact_sha256':r['artifact_sha256'],'jdk':r['jdk'],'input_sha256':r['input_before'],'source_sha256':r['source_before'],'rows':len(m['rows']),'groups':{g:{'rows':sum(c.values())//2,'statuses':{str(k):v//2 for k,v in c.items()}} for g,c in statuses.items()},'processes':processes,'raw_query_files_per_repetition':8415,'raw_repetition_equal':True,'supplement':sup['comparison'],'hash_threshold':{'rows':len(hash_rows),'raw_equal':True,'files_per_repetition':398,'outputs':hash_outputs},'java_export_types':dict(java_types),'exported_datasize_rows':len(raw_bits),'exported_datasize_raw_bits':raw_bits,'nonpass_rows':errors,'nonpass_count':len(errors),'required_follow_on':['Pkl Binary public codec API and malformed unit/length cases','Bytes.size producer and large Bytes diagnostic formatting','Yaml/Properties/PList/Jsonnet/Protobuf/XML DataSize renderer boundaries','Typed DataSize export parity on Rust native, Wasm and N-API products','Cross-platform Rust comparison and whole-language/full product gates']}
(O/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'verified':True,'rows':len(m['rows']),'success':processes[0]['value_success'],'nonpass':len(errors),'exported_datasize_rows':len(raw_bits),'raw_files_per_repetition':len(a),'supplement':sup['comparison']}))
