// Development-only Stage57 observations through pinned Pkl 0.32.0 public Java APIs.
import java.io.DataOutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;
import org.pkl.core.DataSize;
import org.pkl.core.Evaluator;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
import org.pkl.core.PklBugException;
import org.pkl.core.PklException;

public final class DataSizeOracle {
  static Path out;
  static int valueSuccess, valueError, stringSuccess, stringError, exportedDataSizes;
  static void bytes(Path folder, String name, byte[] data) throws Exception {
    Files.write(folder.resolve(name + ".bin"), data);
  }
  static void utf8(Path folder, String name, String value) throws Exception {
    bytes(folder, name, value.getBytes(StandardCharsets.UTF_8));
    try (var stream = new DataOutputStream(Files.newOutputStream(folder.resolve(name + ".code-units.bin")))) {
      for (int i = 0; i < value.length(); i++) stream.writeChar(value.charAt(i));
    }
  }
  static String errorStatus(Throwable error) {
    if (error instanceof PklBugException) return "oracle-error\n";
    if (error instanceof PklException) return "error\n";
    return "api-exception\n";
  }
  static String errorMessage(Throwable error) {
    return error.getMessage() == null ? error.toString() : error.getMessage();
  }
  static void record(Evaluator evaluator, ModuleSource source, Path folder, String id, String expression) throws Exception {
    Files.createDirectory(folder);
    utf8(folder, "expression", expression);
    System.out.println("query-enter=" + id);
    Object value = null;
    String status="success\n", error="", errorClass="";
    System.out.println("value-enter=" + id);
    try { value = evaluator.evaluateExpression(source, expression); valueSuccess++; }
    catch (Throwable thrown) { status=errorStatus(thrown); error=errorMessage(thrown); errorClass=thrown.getClass().getName(); valueError++; }
    bytes(folder,"value.status",status.getBytes(StandardCharsets.UTF_8));
    utf8(folder,"value.error",error);
    utf8(folder,"value.error-class",errorClass);
    utf8(folder,"value.java-type",value == null ? "" : value.getClass().getName());
    String payloadStatus="not-applicable\n", payloadError="";
    String valueText="", bits="", unit="", hash="", sameReference="", equals="", sameHash="";
    if (status.equals("success\n")) {
      try {
        valueText=String.valueOf(value);
        if (value instanceof DataSize size) {
          exportedDataSizes++;
          bits=String.format(Locale.ROOT,"%016x",Double.doubleToRawLongBits(size.getValue()));
          unit=size.getUnit().getSymbol(); hash=Integer.toString(size.hashCode());
          Object repeated=evaluator.evaluateExpression(source,expression);
          sameReference=Boolean.toString(value==repeated);
          equals=Boolean.toString(value.equals(repeated));
          sameHash=Boolean.toString(value.hashCode()==repeated.hashCode());
        }
        payloadStatus="success\n";
      } catch (Throwable thrown) { payloadStatus=errorStatus(thrown); payloadError=errorMessage(thrown); }
    }
    bytes(folder,"value.payload-status",payloadStatus.getBytes(StandardCharsets.UTF_8));
    utf8(folder,"value.payload-error",payloadError);
    utf8(folder,"value.text",valueText);
    utf8(folder,"value.raw-bits-hex",bits);
    utf8(folder,"value.unit",unit);
    utf8(folder,"value.hash",hash);
    utf8(folder,"value.repeat-reference",sameReference);
    utf8(folder,"value.repeat-equals",equals);
    utf8(folder,"value.repeat-hash-equals",sameHash);
    System.out.println("value-exit=" + id + " status=" + status.strip() + " payload=" + payloadStatus.strip());
    String result="", stringErrorText="", stringErrorClass="", stringStatus="success\n";
    System.out.println("string-enter=" + id);
    try { result=evaluator.evaluateExpressionString(source,expression); stringSuccess++; }
    catch (Throwable thrown) { stringStatus=errorStatus(thrown); stringErrorText=errorMessage(thrown); stringErrorClass=thrown.getClass().getName(); stringError++; }
    bytes(folder,"string.status",stringStatus.getBytes(StandardCharsets.UTF_8));
    utf8(folder,"string.stdout",result);
    utf8(folder,"string.stderr",stringErrorText);
    utf8(folder,"string.error-class",stringErrorClass);
    System.out.println("string-exit=" + id + " status=" + stringStatus.strip());
    System.out.println("query-exit=" + id);
  }
  public static void main(String[] args) throws Exception {
    if (args.length!=3) throw new IllegalArgumentException("OUTPUT INPUT URI");
    out=Path.of(args[0]); Path input=Path.of(args[1]);
    String module=Files.readString(input.resolve("module.pkl"),StandardCharsets.UTF_8);
    var source=ModuleSource.create(URI.create(args[2]),module);
    var lines=Files.readAllLines(input.resolve("queries.tsv"),StandardCharsets.UTF_8);
    try (var evaluator=EvaluatorBuilder.preconfigured().setModuleCacheDir(null).setColor(false)
        .setPowerAssertionsEnabled(false).setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      int index=0;
      for (String line:lines) {
        var columns=line.split("\t",-1);
        if (columns.length!=2 || !columns[0].matches("[a-z0-9-]+")) throw new IllegalArgumentException("bad query row " + index);
        record(evaluator,source,out.resolve(String.format(Locale.ROOT,"%03d-%s",index,columns[0])),columns[0],columns[1]);
        index++;
      }
    }
    System.out.println("closed rows=" + lines.size() + " value-success=" + valueSuccess + " value-error=" + valueError
        + " string-success=" + stringSuccess + " string-error=" + stringError + " datasize-export=" + exportedDataSizes);
  }
}
