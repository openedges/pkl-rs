from pathlib import Path
import hashlib,json,os,platform,re,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
lock=read(ROOT/'oracle.lock.json');jar=ROOT/'.cache/oracle'/lock['artifact']['filename']
assert sha(jar)==lock['artifact']['sha256']=='c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059'
refs=(ROOT/'references.lock').read_text();assert 'pkl.revision='+lock['source']['revision'] in refs and lock['source']['revision']=='e51fb2f91774265666f94980ec630db794a4db2d'
assert lock['version']=='0.32.0'
java=Path(os.environ.get('PKL_ORACLE_JAVA','/usr/bin/java')).resolve()
env={'PATH':os.defpath,'HOME':str(ROOT/'.cache/oracle/home'),'TMPDIR':str(ROOT/'.cache/oracle/tmp'),'TMP':str(ROOT/'.cache/oracle/tmp'),'TEMP':str(ROOT/'.cache/oracle/tmp'),'LC_ALL':'C','LANG':'C','TZ':'UTC','TERM':'dumb','NO_COLOR':'1','COLUMNS':'80'}
identity=subprocess.run([str(java),'-XshowSettings:properties','-version'],cwd=OUT,env=env,capture_output=True,timeout=60)
(OUT/'java-identity.stdout.bin').write_bytes(identity.stdout);(OUT/'java-identity.stderr.bin').write_bytes(identity.stderr)
assert identity.returncode==0
props=dict(re.findall(r'^\s+([\w.]+) = (.*)$',identity.stderr.decode(),re.M))
for k,v in lock['jdk']['properties'].items():assert props[k]==v,(k,props[k],v)
home=Path(props['java.home']);jdk={'executable':str(java),'executable_sha256':sha(java),'modules_sha256':sha(home/'lib/modules'),'release_sha256':sha(home/'release'),'properties':{k:props[k] for k in ['java.vendor','java.version','java.runtime.version','java.vm.name','java.vm.version','java.home','os.name','os.arch','os.version']}}
files=['DataSizeOracle.java','prepare.py','run.py','module.pkl','queries.tsv','cases.json']
sourcefiles=['external/pkl/stdlib/base.pkl','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmDataSize.java','external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/DataSizeNodes.java','external/pkl/pkl-core/src/main/java/org/pkl/core/DataSizeUnit.java','external/pkl/pkl-core/src/main/java/org/pkl/core/DataSize.java']
input_before={n:sha(OUT/n) for n in files};source_before={n:sha(ROOT/n) for n in sourcefiles}
manifest=read(OUT/'cases.json');rows=manifest['rows'];assert len(rows)==len({x['id'] for x in rows})==240 and manifest['repetitions']==2
assert (OUT/'queries.tsv').read_text()==''.join(x['id']+'\t'+x['expression']+'\n' for x in rows)
options=lock['jvm_options']+[f'-Duser.home={env["HOME"]}',f'-Djava.io.tmpdir={env["TMPDIR"]}']
result={'schema':1,'scope':'Actual pinned Java 0.32.0 public API DataSize language observations, no Rust candidate. Repetitions are fresh JVM processes.','host':platform.platform(),'oracle_lock_sha256':sha(ROOT/'oracle.lock.json'),'references_lock_sha256':sha(ROOT/'references.lock'),'reference_revision':lock['source']['revision'],'artifact':str(jar),'artifact_sha256':sha(jar),'jdk':jdk,'environment':env,'input_before':input_before,'source_before':source_before,'repetitions':[]}
(OUT/'provenance.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
for repeat in range(2):
 folder=OUT/f'repeat-{repeat}';folder.mkdir(exist_ok=False)
 cmd=[str(java),*options,'-cp',str(jar),str(OUT/'DataSizeOracle.java'),str(folder),str(OUT),manifest['module_uri']]
 start=time.time();proc=subprocess.Popen(cmd,cwd=OUT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=proc.communicate(timeout=1200)
 (folder/'process.stdout.bin').write_bytes(stdout);(folder/'process.stderr.bin').write_bytes(stderr)
 entry={'repeat':repeat,'pid':proc.pid,'command':cmd,'cwd':str(OUT),'exit_code':proc.returncode,'started_epoch':start,'finished_epoch':time.time(),'stdout_sha256':sha(folder/'process.stdout.bin'),'stderr_sha256':sha(folder/'process.stderr.bin'),'stdout_bytes':len(stdout),'stderr_bytes':len(stderr),'query_directories':len([x for x in folder.iterdir() if x.is_dir()])}
 result['repetitions'].append(entry);(OUT/'provenance.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'repeat':repeat,'exit_code':proc.returncode,'query_directories':entry['query_directories'],'process_stdout_bytes':len(stdout),'process_stderr_bytes':len(stderr)}),flush=True)
 if proc.returncode!=0 or entry['query_directories']!=len(rows):break
result['input_after']={n:sha(OUT/n) for n in files};result['source_after']={n:sha(ROOT/n) for n in sourcefiles};result['artifact_after_sha256']=sha(jar)
result['stable']=result['input_before']==result['input_after'] and result['source_before']==result['source_after'] and result['artifact_sha256']==result['artifact_after_sha256']
if len(result['repetitions'])==2 and all(x['exit_code']==0 for x in result['repetitions']):
 def data(folder):return {x.relative_to(folder).as_posix():sha(x) for x in folder.rglob('*') if x.is_file() and x.name not in ['process.stdout.bin','process.stderr.bin']}
 a=data(OUT/'repeat-0');b=data(OUT/'repeat-1');result['repetition_file_set_equal']=set(a)==set(b);result['repetition_raw_equal']=a==b;result['repetition_files']=len(a);result['repetition_differences']=[n for n in sorted(set(a)|set(b)) if a.get(n)!=b.get(n)]
result['complete']=len(result['repetitions'])==2 and all(x['exit_code']==0 and x['query_directories']==len(rows) for x in result['repetitions']) and result.get('repetition_raw_equal') is True and result['stable']
(OUT/'provenance.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'complete':result['complete'],'raw_equal':result.get('repetition_raw_equal'),'file_count':result.get('repetition_files'),'stable':result['stable']}),flush=True)
sys.exit(0 if result['complete'] else 1)
