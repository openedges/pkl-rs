from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent
rows=[]
def add(group,id,expression):
 assert '\t' not in expression and '\n' not in expression and id not in {r['id'] for r in rows}
 rows.append({'group':group,'id':id,'expression':expression})
units=['b','kb','kib','mb','mib','gb','gib','tb','tib','pb','pib']
for u in units:
 for label,x in [('int','7'),('float','7.25'),('negative','(-3)')]:add('construct',f'{label}-{u}',f'{x}.{u}')
 add('construct',f'to-data-size-{u}',f'7.toDataSize("{u}")')
 add('members',f'value-{u}',f'7.25.{u}.value')
 add('members',f'unit-{u}',f'7.25.{u}.unit')
 add('members',f'binary-{u}',f'1.{u}.isBinaryUnit')
 add('members',f'decimal-{u}',f'1.{u}.isDecimalUnit')
 add('conversion',f'unit-{u}-to-b',f'1.{u}.toUnit("b")')
 add('conversion',f'b-to-unit-{u}',f'1.b.toUnit("{u}")')
 add('conversion',f'{u}-to-binary',f'1.{u}.toBinaryUnit()')
 add('conversion',f'{u}-to-decimal',f'1.{u}.toDecimalUnit()')
for id,e in [
 ('large-int','9007199254740993.b'),('max-int','9223372036854775807.b'),('min-int','(-9223372036854775808).b'),
 ('positive-zero','0.0.mb'),('negative-zero','(-0.0).mb'),('positive-infinity','(1.0 / 0.0).mb'),('negative-infinity','(-1.0 / 0.0).mb'),('nan','(0.0 / 0.0).mb'),
 ('subnormal','(1.0e-320).pib'),('max-double','(1.0e308).pib'),('very-small','(1.0e-300).pib'),
 ('integer-value','4.0.mb.value'),('negative-zero-value','(-0.0).mb.value'),('large-value','(1.0e100).mb.value'),('nan-value','(0.0/0.0).mb.value'),
 ('mixed-decimal-binary','1.mib.toUnit("mb")'),('roundtrip','1.pib.toUnit("b").toUnit("pib")'),
 ('positive-zero-predicate','0.0.mb.isPositive'),('negative-zero-predicate','(-0.0).mb.isPositive'),('nan-predicate','(0.0/0.0).mb.isPositive'),
 ('is-between-inclusive','3.kb.isBetween(2000.b,3000.b)'),('is-between-reversed','3.kb.isBetween(4.kb,2.kb)'),('is-between-mixed','1.mib.isBetween(1000.kb,2.mb)'),
]:add('boundaries',id,e)
ops=[('add','1.mb + 1.kb'),('add-reverse','1.kb + 1.mb'),('add-mixed','1.mib + 1.mb'),('add-mixed-reverse','1.mb + 1.mib'),
('subtract','1.mb - 1000.kb'),('subtract-reverse','1000.kb - 1.mb'),('multiply-int','2.mb * 3'),('multiply-int-reverse','3 * 2.mb'),('multiply-float','2.mb * 1.25'),('multiply-float-reverse','1.25 * 2.mb'),
('divide-scalar','5.mb / 2'),('divide-size','1.mib / 1.kb'),('divide-size-reverse','1.kb / 1.mib'),('int-divide-scalar','5.mb ~/ 2'),('int-divide-size','5.mb ~/ 2.mb'),('int-divide-mixed','1.mib ~/ 1.kb'),
('remainder','5.mb % 2'),('power-int','2.mb ** 3'),('power-float','2.mb ** 0.5'),('unary-minus','-2.mb'),('less-mixed','1.mb < 1.mib'),('less-reverse','1.mib < 1.mb'),('le-equal','1.mb <= 1000.kb'),('greater','2.kb > 1999.b'),('ge','1.mib >= 1.mb'),
('nan-less','(0.0/0.0).mb < 1.mb'),('nan-greater','(0.0/0.0).mb > 1.mb'),('zero-order','(-0.0).mb < 0.0.mb')]
for id,e in ops:add('operators',id,e)
for id,e in [
 ('same-unit','1.mb == 1.mb'),('cross-unit','1.mb == 1000.kb'),('cross-unit-reverse','1000.kb == 1.mb'),('different','1.mb != 2.mb'),
 ('nan-self','nanSize == nanSize'),('nan-distinct','(0.0/0.0).mb == (0.0/0.0).mb'),('zero-equality','(-0.0).mb == 0.0.mb'),
 ('set-equal','Set(1.mb,1000.kb).length'),('set-different','Set(1.mb,1.mib).length'),('set-nan-self','Set(nanSize,nanSize).length'),('set-nan-distinct','Set((0.0/0.0).mb,(0.0/0.0).mb).length'),
 ('set-zero','Set((-0.0).mb,0.0.mb).length'),('map-equal','Map(1.mb,"first",1000.kb,"second").length'),('map-nan-self','Map(nanSize,1,nanSize,2).length'),
 ('list-equality','List(1.mb,2.kb) == List(1000.kb,2.kb)'),('typed-object-equality','new { x = 1.mb } == new { x = 1000.kb }')
]:add('equality-keys',id,e)
for id,e in [
 ('class','1.mb.getClass().simpleName'),('is-datasize','1.mb is DataSize'),('is-any','1.mb is Any'),('is-number','1.mb is Number'),('is-typed','1.mb is Typed'),
 ('as-datasize','1.mb as DataSize'),('as-number','1.mb as Number'),('nullable','1.mb is DataSize?'),('union','1.mb is DataSize|String'),
 ('unit-valid','new { x: DataSizeUnit = "mb" }.x'),('unit-invalid','new { x: DataSizeUnit = "MB" }.x'),
 ('typed-property','new { x: DataSize = 1.mb }.x'),('typed-property-wrong','new { x: DataSize = 1 }.x'),
 ('typed-default-missing','new { x: DataSize }.x'),('typed-default-null','new { x: DataSize = null }.x'),
 ('typed-method','((x: DataSize) -> x.unit)(1.mb)'),('typed-method-wrong','((x: DataSize) -> x.unit)(1)'),
 ('alias','(1.mb is DataSizeAlias)'),('bytes-size','Bytes(1,2,3).size')
]:add('types-defaults',id,e)
for id,e in [
 ('to-string','1.mb.toString()'),('interpolation','"value=\\(1.25.mib)"'),('pcf','new PcfRenderer {}.renderValue(1.25.mib)'),('pcf-converter','new PcfRenderer { converters { [DataSize] = (it) -> "converted" } }.renderValue(1.mb)'),
 ('pcf-any-converter','new PcfRenderer { converters { [Any] = (it) -> "any" } }.renderValue(1.mb)'),
 ('json-unsupported','new JsonRenderer {}.renderValue(1.mb)'),('json-converter','new JsonRenderer { converters { [DataSize] = (it) -> it.value } }.renderValue(1.mb)'),
 ('pcf-document-top','new PcfRenderer {}.renderDocument(1.mb)')
]:add('renderers',id,e)
for id,e in [
 ('invalid-to-unit','1.mb.toUnit("bogus")'),('invalid-to-data-size','1.toDataSize("bogus")'),('wrong-to-unit-type','1.mb.toUnit(1)'),('wrong-between-type','1.mb.isBetween(0.mb,"bad")'),
 ('wrong-add','1.mb + 1'),('wrong-multiply','1.mb * 1.mb'),('wrong-divide','1 / 1.mb'),('wrong-remainder','1.mb % 1.mb'),
 ('division-by-zero','1.mb / 0'),('trunc-divide-by-zero','1.mb ~/ 0'),('trunc-ratio-by-zero','1.mb ~/ 0.mb'),('too-large-trunc','(1.0e308).mb ~/ 1.b'),
 ('nan-trunc','(0.0/0.0).mb ~/ 1'),('too-many-arguments','1.mb.toUnit("kb","mb")')
]:add('errors',id,e)
module='''// Stage57 DataSize public API source. All expressions are supplied separately.\nlocal nanSize = (0.0 / 0.0).mb\ntypealias DataSizeAlias = DataSize\nmarker = "stage57"\n'''
(O/'module.pkl').write_bytes(module.encode())
(O/'queries.tsv').write_bytes(''.join(f"{r['id']}\t{r['expression']}\n" for r in rows).encode())
(O/'cases.json').write_text(json.dumps({'schema':1,'baseline':'Pkl 0.32.0','module_uri':'file:///stage57/datasize-oracle.pkl','repetitions':2,'rows':rows},indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'rows':len(rows),'groups':{g:sum(x['group']==g for x in rows) for g in sorted({x['group'] for x in rows})},'module_sha256':hashlib.sha256((O/'module.pkl').read_bytes()).hexdigest(),'queries_sha256':hashlib.sha256((O/'queries.tsv').read_bytes()).hexdigest()}))
