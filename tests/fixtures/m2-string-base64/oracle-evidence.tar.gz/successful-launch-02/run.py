"""Record the Stage68 pinned Java String Base64 exploration process."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
PREP = ROOT / "target/m2/stage68-base64-prep-02"
OUTPUT = ROOT / "target/m2/stage68-base64-oracle-02"
PRODUCER_SHA = "cba17c0f83775f9a6f23904eed2f2effb5b074094a652578a64653c0f0d5a2a9"

def identity(path):
    path = Path(path)
    with path.open("rb") as stream:
        return {"bytes": path.stat().st_size,
                "sha256": hashlib.file_digest(stream, "sha256").hexdigest()}

def save(path, obj):
    Path(path).write_text(json.dumps(obj, sort_keys=True, indent=2) + "\n")

def main():
    if Path.cwd().resolve() != ROOT or OUTPUT.exists() or (HERE / "report.json").exists():
        raise ValueError("fresh Stage68 Java launch from authoritative worktree required")
    producer = PREP / "run.py"
    if identity(producer)["sha256"] != PRODUCER_SHA:
        raise ValueError("Stage68 producer changed")
    lock = json.loads((ROOT / "oracle.lock.json").read_bytes())
    jar = ROOT / ".cache/oracle" / lock["artifact"]["filename"]
    inputs = [Path(__file__), producer, PREP / "cases.json", PREP / "module.pkl",
              PREP / "queries.tsv",
              ROOT / "tools/java/CollectionConversionsOracle.java", ROOT / "oracle.lock.json",
              ROOT / "references.lock", jar]
    before = {p.relative_to(ROOT).as_posix(): identity(p) for p in inputs}
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    command = [sys.executable, "-B", str(producer), "--output", str(OUTPUT)]
    report = {"schema": 1, "kind": "stage68-string-base64-java-launch",
              "scope": "Two fresh pinned Java public string sessions, no Rust candidate",
              "command": command, "cwd": str(ROOT), "host": platform.uname()._asdict(),
              "python": sys.version, "inputs_before": before,
              "environment_relevant": {k: env.get(k) for k in
                  ("PATH", "HOME", "TMPDIR", "LANG", "LC_ALL", "TZ", "PKL_ORACLE_JAVA")},
              "started_epoch": time.time(), "complete": False,
              "candidate_compatibility_passes_claimed": 0}
    save(HERE / "report.json", report)
    with (HERE / "stdout.bin").open("xb") as stdout, (HERE / "stderr.bin").open("xb") as stderr:
        child = subprocess.Popen(command, cwd=ROOT, env=env,
                                 stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
        report["pid"] = child.pid
        save(HERE / "report.json", report)
        report["exit_code"] = child.wait()
    after = {p.relative_to(ROOT).as_posix(): identity(p) for p in inputs}
    provenance = OUTPUT / "provenance.json"
    audit = OUTPUT / "audit.json"
    report.update(complete=True, finished_epoch=time.time(), inputs_after=after,
                  input_stable=before == after, stdout=identity(HERE / "stdout.bin"),
                  stderr=identity(HERE / "stderr.bin"),
                  provenance=identity(provenance) if provenance.exists() else None,
                  audit=identity(audit) if audit.exists() else None)
    save(HERE / "report.json", report)
    print(json.dumps({"exit_code": report["exit_code"],
                      "input_stable": report["input_stable"],
                      "audit": report["audit"]}, sort_keys=True))
    return report["exit_code"] if report["exit_code"] else int(not report["input_stable"])

if __name__ == "__main__":
    raise SystemExit(main())
