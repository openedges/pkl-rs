"""Record the actual pinned Stage78 Java-only acquisition process and source bookends."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
RUNNER = HERE / "run.py"
FIXTURE = ROOT / "target/m2/stage78-number-primitives-oracle-prep-02/fixture"
OUTPUT = ROOT / "target/m2/stage78-number-primitives-oracle-02"
EXECUTION = HERE / "execution-01"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.resolve() != OUTPUT or OUTPUT.exists() or EXECUTION.exists():
        raise ValueError("fresh exact Stage78 output and execution directories required")
    spec = importlib.util.spec_from_file_location("stage78_number_oracle", RUNNER)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    java = Path("/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home/bin/java")
    home = java.parents[1]
    paths = [HERE / "launch.py", RUNNER,
             *(FIXTURE / name for name in ("module.pkl", "queries.tsv", "cases.json")),
             ROOT / "tools/java/CollectionConversionsOracle.java",
             ROOT / ".cache/oracle/pkl-tools-0.32.0.jar",
             java, home / "lib/modules", home / "release", home / "lib/src.zip",
             *(ROOT / name for name in runner.SOURCES)]
    paths = list(dict.fromkeys(paths))
    before = {str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path):
              {"bytes": path.stat().st_size, "sha256": sha(path)} for path in paths}
    EXECUTION.mkdir()
    argv = [sys.executable, "-B", str(RUNNER), "--output", str(OUTPUT),
            "--fixture", str(FIXTURE)]
    started = time.time()
    process = subprocess.Popen(argv, cwd=ROOT, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    save(EXECUTION / "process.json", {"complete": False, "pid": process.pid,
                                      "argv": argv, "cwd": str(ROOT),
                                      "started_epoch": started, "inputs_before": before})
    stdout, stderr = process.communicate()
    (EXECUTION / "stdout.bin").write_bytes(stdout)
    (EXECUTION / "stderr.bin").write_bytes(stderr)
    after = {str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path):
             {"bytes": path.stat().st_size, "sha256": sha(path)} for path in paths}
    provenance = OUTPUT / "provenance.json"
    provenance_complete = (provenance.exists() and
                           json.loads(provenance.read_bytes()).get("complete") is True)
    report = {"kind": "stage78-number-primitives-java-outer-process-v1",
              "complete": True, "success": process.returncode == 0 and before == after
              and provenance_complete, "pid": process.pid, "argv": argv,
              "cwd": str(ROOT), "started_epoch": started, "finished_epoch": time.time(),
              "exit_code": process.returncode, "source_stable": before == after,
              "producer_complete": provenance_complete,
              "candidate_compatibility_passes_claimed": 0,
              "inputs_before": before, "inputs_after": after,
              "stdout": {"bytes": len(stdout), "sha256": sha(EXECUTION / "stdout.bin")},
              "stderr": {"bytes": len(stderr), "sha256": sha(EXECUTION / "stderr.bin")}}
    save(EXECUTION / "process.json", report)
    print(json.dumps({"exit_code": process.returncode, "success": report["success"],
                      "source_stable": report["source_stable"],
                      "producer_complete": provenance_complete}), flush=True)
    return 0 if report["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
