"""Independent finite read-only Stage78 source/raw review; no Java/compiler calls."""
from pathlib import Path
import hashlib
import json
import os
import re
import stat
import subprocess
import time
import zipfile

R = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
O = Path(__file__).resolve().parent
D = R / 'target/m2/stage78-number-primitives-draft-01'
P = R / 'target/m2/stage78-number-primitives-oracle-03'
S = R / 'target/m2/stage78-number-reference-supplement-oracle-01'


def read(p):
    return json.loads(p.read_bytes())


def identity(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    s = p.stat()
    return {'bytes': s.st_size, 'sha256': h.hexdigest()}


def bound(p):
    return {'path': str(p.relative_to(R)) if p.is_relative_to(R) else str(p), **identity(p)}


def require(p, expected):
    actual = identity(p)
    assert all(actual[k] == v for k, v in expected.items() if k in actual), (str(p), expected, actual)


def put(name, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
    with (O / name).open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())


values = {
    'int-sign-pos': '1', 'int-sign-neg': '-1', 'int-sign-zero': '0',
    'int-abs-neg': '123', 'int-ceil': '-123', 'int-floor': '123',
    'int-round': '-123', 'int-truncate': '123',
    'float-sign-pos': '1.0', 'float-sign-neg': '-1.0',
    'float-sign-plus-zero': '0.0', 'float-sign-minus-zero': '-0.0',
    'float-sign-nan': 'NaN', 'float-sign-pos-inf': '1.0', 'float-sign-neg-inf': '-1.0',
    'float-abs-minus-zero': '0.0', 'float-abs-nan': 'NaN', 'float-abs-neg-inf': 'Infinity',
    'float-ceil-minus-zero': '-0.0', 'float-ceil-small-neg': '-0.0',
    'float-floor-plus-zero': '0.0', 'float-floor-small-pos': '0.0',
    'float-round-half-zero': '0.0', 'float-round-half-negzero': '-0.0',
    'float-round-half-even': '2.0', 'float-round-half-odd': '4.0',
    'float-round-neg-half-even': '-2.0', 'float-round-neg-half-odd': '-4.0',
    'float-round-nan': 'NaN', 'float-round-inf': 'Infinity',
    'float-truncate-small-neg': '-0.0', 'float-truncate-minus-zero': '-0.0',
    'float-truncate-nan': 'NaN', 'float-truncate-neg-inf': '-Infinity',
    'ref-int-sign-type': 'true', 'ref-int-abs-type': 'true',
    'ref-float-sign-type': 'true', 'ref-float-floor-type': 'true',
}
error_heads = {
    'int-abs-min': 'Integer overflow.',
    'int-sign-as-method': 'Cannot find method `sign` in class `Int`.',
    'int-round-as-property': 'Cannot find property `round` in object of type `Int`.',
    'int-round-extra-arg': 'Expected 0 function arguments but got 1.',
    'int-truncate-extra-arg': 'Expected 0 function arguments but got 1.',
    'float-sign-as-method': 'Cannot find method `sign` in class `Float`.',
    'float-round-as-property': 'Cannot find property `round` in object of type `Float`.',
    'float-round-extra-arg': 'Expected 0 function arguments but got 1.',
    'ref-int-round-method': 'Cannot find method `round` in class `pkl.ref#Reference`.',
    'ref-float-truncate-method': 'Cannot find method `truncate` in class `pkl.ref#Reference`.',
}
int_props = 'abs b ceil d floor gb gib h inv isEven isFinite isInfinite isNaN isNonZero isOdd isPositive kb kib mb mib min ms ns pb pib s sign tb tib us'.split()
float_props = [x for x in int_props if x not in ('inv', 'isEven', 'isOdd')]
ref_methods = 'getClass getData getDomain getPath getProperty getPropertyOrNull hasProperty ifNonNull toDynamic toMap toString'.split()
base = (R / 'external/pkl/stdlib/base.pkl').read_text()


def expected_error(row):
    name, expression = row['id'], row['expression']
    result = '–– Pkl Error ––\n' + error_heads[name] + '\n\n'
    frame = {
        'int-round-extra-arg': ('Int', 'round'),
        'int-truncate-extra-arg': ('Int', 'truncate'),
        'float-round-extra-arg': ('Float', 'round'),
    }.get(name)
    if frame:
        cls, method = frame
        signature = f'external function {method}(): {cls}'
        offset = base.index(signature)
        line = base[:offset].count('\n') + 1
        result += (f'{line} | {signature}\n' + ' ' * (len(str(line)) + 3)
                   + '^' * len(signature) + '\n'
                   + f'at pkl.base#{cls}.{method} (https://github.com/apple/pkl/blob/0.32.0/stdlib/base.pkl#L{line})\n\n')
    result += f'1 | {expression}\n    ' + '^' * len(expression) + '\nat  (repl:text)\n'
    if name in ('int-sign-as-method', 'float-sign-as-method'):
        result += '\nDid you mean any of the following?\nsign\ns\n'
    elif name in ('int-round-as-property', 'float-round-as-property'):
        props = int_props if name.startswith('int-') else float_props
        result += '\nAvailable properties:\n' + '\n'.join(props) + '\n'
    elif name.startswith('ref-'):
        result += '\nAvailable methods in class `pkl.ref#Reference`:\n' + '\n'.join(ref_methods) + '\n'
    return result


raw_identities = {}
intent_rows = []


def check_capture(root, expected_values, expected_errors, outer_path, expected_count):
    cases, provenance, audit, outer = [read(p) for p in (
        root / 'cases.json', root / 'provenance.json', root / 'audit.json', outer_path)]
    rows = cases['rows']
    assert len(rows) == len({x['id'] for x in rows}) == expected_count
    assert set(expected_values) | set(expected_errors) == {x['id'] for x in rows}
    assert not (set(expected_values) & set(expected_errors))
    assert (root / 'queries.tsv').read_bytes() == ''.join(f"{x['mode']}\t{x['id']}\t{x['expression']}\n" for x in rows).encode()
    assert all(provenance[x] for x in ('complete', 'stable', 'raw_equal'))
    assert provenance['raw_differences'] == [] and len(provenance['sessions']) == 2
    assert provenance['input_before'] == provenance['input_after']
    assert provenance['source_before'] == provenance['source_after']
    for name, sha in provenance['input_before'].items():
        require(root / name, {'sha256': sha})
    for name, sha in provenance['source_before'].items():
        require(R / name, {'sha256': sha})
        require(root / 'sources' / name, {'sha256': sha})
    assert provenance['artifact_sha256'] == provenance['artifact_after_sha256']
    require(Path(provenance['artifact']), {'sha256': provenance['artifact_sha256']})
    jdk = provenance['jdk']
    java = Path(jdk['executable'])
    for p, key in [(java, 'executable_sha256'), (java.parent.parent / 'lib/modules', 'modules_sha256'),
                   (java.parent.parent / 'release', 'release_sha256'), (java.parent.parent / 'lib/src.zip', 'source_archive_sha256')]:
        require(p, {'sha256': jdk[key]})
    assert outer['complete'] and outer['success'] and outer['producer_complete']
    assert outer['exit_code'] == 0 and outer['source_stable']
    assert outer['inputs_before'] == outer['inputs_after']
    for p, v in outer['inputs_before'].items():
        require(Path(p) if Path(p).is_absolute() else R / p, v)
    for channel in ('stdout', 'stderr'):
        require(outer_path.parent / (channel + '.bin'), outer[channel])
    repeat_maps = []
    for repeat in range(2):
        folder = root / f'repeat-{repeat}'
        session = provenance['sessions'][repeat]
        assert session['repeat'] == repeat and session['exit_code'] == 0 and session['interruption_reason'] is None
        assert session['query_directories'] == expected_count
        for channel in ('stdout', 'stderr'):
            raw = folder / f'process.{channel}.bin'
            require(raw, {'bytes': session[channel + '_bytes'], 'sha256': session[channel + '_sha256']})
        assert (folder / 'process.stderr.bin').read_bytes() == b''
        terminal = f'session-closed mode=string rows={expected_count} public-calls={expected_count} success={len(expected_values)} errors={len(expected_errors)}\n'
        assert (folder / 'process.stdout.bin').read_bytes().endswith(terminal.encode())
        paths = [folder / 'process.stdout.bin', folder / 'process.stderr.bin']
        for index, row in enumerate(rows):
            q = folder / f"{index:03d}-{row['id']}"
            name = row['id']
            error = expected_errors.get(name, '')
            fields = {'mode': 'string', 'expression': row['expression'],
                      'result.stdout': expected_values.get(name, ''), 'result.stderr': error,
                      'result.error-class': 'org.pkl.core.PklException' if error else '',
                      'result.exception-to-string': 'org.pkl.core.PklException: ' + error if error else '',
                      'result.cause-class': '', 'result.cause-message': '', 'result.cause-to-string': '',
                      'result.java-type': ''}
            expected_files = {'result.status.bin'}
            status = 'error' if error else 'success'
            assert (q / 'result.status.bin').read_bytes() == (status + '\n').encode(), (name, 'status')
            for key, value in fields.items():
                p, u = q / (key + '.bin'), q / (key + '.code-units.bin')
                assert p.read_bytes() == value.encode('utf-8'), (name, key, p.read_bytes(), value)
                assert u.read_bytes() == value.encode('utf-16-be'), (name, key + 'UTF16')
                expected_files.update((p.name, u.name))
            assert {x.name for x in q.iterdir()} == expected_files
            paths.extend(q / x for x in sorted(expected_files))
            if repeat == 0:
                intent_rows.append({'capture': str(root.relative_to(R)), 'index': index, **row,
                                    'expected_status': status, 'expected_stdout': expected_values.get(name, ''),
                                    'complete_expected_error': error, 'all_utf8_utf16_exception_and_cause_fields_exact': True,
                                    'raw_stdout': bound(q / 'result.stdout.bin'), 'raw_stderr': bound(q / 'result.stderr.bin')})
        current = {str(p.relative_to(folder)): identity(p) for p in paths}
        assert set(current) == {str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file()}
        repeat_maps.append(current)
        for p in paths:
            raw_identities[str(p.relative_to(R))] = identity(p)
    assert repeat_maps[0] == repeat_maps[1]
    assert len(repeat_maps[0]) == provenance['raw_files']
    assert sum(v['bytes'] for m in repeat_maps for v in m.values()) == provenance['raw_bytes']
    assert audit['rows'] == expected_count
    return {'rows': expected_count, 'success': len(expected_values), 'ordinary_errors': len(expected_errors),
            'raw_files_per_repeat': len(repeat_maps[0]), 'raw_bytes_both_repeats': provenance['raw_bytes'],
            'outer': bound(outer_path), 'provenance': bound(root / 'provenance.json'), 'audit': bound(root / 'audit.json'),
            'cases': bound(root / 'cases.json'), 'module': bound(root / 'module.pkl'), 'queries': bound(root / 'queries.tsv'),
            'both_jvm_exits': [s['exit_code'] for s in provenance['sessions']], 'source_artifact_input_bookends_exact': True}


require(D / 'report.json', {'sha256': 'fa82a4397f67d9d32be33d39fe6b685768fe1ab919f18d2a785fbf3b2c70767c'})
require(D / 'combined.patch', {'sha256': '3afc5eda6c5fe1f410239ea734a1c1d7e4d7f90cc70fdbf454162568fbe452b7'})
draft = read(D / 'report.json')
for category in ('inputs', 'overlay', 'upstream'):
    for path, value in draft[category].items():
        require((R if category == 'upstream' else D) / path, value)
for path, value in draft['base'].items():
    require(R / path, value)
for cls in ('Int', 'Float'):
    start = base.index(f'class {cls} ')
    for prop in ('sign', 'abs', 'ceil', 'floor'):
        assert f'external {prop}: {cls}' in base[start:]
    for method in ('round', 'truncate'):
        assert f'external function {method}(): {cls}' in base[start:]
for prop in ('sign', 'abs', 'ceil', 'floor'):
    assert f'abstract {prop}: Number' in base
assert subprocess.check_output(['git', '-C', str(R / 'external/pkl'), 'rev-parse', 'HEAD']).strip().decode() == draft['upstream_git_revision']
main = check_capture(P, values, {x['id']: expected_error(x) for x in read(P / 'cases.json')['rows'] if x['id'] in error_heads},
                     R / 'target/m2/stage78-number-primitives-oracle-prep-03/execution-01/process.json', 48)
supp_values = {}
for row in read(S / 'cases.json')['rows']:
    referent = re.search(r', (Int|Float|Number|String)>$', row['expression']).group(1)
    receiver = re.search(r'module\.ref(Int|Float|Number)\.', row['expression']).group(1)
    supp_values[row['id']] = 'true' if referent in (receiver, 'Number') else 'false'
supplement = check_capture(S, supp_values, {},
                           R / 'target/m2/stage78-number-reference-supplement-prep-01/execution-01/process.json', 24)
assert sum(v == 'true' for v in supp_values.values()) == 8
prior = []
for suffix in ('01', '02'):
    p = R / ('target/m2/stage78-number-primitives-oracle-' + suffix)
    row = p / 'repeat-0/004-int-abs-min'
    assert (row / 'expression.bin').read_bytes() == b'math.minInt.abs'
    wrong = '–– Pkl Error ––\nCannot find property `math`.\n\n1 | math.minInt.abs\n    ^^^^\nat  (repl:text)\n'
    assert (row / 'result.stderr.bin').read_bytes() == wrong.encode()
    assert read(p / 'provenance.json')['complete']
    prior.append({'provenance': bound(p / 'provenance.json'), 'audit': bound(p / 'audit.json'),
                  'minimum_abs_raw': bound(row / 'result.stderr.bin'), 'int_abs_min_intent_met': False,
                  'actual_error': 'Cannot find property `math`.', 'original_bytes_preserved': True})

source_names = [
    'external/pkl/stdlib/base.pkl', 'external/pkl/stdlib/ref.pkl',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/IntNodes.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/FloatNodes.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmSafeMath.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmReference.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/type/TypeNode.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/type/TypeTestNode.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/type/ResolveDeclaredTypeNode.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/type/ResolveSimpleDeclaredTypeNode.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/type/ResolveQualifiedDeclaredTypeNode.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/member/ClassProperty.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/VmModifier.java',
    'crates/pkl-runtime/src/value_identity.rs', 'crates/pkl-runtime/src/numeric.rs',
]
jdk_members = {}
with zipfile.ZipFile('/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home/lib/src.zip') as z:
    for name in ('java.base/java/lang/StrictMath.java', 'java.base/java/lang/Math.java', 'java.base/java/lang/Long.java'):
        b = z.read(name)
        jdk_members[name] = {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

put('raw-identities.json', raw_identities)
put('intent-matrix.json', intent_rows)
report = {
    'schema': 1, 'kind': 'stage78-number-primitives-independent-source-and-java-authority-review',
    'complete': True, 'approved': True, 'source_stable': True, 'observed_epoch': time.time(),
    'approval_scope': 'Source-only numeric draft and corrected48+supplement24 pinned Java observations. No Rust/native/platform compatibility result or production integration approval.',
    'reviewer_executed_java_compiler_or_canonical_mutation': False,
    'draft': bound(D / 'report.json'), 'production_patch': bound(D / 'combined.patch'),
    'original48': main, 'reference24': supplement, 'preserved_failed_intents': prior,
    'intent_matrix': bound(O / 'intent-matrix.json'), 'raw_identities': bound(O / 'raw-identities.json'),
    'actual_totals': {'rows': 72, 'success': 62, 'ordinary_pkl_errors': 10, 'oracle_or_api_errors': 0,
                      'per_repeat_raw_files': 1516, 'both_repeat_raw_files': 3032, 'both_repeat_raw_bytes': 62594},
    'source_inputs': [bound(R / x) for x in source_names], 'pinned_jdk_source_members': jdk_members,
    'source_findings': [
        'Int sign uses Long.signum; abs uses checked minimum overflow; ceil/floor/round/truncate are identity. Proposed Rust Int operations match these executable definitions.',
        'FloatNodes delegates to StrictMath.signum/abs/ceil/floor/rint and VmSafeMath.truncate. The Rust sign guard preserves NaN and both zero signs; abs clears the sign bit; ties-even round and negative-ceil/otherwise-floor truncate follow the pinned implementation. Exact emitted values remain untested in Rust.',
        'Pinned Number.sign prose says NaN yields0, but FloatNodes, pinned JDK Math.signum and actual Java NaN.sign yield NaN. Executable/raw authority governs; the draft preserves NaN.',
        'The property/method distinction is retained: sign/abs/ceil/floor are properties; round/truncate are zero-argument methods with exact concrete base signatures and source locations. Reference property metadata is Int/Float/Number respectively; methods are not synthetic referent methods.',
        'Bare ref and D in type syntax resolve through enclosing-module import/type lookup even though bare math value lookup in evaluator expressions failed. TypeTestNode executes ReferenceTypeNode domain and referent checks.',
        'Reference positive-only checks cannot exclude UNKNOWN because VmReference.referentTypeIsSubtypeOf returns true for UNKNOWN. Supplement negative controls now reject opposite concrete numeric types on each of the four observed concrete paths and reject Int/Float/String on all four Number-property paths, while the appropriate concrete/Number positives hold.',
        'VmReference checks exported PClass.Property.isExternal, while ClassProperty.export invokes VmModifier.export(modifiers,false), omitting EXTERNAL for property/method contracts. This explains why ref.pkl external-property prose alone does not predict the observed numeric property access; raw authority is retained.',
    ],
    'concrete_blockers_found': [],
    'remaining_scope': [
        'No Stage78 Rust candidate has compiled or been compared. All72 rows are Java authority only; error frames/hints, signed zero/NaN/infinity rendering and runtime type export require raw Rust comparison.',
        'Four concrete Reference paths are dynamically discriminated (Int.sign/abs, Float.sign/floor). Remaining concrete numeric metadata properties are source-reviewed, not additional Java controls; all four Number-property paths are discriminated.',
        'All rows use evaluateExpressionString. Java result.java-type is intentionally empty; this is not a typed export proof. Logger channels were not captured.',
        'The first two acquisitions are preserved but their int-abs-min row tested missing lexical math, not overflow. Only corrected03 provides that intended overflow authority.',
        'Stage76 and Stage78 both change primitives.rs. Merge narrow hunks into the actual frozen candidate; do not replace the whole Stage76 file with this older-base overlay.',
        'Original upstream modules, full workspace/platform/API/M2 and performance gates remain unexecuted/open for this draft.'
    ],
    'review_script': bound(Path(__file__).resolve()), 'frozen_after_sha_handoff': True,
}
put('report.json', report)
fd = os.open(O, os.O_RDONLY)
os.fsync(fd)
os.close(fd)
print(json.dumps(bound(O / 'report.json')))
