# Stage68 `Collection.isNotEmpty` 공통 속성 근거와 수정 범위

범위: Pkl 0.32.0 Java 원시 관찰 47개. `target/m2/stage68-collection-emptiness-oracle-01`의 42개 첫 입력과 두 JVM 세션은 이력으로 보존했고, `target/m2/stage68-collection-emptiness-oracle-02`에서 Reference 타입 확인 5개를 추가해 새 JVM 두 세션으로 다시 취득했다. 후보 Rust 평가·호환성 통과 주장은 없다.

## 관찰

- `external/pkl/stdlib/base.pkl`의 List, Set, Map, Listing, Mapping은 `isNotEmpty: Boolean` **속성**을 선언한다. 고정 Java `ListNodes`, `SetNodes`, `MapNodes`, `ListingNodes`, `MappingNodes`의 구현은 각각 `!self.isEmpty()`이다. 다섯 종류의 빈 값은 `false`, 한 항목 값은 `true`; `.isNotEmpty()`는 다섯 종류 모두 `Cannot find method` 오류다.
- Listing의 `isEmpty()`는 구조적 길이 `0` 검사다. 값이 `throw("listing-lazy")`인 한 항목 Listing에서도 `.isNotEmpty`는 `true`, `.isEmpty`는 `false`이며 `.toList()`가 그 오류를 드러낸다. Mapping의 항목 값이 `throw("mapping-lazy")`인 경우도 같다. Mapping의 `getLength()`는 부모 체인을 순회하고 중복·숨김 키를 반영하여 항목을 세며 값을 읽지 않는다. 키 식 자체의 `throw("key-bang")`와 중복 정의는 별도 오류로 관찰됐다.
- `List(isNotEmpty)`와 `List(!isNotEmpty)`, Listing·Mapping의 해당 제약에서 속성 조회가 이루어진다. 네 제약 확인식은 Java에서 모두 `true`였다.
- `ref.Reference`가 감싼 List·Set·Map의 `isNotEmpty` 접근은 `Reference<D, Boolean>`으로 합성된다. 같은 이름을 Listing·Mapping Reference에서 읽으면 `Cannot find property`가 난다. 이 구분은 `VmReference`의 참조 접근 규칙이며 컬렉션 값에 대한 직접 속성 조회와 별개다. Reference를 일괄 허용하지 않는다.

## 권장하는 후보 수정 경계

`crates/pkl-runtime/src/vm/collections.rs::collection_builtin`의 기존 `length`/`isEmpty` **속성** 경로에 List·Set·Map·Listing·Mapping용 `isNotEmpty`를 추가한다. 값은 현재 길이 `!= 0`으로 계산한다. Mapping의 아직 계산하지 않은 길이는 `length`/`isEmpty`와 같은 `count_mapping_keys` 중단·재개 경로를 거친 뒤 `!= 0`을 적용해야 한다. 항목 값을 강제하거나 Mapping의 내부 원시 멤버 수만 사용하면 지연·중복·숨김 사례의 우선순위가 바뀐다. Dynamic 및 메서드 호출 경로를 이 수정으로 넓히지 않는다. 제약의 implicit property 경로와 기존 Reference 합성/거절 규칙은 새 Java 행의 원시 출력으로 별도 확인한다.

## 취득과 한계

최종 입력은 `target/m2/stage68-collection-emptiness-prep-02/{module.pkl,cases.json,queries.tsv,run.py}`에 고정했다. 동일한 `tools/java/CollectionConversionsOracle.java`를 각 신선한 JVM에서 사용했다. 두 PID는 17740과 17741이며 각 세션 47행, 989개 원시 파일을 만들었다. 결과는 성공 34개, 일반 Pkl 오류 13개, 두 세션의 원시 파일은 동일하다. 58개 고정 소스 사본과 입력/JDK/JAR/실행 원시 스트림은 `provenance.json`에 기록됐다. 독립 전수 파일 재해시와 오류 행 검토는 `target/m2/stage68-collection-emptiness-review-01/report.json`에 있다. 이 관찰은 공통 속성의 작은 범위이며 원본 코퍼스, 전체 API, 플랫폼, 성능 게이트를 대체하지 않는다.
