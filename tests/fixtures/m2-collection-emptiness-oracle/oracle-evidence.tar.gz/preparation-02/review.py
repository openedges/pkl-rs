"""Read-only full raw/provenance review for the bounded Stage68 Java control."""
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
CAPTURE = ROOT / "target/m2/stage68-collection-emptiness-oracle-02"
INPUT = Path(__file__).resolve().parent
REPORT = ROOT / "target/m2/stage68-collection-emptiness-review-01/report.json"
CHANNELS = {"result.status.bin"}
for name in ("mode", "expression", "result.stdout", "result.stderr", "result.error-class",
             "result.exception-to-string", "result.cause-class", "result.cause-message",
             "result.cause-to-string", "result.java-type"):
    CHANNELS.update((name + ".bin", name + ".code-units.bin"))
ERROR_IDS = {f"{kind}-method" for kind in ("list", "set", "map", "listing", "mapping")}
ERROR_IDS.update(("listing-lazy-force", "mapping-lazy-force", "reference-listing",
                  "reference-mapping", "reference-listing-type", "reference-mapping-type",
                  "mapping-key-error", "mapping-duplicate"))


def sha(path):
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
            size += len(chunk)
    return {"bytes": size, "sha256": digest.hexdigest()}


def check(ok, message):
    if not ok:
        raise ValueError(message)


def main():
    check(not REPORT.exists(), "fresh review report required")
    cases = json.loads((INPUT / "cases.json").read_text())
    provenance = json.loads((CAPTURE / "provenance.json").read_text())
    audit = json.loads((CAPTURE / "audit.json").read_text())
    lock = json.loads((ROOT / "oracle.lock.json").read_text())
    rows = cases["rows"]
    check(cases["schema"] == 1 and cases["baseline"] == "Pkl 0.32.0"
          and cases["module_uri"] == "file:///stage68/collection-emptiness.pkl"
          and cases["repetitions"] == 2 and len(rows) == 47
          and len({r["id"] for r in rows}) == 47, "input contract differs")
    check((INPUT / "queries.tsv").read_text() == "".join(
        f"{r['mode']}\t{r['id']}\t{r['expression']}\n" for r in rows), "queries differ")
    check(all(r["mode"] == "string" for r in rows), "mixed mode")
    check(provenance["complete"] and provenance["stable"] and provenance["raw_equal"]
          and provenance["raw_files"] == 47 * 21 + 2
          and provenance["raw_differences"] == [], "acquisition protocol differs")
    check(provenance["oracle_lock_sha256"] == sha(ROOT / "oracle.lock.json")["sha256"]
          and provenance["references_lock_sha256"] == sha(ROOT / "references.lock")["sha256"]
          and provenance["reference_revision"] == lock["source"]["revision"]
          and provenance["artifact_sha256"] == provenance["artifact_after_sha256"]
          == lock["artifact"]["sha256"] == sha(Path(provenance["artifact"]))["sha256"],
          "oracle pin differs")
    check(all(provenance["jdk"]["properties"].get(k) == v
              for k, v in lock["jdk"]["properties"].items()), "JDK properties differ")
    for key in provenance["input_before"]:
        check(provenance["input_before"][key] == provenance["input_after"][key]
              == sha(CAPTURE / key)["sha256"], "copied input differs: " + key)
    check(sha(CAPTURE / "run.py") == sha(INPUT / "run.py"), "producer copy differs")
    check(sha(CAPTURE / "CollectionConversionsOracle.java")
          == sha(ROOT / "tools/java/CollectionConversionsOracle.java"), "Java helper differs")
    for key in provenance["source_before"]:
        check(provenance["source_before"][key] == provenance["source_after"][key]
              == sha(CAPTURE / "sources" / key)["sha256"]
              == sha(ROOT / key)["sha256"], "pinned source differs: " + key)
    check(len(provenance["source_before"]) == 58, "source count differs")
    sessions = provenance["sessions"]
    check(len(sessions) == 2 and [s["repeat"] for s in sessions] == [0, 1]
          and sessions[0]["pid"] != sessions[1]["pid"]
          and all(s["exit_code"] == 0 and s["query_directories"] == 47 for s in sessions),
          "JVM session count/identity differs")
    inventories = []
    for repeat, session in enumerate(sessions):
        folder = CAPTURE / f"repeat-{repeat}"
        expected_dirs = {f"{i:03d}-{r['id']}" for i, r in enumerate(rows)}
        check({p.name for p in folder.iterdir() if p.is_dir()} == expected_dirs,
              "ordered row directories differ")
        check(sha(folder / "process.stdout.bin")["sha256"] == session["stdout_sha256"]
              and sha(folder / "process.stderr.bin")["sha256"] == session["stderr_sha256"]
              and (folder / "process.stdout.bin").stat().st_size == session["stdout_bytes"]
              and (folder / "process.stderr.bin").stat().st_size == session["stderr_bytes"],
              "JVM process streams differ")
        inventory = {}
        for i, row in enumerate(rows):
            child = folder / f"{i:03d}-{row['id']}"
            check({p.name for p in child.iterdir()} == CHANNELS, "raw channels differ")
            status = (child / "result.status.bin").read_text()
            check(status in ("success\n", "error\n"), "ordinary status differs")
            check((status == "error\n") == (row["id"] in ERROR_IDS),
                  "authored first error intent differs: " + row["id"])
            check((child / "expression.bin").read_text() == row["expression"]
                  and (child / "mode.bin").read_text() == row["mode"], "raw query differs")
            for name in CHANNELS:
                path = child / name
                inventory[path.relative_to(folder).as_posix()] = sha(path)["sha256"]
            if repeat == 0:
                observed = audit["observations"][i]
                stderr = (child / "result.stderr.bin").read_text()
                lines = stderr.splitlines()
                check(observed["id"] == row["id"]
                      and observed["expression"] == row["expression"]
                      and observed["status"] + "\n" == status
                      and observed["first_error_line"] == (lines[1] if len(lines) > 1 else "")
                      and observed["stdout_sha256"] == sha(child / "result.stdout.bin")["sha256"]
                      and observed["stderr_sha256"] == sha(child / "result.stderr.bin")["sha256"],
                      "audit row differs")
                if status == "error\n":
                    check(observed["error_class"] == "org.pkl.core.PklException"
                          and observed["first_error_line"], "error class/line differs")
        for name in ("process.stdout.bin", "process.stderr.bin"):
            inventory[name] = sha(folder / name)["sha256"]
        inventories.append(inventory)
    check(inventories[0] == inventories[1] and len(inventories[0]) == 989,
          "full raw readback differs")
    check(audit["rows"] == 47 and audit["statuses"] == {"success": 34, "error": 13}
          and audit["candidate_compatibility_passes_claimed"] == 0,
          "audit scope/count differs")
    REPORT.parent.mkdir(parents=True, exist_ok=True)
    record = {"schema": 1, "kind": "stage68-collection-emptiness-java-review",
              "complete": True, "approved": True, "source_stable": True,
              "candidate_compatibility_passes_claimed": 0,
              "rows": 47, "success": 34, "ordinary_errors": 13,
              "fresh_jvm_pids": [s["pid"] for s in sessions], "raw_files_per_jvm": 989,
              "copied_sources": 58,
              "inputs": {p.relative_to(ROOT).as_posix(): sha(p)
                         for p in (INPUT / "run.py", INPUT / "cases.json", INPUT / "module.pkl",
                                   INPUT / "queries.tsv", CAPTURE / "provenance.json",
                                   CAPTURE / "audit.json", ROOT / "oracle.lock.json",
                                   ROOT / "references.lock", ROOT / "tools/java/CollectionConversionsOracle.java")},
              "limits": ["Target-only Java authority; no Rust/native/portable compatibility pass.",
                         "Raw repeat equality does not verify full M2/API/performance scope."]}
    REPORT.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: record[k] for k in ("complete", "rows", "success",
                                               "ordinary_errors", "copied_sources")}, sort_keys=True))


if __name__ == "__main__":
    sys.exit(main())
