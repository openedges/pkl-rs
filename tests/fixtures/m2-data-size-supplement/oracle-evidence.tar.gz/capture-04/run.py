from pathlib import Path
import hashlib,json,os,platform,re,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
lock=read(ROOT/'oracle.lock.json');jar=ROOT/'.cache/oracle'/lock['artifact']['filename']
assert sha(jar)==lock['artifact']['sha256']=='c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059'
refs=(ROOT/'references.lock').read_text();assert 'pkl.revision='+lock['source']['revision'] in refs and lock['source']['revision']=='e51fb2f91774265666f94980ec630db794a4db2d' and lock['version']=='0.32.0'
java=Path(os.environ.get('PKL_ORACLE_JAVA','/usr/bin/java')).resolve()
env={'PATH':os.defpath,'HOME':str(ROOT/'.cache/oracle/home'),'TMPDIR':str(ROOT/'.cache/oracle/tmp'),'TMP':str(ROOT/'.cache/oracle/tmp'),'TEMP':str(ROOT/'.cache/oracle/tmp'),'LC_ALL':'C','LANG':'C','TZ':'UTC','TERM':'dumb','NO_COLOR':'1','COLUMNS':'80'}
identity=subprocess.run([str(java),'-XshowSettings:properties','-version'],cwd=OUT,env=env,capture_output=True,timeout=60)
(OUT/'java-identity.stdout.bin').write_bytes(identity.stdout);(OUT/'java-identity.stderr.bin').write_bytes(identity.stderr);assert identity.returncode==0
props=dict(re.findall(r'^\s+([\w.]+) = (.*)$',identity.stderr.decode(),re.M))
for k,v in lock['jdk']['properties'].items():assert props[k]==v,(k,props[k],v)
home=Path(props['java.home']);jdk={'executable':str(java),'executable_sha256':sha(java),'modules_sha256':sha(home/'lib/modules'),'release_sha256':sha(home/'release'),'properties':{k:props[k] for k in ['java.vendor','java.version','java.runtime.version','java.vm.name','java.vm.version','java.home','os.name','os.arch','os.version']}}
inputs=['DataSizeSplitOracle.java','run.py','module.pkl','queries.tsv','cases.json'];sources=['external/pkl/stdlib/base.pkl','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmDataSize.java','external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/DataSizeNodes.java','external/pkl/pkl-core/src/main/java/org/pkl/core/DataSizeUnit.java','external/pkl/pkl-core/src/main/java/org/pkl/core/DataSize.java']
input_before={n:sha(OUT/n) for n in inputs};source_before={n:sha(ROOT/n) for n in sources};m=read(OUT/'cases.json')
assert m['schema']==1 and m['repetitions']==2 and m['boundaries']==['string','export'] and len(m['rows'])==44
assert (OUT/'queries.tsv').read_text()==''.join(x['id']+'\t'+x['expression']+'\n' for x in m['rows'])
options=lock['jvm_options']+[f'-Duser.home={env["HOME"]}',f'-Djava.io.tmpdir={env["TMPDIR"]}']
result={'schema':2,'scope':'Additive exploratory separate Java 0.32.0 public string-query and exported-value evaluator sessions; no Rust candidate.','host':platform.platform(),'oracle_lock_sha256':sha(ROOT/'oracle.lock.json'),'references_lock_sha256':sha(ROOT/'references.lock'),'reference_revision':lock['source']['revision'],'artifact':str(jar),'artifact_sha256':sha(jar),'jdk':jdk,'environment':env,'input_before':input_before,'source_before':source_before,'sessions':[]}
(OUT/'provenance.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
for mode in m['boundaries']:
 for repeat in range(m['repetitions']):
  folder=OUT/mode/f'repeat-{repeat}';folder.mkdir(parents=True,exist_ok=False)
  cmd=[str(java),*options,'-cp',str(jar),str(OUT/'DataSizeSplitOracle.java'),mode,str(folder),str(OUT),m['module_uri']]
  start=time.time();p=subprocess.Popen(cmd,cwd=OUT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=p.communicate(timeout=1200)
  (folder/'process.stdout.bin').write_bytes(stdout);(folder/'process.stderr.bin').write_bytes(stderr)
  entry={'mode':mode,'repeat':repeat,'pid':p.pid,'command':cmd,'cwd':str(OUT),'exit_code':p.returncode,'started_epoch':start,'finished_epoch':time.time(),'stdout_sha256':sha(folder/'process.stdout.bin'),'stderr_sha256':sha(folder/'process.stderr.bin'),'stdout_bytes':len(stdout),'stderr_bytes':len(stderr),'query_directories':len([x for x in folder.iterdir() if x.is_dir()])}
  result['sessions'].append(entry);(OUT/'provenance.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
  print(json.dumps({'mode':mode,'repeat':repeat,'exit_code':p.returncode,'rows':entry['query_directories'],'stdout_bytes':len(stdout),'stderr_bytes':len(stderr)}),flush=True)
  if p.returncode!=0 or entry['query_directories']!=44:break
 if result['sessions'][-1]['exit_code']!=0:break
result['input_after']={n:sha(OUT/n) for n in inputs};result['source_after']={n:sha(ROOT/n) for n in sources};result['artifact_after_sha256']=sha(jar)
result['stable']=result['input_before']==result['input_after'] and result['source_before']==result['source_after'] and result['artifact_sha256']==result['artifact_after_sha256']
for mode in m['boundaries']:
 a=OUT/mode/'repeat-0';b=OUT/mode/'repeat-1'
 if a.is_dir() and b.is_dir():
  def files(folder):return {x.relative_to(folder).as_posix():sha(x) for x in folder.rglob('*') if x.is_file()}
  x,y=files(a),files(b);result[mode+'_raw_equal']=x==y;result[mode+'_files']=len(x);result[mode+'_raw_differences']=[n for n in sorted(set(x)|set(y)) if x.get(n)!=y.get(n)]
result['complete']=len(result['sessions'])==4 and all(x['exit_code']==0 and x['query_directories']==255 for x in result['sessions']) and result.get('string_raw_equal') and result.get('export_raw_equal') and result['stable']
(OUT/'provenance.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'complete':result['complete'],'stable':result['stable'],'string_raw_equal':result.get('string_raw_equal'),'export_raw_equal':result.get('export_raw_equal'),'string_files':result.get('string_files'),'export_files':result.get('export_files')}),flush=True)
sys.exit(0 if result['complete'] else 1)
