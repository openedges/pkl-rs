import java.io.DataOutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
public final class DataSizeBytesIdentity {
  static void utf8(Path dir,String name,String value) throws Exception {
    Files.write(dir.resolve(name+".bin"),value.getBytes(StandardCharsets.UTF_8));
    try(var out=new DataOutputStream(Files.newOutputStream(dir.resolve(name+".code-units.bin"))))
      {for(int i=0;i<value.length();i++)out.writeChar(value.charAt(i));}
  }
  static String message(Throwable value){return value.getMessage()==null?value.toString():value.getMessage();}
  public static void main(String[] args) throws Exception {
    if(args.length!=3)throw new IllegalArgumentException("OUTPUT INPUT URI");
    var output=Path.of(args[0]);var input=Path.of(args[1]);
    var source=ModuleSource.create(URI.create(args[2]),Files.readString(input.resolve("module.pkl"),StandardCharsets.UTF_8));
    var queries=Files.readAllLines(input.resolve("queries.tsv"),StandardCharsets.UTF_8);
    int calls=0,errors=0;
    System.out.println("session-open rows="+queries.size());
    try(var evaluator=EvaluatorBuilder.preconfigured().setModuleCacheDir(null).setColor(false)
        .setPowerAssertionsEnabled(false).setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      for(int index=0;index<queries.size();index++){
        var parts=queries.get(index).split("\t",-1);if(parts.length!=2)throw new IllegalArgumentException("bad query");
        var dir=output.resolve(String.format("%03d-%s",index,parts[0]));Files.createDirectory(dir);
        utf8(dir,"expression",parts[1]);Object[] values=new Object[2];String[] statuses=new String[2];
        for(int repeat=0;repeat<2;repeat++){
          String call="export-"+index+"-"+parts[0]+"-"+repeat;System.out.println("call-enter="+call);calls++;
          String error="",type="",text="",hash="";String status="success";
          try{values[repeat]=evaluator.evaluateExpression(source,parts[1]);type=values[repeat]==null?"null":values[repeat].getClass().getName();text=String.valueOf(values[repeat]);hash=values[repeat]==null?"":Integer.toString(values[repeat].hashCode());}
          catch(Throwable thrown){status="error";error=message(thrown);type=thrown.getClass().getName();errors++;}
          statuses[repeat]=status;utf8(dir,"call-"+repeat+".status",status+"\n");utf8(dir,"call-"+repeat+".error",error);
          utf8(dir,"call-"+repeat+".java-type",type);utf8(dir,"call-"+repeat+".text",text);utf8(dir,"call-"+repeat+".hash",hash);
          System.out.println("call-exit="+call+" status="+status);
        }
        if(statuses[0].equals("success")&&statuses[1].equals("success")){
          utf8(dir,"comparison.reference",Boolean.toString(values[0]==values[1]));
          utf8(dir,"comparison.equals",Boolean.toString(values[0].equals(values[1])));
          utf8(dir,"comparison.hash-equal",Boolean.toString(values[0].hashCode()==values[1].hashCode()));
        }else{for(var name:new String[]{"comparison.reference","comparison.equals","comparison.hash-equal"})utf8(dir,name,"");}
      }
    }
    System.out.println("session-closed rows="+queries.size()+" public-calls="+calls+" errors="+errors);
  }
}
