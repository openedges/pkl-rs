from pathlib import Path
import hashlib,json,os,platform,re,subprocess,time
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
lock=read(ROOT/'oracle.lock.json');jar=ROOT/'.cache/oracle'/lock['artifact']['filename']
assert lock['version']=='0.32.0' and lock['source']['revision']=='e51fb2f91774265666f94980ec630db794a4db2d' and sha(jar)==lock['artifact']['sha256']=='c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059'
java=Path(os.environ.get('PKL_ORACLE_JAVA','/usr/bin/java')).resolve()
env={'PATH':os.defpath,'HOME':str(ROOT/'.cache/oracle/home'),'TMPDIR':str(ROOT/'.cache/oracle/tmp'),'TMP':str(ROOT/'.cache/oracle/tmp'),'TEMP':str(ROOT/'.cache/oracle/tmp'),'LC_ALL':'C','LANG':'C','TZ':'UTC','TERM':'dumb','NO_COLOR':'1','COLUMNS':'80'}
identity=subprocess.run([str(java),'-XshowSettings:properties','-version'],cwd=OUT,env=env,capture_output=True,timeout=60)
(OUT/'java-identity.stdout.bin').write_bytes(identity.stdout);(OUT/'java-identity.stderr.bin').write_bytes(identity.stderr)
assert identity.returncode==0
props=dict(re.findall(r'^\s+([\w.]+) = (.*)$',identity.stderr.decode(),re.M))
for k,v in lock['jdk']['properties'].items():assert props[k]==v
home=Path(props['java.home']);jdk={'executable':str(java),'executable_sha256':sha(java),'modules_sha256':sha(home/'lib/modules'),'release_sha256':sha(home/'release'),'properties':{k:props[k] for k in ['java.vendor','java.version','java.runtime.version','java.vm.name','java.vm.version','java.home','os.name','os.arch','os.version']}}
inputs=['DataSizeBytesIdentity.java','module.pkl','queries.tsv','cases.json','run.py']
sources=['external/pkl/stdlib/base.pkl','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmDataSize.java','external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/DataSizeNodes.java','external/pkl/pkl-core/src/main/java/org/pkl/core/DataSizeUnit.java','external/pkl/pkl-core/src/main/java/org/pkl/core/DataSize.java']
before={n:sha(OUT/n) for n in inputs};source_before={n:sha(ROOT/n) for n in sources};m=read(OUT/'cases.json')
assert m['schema']==1 and m['baseline']=='Pkl 0.32.0' and len(m['rows'])==8 and m['repetitions']==2
assert (OUT/'queries.tsv').read_text()==''.join(x['id']+'\t'+x['expression']+'\n' for x in m['rows'])
result={'schema':1,'scope':'Additive public Bytes/size export identity and local name shadowing; actual Java, no Rust candidate','host':platform.platform(),'reference_revision':lock['source']['revision'],'oracle_lock_sha256':sha(ROOT/'oracle.lock.json'),'references_lock_sha256':sha(ROOT/'references.lock'),'artifact':str(jar),'artifact_sha256':sha(jar),'jdk':jdk,'environment':env,'input_before':before,'source_before':source_before,'runs':[]}
def save():(OUT/'provenance.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
save();options=[*lock['jvm_options'],f'-Duser.home={env["HOME"]}',f'-Djava.io.tmpdir={env["TMPDIR"]}']
for repeat in range(2):
 folder=OUT/f'repeat-{repeat}';folder.mkdir(parents=True,exist_ok=False)
 cmd=[str(java),*options,'-cp',str(jar),str(OUT/'DataSizeBytesIdentity.java'),str(folder),str(OUT),m['module_uri']]
 start=time.time();proc=subprocess.Popen(cmd,cwd=OUT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=proc.communicate(timeout=1200)
 (folder/'process.stdout.bin').write_bytes(stdout);(folder/'process.stderr.bin').write_bytes(stderr)
 entry={'repeat':repeat,'pid':proc.pid,'command':cmd,'cwd':str(OUT),'exit_code':proc.returncode,'started_epoch':start,'finished_epoch':time.time(),'stdout_sha256':sha(folder/'process.stdout.bin'),'stderr_sha256':sha(folder/'process.stderr.bin'),'stdout_bytes':len(stdout),'stderr_bytes':len(stderr),'query_directories':sum(x.is_dir() for x in folder.iterdir())}
 result['runs'].append(entry);save();print(json.dumps({'repeat':repeat,'exit':proc.returncode,'rows':entry['query_directories'],'stdout':len(stdout),'stderr':len(stderr)}),flush=True)
 if proc.returncode!=0 or entry['query_directories']!=8:break
result['input_after']={n:sha(OUT/n) for n in inputs};result['source_after']={n:sha(ROOT/n) for n in sources};result['artifact_after_sha256']=sha(jar)
def files(folder):return {x.relative_to(folder).as_posix():sha(x) for x in folder.rglob('*') if x.is_file()}
a,b=files(OUT/'repeat-0'),files(OUT/'repeat-1')
result['raw_equal']=a==b;result['raw_files']=len(a);result['raw_differences']=[n for n in sorted(set(a)|set(b)) if a.get(n)!=b.get(n)]
result['stable']=result['input_before']==result['input_after'] and result['source_before']==result['source_after'] and result['artifact_sha256']==result['artifact_after_sha256']
result['complete']=len(result['runs'])==2 and all(x['exit_code']==0 and x['query_directories']==8 for x in result['runs']) and result['raw_equal'] and result['stable']
save();print(json.dumps({'complete':result['complete'],'raw_equal':result['raw_equal'],'raw_files':result['raw_files']}));raise SystemExit(0 if result['complete'] else 1)
