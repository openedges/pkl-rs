from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent;ROOT=O.parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def need(ok,msg):
 if not ok:raise ValueError(msg)
def text(d,n):return (d/f'{n}.bin').read_text()
def check(d,n):
 raw=(d/f'{n}.bin').read_bytes();units=(d/f'{n}.code-units.bin').read_bytes()
 need(len(units)%2==0 and units.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==raw,f'UTF16/raw mismatch: {d}/{n}')
def files(d):return {p.relative_to(d).as_posix():sha(p) for p in d.rglob('*') if p.is_file()}
p=read(O/'provenance.json');m=read(O/'cases.json');rows=m['rows'];n=len(rows)
need(p['complete'] and p['stable'] and p['raw_equal'] and p['raw_differences']==[],'incomplete acquisition')
need(n==8 and m['schema']==1 and m['baseline']=='Pkl 0.32.0' and m['repetitions']==2,'input schema/count')
need((O/'queries.tsv').read_text()==''.join(x['id']+'\t'+x['expression']+'\n' for x in rows),'ordered queries')
need(p['input_before']==p['input_after'] and p['source_before']==p['source_after'],'input/source drift')
for name,value in p['input_before'].items():need(sha(O/name)==value,'input hash')
for name,value in p['source_before'].items():need(sha(ROOT/name)==value,'source hash')
need(p['artifact_sha256']==p['artifact_after_sha256']==sha(p['artifact'])=='c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059','JAR pin')
need(p['oracle_lock_sha256']==sha(ROOT/'oracle.lock.json') and p['references_lock_sha256']==sha(ROOT/'references.lock'),'lock pin')
need(p['reference_revision']=='e51fb2f91774265666f94980ec630db794a4db2d','revision pin')
need(sha(p['jdk']['executable'])==p['jdk']['executable_sha256'],'JDK executable')
home=Path(p['jdk']['properties']['java.home']);need(sha(home/'lib/modules')==p['jdk']['modules_sha256'] and sha(home/'release')==p['jdk']['release_sha256'],'JDK image')
need(len(p['runs'])==2 and [r['repeat'] for r in p['runs']]==[0,1] and len({r['pid'] for r in p['runs']})==2,'process coverage')
channels={x+s for x in ['expression']+[f'call-{r}.{y}' for r in range(2) for y in ['status','error','java-type','text','hash']]+[f'comparison.{y}' for y in ['reference','equals','hash-equal']] for s in ['.bin','.code-units.bin']}
need(len(channels)==28,'channel definition')
observations=[];sessions=[]
for run in p['runs']:
 repeat=run['repeat'];folder=O/f'repeat-{repeat}'
 need(run['exit_code']==0 and run['query_directories']==n and run['cwd']==str(O),'process result')
 need(run['command'][-3:]==[str(folder),str(O),m['module_uri']] and run['command'][0]==p['jdk']['executable'] and run['command'][-5]==p['artifact'],'command/module')
 for channel in ['stdout','stderr']:
  payload=(folder/f'process.{channel}.bin').read_bytes()
  need(len(payload)==run[f'{channel}_bytes'] and sha(folder/f'process.{channel}.bin')==run[f'{channel}_sha256'],'process raw')
 need((folder/'process.stderr.bin').read_bytes()==b'','process stderr')
 lines=[f'session-open rows={n}'];calls=errors=0
 for index,row in enumerate(rows):
  d=folder/f'{index:03d}-{row["id"]}';need(d.is_dir() and {f.name for f in d.iterdir() if f.is_file()}==channels,'query dir/channels')
  for name in ['expression']+[f'call-{r}.{y}' for r in range(2) for y in ['status','error','java-type','text','hash']]+[f'comparison.{y}' for y in ['reference','equals','hash-equal']]:check(d,name)
  need(text(d,'expression')==row['expression'],'executed expression')
  statuses=[]
  for ordinal in range(2):
   status=text(d,f'call-{ordinal}.status');need(status in ('success\n','error\n'),'call status');statuses.append(status.strip())
   if status=='success\n':need(text(d,f'call-{ordinal}.error')=='','success error channel')
   else:need(text(d,f'call-{ordinal}.error') and text(d,f'call-{ordinal}.java-type')=='org.pkl.core.PklException','ordinary Pkl error channel');errors+=1
   call=f'export-{index}-{row["id"]}-{ordinal}';lines.extend([f'call-enter={call}',f'call-exit={call} status={status.strip()}']);calls+=1
  for name in ['reference','equals','hash-equal']:
   value=text(d,f'comparison.{name}')
   need(value in ('true','false') if statuses==['success','success'] else value=='','comparison outcome/channel')
  if repeat==0:observations.append({'id':row['id'],'expression':row['expression'],'statuses':statuses,'java_type':text(d,'call-0.java-type'),'text':text(d,'call-0.text'),'error':text(d,'call-0.error'),'repeat_reference':text(d,'comparison.reference'),'repeat_java_equals':text(d,'comparison.equals'),'repeat_java_hash_equal':text(d,'comparison.hash-equal')})
 lines.append(f'session-closed rows={n} public-calls={calls} errors={errors}')
 need((folder/'process.stdout.bin').read_bytes()==('\n'.join(lines)+'\n').encode(),'complete process protocol')
 sessions.append({'repeat':repeat,'public_calls':calls,'ordinary_errors':errors,'raw_files':len(files(folder)),'stdout_sha256':run['stdout_sha256']})
need(files(O/'repeat-0')==files(O/'repeat-1') and len(files(O/'repeat-0'))==p['raw_files']==226,'raw repetition/file count')
need([x['ordinary_errors'] for x in sessions]==[6,6] and [x['public_calls'] for x in sessions]==[16,16],'observed process counts')
result={'scope':'Additive actual Java public byte-array/DataSize wrapper identity and local Bytes call-resolution; not Pkl-language equality equivalence or Rust compatibility','baseline':'Pkl 0.32.0','module_uri':m['module_uri'],'provenance_sha256':sha(O/'provenance.json'),'input_sha256':p['input_before'],'source_sha256':p['source_before'],'artifact_sha256':p['artifact_sha256'],'jdk':p['jdk'],'sessions':sessions,'observations':observations,'raw_repeat_equal':True,'compatibility_passes_claimed':0,'limits':['Java byte[] equals/hash use array reference semantics and do not establish Pkl Bytes language equality','Exported DataSize wrappers are newly materialized; their reference difference does not disprove VM Bytes.size cache','Local let named Bytes did not shadow call resolution in these three inputs; module-level/function shadowing still unexecuted']}
(O/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'verified':True,'rows':n,'sessions':sessions,'identity_rows':len(observations)},sort_keys=True))
