# Qualified Bytes method resolution

Actual Java 0.32.0 split string/export sessions, two JVMs per boundary, with `function Bytes(x: Int): Int = x` in the module. `this.Bytes(256)` and `module.Bytes(256)` call the user method and return Int 256. `this.Bytes()` reports the declared method's one-argument arity error; `this.Bytes` as a property reports a property lookup error. Unqualified query `Bytes(256)` continues to call the built-in UInt8 factory and fails. Exact raw channels, process protocol and repeated bytes are independently checked in `audit.json`; no Rust candidate claim.
