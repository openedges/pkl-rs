from pathlib import Path
from collections import Counter
import hashlib,json,re
O=Path(__file__).resolve().parent;ROOT=O.parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def require(ok,msg):
 if not ok:raise ValueError(msg)
def raw(folder):return {p.relative_to(folder).as_posix():sha(p) for p in folder.rglob('*') if p.is_file()}
def txt(d,name):return (d/f'{name}.bin').read_text()
def checked(d,name):
 value=(d/f'{name}.bin').read_bytes();units=(d/f'{name}.code-units.bin').read_bytes()
 require(len(units)%2==0 and units.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==value,f'UTF16/raw mismatch {d}/{name}')
 return value.decode('utf-8')
p=read(O/'provenance.json');m=read(O/'cases.json');rows=m['rows'];n=len(rows)
require(p['complete'] and p['stable'] and p['string_raw_equal'] and p['export_raw_equal'],'incomplete acquisition')
require(m['schema']==1 and m['baseline']=='Pkl 0.32.0' and m['boundaries']==['string','export'] and m['repetitions']==2 and n==44,'input schema/count')
require(len({x['id'] for x in rows})==n and (O/'queries.tsv').read_text()==''.join(x['id']+'\t'+x['expression']+'\n' for x in rows),'ordered query bytes')
require(p['input_before']==p['input_after'] and p['source_before']==p['source_after'],'input/source drift')
for name,digest in p['input_before'].items():require(sha(O/name)==digest,'input hash drift '+name)
for name,digest in p['source_before'].items():require(sha(ROOT/name)==digest,'source hash drift '+name)
require(p['artifact_sha256']==p['artifact_after_sha256']=='c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059' and sha(p['artifact'])==p['artifact_sha256'],'JAR drift')
require(sha(ROOT/'oracle.lock.json')==p['oracle_lock_sha256'] and sha(ROOT/'references.lock')==p['references_lock_sha256'],'lock drift')
require(sha(p['jdk']['executable'])==p['jdk']['executable_sha256'],'JDK executable drift')
home=Path(p['jdk']['properties']['java.home'])
require(sha(home/'lib/modules')==p['jdk']['modules_sha256'] and sha(home/'release')==p['jdk']['release_sha256'],'JDK image drift')
require([(x['mode'],x['repeat']) for x in p['sessions']]==[('string',0),('string',1),('export',0),('export',1)],'session order/count')
strings={'result.status.bin'}|{x+s for x in ['expression','result.stdout','result.stderr','result.error-class'] for s in ['.bin','.code-units.bin']}
base={'repeat-invoked.bin','call-0.status.bin','call-0.payload-status.bin'}|{x+s for x in ['expression']+[f'call-0.{v}' for v in ['error','error-class','java-type','payload-error','text','raw-bits-hex','unit','hash']] for s in ['.bin','.code-units.bin']}
extra={'call-1.status.bin','call-1.payload-status.bin','comparison.status.bin'}|{x+s for x in [f'call-1.{v}' for v in ['error','error-class','java-type','payload-error','text','raw-bits-hex','unit','hash']]+[f'comparison.{v}' for v in ['error','reference','equals','hash-equal']] for s in ['.bin','.code-units.bin']}
require((len(strings),len(base),len(extra))==(9,21,27),'channel definitions')
observations=[];sessions=[]
for entry in p['sessions']:
 mode=entry['mode'];repeat=entry['repeat'];folder=O/mode/f'repeat-{repeat}'
 require(entry['exit_code']==0 and entry['query_directories']==n and entry['cwd']==str(O),'process outcome/cwd')
 require(entry['command'][-4:]==[mode,str(folder),str(O),m['module_uri']] and entry['command'][0]==p['jdk']['executable'] and entry['command'][-6]==p['artifact'],'command/module URI')
 for channel in ['stdout','stderr']:
  value=(folder/f'process.{channel}.bin').read_bytes()
  require(sha(folder/f'process.{channel}.bin')==entry[f'{channel}_sha256'] and len(value)==entry[f'{channel}_bytes'],'process raw channel')
 require((folder/'process.stderr.bin').read_bytes()==b'','process stderr')
 lines=[f'session-open mode={mode} rows={n}'];calls=success=errors=datasizes=repeats=0
 for i,row in enumerate(rows):
  id=row['id'];d=folder/f'{i:03d}-{id}'
  require(d.is_dir() and checked(d,'expression')==row['expression'],'query expression/order')
  if mode=='string':
   require({x.name for x in d.iterdir() if x.is_file()}==strings,'string exact channels')
   for name in ['result.stdout','result.stderr','result.error-class']:checked(d,name)
   status=txt(d,'result.status').strip();require(status in ('success','error'),'string unexpected status')
   if status=='success':require(txt(d,'result.stderr')==txt(d,'result.error-class')=='','successful string error channels')
   else:require(txt(d,'result.stdout')=='' and txt(d,'result.stderr') and txt(d,'result.error-class').startswith('org.pkl.'),'ordinary error channels')
   lines.extend([f'call-enter=string-{i}-{id}',f'call-exit=string-{i}-{id} status={status}']);calls+=1;success+=status=='success';errors+=status=='error'
   if repeat==0:observations.append({'id':id,'group':row['group'],'expression':row['expression'],'authored_hypothesis':row['authored_hypothesis'],'string_status':status,'string_stdout_sha256':sha(d/'result.stdout.bin'),'string_stderr_sha256':sha(d/'result.stderr.bin'),'string_stdout':txt(d,'result.stdout'),'string_stderr':txt(d,'result.stderr'),'producer_error_class':txt(d,'result.error-class')})
  else:
   repeatflag=txt(d,'repeat-invoked');require(repeatflag in ('true','false'),'repeat flag')
   require({x.name for x in d.iterdir() if x.is_file()}==(base|extra if repeatflag=='true' else base),'export exact channels')
   for name in ['call-0.error','call-0.error-class','call-0.java-type','call-0.payload-error','call-0.text','call-0.raw-bits-hex','call-0.unit','call-0.hash']:checked(d,name)
   status=txt(d,'call-0.status').strip();payload=txt(d,'call-0.payload-status').strip();require(status in ('success','error'),'export unexpected status')
   require(payload==('success' if status=='success' else 'not-applicable'),'payload status')
   require(repeatflag==('true' if txt(d,'call-0.java-type')=='org.pkl.core.DataSize' else 'false'),'repeat cause')
   require(status==observations[i]['string_status'],'split boundary status disagreement')
   call=f'export-{i}-{id}-0';lines.extend([f'call-enter={call}',f'call-exit={call} status={status}']);calls+=1;success+=status=='success';errors+=status=='error'
   if status=='success':lines.extend([f'payload-enter={call}',f'payload-exit={call} status={payload}'])
   if repeatflag=='true':
    datasizes+=1;repeats+=1
    require(re.fullmatch('[0-9a-f]{16}',txt(d,'call-0.raw-bits-hex')) and txt(d,'call-0.unit') in ('b','kb','kib','mb','mib','gb','gib','tb','tib','pb','pib'),'DataSize export payload')
    for name in ['call-1.error','call-1.error-class','call-1.java-type','call-1.payload-error','call-1.text','call-1.raw-bits-hex','call-1.unit','call-1.hash','comparison.error','comparison.reference','comparison.equals','comparison.hash-equal']:checked(d,name)
    require(txt(d,'call-1.status')=='success\n' and txt(d,'call-1.payload-status')=='success\n' and txt(d,'comparison.status')=='success\n','repeat/comparison status')
    call=f'export-{i}-{id}-1';compare=f'export-{i}-{id}-comparison';lines.extend([f'call-enter={call}',f'call-exit={call} status=success',f'payload-enter={call}',f'payload-exit={call} status=success',f'comparison-enter={compare}',f'comparison-exit={compare} status=success']);calls+=1;success+=1
   if repeat==0:observations[i].update(export_status=status,producer_java_type=txt(d,'call-0.java-type'),export_raw_bits=txt(d,'call-0.raw-bits-hex'),export_unit=txt(d,'call-0.unit'),export_hash=txt(d,'call-0.hash'),export_text=txt(d,'call-0.text'),export_repeat=repeatflag)
 lines.append(f'session-closed mode={mode} rows={n} public-calls={calls} success={success} errors={errors} datasize-rows={datasizes} repeated-export-calls={repeats}')
 require((folder/'process.stdout.bin').read_bytes()==('\n'.join(lines)+'\n').encode(),'full process protocol')
 sessions.append({'mode':mode,'repeat':repeat,'public_evaluator_calls':calls,'success':success,'ordinary_errors':errors,'datasize_rows':datasizes,'repeat_calls':repeats,'raw_files':len(raw(folder)),'process_stdout_sha256':entry['stdout_sha256']})
for mode in ('string','export'):
 a,b=raw(O/mode/'repeat-0'),raw(O/mode/'repeat-1')
 require(a==b and len(a)==p[f'{mode}_files'] and p[f'{mode}_raw_differences']==[],'full raw repeat/file count')
result={'scope':'Additive actual public Java 0.32.0 split DataSize/Bytes observations, no Rust candidate comparison','baseline':'Pkl 0.32.0','module_uri':m['module_uri'],'queries':n,'sessions':sessions,'observations':observations,'string_outcomes':dict(Counter(x['string_status'] for x in observations)),'export_outcomes':dict(Counter(x['export_status'] for x in observations)),'artifact_sha256':p['artifact_sha256'],'jdk':p['jdk'],'inputs_sha256':p['input_before'],'sources_sha256':p['source_before'],'provenance_sha256':sha(O/'provenance.json'),'raw_repeat_equal':{'string':True,'export':True},'compatibility_passes_claimed':0,'earlier_attempt':'stage57-datasize-oracle-04 preserved with complete=false due wrapper row-count metadata bug; all four actual Java sessions exited zero and raw-repeat equality held.'}
(O/'audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'verified':True,'rows':n,'string_outcomes':result['string_outcomes'],'export_outcomes':result['export_outcomes'],'sessions':sessions},sort_keys=True))
