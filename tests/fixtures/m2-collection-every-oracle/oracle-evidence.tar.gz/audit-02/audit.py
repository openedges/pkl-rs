"""Read-only exact-channel audit of the pinned collection every() capture."""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CAPTURE = ROOT / "target/m2/stage68-collection-every-oracle-03"
OLDER = ROOT / "target/m2/stage68-collection-every-oracle-02"
PREP = ROOT / "target/m2/stage68-collection-every-prep-03"
LAUNCH = ROOT / "target/m2/stage68-collection-every-launch-03"
BASE_FILES = {
    "mode.bin", "mode.code-units.bin", "expression.bin", "expression.code-units.bin",
    "result.status.bin", "result.stdout.bin", "result.stdout.code-units.bin",
    "result.stderr.bin", "result.stderr.code-units.bin", "result.error-class.bin",
    "result.error-class.code-units.bin", "result.exception-to-string.bin",
    "result.exception-to-string.code-units.bin", "result.cause-class.bin",
    "result.cause-class.code-units.bin", "result.cause-message.bin",
    "result.cause-message.code-units.bin", "result.cause-to-string.bin",
    "result.cause-to-string.code-units.bin", "result.java-type.bin",
    "result.java-type.code-units.bin", "logs.count.bin",
}
LOG_FIELDS = ("level", "message", "module-uri", "member", "position")

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def identity(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": len(data), "sha256": sha(data)}

def files(path: Path) -> dict[str, str]:
    return {p.name: sha(p.read_bytes()) for p in path.iterdir() if p.is_file()}

def utf16be(text: bytes) -> bytes:
    return text.decode("utf-8").encode("utf-16-be", "surrogatepass")

def main() -> None:
    if (HERE / "report.json").exists():
        raise ValueError("fresh audit required")
    report = json.loads((CAPTURE / "report.json").read_bytes())
    cases = json.loads((CAPTURE / "cases.json").read_bytes())
    launch = json.loads((LAUNCH / "process.json").read_bytes())
    if not (report["complete"] and report["source_stable"] and report["input_stable"] and report["raw_equal"]):
        raise ValueError("capture is incomplete or unstable")
    if report["rows"] != 64 or len(cases["rows"]) != 64 or [s["exit_code"] for s in report["sessions"]] != [0, 0] or len({s["pid"] for s in report["sessions"]}) != 2:
        raise ValueError("authored rows/JVM sessions differ")
    if not launch["source_stable"] or launch["exit_code"] != 0 or launch["stdout"] != {key: identity(LAUNCH / "stdout.bin")[key] for key in ("bytes", "sha256")} or launch["stderr"] != {key: identity(LAUNCH / "stderr.bin")[key] for key in ("bytes", "sha256")}:
        raise ValueError("outer launch process differs")
    if not (report["inputs_before"] == report["inputs_after"] == {name: sha((PREP / name).read_bytes()) for name in report["inputs_before"]} == {name: sha((CAPTURE / name).read_bytes()) for name in report["inputs_before"]}):
        raise ValueError("authored/producer inputs differ")
    if not (report["sources_before"] == report["sources_after"] == report["source_copies_after"]):
        raise ValueError("pinned source maps differ")
    for name, expected in report["sources_before"].items():
        if sha((ROOT / name).read_bytes()) != expected or sha((CAPTURE / "sources" / name).read_bytes()) != expected:
            raise ValueError(f"pinned source/copy differs: {name}")
    observed = []
    file_count = 0
    for index, row in enumerate(cases["rows"]):
        name = f"{index:03d}-{row['id']}"
        left = CAPTURE / "repeat-0" / name
        right = CAPTURE / "repeat-1" / name
        left_files = files(left)
        if left_files != files(right):
            raise ValueError(f"row repetitions differ: {name}")
        count = int((left / "logs.count.bin").read_text().strip())
        expected_files = set(BASE_FILES)
        for log in range(count):
            for field in LOG_FIELDS:
                stem = f"log-{log:03d}.{field}"
                expected_files.update((stem + ".bin", stem + ".code-units.bin"))
        if set(left_files) != expected_files:
            raise ValueError(f"raw channel set differs: {name}")
        file_count += len(left_files)
        if (left / "expression.bin").read_text() != row["expression"] or (left / "mode.bin").read_text() != "string":
            raise ValueError(f"authored row input differs: {name}")
        logs = []
        for log in range(count):
            stem = f"log-{log:03d}"
            event = {}
            for field in LOG_FIELDS:
                plain = (left / f"{stem}.{field}.bin").read_bytes()
                if utf16be(plain) != (left / f"{stem}.{field}.code-units.bin").read_bytes():
                    raise ValueError(f"logger UTF-16 differs: {name}/{stem}/{field}")
                event[field] = plain.decode("utf-8")
            logs.append(event)
        status = (left / "result.status.bin").read_text().strip()
        if status not in ("success", "error") or (status == "error" and (left / "result.error-class.bin").read_text() != "org.pkl.core.PklException"):
            raise ValueError(f"unexpected Java row status/error class: {name}")
        stderr = (left / "result.stderr.bin").read_text()
        first = next((line.strip() for line in stderr.splitlines() if line.strip() and line.strip() != "–– Pkl Error ––"), "")
        observed.append({"id": row["id"], "status": status, "stdout": (left / "result.stdout.bin").read_text(), "first_error_line": first, "logs": logs, "row_files_per_repetition": len(left_files), "raw_files_sha256": sha((json.dumps(left_files, sort_keys=True, separators=(",", ":")) + "\n").encode())})
    if Counter(row["status"] for row in observed) != {"success": 36, "error": 28}:
        raise ValueError("status counts differ")
    older = json.loads((OLDER / "report.json").read_bytes())
    if not older["complete"] or older["rows"] != 56 or cases["rows"][:56] != json.loads((OLDER / "cases.json").read_bytes())["rows"]:
        raise ValueError("earlier capture lineage differs")
    for index, row in enumerate(cases["rows"][:56]):
        name = f"{index:03d}-{row['id']}"
        if files(OLDER / "repeat-0" / name) != files(CAPTURE / "repeat-0" / name):
            raise ValueError(f"earlier row raw differs: {name}")
    audit = {
        "schema": 1,
        "kind": "stage68-collection-every-independent-read-only-audit",
        "complete": True,
        "guest_executions": 0,
        "candidate_compatibility_passes_claimed": 0,
        "audit_source": identity(HERE / "audit.py"),
        "capture_report": identity(CAPTURE / "report.json"),
        "outer_process": identity(LAUNCH / "process.json"),
        "first_capture_report": identity(OLDER / "report.json"),
        "rows": 64,
        "status_per_repetition": {"success": 36, "error": 28},
        "sessions": [{"pid": s["pid"], "exit_code": s["exit_code"], "stdout_sha256": s["stdout_sha256"], "stderr_sha256": s["stderr_sha256"]} for s in report["sessions"]],
        "raw_files_per_repetition": file_count,
        "pinned_source_copies": len(report["sources_before"]),
        "first_56_rows_identical_to_capture_02": True,
        "rows_observed": observed,
        "implementation_boundary": [
            "ListNodes.every, SetNodes.every, and MapNodes.every iterate in retained order and call Function1/Function2 once per visited value/entry. A false Boolean result returns immediately; callback values/errors and Map key/value fetch precede the next cursor advance.",
            "ListingNodes.every and MappingNodes.every are direct lazy collection methods. They iterate member values, call VmUtils.readMember only for the current uncached member, and stop before forcing later values after false.",
            "The method entry validates Function1 for List/Set/Listing and Function2 for Map/Mapping even when empty; the added direct Listing/Mapping arity rows confirm this without strict conversion. An empty receiver returns true without evaluating the callback body or checking its Boolean result; nonempty Int-returning callbacks produce a Boolean type error at invocation.",
            "Reuse the existing Rust collection transform callback continuation and GC roots for the strict three, with a predicate-result Boolean check and early false/empty true. Add a lazy per-member resumable read path for Listing/Mapping; do not reuse Listing.fold's eager shallow-force-all behavior.",
            "Type-constraint invocation should use the same predicate path. The three positive and three negative `is ... every` rows are public controls, but unchanged original modules must be rerun before claiming their full output.",
        ],
        "limitations": ["The logger proves synchronous callback order and source frame for these Pkl 0.32.0 rows; it does not prove Host suspend/cancel scheduling parity.", "This is Java-only authority. No Rust candidate or original full-module output was generated for these 64 rows."]
    }
    (HERE / "report.json").write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"rows": 64, "success": 36, "error": 28, "raw_files_per_session": file_count, "source_copies": len(report["sources_before"])}))

if __name__ == "__main__":
    main()
