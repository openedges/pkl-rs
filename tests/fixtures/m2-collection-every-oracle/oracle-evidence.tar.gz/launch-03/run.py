"""Record the collection every() Java capture and its raw outer channels."""
from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PREP = ROOT / "target/m2/stage68-collection-every-prep-03"
OUT = ROOT / "target/m2/stage68-collection-every-oracle-03"
INPUTS = (HERE / "run.py", *(PREP / name for name in ("run.py", "CollectionEveryOracle.java", "cases.json", "module.pkl", "queries.tsv", "README.md")))

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def identities() -> dict[str, dict[str, object]]:
    return {str(path.relative_to(ROOT)): {"bytes": path.stat().st_size, "sha256": sha(path)} for path in INPUTS}

if __name__ == "__main__":
    if not __debug__ or OUT.exists() or (HERE / "process.json").exists():
        raise SystemExit("fresh capture and launch receipt required")
    before = identities()
    argv = [sys.executable, "-B", str(PREP / "run.py"), "--output", str(OUT)]
    started = time.time()
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=180)
    stdout_file = HERE / "stdout.bin"
    stderr_file = HERE / "stderr.bin"
    stdout_file.write_bytes(result.stdout)
    stderr_file.write_bytes(result.stderr)
    report = {"schema": 1, "kind": "stage68-collection-every-Java-launch", "complete": True, "candidate_compatibility_passes_claimed": 0, "argv": argv, "cwd": str(ROOT), "host": platform.platform(), "python": sys.version, "started_epoch": started, "finished_epoch": time.time(), "exit_code": result.returncode, "stdout": {"bytes": stdout_file.stat().st_size, "sha256": sha(stdout_file)}, "stderr": {"bytes": stderr_file.stat().st_size, "sha256": sha(stderr_file)}, "inputs_before": before, "inputs_after": identities(), "source_stable": before == identities()}
    (HERE / "process.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"exit_code": result.returncode, "source_stable": report["source_stable"], "output": str(OUT)}, sort_keys=True))
    if result.returncode or not report["source_stable"]:
        raise SystemExit(1)
