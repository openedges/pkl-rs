"""Capture Pkl 0.32.0 collection every() with raw per-row logger events."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

PREP = Path(__file__).resolve().parent
ROOT = PREP.parents[2]
sys.path.insert(0, str(ROOT / "tools"))
from amendment_construction_oracle import SOURCES as PARENT_SOURCES

URI = "file:///stage68/collection-every.pkl"
SOURCES = tuple(sorted(set(PARENT_SOURCES) | {
    "external/pkl/stdlib/base.pkl",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/ListNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/SetNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/MapNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/ListingNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/MappingNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/ExternalMethod1Node.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/lambda/ApplyVmFunction1Node.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/lambda/ApplyVmFunction2Node.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/unary/TraceNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmList.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmSet.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmMap.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmListing.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmMapping.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmFunction.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmUtils.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/EvaluatorBuilder.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/Logger.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/StackFrame.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/PklException.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/PklBugException.java",
}))
INPUTS = ("run.py", "CollectionEveryOracle.java", "cases.json", "module.pkl", "queries.tsv", "README.md")

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

def write(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")

def tree(path: Path) -> dict[str, str]:
    return {f.relative_to(path).as_posix(): sha(f) for f in sorted(path.rglob("*")) if f.is_file()}

def capture(out: Path) -> None:
    if not __debug__:
        raise RuntimeError("optimized Python is not admitted")
    out = out.resolve()
    if out.exists():
        raise ValueError("fresh output required")
    cases = json.loads((PREP / "cases.json").read_bytes())
    if cases["schema"] != 1 or cases["baseline"] != "Pkl 0.32.0" or cases["uri"] != URI or cases["repetitions"] != 2 or len(cases["rows"]) != 64:
        raise ValueError("authored cases differ")
    ROWS = tuple((row["id"], row["expression"]) for row in cases["rows"])
    if len({row[0] for row in ROWS}) != len(ROWS):
        raise ValueError("duplicate case ID")
    query_bytes = "".join(f"string\t{key}\t{expression}\n" for key, expression in ROWS).encode()
    if (PREP / "queries.tsv").read_bytes() != query_bytes:
        raise ValueError("authored queries differ")
    lock = json.loads((ROOT / "oracle.lock.json").read_bytes())
    jar = ROOT / ".cache/oracle" / lock["artifact"]["filename"]
    if lock["version"] != "0.32.0" or lock["source"]["revision"] != "e51fb2f91774265666f94980ec630db794a4db2d" or sha(jar) != lock["artifact"]["sha256"]:
        raise ValueError("pinned Pkl oracle differs")
    before = {name: sha(PREP / name) for name in INPUTS}
    source_before = {name: sha(ROOT / name) for name in SOURCES}
    out.mkdir(parents=True)
    for name in INPUTS:
        shutil.copyfile(PREP / name, out / name)
    helper = out / "CollectionEveryOracle.java"
    for name in SOURCES:
        dest = out / "sources" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, dest)
    java = Path(os.environ.get("PKL_ORACLE_JAVA", "/usr/bin/java")).resolve()
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"), "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"), "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC", "TERM": "dumb", "NO_COLOR": "1", "COLUMNS": "80"}
    identity = subprocess.run([str(java), "-XshowSettings:properties", "-version"], cwd=out, env=env, capture_output=True, timeout=60)
    (out / "java-identity.stdout.bin").write_bytes(identity.stdout)
    (out / "java-identity.stderr.bin").write_bytes(identity.stderr)
    props = dict(re.findall(r"^\s+([\w.]+) = (.*)$", identity.stderr.decode(), re.M))
    if identity.returncode or any(props.get(key) != value for key, value in lock["jdk"]["properties"].items()):
        raise ValueError("pinned JDK differs")
    home = Path(props["java.home"])
    options = [*lock["jvm_options"], f"-Duser.home={env['HOME']}", f"-Djava.io.tmpdir={env['TMPDIR']}"]
    report = {"schema": 1, "kind": "stage68-collection-every-Java-authority", "boundary": "public strings plus per-row raw logger messages and frames", "candidate_compatibility_passes_claimed": 0, "uri": URI, "rows": len(ROWS), "host": platform.platform(), "inputs_before": before, "sources_before": source_before, "jar_sha256": sha(jar), "oracle_lock_sha256": sha(ROOT / "oracle.lock.json"), "references_lock_sha256": sha(ROOT / "references.lock"), "jdk": {"executable": str(java), "executable_sha256": sha(java), "modules_sha256": sha(home / "lib/modules"), "release_sha256": sha(home / "release"), "properties": props}, "environment": env, "sessions": [], "complete": False}
    write(out / "report.json", report)
    for rep in range(2):
        folder = out / f"repeat-{rep}"
        folder.mkdir()
        argv = [str(java), *options, "-cp", str(jar), str(helper), str(folder), str(out), URI]
        started = time.time()
        process = subprocess.Popen(argv, cwd=out, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        timed_out = False
        try:
            stdout, stderr = process.communicate(timeout=120)
        except subprocess.TimeoutExpired:
            timed_out = True
            process.kill()
            stdout, stderr = process.communicate()
        (folder / "process.stdout.bin").write_bytes(stdout)
        (folder / "process.stderr.bin").write_bytes(stderr)
        session = {"repeat": rep, "pid": process.pid, "argv": argv, "cwd": str(out), "started_epoch": started, "finished_epoch": time.time(), "exit_code": process.returncode, "timed_out": timed_out, "stdout_sha256": sha(folder / "process.stdout.bin"), "stderr_sha256": sha(folder / "process.stderr.bin"), "rows": sum(q.is_dir() for q in folder.iterdir())}
        report["sessions"].append(session)
        write(out / "report.json", report)
        print(json.dumps(session, sort_keys=True), flush=True)
        if timed_out or process.returncode or session["rows"] != len(ROWS):
            raise ValueError("incomplete Java session; raw retained")
    report["raw_equal"] = tree(out / "repeat-0") == tree(out / "repeat-1")
    report["row_statuses"] = []
    for i, (key, expression) in enumerate(ROWS):
        folder = out / "repeat-0" / f"{i:03d}-{key}"
        report["row_statuses"].append({"id": key, "expression": expression, "status": (folder / "result.status.bin").read_text().strip(), "stdout_sha256": sha(folder / "result.stdout.bin"), "stderr_sha256": sha(folder / "result.stderr.bin"), "logs": int((folder / "logs.count.bin").read_text().strip())})
    report["inputs_after"] = {name: sha(PREP / name) for name in INPUTS}
    report["sources_after"] = {name: sha(ROOT / name) for name in SOURCES}
    report["source_copies_after"] = {name: sha(out / "sources" / name) for name in SOURCES}
    report["source_stable"] = report["sources_before"] == report["sources_after"] == report["source_copies_after"]
    report["input_stable"] = report["inputs_before"] == report["inputs_after"] == {name: sha(out / name) for name in INPUTS}
    report["complete"] = report["source_stable"] and report["input_stable"] and report["raw_equal"] and len({s["pid"] for s in report["sessions"]}) == 2
    write(out / "report.json", report)
    if not report["complete"]:
        raise ValueError("capture incomplete; raw retained")
    print(json.dumps({"complete": True, "statuses": report["row_statuses"]}, sort_keys=True), flush=True)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    capture(parser.parse_args().output)
