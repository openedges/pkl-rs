"""Publish terminal, independently audited Stage47 regression evidence only."""
from collections import Counter
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tarfile

MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
STAGE = MAIN.parent / 'pkl-rs.stage47'
OUT = Path(__file__).parent
AUDIT = MAIN / 'target/m2/stage47-final-audit-01'
AUDIT_EXEC = MAIN / 'target/m2/stage47-final-audit-execution-01'
TERMINAL_ADDENDUM = MAIN / 'target/m2/stage47-final-audit-terminal-addendum-01'
WRAPPER = STAGE / 'target/m2/stage47-full-regression-01'
LANG = STAGE / 'target/m2/stage47-language-final-01'
LIFE = STAGE / 'target/m2/stage47-class-lifecycle-final-01'
REPORTS = MAIN / 'reports/m2'
COMMIT = '0e13a589d43c4cb1d83f41dd1ec416cac1770fc1'
RAW_TARGET = 80 * 1024 * 1024
CACHES = [LANG / 'build', LANG / 'jvm-classpath/build', LIFE / 'build']
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def safe(name):
    path = Path(name)
    assert path.parts and not path.is_absolute() and '..' not in path.parts and str(path) == name and name != '.', name
    return path

def read(path):
    assert path.is_absolute() and path.is_relative_to(MAIN.parent), str(path)
    assert not any(path == excluded or excluded in path.parents for excluded in CACHES), str(path)
    parent = MAIN.parent
    assert stat.S_ISDIR(parent.lstat().st_mode), str(parent)
    for part in path.relative_to(MAIN.parent).parts[:-1]:
        parent = parent / part
        assert stat.S_ISDIR(parent.lstat().st_mode), str(parent)
    assert stat.S_ISREG(path.lstat().st_mode), str(path)
    return path.read_bytes()

def pointer(path):
    return {'path': str(path.relative_to(MAIN)), 'sha256': sha(read(path))}

def write_new(path, value):
    assert not path.exists(), 'Preserve existing artifact: ' + str(path)
    save(path, value)

commands = []
def command(label, argv):
    folder = OUT / 'commands' / label
    folder.mkdir(parents=True, exist_ok=False)
    with (folder / 'stdout.bin').open('wb') as stdout, (folder / 'stderr.bin').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=MAIN, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=stdout, stderr=stderr)
        save(OUT / 'active-command.json', {'label': label, 'pid': process.pid, 'argv': argv})
        code = process.wait()
    row = {'label': label, 'argv': argv, 'cwd': str(MAIN), 'pid': process.pid, 'exitCode': code,
           'stdoutSha256': sha(read(folder / 'stdout.bin')), 'stderrSha256': sha(read(folder / 'stderr.bin')), 'finishedUtc': now()}
    save(folder / 'result.json', row)
    commands.append(row)
    save(OUT / 'commands.json', commands)
    print(label, 'exit', code, flush=True)
    assert code == 0, 'Preserve failed evidence command: ' + label

assert not (OUT / 'report.json').exists(), 'Preserve prior publication.'
audit = load(AUDIT / 'report.json')
driver = load(WRAPPER / 'process-report.json')
terminal = load(WRAPPER / 'outer-terminal.json')
audit_execution = load(AUDIT_EXEC / 'audit-report.json')
audit_terminal = load(AUDIT_EXEC / 'outer-terminal.json')
assert audit['implementation_commit'] == COMMIT and audit['declared_inputs_unchanged_during_audit']
assert audit['source_binding']['all_match_commit_blobs'] and audit['source_binding']['lifecycle_config_directly_captured']
assert driver['commit'] == COMMIT and driver['complete'] and not driver['infrastructureFailures']
assert terminal['session_id'] == 15695 and terminal['exit_code'] == 0
assert terminal['process_report_sha256'] == sha(read(WRAPPER / 'process-report.json'))
assert sha(read(AUDIT / 'report.json')) == '229b50b6ea2ac63341674c89158e90cac88bf0f15ba0bfe1e045f3ad222adc78'
notice_path = Path(audit['wrapper_own_terminal']['path'])
assert notice_path == AUDIT_EXEC / 'wrapper-terminal-from-root-notice.json'
assert audit['wrapper_own_terminal']['sha256'] == sha(read(notice_path))
notice = load(notice_path)
assert all(notice[key] == terminal[key] for key in ['session_id', 'exit_code', 'process_report_sha256'])
assert audit_execution['exitCode'] == 0 and audit_terminal['session_id'] == 56273 and audit_terminal['exit_code'] == 0
assert audit_terminal['audit_execution_report_sha256'] == sha(read(AUDIT_EXEC / 'audit-report.json'))
addendum = load(TERMINAL_ADDENDUM / 'report.json')
assert addendum['matchesSessionExitAndProcessReport'] and addendum['auditRerun'] is False
assert addendum['lateRootTerminal']['sha256'] == sha(read(WRAPPER / 'outer-terminal.json'))
assert addendum['originalAudit']['sha256'] == sha(read(AUDIT / 'report.json'))
for entry in audit['output_pointers'].values():
    assert sha(read(Path(entry['path']))) == entry['sha256']
language, lifecycle = load(LANG / 'report.json'), load(LIFE / 'report.json')
assert lifecycle['schema'] == 2
for label, folder in [('language', LANG), ('lifecycle', LIFE)]:
    assert sha(read(folder / 'report.json')) == audit[label]['report_sha256']

# Every acquisition payload comes exclusively from its authenticated declaration.
# The fixed metadata lists below never enumerate an original evidence tree.
selected = []
for directory in [AUDIT, AUDIT_EXEC, TERMINAL_ADDENDUM]:
    closure = load(directory / 'closure.json')
    for name, claim in closure['files'].items():
        data = read(directory / safe(name))
        assert sha(data) == claim['sha256'] and len(data) == claim['length'], name
def select(label, folder, names):
    for name in names:
        path = folder / safe(name)
        data = read(path)
        selected.append({'path': label + '/' + name, 'source': str(path), 'bytes': len(data),
                         'sha256': sha(data), 'original_mode': stat.S_IMODE(path.lstat().st_mode), 'original_kind': 'regular'})

for label, folder, report in [('language', LANG, language), ('lifecycle', LIFE, lifecycle)]:
    for name, digest in report['evidence_sha256'].items():
        assert sha(read(folder / safe(name))) == digest
    assert len(report['evidence_sha256']) == audit[label]['declared_payloads_verified']
    select(label, folder, report['evidence_sha256'])
    select(label, folder, ['report.json'])
wrapper_files = ['run.py', 'process-report.json', 'outer-terminal.json', 'active.json']
wrapper_files += [row['label'] + '.' + channel + '.bin' for row in driver['commands'] for channel in ['stdout', 'stderr']]
select('wrapper', WRAPPER, wrapper_files)
select('audit', AUDIT, [*load(AUDIT / 'closure.json')['files'], 'closure.json'])
select('audit-execution', AUDIT_EXEC, [*load(AUDIT_EXEC / 'closure.json')['files'], 'closure.json'])
select('audit-terminal-addendum', TERMINAL_ADDENDUM, [*load(TERMINAL_ADDENDUM / 'closure.json')['files'], 'closure.json'])
select('publication', OUT, ['publish.py', 'run.py', 'closeout.py', 'closeout-run.py', 'finalize.py', 'proposal.json'])
select('publication-tool', MAIN / 'tools', ['evidence.py'])
assert len({row['path'] for row in selected}) == len(selected)
rows = sorted(selected, key=lambda row: row['path'])
baseline_summary = MAIN / 'reports/m2/stage46-final-summary.json'
baseline_captures = MAIN / 'reports/m2/stage46-final-regression-captures.json'
baseline = {'summary': pointer(baseline_summary), 'captures': pointer(baseline_captures),
            'archives': load(baseline_captures)['archives'],
            'qualification': 'Previously published Stage46 raw archives are reused by exact pointers. Four fixed audited baseline metadata files remain in the audit capture for offline provenance; no earlier raw archive is recursively repackaged. Stage45 schema1 omission stays historical.'}
for claim in baseline['archives']:
    assert sha(read(MAIN / safe(claim['path']))) == claim['sha256']
selection = {'schema': 1, 'scope': 'Producer-declared raw maps plus fixed terminal wrapper/audit/execution files. No original evidence/cache tree enumeration.',
             'implementation_commit': COMMIT, 'excluded_exact_cargo_paths': list(map(str, CACHES)),
             'original_mode_qualification': 'Tar headers are deterministic0644; original regular-file modes are recoverable from each selection row.',
             'reused_baseline': baseline, 'files': rows,
             'self_qualification': 'This selection omits its own row to avoid a circular hash; archive EVIDENCE.json includes the selection bytes.'}
save(OUT / 'selection.json', selection)
data = read(OUT / 'selection.json')
rows.append({'path': 'publication/selection.json', 'source': str(OUT / 'selection.json'), 'bytes': len(data), 'sha256': sha(data), 'original_mode': stat.S_IMODE((OUT / 'selection.json').lstat().st_mode), 'original_kind': 'regular'})
partitions, partition, size = [], [], 0
for row in rows:
    if partition and size + row['bytes'] > RAW_TARGET:
        partitions.append(partition)
        partition, size = [], 0
    partition.append(row)
    size += row['bytes']
    if row['bytes'] > RAW_TARGET:
        partitions.append(partition)
        partition, size = [], 0
if partition:
    partitions.append(partition)
save(OUT / 'partition-plan.json', {'rawTargetBytes': RAW_TARGET, 'singleOversizedPayloads': [row for row in rows if row['bytes'] > RAW_TARGET],
                                  'groups': [{'index': index, 'files': len(group), 'bytes': sum(row['bytes'] for row in group)} for index, group in enumerate(partitions, 1)]})
print('Selected', len(rows), 'payloads;', len(partitions), 'archives planned', flush=True)
archives, readbacks = [], []
for index, group in enumerate(partitions, 1):
    gather = OUT / f'part-{index:02d}'
    gather.mkdir()
    for row in group:
        source = Path(row['source'])
        data = read(source)
        assert sha(data) == row['sha256'] and len(data) == row['bytes']
        target = gather / safe(row['path'])
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    archive_path = REPORTS / f'stage47-final-regression-{index:02d}.tar.gz'
    assert not archive_path.exists(), 'Preserve existing archive.'
    command(f'part-{index:02d}-create', [sys.executable, str(MAIN / 'tools/evidence.py'), 'create', str(gather), str(archive_path)])
    command(f'part-{index:02d}-verify', [sys.executable, str(MAIN / 'tools/evidence.py'), 'verify', str(archive_path)])
    # A separate full readback joins every archive member to its original bytes,
    # beyond the evidence tool's self-inventory checks.
    by_path = {row['path']: row for row in group}
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        member_map = {member.name: member for member in members}
        assert len(member_map) == len(members) and set(member_map) == set(by_path) | {'EVIDENCE.json'}
        assert all(member.isfile() and safe(member.name) and member.mtime == 0 and member.mode == 0o644 for member in members)
        evidence = json.load(archive.extractfile(member_map['EVIDENCE.json']))
        assert evidence['excluded_patterns'] == []
        assert {row['path']: {'bytes': row['bytes'], 'sha256': row['sha256']} for row in evidence['files']} == {name: {'bytes': row['bytes'], 'sha256': row['sha256']} for name, row in by_path.items()}
        for name, row in by_path.items():
            data = archive.extractfile(member_map[name]).read()
            assert sha(data) == row['sha256'] and len(data) == row['bytes']
            assert data == read(Path(row['source'])), row['source']
    item = {**pointer(archive_path), 'compressed_bytes': archive_path.stat().st_size, 'payload_files': len(group), 'payload_bytes': sum(row['bytes'] for row in group),
            'sizing_disposition': 'Standalone large payload retained explicitly.' if any(row['bytes'] > RAW_TARGET for row in group) else 'Partitioned by80MiB raw target; no arbitrary compressed-size retry gate.'}
    archives.append(item)
    readbacks.append({'archive': item['path'], 'payloadFiles': len(group), 'originalBytesEqual': True, 'memberSetEqual': True, 'deterministicHeaders': True})
    save(OUT / 'archive-readbacks.json', readbacks)
    print('Original-byte readback complete:', index, flush=True)

changes = []
for row in rows:
    path = Path(row['source'])
    data = read(path)
    if sha(data) != row['sha256'] or len(data) != row['bytes'] or stat.S_IMODE(path.lstat().st_mode) != row['original_mode']:
        changes.append(row['source'])
assert not changes, changes
save(OUT / 'originals-after.json', {'selectedFiles': len(rows), 'changes': changes, 'pathSetQualification': 'Explicit immutable producer maps and fixed metadata lists, not an evidence/cache tree enumeration.'})
index_path = REPORTS / 'stage47-final-regression-captures.json'
write_new(index_path, {'schema': 1, 'scope': 'Terminal Stage47 selected native/lifecycle regression with retained strict failures; no fullM2/platform/performance claim.',
                       'archives': archives, 'payload_files': len(rows), 'payload_bytes': sum(row['bytes'] for row in rows),
                       'producer_declared_payload_files': sum(len(report['evidence_sha256']) for report in [language, lifecycle]),
                       'selection_sha256': sha(read(OUT / 'selection.json')), 'originals_unchanged': True,
                       'all_archives_tool_create_verify_exit0': True, 'independent_original_byte_readback': True,
                       'cache_traversal': False, 'wrapper_exit_code': terminal['exit_code'], 'reused_baseline': baseline, 'full_m2_complete': False})
copies = {}
for source, suffix in [('report.json', 'regression-audit'), ('source-map.json', 'source-map'), ('status-changes.json', 'status-changes'),
                       ('case-changes.json', 'case-changes'), ('raw-changes.json', 'raw-changes')]:
    target = REPORTS / f'stage47-final-{suffix}.json'
    assert not target.exists()
    target.write_bytes(read(AUDIT / source))
    copies[source] = pointer(target)
manifest = load(LANG / 'sources/compatibility/m2-language.json')
adapters = {}
case_adapters = {row['id']: row.get('adapter') for row in manifest['cases']}
for row in language['results']:
    adapters.setdefault(case_adapters[row['id']], Counter())[row['status']] += 1
status_changes = load(AUDIT / 'status-changes.json')
summary = {'schema': 1, 'scope': 'Complete selected native/lifecycle regression at the Stage47 implementation commit. Strict failures, unimplemented/unmapped scope and later Stage48/49 work remain open.',
           'implementation_commit': COMMIT, 'references': audit['pinned_references'],
           'selected_regression_acquisition_complete': True, 'wrapper_exit_code': terminal['exit_code'], 'gates': audit['gates'],
           'selected': language['selected_count'], 'status_counts': language['status_counts'], 'inventory_counts': manifest['counts'],
           'selected_adapters': adapters, 'case_ids_and_order_preserved': len(manifest['cases']),
           'case_mapping_changes': load(AUDIT / 'case-changes.json')['case_changes'],
           'requirement_source_hash_changes': load(AUDIT / 'case-changes.json')['requirement_source_hash_changes'],
           'existing_jvm_profile_mapping_preserved': True,
           'status_changes': status_changes['transitions'],
           'failures': [{'id': row['id'], 'status': row['status']} for row in status_changes['current_nonpass']],
           'current_nonpass_cases': len(status_changes['current_nonpass']),
           'historical_nonpass_comparison_union': len(status_changes['all_old_or_new_nonpass']),
           'audit_field_qualification': 'Current nonpassing case IDs and the union of Stage46/Stage47 nonpassing IDs are distinct fields. All exact raw differences remain preserved.',
           'full_gate_failure_reasons': len(language['full_gate_failures']),
           'metamorphic_relations': len(language['metamorphic_results']), 'metamorphic_matches': sum(row['status'] == 'pass' for row in language['metamorphic_results']),
           'persistent': audit['lifecycle'], 'unexecuted_lifecycle_groups': lifecycle['unexecuted_groups'],
           'source_binding': audit['source_binding'], 'source_stable': language['source_stability'], 'artifact_stable': language['artifact_stability'],
           'lifecycle_schema': lifecycle['schema'], 'lifecycle_cargo_controls_directly_captured': ['.cargo/config.toml', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'],
           'historical_lifecycle_qualification': 'Stage45 schema1 did not directly capture root.cargo/config.toml; this Stage47 schema2 result does not retroactively change that evidence.',
           'raw_reports': {label: audit[label]['report_sha256'] for label in ['language', 'lifecycle']},
           'audit': copies['report.json'], 'source_map': copies['source-map.json'], 'case_changes': copies['case-changes.json'],
           'status_changes_record': copies['status-changes.json'], 'raw_changes': copies['raw-changes.json'], 'captures': pointer(index_path),
           'implementation_checks_and_platforms': pointer(REPORTS / 'stage47-implementation-checkpoint.json'),
           'scheduling_comparison': audit['scheduling_change'],
           'terminal_provenance': {'root_original_receipt_is_late': True, 'root_observed_session': 15695, 'root_actual_chunk': '8fdfdd', 'c_audit_actual_session': 56273, 'c_audit_actual_exit': 0, 'qualification': 'Both the original C transcribed root notice and later root producer receipt/addendum are archived; recorded timestamps are not fabricated contemporaneous terminal observations.'},
           'full_m2_complete': False, 'compatibility_complete': False, 'hosted_ci_claimed': False, 'performance_target_claimed': False,
           'remaining': ['All current failed, unimplemented, unmapped and unexecuted required language cases.',
                         'Remaining shared language, stdlib/security/producer obligations; later Stage48/49 implementation and evidence are separate from this commit.',
                         'Whole product/platform and execution-time/peak-memory requirements.', 'Root publication review, planning/docs and Git publication.']}
summary_path = REPORTS / 'stage47-final-summary.json'
write_new(summary_path, summary)
save(OUT / 'report.json', {'scope': 'Publication payload/index/summary complete; own actual outer terminal and closeout follow separately.',
                          'captures': pointer(index_path), 'summary': pointer(summary_path), 'archives': archives, 'commands': commands,
                          'payloadFiles': len(rows), 'payloadBytes': sum(row['bytes'] for row in rows), 'originalChanges': changes,
                          'summaryPointerQualification': 'First-phase pre-closeout summary; later final summary adds only a closeout pointer. Exact first-phase summary bytes are retained in the closeout archive.',
                          'publication_completed': True, 'root_review_and_commit_pending': True, 'finishedUtc': now()})
print(json.dumps({'archives': len(archives), 'payload_files': len(rows), 'summary': pointer(summary_path)}, indent=2), flush=True)
