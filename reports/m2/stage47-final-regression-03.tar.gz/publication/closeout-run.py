from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
OUT=Path(__file__).parent
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
EXEC=OUT/'closeout-execution';EXEC.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
argv=[sys.executable,str(OUT/'closeout.py')]
r={'argv':argv,'cwd':str(MAIN),'parentPid':os.getpid(),'scriptSha256':sha(OUT/'closeout.py'),'terminal':False}
(EXEC/'report.json').write_text(json.dumps(r,indent=2)+'\n')
with(EXEC/'stdout.bin').open('wb')as stdout,(EXEC/'stderr.bin').open('wb')as stderr:
 p=subprocess.Popen(argv,cwd=MAIN,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
 r['pid']=p.pid
 code=p.wait()
r.update(exitCode=code,terminal=True,stdoutSha256=sha(EXEC/'stdout.bin'),stderrSha256=sha(EXEC/'stderr.bin'),sourceUnchanged=sha(OUT/'closeout.py')==r['scriptSha256'])
(EXEC/'report.json').write_text(json.dumps(r,indent=2)+'\n')
print('CLOSEOUT TERMINAL',code,flush=True)
raise SystemExit(code)
