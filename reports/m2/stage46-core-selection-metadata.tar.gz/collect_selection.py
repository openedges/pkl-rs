"""Prepare an explicit read-only Stage46 core/platform publication selection.

No archives, Git writes or edits to producer roots. Known source snapshots are
enumerated by their exact producer maps, not recursive Cargo/cache traversal.
"""
from pathlib import Path
import collections
import hashlib
import json
import os
import stat
import subprocess
import time

MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46')
B = ROOT / 'target/m2'
OUT = Path(__file__).resolve().parent
COMMIT = 'a3eb3634558cef6f36189320498fe7e013296c48'
TREE = 'b559dbaf8895408503e4ed14d994766d71f6e833'


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')


def git(args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd)


started = time.time()
names = '''stage46-ast-preparation-review-01 stage46-ast-preparation-review-02
stage46-base-update-01 stage46-base-update-02 stage46-base-update-03
stage46-binding-check-01 stage46-bootstrap-01 stage46-browser-identity-correction-01
stage46-browser-tooling-01 stage46-c04-review-01 stage46-commit-01
stage46-core-handoff-01 stage46-http-server-correction-01 stage46-implementation-01
stage46-index-binding-01 stage46-index-binding-02 stage46-index-binding-03
stage46-inventory-refresh-01 stage46-module-platform-02 stage46-module-platform-03
stage46-module-platform-exploration-01 stage46-module-portable-consumer-01
stage46-module-portable-consumer-02 stage46-module-portable-integration-01
stage46-original-read-native-01 stage46-original-read-native-02
stage46-original-read-native-03 stage46-original-read-native-04
stage46-platform-acquisition-01 stage46-platform-acquisition-02
stage46-platform-baseline-01 stage46-platform-baseline-02
stage46-platform-http-followup-01 stage46-resource-binding-review-01
stage46-resource-js-tests-01 stage46-resource-platform-01
stage46-resource-platform-02 stage46-resource-platform-03 stage46-resource-review-01
stage46-resource-review-02 stage46-rust5-01 stage46-rust5-02
stage46-triple-preflight-review-01'''.split()
main_names = '''resource-portable-fixture-integration-01
resource-portable-fixture-integration-02 resource-portable-fixture-publication-01
stage46-c05-corrective-review-01 stage46-module-integration-review-01
stage46-module-portable-fixture-review-01 stage46-next-scope-review-01
stage46-resource-platform-review-01 stage46-resource-portable-promotion-review-01
stage46-resource-portable-verifier-review-01 stage46-server-tooling-review-01
stage46-implementation-push-01'''.split()
roots = [B / n for n in names] + [MAIN / 'target/m2' / n for n in main_names]
assert len(roots) == len(set(roots)) and all(p.is_dir() and not p.is_symlink() for p in roots)
b_roots_path = B / 'stage46-oracle-native-publication-selection-01/selected-roots.json'
b_roots = [Path(row['root']) for row in load(b_roots_path)['roots']]
assert all(a != b and a not in b.parents and b not in a.parents for a in roots for b in b_roots)
save('selected-roots.json', {'schema': 1, 'roots': [str(p) for p in roots],
                            'bSelectionSha256': sha_file(b_roots_path),
                            'bRootsCheckedDisjoint': len(b_roots),
                            'excludesWholeRegression': [str(B / n) for n in ['stage46-full-regression-01', 'stage46-language-final-01', 'stage46-class-lifecycle-final-01']]})

# Exact exclusions are installed before any selected-root recursion.
caches = {ROOT / 'target/stage46-cargo', ROOT / 'target/debug', ROOT / 'target/release',
          ROOT / 'target/wasm32-unknown-unknown', ROOT / '.cache', ROOT / 'tools/platform/node_modules'}
for n in ['stage46-module-portable-consumer-01', 'stage46-module-portable-consumer-02']:
    caches.update({B / n / 'workspace/tools/__pycache__', B / n / 'workspace/tools/tests/__pycache__',
                   B / n / 'workspace/tools/platform/node_modules'})
snapshots = {}
for n in range(1, 7):
    p = B / f'stage46-implementation-01/resource-candidate-build-{n:02d}'
    snapshots[p / 'sources'] = p / 'source-after.json'
for n in [1, 2]:
    p = B / f'stage46-platform-baseline-{n:02d}'
    snapshots[p / 'sources'] = p / 'sources.json'
prunes = caches | snapshots.keys()
save('prewalk-prunes.json', {'scope': 'Exact absolute paths only; no generic build/source/cache basename exclusion.',
                            'cacheDirectories': [str(p) for p in sorted(caches)],
                            'explicitMapSourceDirectories': {str(p): str(m) for p, m in snapshots.items()},
                            'note': 'Source directories are pruned from recursive traversal and every exact map entry is processed directly. Cache roots outside selected roots are recorded as outside scope, not walked.'})

index_report = B / 'stage46-index-binding-03/report.json'
assert sha_file(index_report) == 'd3f33e65f425beee50bceff5441699464b262d42252574d2ed14ff0b9eb1b527'
assert git(['rev-parse', COMMIT + '^{tree}']).decode().strip() == TREE
binding_path = B / 'stage46-index-binding-03/file-bindings.json'
bindings = load(binding_path)
commit_record = load(B / 'stage46-commit-01/report.json')
assert commit_record['complete'] and commit_record['commit'] == COMMIT and commit_record['tree'] == TREE
pins = {'.': COMMIT}
for row in bindings.values():
    if row['repository'] != '.':
        pins.setdefault(row['repository'], row['pin'])
        assert pins[row['repository']] == row['pin']
trees = {}
for repo, pin in pins.items():
    cwd = ROOT if repo == '.' else ROOT / repo
    tree = {}
    for entry in git(['ls-tree', '-r', '-z', pin], cwd).split(b'\0'):
        if not entry:
            continue
        metadata, path = entry.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        tree[os.fsdecode(path)] = (mode, kind, oid)
    trees[repo] = tree
verified_git = {}
for repo, pin in pins.items():
    cwd = ROOT if repo == '.' else ROOT / repo
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=cwd,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        for path, row in bindings.items():
            if row['repository'] != repo:
                continue
            relative = path if repo == '.' else path[len(repo) + 1:]
            assert trees[repo][relative] == (row['gitMode'], 'blob', row['gitBlob'])
            key = (repo, row['gitBlob'])
            if key in verified_git:
                assert verified_git[key] == {'sha256': row['gitBlobSha256'], 'bytes': row['blobSize']}
                continue
            process.stdin.write((row['gitBlob'] + '\n').encode())
            process.stdin.flush()
            header = process.stdout.readline().decode().strip().split()
            assert header[:2] == [row['gitBlob'], 'blob']
            size = int(header[2]); h = hashlib.sha256(); blob = hashlib.sha1(f'blob {size}\0'.encode())
            remaining = size
            while remaining:
                data = process.stdout.read(min(remaining, 1048576))
                assert data
                h.update(data); blob.update(data); remaining -= len(data)
            assert process.stdout.read(1) == b'\n'
            assert blob.hexdigest() == row['gitBlob'] and h.hexdigest() == row['gitBlobSha256'] and size == row['blobSize']
            verified_git[key] = {'sha256': h.hexdigest(), 'bytes': size}
    finally:
        process.stdin.close()
        assert process.wait() == 0 and not process.stderr.read()
    print('Verified Git source objects', repo, flush=True)
save('git-source-binding.json', {'commit': COMMIT, 'tree': TREE, 'pins': pins,
                                'producerIndexReportSha256': sha_file(index_report),
                                'producerFileBindingsSha256': sha_file(binding_path),
                                'verifiedUniqueGitBlobs': len(verified_git), 'sourcePathCount': len(bindings),
                                'method': 'Read actual committed/ref-pinned tree entries and full cat-file blob bytes; independently checked Git object SHA1, SHA256 and length. Checkout transforms never count as byte identity.'})

snapshot_maps = {p: load(m) for p, m in snapshots.items()}
snapshot_expected = {}
for p, mapping in snapshot_maps.items():
    assert isinstance(mapping, dict)
    for name, value in mapping.items():
        digest = value if isinstance(value, str) else value['sha256']
        snapshot_expected[p / name] = (name, digest)


def group(root, relative):
    if root.name == 'stage46-implementation-01':
        first = relative.parts[0]
        return 'implementation-' + first if first.startswith('resource-candidate-build-') else 'implementation-checks-proposals'
    if root.name.startswith('stage46-platform-baseline-'):
        return root.name.removeprefix('stage46-')
    if root.name.startswith('stage46-original-read-native-'):
        return 'original-read-native'
    if root.name.startswith('stage46-rust5-'):
        return 'required-rust-checks'
    if root.name.startswith(('stage46-resource-platform-', 'stage46-module-platform-')):
        return 'supplemental-platforms'
    if root.name.startswith(('stage46-index-binding-', 'stage46-commit-', 'stage46-implementation-push-', 'stage46-base-update-')):
        return 'source-commit-push-binding'
    if root.parent == MAIN / 'target/m2' and 'review' in root.name:
        return 'independent-reviews'
    return 'tooling-integration-reviews'


hash_cache = {}
inventory = []
encountered_prunes = []
stats = collections.defaultdict(lambda: {'files': 0, 'bytes': 0, 'rawPayloadFiles': 0, 'rawPayloadBytes': 0,
                                        'gitMappedFiles': 0, 'gitMappedBytes': 0, 'symlinks': 0})


def record(root, path):
    info = path.lstat()
    relative = path.relative_to(root)
    row = {'root': str(root), 'path': relative.as_posix(), 'absolutePath': str(path),
           'group': group(root, relative), 'mode': stat.S_IMODE(info.st_mode)}
    if stat.S_ISLNK(info.st_mode):
        payload = os.fsencode(os.readlink(path))
        row.update(kind='symlink', bytes=len(payload), sha256=sha_bytes(payload), linkTargetHex=payload.hex(), storage='raw-payload')
    else:
        assert stat.S_ISREG(info.st_mode), str(path)
        key = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)
        digest = hash_cache.get(key)
        if digest is None:
            digest = hash_file = sha_file(path)
            hash_cache[key] = hash_file
        row.update(kind='regular-file', bytes=info.st_size, sha256=digest, storage='raw-payload')
        source_path = None
        if path in snapshot_expected:
            source_path, expected = snapshot_expected[path]
            assert digest == expected, str(path)
        elif 'sources' in relative.parts:
            i = relative.parts.index('sources')
            source_path = Path(*relative.parts[i + 1:]).as_posix()
        elif '/workspace/tests/fixtures/' in str(path):
            source_path = 'tests/fixtures/' + str(path).split('/workspace/tests/fixtures/', 1)[1]
        if source_path in bindings:
            bound = bindings[source_path]
            if digest == bound['gitBlobSha256'] and info.st_size == bound['blobSize']:
                row.update(storage='git-source-map', repositoryPath=source_path, repository=bound['repository'],
                           commitOrPin=pins[bound['repository']], gitBlob=bound['gitBlob'], gitMode=bound['gitMode'])
    inventory.append(row)
    g = stats[row['group']]
    g['files'] += 1; g['bytes'] += row['bytes']
    if row['kind'] == 'symlink':
        g['symlinks'] += 1
    if row['storage'] == 'git-source-map':
        g['gitMappedFiles'] += 1; g['gitMappedBytes'] += row['bytes']
    else:
        g['rawPayloadFiles'] += 1; g['rawPayloadBytes'] += row['bytes']


def walk(root, directory):
    assert directory not in prunes
    with os.scandir(directory) as entries:
        for entry in sorted(entries, key=lambda e: e.name):
            path = directory / entry.name
            if path in prunes:
                encountered_prunes.append(str(path))
                continue
            if entry.is_symlink():
                record(root, path)
            elif entry.is_dir(follow_symlinks=False):
                walk(root, path)
            else:
                record(root, path)


producer_metadata = []
for root in roots:
    walk(root, root)
    for snapshot in snapshots:
        if root == snapshot or root in snapshot.parents:
            for name in snapshot_maps[snapshot]:
                record(root, snapshot / name)
    producer_metadata.append({'root': str(root), 'existingClosureSha256': sha_file(root / 'closure.json') if (root / 'closure.json').is_file() else None,
                              'topReportSha256': sha_file(root / 'report.json') if (root / 'report.json').is_file() else None,
                              'outerTerminalSha256': sha_file(root / 'outer-terminal.json') if (root / 'outer-terminal.json').is_file() else None,
                              'qualification': 'A null original closure remains null; this proposed selection is a current read-only inventory, not a retrospective producer seal.'})
    print('Selected', root.name, flush=True)
assert len(inventory) == len({r['absolutePath'] for r in inventory})
inventory.sort(key=lambda r: r['absolutePath'])
with (OUT / 'original-files.jsonl').open('w') as stream:
    for row in inventory:
        stream.write(json.dumps(row, ensure_ascii=True) + '\n')
save('producer-metadata.json', producer_metadata)
save('proposed-groups.json', dict(sorted(stats.items())))
save('selection-report.json', {
    'scope': 'Proposed Stage46 core/platform evidence selection and byte-verified committed-source dedup map only. No archives, Git writes, source changes, acquisitions or reruns.',
    'commit': COMMIT, 'tree': TREE, 'selectedRoots': len(roots), 'disjointBRoots': len(b_roots),
    'originalFiles': len(inventory), 'originalBytes': sum(r['bytes'] for r in inventory),
    'rawPayloadFiles': sum(v['rawPayloadFiles'] for v in stats.values()), 'rawPayloadBytes': sum(v['rawPayloadBytes'] for v in stats.values()),
    'gitMappedFiles': sum(v['gitMappedFiles'] for v in stats.values()), 'gitMappedBytes': sum(v['gitMappedBytes'] for v in stats.values()),
    'symlinks': sum(v['symlinks'] for v in stats.values()), 'encounteredPrewalkPrunes': encountered_prunes,
    'originalFileManifestSha256': sha_file(OUT / 'original-files.jsonl'), 'seconds': time.time() - started,
    'preservedBoundaries': ['Historical runtime/clippy/fixture/consumer/index/HTTP failures and producer scripts/raw streams remain selected.',
        'C05 historical default-headless browser identity limitation remains preserved with addenda; C06 explicit-executable acquisitions and post-build HTTP tools remain separately bound.',
        'All compiled candidate and baseline artifacts remain raw payloads. Only independently byte-equal committed source/fixture snapshots are proposed for Git reconstruction.',
        'Raw checkout-transformed gradlew.bat bytes and any historical source bytes differing from the committed blob remain raw payloads.',
        'Whole Stage46 language/persistent full regression is still a separately published acquisition and is excluded here.',
        'Selection is not publication completion. Before gathering/archive, recheck original path sets/hashes, commit binding and producer closure/addendum status. No original closure is invented.'],
})
save('closure.json', {p.name: sha_file(p) for p in OUT.iterdir() if p.is_file() and p.name != 'closure.json'})
print(json.dumps(load(OUT / 'selection-report.json')), flush=True)
