"""Add explicitly frozen closeout metadata; preserve the initial selection."""
from pathlib import Path
import hashlib
import json
import os
import stat

OUT = Path(__file__).resolve().parent
MAIN = OUT.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
roots = [MAIN / 'target/m2/stage46-publication-metadata-01', MAIN / 'target/m2/stage47-worktree-setup-01']
explicit = [MAIN / 'reports/m2/stage46-implementation-checkpoint.json', MAIN / 'README.md', MAIN / 'PLAN.md', MAIN / 'reports/m2/README.md']
rows = []
for root in roots:
    for directory, dirs, files in os.walk(root, followlinks=False):
        directory = Path(directory)
        assert not dirs, 'Closeout receipt roots must be flat and cache-free'
        for name in files:
            path = directory / name
            assert path.is_file() and not path.is_symlink()
            rows.append({'root': str(root), 'path': name, 'absolutePath': str(path), 'group': 'closeout-metadata',
                         'mode': stat.S_IMODE(path.stat().st_mode), 'kind': 'regular-file', 'bytes': path.stat().st_size,
                         'sha256': sha(path), 'storage': 'raw-payload'})
for path in explicit:
    assert path.is_file() and not path.is_symlink()
    rows.append({'root': str(MAIN), 'path': path.relative_to(MAIN).as_posix(), 'absolutePath': str(path),
                 'group': 'closeout-draft-documentation', 'mode': stat.S_IMODE(path.stat().st_mode),
                 'kind': 'regular-file', 'bytes': path.stat().st_size, 'sha256': sha(path), 'storage': 'raw-payload',
                 'qualification': 'Frozen pre-publication draft metadata/documentation, distinct from tested C06 runtime and implementation commit. Later publication-pointer updates require a separate binding.'})
(OUT / 'closeout-files.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in sorted(rows, key=lambda r: r['absolutePath'])))
initial = json.loads((OUT / 'selection-report.json').read_text())
assert not (set(r['absolutePath'] for r in rows) & {json.loads(l)['absolutePath'] for l in (OUT / 'original-files.jsonl').open()})
final = {'scope': 'Final proposed selection including separately frozen closeout metadata. Initial selection and counts remain unchanged as historical records.',
         'initialSelectionReportSha256': sha(OUT / 'selection-report.json'), 'initialFileManifestSha256': sha(OUT / 'original-files.jsonl'),
         'additionalRootCount': len(roots), 'additionalExplicitDraftFiles': len(explicit), 'additionalFileCount': len(rows),
         'additionalBytes': sum(r['bytes'] for r in rows), 'closeoutManifestSha256': sha(OUT / 'closeout-files.jsonl'),
         'totalRootCount': initial['selectedRoots'] + len(roots), 'totalOriginalFiles': initial['originalFiles'] + len(rows),
         'totalOriginalBytes': initial['originalBytes'] + sum(r['bytes'] for r in rows),
         'noArchiveOrGitWritesYet': True, 'fullRegressionExcluded': True}
(OUT / 'final-selection-report.json').write_text(json.dumps(final, indent=2) + '\n')
execution = {'scope': 'Independent read-only selection execution only.', 'attempts': [
    {'actualExitCode': 1, 'toolResultChunk': 'fd3b72', 'scriptOriginalName': 'select.py', 'reason': 'The script basename shadowed Python stdlib select during subprocess import; raw stdout.bin/stderr.bin preserved. No producer changes.'},
    {'actualExitCode': 0, 'toolSessionId': 12543, 'terminalToolResultChunk': '414d7b', 'script': 'collect_selection.py', 'scriptSha256': sha(OUT / 'collect_selection.py')}],
    'initialClosureQualification': 'Initial closure.json was generated before the collection process printed its final stdout line. It remains preserved; the final-selection-closure.json generated after actual process termination is authoritative for this selection package.'}
(OUT / 'selection-execution.json').write_text(json.dumps(execution, indent=2) + '\n')
(OUT / 'final-selection-closure.json').write_text(json.dumps({p.name: sha(p) for p in OUT.iterdir() if p.is_file() and p.name != 'final-selection-closure.json'}, indent=2) + '\n')
print(json.dumps({'finalSelectionSha256': sha(OUT / 'final-selection-report.json'), **final}))
