"""Record actual provider regressions using explicitly bound platform artifacts."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
save = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
assert len(sys.argv) == 3, 'Explicit platform artifact manifest and SHA256 required.'
pins_path = Path(sys.argv[1]).resolve()
assert sha(pins_path) == sys.argv[2]
pins = load(pins_path)
assert pins['schema'] == 1 and pins['sourceBindings']
assert all(sha(Path(p)) == digest for p, digest in {**pins['files'], **pins['sourceBindings']}.items())
addon = next(Path(p) for p in pins['files'] if Path(p).name == 'pkl_napi.node')
wasm = next(Path(p).parent for p in pins['files'] if Path(p).name == 'pkl_wasm_bg.wasm')
env_path = ROOT / 'target/m2/stage49-platform-environment-01/report.json'
environment = load(env_path)
assert sha(Path(environment['browser'])) == environment['browserSha256']
assert sha(Path(environment['nodePath'])) == environment['nodeSha256']
assert not (OUT / 'report.json').exists(), 'Preserve previous integration evidence.'
paths = [p for p in (ROOT / 'tools/platform').iterdir() if p.is_file() and p.suffix in {'.mjs', '.json'}]
paths += list((ROOT / 'tools').glob('*_fixtures.py'))
before = {}
for path in sorted(paths):
    relative = path.relative_to(ROOT)
    data = path.read_bytes()
    dest = OUT / 'sources' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    before[str(relative)] = hashlib.sha256(data).hexdigest()
save(OUT / 'sources-before.json', before)
report = {'scope': 'Actual Node/Chromium provider comparisons on immutable supplied artifacts. Wrapper zero means scheduled processes/reports were recorded, not passing raw compatibility or full lifecycle gates.',
          'cwd': str(ROOT), 'startedUtc': now(), 'host': platform.platform(),
          'artifactManifest': str(pins_path), 'artifactManifestSha256': sha(pins_path),
          'environment': environment, 'commands': [], 'complete': False, 'infrastructureErrors': []}
save(OUT / 'report.json', report)

def execute(label, argv):
    argv = list(map(str, argv))
    row = {'label': label, 'argv': argv, 'cwd': str(ROOT), 'startedUtc': now()}
    with (OUT / (label + '.stdout.bin')).open('wb') as stdout, (OUT / (label + '.stderr.bin')).open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=stdout, stderr=stderr)
        row['pid'] = process.pid
        save(OUT / 'active.json', row)
        print('START', label, process.pid, flush=True)
        row['exitCode'] = process.wait()
    row.update(finishedUtc=now(), stdoutSha256=sha(OUT / (label + '.stdout.bin')), stderrSha256=sha(OUT / (label + '.stderr.bin')))
    result_path = OUT / label / 'execution.json'
    if result_path.is_file():
        row['executionReportSha256'] = sha(result_path)
        result = load(result_path)
        row['reportedTargets'] = list(result.get('targets', {}))
        row['reportedInfrastructureErrors'] = result.get('infrastructureErrors', [])
        row['reportedBrowserErrors'] = result.get('browserErrors', [])
        row['reportedChangedInputs'] = result.get('changedInputs', [])
        if set(row['reportedTargets']) != {'node', 'browser'}:
            report['infrastructureErrors'].append(label + ': missing actual target report')
        if any(row[key] for key in ['reportedInfrastructureErrors', 'reportedBrowserErrors', 'reportedChangedInputs']):
            report['infrastructureErrors'].append(label + ': reported acquisition/integrity failure')
    else:
        report['infrastructureErrors'].append(label + ': missing execution report')
    if row['exitCode'] not in (0, 1):
        report['infrastructureErrors'].append(label + ': abnormal process termination')
    report['commands'].append(row)
    save(OUT / (label + '.terminal.json'), row)
    save(OUT / 'report.json', report)
    print('DONE', label, row['exitCode'], flush=True)

node = environment['nodePath']
package = ROOT / 'tools/platform/package.json'
for profile in ['public', 'provided-primary']:
    label = 'modulekey-' + profile
    execute(label, [node, ROOT / 'tools/platform/compare-modulekey.mjs', OUT / label,
                    wasm, addon, ROOT / 'tests/fixtures/m2-modulekey-spi',
                    ROOT / 'tests/fixtures/m2-modulekey-host/host-metadata.json',
                    ROOT / 'tools/modulekey_fixtures.py', package, environment['browser'],
                    environment['browserSha256'], pins_path, sys.argv[2], 'all212', profile])

cases = [
    ('renderer', 'compare-renderer.mjs', 'm2-renderer-portable', True, None),
    ('resource', 'compare-resource.mjs', 'm2-resource-portable', True, None),
    ('module-preparation', 'compare-module-preparation.mjs', 'm2-module-portable', True, None),
    ('moduleinfo', 'compare-moduleinfo.mjs', 'm2-moduleinfo', True, None),
    ('security-denial', 'compare-security-denial.mjs', 'm2-security-denial', True, None),
    ('guest-catch', 'compare-guest-catch.mjs', 'm2-guest-catch', True, None),
    ('module-loader', 'compare-module-loader.mjs', 'm2-module-loading', False, None),
    ('module-inheritance', 'compare-module-loader.mjs', 'm2-module-inheritance-platform', False, 'module_inheritance_fixtures.py'),
]
for label, driver, fixture, with_package, verifier in cases:
    argv = [node, ROOT / 'tools/platform' / driver, OUT / label, wasm, addon, ROOT / 'tests/fixtures' / fixture]
    if with_package:
        argv.append(package)
    if verifier:
        argv.append(ROOT / 'tools' / verifier)
    execute(label, argv)

after = {p: sha(ROOT / p) for p in before}
save(OUT / 'sources-after.json', after)
report['sourceChanges'] = [p for p, digest in before.items() if after[p] != digest]
report['artifactChanges'] = [p for p, digest in {**pins['files'], **pins['sourceBindings']}.items() if sha(Path(p)) != digest]
report['runtimeChanges'] = [environment[k] for k, h in [('browser', 'browserSha256'), ('nodePath', 'nodeSha256')]
                            if sha(Path(environment[k])) != environment[h]]
report['finishedUtc'] = now()
report['complete'] = True
report['liveHandles'] = []
save(OUT / 'report.json', report)
save(OUT / 'active.json', {'complete': True, 'liveHandles': []})
print(json.dumps({k: report[k] for k in ['complete', 'infrastructureErrors', 'sourceChanges', 'artifactChanges', 'runtimeChanges']}), flush=True)
raise SystemExit(int(any(report[k] for k in ['infrastructureErrors', 'sourceChanges', 'artifactChanges', 'runtimeChanges'])))
