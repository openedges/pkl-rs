//! Ordered lazy collections and bytecode construction/iteration continuations.
use super::*;
use crate::heap::{
    CollectionIterator, CollectionKind, CollectionMember, CollectionMemberKind, PredicateIterator,
};

pub(super) fn typed_class(heap: &Heap, mut id: ObjectId) -> Result<Option<Class>, RuntimeError> {
    let mut visited = BTreeSet::new();
    loop {
        if !visited.insert(id) {
            return Err(RuntimeError::new(ErrorKind::Cycle, "cyclic parent chain"));
        }
        let object = heap.get(id)?;
        if let Some(class) = &object.class_definition {
            if matches!(object.builtin_type, Some(TypeCheck::Collection(_))) {
                return Ok(None);
            }
            return Ok(Some(class.clone()));
        }
        let Some(parent) = object.parent else {
            return Ok(None);
        };
        id = parent;
    }
}

use super::equality::same_key;

#[cfg(test)]
#[path = "collections_tests.rs"]
mod tests;

pub(super) fn join_blocks(
    blocks: &mut Vec<Vec<Instruction>>,
    metadata: &mut Vec<BlockMetadata>,
) -> [usize; 4] {
    let source = crate::stdlib_sources::base();
    ["List", "Set", "Listing", "ForeignMapEntry"].map(|class| {
        if class == "ForeignMapEntry" {
            let block = blocks.len();
            blocks.push(vec![
                Instruction::LoadLocal(1),
                Instruction::JavaValueString,
                Instruction::Constant(Value::string("=")),
                Instruction::Add,
                Instruction::LoadLocal(0),
                Instruction::JavaValueString,
                Instruction::Add,
                Instruction::Return,
            ]);
            metadata.push(BlockMetadata {
                spans: vec![None; 8],
                ..Default::default()
            });
            return block;
        }
        let class_start = source
            .text
            .find(&format!("class {class}<"))
            .expect("pinned collection class");
        let declaration = "external function join(separator: String): String";
        let start = class_start
            + source.text[class_start..]
                .find(declaration)
                .expect("pinned collection join");
        let parameter = start + "external function join(separator: ".len();
        let block = blocks.len();
        blocks.push(vec![
            Instruction::LoadLocal(0),
            Instruction::CheckType(TypeCheck::String),
            Instruction::CollectionJoin,
            Instruction::Return,
        ]);
        metadata.push(BlockMetadata {
            source: Some(source.clone()),
            member: format!("#{class}.join").into(),
            declaration: Some(Span::new(start, start + declaration.len())),
            spans: vec![None, Some(Span::new(parameter, parameter + 6)), None, None],
            ..BlockMetadata::default()
        });
        block
    })
}

pub(super) struct JoinRun {
    source: ObjectId,
    shallow: bool,
    values: Vec<Value>,
    separator: PklString,
    next: usize,
    awaiting: bool,
    output: crate::pkl_string::PklStringBuilder,
}
impl JoinRun {
    pub(super) fn roots(&self, roots: &mut Vec<Value>) {
        roots.push(Value::Object(self.source));
        roots.extend(self.values.iter().cloned());
    }
}

impl Vm {
    pub(super) fn empty_object(&mut self, kind: CollectionKind) -> ObjectId {
        let (index, class) = match kind {
            CollectionKind::Dynamic => (0, classes::BuiltinClass::Dynamic),
            CollectionKind::Listing => (1, classes::BuiltinClass::Listing),
            CollectionKind::Mapping => (2, classes::BuiltinClass::Mapping),
            _ => unreachable!("lazy empty object"),
        };
        // Like the strict empty cache, this is weak: a retained value preserves
        // its identity, while an unreferenced singleton does not keep a heap
        // alive after a query. Generational handles prevent stale-slot reuse.
        if let Some(id) = self.empty_objects[index]
            && self.heap.get(id).is_ok()
        {
            return id;
        }
        let class = self.canonical_builtin_class(class);
        let parent = self.heap.get_class(class).expect("builtin class").prototype;
        let id = self.heap.allocate(Object {
            parent: Some(parent),
            collection_kind: kind,
            ..Object::default()
        });
        self.empty_objects[index] = Some(id);
        id
    }

    fn amendment_class_parent(&self, class: ObjectId) -> Result<ObjectId, RuntimeError> {
        let prototype = self.heap.get_class(class)?.prototype;
        self.check_class_instantiable(self.heap.class_definition(class)?)?;
        if self.class_external(class)? {
            return Err(external_amendment_error(
                &self.heap.class_display_name(class)?,
            ));
        }
        Ok(prototype)
    }

    pub(super) fn empty_strict_collection(&mut self, kind: CollectionKind) -> ObjectId {
        let index = match kind {
            CollectionKind::List => 0,
            CollectionKind::Set => 1,
            CollectionKind::Map => 2,
            _ => unreachable!("strict empty collection"),
        };
        if let Some(id) = self.empty_collections[index]
            && self.heap.get(id).is_ok()
        {
            return id;
        }
        let id = self.heap.allocate(Object {
            collection_kind: kind,
            ..Object::default()
        });
        self.empty_collections[index] = Some(id);
        id
    }

    pub(super) fn finish_strict_collection(
        &mut self,
        id: ObjectId,
    ) -> Result<ObjectId, RuntimeError> {
        let object = self.heap.get(id)?;
        if matches!(
            object.collection_kind,
            CollectionKind::List | CollectionKind::Set | CollectionKind::Map
        ) && object.length == 0
            && object.members.is_empty()
            && object.collection_members.is_empty()
            && object.set_entries.is_empty()
            && object.parent.is_none()
            && object.collection_cast.is_none()
        {
            Ok(self.empty_strict_collection(object.collection_kind))
        } else {
            Ok(id)
        }
    }

    pub(super) fn collection_join_method(&mut self, receiver: Value) {
        let index = if self.is_list(&receiver) {
            0
        } else if self.is_set(&receiver) {
            1
        } else {
            2
        };
        let block = self.program.collection_join_blocks[index];
        let id = self.heap.allocate(Object {
            function: Some(Function {
                block,
                arity: 1,
                method: true,
                captured_this: Some(receiver),
            }),
            ..Object::default()
        });
        self.stack.push(Value::Function(id));
    }

    pub(super) fn begin_collection_join(&mut self) -> Result<(), RuntimeError> {
        let Value::String(separator) = self.pop()? else {
            return Err(invalid("unchecked collection join separator"));
        };
        let receiver = self
            .frames
            .last()
            .and_then(|f| f.environment.this_value.clone())
            .ok_or_else(|| invalid("collection join without receiver"))?
            .as_object()?;
        let shallow = self.heap.get(receiver)?.collection_kind == CollectionKind::Listing;
        // ListingNodes.join returns before force/iteration for an empty receiver.
        // The separator's String check has already run in the synthetic block.
        if shallow && self.heap.get(receiver)?.length == 0 {
            self.stack.push(Value::String("".into()));
            return Ok(());
        }
        let values = if shallow {
            Vec::new()
        } else {
            ordered_members(&self.heap, receiver)?
                .iter()
                .map(|member| {
                    cached_render_value(&self.heap, receiver, member)?
                        .ok_or_else(|| invalid("uncached strict collection element"))
                })
                .collect::<Result<Vec<_>, _>>()?
        };
        self.frames
            .last_mut()
            .expect("active join frame")
            .collection_join = Some(JoinRun {
            source: receiver,
            shallow,
            values,
            separator,
            next: 0,
            awaiting: false,
            output: crate::pkl_string::PklStringBuilder::default(),
        });
        if shallow {
            self.force_shallow_frame(Value::Object(receiver))?;
        }
        Ok(())
    }

    pub(super) fn step_collection_join(&mut self) -> Result<(), RuntimeError> {
        let frame = self.frames.len() - 1;
        let mut run = self.frames[frame]
            .collection_join
            .take()
            .expect("active join");
        if run.shallow {
            self.pop()?;
            run.shallow = false;
            run.values = ordered_members(&self.heap, run.source)?
                .iter()
                .map(|member| {
                    cached_render_value(&self.heap, run.source, member)?
                        .ok_or_else(|| invalid("uncached shallow Listing join element"))
                })
                .collect::<Result<Vec<_>, _>>()?;
        }
        if run.awaiting {
            let Value::String(text) = self.pop()? else {
                return Err(invalid("non-string collection element rendering"));
            };
            run.output.push_value(&text);
        }
        let Some(value) = run.values.get(run.next).cloned() else {
            self.stack.push(Value::String(run.output.finish()));
            return Ok(());
        };
        if run.next != 0 {
            run.output.push_value(&run.separator);
        }
        run.next += 1;
        run.awaiting = true;
        self.frames[frame].collection_join = Some(run);

        self.java_value_string(value)
    }

    // Java Object.toString is also used for PropertiesRenderer path components.
    // Preserve the same forcing and reference behavior as collection join.
    pub(super) fn java_value_string(&mut self, value: Value) -> Result<(), RuntimeError> {
        if let Value::Object(id) = &value
            && let Some(entry) = self.heap.get(*id)?.foreign_map_entry.clone()
        {
            // Map.entry's Java toString concatenates key + "=" + value. This is
            // distinct from Pkl method dispatch, which hits an upstream internal
            // error for these foreign objects. Each child can suspend independently.
            let function = self.heap.allocate(Object {
                function: Some(Function {
                    block: self.program.collection_join_blocks[3],
                    arity: 2,
                    method: false,
                    captured_this: None,
                }),
                ..Default::default()
            });
            return self.invoke_function(function, entry.to_vec(), false);
        }
        // StringBuilder.append(Object) invokes Java value stringification, not
        // Pkl's virtual Typed.toString. Objects force deeply; strict collections
        // render their cached contents without forcing nested objects.
        if let Value::Object(id) = value
            && self.heap.get(id)?.reference.is_some()
        {
            self.render_reference(id)?;
        } else if self.is_list(&value) || self.is_set(&value) {
            let text = crate::diagnostic_values::render_multiline(
                &value,
                &self.heap,
                &self.program.module_name,
            )?;
            self.stack.push(Value::String(text));
        } else if let Value::Bytes(bytes) = &value {
            // VmBytes.toString is not the diagnostic renderer's eight-byte preview.
            let mut text = crate::pkl_string::PklStringBuilder::default();
            text.push_str("Bytes(");
            for (index, byte) in bytes.iter().enumerate() {
                if index != 0 {
                    text.push_str(", ");
                }
                text.push_str(&byte.to_string());
            }
            text.push(')');
            self.stack.push(Value::String(text.finish()));
        } else if self.is_map(&value)
            || matches!(
                value,
                Value::Class(_) | Value::TypeAlias(_) | Value::Function(_)
            )
        {
            let text = crate::diagnostic_values::render_string(
                &value,
                &self.heap,
                &self.program.module_name,
                usize::MAX,
            )?;
            self.stack.push(Value::String(text));
        } else if matches!(value, Value::Object(_)) {
            self.begin_object_string(value)?;
        } else {
            self.stack.push(Value::String(scalar_string(&value)?));
        }
        Ok(())
    }
}

fn same_member(heap: &Heap, left: &CollectionMember, right: &CollectionMember) -> bool {
    (left.kind == CollectionMemberKind::Property) == (right.kind == CollectionMemberKind::Property)
        && same_key(heap, &left.key, &right.key)
}

/// Read declaration order without forcing member values. Overrides retain their
/// inherited position; properties and entries have distinct key namespaces.
pub fn ordered_members(
    heap: &Heap,
    receiver: ObjectId,
) -> Result<Vec<CollectionMember>, RuntimeError> {
    if heap.get(receiver)?.collection_kind == CollectionKind::Map {
        let object = heap.get(receiver)?;
        return Ok(object
            .map_index()
            .insertion_order()
            .iter()
            .map(|index| object.collection_members[*index].clone())
            .collect());
    }
    let typed = typed_class(heap, receiver)?.is_some() || heap.get(receiver)?.is_module;
    let mut chain = Vec::new();
    let mut next = Some(receiver);
    let mut visited = BTreeSet::new();
    while let Some(id) = next {
        if !visited.insert(id) {
            return Err(RuntimeError::new(ErrorKind::Cycle, "cyclic parent chain"));
        }
        chain.push(id);
        next = heap.get(id)?.parent;
    }
    let mut result: Vec<CollectionMember> = Vec::new();
    for id in chain.into_iter().rev() {
        let object = heap.get(id)?;
        let fallback;
        let members = if object.collection_members.is_empty() {
            fallback = object
                .members
                .iter()
                .filter(|m| !m.local && !m.method && !m.entry)
                .map(|m| CollectionMember {
                    key: Value::string(m.name.clone()),
                    name: m.name.clone(),
                    kind: CollectionMemberKind::Property,
                })
                .collect::<Vec<_>>();
            &fallback
        } else {
            &object.collection_members
        };
        for member in members {
            if !typed
                && member.kind == CollectionMemberKind::Property
                && member.name.as_ref() == "default"
            {
                continue;
            }
            if let Some(old) = result.iter_mut().find(|old| same_member(heap, old, member)) {
                *old = member.clone();
            } else {
                result.push(member.clone());
            }
        }
    }
    Ok(result)
}

/// Recover an entry's authored key from the internal cache name.
pub(crate) fn cache_entry_key(
    heap: &Heap,
    receiver: ObjectId,
    key: &CacheKey,
) -> Result<Option<Value>, RuntimeError> {
    if !key.entry || key.owner.is_some() {
        return Ok(None);
    }
    let mut owner = Some(receiver);
    let mut seen = BTreeSet::new();
    while let Some(id) = owner {
        if !seen.insert(id) {
            return Err(RuntimeError::new(ErrorKind::Cycle, "cyclic parent chain"));
        }
        let object = heap.get(id)?;
        if let Some(member) = object
            .collection_members
            .iter()
            .find(|member| member.name == key.name && member.kind != CollectionMemberKind::Property)
        {
            return Ok(Some(member.key.clone()));
        }
        owner = object.parent;
    }
    Err(invalid("missing cache entry key"))
}

/// Snapshot an already cached receiver value. Runtime rendering prepares key
/// equality before this lookup; this helper itself never evaluates a member.
pub(crate) fn cached_render_value(
    heap: &Heap,
    receiver: ObjectId,
    member: &CollectionMember,
) -> Result<Option<Value>, RuntimeError> {
    let entry = member.kind != CollectionMemberKind::Property;
    let object = heap.get(receiver)?;
    if entry {
        for slot in &object.cache_slots {
            if slot.key.entry
                && slot.key.owner.is_none()
                && !slot.key.method
                && let Some(key) = cache_entry_key(heap, receiver, &slot.key)?
                && same_key(heap, &member.key, &key)
            {
                return Ok(Some(slot.value.clone()));
            }
        }
    }
    Ok(
        match object.cache.get(&CacheKey {
            entry,
            owner: None,
            name: member.name.clone(),
            method: false,
        }) {
            Some(LazyState::Completed(value)) => Some(value.clone()),
            _ => None,
        },
    )
}

pub(super) fn forcing_members(
    heap: &Heap,
    receiver: ObjectId,
) -> Result<Vec<CollectionMember>, RuntimeError> {
    if heap.get(receiver)?.collection_kind == CollectionKind::Map {
        return ordered_members(heap, receiver);
    }
    let effective = ordered_members(heap, receiver)?;
    let mut result = Vec::new();
    let mut next = Some(receiver);
    let mut visited = BTreeSet::new();
    while let Some(id) = next {
        if !visited.insert(id) {
            return Err(RuntimeError::new(ErrorKind::Cycle, "cyclic parent chain"));
        }
        let object = heap.get(id)?;
        for member in &object.members {
            if member.local || member.method {
                continue;
            }
            if let Some(descriptor) = effective.iter().find(|d| {
                d.name == member.name && (d.kind != CollectionMemberKind::Property) == member.entry
            }) && !result.iter().any(|old| same_member(heap, descriptor, old))
            {
                result.push(descriptor.clone());
            }
        }
        next = object.parent;
    }
    Ok(result)
}

/// Class-hidden names stay hidden even when an override lacks the modifier.
pub(crate) fn hidden_property(
    heap: &Heap,
    receiver: ObjectId,
    name: &str,
    entry: bool,
) -> Result<bool, RuntimeError> {
    if entry {
        return Ok(false);
    }
    // Dynamic, Listing and Mapping inherit the hidden standard-library default.
    if name == "default" && typed_class(heap, receiver)?.is_none() && !heap.get(receiver)?.is_module
    {
        return Ok(true);
    }
    let mut owner = Some(receiver);
    let mut seen = BTreeSet::new();
    while let Some(id) = owner {
        if !seen.insert(id) {
            return Err(RuntimeError::new(ErrorKind::Cycle, "cyclic parent chain"));
        }
        let object = heap.get(id)?;
        if object.members.iter().any(|member| {
            !member.entry && !member.local && member.name.as_ref() == name && member.hidden()
        }) {
            return Ok(true);
        }
        owner = object.parent;
    }
    Ok(false)
}

#[derive(Clone)]
pub(crate) struct RenderMember {
    pub descriptor: CollectionMember,
    pub skip: bool,
    pub code: Option<usize>,
}

/// VmObject.iterateMembers visits every nonlocal declaration parent first.
/// Deduplication happens later, after the renderer hashes each visited key.
pub(crate) fn render_members(
    heap: &Heap,
    receiver: ObjectId,
) -> Result<Vec<RenderMember>, RuntimeError> {
    let mut chain = Vec::new();
    let mut owner = Some(receiver);
    let mut seen = BTreeSet::new();
    while let Some(id) = owner {
        if !seen.insert(id) {
            return Err(RuntimeError::new(ErrorKind::Cycle, "cyclic parent chain"));
        }
        chain.push(id);
        owner = heap.get(id)?.parent;
    }
    let typed = typed_class(heap, receiver)?.is_some() || heap.get(receiver)?.is_module;
    let mut result = Vec::new();
    for id in chain.into_iter().rev() {
        let object = heap.get(id)?;
        for member in &object.members {
            if member.local || member.method {
                continue;
            }
            let descriptor = if let Some(descriptor) =
                object.collection_members.iter().find(|descriptor| {
                    descriptor.name == member.name
                        && (descriptor.kind != CollectionMemberKind::Property) == member.entry
                }) {
                descriptor.clone()
            } else if member.entry {
                continue;
            } else {
                CollectionMember {
                    key: Value::string(member.name.clone()),
                    name: member.name.clone(),
                    kind: CollectionMemberKind::Property,
                }
            };
            result.push(RenderMember {
                code: Some(member.code),
                descriptor,
                skip: member.hidden()
                    || member.external()
                    || member.definition()
                    || (!typed && !member.entry && member.name.as_ref() == "default"),
            });
        }
    }
    Ok(result)
}

/// Predicates visit declarations child first and test each value immediately.
/// Their cache belongs to the declaration owner, even when the member executes
/// against a more derived source receiver.
fn predicate_members(
    heap: &Heap,
    source: ObjectId,
) -> Result<Vec<(ObjectId, CollectionMember)>, RuntimeError> {
    let mut result = Vec::new();
    let mut seen = Vec::new();
    let mut next = Some(source);
    let mut visited = BTreeSet::new();
    while let Some(owner) = next {
        if !visited.insert(owner) {
            return Err(RuntimeError::new(ErrorKind::Cycle, "cyclic parent chain"));
        }
        let object = heap.get(owner)?;
        for descriptor in &object.collection_members {
            if seen.iter().any(|old| same_member(heap, descriptor, old)) {
                continue;
            }
            seen.push(descriptor.clone());
            if descriptor.kind != CollectionMemberKind::Property {
                result.push((owner, descriptor.clone()));
            }
        }
        next = object.parent;
    }
    Ok(result)
}

pub(super) fn external_amendment_error(name: &str) -> RuntimeError {
    let mut error = RuntimeError::new(
        ErrorKind::Type,
        format!("Cannot instantiate, or amend an instance of, external class `{name}`."),
    );
    error.hint = Some("To create an instance of an external class, use its literal syntax or constructor method.\nExamples:\n* `123` uses literal syntax to create an instance of class `Int`.\n* `Pair(1, 2)` uses the `Pair()` constructor method to create an instance of class `Pair`.".into());
    error
}

impl Vm {
    fn set_candidates(
        &self,
        id: ObjectId,
        value: &Value,
        assoc: bool,
    ) -> Result<Vec<Value>, RuntimeError> {
        let object = self.heap.get(id)?;
        let hash = self.java_hash(value)?;
        let indices = if assoc {
            object.map_index().assoc_candidates(hash)
        } else {
            object.map_index().candidates(hash)
        };
        Ok(indices
            .into_iter()
            .map(|index| object.set_entries[index].clone())
            .collect())
    }

    pub(super) fn set_contains(&self, id: ObjectId, value: &Value) -> Result<bool, RuntimeError> {
        // Paguro's empty root returns before hashing even a primitive probe.
        if self.heap.get(id)?.set_entries.is_empty() {
            return Ok(false);
        }
        Ok(self
            .set_candidates(id, value, false)?
            .iter()
            .any(|candidate| same_key(&self.heap, value, candidate)))
    }

    pub(super) fn prepare_set_lookup(
        &mut self,
        id: ObjectId,
        value: &Value,
    ) -> Result<bool, RuntimeError> {
        if self.heap.get(id)?.set_entries.is_empty() {
            return Ok(false);
        }
        if self.prepare_keys(vec![value.clone()])? {
            return Ok(true);
        }
        self.search_key(value, self.set_candidates(id, value, false)?)
    }

    pub(super) fn invoke_set_contains(
        &mut self,
        callable: ObjectId,
        native: reference::NativeFunction,
        arguments: Vec<Value>,
    ) -> Result<(), RuntimeError> {
        if arguments.len() != 1 {
            let source = crate::stdlib_sources::base();
            let declaration = source
                .text
                .find("external class Set<")
                .expect("pinned Set class");
            let fragment = "external function contains(element: Any): Boolean";
            let start = declaration
                + source.text[declaration..]
                    .find(fragment)
                    .expect("pinned Set.contains");
            let span = Span::new(start, start + fragment.len());
            let mut error = RuntimeError::new(
                ErrorKind::Type,
                format!("Expected 1 function arguments but got {}.", arguments.len()),
            );
            error.frames.push(RuntimeFrame {
                span,
                member: "#Set.contains".into(),
                source: Some(source),
            });
            return Err(error);
        }
        let id = native.receiver.as_object()?;
        if self.prepare_set_lookup(id, &arguments[0])? {
            self.frames
                .last_mut()
                .expect("active frame")
                .equality_run
                .as_mut()
                .expect("Set lookup")
                .hide_callsite = false;
            self.stack.push(Value::Function(callable));
            self.stack.extend(arguments);
            return Ok(());
        }
        self.stack
            .push(Value::Bool(self.set_contains(id, &arguments[0])?));
        Ok(())
    }

    fn prepare_set_element(&mut self) -> Result<(), RuntimeError> {
        let value = self.pop()?;
        let id = self.builder()?;
        if self.prepare_set_lookup(id, &value)? {
            self.stack.push(value);
            return Ok(());
        }
        let present = self.set_contains(id, &value)?;
        self.stack.extend([value, Value::Bool(present)]);
        Ok(())
    }

    pub(super) fn add_set_element(&mut self) -> Result<(), RuntimeError> {
        let present = self.pop()?;
        let value = self.pop()?;
        if present == Value::Bool(true) {
            return Ok(());
        }
        if self.put_set_key(&value)? {
            self.stack.extend([value, present]);
            return Ok(());
        }
        self.stack.push(value);
        self.append_strict_element()
    }

    /// Return true only when hashing/equality must retry this instruction.
    pub(super) fn put_set_key(&mut self, value: &Value) -> Result<bool, RuntimeError> {
        let id = self.builder()?;
        if self.prepare_keys(vec![value.clone()])?
            || self.search_key(value, self.set_candidates(id, value, true)?)?
        {
            return Ok(true);
        }
        let replacing = self
            .set_candidates(id, value, true)?
            .iter()
            .any(|candidate| same_key(&self.heap, value, candidate));
        if !replacing {
            let object = self.heap.get(id)?;
            let old = object
                .map_index()
                .rehash(self.java_hash(value)?)
                .into_iter()
                .map(|index| object.set_entries[index].clone())
                .collect();
            if self.prepare_keys(old)? {
                return Ok(true);
            }
            let mut hashes = self
                .heap
                .get(id)?
                .set_entries
                .iter()
                .map(|value| self.java_hash(value))
                .collect::<Result<Vec<_>, _>>()?;
            hashes.push(self.java_hash(value)?);
            let object = self.heap.get_mut(id)?;
            object
                .map_index
                .get_or_insert_with(Box::default)
                .insert(hashes, true);
            object.set_entries.push(value.clone());
        }
        Ok(false)
    }

    pub(super) fn set_hash_elements(&self, id: ObjectId) -> Result<Vec<Value>, RuntimeError> {
        let object = self.heap.get(id)?;
        Ok(object
            .map_index()
            .ordered()
            .into_iter()
            .map(|index| object.set_entries[index].clone())
            .collect())
    }

    fn map_candidates(&self, id: ObjectId, key: &Value) -> Result<Vec<Value>, RuntimeError> {
        let object = self.heap.get(id)?;
        Ok(object
            .map_index()
            .candidates(self.java_hash(key)?)
            .into_iter()
            .map(|index| object.collection_members[index].key.clone())
            .collect())
    }

    /// Paguro skips hashing only when its root is empty. Every nonempty lookup
    /// hashes the probe before comparing candidates, including small Maps.
    pub(super) fn prepare_map_lookup(
        &mut self,
        id: ObjectId,
        key: &Value,
    ) -> Result<bool, RuntimeError> {
        if self.heap.get(id)?.length == 0 {
            return Ok(false);
        }
        if self.prepare_keys(vec![key.clone()])? {
            return Ok(true);
        }
        self.search_key(key, self.map_candidates(id, key)?)
    }

    pub(super) fn map_value(
        &self,
        id: ObjectId,
        key: &Value,
    ) -> Result<Option<Value>, RuntimeError> {
        let object = self.heap.get(id)?;
        let candidates = self.map_candidates(id, key)?;
        let member = object.collection_members.iter().find(|member| {
            candidates
                .iter()
                .any(|candidate| equality::identical_key(&self.heap, candidate, &member.key))
                && same_key(&self.heap, key, &member.key)
        });
        Ok(member.and_then(|member| {
            object
                .member_values
                .get(&CacheKey {
                    owner: None,
                    name: member.name.clone(),
                    method: false,
                    entry: true,
                })
                .cloned()
        }))
    }

    /// Construct the diagnostic only after the shared hash/equality continuation
    /// has visited all candidate keys. Member values are never forced here.
    pub(super) fn key_suggestions_error(
        &self,
        key: &Value,
        candidates: Vec<PklString>,
    ) -> RuntimeError {
        let rendered =
            crate::diagnostic_values::render(key, &self.heap, &self.program.module_name, 80)
                .unwrap_or_else(|_| display_value(key));
        let mut error = RuntimeError::new(
            ErrorKind::MissingMember,
            PklString::join(&["Cannot find key `".into(), rendered, "`.".into()], ""),
        );
        if let Value::String(query) = key {
            let suggestions = crate::diagnostic::key_suggestions(query, candidates);
            if !suggestions.is_empty() {
                let mut lines = vec![PklString::from("Did you mean any of the following?")];
                lines.extend(suggestions.into_iter().map(|key| key.quoted()));
                error.hint = Some(PklString::join(&lines, "\n"));
            }
        }
        error
    }

    fn insert_map_entry(
        &mut self,
        id: ObjectId,
        key: Value,
        value: Value,
    ) -> Result<(), RuntimeError> {
        self.insert_map_entry_ordered(id, key, value, None)
    }

    pub(super) fn prepare_map_association(
        &mut self,
        id: ObjectId,
        key: &Value,
    ) -> Result<bool, RuntimeError> {
        if self.prepare_keys(vec![key.clone()])? {
            return Ok(true);
        }
        let object = self.heap.get(id)?;
        let candidates: Vec<_> = object
            .map_index()
            .assoc_candidates(self.java_hash(key)?)
            .into_iter()
            .map(|index| object.collection_members[index].key.clone())
            .collect();
        if self.search_key(key, candidates.clone())? {
            return Ok(true);
        }
        if !candidates
            .iter()
            .any(|candidate| same_key(&self.heap, key, candidate))
        {
            let object = self.heap.get(id)?;
            let keys = object
                .map_index()
                .rehash(self.java_hash(key)?)
                .into_iter()
                .map(|index| object.collection_members[index].key.clone())
                .collect();
            if self.prepare_keys(keys)? {
                return Ok(true);
            }
        }
        Ok(false)
    }

    pub(super) fn insert_map_entry_ordered(
        &mut self,
        id: ObjectId,
        key: Value,
        value: Value,
        append_order: Option<bool>,
    ) -> Result<(), RuntimeError> {
        let object = self.heap.get(id)?;
        let append_order = match append_order {
            Some(append) => append,
            None => self.map_value(id, &key)?.is_none(),
        };
        let candidates = object.map_index().assoc_candidates(self.java_hash(&key)?);
        let replacing = object.collection_members.iter().position(|member| {
            candidates.iter().any(|index| {
                equality::identical_key(
                    &self.heap,
                    &object.collection_members[*index].key,
                    &member.key,
                )
            }) && same_key(&self.heap, &key, &member.key)
        });
        let name = replacing
            .map(|index| object.collection_members[index].name.clone())
            .unwrap_or_else(|| {
                Arc::from(format!(
                    "\0{}:{}",
                    id.index,
                    object.collection_members.len()
                ))
            });
        let mut hashes = object
            .collection_members
            .iter()
            .map(|member| self.java_hash(&member.key))
            .collect::<Result<Vec<_>, RuntimeError>>()?;
        hashes.push(self.java_hash(&key)?);
        let object = self.heap.get_mut(id)?;
        if replacing.is_none() {
            object
                .map_index
                .get_or_insert_with(Box::default)
                .insert(hashes, append_order);
            object.collection_members.push(CollectionMember {
                key,
                name: name.clone(),
                kind: CollectionMemberKind::Entry,
            });
            object.members.push(Member {
                flags: 0,
                name: name.clone(),
                code: usize::MAX,
                local: false,
                method: false,
                entry: true,
                ty: None,
                type_span: None,
                constant: false,
                fixed: false,
            });
            object.length = object.map_index().insertion_order().len();
        }
        let cache = CacheKey {
            owner: None,
            name,
            method: false,
            entry: true,
        };
        object.member_values.insert(cache.clone(), value.clone());
        object.complete_cache(cache, value);
        Ok(())
    }

    pub(super) fn invoke_map_lookup(
        &mut self,
        callable: ObjectId,
        native: reference::NativeFunction,
        arguments: Vec<Value>,
    ) -> Result<(), RuntimeError> {
        if arguments.len() != 1 {
            return Err(RuntimeError::new(
                ErrorKind::Type,
                format!("Expected 1 function arguments but got {}.", arguments.len()),
            ));
        }
        let id = native.receiver.as_object()?;
        let key = &arguments[0];
        if self.prepare_map_lookup(id, key)? {
            self.frames
                .last_mut()
                .expect("active frame")
                .equality_run
                .as_mut()
                .expect("Map lookup")
                .hide_callsite = false;
            self.stack.push(Value::Function(callable));
            self.stack.extend(arguments);
            return Ok(());
        }
        let value = self.map_value(id, key)?;
        self.stack.push(if native.name.as_ref() == "containsKey" {
            Value::Bool(value.is_some())
        } else {
            value.unwrap_or(Value::Null)
        });
        Ok(())
    }

    pub(super) fn map_hash_members(
        &self,
        id: ObjectId,
    ) -> Result<Vec<CollectionMember>, RuntimeError> {
        let object = self.heap.get(id)?;
        Ok(object
            .map_index()
            .ordered()
            .into_iter()
            .map(|index| object.collection_members[index].clone())
            .collect())
    }

    fn prepare_map_entry(&mut self) -> Result<(), RuntimeError> {
        let value = self.pop()?;
        let key = self.pop()?;
        let id = self.builder()?;
        if self.prepare_keys(vec![key.clone()])?
            || self.search_key(&key, self.map_candidates(id, &key)?)?
        {
            self.stack.extend([key, value]);
            return Ok(());
        }
        self.stack.extend([key, value]);
        Ok(())
    }

    fn add_map_entry(&mut self) -> Result<(), RuntimeError> {
        let value = self.pop()?;
        let key = self.pop()?;
        let id = self.builder()?;
        if self.map_value(id, &key)?.is_none() {
            let object = self.heap.get(id)?;
            let old_keys = object
                .map_index()
                .rehash(self.java_hash(&key)?)
                .into_iter()
                .map(|index| object.collection_members[index].key.clone())
                .collect();
            if self.prepare_keys(old_keys)? {
                self.stack.extend([key, value]);
                return Ok(());
            }
        }
        self.insert_map_entry(id, key, value)
    }

    fn next_map_entry(&mut self, iterator: ObjectId, end: usize) -> Result<(), RuntimeError> {
        let state = self
            .heap
            .get(iterator)?
            .iterator
            .as_ref()
            .expect("Map iterator");
        let source = state.source;
        let Some(member) = state.members.get(state.position).cloned() else {
            return self.jump(end);
        };
        if self.prepare_map_lookup(source, &member.key)? {
            return Ok(());
        }
        let value = self
            .map_value(source, &member.key)?
            .ok_or_else(|| invalid("Map iterator key is no longer reachable"))?;
        self.heap
            .get_mut(iterator)?
            .iterator
            .as_mut()
            .expect("Map iterator")
            .position += 1;
        self.stack.extend([member.key, value]);
        Ok(())
    }

    fn check_strict_spread(&self) -> Result<(), RuntimeError> {
        let value = self
            .stack
            .last()
            .ok_or_else(|| invalid("missing spread source"))?;
        let (source_label, allowed, hint) = match value {
            Value::Bytes(_) => (
                "Bytes",
                CollectionKind::Listing,
                "`Bytes` can only be spread into objects of type `Dynamic` and `Listing`.",
            ),
            Value::IntSeq(_) => (
                "IntSeq",
                CollectionKind::Listing,
                "`IntSeq` can only be spread into objects of type `Dynamic` and `Listing`.",
            ),
            Value::Object(source) => match self.heap.get(*source)?.collection_kind {
                CollectionKind::Map => (
                    "Map",
                    CollectionKind::Mapping,
                    "`Map` can only be spread into objects of type `Dynamic` and `Mapping`.",
                ),
                CollectionKind::List => (
                    "List",
                    CollectionKind::Listing,
                    "`List` and `Set` can only be spread into objects of type `Dynamic` and `Listing`.",
                ),
                CollectionKind::Set => (
                    "Set",
                    CollectionKind::Listing,
                    "`List` and `Set` can only be spread into objects of type `Dynamic` and `Listing`.",
                ),
                _ => return Ok(()),
            },
            _ => return Ok(()),
        };
        let target = self.builder()?;
        let kind = self.heap.get(target)?.collection_kind;
        let class = typed_class(&self.heap, target)?;
        if (kind == CollectionKind::Dynamic || kind == allowed) && class.is_none() {
            return Ok(());
        }
        let label = class.map_or_else(
            || format!("{kind:?}"),
            |class| {
                format!(
                    "{}#{}",
                    class.module.as_deref().unwrap_or(&self.program.module_name),
                    class.name
                )
            },
        );
        let mut error = RuntimeError::new(
            ErrorKind::Type,
            PklString::join(&[format!("Cannot spread value of type `{source_label}` into object of type `{label}`.\nValue: ").into(),
crate::diagnostic_values::render(value, &self.heap, &self.program.module_name, 80)?], ""),
        );
        error.hint = Some(hint.into());
        Err(error)
    }

    fn builder(&self) -> Result<ObjectId, RuntimeError> {
        self.frames
            .last()
            .and_then(|f| f.builders.last())
            .copied()
            .ok_or_else(|| invalid("missing collection builder"))
    }

    pub(super) fn collection_builtin(
        &mut self,
        receiver: ObjectId,
        name: &str,
    ) -> Result<bool, RuntimeError> {
        let object = self.heap.get(receiver)?;
        if let Some(pair) = &object.pair
            && matches!(name, "first" | "key" | "second" | "value")
        {
            let value = pair[usize::from(matches!(name, "second" | "value"))].clone();
            self.stack.push(value);
            return Ok(true);
        }
        if object.collection_kind == CollectionKind::Dynamic
            || object.is_module
            || !(matches!(name, "length" | "isEmpty" | "isNotEmpty")
                || (name == "lastIndex" && object.collection_kind == CollectionKind::Listing))
        {
            return Ok(false);
        }
        if object.collection_kind == CollectionKind::Mapping
            && object.mapping_length.is_none()
            && matches!(name, "length" | "isEmpty" | "isNotEmpty")
        {
            let mut chain = Vec::new();
            let mut owner = Some(receiver);
            while let Some(id) = owner {
                chain.push(id);
                owner = self.heap.get(id)?.parent;
            }
            let mut keys = Vec::new();
            for id in chain.into_iter().rev() {
                keys.extend(
                    self.heap
                        .get(id)?
                        .collection_members
                        .iter()
                        .filter(|m| m.kind == CollectionMemberKind::Entry)
                        .map(|m| m.key.clone()),
                );
            }
            self.count_mapping_keys(receiver, keys);
            {
                self.frames
                    .last_mut()
                    .expect("active frame")
                    .equality_run
                    .as_mut()
                    .expect("key hash")
                    .hide_callsite = false;
                let frame = self.frames.last().expect("active frame");
                if matches!(
                    self.program
                        .blocks
                        .get(frame.block)
                        .and_then(|b| b.get(frame.pc - 1)),
                    Some(Instruction::GetMember(_) | Instruction::GetConstMember(_))
                ) {
                    self.stack.push(Value::Object(receiver));
                }
                return Ok(true);
            }
        }
        let object = self.heap.get(receiver)?;
        let length = if object.collection_kind == CollectionKind::Mapping {
            object.mapping_length.expect("completed Mapping length")
        } else {
            object.length
        };
        let value = match name {
            "length" => Value::Int((length as i64).into()),
            "lastIndex" => Value::Int((length as i64 - 1).into()),
            "isEmpty" => Value::Bool(length == 0),
            "isNotEmpty" => Value::Bool(length != 0),
            _ => return Ok(false),
        };
        self.stack.push(value);
        Ok(true)
    }

    /// Stable-hash declaration maps use the pinned bucket chain order. Maps
    /// containing JVM identity-dependent keys retain the explicit linear fallback.
    pub(super) fn declaration_candidates(
        &self,
        owner: ObjectId,
        key: &Value,
        inherited: bool,
    ) -> Result<Vec<Value>, RuntimeError> {
        let mut result = Vec::new();
        let mut current = Some(owner);
        while let Some(id) = current {
            let object = self.heap.get(id)?;
            let members = &object.collection_members;
            let indices = if let (Some(index), Some(hash)) =
                (&object.declaration_index, self.java_hash(key)?)
            {
                index.candidates(Some(hash))
            } else {
                (0..members.len()).collect()
            };
            result.extend(indices.into_iter().filter_map(|index| {
                let member = &members[index];
                (member.kind != CollectionMemberKind::Property).then(|| member.key.clone())
            }));
            current = if inherited { object.parent } else { None };
        }
        Ok(result)
    }

    fn update_declaration_index(&mut self, id: ObjectId) -> Result<(), RuntimeError> {
        let object = self.heap.get(id)?;
        if object.members.len() <= 4 {
            return Ok(());
        }
        let keys = object
            .collection_members
            .iter()
            .map(|member| {
                if member.kind == CollectionMemberKind::Property {
                    Ok(None)
                } else {
                    self.java_hash(&member.key)
                }
            })
            .collect::<Result<Option<Vec<_>>, _>>()?;
        let keys = keys.filter(|_| object.collection_members.len() == object.members.len());
        let Some(keys) = keys else {
            let object = self.heap.get_mut(id)?;
            object.declaration_index = None;
            object.declaration_hashes.clear();
            return Ok(());
        };
        let object = self.heap.get_mut(id)?;
        let index = object
            .declaration_index
            .get_or_insert_with(|| crate::economic_map::EconomicMapIndex::with_capacity(0));
        while index.len() < keys.len() {
            if index.grow_before_append() {
                for old in index.start_rehash() {
                    object.declaration_hashes[old] = keys[old];
                    index.put_hash(old, keys[old], false);
                }
            }
            let slot = index.push();
            object.declaration_hashes.push(keys[slot]);
            if (!index.has_hash() && index.len() > 4)
                || (index.has_hash() && index.put_hash(slot, keys[slot], index.should_rehash()))
            {
                for old in index.start_rehash() {
                    object.declaration_hashes[old] = keys[old];
                    index.put_hash(old, keys[old], false);
                }
            }
        }
        Ok(())
    }

    pub(super) fn prepare_insertion(
        &mut self,
        key: &Value,
        kind: CollectionMemberKind,
    ) -> Result<bool, RuntimeError> {
        let object = self.heap.get(self.builder()?)?;
        if object.members.len() < 4
            || object.collection_members.iter().any(|member| {
                (member.kind == CollectionMemberKind::Property)
                    == (kind == CollectionMemberKind::Property)
                    && same_key(&self.heap, key, &member.key)
            })
        {
            return Ok(false);
        }
        let mut keys: Vec<_> = object
            .collection_members
            .iter()
            .map(|member| member.key.clone())
            .collect();
        keys.push(key.clone());
        self.prepare_keys(keys)
    }

    pub(super) fn add_collection_member(
        &mut self,
        mut member: Member,
        key: Option<Value>,
        kind: CollectionMemberKind,
        value: Option<Value>,
    ) -> Result<(), RuntimeError> {
        let target = self.builder()?;
        let object = self.heap.get(target)?;
        let collection_kind = object.collection_kind;
        let parent = object.parent;
        let length = object.length;
        let key = key.unwrap_or(Value::Int((length as i64).into()));
        if kind != CollectionMemberKind::Property
            && let Some(class) = typed_class(&self.heap, target)?
        {
            let element = kind == CollectionMemberKind::Element;
            let label = if element { "element" } else { "entry" };
            let type_label = if !element && !object.specialized_literal {
                crate::diagnostic_values::render(
                    &Value::Object(target),
                    &self.heap,
                    &self.program.module_name,
                    80,
                )?
            } else {
                format!(
                    "{}#{}",
                    class.module.as_deref().unwrap_or(&self.program.module_name),
                    class.name
                )
                .into()
            };
            let mut error = RuntimeError::new(
                ErrorKind::Type,
                PklString::join(
                    &[
                        "Object of type `".into(),
                        type_label,
                        format!("` cannot have an {label}.").into(),
                    ],
                    "",
                ),
            );
            error.hint = Some(if element {
                "Only objects of type `Listing` and `Dynamic` can have elements. If you did not mean to add an element, you probably got the syntax wrong. For example, `obj { name }` adds an element, whereas `obj { name = \"Pigeon\" }` sets a property."
            } else {
                "Only objects of type `Mapping` and `Dynamic` can have entries. If you did not mean to add an entry, you probably got the syntax wrong. For example, `obj { [\"name\"] = \"Pigeon\" }` adds an entry, whereas `obj { name = \"Pigeon\" }` sets a property."
            }.into());
            return Err(error);
        }
        if kind == CollectionMemberKind::Element && collection_kind == CollectionKind::Mapping {
            let mut error = RuntimeError::new(
                ErrorKind::Type,
                "Object of type `Mapping` cannot have an element.",
            );
            error.hint = Some("Only objects of type `Listing` and `Dynamic` can have elements. If you did not mean to add an element, you probably got the syntax wrong. For example, `obj { name }` adds an element, whereas `obj { name = \"Pigeon\" }` sets a property.".into());
            return Err(error);
        }
        if kind == CollectionMemberKind::Property
            && !member.local
            && member.name.as_ref() != "default"
            && collection_kind != CollectionKind::Dynamic
        {
            let mut error = RuntimeError::new(
                ErrorKind::Type,
                format!(
                    "Object of type `{collection_kind:?}` cannot have a property (other than `default`)."
                ),
            );
            error.hint = Some("Objects of type `Listing` and `Mapping` can only have a `default` property (and `local` properties). If you did not mean to set a property, you probably got the syntax wrong. For example, `obj { name = \"Pigeon\" }` sets a property, whereas `obj { [\"name\"] = \"Pigeon\" }` adds an entry.".into());
            return Err(error);
        }
        if kind == CollectionMemberKind::Entry && collection_kind == CollectionKind::Listing {
            let Value::Int(index) = key else {
                return Err(RuntimeError::new(
                    ErrorKind::Type,
                    format!(
                        "Expected key of type `Int`, but got type `{}`.",
                        crate::diagnostic_values::type_name(
                            &key,
                            &self.heap,
                            &self.program.module_name
                        )?
                    ),
                ));
            };
            let parent_length = parent
                .map(|id| self.heap.get(id).map(|o| o.length))
                .transpose()?
                .unwrap_or(0);
            if index < 0 || index.get() as usize >= parent_length {
                return Err(RuntimeError::new(
                    ErrorKind::Type,
                    format!(
                        "Element index `{index}` is out of range `0`..`{}`.",
                        parent_length as i64 - 1
                    ),
                ));
            }
        }
        if kind == CollectionMemberKind::Property
            && object.members.iter().any(|old| {
                !old.entry
                    && old.name == member.name
                    && old.local == member.local
                    && old.method == member.method
            })
        {
            return Err(RuntimeError::new(
                ErrorKind::Type,
                format!("Duplicate definition of member `{}`.", member.name),
            ));
        }
        let mut descriptor = CollectionMember {
            key,
            name: member.name.clone(),
            kind,
        };
        let candidates = self.declaration_candidates(target, &descriptor.key, false)?;
        let replacing = object.collection_members.iter().position(|old| {
            (descriptor.kind == CollectionMemberKind::Property
                || candidates
                    .iter()
                    .any(|candidate| equality::identical_key(&self.heap, candidate, &old.key)))
                && same_member(&self.heap, &descriptor, old)
        });
        if replacing.is_some_and(|index| {
            !(object.specialized_literal
                && kind == CollectionMemberKind::Element
                && object.collection_members[index].kind == CollectionMemberKind::Entry)
        }) {
            return Err(RuntimeError::new(
                ErrorKind::Type,
                PklString::join(
                    &[
                        "Duplicate definition of member `".into(),
                        crate::diagnostic_values::render(
                            &descriptor.key,
                            &self.heap,
                            &self.program.module_name,
                            80,
                        )?,
                        "`.".into(),
                    ],
                    "",
                ),
            ));
        }
        if kind != CollectionMemberKind::Property {
            descriptor.name = replacing
                .map(|index| object.collection_members[index].name.clone())
                .or_else(|| {
                    parent
                        .and_then(|id| ordered_members(&self.heap, id).ok())
                        .and_then(|members| {
                            members
                                .into_iter()
                                .find(|old| same_member(&self.heap, &descriptor, old))
                        })
                        .map(|old| old.name)
                })
                .unwrap_or_else(|| {
                    Arc::from(format!("\0{}:{}", target.index, object.members.len()))
                });
            member.name = descriptor.name.clone();
            member.entry = true;
        }
        if let Some(parent) = parent {
            self.validate_object_members(parent, std::slice::from_ref(&member))?;
        }
        // Synthetic members with no body are complete values. Retaining their
        // producer's environment would keep callback inputs and lexical scopes
        // alive even when the result contains only scalars.
        let environment = if value.is_some() && member.code == usize::MAX && member.ty.is_none() {
            None
        } else {
            let frame = self.frames.last().expect("active frame");
            let mut environment = frame.environment.clone();
            environment.restore_for_bindings = !frame.generator_scopes.is_empty();
            Some(environment)
        };
        let cache_key = CacheKey {
            owner: None,
            name: member.name.clone(),
            method: member.method,
            entry: member.entry,
        };
        let object = self.heap.get_mut(target)?;
        if let Some(environment) = environment {
            object
                .member_environments
                .insert(cache_key.clone(), environment);
        }
        if !member.local && !member.method {
            if let Some(index) = replacing {
                object.collection_members[index] = descriptor;
            } else {
                object.collection_members.push(descriptor);
            }
        }
        if let Some(index) = object.members.iter().position(|old| {
            old.name == member.name
                && old.entry == member.entry
                && old.local == member.local
                && old.method == member.method
        }) {
            object.members[index] = member;
        } else {
            object.members.push(member);
        }
        if kind == CollectionMemberKind::Element {
            object.length += 1;
        }
        if let Some(value) = value {
            object
                .member_values
                .insert(cache_key.clone(), value.clone());
            self.complete_cache(target, cache_key, value)?;
        }
        self.update_declaration_index(target)?;
        Ok(())
    }

    fn source_member(
        &self,
        mut source: ObjectId,
        descriptor: &CollectionMember,
    ) -> Result<Member, RuntimeError> {
        loop {
            let object = self.heap.get(source)?;
            if let Some(member) = object.members.iter().find(|m| {
                m.name == descriptor.name
                    && m.entry == (descriptor.kind != CollectionMemberKind::Property)
                    && !m.local
                    && !m.method
            }) {
                return Ok(member.clone());
            }
            source = object
                .parent
                .ok_or_else(|| invalid("missing iterable member"))?;
        }
    }

    fn spread_error(&mut self, message: impl Into<PklString>, member: &Member) -> RuntimeError {
        let mut error = RuntimeError::new(ErrorKind::Type, message);
        let frame = self.frames.last_mut().expect("active frame");
        if let Some(metadata) = self.program.metadata.get(frame.block)
            && let Some(Some(span)) = metadata.spans.get(frame.pc - 1)
        {
            error.frames.push(RuntimeFrame {
                source: None,
                span: *span,
                member: frame
                    .diagnostic_member
                    .clone()
                    .unwrap_or_else(|| metadata.member.clone()),
            });
        }
        if let Some(metadata) = self.program.metadata.get(member.code)
            && let Some(span) = metadata.declaration
        {
            error.frames.push(RuntimeFrame {
                source: None,
                span,
                member: metadata.member.clone(),
            });
        }
        frame.callsite_hidden = true;
        error
    }

    pub(super) fn collection_instruction(
        &mut self,
        instruction: Instruction,
    ) -> Result<(), RuntimeError> {
        let empty_amendment = matches!(instruction, Instruction::AmendEmpty);
        // Reuse construction without nesting this large dispatcher's native frame.
        let instruction = if empty_amendment {
            if matches!(self.stack.last(), Some(Value::Function(_))) {
                return Ok(());
            }
            // References use the object heap but are not Pkl VmObjectLike values.
            if let Some(Value::Object(id)) = self.stack.last()
                && self.heap.get(*id)?.reference.is_none()
                && !matches!(
                    self.heap.get(*id)?.collection_kind,
                    CollectionKind::List | CollectionKind::Set | CollectionKind::Map
                )
            {
                return Ok(());
            }
            if let Some(Value::NullWithDefault(id)) = self.stack.last() {
                let value = self.heap.null_default(*id)?;
                *self.stack.last_mut().expect("null parent") = value;
                return Ok(());
            }
            Instruction::BeginCollection {
                kind: CollectionKind::Dynamic,
                has_parent: true,
                specialized: true,
            }
        } else {
            instruction
        };
        match instruction {
            Instruction::Swap => {
                let right = self.pop()?;
                let left = self.pop()?;
                self.stack.push(right);
                self.stack.push(left);
            }
            Instruction::BeginCollection {
                kind,
                has_parent,
                specialized,
            } => {
                let parent = if has_parent {
                    let mut value = self.pop()?;
                    while let Value::NullWithDefault(id) = value {
                        value = self.heap.null_default(id)?;
                    }
                    match value {
                        Value::Null => Some(self.empty_object(CollectionKind::Dynamic)),
                        Value::Class(class) => Some(self.amendment_class_parent(class)?),
                        value @ (Value::Bool(_)
                        | Value::Int(_)
                        | Value::Float(_)
                        | Value::Duration(_)
                        | Value::IntSeq(_)
                        | Value::Regex(_)
                        | Value::Bytes(_)
                        | Value::TypeAlias(_)
                        | Value::DataSize(_)
                        | Value::String(_)) => {
                            return Err(external_amendment_error(value_type_name(&value)));
                        }
                        value => Some(value.as_object()?),
                    }
                } else {
                    None
                };
                let (kind, length) = if let Some(id) = parent {
                    let object = self.heap.get(id)?;
                    if object.reference.is_some() {
                        return Err(external_amendment_error("pkl.ref#Reference"));
                    }
                    if let Some(class) = typed_class(&self.heap, id)? {
                        self.check_class_instantiable(&class)?;
                    }
                    if matches!(
                        object.collection_kind,
                        CollectionKind::List | CollectionKind::Map | CollectionKind::Set
                    ) {
                        return Err(external_amendment_error(&format!(
                            "{:?}",
                            object.collection_kind
                        )));
                    }
                    (object.collection_kind, object.length)
                } else {
                    (kind, 0)
                };
                let environment = self
                    .frames
                    .last()
                    .expect("active frame")
                    .environment
                    .clone();
                let is_module = parent
                    .map(|id| self.heap.get(id).map(|o| o.is_module))
                    .transpose()?
                    .unwrap_or(false);
                let id = self.heap.allocate(Object {
                    is_module,
                    parent,
                    collection_kind: kind,
                    length,
                    environment,
                    specialized_literal: specialized,
                    ..Object::default()
                });
                self.frames
                    .last_mut()
                    .expect("active frame")
                    .builders
                    .push(id);
            }
            Instruction::SetCollectionDefault { defined, origin } => {
                let value = if defined { Some(self.pop()?) } else { None };
                let target = self.builder()?;
                self.heap.get_mut(target)?.collection_default = Some(value);
                self.heap.get_mut(target)?.collection_default_origin = origin;
            }
            Instruction::SetCollectionTypeDefault { ty, origin } => {
                let environment = self
                    .frames
                    .last()
                    .expect("active frame")
                    .environment
                    .clone();
                let ty = ty.substituted(&environment)?;
                let target = self.builder()?;
                self.heap.get_mut(target)?.collection_default_origin = origin.clone();
                if matches!(ty.resolved(), TypeCheck::Unknown) {
                    self.heap.get_mut(target)?.collection_default = None;
                } else {
                    self.frames
                        .last_mut()
                        .expect("active frame")
                        .generic_default =
                        Some(generics::GenericDefaultRun::new(target, ty, origin));
                }
            }
            Instruction::GenericConstructorParent { ty, source, cache } => {
                let environment = &self.frames.last().expect("active frame").environment;
                let source = ty.argument_source(environment).unwrap_or(source);
                let ty = ty.substituted(environment)?;
                let frame = self.frames.last().expect("active frame");
                let metadata = &self.program.metadata[frame.block];
                let origin = metadata
                    .spans
                    .get(frame.pc.saturating_sub(1))
                    .copied()
                    .flatten()
                    .map(|span| RuntimeFrame {
                        source: metadata.source.clone(),
                        span,
                        member: if metadata.member.is_empty() {
                            metadata
                                .source
                                .as_ref()
                                .map(|source| PklString::from(source.uri.clone()))
                                .unwrap_or_default()
                        } else {
                            metadata.member.clone()
                        }
                        .concat(&".default".into()),
                    });
                let cache = cache.then_some((frame.block, frame.pc - 1));
                self.frames
                    .last_mut()
                    .expect("active frame")
                    .generic_default = Some(generics::GenericDefaultRun::constructor(
                    ty, source, origin, cache,
                ));
            }

            Instruction::EndCollection => self.end_collection()?,
            Instruction::AddCollectionProperty(member) => {
                let key = Value::string(member.name.clone());
                if self.prepare_insertion(&key, CollectionMemberKind::Property)? {
                    return Ok(());
                }
                self.add_collection_member(
                    member,
                    Some(key),
                    CollectionMemberKind::Property,
                    None,
                )?;
            }
            Instruction::AddCollectionElement(member) => {
                let object = self.heap.get(self.builder()?)?;
                if object.collection_kind != CollectionKind::Mapping
                    && typed_class(&self.heap, self.builder()?)?.is_none()
                {
                    let key = Value::Int((object.length as i64).into());
                    if self.prepare_insertion(&key, CollectionMemberKind::Element)? {
                        return Ok(());
                    }
                }
                self.add_collection_member(member, None, CollectionMemberKind::Element, None)?
            }
            Instruction::AddCollectionEntry {
                member,
                check_index,
                span,
            } => {
                let key = self.pop()?;
                let target = self.builder()?;
                if typed_class(&self.heap, target)?.is_none() && !check_index {
                    if self.heap.get(target)?.members.len() > 4
                        && self.prepare_keys(vec![key.clone()])?
                    {
                        self.stack.push(key);
                        return Ok(());
                    }
                    let candidates = self.declaration_candidates(target, &key, false)?;
                    if self.search_key(&key, candidates)? {
                        self.stack.push(key);
                        return Ok(());
                    }
                    if self.prepare_insertion(&key, CollectionMemberKind::Entry)? {
                        self.stack.push(key);
                        return Ok(());
                    }
                }
                if check_index {
                    let parent = self.heap.get(self.builder()?)?.parent;
                    let length = parent
                        .map(|id| self.heap.get(id).map(|o| o.length))
                        .transpose()?
                        .unwrap_or(0);
                    let Value::Int(index) = key else {
                        return Err(RuntimeError::new(
                            ErrorKind::Type,
                            format!(
                                "Expected value of type `Int`, but got type `{}`.",
                                value_type_name(&key)
                            ),
                        ));
                    };
                    if index < 0 || index.get() as usize >= length {
                        return Err(RuntimeError::new(
                            ErrorKind::Type,
                            format!(
                                "Element index `{index}` is out of range `0`..`{}`.",
                                length as i64 - 1
                            ),
                        ));
                    }
                }
                let target = self.builder()?;
                let generated_typed = !self.heap.get(target)?.specialized_literal
                    && typed_class(&self.heap, target)?.is_some();
                self.add_collection_member(member, Some(key), CollectionMemberKind::Entry, None)
                    .map_err(|error| {
                        if generated_typed {
                            error.at(span)
                        } else {
                            error
                        }
                    })?;
            }
            Instruction::Subscript { .. } | Instruction::SuperSubscript { .. } => {
                let key = self.pop()?;
                let is_super = matches!(instruction, Instruction::SuperSubscript { .. });
                let receiver = if is_super {
                    self.scope(0)?.receiver
                } else {
                    let value = self.pop()?;
                    if let Value::String(text) = &value {
                        let Instruction::Subscript { key_span } = instruction else {
                            unreachable!("ordinary subscript instruction")
                        };
                        let value = self.subscript_string(text, key, key_span)?;
                        self.stack.push(value);
                        return Ok(());
                    }
                    if let Value::Bytes(bytes) = &value {
                        let value = self.subscript_bytes(bytes, key)?;
                        self.stack.push(value);
                        return Ok(());
                    }
                    if matches!(value, Value::IntSeq(_)) {
                        return Err(RuntimeError::new(ErrorKind::Type, PklString::join(&[
                            format!("Operator `[]` is not defined for operand types `IntSeq` and `{}`.\nLeft operand : ", crate::diagnostic_values::type_name(&key, &self.heap, &self.program.module_name)?).into(),
                            crate::diagnostic_values::render(&value, &self.heap, &self.program.module_name, 80)?,
                            "\nRight operand: ".into(),
                            crate::diagnostic_values::render(&key, &self.heap, &self.program.module_name, 80)?,
                        ], "")));
                    }
                    value.as_object()?
                };
                if !is_super && self.heap.get(receiver)?.collection_kind == CollectionKind::Set {
                    return Err(RuntimeError::new(
                        ErrorKind::Type,
                        PklString::join(
                            &[
                                "Operator `[]` is not defined for operand types `Set` and `".into(),
                                (crate::diagnostic_values::type_name(
                                    &key,
                                    &self.heap,
                                    &self.program.module_name,
                                )?)
                                .into(),
                                "`.\nLeft operand : ".into(),
                                crate::diagnostic_values::render(
                                    &Value::Object(receiver),
                                    &self.heap,
                                    &self.program.module_name,
                                    80,
                                )?,
                                "\nRight operand: ".into(),
                                crate::diagnostic_values::render(
                                    &key,
                                    &self.heap,
                                    &self.program.module_name,
                                    80,
                                )?,
                            ],
                            "",
                        ),
                    ));
                }
                if !is_super && self.heap.get(receiver)?.collection_kind == CollectionKind::Map {
                    if self.prepare_map_lookup(receiver, &key)? {
                        self.stack.extend([Value::Object(receiver), key]);
                        return Ok(());
                    }
                    let Some(value) = self.map_value(receiver, &key)? else {
                        return self.fail_missing_key(receiver, key);
                    };
                    self.stack.push(value);
                    return Ok(());
                }
                if !is_super && self.heap.get(receiver)?.reference.is_some() {
                    self.stack.push(Value::Object(receiver));
                    self.stack.push(key.clone());
                    if let Some(result) = self.reference_access(receiver, None, Some(key))? {
                        self.pop()?;
                        self.pop()?;
                        self.stack.push(result);
                    }
                    return Ok(());
                }
                let owner = if is_super {
                    let Some(parent) = self.heap.get(self.scope(0)?.owner)?.parent else {
                        self.stack.push(key);
                        return self.force(
                            receiver,
                            receiver,
                            "default".into(),
                            false,
                            true,
                            false,
                        );
                    };
                    parent
                } else {
                    receiver
                };
                if self.heap.get(owner)?.members.len() > 4
                    && self.prepare_keys(vec![key.clone()])?
                {
                    if !is_super {
                        self.stack.push(Value::Object(receiver));
                    }
                    self.stack.push(key);
                    return Ok(());
                }
                let candidates = self.declaration_candidates(owner, &key, true)?;
                if self.search_key(&key, candidates)? {
                    if !is_super {
                        self.stack.push(Value::Object(receiver));
                    }
                    self.stack.push(key);
                    return Ok(());
                }
                let object = self.heap.get(receiver)?;
                if !is_super
                    && matches!(
                        object.collection_kind,
                        CollectionKind::Listing | CollectionKind::List
                    )
                {
                    let Value::Int(index) = key else {
                        let name = format!("{:?}", object.collection_kind);
                        return Err(RuntimeError::new(
                            ErrorKind::Type,
                            PklString::join(&[format!("Operator `[]` is not defined for operand types `{name}` and `").into(),
(value_type_name(&key)).into(),
"`.\nLeft operand : ".into(),
crate::diagnostic_values::render(
                                    &Value::Object(receiver),
                                    &self.heap,
                                    &self.program.module_name,
                                    80
                                )?,
"\nRight operand: ".into(),
crate::diagnostic_values::render(
                                    &key,
                                    &self.heap,
                                    &self.program.module_name,
                                    80
                                )?], ""),
                        ));
                    };
                    if index < 0 || index.get() as usize >= object.length {
                        let message: PklString = format!(
                            "Element index `{}` is out of range `0`..`{}`.",
                            strings::diagnostic_integer(index.get()),
                            strings::diagnostic_integer(object.length as i64 - 1)
                        )
                        .into();
                        let message = if object.collection_kind == CollectionKind::List {
                            PklString::join(
                                &[
                                    message,
                                    "\nCollection: ".into(),
                                    crate::diagnostic_values::render_string(
                                        &Value::Object(receiver),
                                        &self.heap,
                                        &self.program.module_name,
                                        80,
                                    )?,
                                ],
                                "",
                            )
                        } else {
                            message
                        };
                        return Err(RuntimeError::new(ErrorKind::Type, message));
                    }
                }
                let candidates = self.declaration_candidates(owner, &key, true)?;
                let member = ordered_members(&self.heap, owner)?
                    .into_iter()
                    .rev()
                    .find(|m| {
                        m.kind != CollectionMemberKind::Property
                            && candidates.iter().any(|candidate| {
                                equality::identical_key(&self.heap, candidate, &m.key)
                            })
                            && same_key(&self.heap, &key, &m.key)
                    });
                if member.is_none() && self.prepare_keys(vec![key.clone()])? {
                    if !is_super {
                        self.stack.push(Value::Object(receiver));
                    }
                    self.stack.push(key);
                    return Ok(());
                }
                if let Instruction::SuperSubscript { end } = instruction {
                    if member.is_none() {
                        // ReadSuperEntryNode uses the dynamic receiver's default,
                        // not the lexical owner's. Keep the evaluated key rooted
                        // while property/type resolution or the callback suspends.
                        self.stack.push(key);
                        return self.force(
                            receiver,
                            receiver,
                            "default".into(),
                            false,
                            true,
                            false,
                        );
                    }
                    self.frames.last_mut().expect("super entry frame").pc = end;
                }
                let Some(member) = member else {
                    return self.fail_missing_key(receiver, key);
                };
                self.force_key(receiver, owner, member.name, false, !is_super, false, true)?;
            }
            Instruction::EntryKey => {
                let force = self
                    .frames
                    .last()
                    .and_then(|frame| frame.force.as_ref())
                    .ok_or_else(|| invalid("entry key outside member"))?;
                let key = self
                    .heap
                    .get(force.owner)?
                    .collection_members
                    .iter()
                    .find(|member| member.name == force.name)
                    .ok_or_else(|| invalid("entry key is missing"))?
                    .key
                    .clone();
                self.stack.push(key);
            }
            Instruction::EntryDefault => {
                let receiver = self
                    .frames
                    .last()
                    .and_then(|frame| frame.force.as_ref())
                    .ok_or_else(|| invalid("entry default outside member"))?
                    .receiver;
                self.force(receiver, receiver, "default".into(), false, true, false)?;
            }
            Instruction::EntryParent { end } => {
                let force = self
                    .frames
                    .last()
                    .and_then(|f| f.force.as_ref())
                    .cloned()
                    .ok_or_else(|| invalid("entry parent outside member"))?;
                let parent = self.heap.get(force.owner)?.parent;
                let key = self
                    .heap
                    .get(force.owner)?
                    .collection_members
                    .iter()
                    .find(|m| m.name == force.name)
                    .map(|m| m.key.clone());
                if let (Some(parent), Some(key)) = (parent, &key) {
                    let candidates = forcing_members(&self.heap, parent)?
                        .into_iter()
                        .filter(|m| m.kind != CollectionMemberKind::Property)
                        .map(|m| m.key)
                        .collect();
                    if self.search_key(key, candidates)? {
                        return Ok(());
                    }
                }
                let inherited = parent
                    .map(|parent| ordered_members(&self.heap, parent))
                    .transpose()?
                    .unwrap_or_default()
                    .into_iter()
                    .find(|member| {
                        member.kind != CollectionMemberKind::Property
                            && (member.name == force.name
                                || key
                                    .as_ref()
                                    .is_some_and(|key| same_key(&self.heap, key, &member.key)))
                    });
                if let (Some(parent), Some(member)) = (parent, inherited) {
                    // The inherited value is already the parent; skip the
                    // default(key) call emitted for the missing-entry branch.
                    self.frames.last_mut().expect("entry frame").pc = end;
                    self.force_key(
                        force.receiver,
                        parent,
                        member.name,
                        false,
                        false,
                        false,
                        true,
                    )?;
                } else {
                    self.force(
                        force.receiver,
                        force.receiver,
                        "default".into(),
                        false,
                        true,
                        false,
                    )?;
                }
            }
            Instruction::OpenIterator { nullable, spread } => {
                let value = self.pop()?;
                if let Value::Bytes(bytes) = value {
                    let id = self.heap.allocate(Object {
                        bytes_iterator: Some(Box::new((bytes, 0, spread))),
                        ..Default::default()
                    });
                    self.stack.push(Value::Object(id));
                    return Ok(());
                }
                if let Value::IntSeq(sequence) = value {
                    let id = self.heap.allocate(Object {
                        int_seq_iterator: Some(Box::new(sequence.cursor(!spread))),
                        ..Default::default()
                    });
                    self.stack.push(Value::Object(id));
                    return Ok(());
                }
                let iterator = if nullable && value == Value::Null {
                    let source = self.heap.allocate(Object::default());
                    Some(CollectionIterator {
                        source,
                        members: Vec::new(),
                        position: 0,
                        force_members: Vec::new(),
                        force_position: 0,
                        awaiting_value: false,
                    })
                } else {
                    let source = match value.as_object() {
                        Ok(source) => source,
                        Err(_) => {
                            let mut error = RuntimeError::new(
                                ErrorKind::Type,
                                format!(
                                    "Cannot iterate over value of type `{}`.",
                                    value_type_name(&value)
                                ),
                            );
                            if !(spread && value.is_null()) {
                                error.message = error.message.concat(&PklString::join(
                                    &[
                                        "\nValue: ".into(),
                                        crate::diagnostic_values::render(
                                            &value,
                                            &self.heap,
                                            &self.program.module_name,
                                            80,
                                        )?,
                                    ],
                                    "",
                                ));
                            }
                            if spread && value.is_null() {
                                let frame = self.frames.last().expect("active frame");
                                error.spread_hint = self
                                    .program
                                    .metadata
                                    .get(frame.block)
                                    .and_then(|metadata| metadata.spans.get(frame.pc - 1))
                                    .copied()
                                    .flatten()
                                    .map(Box::new);
                            }
                            return Err(error);
                        }
                    };
                    if self.heap.get(source)?.reference.is_some() {
                        return Err(RuntimeError::new(
                            ErrorKind::Type,
                            PklString::join(&["Cannot iterate over value of type `pkl.ref#Reference`.\nValue: ".into(),
crate::diagnostic_values::render(
                                    &value,
                                    &self.heap,
                                    &self.program.module_name,
                                    80
                                )?], ""),
                        ));
                    }
                    if self.heap.get(source)?.is_module {
                        let mut error = RuntimeError::new(
                            ErrorKind::Type,
                            PklString::join(
                                &[
                                    "Cannot iterate over value of type `".into(),
                                    self.program.module_name.clone().into(),
                                    "`.\nValue: ".into(),
                                    crate::diagnostic_values::render(
                                        &value,
                                        &self.heap,
                                        &self.program.module_name,
                                        80,
                                    )?,
                                ],
                                "",
                            ),
                        );
                        if spread {
                            error.hint = Some("`Typed` values are not iterable. If you mean to spread its members, convert it to `Dynamic` using `toDynamic()`.".into());
                        }
                        self.frames
                            .last_mut()
                            .expect("active frame")
                            .callsite_hidden = true;
                        return Err(error);
                    }
                    if let Some(class) = typed_class(&self.heap, source)? {
                        let mut error = RuntimeError::new(
                            ErrorKind::Type,
                            PklString::join(
                                &[
                                    "Cannot iterate over value of type `".into(),
                                    (reference::type_name(
                                        &TypeCheck::Class {
                                            module: class.module.clone(),
                                            id: class.id,
                                            name: class.name,
                                        },
                                        &self.program.module_name,
                                    ))
                                    .into(),
                                    "`.\nValue: ".into(),
                                    crate::diagnostic_values::render(
                                        &value,
                                        &self.heap,
                                        &self.program.module_name,
                                        80,
                                    )?,
                                ],
                                "",
                            ),
                        );
                        if spread {
                            error.hint = Some("`Typed` values are not iterable. If you mean to spread its members, convert it to `Dynamic` using `toDynamic()`.".into());
                        }
                        return Err(error);
                    }
                    let members = ordered_members(&self.heap, source)?;
                    Some(CollectionIterator {
                        source,
                        force_members: forcing_members(&self.heap, source)?,
                        members,
                        position: 0,
                        force_position: 0,
                        awaiting_value: false,
                    })
                };
                let id = self.heap.allocate(Object {
                    iterator,
                    ..Object::default()
                });
                self.stack.push(Value::Object(id));
            }
            Instruction::EnterForScope { bindings } => self.enter_for_scope(bindings)?,
            Instruction::LeaveForScope => self.leave_for_scope()?,
            Instruction::IteratorNext { end } => {
                let id = self
                    .stack
                    .iter()
                    .rev()
                    .filter_map(Value::heap_id)
                    .find(|id| {
                        self.heap.get(*id).is_ok_and(|object| {
                            object.iterator.is_some()
                                || object.int_seq_iterator.is_some()
                                || object.bytes_iterator.is_some()
                        })
                    })
                    .or_else(|| self.stack.last().and_then(Value::heap_id))
                    .ok_or_else(|| invalid("missing iterator"))?;
                if let Some(cursor) = self.heap.get_mut(id)?.bytes_iterator.as_mut() {
                    if let Some(byte) = cursor.0.get(cursor.1).copied() {
                        let value = if cursor.2 {
                            i64::from(byte)
                        } else {
                            i64::from(byte as i8)
                        };
                        self.stack.extend([
                            Value::Int((cursor.1 as i64).into()),
                            Value::Int(value.into()),
                        ]);
                        cursor.1 += 1;
                    } else {
                        self.jump(end)?;
                    }
                    return Ok(());
                }
                if let Some(cursor) = self.heap.get_mut(id)?.int_seq_iterator.as_mut() {
                    if let Some((index, value)) = cursor.next() {
                        self.stack
                            .extend([Value::Int(index.into()), Value::Int(value.into())]);
                    } else {
                        self.jump(end)?;
                    }
                    return Ok(());
                }
                let source = self
                    .heap
                    .get(id)?
                    .iterator
                    .as_ref()
                    .ok_or_else(|| invalid("missing iterator"))?
                    .source;
                if self.heap.get(source)?.collection_kind == CollectionKind::Map {
                    self.next_map_entry(id, end)?;
                    return Ok(());
                }
                let awaiting = self
                    .heap
                    .get(id)?
                    .iterator
                    .as_ref()
                    .is_some_and(|iterator| iterator.awaiting_value);
                if awaiting {
                    self.pop()?;
                    self.heap
                        .get_mut(id)?
                        .iterator
                        .as_mut()
                        .expect("active iterator")
                        .awaiting_value = false;
                }
                let forcing = self
                    .heap
                    .get_mut(id)?
                    .iterator
                    .as_mut()
                    .and_then(|iterator| {
                        let member = iterator.force_members.get(iterator.force_position)?.clone();
                        iterator.force_position += 1;
                        iterator.awaiting_value = true;
                        Some((iterator.source, member))
                    });
                if let Some((source, member)) = forcing {
                    let caller = self.frames.len() - 1;
                    self.frames[caller].pc -= 1;
                    self.force_collection_member(source, member)?;
                    if self.frames.len() > caller + 1 {
                        self.frames[caller].callsite_hidden = true;
                    }
                    return Ok(());
                }
                let source = self
                    .heap
                    .get(id)?
                    .iterator
                    .as_ref()
                    .expect("active iterator")
                    .source;
                let effective = ordered_members(&self.heap, source)?;
                self.heap
                    .get_mut(id)?
                    .iterator
                    .as_mut()
                    .expect("active iterator")
                    .members = effective;
                let next = self
                    .heap
                    .get_mut(id)?
                    .iterator
                    .as_mut()
                    .and_then(|iterator| {
                        let member = iterator.members.get(iterator.position)?.clone();
                        iterator.position += 1;
                        Some((iterator.source, member))
                    });
                if let Some((source, member)) = next {
                    self.stack.push(member.key.clone());
                    let caller = self.frames.len() - 1;
                    self.force_collection_member(source, member)?;
                    if self.frames.len() > caller + 1 {
                        self.frames[caller].callsite_hidden = true;
                    }
                } else {
                    self.jump(end)?;
                }
            }
            Instruction::SpreadMember => {
                let value = self.pop()?;
                let key = self.pop()?;
                let iterator = self
                    .stack
                    .last()
                    .ok_or_else(|| invalid("missing spread iterator"))?
                    .as_object()?;
                if self.heap.get(iterator)?.int_seq_iterator.is_some()
                    || self.heap.get(iterator)?.bytes_iterator.is_some()
                {
                    self.stack.push(value);
                    self.append_strict_element()?;
                    return Ok(());
                }
                let state = self
                    .heap
                    .get(iterator)?
                    .iterator
                    .as_ref()
                    .ok_or_else(|| invalid("empty spread iterator"))?;
                let source_member = state.members[state.position - 1].clone();
                let mut member = self.source_member(state.source, &source_member)?;
                let target = self.builder()?;
                let object = self.heap.get(target)?;
                let target_kind = object.collection_kind;
                let typed_target = typed_class(&self.heap, target)?;
                let forbidden = if typed_target.is_some() {
                    source_member.kind != CollectionMemberKind::Property
                } else {
                    match target_kind {
                        CollectionKind::Listing | CollectionKind::List | CollectionKind::Set => {
                            source_member.kind != CollectionMemberKind::Element
                        }
                        CollectionKind::Mapping | CollectionKind::Map => {
                            source_member.kind != CollectionMemberKind::Entry
                        }
                        CollectionKind::Dynamic => false,
                    }
                };
                if forbidden {
                    let kind = match source_member.kind {
                        CollectionMemberKind::Property => "properties",
                        CollectionMemberKind::Entry => "entries",
                        CollectionMemberKind::Element => "elements",
                    };
                    let type_label = typed_target.map_or_else(
                        || format!("{target_kind:?}"),
                        |class| {
                            format!(
                                "{}#{}",
                                class.module.as_deref().unwrap_or(&self.program.module_name),
                                class.name
                            )
                        },
                    );
                    return Err(self.spread_error(format!("Cannot spread object containing {kind} into object of type `{type_label}`."), &member));
                }
                if source_member.kind == CollectionMemberKind::Entry {
                    if self.heap.get(target)?.members.len() > 4
                        && self.prepare_keys(vec![key.clone()])?
                    {
                        self.stack.push(key);
                        return Ok(());
                    }
                    let candidates = self.declaration_candidates(target, &key, false)?;
                    if self.search_key(&key, candidates)? {
                        self.stack.push(key);
                        self.stack.push(value);
                        return Ok(());
                    }
                }
                let insertion_key = if source_member.kind == CollectionMemberKind::Element {
                    Value::Int((self.heap.get(target)?.length as i64).into())
                } else {
                    key.clone()
                };
                if self.prepare_insertion(&insertion_key, source_member.kind)? {
                    self.stack.push(key);
                    self.stack.push(value);
                    return Ok(());
                }
                let object = self.heap.get(target)?;
                if source_member.kind != CollectionMemberKind::Element
                    && object
                        .collection_members
                        .iter()
                        .any(|m| same_member(&self.heap, &source_member, m))
                {
                    let label = if source_member.kind == CollectionMemberKind::Property {
                        "property"
                    } else {
                        "entry key"
                    };
                    let key = if source_member.kind == CollectionMemberKind::Property {
                        scalar_string(&key)?
                    } else {
                        display_value(&key)
                    };
                    return Err(self.spread_error(PklString::join(&[format!("Cannot spread object because the enclosing object already has a declaration of {label} `").into(),key,"`.".into()], ""), &member));
                }
                member.constant = false;
                let key = (source_member.kind != CollectionMemberKind::Element).then_some(key);
                self.add_collection_member(member, key, source_member.kind, Some(value))?;
            }
            Instruction::OpenPredicate => {
                let target = self.builder()?;
                let object = self.heap.get(target)?;
                let class = typed_class(&self.heap, target)?;
                if object.is_module
                    || class.is_some()
                    || object.collection_kind == CollectionKind::List
                {
                    let label = class.map_or_else(
                        || {
                            if object.is_module {
                                self.program.module_name.to_string()
                            } else {
                                format!("{:?}", object.collection_kind)
                            }
                        },
                        |class| {
                            format!(
                                "{}#{}",
                                class.module.as_deref().unwrap_or(&self.program.module_name),
                                class.name
                            )
                        },
                    );
                    return Err(RuntimeError::new(
                        ErrorKind::Type,
                        format!("Object of type `{label}` cannot have a predicate member."),
                    ));
                }
                let source = object.parent.unwrap_or(target);
                let members = if object.parent.is_some() {
                    predicate_members(&self.heap, source)?
                } else {
                    Vec::new()
                };
                let previous_this = self.current_custom_this()?;
                let id = self.heap.allocate(Object {
                    predicate_iterator: Some(PredicateIterator {
                        source,
                        members,
                        position: 0,
                        awaiting_value: false,
                        previous_this,
                    }),
                    ..Object::default()
                });
                self.stack.push(Value::Object(id));
            }
            Instruction::PredicateNext { end } => {
                let id = self
                    .stack
                    .last()
                    .and_then(Value::heap_id)
                    .filter(|id| {
                        self.heap
                            .get(*id)
                            .is_ok_and(|object| object.predicate_iterator.is_some())
                    })
                    .or_else(|| {
                        self.stack
                            .iter()
                            .rev()
                            .filter_map(Value::heap_id)
                            .find(|id| {
                                self.heap
                                    .get(*id)
                                    .is_ok_and(|object| object.predicate_iterator.is_some())
                            })
                    })
                    .ok_or_else(|| invalid("missing predicate iterator"))?;
                let state = self
                    .heap
                    .get(id)?
                    .predicate_iterator
                    .as_ref()
                    .expect("predicate iterator");
                let source = state.source;
                let awaiting_value = state.awaiting_value;
                let previous_this = state.previous_this.clone();
                let next = state
                    .members
                    .get(state.position - usize::from(awaiting_value))
                    .cloned();
                if awaiting_value {
                    let value = self.pop()?;
                    let (owner, member) =
                        next.ok_or_else(|| invalid("missing pending predicate member"))?;
                    self.complete_cache(
                        owner,
                        CacheKey {
                            owner: None,
                            name: member.name.clone(),
                            method: false,
                            entry: true,
                        },
                        value.clone(),
                    )?;
                    self.heap
                        .get_mut(id)?
                        .predicate_iterator
                        .as_mut()
                        .expect("predicate iterator")
                        .awaiting_value = false;
                    self.set_current_custom_this(Some(value))?;
                    return Ok(());
                }
                let Some((owner, member)) = next else {
                    self.set_current_custom_this(previous_this)?;
                    self.pop()?;
                    self.jump(end)?;
                    return Ok(());
                };
                self.heap
                    .get_mut(id)?
                    .predicate_iterator
                    .as_mut()
                    .expect("predicate iterator")
                    .position += 1;
                let key = CacheKey {
                    owner: None,
                    name: member.name.clone(),
                    method: false,
                    entry: true,
                };
                if let Some(value) = self.cached_slot(owner, &key)? {
                    self.set_current_custom_this(Some(value))?;
                } else {
                    self.heap
                        .get_mut(id)?
                        .predicate_iterator
                        .as_mut()
                        .expect("predicate iterator")
                        .awaiting_value = true;
                    let caller = self.frames.len() - 1;
                    self.frames[caller].pc -= 1;
                    self.force_key_mode(
                        source,
                        owner,
                        member.name.clone(),
                        false,
                        false,
                        false,
                        true,
                        true,
                    )?;
                    if self.frames.len() > caller + 1 {
                        self.frames[caller].callsite_hidden = true;
                    }
                }
            }
            Instruction::AddPredicateMember(member) => {
                let applicable = self.pop()?;
                let id = self
                    .stack
                    .last()
                    .ok_or_else(|| invalid("missing predicate iterator"))?
                    .as_object()?;
                let state = self
                    .heap
                    .get(id)?
                    .predicate_iterator
                    .as_ref()
                    .ok_or_else(|| invalid("missing predicate iterator"))?;
                let key = state.members[state.position - 1].1.key.clone();
                let kind = state.members[state.position - 1].1.kind;
                let previous_this = state.previous_this.clone();
                self.set_current_custom_this(previous_this)?;
                let Value::Bool(applicable) = applicable else {
                    return Err(type_error(
                        &TypeCheck::Boolean,
                        &applicable,
                        &self.program.module_name,
                        &self.heap,
                    )?);
                };
                if applicable {
                    // Selected elements replace existing indices; they do not
                    // append or increase the collection's length.
                    self.add_collection_member(
                        member,
                        Some(key),
                        CollectionMemberKind::Entry,
                        None,
                    )?;
                    self.heap
                        .get_mut(self.builder()?)?
                        .collection_members
                        .last_mut()
                        .ok_or_else(|| invalid("missing selected predicate member"))?
                        .kind = kind;
                }
            }
            Instruction::PrepareSetElement => self.prepare_set_element()?,
            Instruction::AddSetElement => self.add_set_element()?,
            Instruction::PutSetKey => {
                let value = self.pop()?;
                if self.put_set_key(&value)? {
                    self.stack.push(value);
                }
            }
            Instruction::PrepareMapEntry => self.prepare_map_entry()?,
            Instruction::AddMapEntry => self.add_map_entry()?,
            Instruction::CheckMapSpread => self.check_strict_spread()?,
            Instruction::MakeList { length } => {
                let mut values = Vec::with_capacity(length);
                for _ in 0..length {
                    values.push(self.pop()?);
                }
                values.reverse();
                let id = self.heap.allocate(Object {
                    collection_kind: CollectionKind::List,
                    ..Object::default()
                });
                self.frames
                    .last_mut()
                    .expect("active frame")
                    .builders
                    .push(id);
                for value in values {
                    let member = Member {
                        flags: 0,
                        entry: true,
                        name: Arc::from(""),
                        code: usize::MAX,
                        local: false,
                        method: false,
                        ty: None,
                        type_span: None,
                        constant: false,
                        fixed: false,
                    };
                    self.add_collection_member(
                        member,
                        None,
                        CollectionMemberKind::Element,
                        Some(value),
                    )?;
                }
                self.frames.last_mut().expect("active frame").builders.pop();
                let id = self.finish_strict_collection(id)?;
                self.stack.push(Value::Object(id));
            }
            _ => return Err(invalid("unexpected collection instruction")),
        }
        if empty_amendment {
            self.end_collection()?;
        }
        Ok(())
    }

    fn end_collection(&mut self) -> Result<(), RuntimeError> {
        let id = self
            .frames
            .last_mut()
            .expect("active frame")
            .builders
            .pop()
            .ok_or_else(|| invalid("missing collection builder"))?;
        let object = self.heap.get(id)?;
        let result = if object.members.is_empty() {
            if let Some(parent) = object.parent {
                let prototype = self.heap.get(parent)?;
                if prototype.class_definition.is_some()
                    && matches!(prototype.builtin_type, Some(TypeCheck::Collection(_)))
                {
                    self.empty_object(object.collection_kind)
                } else {
                    parent
                }
            } else if matches!(
                object.collection_kind,
                CollectionKind::Dynamic | CollectionKind::Listing | CollectionKind::Mapping
            ) && object.collection_default.is_none()
            {
                self.empty_object(object.collection_kind)
            } else {
                id
            }
        } else {
            id
        };
        let result = self.finish_strict_collection(result)?;
        self.stack.push(Value::Object(result));
        Ok(())
    }
}

impl Compiler<'_> {
    pub(super) fn instance_body(
        &mut self,
        members: &[crate::syntax::ObjectMember],
        parameters: &[crate::syntax::Parameter],
        span: Span,
        parameter_span: Span,
        output: &mut Code,
    ) -> Result<(), RuntimeError> {
        if members
            .iter()
            .all(|member| matches!(member, crate::syntax::ObjectMember::Property(_)))
        {
            let properties = Self::body_properties_only(members)?;
            let template = self.object(&properties)?;
            output.push_at(Instruction::MakeInstance { template }, span);
            if !parameters.is_empty() && !members.is_empty() {
                output.push_at(
                    Instruction::CheckObjectParameters {
                        target: amendment::ParameterTarget::Value,
                    },
                    parameter_span,
                );
            }
            self.initialize_member_types(&properties, false, output)?;
        } else {
            // Construct the typed parent first, preserving class validation.
            // Generator clauses then execute in source order, including
            // predicates that reject typed parents only when reached.
            if let Some(parameter) = parameters.first() {
                output.push_at(
                    Instruction::CheckObjectParameters {
                        target: amendment::ParameterTarget::Parent {
                            kind: CollectionKind::Dynamic,
                            has_parent: true,
                            typed: parameter.ty.is_some(),
                        },
                    },
                    parameter.ty.as_ref().map_or(parameter.span, |ty| ty.span),
                );
            }
            let template = self.object(&[])?;
            output.push_at(Instruction::MakeInstance { template }, span);
            self.collection_body(members, parameters, CollectionKind::Dynamic, true, output)?;
        }
        Ok(())
    }

    pub(super) fn body_properties_only(
        members: &[crate::syntax::ObjectMember],
    ) -> Result<Vec<crate::syntax::Member>, RuntimeError> {
        members
            .iter()
            .map(|member| match member {
                crate::syntax::ObjectMember::Property(member) => Ok(member.clone()),
                member => {
                    Err(unsupported_type("non-property typed object members").at(member.span()))
                }
            })
            .collect()
    }

    fn body_properties(
        members: &[crate::syntax::ObjectMember],
        result: &mut Vec<crate::syntax::Member>,
    ) {
        use crate::syntax::ObjectMember;
        for member in members {
            match member {
                ObjectMember::Property(member) => result.push(member.clone()),
                ObjectMember::When {
                    then_members,
                    else_members,
                    ..
                } => {
                    Self::body_properties(then_members, result);
                    Self::body_properties(else_members, result);
                }
                ObjectMember::For { members, .. } => Self::body_properties(members, result),
                _ => {}
            }
        }
    }

    pub(super) fn collection_body(
        &mut self,
        members: &[crate::syntax::ObjectMember],
        parameters: &[crate::syntax::Parameter],
        kind: CollectionKind,
        has_parent: bool,
        output: &mut Code,
    ) -> Result<(), RuntimeError> {
        let previous = std::mem::replace(&mut self.super_method_allowed, false);
        let result = self.collection_body_scoped(members, parameters, kind, has_parent, output);
        self.super_method_allowed = previous;
        result
    }

    fn collection_body_scoped(
        &mut self,
        members: &[crate::syntax::ObjectMember],
        parameters: &[crate::syntax::Parameter],
        kind: CollectionKind,
        has_parent: bool,
        output: &mut Code,
    ) -> Result<(), RuntimeError> {
        if has_parent && members.is_empty() {
            output.push(Instruction::AmendEmpty);
            return Ok(());
        }
        let mut properties = Vec::new();
        Self::body_properties(members, &mut properties);
        let generators = members.iter().any(|m| {
            matches!(
                m,
                crate::syntax::ObjectMember::When { .. }
                    | crate::syntax::ObjectMember::For { .. }
                    | crate::syntax::ObjectMember::Spread { .. }
                    | crate::syntax::ObjectMember::Predicate { .. }
            )
        });
        if let Some(parameter) = parameters.first().filter(|_| generators) {
            output.push_at(
                Instruction::CheckObjectParameters {
                    target: amendment::ParameterTarget::Parent {
                        kind,
                        has_parent,
                        typed: parameter.ty.is_some(),
                    },
                },
                parameter.ty.as_ref().map_or(parameter.span, |ty| ty.span),
            );
        }
        let amendment = if has_parent {
            Some(self.compile_function_amendment(parameters, output)?)
        } else {
            None
        };
        self.type_scopes.push(properties.clone());
        output.push(Instruction::BeginCollection {
            kind,
            has_parent,
            specialized: !generators,
        });
        let mixed = members
            .iter()
            .any(|m| matches!(m, crate::syntax::ObjectMember::Element { .. }));
        let mut parameter_check = None;
        if generators {
            self.collection_members(members, false, output)?;
        } else {
            // Pinned specialized literals install keyed members before elements.
            for member in members
                .iter()
                .filter(|m| matches!(m, crate::syntax::ObjectMember::Property(_)))
            {
                self.collection_members(std::slice::from_ref(member), mixed, output)?;
            }
            if !parameters.is_empty() {
                parameter_check = Some(output.len());
                output.push(Instruction::CheckObjectParameters {
                    target: amendment::ParameterTarget::Builder {
                        amendment_end: None,
                    },
                });
            }
            for member in members
                .iter()
                .filter(|m| matches!(m, crate::syntax::ObjectMember::Entry { .. }))
            {
                self.collection_members(std::slice::from_ref(member), mixed, output)?;
            }
            for member in members
                .iter()
                .filter(|m| matches!(m, crate::syntax::ObjectMember::Element { .. }))
            {
                self.collection_members(std::slice::from_ref(member), mixed, output)?;
            }
        }
        output.push(Instruction::EndCollection);
        self.initialize_member_types(&properties, false, output)?;
        self.type_scopes.pop();
        if let Some(index) = amendment {
            let end = output.len();
            if let Instruction::BeginFunctionAmendment { end: target, .. } = &mut output[index] {
                *target = end;
            }
            if let Some(check) = parameter_check {
                output[check] = Instruction::CheckObjectParameters {
                    target: amendment::ParameterTarget::Builder {
                        amendment_end: Some(end),
                    },
                };
            }
            output.push(Instruction::EndFunctionAmendment);
        }
        Ok(())
    }

    fn lazy_collection_member(
        &mut self,
        value: &crate::syntax::Expr,
        key: Option<&crate::syntax::Expr>,
        span: Span,
    ) -> Result<Member, RuntimeError> {
        let previous = std::mem::replace(&mut self.constructor_parameters_bound, false);
        let result = self.lazy_collection_member_body(value, key, span);
        self.constructor_parameters_bound = previous;
        result
    }

    fn lazy_collection_member_body(
        &mut self,
        value: &crate::syntax::Expr,
        key: Option<&crate::syntax::Expr>,
        span: Span,
    ) -> Result<Member, RuntimeError> {
        let previous = self.member.clone();
        let literal = key.and_then(|key| match &key.kind {
            crate::syntax::ExprKind::String(value) => {
                Some(PklString::from("\"").concat(value).concat(&"\"".into()))
            }
            crate::syntax::ExprKind::Int(value) => Some(value.to_string().into()),
            crate::syntax::ExprKind::Float(value) => {
                Some(crate::numeric::double_to_string(*value).into())
            }
            crate::syntax::ExprKind::Bool(value) => Some(value.to_string().into()),
            _ => None,
        });
        let label = literal.unwrap_or_else(|| {
            let count = self.entry_counts.entry(previous.clone()).or_default();
            *count += 1;
            format!("#{count}").into()
        });
        self.member = previous
            .concat(&"[".into())
            .concat(&label)
            .concat(&"]".into());
        let mut code = Code::default();
        self.expression_with_entry_parent(value, &mut code)?;
        if self.constant_member_body(value) {
            for instruction in &mut code.instructions {
                if let Instruction::Constant(value) = instruction {
                    *value = value.clone().boxed();
                }
            }
        }
        code.push(Instruction::Return);
        let block = self.block(code, Some(span))?;
        self.program.metadata[block].member_span = Some(span);
        self.program.metadata[block].value_span = Some(if self.constant_member_body(value) {
            self.constant_member_value_span(
                value,
                self.executable_value_span(key.unwrap_or(value)).end,
                key.is_some(),
            )
        } else {
            self.executable_value_span(value)
        });
        self.member = previous;
        Ok(Member {
            flags: 0,
            entry: true,
            name: Arc::from(""),
            code: block,
            local: false,
            method: false,
            ty: None,
            type_span: None,
            constant: false,
            fixed: false,
        })
    }

    fn collection_eager_expression(
        &mut self,
        expression: &crate::syntax::Expr,
        output: &mut Code,
    ) -> Result<(), RuntimeError> {
        let scope = self.type_scopes.pop().expect("collection scope");
        let result = self.expression(expression, output);
        self.type_scopes.push(scope);
        result
    }

    fn collection_members(
        &mut self,
        members: &[crate::syntax::ObjectMember],
        mixed: bool,
        output: &mut Code,
    ) -> Result<(), RuntimeError> {
        use crate::syntax::ObjectMember;
        for member in members {
            match member {
                ObjectMember::Property(member) => {
                    let scope = self.type_scopes.pop().expect("collection scope");
                    let template = self.object(std::slice::from_ref(member));
                    self.type_scopes.push(scope);
                    let template = template?;
                    let compiled = self.program.objects[template][0].clone();
                    let span = if let crate::syntax::ExprKind::Function {
                        method: true,
                        header_span,
                        ..
                    } = &member.expr.kind
                    {
                        Span::new(member.span.start, header_span.end)
                    } else {
                        member.name_span
                    };
                    output.push_at(Instruction::AddCollectionProperty(compiled), span);
                }
                ObjectMember::Element { value, span } => {
                    let member = self.lazy_collection_member(value, None, value.span)?;
                    output.push_at(Instruction::AddCollectionElement(member), *span);
                }
                ObjectMember::Entry { key, value, span } => {
                    self.collection_eager_expression(key, output)?;
                    let member = self.lazy_collection_member(value, Some(key), key.span)?;
                    let literal = matches!(
                        key.kind,
                        crate::syntax::ExprKind::Int(_)
                            | crate::syntax::ExprKind::Float(_)
                            | crate::syntax::ExprKind::String(_)
                            | crate::syntax::ExprKind::Bool(_)
                            | crate::syntax::ExprKind::Null
                    );
                    output.push_at(
                        Instruction::AddCollectionEntry {
                            member,
                            check_index: mixed && !literal,
                            span: *span,
                        },
                        key.span,
                    );
                }
                ObjectMember::When {
                    condition,
                    then_members,
                    else_members,
                    ..
                } => {
                    self.collection_eager_expression(condition, output)?;
                    let branch = output.len();
                    output.push_at(Instruction::JumpIfFalse(0), condition.span);
                    self.collection_members(then_members, false, output)?;
                    let end = output.len();
                    output.push(Instruction::Jump(0));
                    output[branch] = Instruction::JumpIfFalse(output.len());
                    self.collection_members(else_members, false, output)?;
                    output[end] = Instruction::Jump(output.len());
                }
                ObjectMember::For {
                    parameters,
                    iterable,
                    members,
                    span,
                    ..
                } => {
                    let scope = self.type_scopes.pop().expect("collection scope");
                    let checks = parameters
                        .iter()
                        .map(|parameter| {
                            parameter
                                .ty
                                .as_ref()
                                .and_then(|ty| self.resolve_expression_type(ty, output))
                        })
                        .collect::<Vec<_>>();
                    self.type_scopes.push(scope);
                    self.collection_eager_expression(iterable, output)?;
                    output.push_at(
                        Instruction::OpenIterator {
                            nullable: false,
                            spread: false,
                        },
                        iterable.unparenthesized().span,
                    );
                    let start = output.len();
                    output.push_at(Instruction::IteratorNext { end: 0 }, iterable.span);
                    output.push(Instruction::EnterForScope {
                        bindings: parameters.len(),
                    });
                    if parameters.len() == 1 {
                        output.push(Instruction::Swap);
                        output.push(Instruction::Pop);
                        let ty = checks[0].clone().unwrap_or(TypeCheck::Unknown);
                        let span = parameters[0]
                            .ty
                            .as_ref()
                            .map_or(parameters[0].span, |ty| ty.span);
                        output.push_at(Instruction::BindLocal { depth: None, ty }, span);
                    } else if parameters.len() == 2 {
                        output.push(Instruction::Swap);
                        let ty = checks[0].clone().unwrap_or(TypeCheck::Unknown);
                        let span = parameters[0]
                            .ty
                            .as_ref()
                            .map_or(parameters[0].span, |ty| ty.span);
                        output.push_at(Instruction::BindLocal { depth: None, ty }, span);
                        let ty = checks[1].clone().unwrap_or(TypeCheck::Unknown);
                        let span = parameters[1]
                            .ty
                            .as_ref()
                            .map_or(parameters[1].span, |ty| ty.span);
                        output.push_at(Instruction::BindLocal { depth: None, ty }, span);
                    } else {
                        return Err(unsupported_type("this generator parameter count").at(*span));
                    }
                    self.collection_members(members, false, output)?;
                    output.push(Instruction::LeaveForScope);
                    output.push(Instruction::Jump(start));
                    output[start] = Instruction::IteratorNext { end: output.len() };
                    output.push(Instruction::Pop);
                }
                ObjectMember::Spread {
                    value,
                    nullable,
                    span,
                } => {
                    self.collection_eager_expression(value, output)?;
                    output.push_at(Instruction::CheckMapSpread, *span);
                    output.push_at(
                        Instruction::OpenIterator {
                            nullable: *nullable,
                            spread: true,
                        },
                        value.unparenthesized().span,
                    );
                    let start = output.len();
                    output.push_at(Instruction::IteratorNext { end: 0 }, value.span);
                    output.push_at(Instruction::SpreadMember, *span);
                    output.push(Instruction::Jump(start));
                    output[start] = Instruction::IteratorNext { end: output.len() };
                    output.push(Instruction::Pop);
                }
                ObjectMember::Predicate {
                    condition, value, ..
                } => {
                    output.push_at(Instruction::OpenPredicate, condition.span);
                    let start = output.len();
                    output.push_at(Instruction::PredicateNext { end: 0 }, condition.span);
                    self.collection_eager_expression(condition, output)?;
                    let member =
                        self.lazy_collection_member(value, Some(condition), condition.span)?;
                    output.push_at(Instruction::AddPredicateMember(member), condition.span);
                    output.push(Instruction::Jump(start));
                    output[start] = Instruction::PredicateNext { end: output.len() };
                }
            }
        }
        Ok(())
    }
}
