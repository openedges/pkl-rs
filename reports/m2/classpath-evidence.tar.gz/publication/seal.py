#!/usr/bin/env python3
"""Gather exact classpath evidence roots without walking either Cargo cache."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import compat
import evidence
import m2_jvm_classpath as contract
import oracle

PUBLICATION = Path(__file__).resolve().parent
GATHERED = PUBLICATION / 'gathered'
ROOT_NAMES = ['classpath-original-01', 'classpath-original-02', 'classpath-required-checks-01',
              'classpath-tooling-checks-01', 'classpath-example-tests-01',
              'classpath-controls-java-01', 'classpath-controls-native-01']
SOURCES = [ROOT / 'target/m2' / name for name in ROOT_NAMES]
EXCLUDED = {ROOT / 'target/m2/classpath-original-01/build',
            ROOT / 'target/m2/classpath-original-02/build'}
PROPOSED = ['compatibility/m2-jvm-classpath.json',
    'crates/pkl-runtime/examples/jvm_snippet_probe.rs',
    'crates/pkl-runtime/examples/support/classpath_host.rs',
    'crates/pkl-runtime/examples/support/module_host.rs',
    'docs/m2-jvm-classpath.md', 'docs/m2-language.md',
    'tools/java/M2JvmSnippetOutputProbe.java',
    'tools/java/classpath/org/pkl/core/module/TestModuleKeyFactory.java',
    'tools/java/classpath/org/pkl/core/resource/TestResourceReader.java',
    'tools/m2_jvm_classpath.py', 'tools/tests/test_m2_jvm_classpath.py']
ARCHIVE = ROOT / 'reports/m2/classpath-evidence.tar.gz'
BINDING = ROOT / 'reports/m2/classpath-source-binding.json'
SUMMARY = ROOT / 'reports/m2/classpath-checkpoint-summary.json'
AUDIT = ROOT / 'reports/m2/classpath-publication-audit.json'


def raw(path):
    return os.fsencode(os.readlink(path)) if path.is_symlink() else path.read_bytes()


def scan():
    """lstat each entry once; links never enter the directory traversal stack."""
    records = {}
    for source in SOURCES:
        if source.is_symlink() or not source.is_dir():
            raise ValueError('missing/non-directory explicit source root: ' + str(source))
        pending = [source]
        while pending:
            current = pending.pop()
            for entry in sorted(os.scandir(current), key=lambda entry: entry.name):
                path = Path(entry.path)
                if path in EXCLUDED:
                    continue
                name = path.relative_to(ROOT).as_posix()
                if entry.is_symlink():
                    data = os.fsencode(os.readlink(path))
                    records[name] = dict(kind='symlink', bytes=len(data), sha256=compat.digest(data),
                        representation='Exact link-target bytes in a regular archive member; never followed.')
                elif entry.is_dir(follow_symlinks=False):
                    records[name] = dict(kind='directory', bytes=0, sha256=None)
                    pending.append(path)
                elif entry.is_file(follow_symlinks=False):
                    data = path.read_bytes()
                    records[name] = dict(kind='file', bytes=len(data), sha256=compat.digest(data))
                else:
                    raise ValueError('unsupported evidence entry: ' + name)
    return records


def checked_command(command, destination):
    destination.mkdir(parents=True, exist_ok=False)
    completed = subprocess.run(command, cwd=ROOT, capture_output=True)
    (destination / 'stdout.bin').write_bytes(completed.stdout)
    (destination / 'stderr.bin').write_bytes(completed.stderr)
    row = dict(command=command, cwd=str(ROOT), exit_code=completed.returncode,
               stdout_sha256=compat.digest(completed.stdout), stderr_sha256=compat.digest(completed.stderr))
    compat.write_json(destination / 'process.json', row)
    if completed.returncode:
        raise ValueError('final tooling command failed; retained at ' + str(destination))
    return row


def source_binding(source_inventory):
    current = {name: (ROOT / name).read_bytes() for name in PROPOSED}
    command = ['git', 'hash-object', '--no-filters', '--stdin-paths']
    result = subprocess.run(command, cwd=ROOT, input=('\n'.join(PROPOSED) + '\n').encode(),
                            capture_output=True, check=True)
    blobs = result.stdout.decode().splitlines()
    if len(blobs) != len(PROPOSED):
        raise ValueError('Git blob coverage differs')
    proposed = {}
    for name, blob in zip(PROPOSED, blobs):
        data = current[name]
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        if blob != actual or (ROOT / name).read_bytes() != data:
            raise ValueError('proposed source changed during Git blob proof: ' + name)
        proposed[name] = dict(sha256=compat.digest(data), git_blob=blob, bytes=len(data))
    snapshots = {}
    for source in SOURCES:
        folder = source / 'sources'
        if not folder.is_dir():
            continue
        entries, differences = {}, []
        prefix = folder.relative_to(ROOT).as_posix() + '/'
        for captured_path, item in sorted(source_inventory.items()):
            if not captured_path.startswith(prefix) or item['kind'] != 'file':
                continue
            name = captured_path.removeprefix(prefix)
            captured = item['sha256']
            current_path = ROOT / name
            current_digest = oracle.sha256(current_path) if current_path.is_file() else None
            entries[name] = dict(captured_sha256=captured, current_sha256=current_digest,
                matches_current=captured == current_digest,
                current_proposed_git_blob=proposed[name]['git_blob'] if name in proposed else None)
            if captured != current_digest:
                differences.append(name)
        snapshots[source.relative_to(ROOT).as_posix()] = dict(
            count=len(entries), root_cargo_config_present='.cargo/config.toml' in entries,
            differs_from_current=sorted(differences), entries=entries)
    checkout = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    references = {}
    for name in ('external/pkl', 'external/pkl-pantry'):
        actual = subprocess.check_output(['git', '-C', name, 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
        gitlink = subprocess.check_output(['git', 'ls-tree', 'HEAD', '--', name], cwd=ROOT).decode().strip()
        references[name] = dict(checkout=actual, recorded_gitlink=gitlink)
    return dict(schema=1, scope='Current proposed files proved as exact Git blobs without object/index writes. '
        'Historical capture differences are explicit; final implementation commit binding is pending root publication.',
        checkout_before_publication=checkout, hash_object_command=command,
        hash_object_stdin_paths=PROPOSED, hash_object_stdout=result.stdout.decode(),
        references=references, proposed_files=proposed, captured_sources=snapshots)


if GATHERED.exists() or any(path.exists() for path in (ARCHIVE, BINDING, SUMMARY, AUDIT)):
    raise ValueError('publication destinations must be fresh')
latest = contract.verify_report(ROOT / 'target/m2/classpath-original-02')
if contract.contract_failures(ROOT / 'target/m2/classpath-original-02', latest):
    raise ValueError('final original02 comparison is not passing')
if len(latest['results']) != 2 or not all(row['status'] == 'pass' for row in latest['results']):
    raise ValueError('expected two final original comparisons')
before_sources = {name: oracle.sha256(ROOT / name) for name in PROPOSED}
final_tooling = PUBLICATION / 'final-tooling'
commands = [
    ['python3', '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_jvm_classpath.py', '-v'],
    ['python3', 'tools/m2_jvm_classpath.py', '--check'],
    ['python3', 'tools/m2_manifest.py', '--check'],
    ['python3', 'tools/discover.py', '--check'],
    ['python3', 'tools/m2_jvm_classpath.py', '--verify-report', 'target/m2/classpath-original-02'],
    ['python3', 'tools/m2_jvm_classpath.py', '--verify-contract', 'target/m2/classpath-original-02'],
]
tooling_rows = [checked_command(command, final_tooling / str(index)) for index, command in enumerate(commands)]
after_sources = {name: oracle.sha256(ROOT / name) for name in PROPOSED}
if before_sources != after_sources:
    raise ValueError('proposed source changed during final tooling checks')
compat.write_json(final_tooling / 'report.json', dict(commands=tooling_rows,
    before=before_sources, after=after_sources, stable=True))
before = scan()
GATHERED.mkdir(parents=True)
for name, item in before.items():
    destination = GATHERED / 'raw' / name
    if item['kind'] == 'directory':
        destination.mkdir(parents=True, exist_ok=True)
        continue
    destination.parent.mkdir(parents=True, exist_ok=True)
    data = raw(ROOT / name)
    if len(data) != item['bytes'] or compat.digest(data) != item['sha256']:
        raise ValueError('source changed before gather: ' + name)
    destination.write_bytes(data)
shutil.copytree(final_tooling, GATHERED / 'publication/final-tooling')
shutil.copyfile(Path(__file__), GATHERED / 'publication/seal.py')
shutil.copyfile(ROOT / 'tools/evidence.py', GATHERED / 'publication/evidence.py')
binding = source_binding(before)
compat.write_json(BINDING, binding)
compat.write_json(GATHERED / 'publication/source-binding.json', binding)
after_gather = scan()
if before != after_gather:
    raise ValueError('original evidence changed during gather')
compat.write_json(GATHERED / 'publication/source-integrity.json', dict(
    schema=1, roots=[path.relative_to(ROOT).as_posix() for path in SOURCES],
    exact_exclusions_before_walking=sorted(str(path.relative_to(ROOT)) for path in EXCLUDED),
    excluded_sibling_not_selected='target/classpath-check-cargo',
    before=before, after_gather=after_gather, original_evidence_unchanged=True,
    symlink_policy='Original link targets are regular payload bytes with symlink kind metadata; never dereferenced.'))
native = compat.read_json(ROOT / 'target/m2/classpath-controls-native-01/report.json')
counts = dict(Counter(row['status'] for row in native['results']))
if counts != {'pass': 3, 'mismatch': 2, 'candidate-unsupported': 1}:
    raise ValueError('unexpected classpath controls; preserve and review before publication')
required = compat.read_json(ROOT / 'target/m2/classpath-required-checks-01/report.json')
if not required['complete'] or not required['source_stable'] or any(row['exit_code'] for row in required['commands']):
    raise ValueError('required Rust checks incomplete')
checkpoint = dict(schema=1, baseline='Pkl 0.32.0', status='Bounded native directory-classpath checkpoint; M2 remains open.',
    full_m2_complete=False, original_cli_inventory_promoted=False, hosted_ci_claimed=False,
    original=dict(final_acquisition='target/m2/classpath-original-02', repetitions=2, matches=2,
        historical_acquisition='target/m2/classpath-original-01', historical_matches=2,
        input=latest['profile']['input'], candidate=latest['candidate'], oracle=latest['oracle'],
        qualification='Two repetitions of one unchanged original input are not two distinct cases.'),
    controls=dict(java='target/m2/classpath-controls-java-01', native='target/m2/classpath-controls-native-01',
        counts=counts, results=[{key: row[key] for key in ('id', 'status', 'differences')} for row in native['results']]),
    required_rust_checks=dict(commands=required['commands'], source_stable=required['source_stable'],
                              captured_inputs=len(required['before']), host=required['host']),
    tooling=dict(initial='target/m2/classpath-tooling-checks-01', final_commands=tooling_rows),
    example_tests='target/m2/classpath-example-tests-01',
    historical_integrity_findings=['original01 checker ignored directory symlinks.',
        'original01 source coverage omitted exact-root Cargo configuration.',
        'original01 recorded-build candidate original_path was not enforced.',
        'All original01 payloads and earlier tooling checks are retained unchanged; original02 uses corrected tooling.'],
    remaining=['Error controls retain two full-stderr mismatches: ApiIdentity transforms builtin source to a URL '
               'while the upstream empty transformer retains pkl:base.',
        'The repl:text import trust-denial control remains candidate-unsupported; common default module trust is not implemented.',
        'Original blocked inventory/full gate requires explicit reviewed profile integration; additive success does not erase it.',
        'General classpaths, JARs, URI/security cases, provider APIs, complete diagnostics, Wasm/NAPI, '
        'full-language compatibility, release platforms and performance/memory gates remain open.'])
compat.write_json(GATHERED / 'publication/checkpoint.json', checkpoint)
evidence.create(GATHERED, ARCHIVE, [])
# Independently compare every archive member to the already clean gathered
# files. tools/evidence.py never receives the original roots or their caches.
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    members = {member.name: member for member in archive.getmembers()}
    archive_inventory = json.load(archive.extractfile(members['EVIDENCE.json']))
    for row in archive_inventory['files']:
        data = archive.extractfile(members[row['path']]).read()
        gathered = (GATHERED / row['path']).read_bytes()
        if data != gathered or compat.digest(data) != row['sha256']:
            raise ValueError('archive payload differs: ' + row['path'])
after_archive = scan()
if before != after_archive:
    raise ValueError('original evidence changed while sealing archive')
if before_sources != {name: oracle.sha256(ROOT / name) for name in PROPOSED}:
    raise ValueError('proposed source changed during publication')
archive_metadata = dict(path=str(ARCHIVE.relative_to(ROOT)), sha256=oracle.sha256(ARCHIVE),
    compressed_bytes=ARCHIVE.stat().st_size, payload_files=len(archive_inventory['files']),
    payload_bytes=sum(row['bytes'] for row in archive_inventory['files']))
compat.write_json(SUMMARY, dict(checkpoint, archive=archive_metadata,
    source_binding=dict(path=str(BINDING.relative_to(ROOT)), sha256=oracle.sha256(BINDING))))
audit = dict(schema=1, archive=archive_metadata, original_evidence_before_after_equal=True,
    original_entries=len(before), original_kinds=dict(Counter(item['kind'] for item in before.values())),
    gathered_payloads_exact=True, archive_inventory_verified=True,
    proposed_git_blobs=len(binding['proposed_files']), proposed_source_stable=True,
    roots=[str(path.relative_to(ROOT)) for path in SOURCES],
    exact_exclusions_before_walking=sorted(str(path.relative_to(ROOT)) for path in EXCLUDED),
    summary_sha256=oracle.sha256(SUMMARY), source_binding_sha256=oracle.sha256(BINDING),
    final_commit_binding='Pending root publication; no Git objects/index/gitlinks changed.')
compat.write_json(AUDIT, audit)
print(json.dumps(audit, sort_keys=True))
