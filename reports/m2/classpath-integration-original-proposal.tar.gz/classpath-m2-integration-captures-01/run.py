from pathlib import Path
import hashlib
import json
import os
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools'))
import m2_language

if (OUT / 'report.json').exists():
    raise ValueError('choose new capture output')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = {name: sha(ROOT / name) for name in m2_language.source_paths()}
commands = [
    ([sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_execution_profiles.py', '-v'], 0),
    ([sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_language.py', '-v'], 0),
    ([sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_jvm_classpath.py', '-v'], 0),
    ([sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_module_eval.py', '-v'], 0),
    ([sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_mappings.py', '-v'], 0),
    ([sys.executable, 'tools/m2_manifest.py', '--check'], 0),
    ([sys.executable, 'tools/m2_jvm_classpath.py', '--check'], 0),
    ([sys.executable, 'tools/discover.py', '--check'], 0),
    ([sys.executable, 'tools/m2_language.py', '--adapter', 'language-jvm-classpath-output', '--output',
      'target/m2/classpath-m2-integration-01', '--record-only'], 0),
    ([sys.executable, 'tools/m2_language.py', '--verify-report', 'target/m2/classpath-m2-integration-01'], 0),
    ([sys.executable, 'tools/m2_language.py', '--verify-subset', 'target/m2/classpath-m2-integration-01'], 0),
    ([sys.executable, 'tools/m2_language.py', '--verify-full', 'target/m2/classpath-m2-integration-01'], 1),
]
report = dict(schema=1, scope='Focused original import1b M2 JVM-profile integration, not the full selected acquisition.',
    cwd=str(ROOT), host=platform.platform(), python=sys.version, before=sources, commands=[], complete=False)
def save(): (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
save()
for index, (command, expected) in enumerate(commands):
    print('START', index, command, flush=True)
    started = time.monotonic()
    with (OUT / f'{index}.stdout.bin').open('wb') as stdout, (OUT / f'{index}.stderr.bin').open('wb') as stderr:
        child = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr)
        (OUT / 'active.json').write_text(json.dumps(dict(index=index, command=command, pid=child.pid), indent=2) + '\n')
        code = child.wait()
    report['commands'].append(dict(index=index, command=command, exit_code=code, expected_exit=expected,
        seconds=time.monotonic()-started, stdout_sha256=sha(OUT / f'{index}.stdout.bin'),
        stderr_sha256=sha(OUT / f'{index}.stderr.bin')))
    save()
    print('FINISH', index, code, flush=True)
    if code != expected:
        raise SystemExit('Unexpected command outcome; raw failure retained')
report['after'] = {name: sha(ROOT / name) for name in sources}
report['source_stable'] = report['before'] == report['after']
report['complete'] = True
save()
if not report['source_stable']:
    raise SystemExit('Source changed during acquisition')
