"""Correct the interpretation of preserved child and wrapper exit records."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

root = Path.cwd()
out = root / "target/m2/stage44-final-correction-01"
source = out / "source"
source.mkdir()
reports = root / "reports/m2"
original = root.parent / "pkl-rs.stage44/target/m2/stage44-full-regression-01/process-report.json"
recovery = root.parent / "pkl-rs.stage44/target/m2/stage44-full-regression-continuation-01/recovery.json"
review = root / "target/m2/stage44-final-review-01/report.json"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2) + "\n")

record = json.loads(original.read_text())
recovered = json.loads(recovery.read_text())
assert sha(original) == recovered["original_wrapper_report_sha256"]
assert record["complete"] is False
assert len(record["commands"]) == 1
child = record["commands"][0]
assert child["label"] == "language-acquire" and child["returncode"] == 0
summary_path = reports / "stage44-final-summary.json"
previous_summary = sha(summary_path)
published_review = reports / "stage44-final-independent-review.json"
assert not published_review.exists()
shutil.copyfile(review, published_review)
retained = [
    reports / "stage44-final-regression-audit.json",
    reports / "stage44-final-regression-captures.json",
    reports / "stage44-final-regression-captures.tar.gz",
    reports / "stage44-final-closeout-captures.tar.gz",
    original,
    recovery,
]
identities = {str(p): sha(p) for p in retained}
correction = {
    "schema": 1,
    "scope": "Metadata interpretation correction only; no acquisition, comparison outcome, source, artifact, or original evidence changes.",
    "finding": "distinguish-child-returncode-from-wrapper-terminal",
    "original_wrapper_terminal_returncode": None,
    "original_language_acquisition_recorded_returncode": 0,
    "original_process_report": {"path": str(original), "sha256": sha(original)},
    "language_child_finished_utc": child["finishedUtc"],
    "recovery_record": {"path": str(recovery), "sha256": sha(recovery)},
    "independent_review": {"path": str(published_review.relative_to(root)), "sha256": sha(published_review)},
    "superseded_standalone_summary_sha256": previous_summary,
    "retained_original_sha256": identities,
    "qualification": "Null child-acquisition fields in the historical audit, recovery, publication index and pre-closeout summary conflate child and wrapper status. The preserved original process report already records child exit 0. Only the wrapper terminal result remains unknown. This correction supersedes that interpretation without modifying the historical records.",
    "comparison_counts_unchanged": True,
    "full_m2_complete": False,
}
correction_path = reports / "stage44-final-provenance-correction.json"
write(correction_path, correction)
for src, name in [
    (Path(__file__), "correct.py"),
    (original, "original-process-report.json"),
    (recovery, "original-recovery.json"),
    (review, "independent-review.json"),
    (root / "target/m2/stage44-final-review-01/review.py", "independent-review.py"),
    (summary_path, "pre-correction-summary.json"),
    (correction_path, "correction.json"),
]:
    shutil.copyfile(src, source / name)
archive = reports / "stage44-final-correction-captures.tar.gz"
assert not archive.exists()
spec = importlib.util.spec_from_file_location("evidence", root / "tools/evidence.py")
evidence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evidence)
evidence.create(source, archive, [])
summary = json.loads(summary_path.read_text())
del summary["original_language_acquisition_returncode"]
summary["original_wrapper_terminal_returncode"] = None
summary["original_language_acquisition_recorded_returncode"] = 0
summary["orchestration_recovery"] = "Original wrapper has no captured terminal exit; its preserved process report records language child exit 0. Continuation verified the existing language evidence without reacquisition, then acquired and verified lifecycle. Initial records remain unchanged; see provenance_correction for the superseded child/wrapper interpretation."
summary["provenance_correction"] = {"path": str(correction_path.relative_to(root)), "sha256": sha(correction_path)}
summary["independent_review"] = {"path": str(published_review.relative_to(root)), "sha256": sha(published_review), "qualification": "Reviewed pre-correction summary; its single finding is addressed by provenance_correction."}
summary["correction_captures"] = {"path": str(archive.relative_to(root)), "sha256": sha(archive)}
summary["publication_closeout"]["scope"] = "Historical publisher script, exact selected file list, verified acquisition index and pre-closeout summary. Initial child/wrapper interpretation is superseded by provenance_correction; all archived bytes remain unchanged."
summary_path.write_text(json.dumps(summary, indent=2) + "\n")
assert all(sha(Path(p)) == h for p, h in identities.items())
write(out / "report.json", {"complete": True, "originals_unchanged": True, "summary_sha256": sha(summary_path), "correction_sha256": sha(correction_path), "archive_sha256": sha(archive)})
print(json.dumps({"complete": True, "originals_unchanged": True, "summary_sha256": sha(summary_path)}))
