from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'pkl-rs.stage44/target/m2'
OLD = ROOT.parent / 'pkl-rs.stage42/target/m2'
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())
summary = load(ROOT / 'reports/m2/stage44-final-summary.json')
audit = load(ROOT / 'reports/m2/stage44-final-regression-audit.json')
captures = load(ROOT / 'reports/m2/stage44-final-regression-captures.json')
source_map = load(ROOT / 'reports/m2/stage44-final-source-map.json')
selection_path = ROOT / 'target/m2/stage44-final-publication-01/selection.json'
selection = load(selection_path)
lang = load(BASE / 'stage44-language-final-01/report.json')
life = load(BASE / 'stage44-class-lifecycle-final-01/report.json')
driver = load(BASE / 'stage44-full-regression-continuation-01/process-report.json')
initial = load(BASE / 'stage44-full-regression-01/process-report.json')
recovery = load(BASE / 'stage44-full-regression-continuation-01/recovery.json')
checks = {}
findings = []

for key in ('source_map', 'audit', 'raw_changes', 'captures', 'required_checks_and_platforms', 'publication_closeout'):
    pointer = summary[key]
    assert sha((ROOT / pointer['path']).read_bytes()) == pointer['sha256'], key
assert sha(selection_path.read_bytes()) == captures['selection_sha256']
checks['summary_pointers'] = True

archived = {}
archive_results = {}
for archive_path, expected_hash in [
    (ROOT / captures['archive']['path'], captures['archive']['sha256']),
    (ROOT / summary['publication_closeout']['path'], summary['publication_closeout']['sha256'])]:
    assert sha(archive_path.read_bytes()) == expected_hash
    with tarfile.open(archive_path, 'r:gz') as archive:
        entries = archive.getmembers()
        names = [entry.name for entry in entries]
        assert len(set(names)) == len(names)
        assert all(entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts for entry in entries)
        indexed = {entry.name: entry for entry in entries}
        inventory = json.load(archive.extractfile(indexed['EVIDENCE.json']))
        rows = {row['path']: row for row in inventory['files']}
        assert len(rows) == len(inventory['files']) and set(rows) == set(names) - {'EVIDENCE.json'}
        for name, row in rows.items():
            data = archive.extractfile(indexed[name]).read()
            assert len(data) == row['bytes'] and sha(data) == row['sha256'], name
            if archive_path.name == 'stage44-final-regression-captures.tar.gz':
                archived[name] = data
        archive_results[archive_path.name] = dict(files=len(rows), bytes=sum(row['bytes'] for row in rows.values()),
                                                  sha256=expected_hash, compressed_bytes=archive_path.stat().st_size)
assert len(selection['files']) == len(archived) == captures['payload_files'] == 58175
assert sum(row['bytes'] for row in selection['files']) == captures['payload_bytes'] == 86889799
for row in selection['files']:
    assert row['path'] in archived and sha(archived[row['path']]) == row['sha256']
    assert sha(Path(row['source']).read_bytes()) == row['sha256'], row['source']
checks['archive_selection_and_original_payloads'] = True

assert json.loads(archived['language/report.json']) == lang
assert json.loads(archived['lifecycle/report.json']) == life
assert len(lang['evidence_sha256']) + len(life['evidence_sha256']) == 58140
for label, report in [('language', lang), ('lifecycle', life)]:
    for name, digest in report['evidence_sha256'].items():
        assert not Path(name).is_absolute() and '..' not in Path(name).parts and not name.startswith('build/')
        assert sha(archived[label + '/' + name]) == digest, (label, name)
checks['declared_payloads'] = 58140

manifest = json.loads(archived['language/sources/compatibility/m2-language.json'])
old_manifest = load(OLD / 'stage42-language-final-02/sources/compatibility/m2-language.json')
old_lang = load(OLD / 'stage42-language-final-02/report.json')
assert manifest['cases'] == old_manifest['cases'] and len(manifest['cases']) == 4527
assert lang['selection'] == old_lang['selection']
assert [(row['id'], row['status']) for row in lang['results']] == [(row['id'], row['status']) for row in old_lang['results']]
counts = dict(Counter(row['status'] for row in lang['results']))
assert counts == lang['status_counts'] == summary['status_counts']
assert counts == {'pass': 3640, 'candidate-unsupported': 13, 'mismatch': 9, 'oracle-contract-mismatch': 1, 'oracle-error': 1}
assert len(lang['results']) == lang['selected_count'] == summary['selected'] == 3664
assert len(lang['full_gate_failures']) == summary['full_gate_failure_reasons'] == 1837
assert len(lang['metamorphic_results']) == 88 and all(row['status'] == 'pass' for row in lang['metamorphic_results'])
checks['all_4527_definitions_and_3664_statuses_unchanged'] = True

case_by_id = {row['id']: row for row in manifest['cases']}
for row in lang['results']:
    case = case_by_id[row['id']]
    if row.get('adapter') == 'language-module-eval':
        folder = 'language/cases/' + row['directory']
        runtime = {}
        for target in ('java', 'rust'):
            prefix = folder + '/' + target
            meta = json.loads(archived[prefix + '/result.json'])
            runtime[target] = dict(stdout=archived[prefix + '/stdout.bin'], stderr=archived[prefix + '/stderr.bin'],
                exit_code=meta['exit_code'], timed_out=meta['timed_out'], files=meta['files'],
                workspace_changes=meta['workspace_changes'])
        java, rust = runtime['java'], runtime['rust']
        if java['timed_out'] or java['exit_code'] not in (0, 1) or (java['exit_code'] == 1 and not java['stderr'].startswith('–– Pkl Error ––\n'.encode())):
            status = 'oracle-error'
        elif java['exit_code'] not in case['upstream_case']['expected_exit']:
            status = 'oracle-contract-mismatch'
        elif rust['timed_out']:
            status = 'candidate-timeout'
        elif rust['exit_code'] in (2, 3, 4):
            status = {2: 'candidate-unsupported', 3: 'candidate-limit-exceeded', 4: 'candidate-internal-error'}[rust['exit_code']]
        else:
            status = 'pass' if java == rust else 'mismatch'
    else:
        prefix = 'language/cases/' + row['id'] + '/'
        java = tuple([row['java']['exit_code']] + [archived[prefix + 'java.' + channel + '.bin'] for channel in ('stdout', 'stderr')])
        rust = tuple([row['rust']['exit_code']] + [archived[prefix + 'rust.' + channel + '.bin'] for channel in ('stdout', 'stderr')])
        expected_exit = 0 if case['expected_outcome'] == 'success' else 1
        outcome = archived[prefix + 'java.outcome.bin']
        java_ok = (not row['java']['timed_out'] and java[0] == expected_exit
                   and (not java[2] and outcome == b'success\n' if expected_exit == 0
                        else not java[1] and bool(java[2]) and outcome.startswith(b'pkl-exception\torg.pkl.core.')))
        status = 'oracle-error' if not java_ok else 'candidate-timeout' if row['rust']['timed_out'] else 'pass' if java == rust else 'mismatch'
    assert row['status'] == status, (row['id'], row['status'], status)
checks['independent_raw_status_reconstruction'] = 3664

call_count, errors, class_differences = 0, 0, 0
assert life['comparison_channels'] == summary['persistent_comparison_channels'] == ['status', 'stdout', 'stderr']
for row in life['cases']:
    processes = row['observations']['processes']
    java, rust = processes['java']['calls'], processes['rust']['calls']
    assert len(java) == len(rust) == len(row['observations']['comparisons'])
    for left, right in zip(java, rust):
        assert left['index'] == right['index'] and left['expression'] == right['expression']
        for channel in ('status', 'stdout', 'stderr'):
            left_data = archived[f'lifecycle/{row["directory"]}/java/{left["index"]}.{channel}.bin']
            right_data = archived[f'lifecycle/{row["directory"]}/rust/{right["index"]}.{channel}.bin']
            assert left_data == right_data, (row['id'], left['index'], channel)
            for call, data in [(left, left_data), (right, right_data)]:
                assert call['channels'][channel]['bytes'] == len(data) and call['channels'][channel]['sha256'] == sha(data)
        errors += left['status'] == 'error'
        class_differences += left['channels']['error-class']['sha256'] != right['channels']['error-class']['sha256']
        call_count += 1
assert len(life['cases']) == 334 and call_count == 2782 and errors == 928
checks['persistent_raw_calls'] = dict(sequence_executions=334, calls=call_count, errors=errors,
                                      error_class_differences_retained_but_not_compared=class_differences)

def tree(repository, revision):
    rows = {}
    for record in subprocess.check_output(['git', '-C', str(repository), 'ls-tree', '-r', '-z', revision]).split(b'\0'):
        if record:
            meta, name = record.split(b'\t'); mode, kind, oid = meta.decode().split()
            rows[name.decode()] = (kind, oid)
    return rows

trees = {key: tree(ROOT / key if key.startswith('external/') else ROOT, revision)
         for key, revision in [(summary['implementation_commit'], summary['implementation_commit']),
                               (summary['recorded_checkout'], summary['recorded_checkout']),
                               *summary['references'].items()]}
records = [(name, 'language/sources/' + name, digest) for name, digest in lang['source_sha256'].items()]
records += [(row['path'], 'lifecycle/' + row['snapshot'], row['sha256']) for row in life['sources']]
for name, member, digest in records:
    data = archived[member]
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert sha(data) == digest == source_map[name]['sha256'] and blob == source_map[name]['git_blob']
    reference = next((prefix for prefix in summary['references'] if name.startswith(prefix + '/')), None)
    if reference:
        assert trees[reference][name[len(reference) + 1:]] == ('blob', blob)
        assert source_map[name]['commit'] == summary['references'][reference]
    else:
        for revision in [summary['implementation_commit'], summary['recorded_checkout']]:
            assert trees[revision][name] == ('blob', blob)
assert len(records) == 4262 and len({row[0] for row in records}) == len(source_map) == 4078
checks['git_tree_source_binding'] = dict(captured_records=4262, unique_paths=4078)

assert driver['complete'] and all(row['returncode'] == summary['gates'][row['label']] for row in driver['commands'])
for row in driver['commands']:
    for channel in ('stdout', 'stderr'):
        data = archived['continuation/' + row[channel]['path']]
        assert sha(data) == row[channel]['sha256'] and len(data) == row[channel]['bytes']
assert not initial['complete'] and initial['commands'][0]['returncode'] == 0
assert sha((BASE / 'stage44-full-regression-01/process-report.json').read_bytes()) == recovery['original_wrapper_report_sha256']
checks['terminal_provenance'] = dict(original_wrapper_terminal=None, recorded_language_child_returncode=0,
    continuation_complete=True, strict_gates=[summary['gates'][key] for key in ('language-verify-development', 'language-verify-subset', 'language-verify-full')])
if summary.get('original_language_acquisition_returncode') is None and 'original_language_acquisition_recorded_returncode' not in summary:
    findings.append(dict(id='distinguish-child-returncode-from-wrapper-terminal',severity='P2 evidence qualification',
        summary='Original wrapper terminal is unknown, but its preserved process-report commands[0] records language-acquire returncode0. Preserve historical recovery null and qualify both facts explicitly in final standalone summary.'))
report = dict(schema=1, scope='Independent read-only Stage44 closeout review. No builds, Java/evaluator runs, acquisition reruns, Git writes or source/report mutations.',
    summary_sha256=sha((ROOT / 'reports/m2/stage44-final-summary.json').read_bytes()),
    checks=checks, archives=archive_results, findings=findings,
    no_full_compatibility_claim=not summary['full_m2_complete'] and not summary['compatibility_complete'],
    no_new_ci_or_performance_claim=not summary['hosted_ci_claimed'] and not summary['performance_target_claimed'])
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(checks=checks, archives=archive_results, findings=findings), indent=2))
