from pathlib import Path
import json,hashlib,sys,os
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tools'));import evidence
BASE=ROOT.parent/'pkl-rs.stage44/target/m2';OUT=ROOT/'target/m2/stage44-final-publication-01';GATHER=OUT/'source';GATHER.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
selected=[]
for label,name in [('language','stage44-language-final-01'),('lifecycle','stage44-class-lifecycle-final-01')]:
 root=BASE/name; report=load(root/'report.json')
 selected += [(label,root,rel) for rel in [*report['evidence_sha256'],'report.json']]
for label,root in [('initial-driver',BASE/'stage44-full-regression-01'),('continuation',BASE/'stage44-full-regression-continuation-01'),('audit',ROOT/'target/m2/stage44-final-audit-01')]:
 for p in sorted(root.iterdir()):
  assert p.is_file() and not p.is_symlink(),p
  selected.append((label,root,p.name))
rows=[]
for label,root,rel in selected:
 p=root/rel;assert p.is_file() and not p.is_symlink();dest=GATHER/label/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 data=p.read_bytes();digest=hashlib.sha256(data).hexdigest();dest.write_bytes(data)
 rows.append({'source':str(p),'path':str(dest.relative_to(GATHER)),'bytes':len(data),'sha256':digest})
save(OUT/'selection.json',{'selection':'Explicit producer evidence maps plus top-level wrapper/audit regular files; no recursive traversal of either acquisition tree or Cargo caches.','unread_cache_roots':[str(BASE/'stage44-class-lifecycle-final-01/build'),str(ROOT.parent/'pkl-rs.stage44/target/debug'),str(ROOT.parent/'pkl-rs.stage44/target/release')],'files':rows})
archive=ROOT/'reports/m2/stage44-final-regression-captures.tar.gz';assert not archive.exists();evidence.create(GATHER,archive,[])
for row in rows: assert sha(Path(row['source']))==row['sha256'],row['source']
index={'schema':1,'scope':'Original completed Stage43/44 language and lifecycle regression, incomplete original wrapper and terminal continuation, exact raw/source audit.','archive':{'path':str(archive.relative_to(ROOT)),'sha256':sha(archive),'compressed_bytes':archive.stat().st_size},'payload_files':len(rows),'payload_bytes':sum(r['bytes'] for r in rows),'selection_sha256':sha(OUT/'selection.json'),'originals_unchanged':True,'cache_traversal':False,'original_language_acquire_returncode':None,'full_m2_complete':False}
save(ROOT/'reports/m2/stage44-final-regression-captures.json',index);save(OUT/'report.json',index)
print(json.dumps(index,indent=2))
