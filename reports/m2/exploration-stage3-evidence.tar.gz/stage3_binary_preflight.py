from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import oracle
import m2_language as runner
import m2_manifest as contract

CASES = {'pipe-dynamic-rhs': 'result = 1 |> new Dynamic {}\n', 'pipe-class-rhs': 'class C { x = 1 }\nresult = 1 |> new C {}\n', 'constraint-inherited-fatal-frame': 'open class A { value: Int(1 ~/ 0 > 0) = 5 }\nclass B extends A { value = 6 }\nresult = (new B {}).value\n'}


output = ROOT / 'target/m2/stage3-binary-preflight-01'
output.mkdir(parents=True, exist_ok=False)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
(output / 'oracle.json').write_bytes(contract.encoded(metadata))
artifacts = output / 'artifacts'
classes = artifacts / 'java'
classes.mkdir(parents=True)
source = ROOT / 'tools/java/M2LanguageProbe.java'
(artifacts / source.name).write_bytes(source.read_bytes())
compiled = runner.capture([str(Path(metadata['java']).with_name('javac')), '-encoding', 'UTF-8', '-cp', metadata['artifact'], '-d', str(classes), str(source)], output, 'javac', metadata['environment'])
assert compiled['exit_code'] == 0
results=[]
for key,text in CASES.items():
 folder=output/'cases'/key
 folder.mkdir(parents=True)
 source=folder/'input.pkl'
 source.write_bytes(text.encode())
 enabled = False
 java=runner.capture_java(metadata,artifacts/'language_probe',key,source,'result',folder,enabled)
 results.append(dict(id=key,power_assertions=enabled,source_sha256=oracle.sha256(source),java=java))
 print(key,java['exit_code'],flush=True)
(output/'report.json').write_bytes(contract.encoded(dict(scope='Java-only diagnostic rendering specimens; no candidate compatibility claim',oracle=metadata,results=results)))
