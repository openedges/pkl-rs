from pathlib import Path
import json
ROOT = Path(__file__).resolve().parents[2]
selection = ROOT / 'tests/fixtures/m2/cases.json'
data = json.loads(selection.read_bytes())
assert len(data['cases']) == 191

def add(folder, key, enabled=False, name=None):
 identifier = name or key
 source = folder / 'cases' / key / 'input.pkl'
 process = json.loads((source.parent / 'java.process.json').read_bytes())
 outcome = (source.parent / 'java.outcome.bin').read_bytes()
 assert process['exit_code'] in (0, 1) and not process['timed_out']
 assert outcome == b'success\n' if process['exit_code'] == 0 else outcome == b'pkl-exception\torg.pkl.core.PklException\n'
 fixture = Path('tests/fixtures/m2') / (identifier + '.pkl')
 assert not (ROOT / fixture).exists()
 (ROOT / fixture).write_bytes(source.read_bytes())
 if identifier.startswith('pipe-'):
  requirements = ['semantic:operators', 'semantic:functions']
 elif key.startswith('alias-'):
  requirements = ['semantic:type-aliases', 'semantic:generics']
 else:
  requirements = ['semantic:constraints', 'semantic:types']
  if 'alias' in key: requirements.append('semantic:type-aliases')
  if any(word in key for word in ('scope', 'this', 'receiver', 'closure', 'nested-object')): requirements.append('semantic:name-resolution')
  if any(word in key for word in ('union', 'nullable')): requirements.append('semantic:unions')
  if any(word in key for word in ('-is-', '-as-')): requirements.append('semantic:type-tests-casts')
 if process['exit_code'] == 1: requirements.append('semantic:diagnostics')
 row = dict(id=identifier, input=str(fixture), expression='result', requirements=requirements,
            expected_outcome='success' if process['exit_code'] == 0 else 'failure')
 if enabled: row['power_assertions'] = True
 data['cases'].append(row)

first = ROOT / 'target/m2/stage3-preflight-01'
for row in json.loads((first / 'report.json').read_bytes())['results']:
 if row['id'] not in ('constraint-alias-lexical', 'constraint-this-nested'):
  add(first, row['id'])

power = ROOT / 'target/m2/stage3-preflight-power-01'
extra_plain = ['constraint-alias-scope', 'constraint-receiver-scope', 'constraint-nested-object-outer',
 'constraint-nested-object-this', 'constraint-alias-generic', 'constraint-union-both-false',
 'constraint-nested-constraint', 'constraint-function-closure', 'constraint-shortcircuit', 'constraint-alias-this-capture']
for key in extra_plain: add(power, key)
power_selected = ['constraint-false', 'constraint-compare-false', 'constraint-second-false', 'constraint-function-false',
 'constraint-unicode', 'constraint-multiline', 'constraint-power-and', 'constraint-power-nested', 'constraint-as-false',
 'constraint-union-both-false', 'constraint-nested-constraint', 'constraint-function-closure', 'constraint-shortcircuit', 'constraint-alias-scope']
for key in power_selected: add(power, key, True, 'power-' + key)
extra = ROOT / 'target/m2/stage3-preflight-extra-01'
for key in ['constraint-expression-multiline', 'constraint-expression-comment']:
 add(extra, key, True, 'power-' + key)
assert len(data['cases']) == 258
selection.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
print('selected', len(data['cases']))
