from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import oracle
import m2_language as runner
import m2_manifest as contract

output = ROOT / 'target/m2/stage3-object-method-java-01'
output.mkdir(parents=True, exist_ok=False)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
manifest = contract.current_manifest()
(output / 'oracle.json').write_bytes(contract.encoded(metadata))
(output / 'manifest.json').write_bytes(contract.encoded(manifest))
artifacts = output / 'artifacts'
classes = artifacts / 'java'
classes.mkdir(parents=True)
source = ROOT / 'tools/java/M2LanguageProbe.java'
(artifacts / source.name).write_bytes(source.read_bytes())
compiled = runner.capture([str(Path(metadata['java']).with_name('javac')), '-encoding', 'UTF-8', '-cp', metadata['artifact'], '-d', str(classes), str(source)], output, 'javac', metadata['environment'])
assert compiled['exit_code'] == 0
selected = [row for row in manifest['cases'] if row['id']=='error-object-nonlocal-method-frame']
def run(case):
 folder = output / 'cases' / case['id']
 folder.mkdir(parents=True)
 source = ROOT / case['input']
 (folder / 'input.pkl').write_bytes(source.read_bytes())
 process = runner.capture_java(metadata, artifacts / 'language_probe', case['id'], source, case['expression'], folder, case.get('power_assertions', False))
 outcome = (folder / 'java.outcome.bin').read_bytes()
 valid = not process['timed_out'] and process['exit_code'] == (0 if case['expected_outcome'] == 'success' else 1)
 valid = valid and (outcome == b'success\n' if process['exit_code'] == 0 else runner.valid_exception_outcome(outcome))
 print(case['id'], process['exit_code'], 'expected' if valid else 'UNEXPECTED', flush=True)
 return dict(id=case['id'], input=case['input'], input_sha256=oracle.sha256(source), expected_outcome_matches=valid, java=process)
with ThreadPoolExecutor(max_workers=3) as pool:
 results = list(pool.map(run, selected))
report = dict(scope='Exploratory pinned Java-only specimen capture; no Rust comparison or source-bound build claim',
 oracle=metadata, results=results, source_sha256={str(source.relative_to(ROOT)):oracle.sha256(source)},
 classes_sha256={str(path.relative_to(output)):oracle.sha256(path) for path in classes.rglob('*') if path.is_file()})
(output / 'report.json').write_bytes(contract.encoded(report))
assert all(row['expected_outcome_matches'] for row in results)
