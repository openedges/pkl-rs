from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import oracle
import m2_language as runner
import m2_manifest as contract

CASES = {
 'constraint-expression-multiline': 'result: Int(this +\n  1 > 100) = 42\n',
 'constraint-expression-comment': 'result: Int(this /* op */ > 42) = 42\n',
 'constraint-expression-two-lines': 'result: Int(this +\n  this > 100) = 42\n',
 'constraint-expression-shortcircuit-or': 'result: Int(this > 100 || this < 0) = 42\n',
 'constraint-function-body-multiline': 'positive = (x) -> x +\n  1 > 100\nresult: Int(positive) = 42\n',
 'constraint-union-fatal-before-fallback': 'result: Int(this ~/ 0 > 0) | Int = 42\n',
 'constraint-is-fatal-division': 'result = 42 is Int(this ~/ 0 > 0)\n',
 'constraint-function-typed-argument': 'predicate = (x: String) -> true\nresult: Int(predicate) = 42\n',
 'constraint-function-throws': 'predicate = (x) -> throw("predicate failed")\nresult: Int(predicate) = 42\n',
}
output = ROOT / 'target/m2/stage3-preflight-extra-01'
output.mkdir(parents=True, exist_ok=False)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
(output / 'oracle.json').write_bytes(contract.encoded(metadata))
artifacts = output / 'artifacts'
classes = artifacts / 'java'
classes.mkdir(parents=True)
source = ROOT / 'tools/java/M2LanguageProbe.java'
(artifacts / source.name).write_bytes(source.read_bytes())
compiled = runner.capture([str(Path(metadata['java']).with_name('javac')), '-encoding', 'UTF-8', '-cp', metadata['artifact'], '-d', str(classes), str(source)], output, 'javac', metadata['environment'])
assert compiled['exit_code'] == 0
results = []
for key, text in CASES.items():
 folder = output / 'cases' / key
 folder.mkdir(parents=True)
 source = folder / 'input.pkl'
 source.write_bytes(text.encode())
 result = runner.capture_java(metadata, artifacts / 'language_probe', key, source, 'result', folder, True)
 results.append(dict(id=key, source_sha256=oracle.sha256(source), power_assertions=True, java=result))
 print(key, result['exit_code'], (folder / 'java.stdout.bin').read_bytes(), flush=True)
(output / 'report.json').write_bytes(contract.encoded(dict(scope='Exploratory explicit power-assertion Java-only semantics; not compatibility evidence', oracle=metadata, results=results)))
