from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import oracle
import m2_language as runner
import m2_manifest as contract

CASES = {
 'pipe-basic': 'result = 7 |> ((x) -> x * 6)\n',
 'pipe-chain': 'double = (x) -> x * 2\nadd = (x) -> x + 1\nresult = 3 |> double |> add\n',
 'pipe-add-precedence': 'result = 1 + 2 |> ((x) -> x * 3)\n',
 'pipe-or-precedence': 'result = false || true |> ((x) -> !x)\n',
 'pipe-coalesce-precedence': 'result = null ?? 2 |> ((x) -> x + 1)\n',
 'pipe-coalesce-lazy': 'result = 42 ?? missing |> missingToo\n',
 'pipe-not-function': 'result = 1 |> 2\n',
 'pipe-null-function': 'result = 1 |> null\n',
 'pipe-zero-arity': 'result = 1 |> (() -> 42)\n',
 'pipe-two-arity': 'result = 1 |> ((x, y) -> x + y)\n',
 'pipe-parameter-type': 'result = 1 |> ((x: String) -> x)\n',
 'pipe-left-first': 'result = missingLeft |> missingRight\n',
 'pipe-right-before-arity': 'result = 1 |> (if (missing) (() -> 42) else (() -> 42))\n',
 'pipe-function-body-error': 'result = 1 |> ((x) -> x ~/ 0)\n',
 'constraint-true': 'result: Int(this > 0) = 42\n',
 'constraint-false': 'result: Int(false) = 42\n',
 'constraint-compare-false': 'result: Int(this > 42) = 42\n',
 'constraint-base-before-body': 'result: Int(missing) = "bad"\n',
 'constraint-first-before-second': 'result: Int(false, missing) = 42\n',
 'constraint-second-false': 'result: Int(true, this < 0) = 42\n',
 'constraint-nonbool': 'result: Int(1) = 42\n',
 'constraint-function-true': 'positive = (x) -> x > 0\nresult: Int(positive) = 42\n',
 'constraint-function-false': 'positive = (x) -> x > 0\nresult: Int(positive) = -1\n',
 'constraint-function-nonbool': 'result: Int((x) -> 1) = 42\n',
 'constraint-function-zero-arity': 'result: Int(() -> true) = 42\n',
 'constraint-function-two-arity': 'result: Int((x, y) -> true) = 42\n',
 'constraint-fatal-division': 'result: Int(this ~/ 0 == 1) = 42\n',
 'constraint-nullable-skip': 'result: Int(this > 0)? = null\n',
 'constraint-nullable-overall': 'result: (Int?)(this != null) = null\n',
 'constraint-union-fallback': 'result: Int(false) | Int = 42\n',
 'constraint-union-fatal': 'result: Int(1) | Int = 42\n',
 'constraint-is-false': 'result = 42 is Int(this > 50)\n',
 'constraint-is-fatal': 'result = 42 is Int(1)\n',
 'constraint-as-false': 'result = 42 as Int(this > 50)\n',
 'constraint-alias-lexical': 'const threshold = 10\ntypealias Small = Int(this < threshold)\nobj = new { threshold = 100; value: Small = 42 }\nresult = obj.value\n',
 'constraint-this-nested': 'result: Int((new { value = this }).value == 42) = 42\n',
 'constraint-this-closure': 'result: Int(((x) -> this == x).apply(42)) = 42\n',
 'constraint-let': 'result: Int(let (x = this) x > 0) = 42\n',
 'constraint-unicode': 'result: String(this == "😀é") = "😀x"\n',
 'constraint-multiline': 'result: Int(\n  this + 1 > 100\n) = 42\n',
 'constraint-power-and': 'result: Int(this > 0 && this < 10) = 42\n',
 'constraint-power-nested': 'result: Int((this + 1) * 2 == 100) = 42\n',
 'alias-nested-identity-type': 'typealias Identity<T> = T\nresult: Identity<Identity<Int>> = "bad"\n',
}

def main():
 output = ROOT / 'target/m2/stage3-preflight-01'
 output.mkdir(parents=True, exist_ok=False)
 metadata = oracle.ensure_oracle(ROOT, fetch=False)
 (output / 'oracle.json').write_bytes(contract.encoded(metadata))
 artifacts = output / 'artifacts'
 classes = artifacts / 'java'
 classes.mkdir(parents=True)
 source = ROOT / 'tools/java/M2LanguageProbe.java'
 (artifacts / source.name).write_bytes(source.read_bytes())
 javac = runner.capture([str(Path(metadata['java']).with_name('javac')), '-encoding', 'UTF-8', '-cp', metadata['artifact'], '-d', str(classes), str(source)], output, 'javac', metadata['environment'])
 assert javac['exit_code'] == 0
 results = []
 for identifier, text in CASES.items():
  folder = output / 'cases' / identifier
  folder.mkdir(parents=True)
  source = folder / 'input.pkl'
  source.write_bytes(text.encode())
  result = runner.capture_java(metadata, artifacts / 'language_probe', identifier, source, 'result', folder)
  results.append(dict(id=identifier, source_sha256=oracle.sha256(source), java=result))
  print(identifier, result['exit_code'], (folder / 'java.stdout.bin').read_bytes(), flush=True)
 (output / 'report.json').write_bytes(contract.encoded(dict(scope='Exploratory Java-only semantics; not compatibility evidence', oracle=metadata, results=results)))

if __name__ == '__main__': main()
