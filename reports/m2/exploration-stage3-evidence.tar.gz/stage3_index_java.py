from pathlib import Path
import hashlib
import json
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools'))
import m2_language as runner
import m2_manifest as contract

folders=[ROOT/'target/m2'/name for name in [
 'stage3-selected-java-01','stage3-generated-java-02','stage3-receiver-java-01',
 'stage3-selected-extra-java-01','stage3-surrogate-java-01','stage3-scope-java-01','stage3-object-method-java-01','stage3-binary-java-01']]
manifest=contract.current_manifest()
selected=[row for row in manifest['cases']if row.get('adapter')=='language-api-string'][191:]
results=[]
for case in selected:
 matches=[]
 for output in folders:
  folder=output/'cases'/case['id']
  if not folder.is_dir()or contract.digest((folder/'input.pkl').read_bytes())!=case['input_sha256']:continue
  process=json.loads((folder/'java.process.json').read_bytes())
  arguments=runner.expression_arguments(ROOT/case['input'],case['expression'],case.get('power_assertions',False))
  assert process['command'][-len(arguments):]==arguments
  assert not process['timed_out']and process['exit_code']==(0 if case['expected_outcome']=='success'else 1)
  raw={}
  for channel in ['stdout','stderr','outcome']:
   data=(folder/f'java.{channel}.bin').read_bytes()
   digest=contract.digest(data)
   assert digest==process[channel+'_sha256']
   raw[channel]=digest
  outcome=(folder/'java.outcome.bin').read_bytes()
  assert outcome==b'success\n'if process['exit_code']==0 else outcome==b'pkl-exception\torg.pkl.core.PklException\n'
  matches.append(dict(id=case['id'],input=case['input'],input_sha256=case['input_sha256'],
   power_assertions=case.get('power_assertions',False),specimen=str(folder.relative_to(ROOT)),
   exit_code=process['exit_code'],raw_sha256=raw,oracle_metadata_sha256=contract.digest((output/'oracle.json').read_bytes())))
 assert matches,case['id']
 results.append(matches[-1])
summary=dict(scope='Index of verified pinned Java-only raw specimens for newly selected stage3 inputs; Rust comparison and final source-bound acquisition pending',
 selected_count=len([row for row in manifest['cases']if row.get('adapter')=='language-api-string']),new_cases=len(results),
 manifest_sha256=contract.digest((ROOT/contract.MANIFEST).read_bytes()),results=results)
(ROOT/'target/m2/stage3-java-specimens.json').write_bytes(contract.encoded(summary))
print('Verified raw input/command/outcome/hash identities for',len(results),'new specimens')
