from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import oracle
import m2_language as runner
import m2_manifest as contract

CASES = {
 'string-control': 'result: String(false) = "\\u{0}\\u{1}\\t\\n\\r\\\"\\\\"\n',
 'string-control-power': 'result: String(this == "expected") = "\\u{0}\\t\\n\\r\\\"\\\\"\n',
 'typed-object-unforced-order': 'open class Base { z = 3; a = 1 }\nclass Child extends Base { m = 2 }\nresult: Child(false) = new Child { z = 4 }\n',
 'typed-object-cached-order': 'open class Base { z = 3; a = 1 }\nclass Child extends Base { m = 2 }\nresult: Child(this.a == 1 && false) = new Child { z = 4 }\n',
 'typed-object-cache-no-force': 'class C { first = 1; unused = 1 ~/ 0; last = 3 }\nresult: C(this.last == 3 && false) = new C {}\n',
 'constraint-grouped-this': 'result: Int((this) > 42) = 5\n',
 'constraint-grouped-name': 'local limit = 0\nresult: Int((limit) > this) = 5\n',
 'constraint-whole-group': 'result: Int(((this > 42))) = 5\n',
}
for length in [79, 80, 81, 99, 100, 101]:
 CASES['string-length-' + str(length)] = 'result: String(false) = "' + 'x' * length + '"\n'

output = ROOT / 'target/m2/stage3-renderer-preflight-01'
output.mkdir(parents=True, exist_ok=False)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
(output / 'oracle.json').write_bytes(contract.encoded(metadata))
artifacts = output / 'artifacts'
classes = artifacts / 'java'
classes.mkdir(parents=True)
source = ROOT / 'tools/java/M2LanguageProbe.java'
(artifacts / source.name).write_bytes(source.read_bytes())
compiled = runner.capture([str(Path(metadata['java']).with_name('javac')), '-encoding', 'UTF-8', '-cp', metadata['artifact'], '-d', str(classes), str(source)], output, 'javac', metadata['environment'])
assert compiled['exit_code'] == 0
results=[]
for key,text in CASES.items():
 folder=output/'cases'/key
 folder.mkdir(parents=True)
 source=folder/'input.pkl'
 source.write_bytes(text.encode())
 enabled = key.endswith('-power') or key.startswith('constraint-')
 java=runner.capture_java(metadata,artifacts/'language_probe',key,source,'result',folder,enabled)
 results.append(dict(id=key,power_assertions=enabled,source_sha256=oracle.sha256(source),java=java))
 print(key,java['exit_code'],flush=True)
(output/'report.json').write_bytes(contract.encoded(dict(scope='Java-only diagnostic rendering specimens; no candidate compatibility claim',oracle=metadata,results=results)))
