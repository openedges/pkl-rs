from pathlib import Path
import json
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import oracle
import m2_language as runner
import m2_manifest as contract
from stage3_preflight import CASES

POWER = ['constraint-false', 'constraint-compare-false', 'constraint-first-before-second',
 'constraint-second-false', 'constraint-function-false', 'constraint-unicode', 'constraint-multiline',
 'constraint-power-and', 'constraint-power-nested', 'constraint-is-false', 'constraint-as-false',
 'constraint-union-fallback', 'constraint-fatal-division']
EXTRA = {
 'constraint-alias-scope': 'const threshold = 10\ntypealias Small = Int(this < threshold)\nclass C { threshold = 100; value: Small = 42 }\nresult = (new C {}).value\n',
 'constraint-receiver-scope': 'class C { threshold = 100; value: Int(this < threshold) = 42 }\nresult = (new C {}).value\n',
 'constraint-nested-object-outer': 'class Box { value: Int }\nresult: Int(let (tested = this) (new Box { value = tested }).value == this) = 42\n',
 'constraint-nested-object-this': 'class Box { value: Int = 42 }\nresult: Int((new Box { value = this }).value == 42) = 42\n',
 'constraint-alias-generic': 'typealias Same<T> = T(this is T)\nresult: Same<Int> = 42\n',
 'constraint-union-both-false': 'result: Int(this > 50) | Int(this < 0) = 42\n',
 'constraint-nested-constraint': 'result: Int(this is Int(this > 50)) = 42\n',
 'constraint-function-closure': 'function greater(bound) = (x) -> x > bound\nresult: Int(greater(50)) = 42\n',
 'constraint-shortcircuit': 'result: Int(this > 100 && missing) = 42\n',
 'constraint-alias-this-capture': 'typealias Check = Int(((x) -> this == x).apply(42))\nresult: Check = 42\n',
 'constraint-plain-union-both-false': 'result: Int(this > 50) | Int(this < 0) = 42\n',
}

output = ROOT / 'target/m2/stage3-preflight-power-01'
output.mkdir(parents=True, exist_ok=False)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
(output / 'oracle.json').write_bytes(contract.encoded(metadata))
artifacts = output / 'artifacts'
classes = artifacts / 'java'
classes.mkdir(parents=True)
source = ROOT / 'tools/java/M2LanguageProbe.java'
(artifacts / source.name).write_bytes(source.read_bytes())
compiled = runner.capture([str(Path(metadata['java']).with_name('javac')), '-encoding', 'UTF-8', '-cp', metadata['artifact'], '-d', str(classes), str(source)], output, 'javac', metadata['environment'])
assert compiled['exit_code'] == 0
results = []
rows = [(key, CASES[key], True) for key in POWER] + [(key, text, not key.startswith('constraint-plain-')) for key, text in EXTRA.items()]
for key, text, enabled in rows:
 folder = output / 'cases' / key
 folder.mkdir(parents=True)
 source = folder / 'input.pkl'
 source.write_bytes(text.encode())
 result = runner.capture_java(metadata, artifacts / 'language_probe', key, source, 'result', folder, enabled)
 results.append(dict(id=key, source_sha256=oracle.sha256(source), power_assertions=enabled, java=result))
 print(key, result['exit_code'], (folder / 'java.stdout.bin').read_bytes(), flush=True)
(output / 'report.json').write_bytes(contract.encoded(dict(scope='Exploratory explicit power-assertion Java-only semantics; not compatibility evidence', oracle=metadata, results=results)))
