"""Capture required local Rust checks against one held source snapshot."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(sys.argv[1]).resolve()
OUT.mkdir(parents=True, exist_ok=False)
CACHE = ROOT / 'target/m2/stage40-required-cargo'


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def source_paths():
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--',
        'crates', 'xtask', 'tests/fixtures', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml',
        'references.lock', '.gitmodules'], cwd=ROOT).decode().split('\0')
    paths = {ROOT / name for name in names if name and (ROOT / name).is_file()}
    corpus = json.loads((ROOT / 'compatibility/corpus.json').read_bytes())
    registry = json.loads((ROOT / 'compatibility/m2-module-eval.json').read_bytes())
    selected = {row['id'] for row in registry['cases']}
    paths.update(ROOT / 'external/pkl' / row['source']['path'] for row in corpus['cases'] if row['id'] in selected)
    paths.update(ROOT / name for name in ['external/pkl/stdlib/base.pkl', 'external/pkl/stdlib/ref.pkl'])
    return sorted(paths)


before = {str(path.relative_to(ROOT)): digest(path) for path in source_paths()}
assert 'tests/fixtures/m2-pcf-string-output/cases.bin' in before
for name in before:
    destination = OUT / 'sources' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, destination)
(OUT / 'sources.json').write_text(json.dumps(before, indent=2) + '\n')
shutil.copyfile(__file__, OUT / 'run.py')
environment = dict(os.environ)
environment['CARGO_TARGET_DIR'] = str(CACHE)
commands = [
    ('rustc-version', ['rustc', '--version', '--verbose']),
    ('cargo-version', ['cargo', '--version']),
    ('host', ['uname', '-a']),
    ('references', ['cargo', 'xtask', 'verify']),
    ('format', ['cargo', 'fmt', '--all', '--', '--check']),
    ('clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('tests', ['cargo', 'test', '--workspace', '--locked']),
    ('wasm-check', ['cargo', 'check', '-p', 'pkl-runtime', '--target', 'wasm32-unknown-unknown', '--locked']),
]
rows = []
for name, command in commands:
    start = time.monotonic()
    with (OUT / (name + '.stdout')).open('wb') as stdout, (OUT / (name + '.stderr')).open('wb') as stderr:
        result = subprocess.run(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
    row = dict(name=name, command=command, cwd=str(ROOT), exit_code=result.returncode,
               elapsed_seconds=time.monotonic() - start, cargo_target_dir=str(CACHE))
    (OUT / (name + '.process.json')).write_text(json.dumps(row, indent=2) + '\n')
    rows.append(row)
    print(json.dumps(row), flush=True)
after = {str(path.relative_to(ROOT)): digest(path) for path in source_paths()}
changes = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
artifacts = {}
for match in re.finditer(r'Running .*\(([^)]+)\)', (OUT / 'tests.stderr').read_text()):
    path = Path(match[1])
    if not path.is_absolute():
        path = ROOT / path
    if path.is_file():
        artifacts[str(path)] = dict(sha256=digest(path), bytes=path.stat().st_size)
report = dict(scope='Required local macOS Rust checks; not complete language/platform/performance compatibility.',
              commands=rows, source_count=len(before), source_changes=changes,
              executed_test_artifacts=artifacts,
              environment_overrides={'CARGO_TARGET_DIR': str(CACHE)},
              compiler_environment={name: environment[name] for name in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
                  'RUSTC_WRAPPER', 'CARGO_BUILD_TARGET'] if name in environment})
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
raise SystemExit(any(row['exit_code'] for row in rows) or bool(changes))
