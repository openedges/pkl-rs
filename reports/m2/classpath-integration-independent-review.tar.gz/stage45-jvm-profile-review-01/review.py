"""Independent read-only review of the frozen classpath M2 integration."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
from unittest.mock import patch

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.classpath')
OUTPUT = Path(__file__).resolve().parent
FROZEN = ROOT / 'target/m2/classpath-m2-integration-captures-01'
PARENT = ROOT / 'target/m2/classpath-m2-integration-01'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'tools'))
import m2_language as language
import m2_jvm_classpath as jvm
import m2_manifest as manifest
import m2_source_inputs as catalog

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(name, obj):
    path = OUTPUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def git_bytes(path):
    return subprocess.check_output(['git', 'show', '43c97a4:' + path], cwd=ROOT)

def now():
    return datetime.now(timezone.utc).isoformat()

report = dict(schema=1, started_utc=now(), scope='Independent read-only frozen tooling review; no Rust changes, Git mutations, new builds, or reacquisition.',
              cwd=str(ROOT), host=platform.platform(), python=sys.version, commands=[], findings=[])
proposed = json.loads((FROZEN / 'proposed-manifest.json').read_bytes())
report['proposed_manifest_sha256'] = digest((FROZEN / 'proposed-manifest.json').read_bytes())
assert report['proposed_manifest_sha256'] == 'ba3631c1bce070485e497b7697c0b6003694683f5267297ff68b551c1facc365'
before = {}
for entry in proposed['files']:
    name = entry['path']
    data = (ROOT / name).read_bytes()
    assert digest(data) == entry['sha256']
    assert data == (FROZEN / 'proposed-sources' / name).read_bytes()
    destination = OUTPUT / 'sources' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    before[name] = digest(data)
    if entry['status'] != 'new':
        base = OUTPUT / 'baseline' / name
        base.parent.mkdir(parents=True, exist_ok=True)
        base.write_bytes(git_bytes(name))
write('source-before.json', before)
diff = subprocess.check_output(['git', 'diff', '43c97a4', '--', *before], cwd=ROOT)
(OUTPUT / 'tracked.diff').write_bytes(diff)
assert not any(name.endswith('.rs') for name in before)
current = json.loads((ROOT / 'compatibility/m2-language.json').read_bytes())
base = json.loads(git_bytes('compatibility/m2-language.json'))
assert [x['id'] for x in base['cases']] == [x['id'] for x in current['cases']]
assert len(current['cases']) == len({x['id'] for x in current['cases']}) == 4527
assert len(current['requirements']) == 475
changes = []
for old, new in zip(base['cases'], current['cases']):
    if old != new:
        changes.append(dict(id=new['id'], fields=sorted(k for k in set(old) | set(new) if old.get(k) != new.get(k))))
assert changes == [dict(id=jvm.CASE_ID, fields=['adapter', 'execution', 'execution_profile'])]
for name in ['compatibility/corpus.json', 'compatibility/m2-module-eval.json']:
    assert (ROOT / name).read_bytes() == git_bytes(name)
old_profile = json.loads(git_bytes(jvm.PROFILE))
profile = json.loads((ROOT / jvm.PROFILE).read_bytes())
assert [k for k in set(old_profile) | set(profile) if old_profile.get(k) != profile.get(k)] == ['scope']
selected = language.selected_cases(current)
row = next(x for x in current['cases'] if x['id'] == jvm.CASE_ID)
assert row['upstream_case']['execution']['status'] == 'blocked'
assert row['upstream_case']['expected_exit'] == [0]
assert row['input_sha256'] == digest((ROOT / row['input']).read_bytes())
assert len(selected) == 3664
assert [x['id'] for x in language.selected_cases(base)] == [x['id'] for x in selected]
report['manifest'] = dict(case_count=4527, requirements=475, selected=3664,
    selected_adapters=dict(Counter(x['adapter'] for x in selected)), changes=changes,
    all_case_and_selected_order_preserved=True, historical_corpus_and_cli_registry_unchanged=True,
    original_case_sha256=digest(manifest.encoded(row['upstream_case'])), original_input_sha256=row['input_sha256'],
    profile_only_scope_changed=True)

# Record verification commands without acquiring cases or compiling artifacts.
commands = [[sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', name, '-v']
            for name in ['test_m2_execution_profiles.py', 'test_m2_language.py', 'test_m2_jvm_classpath.py',
                         'test_m2_module_eval.py', 'test_m2_mappings.py']]
commands += [[sys.executable, '-B', 'tools/m2_manifest.py', '--check'],
             [sys.executable, '-B', 'tools/m2_jvm_classpath.py', '--check'],
             [sys.executable, '-B', 'tools/discover.py', '--check']]
commands += [[sys.executable, '-B', 'tools/m2_language.py', action, str(PARENT)]
             for action in ['--verify-report', '--verify-subset', '--verify-full']]
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
for index, command in enumerate(commands):
    start = now()
    result = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, timeout=180)
    expected = 1 if '--verify-full' in command else 0
    for name in ['stdout', 'stderr']:
        (OUTPUT / f'{index:02}.{name}.bin').write_bytes(getattr(result, name))
    capture = dict(command=command, cwd=str(ROOT), started_utc=start, finished_utc=now(),
                   exit_code=result.returncode, expected_exit=expected,
                   stdout_sha256=digest(result.stdout), stderr_sha256=digest(result.stderr))
    report['commands'].append(capture)
    write('partial-report.json', report)
    print(index, result.returncode, command[-2:], flush=True)
    assert result.returncode == expected

parent = json.loads((PARENT / 'report.json').read_bytes())
child = json.loads((PARENT / 'jvm-classpath/report.json').read_bytes())
assert parent['source_sha256'] == child['sources'] == child['sources_after']
assert parent['oracle'] == child['oracle']
assert parent['classpath_candidate']['source_binding'] == 'recorded-build'
assert child['candidate']['source_binding'] == 'unbound-caller-supplied'
assert (PARENT / 'artifacts/jvm_snippet_probe').read_bytes() == (PARENT / 'jvm-classpath/artifacts/jvm_snippet_probe').read_bytes()
assert [x['name'] for x in child['commands']] == ['javac']
assert not (PARENT / 'build').exists() and not (PARENT / 'jvm-classpath/build').exists()
assert len(parent['results']) == 1 and parent['results'][0]['id'] == jvm.CASE_ID
assert len(child['results']) == 2 and all(x['status'] == 'pass' for x in child['results'])
assert parent['full_gate_failures'] == manifest.full_gate_failures(current, parent['results'])
assert len(parent['full_gate_failures']) == 5476
assert 'required case incomplete: ' + jvm.CASE_ID not in parent['full_gate_failures']
write('full-gate-failures.json', parent['full_gate_failures'])
report['binding'] = dict(parent_report_sha256=digest((PARENT / 'report.json').read_bytes()),
    child_report_sha256=digest((PARENT / 'jvm-classpath/report.json').read_bytes()),
    parent_binding='recorded-build', child_binding='unbound-caller-supplied',
    parent_build_command=parent['classpath_candidate']['build']['command'],
    child_commands=['javac'], child_build_absent=True, same_artifact_bytes=True,
    candidate_sha256=parent['classpath_candidate']['sha256'], same_source_map=True,
    source_count=len(parent['source_sha256']), same_oracle=True,
    parent_inventory_count=len(parent['evidence_sha256']), repetitions=2,
    original_case_executions_counted=1, full_gate_failures=5476,
    remaining_selected_not_reacquired=3663)

# Confirm the actual traversal avoids the exact cache before any descent, while
# unrelated directories named build remain visible evidence.
real_scandir = os.scandir
cache_checks = []
with tempfile.TemporaryDirectory(dir=OUTPUT) as temporary:
    directory = Path(temporary)
    for relative in ['build', 'jvm-classpath/build']:
        cache = directory / relative
        cache.mkdir(parents=True)
        visited = []
        def scan(path):
            visited.append(Path(path))
            assert not Path(path).is_relative_to(cache)
            return real_scandir(path)
        with patch.object(os, 'scandir', side_effect=scan):
            try:
                list(language.evidence_paths(directory))
            except ValueError as error:
                assert 'Cargo build cache' in str(error)
            else:
                raise AssertionError('exact cache was not rejected')
        cache.rmdir()
        cache_checks.append(dict(path=relative, rejected=True, descended=False))
    unrelated = directory / 'unrelated/build'
    unrelated.mkdir(parents=True)
    (unrelated / 'raw.bin').write_bytes(b'raw evidence')
    assert unrelated / 'raw.bin' in list(language.evidence_paths(directory))
    cache = directory / 'build'
    cache.mkdir()
    visited = []
    with patch.object(os, 'scandir', side_effect=scan):
        observed = jvm.inventory(directory)
    assert 'unrelated/build/raw.bin' in observed
    assert not any(path.is_relative_to(cache) for path in visited)
report['cache_checks'] = dict(parent=cache_checks, unrelated_build_included=True,
                             standalone_exact_build_pruned_before_walk=True)
tree = ast.parse((ROOT / 'tools/m2_source_inputs.py').read_text())
imports = [node.module if isinstance(node, ast.ImportFrom) else alias.name
           for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom))
           for alias in (node.names if isinstance(node, ast.Import) else [None])]
assert imports == ['json', 'pathlib']
report['source_catalog'] = dict(imports=imports, runner_imports_absent=True,
                              entry_import_order_tests_passed=True)
report['findings'] = [dict(severity='follow-up', scope='Combined Stage45 tree only',
    detail='Stage45 adds compile-time include_str!(../stdlib/modules.txt). m1_platforms.py and the new m2_source_inputs.py both omit .txt payloads. Add crates/pkl-runtime/src/stdlib/modules.txt to their explicit required input sets after integration; do not broaden cache walking or relabel prior captures as containing it. The frozen 43c97a4 proposal has no such input, so this is not a defect in its own recorded acquisition.',
    verification='A collector regression should assert that exact path is returned and a payload mutation changes captured hash; missing explicit input should fail closed.')]
after = {name: digest((ROOT / name).read_bytes()) for name in before}
assert before == after
write('source-after.json', after)
report.update(source_stable=True, no_new_actionable_blocker_in_frozen_proposal=True,
              tests_rerun=75, unverified='No new Java/native acquisition; no execution of the remaining 3663 selected cases; no whole M2, release-platform, API or performance closure.',
              finished_utc=now())
write('report.json', report)
print('REVIEW COMPLETE', digest((OUTPUT / 'report.json').read_bytes()), flush=True)
