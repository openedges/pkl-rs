//! Resumable type checking uses the same bytecode frames, Host suspension, and heap.
use super::*;
use crate::diagnostic::{PowerAssertionValue, TypeDiagnostic, UnionTypeDiagnostic};

#[derive(Clone)]
pub(super) enum TypeDestination {
    Stack,
    Test,
    Return,
}

#[derive(Clone)]
struct Observation {
    value: Value,
    executions: usize,
}
type Trace = BTreeMap<Span, Observation>;

#[derive(Clone)]
enum Mismatch {
    Simple {
        span: Span,
        ty: TypeCheck,
        value: Value,
    },
    Constraint {
        span: Span,
        value: Value,
        body_span: Span,
        observations: Option<Trace>,
    },
    Union {
        span: Span,
        value: Value,
        children: Vec<(Span, Mismatch)>,
    },
}
impl Mismatch {
    fn diagnostic(
        &self,
        heap: &Heap,
        module: &str,
        indent: usize,
    ) -> Result<TypeDiagnostic, RuntimeError> {
        use crate::diagnostic_values::{render, type_name as actual_type};
        Ok(match self {
            Self::Simple { span, ty, value } => TypeDiagnostic::Simple { span: *span, message: type_error_at_width(ty, value, module, heap, 80usize.saturating_sub(indent))?.message },
            Self::Constraint { span, value, body_span, observations } => TypeDiagnostic::Constraint {
                span: *span, value: render(value, heap, module, 80usize.saturating_sub(indent))?, body_span: *body_span,
                observations: observations.as_ref().map(|trace| trace.iter().map(|(span, observation)| Ok(PowerAssertionValue {
                    span: *span, value: render(&observation.value, heap, module, 100)?, executions: observation.executions,
                    hidden: matches!(observation.value, Value::Function(_)),
                })).collect::<Result<Vec<_>, RuntimeError>>()).transpose()?,
            },
            Self::Union { span, value, children } => TypeDiagnostic::Union {
                span: *span, value: render(value, heap, module, 80usize.saturating_sub(indent))?, actual_type: actual_type(value, heap, module)?, is_null: matches!(value, Value::Null),
                children: children.iter().map(|(type_span, mismatch)| Ok(UnionTypeDiagnostic {
                    type_span: *type_span,
                    nontrivial: !matches!(mismatch, Mismatch::Simple { span, .. } if span == type_span),
                    diagnostic: Box::new(mismatch.diagnostic(heap, module, indent + 2)?),
                })).collect::<Result<Vec<_>, RuntimeError>>()?,
            },
        })
    }
    fn roots(&self, roots: &mut Vec<Value>) {
        match self {
            Self::Simple { value, .. } => roots.push(value.clone()),
            Self::Constraint {
                value,
                observations,
                ..
            } => {
                roots.push(value.clone());
                if let Some(trace) = observations {
                    roots.extend(trace.values().map(|observation| observation.value.clone()));
                }
            }
            Self::Union {
                value, children, ..
            } => {
                roots.push(value.clone());
                for (_, mismatch) in children {
                    mismatch.roots(roots);
                }
            }
        }
    }
}

#[derive(Clone)]
struct UnionState {
    types: Vec<TypeCheck>,
    spans: Vec<Span>,
    span: Span,
    index: usize,
    failures: Vec<(Span, Mismatch)>,
    parent_test: bool,
    replay: bool,
}
#[derive(Clone)]
enum Task {
    Check {
        ty: TypeCheck,
        span: Span,
    },
    RestoreEnvironment(Environment),
    AfterBase {
        constraints: Vec<ConstraintCode>,
    },
    Constraints {
        constraints: Vec<ConstraintCode>,
        index: usize,
    },
    ConstraintResult {
        constraints: Vec<ConstraintCode>,
        index: usize,
    },
    PredicateResult {
        constraints: Vec<ConstraintCode>,
        index: usize,
        body_span: Span,
        function: ObjectId,
    },
    TraceResult {
        span: Span,
        body_span: Span,
    },
    UnionResult(UnionState),
}

pub(super) struct TypeRun {
    value: Value,
    checked: Value,
    pub(super) environment: Environment,
    member: Arc<str>,
    tasks: Vec<Task>,
    outcome: Option<Result<Value, Mismatch>>,
    pub(super) returned: Option<Value>,
    destination: TypeDestination,
    frames: Vec<RuntimeFrame>,
    in_type_test: bool,
    tracker: Option<Trace>,
}
fn environment_roots(environment: &Environment, roots: &mut Vec<Value>) {
    roots.extend(environment.locals.iter().cloned());
    roots.extend(environment.this_value.iter().cloned());
    roots.extend(environment.outer_value.iter().cloned());
    roots.extend(environment.custom_this.iter().cloned());
    for scope in &environment.scopes {
        roots.extend([Value::Object(scope.receiver), Value::Object(scope.owner)]);
    }
}
impl TypeRun {
    /// Inherited annotation continuations have no authored Return instruction.
    /// Fatal child evaluation still needs the overriding property's value frame.
    pub(super) fn fatal_value_frames(&self) -> impl Iterator<Item = &RuntimeFrame> {
        self.frames.iter().skip(1)
    }
    pub(super) fn roots(&self, roots: &mut Vec<Value>) {
        roots.extend([self.value.clone(), self.checked.clone()]);
        roots.extend(self.returned.iter().cloned());
        environment_roots(&self.environment, roots);
        if let Some(trace) = &self.tracker {
            roots.extend(trace.values().map(|observation| observation.value.clone()));
        }
        if let Some(Err(mismatch)) = &self.outcome {
            mismatch.roots(roots);
        }
        for task in &self.tasks {
            match task {
                Task::UnionResult(state) => {
                    for (_, mismatch) in &state.failures {
                        mismatch.roots(roots);
                    }
                }
                Task::RestoreEnvironment(environment) => environment_roots(environment, roots),
                Task::PredicateResult { function, .. } => roots.push(Value::Function(*function)),
                _ => {}
            }
        }
    }
    fn mismatch(&mut self, span: Span, body_span: Span) {
        self.outcome = Some(Err(Mismatch::Constraint {
            span,
            value: self.value.clone(),
            body_span,
            observations: self.tracker.take(),
        }));
    }
}
fn module_environment(environment: &Environment) -> Result<Environment, RuntimeError> {
    let mut result = environment.clone();
    let scope = *result
        .scopes
        .last()
        .ok_or_else(|| invalid("missing alias module"))?;
    result.scopes = vec![scope];
    // TypeAliasTypeNode swaps receiver and owner in the original frame, preserving locals.
    result.this_value = Some(Value::Object(scope.receiver));
    result.outer_value = None;
    Ok(result)
}

impl Vm {
    pub(super) fn observe(&mut self, span: Span, value: Value) {
        for frame in &mut self.frames {
            if let Some(run) = &mut frame.type_run
                && let Some(trace) = &mut run.tracker
            {
                trace
                    .entry(span)
                    .and_modify(|observation| {
                        observation.executions += 1;
                        observation.value = value.clone();
                    })
                    .or_insert_with(|| Observation {
                        value: value.clone(),
                        executions: 1,
                    });
            }
        }
    }
    fn active_tracker(&self) -> bool {
        self.frames.iter().any(|frame| {
            frame
                .type_run
                .as_ref()
                .is_some_and(|run| run.tracker.is_some())
        })
    }
    pub(super) fn begin_type(
        &mut self,
        ty: TypeCheck,
        value: Value,
        destination: TypeDestination,
        frames: Vec<RuntimeFrame>,
    ) -> Result<(), RuntimeError> {
        let in_type_test = matches!(destination, TypeDestination::Test)
            || self
                .frames
                .iter()
                .rev()
                .find_map(|frame| frame.type_run.as_ref())
                .is_some_and(|run| run.in_type_test);
        let frame = self
            .frames
            .last_mut()
            .ok_or_else(|| invalid("missing type-check frame"))?;
        let metadata = self.program.metadata.get(frame.block);
        let span = frames
            .first()
            .map(|frame| frame.span)
            .or_else(|| {
                metadata
                    .and_then(|metadata| metadata.spans.get(frame.pc.saturating_sub(1)))
                    .copied()
                    .flatten()
            })
            .unwrap_or(Span::new(0, 0));
        let member = frames
            .first()
            .map(|frame| frame.member.clone())
            .or_else(|| frame.diagnostic_member.clone())
            .or_else(|| metadata.map(|metadata| metadata.member.clone()))
            .unwrap_or_else(|| Arc::from(""));
        frame.type_run = Some(TypeRun {
            value: value.clone(),
            checked: value,
            environment: frame.environment.clone(),
            member,
            tasks: vec![Task::Check { ty, span }],
            outcome: None,
            returned: None,
            destination,
            frames,
            in_type_test,
            tracker: None,
        });
        Ok(())
    }
    fn launch_constraint(
        &mut self,
        run: TypeRun,
        constraint: ConstraintCode,
    ) -> Result<(), RuntimeError> {
        let mut environment = if constraint.module_environment {
            module_environment(&run.environment)?
        } else {
            run.environment.clone()
        };
        environment.custom_this = Some(run.value.clone());
        let member = run.member.clone();
        self.frames.last_mut().expect("type frame").type_run = Some(run);
        self.frames.last_mut().expect("type frame").callsite_hidden = true;
        self.frames.push(Frame {
            block: constraint.block,
            pc: 0,
            base: self.stack.len(),
            environment,
            force: None,
            lambda: false,
            type_run: None,
            return_to_type: true,
            diagnostic_member: Some(member),
            callsite_hidden: false,
        });
        Ok(())
    }
    fn launch_predicate(&mut self, run: TypeRun, function: ObjectId) -> Result<(), RuntimeError> {
        let argument = run.value.clone();
        self.frames.last_mut().expect("type frame").type_run = Some(run);
        self.frames.last_mut().expect("type frame").callsite_hidden = true;
        self.invoke_function(function, vec![argument], false)?;
        self.frames
            .last_mut()
            .expect("predicate frame")
            .return_to_type = true;
        Ok(())
    }
    pub(super) fn step_type(&mut self) -> Result<(), RuntimeError> {
        let mut run = self
            .frames
            .last_mut()
            .expect("type frame")
            .type_run
            .take()
            .expect("type run");
        let should_trace = self.power_assertions
            && (!run.in_type_test || self.active_tracker() || run.tracker.is_some());
        let Some(task) = run.tasks.pop() else {
            let outcome = run
                .outcome
                .take()
                .ok_or_else(|| invalid("missing type result"))?;
            match (outcome, run.destination) {
                (Ok(_), TypeDestination::Test) => self.stack.push(Value::Bool(true)),
                (Err(_), TypeDestination::Test) => self.stack.push(Value::Bool(false)),
                (Ok(value), TypeDestination::Stack) => self.stack.push(value),
                (Ok(value), TypeDestination::Return) => {
                    self.stack.push(value);
                    self.frames.last_mut().expect("type frame").pc -= 1;
                }
                (Err(mismatch), _) => {
                    let diagnostic =
                        mismatch.diagnostic(&self.heap, &self.program.module_name, 0)?;
                    let mut error = RuntimeError::new(
                        ErrorKind::Type,
                        match &diagnostic {
                            TypeDiagnostic::Simple { message, .. } => message.as_str(),
                            _ => "Type constraint violated.",
                        },
                    );
                    error.span = Some(diagnostic.span());
                    error.frames = run.frames;
                    if let Some(frame) = error.frames.first_mut() {
                        frame.span = diagnostic.span();
                    }
                    error.type_diagnostic = Some(Box::new(diagnostic));
                    return Err(error);
                }
            }
            return Ok(());
        };
        match task {
            Task::Check { ty, span } => match ty {
                TypeCheck::Alias(inner) => {
                    let environment = module_environment(&run.environment)?;
                    run.tasks.push(Task::RestoreEnvironment(std::mem::replace(
                        &mut run.environment,
                        environment,
                    )));
                    run.tasks.push(Task::Check { ty: *inner, span });
                }
                TypeCheck::Nullable(inner) if !matches!(run.value, Value::Null) => {
                    run.tasks.push(Task::Check { ty: *inner, span })
                }
                TypeCheck::Union { types, spans, .. } if !types.is_empty() => {
                    let parent_test = run.in_type_test;
                    run.in_type_test = true;
                    run.tasks.push(Task::UnionResult(UnionState {
                        types: types.clone(),
                        spans: spans.clone(),
                        span,
                        index: 0,
                        failures: Vec::new(),
                        parent_test,
                        replay: false,
                    }));
                    run.tasks.push(Task::Check {
                        ty: types[0].clone(),
                        span: spans[0],
                    });
                }
                TypeCheck::Constrained {
                    base,
                    base_span,
                    constraints,
                } => {
                    run.tasks.push(Task::AfterBase { constraints });
                    run.tasks.push(Task::Check {
                        ty: *base,
                        span: base_span,
                    });
                }
                ty => {
                    run.outcome = Some(if ty.accepts(&run.value, &self.heap) {
                        Ok(run.value.clone())
                    } else {
                        Err(Mismatch::Simple {
                            span,
                            ty,
                            value: run.value.clone(),
                        })
                    });
                }
            },
            Task::RestoreEnvironment(environment) => run.environment = environment,
            Task::AfterBase { constraints } => {
                if let Some(Ok(value)) = &run.outcome {
                    run.checked = value.clone();
                    run.tasks.push(Task::Constraints {
                        constraints,
                        index: 0,
                    });
                }
            }
            Task::Constraints { constraints, index } => {
                if index == constraints.len() {
                    run.outcome = Some(Ok(run.checked.clone()));
                } else {
                    let constraint = constraints[index].clone();
                    run.tasks
                        .push(Task::ConstraintResult { constraints, index });
                    return self.launch_constraint(run, constraint);
                }
            }
            Task::ConstraintResult { constraints, index } => {
                self.frames.last_mut().expect("type frame").callsite_hidden = false;
                let result = run
                    .returned
                    .take()
                    .ok_or_else(|| invalid("missing constraint return"))?;
                let constraint = constraints[index].clone();
                match result {
                    Value::Bool(true) => run.tasks.push(Task::Constraints { constraints, index: index+1 }),
                    Value::Bool(false) if should_trace => {
                        run.tracker = Some(BTreeMap::new());
                        run.tasks.push(Task::TraceResult { span: constraint.span, body_span: constraint.span });
                        return self.launch_constraint(run, constraint);
                    }
                    Value::Bool(false) => run.mismatch(constraint.span, constraint.span),
                    Value::Function(function) => {
                        let body_span = self.heap.get(function)?.function.as_ref().and_then(|function| self.program.metadata.get(function.block)).and_then(|metadata| metadata.declaration.or(metadata.value_span)).unwrap_or(constraint.span);
                        run.tasks.push(Task::PredicateResult { constraints, index, body_span, function });
                        return self.launch_predicate(run, function);
                    }
                    Value::Null => return Err(RuntimeError::new(ErrorKind::Type, "Expected value of type `Boolean` or `Function`, but got `null`.").at(constraint.span)),
                    value => return Err(RuntimeError::new(ErrorKind::Type, format!("Expected value of type `Boolean` or `Function`, but got type `{}`.\nValue: {}", crate::diagnostic_values::type_name(&value, &self.heap, &self.program.module_name)?, crate::diagnostic_values::render(&value, &self.heap, &self.program.module_name, 80)?)).at(constraint.span)),
                }
            }
            Task::PredicateResult {
                constraints,
                index,
                body_span,
                function,
            } => {
                let result = run
                    .returned
                    .take()
                    .ok_or_else(|| invalid("missing predicate return"))?;
                match result {
                    Value::Bool(true) => {
                        self.frames.last_mut().expect("type frame").callsite_hidden = false;
                        run.tasks.push(Task::Constraints {
                            constraints,
                            index: index + 1,
                        });
                    }
                    Value::Bool(false) if should_trace => {
                        run.tracker = Some(BTreeMap::new());
                        run.tasks.push(Task::TraceResult {
                            span: constraints[index].span,
                            body_span,
                        });
                        return self.launch_predicate(run, function);
                    }
                    Value::Bool(false) => {
                        self.frames.last_mut().expect("type frame").callsite_hidden = false;
                        run.mismatch(constraints[index].span, body_span);
                    }
                    value => {
                        return Err(type_error(
                            &TypeCheck::Boolean,
                            &value,
                            &self.program.module_name,
                            &self.heap,
                        )?);
                    }
                }
            }
            Task::TraceResult { span, body_span } => {
                self.frames.last_mut().expect("type frame").callsite_hidden = false;
                run.returned
                    .take()
                    .ok_or_else(|| invalid("missing trace result"))?;
                run.mismatch(span, body_span);
            }
            Task::UnionResult(mut state) => {
                let outcome = run
                    .outcome
                    .take()
                    .ok_or_else(|| invalid("missing union alternative result"))?;
                if outcome.is_ok() && !state.replay {
                    run.in_type_test = state.parent_test;
                    run.outcome = Some(outcome);
                } else {
                    if let Err(mismatch) = outcome {
                        if state.replay {
                            state.failures[state.index] = (state.spans[state.index], mismatch);
                        } else {
                            state.failures.push((state.spans[state.index], mismatch));
                        }
                    }
                    state.index += 1;
                    if state.index == state.types.len() {
                        run.in_type_test = state.parent_test;
                        if !state.replay
                            && self.power_assertions
                            && (!state.parent_test
                                || self.active_tracker()
                                || run.tracker.is_some())
                        {
                            state.index = 0;
                            state.replay = true;
                        } else {
                            run.outcome = Some(Err(Mismatch::Union {
                                span: state.span,
                                value: run.value.clone(),
                                children: state.failures,
                            }));
                            self.frames.last_mut().expect("type frame").type_run = Some(run);
                            return Ok(());
                        }
                    }
                    let ty = state.types[state.index].clone();
                    let span = state.spans[state.index];
                    run.tasks.push(Task::UnionResult(state));
                    run.tasks.push(Task::Check { ty, span });
                }
            }
        }
        self.frames.last_mut().expect("type frame").type_run = Some(run);
        Ok(())
    }
}
