from pathlib import Path
import json,hashlib,collections
R=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage50');O=Path(__file__).resolve().parent;C=R/'target/m2/stage50-platform-control-01';I=R/'target/m2/stage50-platform-integration-01';seen={}
def read(p):
 p=Path(p);b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert str(p)not in seen or seen[str(p)]==h;seen[str(p)]=h;return b
def load(p):return json.loads(read(p))
def checked(p,h):assert hashlib.sha256(read(p)).hexdigest()==h
integration=load(I/'report.json');control=load(C/'report.json');primitive=load(C/'primitives/report.json');receipt=load(I/'root-terminal-receipt.json');assert receipt['exitCode']==0 and receipt['sessionId']==78695 and receipt['reportSha256']==hashlib.sha256(read(I/'report.json')).hexdigest()
expected_exits={'modulekey-public':1,'modulekey-provided-primary':1,'modulekey-extended':1,'renderer':0,'resource':0,'module-preparation':0,'moduleinfo':0,'security-denial':0,'guest-catch':0,'module-loader':1,'module-inheritance':1};assert len(integration['commands'])==11
matrix={}
for cmd in integration['commands']:
 label=cmd['label'];assert cmd['exitCode']==expected_exits[label];execution=load(I/label/'execution.json');assert execution['targets']['node']['complete']and execution['targets']['browser']['complete']
 checked(I/(label+'.stdout.bin'),cmd['stdoutSha256']);checked(I/(label+'.stderr.bin'),cmd['stderrSha256']);assert load(I/(label+'.terminal.json'))==cmd
 assert cmd['argv'][0]==integration['environment']['nodePath'];assert execution['browserLaunchOptions']['executablePath']==execution['browserExecutable'];assert not execution['infrastructureErrors']and not execution['browserErrors']and not execution['changedInputs']
 targets={}
 for t in ['node','browser']:
  target=execution['targets'][t];rows=load(I/label/(t+'.raw.json'));counts=collections.Counter();requests=0
  for row in rows:
   assert row.get('acquisitionError')is None
   calls=row.get('calls',row.get('results',[]));counts['calls']+=len(calls)
   for call in calls:
    status=call.get('status',call.get('kind'));disposition=call.get('disposition');counts[str(status)+':'+str(disposition)]+=1
    if label in ['modulekey-public','modulekey-provided-primary','modulekey-extended','renderer','resource','module-preparation']:
     assert status=='success'and disposition is None or status=='error'and disposition in ['language-error','unsupported','limit-exceeded','internal-failure']
   requests+=len(row.get('requests',row.get('moduleRequests',[])))
  targets[t]={'sessions':len(rows),'actualCallClassificationCounts':dict(counts),'actualModuleRequests':requests,'recordedCounts':target.get('statusCounts',target.get('counts',target.get('rawApiCounts')))}
  if label=='modulekey-extended':
   targets[t].update({k:target[k]for k in ['actualApiCalls','rawByteMatches','rawByteMismatchOrMissing','intendedOrdinaryCompatible','diagnosticOnlyRawMatched','internalBoundaryRawMatched','internalBoundaryCount','acquisitionIntegrityPassed','observationIntegrityPassed']});assert target['rawByteMatches']==936 and target['intendedOrdinaryCompatible']==836 and target['diagnosticOnlyRawMatched']==100 and target['internalBoundaryCount']==8 and target['internalBoundaryRawMatched']==0 and target['acquisitionIntegrityPassed']and target['observationIntegrityPassed']
  if label.startswith('modulekey-'):assert not target['fullLifecyclePassed']
 matrix[label]={'strictProcessExitCode':cmd['exitCode'],'scope':execution['scope'],'targets':targets,'explicitFalseGates':{k:v for k,v in execution.items()if v is False and ('Passed'in k or'Complete'in k)}}
# Exact pinned JVM/oracle identities and every actually recorded M1 command outcome.
oracle=load(C/'primitives/oracle-native/report.json');proof=oracle['oracle'];assert proof['version']=='0.32.0'and proof['source']['revision']=='e51fb2f91774265666f94980ec630db794a4db2d';checked(proof['artifact'],proof['artifact_sha256']);checked(proof['java'],proof['jdk']['executable_sha256']);home=Path(proof['jdk']['properties']['java.home']);checked(home/'lib/modules',proof['jdk']['runtime_modules_sha256']);checked(home/'release',proof['jdk']['release_sha256']);checked(R/'oracle.lock.json',proof['lock_sha256'])
for who,row in oracle['records'].items():
 assert row['exit_code']==0
 for ch in ['stdout','stderr']:checked(C/'primitives/oracle-native'/(who+'.'+ch+'.bin'),row[ch+'_sha256'])
checked(oracle['candidate']['path'],oracle['candidate']['sha256']);assert oracle['candidate']['sha256']==primitive['artifacts']['semantics_probe'];commands=load(C/'primitives/commands.json')
for command in commands:
 assert command['exit_code']==(1 if command['name']=='oracle-native'else 0)
 for ch in ['stdout','stderr']:read(C/'primitives'/(command['name']+'.'+ch+'.bin'))
 if command['name']in ['bindgen-version','wasm-bindgen']:checked(command['command'][0],primitive['wasm_bindgen_sha256'])
assert primitive['execution']==load(C/'primitives/execution/execution.json');assert not primitive['execution']['browserErrors'];assert load(C/'primitives/execution/browser-launch.json')=={k:primitive['execution'][k]for k in ['browserExecutable','browserExecutableSha256','browserLaunchOptions']}
for name in ['node-checks.json','browser-checks.json','node-legacy-utf8-observations.json','browser-legacy-utf8-observations.json']:read(C/'primitives/execution'/name)
for p,h in list(seen.items()):checked(p,h)
(O/'metadata-readback.json').write_text(json.dumps({'matrix':matrix,'m1RecordedCommands':commands,'oracleVersion':proof['version'],'oracleSourceRevision':proof['source']['revision'],'jdkProperties':proof['jdk']['properties'],'m1NodeIdentityQualification':'Parent measured NodePath/hash and reports unchanged runtime. M1 platforms command itself uses PATH node; child records process.version/versions, not process.execPath/hash. Exact child binary path is inferred, not directly captured. Eleven integration drivers invoke absolute bound NodePath.','browserQualification':'Explicit actual launch executablePath/hash for M1 and all11 drivers; browser OS PID not recorded.','bindgenQualification':'Actual M1 command resolves to MAIN tool cache binary; its bytes match declared pinned bindgen hash also available through Stage50 path.','checkedHashes':seen,'originalChanges':[]},indent=2)+'\n');print(json.dumps({'driverGroups':len(matrix),'checkedExtraFiles':len(seen),'originalChanges':[]}))
