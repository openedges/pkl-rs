from pathlib import Path
import hashlib,json,platform,subprocess,time
root=Path.cwd();out=root/'target/m2/stage50-required-rust-01'; release=root/'target/m2/stage50-storage-build01'
def save(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
def snapshot():
    names=set(json.loads((release/'sources-before.json').read_text()))
    names.update(str(p.relative_to(root)) for p in (root/'tests').rglob('*') if p.is_file())
    names.update(str(p.relative_to(root)) for p in (root/'crates').rglob('*') if p.is_file())
    return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in sorted(names)}
assert not (out/'report.json').exists(), 'Preserve previous validation'
assert json.loads((release/'build.json').read_text())['status']=='CLOSED'
before=snapshot();save('inputs-before.json',before)
commands=[['cargo','xtask','verify'],['cargo','fmt','--all','--','--check'],['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],['cargo','test','--workspace','--locked'],['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked']]
rows=[]
for i,command in enumerate(commands):
    start=time.time()
    with (out/f'check-{i}.stdout').open('wb') as stdout,(out/f'check-{i}.stderr').open('wb') as stderr:
        process=subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr)
        save('running.json',{'index':i,'command':command,'pid':process.pid,'startedUnix':start})
        result=process.wait()
    rows.append({'index':i,'command':command,'pid':process.pid,'exitCode':result,'elapsedSeconds':time.time()-start})
    save('checks.json',rows); print(json.dumps(rows[-1]),flush=True)
after=snapshot();save('inputs-after.json',after)
report={'checks':rows,'sourceStable':before==after,'sourceCount':len(before),'host':platform.platform(),'rustc':subprocess.check_output(['rustc','-Vv'],text=True),'releaseManifest':str(release/'build.json'),'releaseManifestSha256':hashlib.sha256((release/'build.json').read_bytes()).hexdigest(),'status':'PASS' if before==after and all(r['exitCode']==0 for r in rows) else 'FAIL'}
save('report.json',report);print(json.dumps(report,indent=2));raise SystemExit(0 if report['status']=='PASS' else 1)
