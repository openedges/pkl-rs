from pathlib import Path
import os,stat,tarfile,json,hashlib,subprocess,re,collections
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).parent;BASE=ROOT/'target/m2'
def h(data):return hashlib.sha256(data).hexdigest()
def sha(p):return h(p.read_bytes())
def load(p):return json.loads(p.read_bytes())
def enc(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def ref(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def git(*args,cwd=ROOT,data=None):return subprocess.check_output(['git',*args],cwd=cwd,input=data)
summary=load(ROOT/'reports/m2/stage39-implementation-checkpoint.json')
binding=load(ROOT/'reports/m2/stage39-implementation-source-binding.json')
checks=load(ROOT/'target/m2/stage39-checks-final-02/report.json')
assert summary['compatibility_complete'] is False and summary['performance_target_claimed'] is False
assert summary['source_tree']==binding['source_tree']
assert summary['rust_count_is_distinct_test_count'] is False
assert checks['passed'] and checks['source_stability'] and checks['source_changes']==[]
for field in ['source_binding','checks','prior_unchanged_tooling_checks','corrected_manifest_and_focused_tool_checks','corrected_native_controls','completed_corrected_standard_platform_acquisition']:
 row=summary[field];assert sha(ROOT/row['path'])==row['sha256'],field
 if 'bytes' in row:assert (ROOT/row['path']).stat().st_size==row['bytes']
for row in summary['archives']:assert sha(ROOT/row['path'])==row['sha256'] and (ROOT/row['path']).stat().st_size==row['bytes']
manifest=load(ROOT/'compatibility/m2-language.json');assert summary['inventory_counts']==manifest['counts']
assert manifest['counts']['cases_by_execution']=={'ready':3599,'unimplemented':888,'unmapped':40}
rust=(ROOT/'target/m2/stage39-checks-final-02/rust-tests.stdout.bin').read_text()
passed=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',rust)))
ignored=sum(map(int,re.findall(r'test result: ok\. \d+ passed; \d+ failed; (\d+) ignored;',rust)))
assert (passed,ignored)==(summary['rust_harness_pass_invocations'],summary['rust_ignored_invocations'])==(575,1)
# Resolve the exact existing source-tree object, never write/change Git/index.
entries={}
for raw in git('ls-tree','-rz','--full-tree',binding['source_tree']).split(b'\0'):
 if raw:
  header,name=raw.split(b'\t',1);mode,kind,oid=header.decode().split();entries[name.decode()]={'mode':mode,'kind':kind,'oid':oid}
assert binding['source_files']==len(binding['sources'])==len(checks['source_sha256'])
assert set(binding['sources'])==set(checks['source_sha256'])
requests={'root':[],'external/pkl':[]}
for name,digest in checks['source_sha256'].items():
 b=binding['sources'][name];assert b['sha256']==digest
 assert sha(ROOT/'target/m2/stage39-checks-final-02/sources'/name)==digest
 assert sha(ROOT/name)==digest,name
 if name.startswith('external/pkl/'):
  repo='external/pkl';query=entries[repo]['oid']+':'+name[len(repo)+1:]
 else:
  repo='root';assert entries[name]['kind']=='blob';query=entries[name]['oid'];assert b['git_blob']==query
 assert b['repository']==repo
 requests[repo].append((name,query))
for repo,items in requests.items():
 cwd=ROOT if repo=='root' else ROOT/repo
 raw=git('cat-file','--batch',cwd=cwd,data=('\n'.join(q for _,q in items)+'\n').encode());pos=0
 for name,query in items:
  end=raw.index(b'\n',pos);oid,kind,size=raw[pos:end].decode().split();size=int(size)
  assert kind=='blob' and oid==binding['sources'][name]['git_blob'],name
  data=raw[end+1:end+1+size];assert len(data)==size and raw[end+1+size:end+2+size]==b'\n'
  assert h(data)==checks['source_sha256'][name],name;pos=end+2+size
 assert pos==len(raw)
for name,oid in binding['submodules'].items():assert entries[name]['oid']==oid and entries[name]['kind']=='commit'
registry=load(ROOT/'compatibility/m2-module-eval.json');corpus=load(ROOT/'compatibility/corpus.json');originals={r['id']:r for r in corpus['cases']}
for item in registry['cases']:
 name='external/pkl/'+originals[item['id']]['source']['path']
 assert name in binding['sources'] and binding['sources'][name]['sha256']==item['input_sha256']
assert len(registry['cases'])==72
print('git/source binding verified',len(binding['sources']),'including72original inputs',flush=True)
# Six independently immutable archives, exact membership + every byte + mode + closed origins.
oracle=load(ROOT/'reports/m2/stage39-oracle-captures.json')
checkpoint=load(ROOT/'reports/m2/stage39-checkpoint-captures.json')
archives=[('oracle',oracle)]
archives += [(k,v) for k,v in checkpoint['archives'].items()]
archives += [(k,load(ROOT/f'reports/m2/stage39-{k}-captures.json')) for k in ['interrupted','correction']]
archive_results=[]
for label,descriptor in archives:
 path=Path(descriptor.get('path',descriptor.get('archive')));path=path if path.is_absolute() else ROOT/path
 assert sha(path)==descriptor.get('sha256',descriptor.get('archive_sha256'))
 assert path.stat().st_size==descriptor.get('bytes',descriptor.get('archive_bytes'))
 inventory_name='inventory.json' if label=='oracle' else 'archive-inventory.json'
 with tarfile.open(path,'r:gz') as tar:
  members=tar.getmembers();names=[m.name for m in members]
  assert len(names)==len(set(names))
  payload=tar.extractfile(inventory_name).read();assert h(payload)==descriptor['inventory_sha256']
  inv=json.loads(payload);listed=inv['files']
  files={r['path']:r for r in listed} if isinstance(listed,list) else listed
  assert len(files)==len(listed)==descriptor['original_files']
  assert set(names)==set(files)|{inventory_name}
  assert all(m.isfile() for m in members)
  for member in members:
   if member.name==inventory_name:continue
   data=tar.extractfile(member).read();item=files[member.name]
   assert len(data)==item['bytes'] and h(data)==item['sha256'],member.name
   if 'mode' in item:assert member.mode==item['mode'],member.name
  # Reconstruct exact intended origin membership with excluded caches pruned before walk.
  if label=='oracle':
   expected={}
   for group in descriptor['roots']:
    origin=Path(group['path']);subset={}
    for directory,children,filenames in os.walk(origin,topdown=True,followlinks=False):
     for n in filenames:
      p=Path(directory)/n;assert p.is_file() and not p.is_symlink();subset[group['archive_prefix']+'/'+p.relative_to(origin).as_posix()]=p
    assert len(subset)==group['files'];expected.update(subset)
   for key in ['seal.py','input-source-binding.json','gitlink.stdout.bin','input-tree.stdout.bin']:
    expected['stage39-oracle-seal-01/'+key]=BASE/'stage39-oracle-seal-01'/key
   exclusions=[]
  else:
   if label in ['interrupted','correction']:
    plan=json.loads(tar.extractfile('_preservation/plan.json').read());roots=plan['roots'];exclusions=plan.get('excluded_cargo_paths',[])
   else:roots=inv['roots'];exclusions=inv['exclusions']
   excluded={BASE/n for n in exclusions};expected={}
   for name in roots:
    for directory,children,filenames in os.walk(BASE/name,topdown=True,followlinks=False):
     children[:]=sorted(n for n in children if Path(directory)/n not in excluded)
     assert all(not (Path(directory)/n).is_symlink() for n in children)
     for n in filenames:
      p=Path(directory)/n;assert p.is_file() and not p.is_symlink();key=p.relative_to(BASE).as_posix();assert key not in expected;expected[key]=p
   if label=='development':expected['stage39-checkpoint-seal-01/seal.py']=BASE/'stage39-checkpoint-seal-01/seal.py'
   if label in ['interrupted','correction']:
    expected['_preservation/archive.py']=BASE/'stage39-supplement-seal-01/archive.py'
    expected['_preservation/plan.json']=BASE/'stage39-supplement-seal-01'/('partial-plan.json' if label=='interrupted' else 'correction-plan.json')
  assert set(expected)==set(files),(label,set(expected)-set(files),set(files)-set(expected))
  for name,origin in expected.items():
   assert origin.stat().st_size==files[name]['bytes'] and sha(origin)==files[name]['sha256'],name
  archive_results.append({'label':label,**ref(path),'original_files':len(files),'payload_bytes':sum(x['bytes'] for x in files.values()),'inventory_sha256':h(payload),'exact_membership':True,'all_payloads_and_current_origins_match':True,'cache_exclusions_pruned_before_traversal':exclusions})
  print('archive verified',label,len(files),flush=True)
# Explicitly preserve interrupted capture accounting + earlier actual failures.
partial=load(BASE/'stage39-module-eval-corrected-audit-01/report.json')
assert partial['status']=='intentionally-interrupted-and-closed' and partial['completed_pairs']==25 and partial['not_started_cases']==46
assert partial['native_complete_captures']==25 and partial['fresh_java_complete_captures']==26 and not partial['full_report_present']
assert partial['driver_terminal']['exit_code']==-2
old=load(BASE/'stage39-module-baseline-comparison-01/report.json')
assert old['native_case_status_counts']=={'pass':42,'mismatch':27,'candidate-non-language-exit2':3}
assert old['compatibility_complete'] is False
initial_clippy=load(BASE/'stage39-adapter-checks-01/clippy.process.json');assert initial_clippy['exit_code']!=0
controls=load(BASE/'stage39-lambda-corrected-native-01/report.json')
result={'status':'pass','scope':'Independent implementation-checkpoint source-tree and six closed archive audit. Full corrected3599 acquisition/gates remain pending; no Stage39/M2 compatibility or performance completion claim.',
 'summary':ref(ROOT/'reports/m2/stage39-implementation-checkpoint.json'),'source_binding':ref(ROOT/'reports/m2/stage39-implementation-source-binding.json'),
 'source_tree':binding['source_tree'],'bound_sources':len(binding['sources']),'submodule_inputs_bound':72,'captured_final_checks_source_map_exact':True,
 'required_checks_passed':checks['passed'],'rust_harness_pass_invocations':passed,'rust_ignored_invocations':ignored,'distinct_test_count_claimed':False,
 'inventory_counts':manifest['counts'],'archives':archive_results,'archived_original_files':sum(r['original_files'] for r in archive_results),
 'retained_baseline_statuses':old['native_case_status_counts'],'retained_interrupted_completed_pairs':partial['completed_pairs'],'retained_interrupted_not_started':partial['not_started_cases'],'initial_clippy_failure_preserved':True,
 'corrected_standard_completed_reference_verified':True,'full_native_pending_preserved':any('3599' in x for x in summary['pending']),
 'findings':[],'clarification':'Initial pending-standard wording corrected by parent additive status update; prior summary preserved. Initial audit inspection expected common inventory format; format assumptions failed before corrected independent verifier, retained in audit notes.',
 'runtime_reruns':0,'production_changes':0,'git_mutations':0,'cache_policy':'Only positive closed origin lists walked; actual persistent/trace build caches pruned top-down before traversal. Git read-only cat-file/ls-tree.'}
(OUT/'report.json').write_bytes(enc(result));print(json.dumps({k:v for k,v in result.items() if k!='archives'},indent=2),flush=True)
