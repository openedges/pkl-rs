"""Update checkpoint status after concurrent acquisitions finish; retain prior bytes."""
from pathlib import Path
import hashlib
import json
import time

root = Path(__file__).resolve().parents[3]
out = Path(__file__).parent
path = root / 'reports/m2/stage39-implementation-checkpoint.json'
prior = path.read_bytes()
assert not (out / 'prior-checkpoint.json').exists()
(out / 'prior-checkpoint.json').write_bytes(prior)
report = json.loads(prior)
report['scope'] = 'Stage39 implementation checkpoint after correcting independently reproduced lambda-keyword regression. The complete corrected native corpus and final evidence review remain unfinished; Stage39 and M2 are not closed.'
report['pending'] = [
    'Full corrected 3599-case native acquisition and all gates',
    'Completion and final verification of corrected persistent/trace evidence',
    'Final review and publication of actual corrected standard, original72 and boundary Node/Chromium evidence',
    'Final source/byte evidence review and milestone checkpoint closeout',
]
report['status_update'] = dict(epoch=time.time(), prior_summary_sha256=hashlib.sha256(prior).hexdigest(),
                             helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                             source_binding_unchanged=True)
standard = root / 'target/m2/stage39-platforms-final-02/report.json'
report['completed_corrected_standard_platform_acquisition'] = dict(
    path=str(standard.relative_to(root)), sha256=hashlib.sha256(standard.read_bytes()).hexdigest(),
    scope='Completed acquisition; final checkpoint evidence review remains separate.')
data = (json.dumps(report, indent=2, sort_keys=True) + '\n').encode()
path.write_bytes(data)
(out / 'report.json').write_bytes(data)
print(json.dumps(report['status_update']))
