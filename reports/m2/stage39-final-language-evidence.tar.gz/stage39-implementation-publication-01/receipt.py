"""Verify the published implementation commit without changing completed sources."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[3]
out = Path(__file__).parent
commit = '5526ec808b9ee9bfd743baa33bbc1a7d2364471b'
branch = 'refs/heads/m2/stage39-upstream-errors'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip() == commit
captures = root / 'target/m2/stage39-command-captures-01'
records = {}
for name in ['implementation-commit-01', 'implementation-push-01', 'implementation-remote-01']:
    directory = captures / name
    record = json.loads((directory / 'process.json').read_bytes())
    assert record['exit_code'] == 0
    for channel in ['stdout', 'stderr']:
        data = (directory / (channel + '.bin')).read_bytes()
        assert hashlib.sha256(data).hexdigest() == record['channels'][channel]['sha256']
    records[name] = record
assert (captures / 'implementation-remote-01/stdout.bin').read_text().split() == [commit, branch]
binding = json.loads((root / 'reports/m2/stage39-implementation-source-binding.json').read_bytes())
entries = {}
for row in subprocess.check_output(['git', 'ls-tree', '-rz', '--full-tree', commit], cwd=root).split(b'\0'):
    if row:
        head, name = row.split(b'\t', 1)
        entries[name.decode()] = head.decode().split()[2]
for name, source in binding['sources'].items():
    if source['repository'] == 'root':
        assert entries[name] == source['git_blob'], name
for name, oid in binding['submodules'].items():
    assert entries[name] == oid
report = dict(schema=1, commit=commit, published_ref=branch, remote='origin',
              remote_head_verified=True, actual_commit_source_blobs_verified=len(binding['sources']),
              source_tree=binding['source_tree'], process_records=records,
              main_integration='Pending final Stage39 checkpoint closeout; main remains at the previous checkpoint.',
              compatibility_complete=False,
              helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(out / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: report[key] for key in ['commit', 'published_ref', 'remote_head_verified', 'actual_commit_source_blobs_verified']}))
