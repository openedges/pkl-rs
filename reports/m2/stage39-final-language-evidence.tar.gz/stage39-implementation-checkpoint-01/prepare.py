"""Bind completed checks to staged Git source blobs; retain pending-suite scope."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(data):
    return (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()

def load(name):
    return json.loads((ROOT / name).read_bytes())

def ref(name):
    data = (ROOT / name).read_bytes()
    return dict(path=name, bytes=len(data), sha256=sha(data))

def git(*args, cwd=ROOT, data=None):
    return subprocess.check_output(['git', *args], cwd=cwd, input=data)

tree = git('write-tree').decode().strip()
entries = {}
for raw in git('ls-tree', '-rz', '--full-tree', tree).split(b'\0'):
    if not raw:
        continue
    header, name = raw.split(b'\t', 1)
    mode, kind, oid = header.decode().split()
    entries[name.decode()] = dict(mode=mode, kind=kind, oid=oid)

checks = load('target/m2/stage39-checks-final-02/report.json')
assert checks['passed'] and checks['source_stability'] and not checks['source_changes']
expected = checks['source_sha256']
binding = {}
normal = []
external = []
for name, digest in sorted(expected.items()):
    assert sha((ROOT / name).read_bytes()) == digest
    assert sha((ROOT / 'target/m2/stage39-checks-final-02/sources' / name).read_bytes()) == digest
    if name.startswith('external/pkl/'):
        external.append((name, entries['external/pkl']['oid'] + ':' + name[len('external/pkl/'):]))
    else:
        assert entries[name]['kind'] == 'blob', name
        normal.append((name, entries[name]['oid']))

for requests, cwd in [(normal, ROOT), (external, ROOT / 'external/pkl')]:
    raw = git('cat-file', '--batch', cwd=cwd, data=('\n'.join(query for _, query in requests) + '\n').encode())
    position = 0
    for name, query in requests:
        end = raw.index(b'\n', position)
        oid, kind, size = raw[position:end].decode().split()
        assert kind == 'blob'
        size = int(size)
        data = raw[end + 1:end + 1 + size]
        assert raw[end + 1 + size:end + 2 + size] == b'\n'
        position = end + 2 + size
        assert sha(data) == expected[name], name
        binding[name] = dict(git_blob=oid, sha256=expected[name],
                             repository='external/pkl' if cwd != ROOT else 'root')
    assert position == len(raw)

binding_report = dict(schema=1, scope='Completed corrected local checks bound to exact staged Git blobs, including pinned submodule inputs. This is a source tree binding, not a completed compatibility gate.',
                      source_tree=tree, source_files=len(binding), sources=binding,
                      submodules={name: entries[name]['oid'] for name in ['external/pkl', 'external/pkl-pantry']})
(ROOT / 'reports/m2/stage39-implementation-source-binding.json').write_bytes(encoded(binding_report))

native = load('target/m2/stage39-lambda-corrected-native-01/report.json')
manifest = load('compatibility/m2-language.json')
rust = (ROOT / 'target/m2/stage39-checks-final-02/rust-tests.stdout.bin').read_text()
passed = sum(int(value) for value in re.findall(r'test result: ok\. (\d+) passed;', rust))
ignored = sum(int(value) for value in re.findall(r'test result: ok\. \d+ passed; \d+ failed; (\d+) ignored;', rust))
summary = dict(schema=1, scope='Stage39 implementation checkpoint after correcting independently reproduced lambda-keyword regression. Final corpus, lifecycle, trace and portable acquisitions remain pending; Stage39 and M2 are not closed.',
               compatibility_complete=False, performance_target_claimed=False,
               source_tree=tree, base_commit=git('rev-parse', 'HEAD').decode().strip(),
               source_binding=ref('reports/m2/stage39-implementation-source-binding.json'),
               checks=ref('target/m2/stage39-checks-final-02/report.json'),
               required_rust_checks_passed=True, check_source_stability=True,
               rust_harness_pass_invocations=passed, rust_ignored_invocations=ignored,
               rust_count_is_distinct_test_count=False,
               prior_unchanged_tooling_checks=ref('target/m2/stage39-checks-final-01/report.json'),
               corrected_manifest_and_focused_tool_checks=ref('target/m2/stage39-adapter-final-checks-02/report.json'),
               corrected_native_controls=ref('target/m2/stage39-lambda-corrected-native-01/report.json'),
               original_control_scope='20 sources, two native repetitions each against two closed Java observations. Accepted output evaluation stays Unsupported; inspect the raw control report for dispositions.',
               inventory_counts=manifest['counts'],
               archives=[ref('reports/m2/' + name) for name in [
                   'stage39-oracle-captures.json', 'stage39-checkpoint-captures.json',
                   'stage39-interrupted-captures.json', 'stage39-correction-captures.json']],
               pending=['Full corrected 3599-case native acquisition and all gates',
                        'Corrected persistent and trace acquisitions',
                        'Actual corrected standard, original72 and boundary Node/Chromium acquisitions',
                        'Final evidence review and milestone checkpoint closeout'],
               helper_sha256=sha(Path(__file__).read_bytes()))
(ROOT / 'reports/m2/stage39-implementation-checkpoint.json').write_bytes(encoded(summary))
(OUT / 'source-tree.txt').write_text(tree + '\n')
(OUT / 'report.json').write_bytes(encoded(summary))
print(json.dumps({key: summary[key] for key in ['source_tree', 'rust_harness_pass_invocations', 'rust_ignored_invocations', 'compatibility_complete']}))
