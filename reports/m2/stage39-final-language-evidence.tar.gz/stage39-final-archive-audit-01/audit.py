from pathlib import Path,PurePosixPath
import json,hashlib,stat,tarfile,os,tempfile
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-final-archive-audit-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
def file_sha(p):return sha(p.read_bytes())
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
results=[]
for kind in ['platform','regression']:
 capture_path=ROOT/'reports/m2'/f'stage39-final-{kind}-captures.json';capture=load(capture_path);archive=Path(capture['archive']);assert archive.stat().st_size==capture['archive_bytes'] and file_sha(archive)==capture['archive_sha256'];archive_before=file_sha(archive)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();names=[m.name for m in members];assert len(names)==len(set(names)) and all(m.isfile() for m in members)
  for name in names:
   path=PurePosixPath(name);assert not path.is_absolute() and '..' not in path.parts and '.' not in path.parts
  inv_bytes=tf.extractfile('archive-inventory.json').read();assert sha(inv_bytes)==capture['inventory_sha256'];inv=json.loads(inv_bytes);plan_bytes=tf.extractfile('_preservation/plan.json').read();plan=json.loads(plan_bytes);helper=tf.extractfile('_preservation/archive.py').read();assert sha(plan_bytes)==capture['plan_sha256'] and sha(helper)==capture['helper_sha256']
  assert plan['archive']==str(archive) and plan['report']==str(capture_path);base=Path(plan['base']);assert base==ROOT/'target/m2';excluded={base/x for x in plan['excluded_cargo_paths']};assert inv['exclusions']==plan['excluded_cargo_paths'] and not inv['excluded_cache_contents_enumerated']
  cargo_proof={}
  for p in excluded:
   assert (p/'CACHEDIR.TAG').is_file() and (p/'.rustc_info.json').is_file();cargo_proof[p.relative_to(base).as_posix()]={'CACHEDIR.TAG_exists':True,'rustc_info_exists':True,'contentsEnumerated':False}
  current={};visited=[]
  for name in plan['roots']:
   p=base/name;assert not p.is_symlink()
   if p.is_file():current[name]=p;continue
   assert p.is_dir()
   for directory,children,files in os.walk(p,topdown=True,followlinks=False):
    # Exact known Cargo trees are removed BEFORE recursion. Generic build log folders are retained.
    children[:]=sorted(n for n in children if Path(directory)/n not in excluded)
    assert not any((Path(directory)/n).is_symlink() for n in children)
    assert all(Path(directory)!=e and not Path(directory).is_relative_to(e) for e in excluded);visited.append(Path(directory).relative_to(base).as_posix())
    for name2 in sorted(files):
     q=Path(directory)/name2;assert q.is_file() and not q.is_symlink();key=q.relative_to(base).as_posix();assert key not in current;current[key]=q
  assert set(inv['files'])==set(current)|{'_preservation/archive.py','_preservation/plan.json'}
  assert set(names)==set(inv['files'])|{'archive-inventory.json'} and len(inv['files'])==capture['original_files']
  assert sum(r['bytes'] for r in inv['files'].values())==capture['original_bytes']
  checked={}
  # Real independent extraction with safe paths; scratch is owned by this audit and removed afterward.
  with tempfile.TemporaryDirectory(prefix='extracted-'+kind+'-',dir=OUT) as temporary:
   dest=Path(temporary)
   for member in members:
    data=tf.extractfile(member).read();q=dest/member.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);q.chmod(member.mode)
    assert q.stat().st_size==member.size and stat.S_IMODE(q.stat().st_mode)==member.mode and q.read_bytes()==data
    if member.name=='archive-inventory.json':assert data==inv_bytes;continue
    row=inv['files'][member.name];assert len(data)==row['bytes'] and sha(data)==row['sha256'] and member.mode==row['mode']
    if member.name in current:
     p=current[member.name];assert p.read_bytes()==data and stat.S_IMODE(p.stat().st_mode)==row['mode']
    checked[member.name]={'bytes':len(data),'mode':member.mode,'sha256':sha(data)}
  assert file_sha(archive)==archive_before
  write(OUT/(kind+'-verified-files.json'),{'files':checked,'exactCurrentOrigins':str(base),'excludedCargoProof':cargo_proof})
  results.append({'kind':kind,'archive':str(archive),'captureReport':str(capture_path),'captureReportSha256':file_sha(capture_path),'archiveSha256':archive_before,'inventorySha256':sha(inv_bytes),'regularMembers':len(members),'originalFiles':len(checked),'payloadBytes':sum(r['bytes'] for r in checked.values()),'declaredRoots':plan['roots'],'membersBytesModesCurrentOriginsExact':True,'independentExtractionVerified':True,'temporaryExtractionRemoved':True,'cachePruningBeforeWalk':cargo_proof})
# Preserve failed audit02 self-inventory as failed evidence, not a valid closure.
p=ROOT/'target/m2/stage39-platform-final-audit-02';mismatches=[]
for r in load(p/'inventory.json')['files']:
 if file_sha(p/r['path'])!=r['sha256']:mismatches.append({'path':r['path'],'inventoriedSha256':r['sha256'],'actualSha256':file_sha(p/r['path'])})
assert [x['path'] for x in mismatches]==['stdout.log']
fixed=ROOT/'target/m2/stage39-platform-final-audit-03';closure=load(fixed/'closure.json');assert file_sha(fixed/'report.json')==closure['reportSha256'] and file_sha(fixed/'inventory.json')==closure['inventorySha256']
for r in load(fixed/'inventory.json')['files']:assert file_sha(fixed/r['path'])==r['sha256']
adjacent=ROOT/'target/m2/stage39-platform-final-audit-03.process.json';process=load(adjacent)
for channel in ['stdout','stderr']:assert file_sha(ROOT/'target/m2'/('stage39-platform-final-audit-03.'+channel+'.log'))==process[channel+'Sha256']
assert process['reportSha256']==file_sha(fixed/'report.json') and process['closureSha256']==file_sha(fixed/'closure.json') and process['scriptSha256']==file_sha(fixed/'audit.py') and process['exitCode']==0
write(OUT/'report.json',{'status':'pass','scope':'Independent bounded archive membership/full-byte/mode/current-origin audit only. No runtime/Git mutation or compatibility rerun; valid acquisition outcomes remain separately reported.','archives':results,'failedAudit02':{'scope':'Correctly preserved historical self-inventory failure, not blessed as valid closure','mismatches':mismatches,'archivedWholeRoot':True},'validAudit03':{'reportSha256':file_sha(fixed/'report.json'),'closureSha256':file_sha(fixed/'closure.json'),'adjacentTerminalProcessAndRawLogsPreserved':True,'processSha256':file_sha(adjacent)},'cacheScope':'Only explicitly declared roots traversed; exactly two identified Cargo build trees removed before descending; generic build log directories retained. No broad target/cache traversal.','archiveDependencies':'Completeness is for explicitly declared preservation roots. Linked prior oracle/development/native-control dependencies outside those roots are not silently claimed embedded.','originalArchivesUnchanged':True})
(OUT/'FINDINGS.md').write_text('Both exact final archives match their declared preservation membership, all file bytes, Unix modes and current closed origin files. Real independent safe extraction was checked and its audit-owned scratch removed. Explicit persistent and trace Cargo build caches were pruned before recursion; regular build log directories were retained.\n\nThe archive preserves the known audit02 stdout self-inventory failure exactly, without treating that closure as valid. Audit03 is coherent, and its adjacent terminal process/stdout/stderr files are present and match the recorded hashes. This audit verifies preservation, not additional runtime compatibility or completion of Stage39/full M2.\n')
files=[{'path':p.relative_to(OUT).as_posix(),'size':p.stat().st_size,'sha256':file_sha(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and p.relative_to(OUT).as_posix() not in ('inventory.json','closure.json')];write(OUT/'inventory.json',{'files':files});write(OUT/'closure.json',{'status':'closed','reportSha256':file_sha(OUT/'report.json'),'inventorySha256':file_sha(OUT/'inventory.json'),'files':len(files)});print(json.dumps({'reportSha256':file_sha(OUT/'report.json'),'closureSha256':file_sha(OUT/'closure.json'),'archives':results},indent=2))
