"""Review the final native acquisition and bind corrected suites to committed bytes."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent
BASE = ROOT / 'target/m2'
COMMIT = '5526ec808b9ee9bfd743baa33bbc1a7d2364471b'
OLD = ROOT.parent / 'pkl-rs/target/m2/stage38-language-final-03'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def ref(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def git(*args, cwd=ROOT, data=None):
    return subprocess.check_output(['git', *args], cwd=cwd, input=data)


assert not (OUT / 'report.json').exists()
assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
language_root = BASE / 'stage39-language-final-02'
language = load(language_root / 'report.json')
old = load(OLD / 'report.json')
manifest = load(ROOT / 'compatibility/m2-language.json')
old_manifest = load(OLD / 'sources/compatibility/m2-language.json')
old_cases = {case['id']: case for case in old_manifest['cases']}
cases = {case['id']: case for case in manifest['cases']}
assert language['source_stability'] and language['artifact_stability']
assert language['selected_count'] == len(language['results']) == 3599
old_ids = [row['id'] for row in old['results']]
assert len(old_ids) == 3527
assert [row['id'] for row in language['results'][:3527]] == old_ids
assert all(cases[name] == old_cases[name] for name in old_ids)
assert all((OLD / 'sources' / cases[name]['input']).read_bytes()
           == (language_root / 'sources' / cases[name]['input']).read_bytes()
           for name in old_ids)
current_rows = {row['id']: row for row in language['results']}
status_changes = []
raw_changes = {'java': [], 'rust': []}
for before in old['results']:
    name = before['id']
    after = current_rows[name]
    if before['status'] != after['status']:
        status_changes.append(dict(id=name, before=before['status'], after=after['status']))
    for runtime in raw_changes:
        channels = []
        for channel in ['stdout', 'stderr']:
            left = OLD / 'cases' / name / f'{runtime}.{channel}.bin'
            right = language_root / 'cases' / name / f'{runtime}.{channel}.bin'
            first, second = left.read_bytes(), right.read_bytes()
            assert sha(first) == before[runtime][channel + '_sha256']
            assert sha(second) == after[runtime][channel + '_sha256']
            if first != second:
                channels.append(dict(channel=channel, before=ref(left), after=ref(right)))
        for field in ['exit_code', 'timed_out']:
            if before[runtime][field] != after[runtime][field]:
                channels.append(dict(channel=field, before=before[runtime][field], after=after[runtime][field]))
        if channels:
            raw_changes[runtime].append(dict(id=name, channels=channels))

modules = language['results'][3527:]
assert len(modules) == 72
assert all(row['adapter'] == 'language-module-eval' for row in modules)
module_counts = dict(Counter(row['status'] for row in modules))
assert module_counts == {'pass': 72}
for row in modules:
    assert row['java']['exit_code'] == row['rust']['exit_code'] == 1
    assert not row['java']['timed_out'] and not row['rust']['timed_out']
    assert not row['java']['workspace_changes'] and not row['rust']['workspace_changes']
assert not status_changes, status_changes
assert len(language['metamorphic_results']) == 88
assert all(row['status'] == 'pass' for row in language['metamorphic_results'])

checks = load(BASE / 'stage39-checks-final-02/report.json')
persistent = load(BASE / 'stage39-persistent-final-02/report.json')
trace = load(BASE / 'stage39-trace-final-02/report.json')
platform = load(BASE / 'stage39-platform-final-audit-03/report.json')
assert checks['passed'] and checks['source_stability'] and checks['source_changes'] == []
assert persistent['source_stability_before_execution'] and persistent['source_stability_after_execution']
assert persistent['acquisition_error'] is None
calls = [call for row in persistent['cases'] for call in row['observations']['comparisons']]
assert len(persistent['cases']) == 334 and len(calls) == 2782
assert all(call['raw_equal'] and call['status'] == 'pass' for call in calls)
assert trace['source_stability'] and trace['artifact_stability']
assert trace['status_counts'] == {'pass': 54, 'oracle-error': 30}
assert platform['status'] == 'pass' and platform['noLiveWriters']
assert platform['standard']['oracleMatchesEach'] == 6076

source_groups = [
    ('stage39-checks-final-02', checks['source_sha256']),
    ('stage39-language-final-02', language['source_sha256']),
    ('stage39-persistent-final-02', {row['path']: row['sha256'] for row in persistent['sources']}),
    ('stage39-trace-final-02', trace['sources']),
    ('stage39-platforms-final-02', load(BASE / 'stage39-platforms-final-02/sources.json')),
]
sources = {}
for group, rows in source_groups:
    for name, digest in rows.items():
        assert sha((BASE / group / 'sources' / name).read_bytes()) == digest, (group, name)
        assert sha((ROOT / name).read_bytes()) == digest, (group, name)
        if name in sources:
            assert sources[name]['sha256'] == digest, (group, name)
        else:
            sources[name] = dict(sha256=digest, groups=[])
        sources[name]['groups'].append(group)

entries = {}
for raw in git('ls-tree', '-rz', '--full-tree', COMMIT).split(b'\0'):
    if raw:
        header, name = raw.split(b'\t', 1)
        mode, kind, oid = header.decode().split()
        entries[name.decode()] = dict(mode=mode, kind=kind, oid=oid)
requests = {'root': [], 'external/pkl': []}
for name in sorted(sources):
    if name.startswith('external/pkl/'):
        repository = 'external/pkl'
        query = entries[repository]['oid'] + ':' + name[len(repository) + 1:]
    else:
        repository = 'root'
        assert entries[name]['kind'] == 'blob', name
        query = entries[name]['oid']
    requests[repository].append((name, query))
for repository, items in requests.items():
    data = git('cat-file', '--batch', cwd=ROOT if repository == 'root' else ROOT / repository,
               data=('\n'.join(query for _, query in items) + '\n').encode())
    position = 0
    for name, _ in items:
        end = data.index(b'\n', position)
        oid, kind, size = data[position:end].decode().split()
        assert kind == 'blob', name
        size = int(size)
        blob = data[end + 1:end + 1 + size]
        assert data[end + 1 + size:end + 2 + size] == b'\n'
        assert sha(blob) == sources[name]['sha256'], name
        sources[name].update(git_blob=oid, repository=repository)
        position = end + 2 + size
    assert position == len(data)
binding = dict(schema=1, commit=COMMIT, source_files=len(sources),
               source_copies=sum(len(rows) for _, rows in source_groups), sources=sources,
               submodules={name: entries[name]['oid'] for name in ['external/pkl', 'external/pkl-pantry']},
               scope='Exact committed Git blobs and pinned upstream inputs for final corrected local suites; no platform or milestone completion inference.')
(OUT / 'source-binding.json').write_bytes(encoded(binding))

gates = {}
for label in ['language-final-02', 'language-report-final-02', 'language-development-final-02',
              'language-subset-final-02', 'language-full-final-02', 'persistent-contract-final-02',
              'trace-report-final-02', 'trace-contract-final-02']:
    path = BASE / 'stage39-command-captures-01' / label / 'process.json'
    record = load(path)
    for channel, expected in record['channels'].items():
        actual = (path.parent / (channel + '.bin')).read_bytes()
        assert len(actual) == expected['bytes'] and sha(actual) == expected['sha256']
    gates[label] = dict(exit_code=record['exit_code'], record=ref(path))
assert [gates[name]['exit_code'] for name in gates] == [0, 0, 1, 1, 1, 0, 0, 1]
result = dict(schema=1, status='pass', implementation_commit=COMMIT,
              scope='Final corrected Stage39 acquisition/source/regression review, retaining strict failures and all original obligations.',
              previous_language=ref(OLD / 'report.json'), current_language=ref(language_root / 'report.json'),
              existing_case_definitions_inputs_and_order_unchanged=True,
              existing_cases=3527, status_changes=status_changes,
              cross_checkout_raw_changes=raw_changes,
              cross_checkout_raw_note='Exact bytes compared without normalization. Different physical checkout URIs affect diagnostic bytes; changes are retained individually and are not claimed byte-identical across stages.',
              selected_count=language['selected_count'], status_counts=language['status_counts'],
              original_module_case_status_counts=module_counts,
              failures=[dict(id=row['id'], status=row['status']) for row in language['results'] if row['status'] != 'pass'],
              metamorphic_relations=88, full_gate_failure_reasons=len(language['full_gate_failures']),
              inventory_counts=manifest['counts'], gates=gates,
              persistent=dict(sequences=334, calls=2782, all_selected_calls_match=True,
                              unexecuted_groups=persistent['unexecuted_groups']),
              trace=trace['status_counts'], platform_audit=ref(BASE / 'stage39-platform-final-audit-03/report.json'),
              source_binding=ref(OUT / 'source-binding.json'),
              compatibility_complete=False, performance_target_claimed=False,
              runtime_reruns=0, helper_sha256=sha(Path(__file__).read_bytes()))
(OUT / 'report.json').write_bytes(encoded(result))
print(json.dumps(dict(status=result['status'], selected=result['status_counts'],
                      full_gate_failure_reasons=result['full_gate_failure_reasons'],
                      source_files=len(sources), source_copies=binding['source_copies'],
                      cross_checkout_raw_changes={k: len(v) for k, v in raw_changes.items()})), flush=True)
