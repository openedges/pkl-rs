from pathlib import Path
import hashlib,json,subprocess,time
root=Path.cwd();out=root/'target/m2/stage49-core-evidence-proposal-01'
names=[*(f'stage49-modulekey-build0{i}' for i in range(1,6)), 'stage49-required-rust-01','stage49-required-rust-02','stage49-probe-checks-01','stage49-ordinary-mismatch-fixes-01','stage49-runtime-debug-02','stage49-admission-test-migration-01','stage49-admission-test-migration-02','stage49-runtime-handoff-01','stage49-runtime-handoff-02']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
def snapshot():
 result={}
 for name in names:
  base=root/'target/m2'/name
  assert base.is_dir(),base
  for p in sorted(base.rglob('*')):
   assert not p.is_symlink(),p
   if p.is_file(): result[str(p.relative_to(root))]={'sha256':digest(p),'bytes':p.stat().st_size}
 result['tools/evidence.py']={'sha256':digest(root/'tools/evidence.py'),'bytes':(root/'tools/evidence.py').stat().st_size}
 return result
before=snapshot();save('sources-before.json',before)
rows=[]
for name in names:
 source=root/'target/m2'/name;archive=out/'archives'/f'{name}.tar.gz';processes=[]
 for action,args in [('create',[str(source),str(archive)]),('verify',[str(archive)])]:
  command=['python3','tools/evidence.py',action,*args];start=time.time()
  with (out/f'{name}-{action}.stdout').open('wb') as stdout,(out/f'{name}-{action}.stderr').open('wb') as stderr:
   p=subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr);save('active.json',{'root':name,'action':action,'command':command,'pid':p.pid});code=p.wait()
  processes.append({'command':command,'pid':p.pid,'exitCode':code,'elapsedSeconds':time.time()-start})
  assert code==0,(name,action,code)
  assert archive.stat().st_size<100_000_000,archive
 files=[v for path,v in before.items() if path.startswith(f'target/m2/{name}/')]
 rows.append({'sourceRoot':str(source),'archive':str(archive),'fileCount':len(files),'uncompressedBytes':sum(v['bytes'] for v in files),'archiveBytes':archive.stat().st_size,'sha256':digest(archive),'processes':processes})
 save('archives.json',rows);print(json.dumps({k:rows[-1][k] for k in ('sourceRoot','fileCount','archiveBytes','sha256')}),flush=True)
after=snapshot();save('sources-after.json',after)
report={'status':'READY_FOR_ROOT_REVIEW' if before==after else 'SOURCE_CHANGED','sourceStable':before==after,'selectedRoots':names,'sourceFileCount':len(before)-1,'uncompressedBytes':sum(v['bytes'] for k,v in before.items() if k!='tools/evidence.py'),'archiveCount':len(rows),'archiveBytes':sum(r['archiveBytes'] for r in rows),'largestArchiveBytes':max(r['archiveBytes'] for r in rows),'allCreateAndVerifyExitZero':all(p['exitCode']==0 for r in rows for p in r['processes']),'toolSha256':before['tools/evidence.py']['sha256'],'qualifications':['Build01 is the early bounded SPI132 snapshot; it is not full public lifecycle or final dependency/source proof.','Build02–04 remain immutable intermediate candidates; build04 has32 ordinary and8 internal raw mismatches preserved in separately packaged oracle evidence.','Build05 is the final core candidate for this handoff; native836 intended ordinary rows match,100 diagnostic-only rows match,8 internal boundaries remain mismatched.','runtime-debug02 logs retain earlier failures and WIP repairs; these logs lack a common frozen source/process manifest and are not promoted to final verification.','Admission migration01/02 are focused WIP source-qualified architecture checks, not Java/platform compatibility claims.','Non-tail code arena slots and retained nested vector capacities still accumulate unbounded metadata; payload reclamation is not total memory closure.','Final platform/oracle/strictobserver evidence is published separately by root/B.'],'gitOrReportsMutated':False}
save('proposal.json',report);print(json.dumps(report,indent=2));raise SystemExit(0 if before==after else 1)
