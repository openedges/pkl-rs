# Stage49 Rust core evidence 게시 제안

상태: root 검토 대기. Git 또는 `reports/`를 수정하지 않았다. 원본 evidence를 변경하지 않고 각 root에서 `tools/evidence.py create`와 별도 `verify`를 실행했다.

14개 archive는 원본 1,266개 파일(158,180,101 bytes)을 포함한다. 압축 합계는 26,151,534 bytes, 최대 단일 archive는 4,470,350 bytes다. 모든 create/verify 프로세스는 exit 0이며, 원본 evidence 14개 root와 `tools/evidence.py`의 before/after 해시가 동일하다.

| 원본 root | 파일 수 | 원본 bytes | archive bytes |
| --- | ---: | ---: | ---: |
| `stage49-modulekey-build01` | 228 | 20515979 | 4262856 |
| `stage49-modulekey-build02` | 232 | 20905657 | 4347432 |
| `stage49-modulekey-build03` | 234 | 21531178 | 4456379 |
| `stage49-modulekey-build04` | 234 | 21569809 | 4464953 |
| `stage49-modulekey-build05` | 234 | 21602475 | 4470350 |
| `stage49-required-rust-01` | 16 | 21092007 | 1985864 |
| `stage49-required-rust-02` | 16 | 21092616 | 1985991 |
| `stage49-probe-checks-01` | 10 | 56509 | 13253 |
| `stage49-ordinary-mismatch-fixes-01` | 2 | 1848 | 1176 |
| `stage49-runtime-debug-02` | 24 | 9549927 | 102555 |
| `stage49-admission-test-migration-01` | 17 | 132156 | 29242 |
| `stage49-admission-test-migration-02` | 17 | 123229 | 27560 |
| `stage49-runtime-handoff-01` | 1 | 2487 | 1585 |
| `stage49-runtime-handoff-02` | 1 | 4224 | 2338 |

`archives.json`은 각 archive의 SHA-256, 원본 root, 실제 create/verify 명령·PID·exit·경과 시간을 기록한다. `sources-before.json`과 `sources-after.json`은 packaging 원본 파일의 byte identity다. `proposal.json`은 범위와 판정이다. 게시할 때 이 control 자료도 archive 목록과 함께 보존해야 한다.

## 증거 범위

- build01은 초기 SPI132의 제한된 source snapshot이며 최종 public lifecycle 또는 전체 dependency 재현성 증거로 승격하지 않는다. build02–04 중간 artifact도 원형을 보존한다.
- build05는 이번 core handoff의 후보이며 `required-rust-02`의 5개 Rust 명령이 모두 exit 0이다. 전체 workspace test와 Wasm check를 실제로 실행했고 53,487개 source/fixture input이 동일했다.
- `runtime-debug-02`의 실패 및 수정 과정 로그는 공통 frozen source/process manifest가 없는 WIP 이력이다. 최종 후보 통과 증거로 합치지 않는다. admission migration01/02 역시 당시 WIP에 대한 focused architecture 검사다.
- build04의 ordinary32 및 internal8 raw mismatch는 B의 별도 native/oracle archive에 남는다. build05는 ordinary32를 수정했고 intended ordinary836과 diagnostic-only100을 raw 비교했다. internal8은 여전히 불일치다.
- non-tail arena slot 및 내부 Vec capacity의 누적은 미해결이다. code/source payload 회수를 전체 메모리 상한으로 해석하지 않는다.
- 전체 Java observer byte/counter gate, 플랫폼 검증 및 전체 M2/성능 완료 판정은 이 core archive만으로 닫지 않는다. 해당 자료는 root/B가 별도 게시한다.
