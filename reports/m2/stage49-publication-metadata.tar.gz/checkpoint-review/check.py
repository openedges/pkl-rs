from pathlib import Path
import json
import hashlib

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
OUT = Path(__file__).resolve().parent
source = ROOT / 'reports/m2/stage49-implementation-checkpoint.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
summary = json.loads(source.read_bytes())
assert sha(source) == '2955756e366f32425bc08308f0ab7f8eb6c971c4ecf6195ae2611bee2b71d9d8'
pointers = []
def walk(value):
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
            p = Path(value['path'])
            assert p.is_file() and sha(p) == value['sha256'], str(p)
            pointers.append({'path': str(p), 'sha256': value['sha256']})
        for child in value.values():
            walk(child)
    elif isinstance(value, list):
        for child in value:
            walk(child)
walk(summary)
required = json.loads(Path(summary['requiredRust']['report']['path']).read_bytes())
assert summary['requiredRust']['checks'] == required['checks'] and required['sourceStable']
assert summary['requiredRust']['sourceCount'] == required['sourceCount']
assert all(row['exitCode'] == 0 for row in required['checks'])
for claim in summary['original212Native'].values():
    actual = json.loads(Path(claim['report']['path']).read_bytes())
    for name in ['evaluationProfile', 'rawApiPass', 'rawApiMismatchOrMissing', 'unexecutedApiCalls',
                 'fullLifecyclePassSessions', 'fullLifecycleFailSessions', 'inputsAndToolsStable', 'allProcessesTerminal']:
        assert claim[name] == actual[name]
extended = summary['extendedNative']
actual = json.loads(Path(extended['report']['path']).read_bytes())
audit = json.loads(Path(extended['independentAudit']['path']).read_bytes())
assert (extended['apiCalls'], extended['rawMatches'], extended['rawMismatchOrMissing']) == (actual['acquiredJavaApiCalls'], actual['rawBytesMatch'], actual['rawMismatchOrMissing'])
assert extended['intentLedger'] == audit['intentLedger']
assert sum(extended['intentLedger'].values()) == extended['apiCalls']
assert extended['rawMatches'] == extended['intentLedger']['intendedOrdinaryMatched'] + extended['intentLedger']['initialAliasIntentNotReached']
assert extended['fullJavaEventCounterGatePassed'] is False and extended['portable944Unexecuted'] is True
for label, claim in summary['portable'].items():
    actual = json.loads(Path(claim['report']['path']).read_bytes())
    for target, data in claim['targets'].items():
        for name, value in data.items():
            source_value = actual['targets'][target]['sessions'] if name == 'sessionCount' else actual['targets'][target][name]
            if name == 'sessionCount' and isinstance(source_value, list):
                source_value = len(source_value)
            assert value == source_value, (label, target, name)
    for name, value in claim['gates'].items():
        assert value == actual[name]
    for name in ['infrastructureErrors', 'browserErrors', 'changedInputs']:
        assert claim[name] == actual[name]
primitive = json.loads(Path(summary['primitive']['report']['path']).read_bytes())
assert all(summary['primitive'][name] == value for name, value in primitive['primitiveGate'].items())
assert summary['primitive']['acquisitionAndArchitecturePassed'] == primitive['acquisitionAndArchitecturePassed']
inventory = json.loads(Path(summary['inventory']['report']['path']).read_bytes())
assert summary['inventory']['counts'] == inventory['counts']
assert summary['inventory']['onlyImplementationSourceHashesChanged'] == inventory['onlyImplementationSourceHashesChanged']
assert summary['fullM2Complete'] is False and summary['performanceTargetClaimed'] is False and summary['hostedCiClaimed'] is False
claims = [source, ROOT / 'PLAN.md', ROOT / 'TESTING.md', ROOT / 'docs/architecture.md',
          ROOT / 'docs/m2-module-admission.md', ROOT / 'docs/m2-module-keys.md']
inputs = [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in claims]
(OUT / 'claim-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
(OUT / 'reviewed-checkpoint.json').write_bytes(source.read_bytes())
result = {'schema': 1, 'checkpointSha256': sha(source), 'verifiedPointers': pointers,
          'requiredRustAndSummaryFieldsMatch': True, 'native944IntentAndPortableScopesMatch': True,
          'portableAndPrimitiveFieldsMatch': True, 'inventoryFieldsMatch': True,
          'architectureStaleBoundaryCorrected': True, 'currentMaterialClaimIssues': [],
          'newEvaluatorRuns': 0, 'qualification': 'Compact existing-record/claim review; raw bytes/source binding are reused from sealed C04/C05 and B audits, not reexecuted.'}
(OUT / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'pointers': len(pointers), 'checkpointSha256': sha(source), 'materialIssues': []}))
