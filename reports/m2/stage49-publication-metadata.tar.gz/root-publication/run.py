"""Package closed root-owned Stage49 evidence without changing producer captures."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
BASE=ROOT/'target/m2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
groups=json.loads((OUT/'selection.json').read_text())
assert not (OUT/'report.json').exists(), 'Preserve previous publication evidence.'
report={'scope':'Closed Stage49 platform, provider, fixture, manifest and independent review evidence. Original failed outcomes and earlier candidates remain separate. Not a whole-M2 completion or performance claim.', 'startedUtc':now(), 'archives':[], 'toolSha256':sha(ROOT/'tools/evidence.py')}
save(OUT/'report.json',report)
for group,names in groups.items():
    staging=OUT/'staging'/group;staging.mkdir(parents=True)
    originals={}
    for name in names:
        source=BASE/name
        assert source.is_dir(),source
        for directory,dirs,files in os.walk(source):
            for dirname in dirs:
                assert not (Path(directory)/dirname).is_symlink()
            for filename in files:
                path=Path(directory)/filename
                assert path.is_file() and not path.is_symlink(),path
                relative=path.relative_to(BASE)
                target=staging/relative;target.parent.mkdir(parents=True,exist_ok=True)
                data=path.read_bytes();target.write_bytes(data)
                originals[str(relative)]={'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mode':path.stat().st_mode & 0o777}
    save(staging/'original-paths.json',originals)
    archive=OUT/('stage49-'+group+'.tar.gz')
    row={'group':group,'roots':names,'archive':str(archive),'originalFiles':len(originals),'originalBytes':sum(v['bytes'] for v in originals.values()),'commands':[]}
    for action,argv in [('create',[sys.executable,str(ROOT/'tools/evidence.py'),'create',str(staging),str(archive)]),('verify',[sys.executable,str(ROOT/'tools/evidence.py'),'verify',str(archive)])]:
        command={'action':action,'argv':argv,'startedUtc':now()}
        with (OUT/(group+'-'+action+'.stdout')).open('wb') as stdout,(OUT/(group+'-'+action+'.stderr')).open('wb') as stderr:
            process=subprocess.Popen(argv,cwd=ROOT,stdout=stdout,stderr=stderr);command.update(pid=process.pid,exitCode=process.wait(),finishedUtc=now())
        row['commands'].append(command)
        assert command['exitCode']==0,command
    row.update(sha256=sha(archive),bytes=archive.stat().st_size,originalChanges=[name for name,facts in originals.items() if sha(Path(facts['path']))!=facts['sha256']])
    assert not row['originalChanges']
    assert row['bytes']<100_000_000
    report['archives'].append(row);save(OUT/'report.json',report)
    print(group,row['originalFiles'],row['bytes'],row['sha256'],flush=True)
report.update(complete=True,finishedUtc=now());save(OUT/'report.json',report)
