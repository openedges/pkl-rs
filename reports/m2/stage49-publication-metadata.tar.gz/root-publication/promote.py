"""Independently check and copy completed core/root evidence into reports."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/m2'
OUT = BASE / 'stage49-publication-review-01'
OUT.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
save = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
core = BASE / 'stage49-core-evidence-proposal-01'
root = BASE / 'stage49-root-publication-proposal-01'
groups = [
    ('core', json.loads((core / 'archives.json').read_bytes()), core / 'archives.json'),
    ('platform', json.loads((root / 'report.json').read_bytes())['archives'], root / 'report.json'),
]
report = {'startedUtc': now(), 'archives': [], 'scope': 'Independent archive validation and exact-byte publication; no evaluator execution or compatibility gate changes.'}
for group, archives, control in groups:
    promoted = []
    for row in archives:
        path = Path(row['archive'])
        assert sha(path) == row['sha256'], path
        argv = [sys.executable, str(ROOT / 'tools/evidence.py'), 'verify', str(path)]
        label = path.stem
        with (OUT / (label + '.stdout')).open('wb') as stdout, (OUT / (label + '.stderr')).open('wb') as stderr:
            process = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
            exit_code = process.wait()
        assert exit_code == 0, path
        destination = ROOT / 'reports/m2' / path.name
        assert not destination.exists(), destination
        destination.write_bytes(path.read_bytes())
        assert sha(destination) == row['sha256']
        entry = {'original': str(path), 'repositoryPath': str(destination.relative_to(ROOT)),
                 'sha256': sha(destination), 'bytes': destination.stat().st_size,
                 'validation': {'argv': argv, 'pid': process.pid, 'exitCode': exit_code}}
        promoted.append(entry)
        report['archives'].append(entry)
        save(OUT / 'report.json', report)
    index = ROOT / 'reports/m2' / ('stage49-' + ('core' if group == 'core' else 'platform') + '-captures.json')
    assert not index.exists()
    save(index, {'scope': 'Exact-byte publication of closed captures and preserved histories. Raw compatibility failures remain failures.',
                 'originalControl': {'path': str(control), 'sha256': sha(control)},
                 'files': promoted, 'implementationCommitNotYetClaimed': True})
report['finishedUtc'] = now()
report['complete'] = True
save(OUT / 'report.json', report)
print('Published', len(report['archives']), 'verified archives', sha(OUT / 'report.json'))
