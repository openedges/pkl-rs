"""Explicit source-map readback before staging; never run evaluators or write Git."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import datetime

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
OUT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
load = lambda p: json.loads(p.read_bytes())
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
head = git('rev-parse', 'HEAD').decode().strip()
maps = {}
for label, folder, first, last in [
    ('candidate05', 'stage49-modulekey-build05', 'sources-before.json', 'sources-after.json'),
    ('requiredRust02', 'stage49-required-rust-02', 'inputs-before.json', 'inputs-after.json'),
    ('platformControl02', 'stage49-platform-control-02', 'sources-before.json', 'sources-after.json'),
    ('platformIntegration02', 'stage49-platform-integration-02', 'sources-before.json', 'sources-after.json'),
]:
    directory = ROOT / 'target/m2' / folder
    before, after = load(directory / first), load(directory / last)
    assert before == after
    maps[label] = {'root': directory, 'before': str(directory / first), 'mapSha256': sha((directory / first).read_bytes()), 'values': before}
assert [len(row['values']) for row in maps.values()] == [226, 53487, 320, 101]
by_path = {}
for label, row in maps.items():
    for name, expected in row['values'].items():
        p = Path(name)
        assert not p.is_absolute() and '..' not in p.parts and name != '.'
        by_path.setdefault(name, {})[label] = expected
parents = {}
def read_source(name):
    p = ROOT / name
    for parent in p.parents:
        if parent == ROOT:
            break
        if parent not in parents:
            parents[parent] = stat.S_ISDIR(parent.lstat().st_mode)
        assert parents[parent], 'non-directory/symlink parent: ' + str(parent)
    mode = p.lstat().st_mode
    if stat.S_ISREG(mode):
        data = p.read_bytes()
        return data, {'kind': 'regular', 'mode': '100755' if mode & 0o111 else '100644', 'gitBlob': blob(data)}
    if stat.S_ISLNK(mode):
        target = os.fsencode(os.readlink(p))
        # The historical producer hashes dereferenced read_bytes for explicit leaf links.
        data = p.read_bytes()
        return data, {'kind': 'symlink', 'mode': '120000', 'gitBlob': blob(target),
                      'literalTargetHex': target.hex(), 'literalTargetSha256': sha(target),
                      'byteHashSemantics': 'Matches producer dereferenced bytes, Git blob binds literal target.'}
    raise ValueError('nonregular declared source: ' + name)
current, missing, mismatches = {}, [], []
for name, claims in sorted(by_path.items()):
    try:
        data, kind = read_source(name)
    except (FileNotFoundError, ValueError) as error:
        missing.append({'path': name, 'error': str(error), 'claims': claims})
        continue
    actual = sha(data)
    current[name] = {**kind, 'bytes': len(data), 'sha256': actual, 'captureClaims': claims}
    for label, expected in claims.items():
        if actual != expected:
            mismatches.append({'path': name, 'capture': label, 'expected': expected, 'current': actual})
snapshot_gaps = {}
for label in ['candidate05', 'platformControl02', 'platformIntegration02']:
    row = maps[label]; absent = []
    for name, expected in row['values'].items():
        p = row['root'] / 'sources' / name
        if not p.is_file() or sha(p.read_bytes()) != expected:
            absent.append(name)
    snapshot_gaps[label] = absent
history = []
for version in [1, 2, 3, 4]:
    directory = ROOT / 'target/m2' / f'stage49-modulekey-build{version:02}'
    path = directory / 'sources-before.json'
    old = load(path)
    after = load(directory / 'sources-after.json')
    assert old == after
    changed = [name for name, digest in old.items() if current.get(name, {}).get('sha256') != digest]
    missing_bytes = [name for name, digest in old.items()
                     if not (directory / 'sources' / name).is_file() or sha((directory / 'sources' / name).read_bytes()) != digest]
    history.append({'version': version, 'mapSha256': sha(path.read_bytes()), 'sourceCount': len(old),
                    'differentFromCurrent': changed, 'snapshotMissingOrHashMismatch': missing_bytes,
                    'notReusedAsFinal05Verification': True})
fixture = ROOT / 'tests/fixtures/m2-modulekey-spi'
manifest_path = fixture / 'manifest.json'
assert sha(manifest_path.read_bytes()) == 'ebd3591361efc0a03e98e38695b120e9c625d9c09d0438fc641de420114aab97'
manifest = load(manifest_path)
for name, row in manifest['files'].items():
    data = (fixture / name).read_bytes()
    assert sha(data) == row['sha256'] and len(data) == row['bytes']
assert sha((ROOT / 'tools/modulekey_fixtures.py').read_bytes()) == '14b95a5cf0b9268b7072a0070d1b2f289c00f67c8212ca0b5ace3aa5174306c8'
host = ROOT / 'tests/fixtures/m2-modulekey-host'
assert sha((host / 'host-metadata.json').read_bytes()) == '1ba947f9d3935cf3424f85e9dc19a6e220f5f8cf482206ad42e087ef9ac0b3d7'
for row in load(host / 'host-metadata.json')['sourceProof'].values():
    assert sha((host / row['copy']).read_bytes()) == row['sha256'] == row['copySha256']
post_docs = ['PLAN.md', 'TESTING.md', 'docs/architecture.md', 'docs/m2-module-admission.md', 'docs/m2-module-keys.md', 'reports/m2/README.md']
docs = {}
for name in post_docs:
    data = (ROOT / name).read_bytes()
    docs[name] = {'bytes': len(data), 'sha256': sha(data), 'gitBlob': blob(data), 'inVerificationMaps': name in by_path,
                  'qualification': 'Current publication/documentation input; not silently represented as a captured runtime input.'}
references = git('ls-tree', 'HEAD', 'external/pkl', 'external/pkl-pantry').decode()
assert 'e51fb2f91774265666f94980ec630db794a4db2d' in references and '904a68184e54da378b0a0e8a911a3fab3956f693' in references
write(OUT / 'current-source-map.json', current)
write(OUT / 'documentation-inputs.json', docs)
write(OUT / 'historical-build-scope.json', history)
write(OUT / 'missing-and-changed.json', {'missing': missing, 'mismatches': mismatches})
final_changes = []
for name, row in current.items():
    data, kind = read_source(name)
    if sha(data) != row['sha256'] or kind != {key: value for key, value in row.items() if key not in ['bytes', 'sha256', 'captureClaims']}:
        final_changes.append(name)
assert git('rev-parse', 'HEAD').decode().strip() == head
report = {'schema': 1, 'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'gitHead': head, 'gitlinksAtHead': references.splitlines(),
          'mapCounts': {label: len(row['values']) for label, row in maps.items()},
          'mapIdentities': {label: {'path': row['before'], 'sha256': row['mapSha256']} for label, row in maps.items()},
          'uniqueCurrentInputPaths': len(current), 'missing': missing, 'capturedHashMismatches': mismatches,
          'currentChangesDuringReadback': final_changes, 'fullSnapshotGaps': snapshot_gaps,
          'requiredRustHashOnlyAtCapture': {'producerStoredBeforeAfterHashes': len(maps['requiredRust02']['values']),
            'fullCandidateSnapshotSubset': len(maps['candidate05']['values']),
            'notOriginallyCopiedByRequiredRustProducer': len(set(maps['requiredRust02']['values']) - set(maps['candidate05']['values'])),
            'qualification': 'Current bytes are independently read and hash-joined now. This does not relabel the original hash-only capture as contemporaneous full snapshots.'},
          'fixturePayloadFiles': len(manifest['files']), 'fixtureManifestAndVerifierAndHostPinsMatch': True,
          'historicalBuilds': history,
          'intermediateLimit': 'Standalone runtime-debug logs lacking source maps/terminal receipts remain source-interval-qualified as in prior reviews; not new verification of those versions.',
          'postDocumentationInputs': docs, 'currentIndexBlobBindingClaimed': False,
          'currentProposalGitBlobsComputedWithoutGitWrites': True,
          'newEvaluatorOrTestRuns': 0, 'gitWrites': 0}
write(OUT / 'report.json', report)
print(json.dumps({key: report[key] for key in ['gitHead', 'mapCounts', 'uniqueCurrentInputPaths', 'missing', 'capturedHashMismatches', 'currentChangesDuringReadback', 'fullSnapshotGaps']}))
raise SystemExit(0 if not missing and not mismatches and not final_changes and not any(snapshot_gaps.values()) else 1)
