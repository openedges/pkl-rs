from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess,sys
O=Path(__file__).parent.resolve();R=O.parents[2];T=R/'tools/module_admission_policy_fixtures.py';TEST=R/'tools/tests/test_module_admission_policy_fixtures.py';F=R/'tests/fixtures/m2-module-admission-policy';G=O.parent/'stage48-policy84-fixtures-01';ORIGINAL=O.parent/'stage48-policy84-tools-01';ROOT_CHECKS=O.parent/'stage48-policy84-installed-checks-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
assert sha(T)=='d1f91dc9a44b8d1a9291f4b8b65aa35ea2e295ec74c2fb521a44ecdf89227739'==sha(ORIGINAL/'policy_fixtures.py');assert sha(F/'manifest.json')=='6a4d5b2c8d394108c8a0ee98b33bbc5fd20525aa467da7e68e1799b8cea8ab72'==sha(G/'manifest.json')
manifest=json.loads((F/'manifest.json').read_bytes());expected=set(manifest['files'])|{'manifest.json'};allowed={str(p)for rel in expected for p in Path(rel).parents};found=set()
for current,dirs,names in os.walk(F,followlinks=False):
 for name in dirs:
  path=Path(current)/name;assert str(path.relative_to(F))in allowed and stat.S_ISDIR(path.lstat().st_mode)
 for name in names:
  path=Path(current)/name;assert stat.S_ISREG(path.lstat().st_mode);found.add(str(path.relative_to(F)))
assert found==expected
payload={}
for rel in sorted(expected):
 a=F/rel;b=G/rel;assert a.read_bytes()==b.read_bytes();payload[rel]={'sha256':sha(a),'bytes':a.stat().st_size}
write(O/'fixture-byte-equality.json',payload)
assert sha(ROOT_CHECKS/'report.json')=='6123e05042a5fe60bd223cc34dbe248ee3874548827b2b7bb3d6669d241ed0d0'
root_report=json.loads((ROOT_CHECKS/'report.json').read_bytes());assert root_report['complete']and root_report['before']==root_report['after']and root_report['inputChanges']==[]and all(c['exitCode']==0 for c in root_report['commands'])
for rel,row in root_report['after'].items():assert sha(R/rel)==row['sha256']
for n in ['report.json','unit.stderr.bin','unit.stdout.bin','fixture-cli.stdout.bin','fixture-cli.stderr.bin']:
 shutil.copyfile(ROOT_CHECKS/n,O/('root-'+n))
shutil.copyfile(T,O/'installed-verifier.py.txt');shutil.copyfile(TEST,O/'installed-tests.py.txt')
empty=O/'empty-cwd';empty.mkdir();row={'command':[sys.executable,'-B','-I',str(T),'--fixtures',str(F)],'cwd':str(empty),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'PYTHONDONTWRITEBYTECODE':'1'}}
with(O/'cli.stdout.bin').open('wb')as out,(O/'cli.stderr.bin').open('wb')as err:
 p=subprocess.Popen(row['command'],cwd=empty,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=p.pid;write(O/'cli.launch.json',row);row['exitCode']=p.wait(timeout=60)
row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha(O/'cli.stdout.bin'),stderrSha256=sha(O/'cli.stderr.bin'));write(O/'cli.terminal.json',row);assert row['exitCode']==0;cli=json.loads((O/'cli.stdout.bin').read_bytes());assert cli['javaApiCalls']==84 and cli['javaOrderedEvents']==280 and not cli['eventUtf16IndependentCapture']and cli['evaluatorExecutions']==0
for rel,data in payload.items():assert sha(F/rel)==data['sha256']
assert sha(T)==sha(ORIGINAL/'policy_fixtures.py')
report={'scope':'Read-only installed verifier/test review; no Java/native/portable evaluation or source/Git writes.','blockers':[],'verifierByteIdenticalToSealedOriginal':True,'verifierSha256':sha(T),'installedTestsSha256':sha(TEST),'installedFixtureFiles':len(payload),'everyFixtureByteIdenticalToSealedOriginal':True,'fixtureChanges':[],'originalSixTestBehaviorsRetained':True,'newTests':['provenance symlink rejected before read','sourceProvenance mapping cannot be forged'],'hermeticity':{'fixturesVerification':'Reads only supplied fixture subtree; source inspection and installed confined-reader test cover raw reads. Independent CLI0 from empty cwd with -B -I.','outputExport':'Intentionally requires original absolute oracle root; not a hermetic export claim.','unknownDirectories':'Authentication precedes path walk; directory allowlist rejects before descent.','symlinks':'Root/parents/leaves rejected by regular lstat before provenance read; full traversal also rejects symlinks.'},'rootInstalledChecks':{'reportSha256':sha(ROOT_CHECKS/'report.json'),'actualRootHandleReported':32260,'rootOwnsHandle':True,'inputHashes':len(root_report['after']),'allUnchanged':True,'commandExitCodes':[c['exitCode']for c in root_report['commands']],'unitTests':8},'independentCli':row,'nativeAdmissionSourceDifference':{'sealedDraft':'bb4b0a7732a31a45ec1e43bfc344455129358beaeca0473f542acea2a43bdaea','integrated':'7d63fb3ae750569d604164d4030d86638010ba55ed97c984ccd1ebb35a105154','difference':'Only .collect() becomes .collect::<Vec<_>>() in UTF16 cause decoding; explicit Rust generic annotation, no changed runtime/Host/expected bytes.','originalDraftUnchanged':True},'strictScope':'84 APIs/280 original ASCII JavaUTF8 events; no independent event UTF16 capture. Full primary/repl lifecycle/counter parity remains mandatory and unpassed. Native proposal preserves212 unexecuted custom SPI APIs.'}
write(O/'report.json',report);write(O/'handoff.json',{'reportSha256':sha(O/'report.json'),'fixtureEqualitySha256':sha(O/'fixture-byte-equality.json'),'cliTerminalSha256':sha(O/'cli.terminal.json'),'blockers':[],'nativeExecuted':False})
files={q.name:{'sha256':sha(q),'bytes':q.stat().st_size}for q in O.iterdir()if q.is_file()};write(O/'inventory.json',{'files':files,'emptyDirectories':['empty-cwd'],'prune':[]});write(O/'closure.json',{'closed':True,'handoffSha256':sha(O/'handoff.json'),'inventorySha256':sha(O/'inventory.json'),'allPayloadHashesVerified':all(sha(O/n)==v['sha256']for n,v in files.items()),'liveHandles':[]});print(json.dumps({'handoffSha256':sha(O/'handoff.json'),'reportSha256':sha(O/'report.json'),'blockers':[]},indent=2))
