from pathlib import Path
import hashlib,json,os,shutil,unittest
from unittest import mock
import policy_fixtures as tool
O=Path(__file__).parent.resolve();G=O.parent/'stage48-policy84-fixtures-01';T=O/'test-clone'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
class Tests(unittest.TestCase):
 def setUp(self):
  self.before=sha(G/'manifest.json');shutil.copytree(G,T,copy_function=os.link)
 def tearDown(self):
  shutil.rmtree(T);self.assertEqual(sha(G/'manifest.json'),self.before)
 def rebless(self,relative,data):
  p=T/relative;p.unlink();p.write_bytes(data);m=T/'manifest.json';d=json.loads(m.read_bytes());d['files'][relative]={'sha256':sha(p),'bytes':len(data)};m.unlink();m.write_text(json.dumps(d,indent=2)+'\n')
 def test_exact84_and280_fullraw(self):
  r=tool.verify(T);self.assertEqual(r['javaApiCalls'],84);self.assertEqual(r['javaOrderedEvents'],280);self.assertEqual(r['statusCounts'],{'success':80,'error':4});self.assertFalse(r['eventUtf16IndependentCapture'])
 def test_reordered_events_reblessed_fixture_rejected(self):
  p=T/'fixtures.json';d=json.loads(p.read_bytes());events=d['fixtures'][0]['orderedEvents'];events[0],events[1]=events[1],events[0];self.rebless('fixtures.json',(json.dumps(d,indent=2)+'\n').encode())
  with self.assertRaisesRegex(ValueError,'fixture differs'):tool.verify(T)
 def test_counter_forgery_with_rewritten_manifest_rejected(self):
  p=next(T.glob('provenance/*/cases/*/0/calls/session-0/outer-0.counters-after.bin'));self.rebless(str(p.relative_to(T)),p.read_bytes().replace(b'resolve=3',b'resolve=2'))
  with self.assertRaisesRegex(ValueError,'pinnedinventory payload'):tool.verify(T)
 def test_primary_event_removal_even_if_reblessed_rejected(self):
  p=T/'fixtures.json';d=json.loads(p.read_bytes());d['fixtures'][0]['orderedEvents'].pop(0);self.rebless('fixtures.json',(json.dumps(d,indent=2)+'\n').encode())
  with self.assertRaisesRegex(ValueError,'fixture differs'):tool.verify(T)
 def test_unknown_directory_denied_before_descent(self):
  p=T/'cargo-lookalike';p.mkdir();seen=[];scan=os.scandir
  def observe(path):seen.append(Path(path));return scan(path)
  with mock.patch('os.scandir',side_effect=observe):
   with self.assertRaises(ValueError):tool.verify(T)
  self.assertNotIn(p,seen)
 def test_hermetic_no_original_file_reads(self):
  read=Path.read_bytes
  def confined(path):self.assertTrue(path.is_relative_to(T));return read(path)
  with mock.patch.object(Path,'read_bytes',confined):tool.verify(T)
if __name__=='__main__':unittest.main(verbosity=2)
