from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).parent.resolve();G=O.parent/'stage48-policy84-fixtures-01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[];before={name:sha(O/name)for name in ['policy_fixtures.py','test_policy_fixtures.py','check.py']}
for name,command in [('tests',[sys.executable,'-m','unittest','-v','test_policy_fixtures']),('verify',[sys.executable,str(O/'policy_fixtures.py'),'--fixtures',str(G)])]:
 r={'name':name,'command':command,'cwd':str(O),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentPid':os.getpid(),'environment':{'PYTHONDONTWRITEBYTECODE':'1'},'fixtureManifestSha256':sha(G/'manifest.json')}
 with(O/(name+'.stdout.bin')).open('wb')as out,(O/(name+'.stderr.bin')).open('wb')as err:
  p=subprocess.Popen(command,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);r['pid']=p.pid;(O/(name+'.launch.json')).write_text(json.dumps(r,indent=2)+'\n');r['exitCode']=p.wait()
 r['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['stdoutSha256']=sha(O/(name+'.stdout.bin'));r['stderrSha256']=sha(O/(name+'.stderr.bin'));(O/(name+'.terminal.json')).write_text(json.dumps(r,indent=2)+'\n');records.append(r)
 if r['exitCode']!=0:break
report={'records':records,'allExitCodesZero':len(records)==2 and all(r['exitCode']==0 for r in records),'sourceBefore':before,'sourceAfter':{name:sha(O/name)for name in before},'fixtureManifestSha256':sha(G/'manifest.json'),'evaluations':0,'liveHandles':[]};(O/'checks-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(0 if report['allExitCodesZero']else 1)
