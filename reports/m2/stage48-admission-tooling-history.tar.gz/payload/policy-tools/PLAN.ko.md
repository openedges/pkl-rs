# Stage48 정책 fixture와 후속 Java 취득

기존 Java06의 세 정책 case를 원문과 고정 pin으로 재사용했습니다. 12개 evaluator session의 84 API(80 성공·4 오류), 280개 순서 event를 모두 보존합니다. 기존 event는 ASCII인 JavaUTF8 원문뿐이며 별도 UTF16 취득으로 표시하지 않습니다. API 문자열·오류의 UTF16과 JavaUTF8은 원래 독립 캡처입니다.

policy_fixtures.py와 TSV consumer profile은 API raw, 실제 admission callback, primary/repl 포함 full event/counter gate를 분리합니다. 미구현 lifecycle을 예상 event 삽입으로 보완하지 않습니다. SourceSession의 supplied-text primary와 query 처리에 실제 Java callback이 없다면 full gate는 실패/미실행입니다.

후속 새 AdmissionProbe는 같은 site/별도 site/fresh query/closure 공유, resolve 거부·재시도, singleton edge trust, original/resolved importer, alias/cache와 uncached 정책, 부분 receiver 후 초기화 실패, clause/ImportExpr factory 시점, decoded singleton URI를 다룹니다. TrustProbe는 jar nested/default trust를 원래 공개 Java API로 취득합니다. 두 probe는 새 target root와 고정 0.32.0 JAR/JDK를 사용하며, 생산·Git·이전 source 원문을 바꾸지 않습니다. A의 실제 adapter/release가 공개되기 전에는 Rust 비교를 실행하지 않습니다.
