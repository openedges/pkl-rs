from pathlib import Path
import hashlib,json
import policy_fixtures as tool
O=Path(__file__).parent.resolve();G=O.parent/'stage48-policy84-fixtures-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
verification=tool.verify(G);bundle=json.loads((G/'fixtures.json').read_bytes());cases=[];expected=[];events=[];operations=[]
for f in bundle['fixtures']:
 identity=[f['id'],str(f['repeat']),str(f['session'])]
 source='provenance/stage47-renderer-api-oracle-06/workspace/'+f['id']+'/main.pkl'
 cases.append('\t'.join(identity+[source,f['uri'],f['moduleName'],f['policyProfile']['mode']]))
 for i,e in enumerate(f['expected']):
  expected.append('\t'.join(identity+[str(i),f['expressions'][i].encode().hex(),e['status'],''.join(f'{u:04x}'for u in e['stdoutUnits']),''.join(f'{u:04x}'for u in e['stderrUnits']),e['stdoutHex'],e['stderrHex'],e['counterBytesBeforeHex'],e['counterBytesAfterHex'],str(e['eventStart']),str(e['eventEnd']),e['errorClassUtf8Hex'],e['messageNullRawHex']]))
 for e in f['orderedEvents']:events.append('\t'.join(identity+[str(e['index']),e['utf8Hex']]))
 for i,op in enumerate(f['operations']):operations.append('\t'.join(identity+[str(i),'java-gc-request'if op=='GC'else'evaluate',''if op=='GC'else op[0],''if op=='GC'else op[1].encode().hex()]))
for name,rows in [('cases.tsv',cases),('expected.tsv',expected),('events.tsv',events),('operations.tsv',operations)]:
 data=('\n'.join(rows)+'\n').encode();path=O/name
 if path.exists()and path.read_bytes()!=data:raise ValueError('existingderivedtablechanged')
 path.write_bytes(data)
profile={'schema':1,'fixtureRoot':str(G),'fixtureManifestSha256':verification['manifestSha256'],'tables':{n:{'sha256':sha(O/n),'bytes':(O/n).stat().st_size}for n in ['cases.tsv','expected.tsv','events.tsv','operations.tsv']},'fieldLayouts':{'cases':['id','repeat','session','sourceRelativeToFixture','sourceUri','moduleName','policyMode'],'expected':['id','repeat','session','index','expressionUtf8Hex','status','stdoutUtf16BEHex','stderrUtf16BEHex','stdoutJavaUtf8Hex','stderrJavaUtf8Hex','counterBytesBeforeHex','counterBytesAfterHex','eventStart','eventEnd','javaErrorClassUtf8Hex','javaMessageNullRawHex'],'events':['id','repeat','session','eventIndex','originalJavaUtf8Hex'],'operations':['id','repeat','session','ordinal','operationKind','sourceName','expressionUtf8Hex']},'coverage':{'cases':12,'apiRows':84,'orderedEvents':280,'operationRows':len(operations)},'eventEncoding':'OriginalJavaUTF8only/allASCII; do notclaimindependentlycapturedUTF16eventstrings. Newcontrols separately captureboth.','consumerGates':{'apiRawChannels':'Comparecompletestatus,stdout/stderrUTF16+JavaUTF8 independently. PreserveJavaerrorclassmetadata; SourceSessionisnotoriginalJVMAPI.','fullEventAndCounters':'Compareall280orderedbytes,allperAPIbefore/aftercounterbytesandterminalcounters; neverinsertprimary/replevents. Missingactualcallbacksremainmismatch/unexecuted.','admissionProjection':'Ifseparatelyreported, classifyactualrawcallbackprojectionwithoutfilteringordowngradingfullgate; no expected-eventcopyintoactual.','gc':'OriginalSystem.gc_requestvsactualnative/portablecollectionschedulemustremainseparate.','missingCauseInput':'OldhelperdidnotrecordactualSecurityManagerExceptionmessage; freshdenialcontrolmustsupply typedfailureinput, neverstripfullPklstderr.'},'expectedFullParityStatusBeforeNewLifecycle':'notexecuted; SourceSessioncurrentlylacksactualprimary/replcallbacks, fullgatecannotbepassedbyAPI84alone.','generalMandatoryGaps':['customfactory/keykind selection','isCached=false','URI equality/aliascache','publicprimary/repllifecycle','import*perentryadmission','cross-evaluatorJVMsingletonlifetime']}
(O/'consumer-profile.json').write_text(json.dumps(profile,indent=2)+'\n');print(json.dumps(profile,indent=2))
