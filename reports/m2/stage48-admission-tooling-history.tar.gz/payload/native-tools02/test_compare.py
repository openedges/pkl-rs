import hashlib,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import compare as m
class FrozenAdmission(unittest.TestCase):
 def setUp(self):
  (m.O/'tests-private').mkdir(exist_ok=True);self.tmp=tempfile.TemporaryDirectory(dir=m.O/'tests-private');self.root=Path(self.tmp.name);self.snapshot=self.root/'sources';self.snapshot.mkdir();self.mapping={}
  for rel,local in [('crates/pkl-runtime/examples/stage48_policy_probe.rs',m.O/'stage48_policy_probe.rs'),('crates/pkl-runtime/examples/stage48_policy_probe/file_host.rs',m.O/'stage48_policy_probe/file_host.rs')]:
   p=self.snapshot/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(local.read_bytes());self.mapping[rel]=m.sha(p)
  self.binary=self.root/'stage48_policy_probe';self.binary.write_bytes(b'Not executable: preflight unit test only');self.mapfile=self.root/'source-after.json';self.release=self.root/'release.json';self.record={'artifacts':{'stage48_policy_probe':{'path':str(self.binary),'sha256':m.sha(self.binary)}},'source_map':str(self.mapfile),'source_map_sha256':'','source_snapshot':str(self.snapshot)};self.save()
 def tearDown(self):self.tmp.cleanup()
 def save(self):self.mapfile.write_text(json.dumps(self.mapping));self.record['source_map_sha256']=m.sha(self.mapfile);self.release.write_text(json.dumps(self.record));self.pin=m.sha(self.release)
 def run_preflight(self):
  with patch.object(m.fixtures,'verify',return_value={'unitMock':'Input verifier has separate actual integration/tamper tests'}):return m.preflight(self.root,self.release,self.pin,m.fixtures.POLICY,m.fixtures.POLICY_TOOL)
 def test_exact_release_source_and_artifact_admitted_without_execution(self):
  with patch.object(m.subprocess,'Popen',side_effect=AssertionError('preflight cannot execute')):self.assertEqual(self.run_preflight()[2],self.binary)
 def test_artifact_tamper_rejected(self):
  self.binary.write_bytes(b'tamper')
  with self.assertRaisesRegex(ValueError,'artifact pin'):self.run_preflight()
 def test_source_snapshot_tamper_rejected(self):
  p=self.snapshot/'crates/pkl-runtime/examples/stage48_policy_probe.rs';p.write_bytes(b'changed')
  with self.assertRaisesRegex(ValueError,'frozen adapter'):self.run_preflight()
 def test_forged_map_rebound_release_still_rejects_wrong_adapter(self):
  self.mapping['crates/pkl-runtime/examples/stage48_policy_probe.rs']='0'*64;self.save()
  with self.assertRaisesRegex(ValueError,'frozen adapter'):self.run_preflight()
 def test_old_renderer_artifact_is_not_policy_probe(self):
  self.record['artifacts']={'stage47_renderer_probe':self.record['artifacts']['stage48_policy_probe']};self.save()
  with self.assertRaises(KeyError):self.run_preflight()
 def test_release_pin_mismatch_rejected(self):
  self.release.write_bytes(b'{}')
  with self.assertRaisesRegex(ValueError,'release pin'):self.run_preflight()
 def test_old_bb4b_source_rejected_even_when_release_map_and_snapshot_match_it(self):
  rel='crates/pkl-runtime/examples/stage48_policy_probe.rs';old=m.O.parent/'stage48-policy-native-consumer-01/stage48_policy_probe.rs';(self.snapshot/rel).write_bytes(old.read_bytes());self.mapping[rel]=m.sha(old);self.save()
  with self.assertRaisesRegex(ValueError,'frozen adapter'):self.run_preflight()
 def test_permanent_path_keeps_every_original_expected_byte_and_operation(self):
  old=m.O.parent/'stage48-policy-native-consumer-01/inputs-02';new=m.O/'inputs';a=json.loads((old/'inputs.json').read_bytes());b=json.loads((new/'inputs.json').read_bytes());a['policy84'].pop('rawFixture');b['policy84'].pop('rawFixture');self.assertEqual(a,b)
  manifest=json.loads((new/'manifest.json').read_bytes())
  for relative in manifest['files']:
   if relative!='inputs.json':self.assertEqual((old/relative).read_bytes(),(new/relative).read_bytes())
if __name__=='__main__':unittest.main()
