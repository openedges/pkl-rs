# Stage48 C01 native policy consumer admission

This separate version accepts the exact integrated adapter `7d63fb3a...`, preserving the sealed `bb4b0a77...` proposal. The only source difference is one explicit Rust generic collection type in UTF16 cause decoding. No expected value, authored Java source or Host policy was rewritten.

The installed policy84 fixture and original verifier retain their literal pins. `inputs` contains the same 652 Java observations, 6,300 events, sources, operations and captured causes as proposal01. Only the provenance location of the policy84 fixture changes to its permanent repository path. Eight actual preflight/input-equivalence tests, authenticated CLI verification and rustfmt passed. These checks are not native evaluator results.

`release-binding.json` records the CLOSED C01 release. `compare.py` authenticates its literal hash, artifact, source map and exact two-file adapter snapshot. No older renderer adapter, earlier bb4b source, or different artifact is admitted. `launch.py` preserves actual process PID, command, source pins, raw streams and waited terminal in a separate fresh launch root. The comparison output is also fresh.

The authorized attempt set is 440 APIs in 52 sessions. Another 212 general factory/key-kind, uncached and factory-error calls remain explicitly unexecuted; their original expected bytes/events remain present. Original 16 alias-name lookup failures and 36 lazy-cycle observations remain raw data without intended catch/init-failure coverage. Corrective02 is separate.

Raw API byte equality and full lifecycle gates are distinct. The supplied-primary SourceProbe lacks actual Java primary/repl/factory/path callbacks. Native counters use their own observed requests/import/resolve/event schema; the complete Java counter bytes remain strict unequal requirements. No expected event insertion, normalization, fabricated primary/repl callback or full M2 completion claim is allowed. Java JVM-global/cross-evaluator lifetime and GC schedules remain separate boundaries.
