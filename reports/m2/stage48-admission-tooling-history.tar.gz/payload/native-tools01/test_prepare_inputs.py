import copy,hashlib,json,os,shutil,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import prepare_inputs as m
O=Path(__file__).parent.resolve()
class Inputs(unittest.TestCase):
 def setUp(self):
  (O/'tests-private').mkdir(exist_ok=True);self.tmp=tempfile.TemporaryDirectory(dir=O/'tests-private');self.root=Path(self.tmp.name)/'inputs';shutil.copytree(O/'inputs-02',self.root)
 def tearDown(self):self.tmp.cleanup()
 def rewrite(self,rel,data):
  (self.root/rel).write_bytes(data);p=self.root/'manifest.json';v=json.loads(p.read_bytes());v['files'][rel]={'sha256':m.sha(data),'bytes':len(data)};p.write_text(json.dumps(v))
 def test_normal_reauthenticates_all_producers(self):
  r=m.verify(self.root);self.assertEqual((r['javaApiCalls'],r['runnableApiCalls'],r['unexecutedApiCalls']),(652,440,212));self.assertEqual(r['evaluations'],0)
 def test_forged_api_counter_outer_manifest_rejected(self):
  v=json.loads((self.root/'inputs.json').read_bytes());v['cases'][0]['expected'][0]['counterBytesBeforeHex']='00';self.rewrite('inputs.json',json.dumps(v).encode())
  with self.assertRaises(ValueError):m.verify(self.root)
 def test_forged_raw_channel_outer_manifest_rejected(self):
  v=json.loads((self.root/'inputs.json').read_bytes());v['cases'][0]['expected'][0]['stdoutHex']='00';self.rewrite('inputs.json',json.dumps(v).encode())
  with self.assertRaises(ValueError):m.verify(self.root)
 def test_forged_cause_outer_manifest_rejected(self):
  b=(self.root/'causes.tsv').read_bytes();self.rewrite('causes.tsv',b.replace(b'0052',b'0053',1))
  with self.assertRaises(ValueError):m.verify(self.root)
 def test_forged_source_outer_manifest_rejected(self):
  rel=json.loads((self.root/'inputs.json').read_bytes())['cases'][0]['source'];self.rewrite(rel,b'stable=99\n')
  with self.assertRaises(ValueError):m.verify(self.root)
 def test_unknown_regular_payload_rejected(self):
  self.rewrite('extra.bin',b'extra')
  with self.assertRaises(ValueError):m.verify(self.root)
 def test_unknown_directory_rejected_before_descent(self):
  extra=self.root/'cargo-target';extra.mkdir();(extra/'sentinel').write_text('must not walk');original=os.scandir;entered=[]
  def scan(path):
   if Path(path)==extra:entered.append(str(path));raise AssertionError('descended unknown directory')
   return original(path)
  with patch.object(os,'scandir',side_effect=scan):
   with self.assertRaisesRegex(ValueError,'before descent'):m.verify(self.root)
  self.assertEqual(entered,[])
 def test_symlink_root_rejected_before_walk(self):
  link=Path(self.tmp.name)/'link';link.symlink_to(self.root,target_is_directory=True)
  with patch.object(os,'walk',side_effect=AssertionError('must reject before walk')):
   with self.assertRaisesRegex(ValueError,'before traversal'):m.verify(link)
 def test_forged_inventory_rejected_before_payload_reads(self):
  producer=next(iter(m.PINS));p=Path(self.tmp.name)/'authority';p.mkdir()
  for n in ['report','inventory','closure']:shutil.copyfile(m.BASE/producer/(n+'.json'),p/(n+'.json'))
  v=json.loads((p/'inventory.json').read_bytes());v['files'].pop(next(iter(v['files'])));(p/'inventory.json').write_text(json.dumps(v))
  with self.assertRaisesRegex(ValueError,'literal'):m.Authority(p,m.PINS[producer])
if __name__=='__main__':unittest.main()
