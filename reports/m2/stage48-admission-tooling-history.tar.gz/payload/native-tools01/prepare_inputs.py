"""Authenticated Java-to-native input tables. No evaluator and no Rust-derived expectation."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,stat,sys
sys.dont_write_bytecode=True
BASE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2')
POLICY=BASE/'stage48-policy84-fixtures-01';POLICY_TOOL=BASE/'stage48-policy84-tools-01/policy_fixtures.py'
POLICY_MANIFEST='6a4d5b2c8d394108c8a0ee98b33bbc5fd20525aa467da7e68e1799b8cea8ab72'
POLICY_TOOL_SHA='d1f91dc9a44b8d1a9291f4b8b65aa35ea2e295ec74c2fb521a44ecdf89227739'
PINS={
 'stage48-module-admission-oracle-01':('dcaa95e8eab8b1a7efda01d2494758d44e5045abe7c75eb79224e0079d768efc','11f1dbb9c1fc0b57761075c6ef9bf618210462f9f7ecefe32f02402cc7e41b29','40750b468c747e60b09f35ede8839983edd5400883b8731a2a2f85f3d173fcfd'),
 'stage48-module-admission-oracle-02':('a8177501de17fcf9b2f20a8e449b52a91f7320481c403df16a6ff4d26ec2132a','5b9cfd51d1034202711c723ad226ce658e8a0c0aa551973b6ccf7374a5076294','05fd544f76db57d0677bed6923a3a54d098f4308e77c734ebf921457338fa5e3')}
UNSUPPORTED={
 'custom-resolved-importer':'General custom ModuleKeyFactory/original→resolved key contract not exposed by current SourceProbe.',
 'resolved-cache-alias-no-original-seed':'General custom factory and original/resolved alias cache not exposed.',
 'uncached-policy-toggle':'ModuleKey.isCached=false and dynamic factory policy not exposed; Host must not emulate cache.',
 'custom-key-pkl-uri-not-stdlib-kind':'General custom factory key-kind selection not exposed; URI string must not masquerade as key kind.',
 'resolved-nested-jar-default-trust':'Custom resolved jar key not exposed; direct trust Java matrix remains separate.',
 'clause-unused-no-loader':'AST ModuleResolver factory-selection effect not exposed as public typed Host request.',
 'expr-unused-no-loader':'General no-loader factory-selection effect not exposed.',
 'clause-unused-factory-throw':'AST custom factory IOException not exposed as public typed Host request.',
 'expr-unused-factory-throw':'General custom factory IOException not exposed.'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def check(ok,msg):
 if not ok:raise ValueError(msg)
def safe(rel):
 p=Path(rel);check(not p.is_absolute() and '..' not in p.parts and str(p)==rel,'unsafe relative path');return p

def regular(root,rel):
 p=root;check(stat.S_ISDIR(p.lstat().st_mode),'regular authority root')
 for part in safe(rel).parts[:-1]:p=p/part;check(stat.S_ISDIR(p.lstat().st_mode),'regular authority parent')
 p=p/safe(rel).name;check(stat.S_ISREG(p.lstat().st_mode),'regular authority payload');return p.read_bytes()

class Authority:
 def __init__(self,root,pins):
  self.root=root;docs=[regular(root,n+'.json')for n in ['report','inventory','closure']];check(tuple(map(sha,docs))==pins,'literal report/inventory/closure pins');self.report,self.inventory,self.closure=map(json.loads,docs);check(self.closure['sealed'] and self.closure['inventorySha256']==pins[1] and self.closure['reportSha256']==pins[0] and not self.closure['liveHandles'],'sealed producer binding');self.rows=self.inventory['files'];self.used={}
 def get(self,rel):
  row=self.rows[rel];check(row['kind']=='regular','regular selected payload');data=regular(self.root,rel);check(sha(data)==row['sha256'] and len(data)==row['bytes'],'pinned inventory raw payload');self.used[rel]={'sha256':sha(data),'bytes':len(data)};return data

def normalized_operation(kind,value):return kind+'\t'+value.encode().hex()+'\n'
def construct():
 check(sha(regular(POLICY,'manifest.json'))==POLICY_MANIFEST,'literal policy manifest');check(sha(POLICY_TOOL.read_bytes())==POLICY_TOOL_SHA,'literal original policy verifier source')
 spec=importlib.util.spec_from_file_location('original_policy_verifier',POLICY_TOOL);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.verify(POLICY)
 bundle=json.loads(regular(POLICY,'fixtures.json'));files={};cases=[];proof={};cause_rows={};causes_proof=[]
 def add_case(cohort,id,repeat,session,source,uri,name,mode,operations,expected,events,counters_final,raw_scope,runnable=True,reason=None):
  key=f'{cohort}/{id}/{repeat}/{session}';relative='cases/'+key;files[relative+'/source.pkl']=source;files[relative+'/operations.tsv']=''.join(normalized_operation(k,v)for k,v in operations).encode();cases.append({'key':key,'cohort':cohort,'id':id,'repeat':repeat,'session':session,'source':relative+'/source.pkl','operations':relative+'/operations.tsv','uri':uri,'moduleName':name,'initialPolicy':mode,'runnable':runnable,'unexecutedReason':reason,'expected':expected,'javaOrderedEvents':events,'javaFinalCounters':counters_final,'scope':raw_scope})
 for f in bundle['fixtures']:
  operations=[('gc','')if op=='GC'else('evaluate',op[1])for op in f['operations']]
  add_case('policy84',f['id'],f['repeat'],f['session'],f['source'].encode(),f['uri'],f['moduleName'],f['policyProfile']['mode'],operations,f['expected'],f['orderedEvents'],f.get('finalCounters'),{'producer':'originalJava06','eventEncoding':'JavaUTF8only/allASCII; no independent event UTF16','fullEventGate':'All280 ordered original events/counters required; missing primary/repl must remain mismatch.','publicApi':'Original Evaluator differs from supplied-primary SourceProbe.'})
 for producer,pins in PINS.items():
  a=Authority(BASE/producer,pins);r=a.report;authored=json.loads(a.get('cases.json'));case_map={c['id']:c for c in authored}
  check(not r['inputChanges'] and r['workspacesUnchanged'] and r['jarStable'],'producer input stable')
  for observation in r['observations']:
   c=case_map[observation['case']];source_rel='workspace/'+c['id']+'/'+c['entry']
   for input_rel in c['inputPaths']:
    relative='workspace/'+c['id']+'/'+input_rel
    if a.rows[relative]['kind']=='regular':
     authored_bytes=a.get(relative);check(sha(authored_bytes)==r['inputHashes'][str(Path(c['workspace'])/input_rel)],'all authored Host files bound to producer input')
   if a.rows[source_rel]['kind']=='symlink':
    row=a.rows[source_rel];parent=BASE/producer/Path(source_rel).parent;check(os.readlink(parent/c['entry'])==row['target'],'source symlink target');source=a.get(str(safe(str(Path(source_rel).parent/row['target']))));check(sha(source)==row['targetPayloadSha256'],'source symlink payload')
   else:source=a.get(source_rel)
   check(sha(source)==r['inputHashes'][str(Path(c['workspace'])/c['entry'])],'source bound producer input')
   for session in observation['sessions']:
    calls=[x for x in observation['calls']if x['session']==session['session']];expected=[];ev=[];mode=c['mode'];session_rel=f"cases/{c['id']}/{observation['repeat']}/calls/session-{session['session']}"
    for event in session['events']:
     p=event['rawPrefix'];raw=a.get(p+'.bin');units=a.get(p+'.code-units.bin');check(raw.hex()==event['utf8Hex'] and units.hex()==event['utf16BEHex'],'event pinned report binding');ev.append(event)
     if raw.startswith(b'policy-profile '):mode=raw.decode().removeprefix('policy-profile ')
     if raw.startswith(b'actual-') and b'-denied 'in raw:
      i=int(raw.rsplit(b'denial=',1)[1]);pre=session_rel+'/denial-'+str(i);kind=a.get(pre+'.kind.bin').decode();context=a.get(pre+'.context.bin').decode();null=a.get(pre+'.message-null.bin').decode();message=a.get(pre+'.message.code-units.bin');raw_message=a.get(pre+'.message.bin');check(message.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==raw_message,'actual raw cause encodings');row='\t'.join([mode.encode().hex(),kind,context.encode().hex(),null,message.hex()]);key=(mode,kind,context);check(key not in cause_rows or cause_rows[key]==row,'conflicting raw cause inputs');cause_rows[key]=row;causes_proof.append({'producer':producer,'rawPrefix':pre,'mode':mode,'kind':kind,'context':context,'messageUtf16Sha256':sha(message),'messageUtf8Sha256':sha(raw_message),'null':null})
    for call in calls:
     p=call['rawPrefix'];check(not call['missingFields'],'missing API capture');status=a.get(p+'.status.bin');check(status in [b'success\n',b'error\n'] and status.decode()==call['status'],'exact status report binding')
     e={'status':status.decode().removesuffix('\n'),'javaRawPrefix':str(BASE/producer/p),'javaErrorClass':call['errorClass'],'javaMessageNull':call['messageNull']}
     for channel in ['stdout','stderr']:
      b=a.get(p+'.'+channel+'.bin');u=a.get(p+'.'+channel+'.code-units.bin');check(b.hex()==call[channel+'Utf8Hex'] and u.hex()==call[channel+'Utf16BEHex'],'channel report/raw binding');e[channel+'Hex']=b.hex();e[channel+'Units']=[int.from_bytes(u[i:i+2],'big')for i in range(0,len(u),2)]
     for when in ['Before','After']:
      b=a.get(p+'.counters-'+when.lower()+'.bin');check(b.decode()==call['counters'+when],'counter report/raw binding');e['counterBytes'+when+'Hex']=b.hex()
     expected.append(e)
    operations=[]
    for op in c['operations']:
     if op['kind']=='evaluate':check(op['source']==c['entry'],'multiple-source root API not exposed');operations.append(('evaluate',op['expression']))
     elif op['kind']=='gc':operations.append(('gc',''))
     else:operations.append((op['kind'],op['value']))
    reason=UNSUPPORTED.get(c['id']);add_case(producer.removeprefix('stage48-module-admission-'),c['id'],observation['repeat'],session['session'],source,c['sourceUri'],Path(c['entry']).stem,c['mode'],operations,expected,ev,session['counters'],{'producer':producer,'eventEncoding':'Independent JavaUTF16/JavaUTF8','intent':c['scope'],'fullEventGate':'Actual primary/repl/factory/getter/security path must not be synthesized; full parity distinct from API parity.'},not reason,reason)
  proof[producer]={'root':str(a.root),'pins':list(pins),'selectedPinnedPayloads':a.used,'directTrustMatrix':'392 direct Java APIs in01; not Evaluator and not native module execution.'}
 files['causes.tsv']=(''.join(cause_rows[key]+'\n'for key in sorted(cause_rows))).encode()
 result={'schema':1,'profile':'provided-primary-policy-v1','cases':cases,'javaApiCalls':sum(len(c['expected'])for c in cases),'runnableApiCalls':sum(len(c['expected'])for c in cases if c['runnable']),'unexecutedApiCalls':sum(len(c['expected'])for c in cases if not c['runnable']),'javaOrderedEvents':sum(len(c['javaOrderedEvents'])for c in cases),'causeInputsProvenance':causes_proof,'producerProvenance':proof,'policy84':{'manifestSha256':POLICY_MANIFEST,'verifierSha256':POLICY_TOOL_SHA,'rawFixture':str(POLICY)},'mandatoryScope':['Full Java trace/counter gate remains distinct and failing where actual primary/repl lifecycle is absent.','16 original query test-name failures remain raw but excluded from intended guest-catch coverage.','36 original lazy cycle APIs remain raw but excluded from init-failure coverage; corrected02 is separate.','No customfactory/uncached/factory-error/import* fallback; unsupported profiles explicitly unexecuted.','Java System.gc request and per-native-poll/explicit collect differ; no observed Java collection claim.','No JVM error-class equivalence claim for Rust SourceSession.']}
 files['inputs.json']=(json.dumps(result,indent=2)+'\n').encode();return files,result

def export(output):
 check(not output.exists(),'fresh input output required');files,result=construct();output.mkdir(parents=True)
 for rel,data in files.items():p=output/safe(rel);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 (output/'manifest.json').write_text(json.dumps({'schema':1,'files':{rel:{'sha256':sha(data),'bytes':len(data)}for rel,data in files.items()}},indent=2)+'\n');return verify(output)
def verify(output):
 check(stat.S_ISDIR(output.lstat().st_mode),'regular input root before traversal');files,result=construct();expected=set(files)|{'manifest.json'};allowed={str(p)for rel in expected for p in safe(rel).parents};found=set()
 for current,dirs,names in os.walk(output,followlinks=False):
  check(stat.S_ISDIR(Path(current).lstat().st_mode),'regular input directory')
  for name in dirs:check(str((Path(current)/name).relative_to(output))in allowed and stat.S_ISDIR((Path(current)/name).lstat().st_mode),'undeclared input directory before descent')
  for name in names:found.add(str((Path(current)/name).relative_to(output)))
 check(found==expected,'exact input payload coverage');manifest=json.loads(regular(output,'manifest.json'));check(set(manifest['files'])==set(files),'manifest exact coverage')
 for rel,data in files.items():actual=regular(output,rel);check(actual==data and manifest['files'][rel]=={'sha256':sha(data),'bytes':len(data)},'pinned reconstructed input bytes')
 return {'schema':1,'javaApiCalls':result['javaApiCalls'],'runnableApiCalls':result['runnableApiCalls'],'unexecutedApiCalls':result['unexecutedApiCalls'],'sessions':len(result['cases']),'runnableSessions':sum(c['runnable']for c in result['cases']),'javaOrderedEvents':result['javaOrderedEvents'],'files':len(expected),'manifestSha256':sha(regular(output,'manifest.json')),'evaluations':0}
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--verify',action='store_true');parser.add_argument('--fixtures',type=Path,default=POLICY);parser.add_argument('--policy-verifier',type=Path,default=POLICY_TOOL);args=parser.parse_args();POLICY=args.fixtures.resolve();POLICY_TOOL=args.policy_verifier.resolve();print(json.dumps(verify(args.output)if args.verify else export(args.output),indent=2))
