from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
O=Path(__file__).parent.resolve();checks=O/'checks-04';checks.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();files=['compare.py','test_compare.py','stage48_policy_probe.rs','stage48_policy_probe/file_host.rs','prepare_inputs.py','test_prepare_inputs.py','check04.py'];before={n:sha(O/n)for n in files};results=[]
for name,cmd in [('preflight-tests',[sys.executable,'-m','unittest','-v','test_compare.py'])]:
 d=checks/name;d.mkdir();row={'command':cmd,'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'PYTHONDONTWRITEBYTECODE':'1'}}
 with(d/'stdout.bin').open('wb')as out,(d/'stderr.bin').open('wb')as err:
  p=subprocess.Popen(cmd,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=p.pid;(d/'launch.json').write_text(json.dumps(row,indent=2)+'\n');row['exitCode']=p.wait()
 row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha(d/'stdout.bin'),stderrSha256=sha(d/'stderr.bin'));(d/'terminal.json').write_text(json.dumps(row,indent=2)+'\n');results.append(row)
after={n:sha(O/n)for n in files};report={'commands':results,'sourceBefore':before,'sourceAfter':after,'sourceStable':before==after,'inputManifestSha256':sha(O/'inputs-02/manifest.json'),'testsPrivateDirectory':str(O/'tests-private'),'evaluations':0,'rustBuilds':0,'scope':'Tool/tamper/preflight tests only; no native or Java evaluation.'};(checks/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(0 if before==after and all(r['exitCode']==0 for r in results)else 1)
