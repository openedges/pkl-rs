"""Frozen-release-only comparison proposal. Default is preflight; no builds or Java execution."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,subprocess,sys,time
sys.dont_write_bytecode=True
import prepare_inputs as fixtures
O=Path(__file__).parent.resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def check(ok,message):
 if not ok:raise ValueError(message)
def preflight(inputs,release,release_sha,policy,verifier):
 fixtures.POLICY=policy;fixtures.POLICY_TOOL=verifier;proof=fixtures.verify(inputs)
 check(sha(release)==release_sha,'explicit release pin');r=json.loads(release.read_bytes());artifact=r['artifacts']['stage48_policy_probe'];binary=Path(artifact['path']);check(sha(binary)==artifact['sha256'],'released native artifact pin')
 source_map=Path(r['source_map']);check(sha(source_map)==r['source_map_sha256'],'released source map pin');mapping=json.loads(source_map.read_bytes());snapshot=Path(r['source_snapshot'])
 for relative,local in [('crates/pkl-runtime/examples/stage48_policy_probe.rs',O/'stage48_policy_probe.rs'),('crates/pkl-runtime/examples/stage48_policy_probe/file_host.rs',O/'stage48_policy_probe/file_host.rs')]:
  expected=sha(local);check(mapping.get(relative)==expected and sha(snapshot/relative)==expected,'exact frozen adapter source '+relative)
 return proof,r,binary

def main():
 p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--release',type=Path,required=True);p.add_argument('--release-sha256',required=True);p.add_argument('--fixtures',type=Path,default=fixtures.POLICY);p.add_argument('--policy-verifier',type=Path,default=fixtures.POLICY_TOOL);p.add_argument('--output',type=Path,required=True);p.add_argument('--execute',action='store_true');a=p.parse_args()
 proof,r,binary=preflight(a.inputs,a.release,a.release_sha256,a.fixtures,a.policy_verifier);check(not a.output.exists(),'fresh output directory');a.output.mkdir(parents=True);bundle=json.loads((a.inputs/'inputs.json').read_bytes());tool_sources={str(q.relative_to(O)):sha(q)for q in [Path(__file__),O/'prepare_inputs.py',O/'stage48_policy_probe.rs',O/'stage48_policy_probe/file_host.rs']};source_before={str(path):fixtures.sha(Path(path).read_bytes())for producer in bundle['producerProvenance'].values()for path in json.loads((Path(producer['root'])/'report.json').read_bytes())['inputHashes']}
 write(a.output/'preflight.json',{'release':str(a.release),'releaseSha256':a.release_sha256,'artifact':str(binary),'artifactSha256':sha(binary),'sourceMapSha256':r['source_map_sha256'],'inputs':str(a.inputs),'inputProof':proof,'toolSources':tool_sources,'execute':a.execute,'sourceBefore':source_before,'scope':'Supplied-primary SourceProbe only. Full Java event/counter lifecycle remains a separate strict gate.'})
 if not a.execute:return
 records=[];unexecuted=[]
 for case in bundle['cases']:
  if not case['runnable']:unexecuted.append({'key':case['key'],'apis':len(case['expected']),'reason':case['unexecutedReason']});continue
  target=a.output/case['key'];target.mkdir(parents=True);command=[str(binary),str(a.inputs/case['source']),case['uri'],case['moduleName'],str(a.inputs/case['operations']),str(target/'raw'),'1',case['initialPolicy'],str(a.inputs/'causes.tsv'),bundle['profile']];row={'key':case['key'],'command':command,'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'TZ':'UTC','LANG':'C','LC_ALL':'C'}}
  with(target/'stdout.bin').open('wb')as out,(target/'stderr.bin').open('wb')as err:
   proc=subprocess.Popen(command,cwd=O,env={**os.environ,**row['environment']},stdout=out,stderr=err);row['pid']=proc.pid;write(target/'launch.json',row)
   try:row['exitCode']=proc.wait(timeout=120);row['timedOut']=False
   except subprocess.TimeoutExpired:proc.kill();row['exitCode']=proc.wait();row['timedOut']=True
  row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha(target/'stdout.bin'),stderrSha256=sha(target/'stderr.bin'));write(target/'terminal.json',row)
  raw=target/'raw/session-0';outcomes=[]
  for i,e in enumerate(case['expected']):
   prefix=raw/f'outer-{i}';required=[prefix.with_name(prefix.name+'.'+suffix)for suffix in ['status.bin','stdout.bin','stderr.bin','stdout.code-units.bin','stderr.code-units.bin']];missing=[str(q.relative_to(target))for q in required if not q.is_file()];parts={}
   if not missing:
    parts['status']=required[0].read_bytes()==e['status'].encode()+b'\n'
    for channel in ['stdout','stderr']:
     parts[channel+'JavaUtf8']=(raw/f'outer-{i}.{channel}.bin').read_bytes().hex()==e[channel+'Hex'];parts[channel+'Utf16BE']=(raw/f'outer-{i}.{channel}.code-units.bin').read_bytes()==b''.join(u.to_bytes(2,'big')for u in e[channel+'Units'])
   outcomes.append({'index':i,'missing':missing,'comparisons':parts,'pass':not missing and all(parts.values())})
  native_events=[];count=0
  while(raw/f'event-{count}.text.bin').is_file():native_events.append((raw/f'event-{count}.text.bin').read_bytes().hex());count+=1
  java_events=[e['utf8Hex']for e in case['javaOrderedEvents']];full_event_match=native_events==java_events
  counter_matches=[]
  for i,e in enumerate(case['expected']):
   for when in ['Before','After']:
    q=raw/f'outer-{i}.counters-{when.lower()}.bin';counter_matches.append(q.is_file() and q.read_bytes().hex()==e['counterBytes'+when+'Hex'])
  result={'process':row,'api':outcomes,'rawApiPass':sum(x['pass']for x in outcomes),'rawApiMismatchOrUnexecuted':sum(not x['pass']for x in outcomes),'nativeEvents':native_events,'javaEvents':java_events,'fullEventBytesEqual':full_event_match,'fullCounterBytesEqual':all(counter_matches),'fullLifecyclePass':full_event_match and all(counter_matches),'nativeTerminalSlots':(raw/'terminal-slots.bin').read_text()if(raw/'terminal-slots.bin').is_file()else None,'javaErrorClassMetadataOnly':True,'constructorBoundary':(raw/'constructor.status.bin').read_text()if(raw/'constructor.status.bin').is_file()else None};write(target/'comparison.json',result);records.append(result);write(a.output/'progress.json',{'terminalProcesses':len(records),'lastCase':case['key']})
 after={path:fixtures.sha(Path(path).read_bytes())for path in source_before};same_artifact=sha(binary)==r['artifacts']['stage48_policy_probe']['sha256'];tool_stable=tool_sources=={rel:sha(O/rel)for rel in tool_sources};post=fixtures.verify(a.inputs)
 report={'scope':'Raw API and strict full event/counter gates are distinct; supplied-primary missing lifecycle remains mismatch, never synthetic. No full M2 completion claim.','records':records,'unexecutedProfiles':unexecuted,'rawApiPass':sum(x['rawApiPass']for x in records),'rawApiMismatchOrUnexecuted':sum(x['rawApiMismatchOrUnexecuted']for x in records),'explicitUnexecutedApiCalls':sum(x['apis']for x in unexecuted),'fullLifecyclePassSessions':sum(x['fullLifecyclePass']for x in records),'fullLifecycleFailSessions':sum(not x['fullLifecyclePass']for x in records),'sourceChanges':[p for p in source_before if source_before[p]!=after[p]],'artifactStable':same_artifact,'toolsStable':tool_stable,'inputsAfter':post,'allProcessesTerminal':True,'liveHandles':[]};write(a.output/'report.json',report)
 # Raw compatibility failures are report data; process/integrity failure is separately reflected by this exit.
 return 0 if not report['sourceChanges'] and same_artifact and tool_stable and all(x['process']['exitCode']==0 and not x['process']['timedOut']for x in records)else 1
if __name__=='__main__':raise SystemExit(main())
