# Stage48 native policy consumer 제안

1. 원래 Java06 policy84와 fresh Java01/02의 report/inventory/closure literal pin을 인증하고 모든 선택 원문·raw 채널·counter·event를 재연결합니다.
2. 실제 raw SecurityManagerException cause만 Host 입력으로 사용합니다. 공통 runtime의 CheckImport/default policy/URI/cache를 Host에서 재구현하지 않습니다.
3. 새 frozen candidate 또는 명시 승인된 isolated snapshot에 두 Rust adapter source를 바인딩한 뒤 root/A가 빌드합니다. 현재 빌드·native 실행 결과는 없습니다.
4. API raw 비교, 실제 typed 요청 ledger, 전체 Java event/counter gate를 분리합니다. primary/repl/factory lifecycle 부재는 실제 mismatch/미실행으로 유지합니다.
5. 652 API 원문 중 440 실행 가능 제안과 212 custom SPI 미실행을 모두 보존합니다. 기존 의도 미도달 16+36은 교정02로 원문을 대체하지 않습니다.
