# Stage48 native admission evidence adapter proposal

This target-only proposal consumes the original Java06 policy84 capture and the fresh Java admission01/02 controls. It is not a compatibility result. No native build or evaluation is recorded here.

`prepare_inputs.py --output NEW_DIRECTORY` authenticates literal producer report, inventory and closure hashes, binds every selected source, raw channel, event and counter to those inventories, and derives the native operations and raw SecurityManagerException cause table. The table contains actual captured Host policy inputs, not formatted Pkl diagnostics. `--verify` reconstructs those inputs and rejects changed expectations, counters, causes, undeclared payloads and directories before descent.

The current input package retains 652 Evaluator calls and 6,300 ordered Java events across 88 sessions. It proposes 440 calls in 52 sessions for the supplied-primary SourceProbe adapter. Another 212 calls in 36 sessions remain explicitly unexecuted because the public runtime does not expose their general factory/key-kind, uncached or factory-error contract. The separate 392 direct SecurityManager API calls remain Java observations; they are not evaluator comparisons.

The original 16 query-local `test` name failures and 36 lazy-cycle calls are retained as raw observations, without counting their intended catch or initialization-failure coverage. Corrective02 has separate sources, URIs and raw outcomes. It reaches guest catch/catchOrNull and eager type-initialization failure, saved partial receiver success and fresh-site cached-error replay.

## Adapter contract

```
stage48_policy_probe SOURCE URI NAME OPERATIONS OUTPUT SESSIONS POLICY CAUSES provided-primary-policy-v1
```

Operations are `evaluate`, `gc` or `policy`, followed by a tab and UTF8 hex. Causes have five tab-separated fields: policy UTF8 hex, raw cause kind (`import` or `module`), actual context UTF8 hex, literal nullable-message flag and raw message UTF16BE hex. Unsupported operations cause an acquisition failure rather than a cache or factory emulation.

The Host records every actual typed module request, token, id, API index, URI context and chosen completion. Policy denial uses an exact captured cause only. A missing required cause yields explicit Unsupported, never a synthesized formatted exception. Other supported requests explicitly delegate to `complete_default_module`, then to the file Host. The Host performs actual file canonicalization/source loading and does not implement URI resolution, import-site or module caching.

The file companion comes from A's explicit development file Host source, with its unit-test block omitted and rustfmt applied. Its source receipt records those transformations. It is a separate adapter source, not a byte-identical claim about the old Stage47 renderer probe.

## Strict gates remain separate

Raw API status, stdout and stderr are compared independently in UTF16BE and JavaUTF8. Java exception-class metadata remains available but is not equated with the Rust public API. Constructor rejection, unexpected transport events, poll bounds and process failures remain failures or unexecuted boundaries.

All original Java events and counters remain strict requirements. The supplied-primary adapter has no actual Java primary/repl module lifecycle, factory callbacks or `resolveSecurePath` callback. It must not synthesize those events, copy expected events into actual output, or label a shorter trace as full parity. Any later admission-only diagnostic projection is separately named and does not replace the full trace/counter gate. Java `System.gc()` is a request; per-poll and explicit native collection are different execution schedules.

A/root must compile the exact proposed files only against an explicitly approved immutable source snapshot or released candidate. Bind the resulting artifact, release/source-map and adapter hashes before execution. Keep all evidence in fresh target directories; do not mutate production, original captures or Git.

The native observer counter schema is `requests/import/resolve/event`; it is not the Java helper's eight- or twelve-field counter schema. The current full-counter raw comparison therefore remains unequal, including this adapter capability/schema boundary, rather than serving as proof of a runtime-only defect. All original Java counter bytes remain in authenticated expectations. An implementation of the complete lifecycle requires a corresponding actual observer, not counter translation or expected-value insertion.

The proposed launcher uses one native process and one SourceProbe session per captured Java session. Original Java used two sequential Evaluators per JVM. JVM-global singleton lifetime and cross-evaluator behavior are therefore explicitly outside this adapter's parity claim. GC schedules also differ as described above.

Use `prepare_inputs.py --fixtures PERMANENT_POLICY84_PATH --policy-verifier ORIGINAL_OR_INSTALLED_BYTE_IDENTICAL_VERIFIER --output FRESH_INPUTS` for a permanent fixture location. The original fixed manifest and verifier source hashes remain mandatory. `compare.py` accepts the same fixture/verifier options. It defaults to preflight and requires `--execute`, an explicit release hash, a released `stage48_policy_probe` artifact and exact adapter/companion hashes in the immutable source map and snapshot before any native process may run. No frozen Stage48 candidate has been supplied to or executed by this proposal.
