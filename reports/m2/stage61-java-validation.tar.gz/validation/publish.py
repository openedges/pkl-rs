"""Publish and fully read back Stage 61 Java authority validation and raw history."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
VALIDATION = Path(__file__).resolve().parent
REPORTS = ROOT / "reports/m2"
HISTORY = [
    ("exploration-01", ROOT / "target/m2/stage61-intseq-java-exploration-01/capture-01", "Early authored rows exposed expression/module visibility errors."),
    ("exploration-02", ROOT / "target/m2/stage61-intseq-java-exploration-01/capture-02", "Corrected authored visibility and extended semantic exploration."),
    ("exploration-03", ROOT / "target/m2/stage61-intseq-java-exploration-01/capture-03", "Expanded to 232 exploratory rows before canonical additions."),
    ("mixed-240", ROOT / "target/m2/stage61-intseq-oracle-01", "Mixed string/export boundary and reserved-word missing-member case superseded."),
    ("math-failed-01", ROOT / "target/m2/stage61-intseq-math-constants-01", "Public expression calls could not resolve the import alias math directly."),
    ("list-failed-01", ROOT / "target/m2/stage61-intseq-list-add-01", "Untyped new object expressions had no parent class."),
]

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}

def need(ok, reason):
    if not ok:
        raise ValueError(reason)

def paths_under(root, prefix):
    need(root.is_dir() and not root.is_symlink(), "publication input directory missing or symlinked")
    result = {}
    for path in root.rglob("*"):
        need(not path.is_symlink(), "publication input contains symlink")
        if path.is_file():
            result[prefix + path.relative_to(root).as_posix()] = path
        else:
            need(path.is_dir(), "publication input contains nonregular path")
    return result

def emit_archive(path, files, scope):
    need(not path.exists(), "fresh publication archive required")
    entries = {name: source.read_bytes() for name, source in files.items()}
    before = {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in entries.items()}
    manifest = {"schema": 1, "scope": scope, "members": dict(sorted(before.items()))}
    entries["archive-manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with path.open("wb") as out:
        with gzip.GzipFile(fileobj=out, mode="wb", mtime=0, filename="") as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, raw in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(raw))
    after = {name: identity(source) for name, source in files.items()}
    need(before == after, "publication source changed while archived")
    observed = {}
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            need(member.isfile() and member.name not in observed and not member.name.startswith("/")
                 and ".." not in Path(member.name).parts, "unsafe or duplicate archive member")
            raw = archive.extractfile(member).read()
            need(len(raw) == member.size, "archive member size differs")
            observed[member.name] = raw
    need(observed == entries and json.loads(observed["archive-manifest.json"]) == manifest,
         "full archive member byte/hash readback differs")
    return {"archive": path.relative_to(ROOT).as_posix(), "identity": identity(path),
            "members": len(observed), "member_hash_readback": True,
            "source_before_after_equal": before == after,
            "embedded_manifest_sha256": sha(observed["archive-manifest.json"])}

def check_capture(label, root):
    p = json.loads((root / "provenance.json").read_bytes())
    a = json.loads((root / "audit.json").read_bytes())
    math = label.startswith("math")
    if math:
        names = (root / "names.txt").read_text().splitlines()
        need(a["rows"] == len(names) == 17, "history math rows differ")
    else:
        rows = json.loads((root / "cases.json").read_bytes())["rows"]
        need(a["rows"] == len(rows), "history case rows differ")
    need(p["complete"] is True and p["stable"] is True and p["raw_equal"] is True
         and p["raw_differences"] == [] and p["input_before"] == p["input_after"]
         and p["source_before"] == p["source_after"]
         and p["artifact_sha256"] == p["artifact_after_sha256"],
         f"history {label} source/acquisition stability differs")
    for name, expected in p["input_before"].items():
        need(identity(root / name)["sha256"] == expected, f"history {label} input differs")
    for name, expected in p["source_before"].items():
        need(identity(root / "sources" / name)["sha256"] == expected,
             f"history {label} source closure differs")
    sessions = p["sessions"]
    need(len(sessions) == 2 and [s["repeat"] for s in sessions] == [0, 1]
         and len({s["pid"] for s in sessions}) == 2
         and sessions[0]["finished_epoch"] <= sessions[1]["started_epoch"],
         f"history {label} fresh ordered JVM coverage differs")
    for session in sessions:
        repeat = session["repeat"]
        folder = root / f"repeat-{repeat}"
        need(session["exit_code"] == 0 and session["query_directories"] == a["rows"],
             f"history {label} session incomplete")
        need(identity(folder / "process.stdout.bin")["sha256"] == session["stdout_sha256"]
             and identity(folder / "process.stderr.bin")["sha256"] == session["stderr_sha256"],
             f"history {label} process hash differs")
        counts = Counter()
        if math:
            protocol = ["session-open boundary=math-constants rows=17 public-calls=34"]
            for index, name in enumerate(names):
                case = folder / f"{index:03d}-{name}"
                need(case.is_dir(), "history math row missing")
                for mode in ("string", "typed"):
                    status = (case / f"{mode}.status.bin").read_text().strip()
                    need(status in ("success", "error"), "history math row status differs")
                    counts[status] += 1
                    call = f"{mode}-{index}-{name}"
                    protocol.extend((f"call-enter={call}", f"call-exit={call} status={status}"))
            protocol.append(f"session-closed boundary=math-constants rows=17 public-calls=34 "
                            f"success={counts['success']} errors={counts['error']}")
        else:
            boundary = "string" if label.startswith("list") else "mixed"
            protocol = [f"session-open mode={boundary} rows={len(rows)}"]
            for index, row in enumerate(rows):
                case = folder / f"{index:03d}-{row['id']}"
                need(case.is_dir(), f"history {label} row missing")
                status = (case / "result.status.bin").read_text().strip()
                need(status in ("success", "error", "oracle-error", "api-exception"),
                     f"history {label} status differs")
                counts[status] += 1
                call = f"{row['mode']}-{index}-{row['id']}"
                protocol.extend((f"call-enter={call}", f"call-exit={call} status={status}"))
            protocol.append(f"session-closed mode={boundary} rows={len(rows)} public-calls={len(rows)} "
                            f"success={counts['success']} errors={len(rows)-counts['success']}")
        need((folder / "process.stdout.bin").read_bytes() == ("\n".join(protocol) + "\n").encode(),
             f"history {label} whole protocol differs")
        need(dict(counts) == a["statuses"], f"history {label} audit status differs")
    return {"rows": a["rows"], "statuses_per_session": a["statuses"],
            "pids": [s["pid"] for s in sessions], "source_stable": p["stable"],
            "raw_repetitions_equal": p["raw_equal"], "artifact_sha256": p["artifact_sha256"],
            "jdk": {name: p["jdk"][name] for name in
                    ("executable_sha256", "modules_sha256", "release_sha256")}}

def main():
    validation = json.loads((VALIDATION / "validation.json").read_bytes())
    need(validation["complete"] is True and validation["source_stable"] is True
         and validation["snapshot_matches"] is True and len(validation["checks"]) == 9
         and all(c["exit_code"] == 0 for c in validation["checks"]),
         "recorded Java-only validation incomplete")
    manifest_observation = validation["manifest_observation"]
    need(manifest_observation["name"] == "m2-manifest-observation"
         and manifest_observation["exit_code"] in (0, 1),
         "M2 manifest observation missing")
    for name, expected in validation["source_before"].items():
        need(identity(VALIDATION / "sources" / name)["sha256"] == expected,
             "validation copied source differs")
    history = {}
    files = {}
    for label, root, reason in HISTORY:
        history[label] = {**check_capture(label, root), "reason_superseded": reason}
        files.update(paths_under(root, f"history/{root.name}/"))
    exploration = ROOT / "target/m2/stage61-intseq-java-exploration-01"
    for path in exploration.iterdir():
        if path.is_file():
            files[f"history/{exploration.name}/{path.name}"] = path
    history_archive = emit_archive(REPORTS / "stage61-java-history.tar.gz", files,
                                   "All superseded Stage 61 IntSeq, math and List.add Java captures with raw channels")
    validation_archive = emit_archive(REPORTS / "stage61-java-validation.tar.gz",
                                      paths_under(VALIDATION, "validation/"),
                                      "Stage 61 Java authority validation checks, logs and copied source closure")
    fixtures = {}
    for label, path in (("intseq", "m2-int-seq-values"),
                        ("math_constants", "m2-int-seq-math-constants"),
                        ("list_add", "m2-int-seq-list-add")):
        root = ROOT / "tests/fixtures" / path
        archive_id = json.loads((root / "archive-identity.json").read_bytes())
        fixture_data = {"path": root.relative_to(ROOT).as_posix(),
                        "archive": identity(root / "oracle-evidence.tar.gz"),
                        "archive_members": archive_id["members"]}
        if label == "intseq":
            fixture_data.update({"module_uri": "file:///stage61/intseq-values.pkl",
                                 "string_rows": 237, "string_statuses_per_session": {"success": 198, "error": 39},
                                 "export_supplement_rows": 3, "export_supplement_statuses_per_session": {"error": 3},
                                 "archive_prefix": "capture-01", "export_prefix": "export-supplement-01"})
        elif label == "math_constants":
            fixture_data.update({"constants": 17, "public_calls_per_session": 34,
                                 "statuses_per_session": {"success": 34}, "archive_prefix": "capture-02"})
        else:
            fixture_data.update({"rows": 21, "statuses_per_session": {"success": 13, "error": 8},
                                 "archive_prefix": "capture-02"})
        fixtures[label] = fixture_data
    current = ROOT / "target/m2/stage61-intseq-oracle-string-01/provenance.json"
    p = json.loads(current.read_bytes())
    result = {"schema": 1, "kind": "stage61-intseq-java-authority-checkpoint",
              "baseline": "Pkl 0.32.0", "candidate_compatibility_passes_claimed": 0,
              "canonical": fixtures,
              "java_runtime": {"artifact_sha256": p["artifact_sha256"],
                               "jdk_executable_sha256": p["jdk"]["executable_sha256"],
                               "jdk_modules_sha256": p["jdk"]["modules_sha256"],
                               "jdk_release_sha256": p["jdk"]["release_sha256"],
                               "reference_revision": p["reference_revision"],
                               "artifact_before_after_equal": p["artifact_sha256"] == p["artifact_after_sha256"]},
              "validation": {"directory": VALIDATION.relative_to(ROOT).as_posix(),
                             "record": (VALIDATION / "validation.json").relative_to(ROOT).as_posix(),
                             "record_identity": identity(VALIDATION / "validation.json"),
                             "source_stable": validation["source_stable"],
                             "checks": validation["checks"],
                             "manifest_observation": manifest_observation,
                             "manifest_freshness_pass_claimed": validation["manifest_freshness_pass_claimed"],
                             "deferred_final_integration": validation["deferred_final_integration"],
                             **validation_archive},
              "history": {"captures": history, **history_archive},
              "limits": [
                  "Java public API observations only; Rust candidate, browser, Node, full M2 and performance compatibility remain separate.",
                  "The three IntSeq typed-export errors are producer-only and do not count as string candidate results.",
                  "Math functions and Java wrapper identity are outside these constant and List.add supplements.",
                  "Original upstream snippet suite replay is separate from this authored corpus.",
                  "M2 manifest freshness awaits concurrent Rust/core source freeze and regeneration when the recorded observation is stale.",
              ]}
    dest = REPORTS / "stage61-java-checkpoint.json"
    need(not dest.exists(), "fresh Java checkpoint publication required")
    dest.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"checkpoint": identity(dest), "validation": validation_archive,
                      "history": history_archive}, sort_keys=True))

if __name__ == "__main__":
    main()
