"""Record Stage 61 Java IntSeq and prerequisite authority validation."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent
PYTHON_SOURCES = [
    "target/m2/stage61-java-validation-01/run_validation.py",
    "target/m2/stage61-java-validation-01/publish.py",
    "tools/int_seq_values_oracle.py", "tools/int_seq_values_fixtures.py",
    "tools/int_seq_math_constants_oracle.py", "tools/int_seq_math_constants_fixtures.py",
    "tools/int_seq_list_add_oracle.py", "tools/int_seq_list_add_fixtures.py",
    "tools/tests/test_int_seq_values_fixtures.py",
    "tools/tests/test_int_seq_prerequisite_fixtures.py",
    "tools/inventory.py", "tools/m2_manifest.py",
]
UPSTREAM_SOURCES = [
    "external/pkl/stdlib/base.pkl", "external/pkl/stdlib/math.pkl",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmIntSeq.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmList.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/IntSeqNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/BaseNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/ListNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/math/MathNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/generator/GeneratorForNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/generator/GeneratorSpreadNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmValueRenderer.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/PcfRenderer.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/JsonRendererNodes.java",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/intseq.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/intseq.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/list.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/list.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/bytes.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/bytes.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/any.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/mathModule.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/generators/spreadSyntaxListing.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/generators/spreadSyntaxDynamic.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/generators/spreadSyntaxMapping.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/generators/elementGeneratorsTyped.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/generators/entryGeneratorsTyped.pkl",
]
FIXTURES = (
    "tests/fixtures/m2-int-seq-values", "tests/fixtures/m2-int-seq-math-constants",
    "tests/fixtures/m2-int-seq-list-add",
)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def identity(path):
    path = Path(path)
    return {"bytes": path.stat().st_size, "sha256": sha(path)}

def save(data):
    (OUTPUT / "validation.json").write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")

def source_names():
    names = set(PYTHON_SOURCES + UPSTREAM_SOURCES + [
        "tools/java/IntSeqValuesOracle.java", "tools/java/IntSeqMathConstantsOracle.java",
        "oracle.lock.json", "references.lock", "compatibility/inventory.json",
    ])
    for fixture in FIXTURES:
        names.update(p.relative_to(ROOT).as_posix() for p in (ROOT / fixture).iterdir() if p.is_file())
    return sorted(names)

def run(name, argv, env):
    folder = OUTPUT / "checks" / name
    folder.mkdir(parents=True)
    started = time.time()
    process = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=300)
    finished = time.time()
    for channel, raw in (("stdout", process.stdout), ("stderr", process.stderr)):
        (folder / (channel + ".bin")).write_bytes(raw)
    result = {"name": name, "argv": argv, "cwd": str(ROOT), "environment": env,
              "started_epoch": started, "finished_epoch": finished,
              "exit_code": process.returncode,
              "stdout": identity(folder / "stdout.bin"), "stderr": identity(folder / "stderr.bin")}
    (folder / "process.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"{name}: {process.returncode}", flush=True)
    return result

def main():
    if (OUTPUT / "sources").exists() or (OUTPUT / "validation.json").exists():
        raise ValueError("fresh Stage 61 Java validation directory required")
    names = source_names()
    before = {name: sha(ROOT / name) for name in names}
    for name in names:
        dest = OUTPUT / "sources" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, dest)
    python = sys.executable
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC",
           "TERM": "dumb", "NO_COLOR": "1", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}
    report = {"schema": 1, "kind": "stage61-intseq-java-authority-validation",
              "scope": "Java authority integrity, prerequisites and source inventory only; no Rust candidate pass",
              "host": platform.uname()._asdict(),
              "python": {"executable": python, "executable_identity": identity(python),
                         "version": sys.version},
              "python_source_closure": PYTHON_SOURCES, "source_before": before,
              "checks": [], "manifest_observation": None, "complete": False,
              "deferred_final_integration": ["M2 manifest freshness after concurrent Rust/core source freeze and regeneration"]}
    save(report)
    commands = []
    for label, script in (("intseq", "tools/int_seq_values_fixtures.py"),
                          ("math", "tools/int_seq_math_constants_fixtures.py"),
                          ("list-add", "tools/int_seq_list_add_fixtures.py")):
        commands.extend(((label + "-verifier", [python, script]),
                         (label + "-verifier-O", [python, "-O", script])))
    modules = ["tools.tests.test_int_seq_values_fixtures",
               "tools.tests.test_int_seq_prerequisite_fixtures"]
    commands.extend((("fixture-tests", [python, "-m", "unittest", *modules, "-v"]),
                     ("fixture-tests-O", [python, "-O", "-m", "unittest", *modules, "-v"]),
                     ("source-inventory", [python, "tools/inventory.py", "--check"])))
    for name, argv in commands:
        report["checks"].append(run(name, argv, env))
        save(report)
    manifest = run("m2-manifest-observation", [python, "tools/m2_manifest.py", "--check"], env)
    report["manifest_observation"] = manifest
    save(report)
    after = {name: sha(ROOT / name) for name in names}
    report["source_after"] = after
    report["source_stable"] = before == after
    report["snapshot_matches"] = before == {name: sha(OUTPUT / "sources" / name) for name in names}
    report["complete"] = (report["source_stable"] and report["snapshot_matches"]
                          and len(report["checks"]) == 9
                          and all(c["exit_code"] == 0 for c in report["checks"]))
    report["manifest_freshness_pass_claimed"] = manifest["exit_code"] == 0
    save(report)
    if not report["complete"]:
        raise ValueError("Java-only validation incomplete; raw attempts retained")

if __name__ == "__main__":
    main()
