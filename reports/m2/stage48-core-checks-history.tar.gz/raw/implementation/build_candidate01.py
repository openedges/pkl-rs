from pathlib import Path
import datetime, hashlib, json, os, platform, shutil, stat, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent/'admission-candidate-build-01'
OLD=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2/stage47-implementation-01/renderer-candidate-build-06')
CACHE=ROOT/'target/stage48-cargo'
ARTIFACTS=['module_eval_probe','stage45_annotation_probe','stage46_resource_probe','stage46_file_probe','stage47_renderer_probe','stage48_policy_probe']
EXCLUDE=[ROOT/'target',ROOT/'node_modules',ROOT/'.git',ROOT/'tools/platform/node_modules',ROOT/'external/pkl/.git',ROOT/'external/pkl/.gradle',ROOT/'external/pkl-pantry/.git',ROOT/'external/pkl-pantry/.gradle']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def listed():
 names=set()
 # Git's tracked file catalog does not traverse build/cache trees. Untracked
 # author paths are restricted before enumeration, never post-filtered from a walk.
 for prefix in ['', 'external/pkl/','external/pkl-pantry/']:
  base=ROOT/prefix
  for raw in subprocess.check_output(['git','--no-optional-locks','ls-files','-z','--cached'],cwd=base).split(b'\0'):
   if raw:names.add(prefix+raw.decode())
 for raw in subprocess.check_output(['git','--no-optional-locks','ls-files','-z','--others','--exclude-standard','--','crates','.cargo','tools','docs','tests','compatibility',':(exclude)tools/platform/node_modules',':(exclude)tools/platform/node_modules/**'],cwd=ROOT).split(b'\0'):
  if raw:names.add(raw.decode())
 result=[];links={}
 for name in sorted(names):
  p=ROOT/name
  if any(p==x or x in p.parents for x in EXCLUDE):raise AssertionError('catalog includes exact excluded path: '+name)
  if p.is_symlink():
   links[name]={'target':os.readlink(p),'mode':stat.S_IMODE(p.lstat().st_mode)}
   continue
  if p.is_file():result.append(name)
 return result,links
def state():
 names,links=listed();return ({n:sha(ROOT/n) for n in names},{n:stat.S_IMODE((ROOT/n).stat().st_mode) for n in names},links)
OUT.mkdir()
save('selection.json',{'method':'tracked Git catalogs plus restricted untracked author paths; no recursive filesystem source walk','exact_exclusions_before_enumeration':[str(p) for p in EXCLUDE],'untracked_roots':['crates','.cargo','tools','docs','tests','compatibility'],'reference_selection':'tracked pinned submodule catalogs only; no Gradle/Cargo traversal','source_mode_note':'actual checkout bytes and filesystem modes, not unmodified Git blob promise; upstream CRLF checkout may differ'})
before,modes,links=state();save('source-before.json',before);save('source-modes-before.json',modes);save('source-links-before.json',links)
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
cmd=['cargo','build','-p','pkl-runtime']
for name in ARTIFACTS:cmd+=['--example',name]
cmd+=['--locked']
env=dict(os.environ,CARGO_TARGET_DIR=str(CACHE),PYTHONDONTWRITEBYTECODE='1')
with (OUT/'stdout.bin').open('wb') as out,(OUT/'stderr.bin').open('wb') as err:
 p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=out,stderr=err)
 save('launch.json',{'pid':p.pid,'command':cmd,'cwd':str(ROOT),'started_utc':start,'cargo_target_dir':str(CACHE),'environment':{k:v for k,v in env.items() if k in ['PATH','JAVA_HOME','LANG','LC_ALL','TZ','RUSTUP_TOOLCHAIN','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_DIR','PYTHONDONTWRITEBYTECODE']},'host':platform.uname()._asdict()})
 code=p.wait()
after,after_modes,after_links=state();save('source-after.json',after);save('source-modes.json',after_modes);save('source-links.json',after_links)
report={'command':cmd,'cwd':str(ROOT),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'exit_code':code,'cargo_target_dir':str(CACHE),'source_stable':before==after and modes==after_modes and links==after_links,'source_before_sha256':sha(OUT/'source-before.json'),'source_after_sha256':sha(OUT/'source-after.json'),'stdout_sha256':sha(OUT/'stdout.bin'),'stderr_sha256':sha(OUT/'stderr.bin')}
save('report.json',report)
if code or not report['source_stable']:print(json.dumps(report),flush=True);sys.exit(code or 1)
old=json.loads((OLD/'source-after.json').read_text());counts={'immutable_hardlinks':0,'copies':0}
for name,h in after.items():
 p=ROOT/name;dst=OUT/'sources'/name;prior=OLD/'sources'/name;dst.parent.mkdir(parents=True,exist_ok=True)
 if old.get(name)==h and prior.is_file() and stat.S_IMODE(prior.stat().st_mode)==after_modes[name] and sha(prior)==h:
  os.link(prior,dst);counts['immutable_hardlinks']+=1
 else:shutil.copy2(p,dst);counts['copies']+=1
 assert sha(dst)==h and stat.S_IMODE(dst.stat().st_mode)==after_modes[name],name
for name,link in after_links.items():
 dst=OUT/'sources'/name;dst.parent.mkdir(parents=True,exist_ok=True);os.symlink(link['target'],dst);assert os.readlink(dst)==link['target']
artifacts={};(OUT/'artifacts').mkdir()
for name in ARTIFACTS:
 p=CACHE/'debug/examples'/name;dst=OUT/'artifacts'/name;shutil.copy2(p,dst);assert sha(p)==sha(dst)
 artifacts[name]={'path':str(dst),'sha256':sha(dst)}
last,last_modes,last_links=state();assert last==after and last_modes==after_modes and last_links==after_links
runtime={'host':platform.uname()._asdict(),'python':sys.version,'commands':[]}
for cmd in [['rustc','--version','--verbose'],['cargo','--version'],['rustup','show','active-toolchain']]:
 p=subprocess.run(cmd,cwd=ROOT,capture_output=True);assert p.returncode==0
 runtime['commands'].append({'argv':cmd,'exit_code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
save('environment.json',runtime)
save('release.json',{'schema':1,'status':'closed','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','--no-optional-locks','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'scope':'Stage48 exploratory admission candidate: executable-site CheckImport, canonical singleton key-resolution bypass, evaluator-owned bundled Resolve, typed Host failure and ref type guards, cycle partial receiver and source-accounted lifecycle roots. Build is not Java compatibility. Custom factory/key kind/isCached, eager clause factory selection, full primary/repl policy lifecycle and import glob remain mandatory unfinished. Prior failed captures preserved.','artifact':artifacts['module_eval_probe']['path'],'artifact_sha256':artifacts['module_eval_probe']['sha256'],'artifacts':artifacts,'source_map':str(OUT/'source-after.json'),'source_map_sha256':sha(OUT/'source-after.json'),'source_snapshot':str(OUT/'sources'),'source_count':len(after),'source_links':str(OUT/'source-links.json'),'source_links_sha256':sha(OUT/'source-links.json'),'source_link_count':len(after_links),'source_modes':str(OUT/'source-modes.json'),'source_modes_sha256':sha(OUT/'source-modes.json'),'build_report':str(OUT/'report.json'),'build_report_sha256':sha(OUT/'report.json'),'environment':str(OUT/'environment.json'),'environment_sha256':sha(OUT/'environment.json'),'snapshot_method':dict(explicit_map_paths=True,all_source_and_snapshot_hashes_verified=True,all_snapshot_modes_equal_live=True,immutable_predecessor=str(OLD),**counts)})
print(json.dumps({'release':str(OUT/'release.json'),'release_sha256':sha(OUT/'release.json'),'source_count':len(after),'source_map_sha256':sha(OUT/'source-after.json'),'artifacts':artifacts}),flush=True)
