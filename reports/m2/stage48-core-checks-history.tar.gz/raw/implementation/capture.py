from pathlib import Path
import datetime, hashlib, json, os, platform, subprocess, sys, time

root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent / sys.argv[1]
out.mkdir()
argv = sys.argv[2:]
files = subprocess.check_output(['rg', '--files', 'crates', '.cargo'], cwd=root, text=True).splitlines()
files += ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'references.lock']
files = sorted(set(files))
def hashes():
    values = {}
    blobs = out.parent / 'source-blobs'
    blobs.mkdir(exist_ok=True)
    for name in files:
        data = (root / name).read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        path = blobs / digest
        if not path.exists():
            path.write_bytes(data)
        else:
            assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
        values[name] = digest
    return values
def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')
before = hashes()
save('source-before.json', before)
env = dict(os.environ, CARGO_TARGET_DIR=str(root / 'target/stage48-cargo'))
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
tick = time.monotonic()
with (out / 'stdout.bin').open('wb') as stdout, (out / 'stderr.bin').open('wb') as stderr:
    process = subprocess.Popen(argv, cwd=root, env=env, stdout=stdout, stderr=stderr)
    save('launch.json', dict(pid=process.pid, command=argv, cwd=str(root), started_utc=start,
        cargo_target_dir=env['CARGO_TARGET_DIR'], source_scope='Explicit rg file list under crates/.cargo plus four Cargo/reference controls; no target/cache traversal. Not a whole-tree release snapshot.', host=platform.platform()))
    exit_code = process.wait()
after = hashes()
save('source-after.json', after)
report = dict(command=argv, exit_code=exit_code, started_utc=start,
    finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), elapsed_seconds=time.monotonic()-tick,
    source_stable=before == after, changed={p:[before.get(p),after.get(p)] for p in set(before)|set(after) if before.get(p)!=after.get(p)},
    stdout_sha256=hashlib.sha256((out/'stdout.bin').read_bytes()).hexdigest(), stderr_sha256=hashlib.sha256((out/'stderr.bin').read_bytes()).hexdigest())
save('report.json', report)
print(json.dumps(report), flush=True)
raise SystemExit(exit_code)
