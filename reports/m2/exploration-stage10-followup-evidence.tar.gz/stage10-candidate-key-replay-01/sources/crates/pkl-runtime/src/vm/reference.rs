//! Deferred references use declaration types without executing referent bodies.
use super::*;
use crate::heap::{CollectionKind, CollectionMember, CollectionMemberKind};

pub(crate) const DOMAIN_ID: usize = usize::MAX;
pub(crate) const ACCESS_ID: usize = usize::MAX - 1;

#[derive(Clone, Debug)]
pub struct Reference {
    pub domain: Value,
    pub data: Value,
    pub path: Vec<Value>,
    pub referent: TypeCheck,
    pub classes: Vec<ObjectId>,
    pub forced: bool,
}
#[derive(Clone, Debug)]
pub struct NativeFunction {
    pub receiver: Value,
    pub name: Arc<str>,
}

pub(crate) fn base_type(name: &str) -> Option<TypeCheck> {
    Some(match name {
        "Any" => TypeCheck::Any,
        "NonNull" => TypeCheck::NonNull,
        "Null" => TypeCheck::Null,
        "Boolean" => TypeCheck::Boolean,
        "Int" => TypeCheck::Int,
        "Float" => TypeCheck::Float,
        "Number" => TypeCheck::Number,
        "String" => TypeCheck::String,
        "Bytes" => TypeCheck::Bytes,
        "Dynamic" => TypeCheck::Collection(CollectionKind::Dynamic),
        "Listing" => TypeCheck::Collection(CollectionKind::Listing),
        "Mapping" => TypeCheck::Collection(CollectionKind::Mapping),
        "List" => TypeCheck::Collection(CollectionKind::List),
        _ => return None,
    })
}

pub(crate) fn type_name(ty: &TypeCheck, module: &str) -> String {
    match ty {
        TypeCheck::Unknown => "unknown".into(),
        TypeCheck::RefDomain => "pkl.ref#Domain".into(),
        TypeCheck::Reference { domain, referent } => format!(
            "pkl.ref#Reference<{}, {}>",
            type_name(domain, module),
            type_name(referent, module)
        ),
        TypeCheck::Class { id:ACCESS_ID,.. } => "pkl.ref#Access".into(),
        TypeCheck::Class { name, .. } => format!("{module}#{name}"),
        TypeCheck::Union { types, .. } => types
            .iter()
            .map(|t| type_name(t, module))
            .collect::<Vec<_>>()
            .join(" | "),
        TypeCheck::Nullable(t) => format!("{}?", type_name(t, module)),
        TypeCheck::Alias(t) | TypeCheck::GenericAlias(t) => type_name(t, module),
        TypeCheck::Constrained { base, .. } => type_name(base, module),
        TypeCheck::ParameterizedCollection { kind, arguments } => format!(
            "{kind:?}<{}>",
            arguments
                .iter()
                .map(|(t, _)| type_name(t, module))
                .collect::<Vec<_>>()
                .join(", ")
        ),
        TypeCheck::Collection(kind) => format!("{kind:?}"),
        TypeCheck::StringLiteral(s) => format!("\"{s}\""),
        _ => super::type_name(ty, module),
    }
}

/// Java exports nullable types as flattened unions and erases constraints.
pub(crate) fn normalize(ty: &TypeCheck) -> TypeCheck {
    match ty {
        TypeCheck::Alias(inner)
        | TypeCheck::GenericAlias(inner)
        | TypeCheck::Constrained { base: inner, .. } => normalize(inner),
        TypeCheck::Nullable(inner) => union(vec![normalize(inner), TypeCheck::Null]),
        TypeCheck::Union { types, .. } => union(types.iter().map(normalize).collect()),
        TypeCheck::Collection(
            kind @ (CollectionKind::List | CollectionKind::Listing | CollectionKind::Mapping),
        ) => TypeCheck::ParameterizedCollection {
            kind: *kind,
            arguments: vec![
                (TypeCheck::Unknown, Span::new(0, 0));
                if *kind == CollectionKind::Mapping {
                    2
                } else {
                    1
                }
            ],
        },
        TypeCheck::ParameterizedCollection { kind, arguments } => {
            TypeCheck::ParameterizedCollection {
                kind: *kind,
                arguments: arguments.iter().map(|(t, s)| (normalize(t), *s)).collect(),
            }
        }
        ty => ty.clone(),
    }
}
fn union(types: Vec<TypeCheck>) -> TypeCheck {
    let mut result = Vec::new();
    for ty in types {
        if let TypeCheck::Union { types, .. } = ty {
            result.extend(types);
        } else {
            result.push(ty);
        }
    }
    if result.iter().any(|t| matches!(t, TypeCheck::Unknown)) {
        return TypeCheck::Unknown;
    }
    if result.iter().any(|t| matches!(t, TypeCheck::Any)) {
        return TypeCheck::Any;
    }
    result.sort_by_key(|t| type_name(t, ""));
    result.dedup_by(|a, b| a.equivalent(b));
    if result.len() == 1 {
        return result.remove(0);
    }
    TypeCheck::Union {
        types: result,
        spans: Vec::new(),
        labels: Vec::new(),
        default: None,
    }
}

pub(crate) fn is_subtype(a: &TypeCheck, b: &TypeCheck, heap: &Heap) -> bool {
    if matches!(a, TypeCheck::Unknown) || matches!(b, TypeCheck::Unknown | TypeCheck::Any) {
        return true;
    }
    subtype(a, b, heap)
}
fn subtype(a: &TypeCheck, b: &TypeCheck, heap: &Heap) -> bool {
    if a.equivalent(b) {
        return true;
    }
    match (a, b) {
        (TypeCheck::IntegerAlias {name:a,..},TypeCheck::IntegerAlias {name:b,..}) => match a.as_ref() {
            "Int8"=>matches!(b.as_ref(),"Int16"|"Int32"),
            "Int16"=>b.as_ref()=="Int32",
            "UInt8"=>matches!(b.as_ref(),"Int16"|"Int32"|"UInt16"|"UInt32"|"UInt"),
            "UInt16"=>matches!(b.as_ref(),"Int32"|"UInt32"|"UInt"),
            "UInt32"=>b.as_ref()=="UInt",_=>false,
        },
        (TypeCheck::IntegerAlias {..}, TypeCheck::Int|TypeCheck::Float|TypeCheck::Number)=>true,
        (TypeCheck::StringLiteral(_), TypeCheck::String) => true,
        (TypeCheck::Int | TypeCheck::Float, TypeCheck::Number) => true,
        (TypeCheck::Class { id, .. }, TypeCheck::Class { id: other, .. }) => {
            let mut current = heap.find_class(*id);
            while let Some(id) = current {
                let Ok(object) = heap.get(id) else {
                    return false;
                };
                if object
                    .class_definition
                    .as_ref()
                    .is_some_and(|c| c.id == *other)
                {
                    return true;
                }
                current = object.parent;
            }
            false
        }
        (
            TypeCheck::ParameterizedCollection {
                kind: a,
                arguments: aa,
            },
            TypeCheck::ParameterizedCollection {
                kind: b,
                arguments: ba,
            },
        ) => {
            a == b
                && aa.len() == ba.len()
                && aa
                    .iter()
                    .zip(ba)
                    .all(|((a, _), (b, _))| subtype(a, b, heap))
        }
        (TypeCheck::Union { types: a, .. }, TypeCheck::Union { types: b, .. }) => {
            a.iter().all(|a| b.iter().any(|b| subtype(a, b, heap)))
        }
        (a, TypeCheck::Union { types, .. }) => types.iter().any(|b| subtype(a, b, heap)),
        _ => false,
    }
}

impl Vm {
    pub(super) fn builtin_class(&mut self, ty: TypeCheck) -> Value {
        if let Some(id)=self.heap.find_builtin_class(&ty) {return Value::Class(id);}
        let (id, name, abstract_) = match ty {
            TypeCheck::Class {id:ACCESS_ID,..} => (ACCESS_ID,"Access".to_owned(),false),
            TypeCheck::RefDomain => (DOMAIN_ID, "Domain".to_owned(), true),
            _ => (
                usize::MAX - 2,
                super::type_name(&ty, &self.program.module_name),
                false,
            ),
        };
        let object = self.heap.allocate(Object {
            builtin_type: Some(ty),
            class_definition: Some(Class {
                id,
                name: Arc::from(name),
                open: false,
                abstract_,
            }),
            ..Object::default()
        });
        Value::Class(object)
    }

    pub(super) fn native_reference_method(&mut self, receiver: Value, name: &str) -> Value {
        let object = self.heap.allocate(Object {
            native_function: Some(NativeFunction {
                receiver,
                name: Arc::from(name),
            }),
            ..Object::default()
        });
        Value::Function(object)
    }

    pub(super) fn reference_member(
        &mut self,
        id: ObjectId,
        name: &str,
        method: bool,
    ) -> Result<bool, RuntimeError> {
        if self.heap.get(id)?.ref_module {
            let value = match (name, method) {
                ("Reference", true) => self.native_reference_method(Value::Object(id), "Reference"),
                ("Reference", false) => self.builtin_class(TypeCheck::Reference {
                    domain: Box::new(TypeCheck::Any),
                    referent: Box::new(TypeCheck::Any),
                }),
                ("Domain", false) => self.builtin_class(TypeCheck::RefDomain),
                ("Access", false) => self.builtin_class(TypeCheck::Class {id:ACCESS_ID,name:Arc::from("Access")}),
                _ => {
                    return Err(RuntimeError::new(
                        ErrorKind::Unsupported,
                        format!("pkl:ref member `{name}` is not implemented"),
                    ));
                }
            };
            self.stack.push(value);
            return Ok(true);
        }
        if self.heap.get(id)?.reference.is_none() {
            return Ok(false);
        }
        let value = if method {
            match name {
                "getDomain" | "getData" | "getPath" | "toString" => {
                    self.native_reference_method(Value::Object(id), name)
                }
                _ => {
                    return Err(RuntimeError::new(
                        ErrorKind::MissingMember,
                        format!("Cannot find method `{name}` in class `pkl.ref#Reference`."),
                    ));
                }
            }
        } else {
            self.reference_access(id, Some(name), None)?
        };
        self.stack.push(value);
        Ok(true)
    }

    pub(super) fn invoke_reference_native(
        &mut self,
        native: NativeFunction,
        args: Vec<Value>,
    ) -> Result<(), RuntimeError> {
        let expected = if native.name.as_ref() == "Reference" {
            3
        } else {
            0
        };
        if args.len() != expected {
            return Err(RuntimeError::new(
                ErrorKind::Type,
                format!(
                    "Expected {expected} function arguments but got {}.",
                    args.len()
                ),
            ));
        }
        if native.name.as_ref()=="scalarToString" {
            self.stack.push(Value::string(scalar_string(&native.receiver)?));
            return Ok(());
        }
        let value = if native.name.as_ref() == "Reference" {
            if !TypeCheck::RefDomain.accepts(&args[0], &self.heap) {
                return Err(RuntimeError::new(
                    ErrorKind::Type,
                    "Reference domain must be a pkl.ref#Domain.",
                ));
            }
            let Value::Class(class_id) = args[1] else {
                return Err(RuntimeError::new(
                    ErrorKind::Type,
                    "Reference referent must be a Class.",
                ));
            };
            let object = self.heap.get(class_id)?;
            let class = object
                .class_definition
                .as_ref()
                .ok_or_else(|| invalid("class metadata missing"))?;
            let ty = object
                .builtin_type
                .clone()
                .unwrap_or_else(|| TypeCheck::Class {
                    id: class.id,
                    name: class.name.clone(),
                });
            let reference = Reference {
                domain: args[0].clone(),
                data: args[2].clone(),
                path: Vec::new(),
                referent: normalize(&ty),
                classes: vec![class_id],
                forced: false,
            };
            Value::Object(self.heap.allocate(Object {
                reference: Some(reference),
                ..Object::default()
            }))
        } else {
            let id = native.receiver.as_object()?;
            let reference = self
                .heap
                .get(id)?
                .reference
                .clone()
                .ok_or_else(|| invalid("reference native receiver"))?;
            match native.name.as_ref() {
                "getDomain" => reference.domain,
                "getData" => reference.data,
                "getPath" => self.reference_list(reference.path),
                "toString" => {
                    self.render_reference(id)?;
                    return Ok(());
                }
                _ => return Err(invalid("unknown reference native method")),
            }
        };
        self.stack.push(value);
        Ok(())
    }

    pub(super) fn render_reference(&mut self, id: ObjectId) -> Result<(), RuntimeError> {
        let function = self.heap.allocate(Object {
            function: Some(Function {
                block: self.reference_render_block,
                arity: 0,
                method: true,
                capture_custom_this: false,
            }),
            environment: Environment {
                locals: vec![Value::Object(id)],
                ..Environment::default()
            },
            ..Object::default()
        });
        self.invoke_function(function, Vec::new(), true)
    }

    fn reference_list(&mut self, values: Vec<Value>) -> Value {
        let mut object = Object {
            collection_kind: CollectionKind::List,
            length: values.len(),
            ..Object::default()
        };
        for (index, value) in values.into_iter().enumerate() {
            let name: Arc<str> = Arc::from(format!("\0{index}"));
            object.members.push(Member {
                entry: true,
                name: name.clone(),
                code: usize::MAX,
                local: false,
                method: false,
                ty: None,
                type_span: None,
                constant: false,
            });
            object.collection_members.push(CollectionMember {
                key: Value::Int(index as i64),
                name: name.clone(),
                kind: CollectionMemberKind::Element,
            });
            object.complete_cache(
                CacheKey {
                    entry: true,
                    owner: None,
                    name,
                    method: false,
                },
                value,
            );
        }
        Value::Object(self.heap.allocate(object))
    }

    fn reference_access_value(&mut self, property: Option<&str>, key: Option<Value>) -> Value {
        let Value::Class(parent)=self.builtin_class(TypeCheck::Class {id:ACCESS_ID,name:Arc::from("Access")}) else {unreachable!()};
        let mut object = Object {parent:Some(parent),..Object::default()};
        for (name, value) in [
            ("property", property.map_or(Value::Null, Value::string)),
            ("key", key.unwrap_or(Value::Null)),
            ("isProperty", Value::Bool(property.is_some())),
            ("isSubscript", Value::Bool(property.is_none())),
        ] {
            let name: Arc<str> = Arc::from(name);
            object.members.push(Member {
                entry: false,
                name: name.clone(),
                code: usize::MAX,
                local: false,
                method: false,
                ty: None,
                type_span: None,
                constant: false,
            });
            object.complete_cache(
                CacheKey {
                    entry: false,
                    owner: None,
                    name,
                    method: false,
                },
                value,
            );
        }
        if self.heap.get(parent).expect("access class").members.is_empty() {
            self.heap.get_mut(parent).expect("access class").members=object.members.clone();
        }
        Value::Object(self.heap.allocate(object))
    }

    pub(super) fn reference_access(
        &mut self,
        id: ObjectId,
        property: Option<&str>,
        key: Option<Value>,
    ) -> Result<Value, RuntimeError> {
        let mut reference = self
            .heap
            .get(id)?
            .reference
            .clone()
            .ok_or_else(|| invalid("missing reference payload"))?;
        let types = if let TypeCheck::Union { types, .. } = &reference.referent {
            types.clone()
        } else {
            vec![reference.referent.clone()]
        };
        let mut candidates = Vec::new();
        for ty in types {
            candidates.push(self.reference_candidate(&ty, property, key.as_ref())?);
        }
        reference.referent = union(candidates);
        reference.forced=false;
        reference
            .path
            .push(self.reference_access_value(property, key));
        Ok(Value::Object(self.heap.allocate(Object {
            reference: Some(reference),
            ..Object::default()
        })))
    }

    fn reference_candidate(
        &self,
        ty: &TypeCheck,
        property: Option<&str>,
        key: Option<&Value>,
    ) -> Result<TypeCheck, RuntimeError> {
        let fail = || {
            RuntimeError::new(
                ErrorKind::MissingMember,
                format!(
                    "Cannot reference {} in type `{}`.",
                    property.map_or_else(|| "subscript".into(), |p| format!("property `{p}`")),
                    type_name(ty, &self.program.module_name)
                ),
            )
        };
        match ty {
            TypeCheck::Unknown => Ok(TypeCheck::Unknown),
            TypeCheck::Null => Ok(TypeCheck::Null),
            TypeCheck::Collection(CollectionKind::Dynamic) => {
                if property == Some("default") {
                    Err(fail())
                } else {
                    Ok(TypeCheck::Unknown)
                }
            }
            TypeCheck::Class { id, .. } if property.is_some() => {
                let name = property.expect("property access");
                let mut current = self.heap.find_class(*id);
                let mut found = false;
                while let Some(id) = current {
                    let object = self.heap.get(id)?;
                    if let Some(member) = object
                        .members
                        .iter()
                        .find(|m| !m.local && !m.method && m.name.as_ref() == name)
                    {
                        found = true;
                        if let Some(ty) = &member.ty {
                            return Ok(normalize(ty));
                        }
                    }
                    current = object.parent;
                }
                if found {
                    Ok(TypeCheck::Unknown)
                } else {
                    Err(fail())
                }
            }
            TypeCheck::ParameterizedCollection { kind, arguments } if property.is_none() => {
                let key = key.expect("subscript key");
                match kind {
                    CollectionKind::List | CollectionKind::Listing
                        if matches!(key, Value::Int(_)) =>
                    {
                        Ok(normalize(&arguments[0].0))
                    }
                    CollectionKind::Mapping
                        if reference_key_matches(&arguments[0].0, key, &self.heap) =>
                    {
                        Ok(normalize(&arguments[1].0))
                    }
                    _ => Err(fail()),
                }
            }
            TypeCheck::String if property == Some("length") => Ok(TypeCheck::Int),
            _ => Err(fail()),
        }
    }
}
fn reference_key_matches(ty: &TypeCheck, key: &Value, heap: &Heap) -> bool {
    match ty {
        TypeCheck::Unknown => true,
        TypeCheck::Union { types, .. } => types.iter().any(|t| reference_key_matches(t, key, heap)),
        TypeCheck::Class { id, .. } => {
            matches!(key,Value::Object(object) if collections::typed_class(heap,*object).ok().flatten().is_some_and(|c| c.id==*id))
        }
        TypeCheck::Any | TypeCheck::NonNull | TypeCheck::Number | TypeCheck::IntegerAlias {..} => false,
        _ => ty.accepts(key, heap),
    }
}
