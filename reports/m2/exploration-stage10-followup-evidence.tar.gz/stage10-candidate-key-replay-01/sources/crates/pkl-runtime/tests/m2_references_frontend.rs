//! Import identity and type/name scope prerequisites for deferred references.
use pkl_runtime::parser::parse_module;
use pkl_runtime::resolver::{Binding, resolve_module};
use pkl_runtime::source::Span;
use pkl_runtime::syntax::{ExprKind, ModifierKind, TypeKind, modifier_flags};

fn span(source: &str, fragment: &str) -> Span {
    let start = source.find(fragment).unwrap();
    Span::new(start, start + fragment.len())
}

#[test]
fn imports_are_local_const_members_with_authored_namespace_and_source_identity() {
    let source = "module example\nimport \"pkl:ref\" as deferred\nresult = deferred.Reference";
    let module = parse_module(source).unwrap();
    let import = &module.members[0];
    assert_eq!(import.name, "deferred");
    assert!(import.local);
    assert_eq!(
        modifier_flags(&import.modifiers),
        ModifierKind::Local.flag() | ModifierKind::Const.flag()
    );
    assert!(matches!(&import.expr.kind, ExprKind::Import { uri } if uri == "pkl:ref"));
    assert_eq!(
        import.expr.span,
        span(source, "import \"pkl:ref\" as deferred")
    );
    let resolved = resolve_module(&module).unwrap();
    let receiver = span(source, "deferred.Reference");
    assert_eq!(
        resolved.names[&Span::new(receiver.start, receiver.start + 8)],
        Binding::Property {
            owner_depth: 0,
            local: true
        }
    );
}

#[test]
fn qualified_type_names_keep_token_spans_and_resolve_imports_outside_value_scopes() {
    let source = "import \"pkl:ref\"\nclass D extends ref.Domain {}\nfunction check(ref, value: ref . `Reference`<D, String>) = ref";
    let module = parse_module(source).unwrap();
    let resolved = resolve_module(&module).unwrap();
    let ExprKind::Function {
        parameters, body, ..
    } = &module.members[2].expr.kind
    else {
        panic!("method")
    };
    let ty = parameters[1].ty.as_ref().unwrap();
    let TypeKind::Named {
        path,
        name_spans,
        arguments,
    } = &ty.kind
    else {
        panic!("named type")
    };
    assert_eq!(path, &["ref", "Reference"]);
    assert_eq!(&source[name_spans[0].start..name_spans[0].end], "ref");
    assert_eq!(
        &source[name_spans[1].start..name_spans[1].end],
        "`Reference`"
    );
    assert_eq!(arguments.len(), 2);
    assert_eq!(
        resolved.names[&ty.span],
        Binding::Property {
            owner_depth: 0,
            local: true
        }
    );
    assert_eq!(
        resolved.names[&body.span],
        Binding::Lexical { depth: 1, slot: 0 }
    );
}

#[test]
fn base_classes_are_values_after_lexical_shadowing_and_reference_is_not_global() {
    let source =
        "import \"pkl:ref\"\nfunction f(String) = String\nresult = List(Int, Any, Reference)";
    let module = parse_module(source).unwrap();
    let resolved = resolve_module(&module).unwrap();
    assert_eq!(resolved.names[&span(source, "Int")], Binding::BaseClass);
    assert_eq!(resolved.names[&span(source, "Any")], Binding::BaseClass);
    assert_eq!(
        resolved.names[&span(source, "Reference")],
        Binding::ImplicitThis
    );
    let ExprKind::Function { body, .. } = &module.members[1].expr.kind else {
        panic!("method")
    };
    assert_eq!(
        resolved.names[&body.span],
        Binding::Lexical { depth: 0, slot: 0 }
    );
}

#[test]
fn imports_share_the_property_namespace_but_keep_methods_separate() {
    for source in [
        "import \"pkl:ref\"\nref = 1",
        "import \"pkl:ref\"\nlocal ref = 1",
        "import \"pkl:ref\"\nimport \"pkl:ref\"",
    ] {
        assert_eq!(
            resolve_module(&parse_module(source).unwrap())
                .unwrap_err()
                .message,
            "Duplicate definition of member `ref`."
        );
    }
    resolve_module(
        &parse_module("import \"pkl:ref\"\nfunction ref() = 1\nresult = ref()").unwrap(),
    )
    .unwrap();
    assert!(parse_module("result = 1\nimport \"pkl:ref\"").is_err());
    assert!(parse_module("import* \"pkl:ref\"").is_err());
    let source = "import \"pkl:ref\"\nlocal ref = 1";
    assert_eq!(resolve_module(&parse_module(source).unwrap()).unwrap_err().span, span(source, "local ref"));
}
