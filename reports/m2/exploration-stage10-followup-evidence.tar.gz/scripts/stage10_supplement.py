from pathlib import Path
import sys,json
sys.path.insert(0,'tools')
import oracle,m2_manifest as c,m2_language as l
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(c.ROOT,fetch=False);(out/'oracle.json').write_bytes(c.encoded(meta))
base='''import "pkl:ref"
class D extends ref.Domain { function renderReference(r): String = r.getData().toString() }
local d = new D {}
'''
rows=[]
def add(id,body,failure=False,group='supplement',prefix=base,relation=None):
 rows.append(dict(id=id,source=prefix+body,expression='result',expected_outcome='failure' if failure else 'success',group=group,**({'relation':relation} if relation else {})))
add('external-length-type','result = ref.Reference(d, String, null).length is ref.Reference<D, Int>\n')
add('external-int-duration','result = ref.Reference(d, Int, null).s is ref.Reference<D, Duration>\n')
add('builtin-computed-string','result = ref.Reference(d, String, null).isEmpty is ref.Reference<D, Boolean>\n')
add('data-not-forced','class Data { value = throw("data forced") }\nresult = ref.Reference(d, String, new Data {}).getPath().length\n')
add('domain-not-forced','class LazyDomain extends ref.Domain { p = throw("domain forced"); function renderReference(r): String = "ok" }\nresult = ref.Reference(new LazyDomain {}, String, null).getPath().length\n')
add('domain-render-not-forced','class LazyDomain extends ref.Domain { p = throw("domain forced"); function renderReference(r): String = "ok" }\nresult = ref.Reference(new LazyDomain {}, String, null).toString()\n')
add('equality-data-forced','class Data { value = throw("data forced") }\nresult = ref.Reference(d, String, new Data {}) == ref.Reference(d, String, new Data {})\n',failure=True)
add('equality-domain-forced','class LazyDomain extends ref.Domain { p = throw("domain forced"); function renderReference(r): String = "ok" }\nresult = ref.Reference(new LazyDomain {}, String, null) == ref.Reference(new LazyDomain {}, String, null)\n',failure=True)
add('hash-data-forced','class Data { value = throw("data forced") }\nresult = Set(ref.Reference(d, String, new Data {})).length\n',failure=True)
add('member-untype-unknown','class H { p = throw("not evaluated") }\nresult = ref.Reference(d, H, null).p.anything[null] is ref.Reference<D, Int>\n')
add('member-inherited-value-override','open class A { p: String }\nclass B extends A { p = throw("not evaluated") }\nresult = ref.Reference(d, B, null).p is ref.Reference<D, String>\n')
add('member-union-call-invalid','class H { f: (Int) -> Boolean }\nresult = ref.Reference(d, H, null).f[0]\n',failure=True)
add('module-metadata','property: String = throw("not evaluated")\nresult = ref.Reference(d, module.getClass(), null).property is ref.Reference<D, String>\n')
add('module-output-forbidden','result = ref.Reference(d, module.getClass(), null).output\n',failure=True)
add('module-output-override-forbidden','output: ModuleOutput = new {}\nresult = ref.Reference(d, module.getClass(), null).output\n',failure=True)
add('access-property','local a = new ref.Access { property = "name" }\nresult = a.isProperty && !a.isSubscript && a.property == "name" && a.key == null\n')
add('access-null-key','local a = new ref.Access { property = null; key = null }\nresult = !a.isProperty && a.isSubscript\n')
add('access-invalid','result = new ref.Access { property = "name"; key = "key" }.property\n',failure=True)
add('namespace-import-alias','import "pkl:ref" as refs\nresult = refs.Reference(d, String, "x").getData()\n')
add('namespace-property','ref = 42\nresult = ref\n')
add('namespace-local-duplicate','local ref = 42\nresult = ref\n',failure=True)
add('namespace-parameter','function f(ref) = ref\nresult = f(42)\n')
add('namespace-parameter-qualified','function f(ref) = ref.Reference(d, String, "x").getData()\nresult = f(42)\n',failure=True)
# Metamorphic controls, with both Java-produced outcomes retained.
for suffix,decl in [('left','typealias Text = String(length > 9)\nclass H { p: Text }\n'),('right','class H { p: String }\n')]:
 add('relation-alias-'+suffix,decl+'local r = ref.Reference(d, H, null).p\nresult = "\\(r.getPath()[0].property):\\(r is ref.Reference<D, String>)"\n',relation='alias-erasure')
for suffix,decl in [('left','class H { p: String = throw("not evaluated") }\n'),('right','class H { p: String }\n')]:
 add('relation-unforced-'+suffix,decl+'local r = ref.Reference(d, H, null).p\nresult = "\\(r.getPath()[0].property):\\(r is ref.Reference<D, String>)"\n',relation='unforced-property')
for suffix,expr in [('left','"prefix:\\(r):suffix"'),('right','"prefix:" + r.toString() + ":suffix"')]:
 add('relation-render-'+suffix,'local r = ref.Reference(d, String, "root")\nresult = '+expr+'\n',relation='interpolation-to-string')
# Execute originals at their exact pinned source URIs, through a selected API expression.
up=Path('external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input')
for p in sorted((up/'errors').glob('reference*.pkl')):
 n=int(p.stem.removeprefix('reference'));expr='test' if n<=19 else ('testInterpolation' if n==20 else ('foo' if n<=23 else 'res'))
 rows.append(dict(id='upstream-error-'+str(n),input=str(p),expression=expr,expected_outcome='failure',group='upstream-selected-expression'))
for id,p,expr in [('upstream-basic-facts',up/'basic/reference.pkl','facts'),('upstream-api-interpolation',up/'api/reference.pkl','refInterpolation'),('upstream-api-joined',up/'api/reference.pkl','aValuesJoined'),('upstream-api-union-typeargs',up/'api/reference.pkl','typeArgs')]:
 rows.append(dict(id=id,input=str(p),expression=expr,expected_outcome='success',group='upstream-selected-expression'))
paths=['target/m2/stage10_supplement.py','tools/m2_language.py','tools/m2_manifest.py','tools/oracle.py','tools/java/M2LanguageProbe.java','oracle.lock.json','references.lock','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/VmModifier.java','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/member/ClassProperty.java','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmReference.java','external/pkl/stdlib/ref.pkl']
identities={}
for p in paths:
 dest=out/'sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(Path(p).read_bytes());identities[p]=oracle.sha256(Path(p))
(out/'source-identities.json').write_bytes(c.encoded(identities));(out/'matrix.json').write_bytes(c.encoded(rows))
classes=out/'artifacts/java';classes.mkdir(parents=True);javac=Path(meta['java']).with_name('javac')
a=l.capture([str(javac),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(classes),str((out/'sources/tools/java/M2LanguageProbe.java').resolve())],out,'javac',meta['environment']);assert a['exit_code']==0
results=[]
for row in rows:
 folder=out/'cases'/row['id'];folder.mkdir(parents=True)
 if 'input' in row:
  src=(c.ROOT/row['input']).resolve();(folder/'input.pkl').write_bytes(src.read_bytes())
 else:
  src=folder/'input.pkl';src.write_text(row['source'])
 java=l.capture_java(meta,out/'artifacts/language_probe',row['id'],src,row['expression'],folder)
 results.append(dict(id=row['id'],input_uri=src.as_uri(),input_sha256=oracle.sha256(src),expected_outcome=row['expected_outcome'],java=java))
 print(row['id'],java['exit_code'],repr((folder/'java.stdout.bin').read_bytes())[:200],flush=True)
(out/'results.json').write_bytes(c.encoded(results));(out/'evidence-sha256.json').write_bytes(c.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
