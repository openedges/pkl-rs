"""Create prospective immutable fixture inputs, then compare at their actual URIs."""
from pathlib import Path
import sys,json,shutil
sys.path.insert(0,'tools')
import oracle,m2_manifest as c,m2_language as l
replay=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
original=json.loads(Path('target/m2/stage10-selection-baseline-01/selection.json').read_bytes());current=json.loads(Path(c.SELECTION).read_bytes());assert current==original
for row in original['cases']:assert Path(row['input']).read_bytes()==(Path('target/m2/stage10-selection-baseline-01/inputs')/row['input']).read_bytes(),row['id']
excluded={'namespace-import-alias':'Invalid draft import placement; retained as exploratory syntax failure.', 'namespace-property':'Duplicate minimized probe; corrected explicit duplicate case retained separately.', 'namespace-dual-alias-valid':'Misleading draft using non-domain Access rather than a valid second import.', 'access-property':'Incomplete draft Access value omits required key; retained as exploration.'}
renamed={'equality-data-forced':'equality-data-shared-initializer-unforced','equality-domain-forced':'equality-domain-shared-initializer-unforced','mapping-reference-key-count':'mapping-reference-key-duplicate','property-string-external':'builtin-string-length-reference-render'}
meta=oracle.ensure_oracle(c.ROOT,fetch=False);(out/'oracle.json').write_bytes(c.encoded(meta));art=out/'artifacts';art.mkdir();frozen=art/'language_probe';frozen.write_bytes((replay/'artifacts/language_probe').read_bytes());frozen.chmod(0o755)
paths=['target/m2/stage10_stage_selection.py','tools/m2_language.py','tools/m2_manifest.py','tools/oracle.py','tools/java/M2LanguageProbe.java','oracle.lock.json','references.lock']
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(Path(p).read_bytes())
if (replay/'sources/crates').exists():shutil.copytree(replay/'sources/crates',out/'sources/crates')
classes=art/'java';classes.mkdir();r=l.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(classes),str((out/'sources/tools/java/M2LanguageProbe.java').resolve())],out,'javac',meta['environment']);assert r['exit_code']==0
proposed=[];observations=[];rejected=[]
for record in json.loads((replay/'results.json').read_bytes()):
 id=record['id'];baseline=Path(record['baseline']);mat=next(r for r in json.loads((baseline/'matrix.json').read_bytes())if r['id']==id)
 if id.startswith('upstream-')or id in excluded or record['status']!='pass':
  rejected.append(dict(id=id,exploration=str(baseline),reason='Original selected-expression evidence does not replace original suite contract.'if id.startswith('upstream-')else excluded.get(id,'Candidate does not match complete raw Java capture.')));continue
 identifier='reference-stage10-'+renamed.get(id,id);path=Path('tests/fixtures/m2')/(identifier+'.pkl');assert not path.exists(),path
 path.write_bytes((baseline/'cases'/id/'input.pkl').read_bytes());source=path.resolve();folder=out/'cases'/identifier;folder.mkdir(parents=True);(folder/'input.pkl').write_bytes(source.read_bytes())
 java=l.capture_java(meta,frozen,identifier,source,mat['expression'],folder);rust=l.capture([str(frozen),str(source),mat['expression']],folder,'rust',meta['environment'])
 outcome='success'if java['exit_code']==0 else'failure';status=l.status(dict(expected_outcome=outcome),java,rust,*((folder/f'{name}.{channel}.bin').read_bytes()for name in ('java','rust')for channel in ('stdout','stderr')),(folder/'java.outcome.bin').read_bytes())
 requirements=['semantic:reference'];body=mat['source']
 if mat['group'].startswith('metadata')or mat['group']in('reference-native-member-metadata','nonnull-alias-metadata')or'class H'in body or'class A'in body:requirements.append('semantic:reflection-metadata')
 if 'is ref.Reference'in body or'as ref.Reference'in body:requirements.extend(['semantic:types','semantic:type-tests-casts'])
 if 'throw('in body or'unforced'in id or'not-forced'in id:requirements.append('semantic:lazy-evaluation')
 if mat['group']in ('subscript','reference-mapping-keys','reference-key-type-identity'):requirements.append('semantic:collections')
 if 'typealias 'in body:requirements.append('semantic:type-aliases')
 if any(token in body for token in ('String(', 'Int(', 'D(true)')):requirements.append('semantic:constraints')
 if ' | 'in body or '?'in body:requirements.append('semantic:unions')
 if 'typealias Ref<T>'in body:requirements.append('semantic:generics')
 if 'namespace'in id:requirements.extend(['semantic:modules','semantic:name-resolution'])
 if 'nonnull'in id:requirements.append('semantic:type-aliases')
 if mat['group']=='reference-object-boundary':
  requirements.append('semantic:objects')
  if '(r) {}'in body:requirements.append('semantic:amendment')
  if 'for ('in body or '...r'in body:requirements.append('semantic:generators')
 if outcome=='failure':requirements.append('semantic:diagnostics')
 case=dict(id=identifier,input=str(path),expression=mat['expression'],requirements=list(dict.fromkeys(requirements)),expected_outcome=outcome)
 if 'relation'in mat:
  family={'alias-erasure':('alias','Declaration alias wrapping a constrained String erases to String without running its constraint.'),'unforced-property':('unforced','Reference synthetic property metadata is unchanged by a throwing property initializer, which must remain unforced.'),'interpolation-to-string':('render','Reference string interpolation delegates to the same domain renderer as explicit toString for this String-valued domain.')}[mat['relation']]
  case['metamorphic_relation']=dict(kind='equal-stdout',case_ids=['reference-stage10-relation-'+family[0]+'-'+side for side in ('left','right')],domain=family[1])
 proposed.append(case);observations.append(dict(id=identifier,original_id=id,exploration=str(baseline),exploratory_uri=record['input_uri'],actual_uri=source.as_uri(),input_sha256=oracle.sha256(source),expression=mat['expression'],status=status,java=java,rust=rust));print(identifier,status,flush=True)
assert len({r['id']for r in proposed})==len(proposed)
(out/'proposed.json').write_bytes(c.encoded(proposed));(out/'results.json').write_bytes(c.encoded(observations));(out/'excluded.json').write_bytes(c.encoded(rejected));(out/'candidate.json').write_bytes(c.encoded(dict(source_binding='frozen-from-exploratory-replay-unbound-caller-supplied',replay=str(replay),sha256=oracle.sha256(frozen))));(out/'evidence-sha256.json').write_bytes(c.encoded({str(p.relative_to(out)):oracle.sha256(p)for p in sorted(out.rglob('*'))if p.is_file()}))
