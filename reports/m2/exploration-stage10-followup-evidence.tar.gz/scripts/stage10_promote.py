"""Append only independently Java-verified actual-URI raw matches."""
from pathlib import Path
import sys,json
sys.path.insert(0,'tools')
import oracle,m2_manifest as c,m2_language as l
stage=Path(sys.argv[1]).resolve();baseline=Path('target/m2/stage10-selection-baseline-01');old=json.loads((baseline/'selection.json').read_bytes());selection_path=Path(c.SELECTION);current=json.loads(selection_path.read_bytes());assert current==old and len(current['cases'])==1059
for case in old['cases']:assert Path(case['input']).read_bytes()==(baseline/'inputs'/case['input']).read_bytes(),case['id']
proposed=json.loads((stage/'proposed.json').read_bytes());rows=json.loads((stage/'results.json').read_bytes());by_id={r['id']:r for r in rows};assert len(proposed)==len(rows)==len(by_id)
for case in proposed:
 row=by_id[case['id']];folder=stage/'cases'/case['id'];assert row['status']=='pass',row['id'];assert oracle.sha256(Path(case['input']))==row['input_sha256'] and Path(case['input']).read_bytes()==(folder/'input.pkl').read_bytes();assert row['java']['exit_code']==(0 if case['expected_outcome']=='success'else 1)
 assert l.status(case,row['java'],row['rust'],*((folder/f'{runtime}.{channel}.bin').read_bytes()for runtime in('java','rust')for channel in('stdout','stderr')),(folder/'java.outcome.bin').read_bytes())=='pass'
ids={r['id']for r in proposed}
for case in proposed:
 if 'metamorphic_relation'in case:assert set(case['metamorphic_relation']['case_ids'])<=ids
relations=l.check_relations(dict(cases=proposed),stage);assert len(relations)==3 and all(r['status']=='pass'for r in relations)
assert not(ids&{r['id']for r in old['cases']});current['cases'].extend(proposed);selection_path.write_text(json.dumps(current,ensure_ascii=False,indent=2)+'\n')
assert json.loads(selection_path.read_bytes())['cases'][:1059]==old['cases']
for case in old['cases']:assert Path(case['input']).read_bytes()==(baseline/'inputs'/case['input']).read_bytes(),case['id']
promotion=dict(schema_version=1,scope='Bounded new Reference/declaration-type metadata probes only; no upstream suite contract replaced, no new development exceptions.',selected_count=len(proposed),total_selected=len(current['cases']),original1059_definitions_and_input_bytes_preserved=True,metamorphic_relations_added=len(relations),relations=relations,actual_uri_stage=str(stage),baseline=str(baseline.resolve()),original_selection_sha256=oracle.sha256(baseline/'selection.json'),candidate=json.loads((stage/'candidate.json').read_bytes()),selected=[dict(id=r['id'],exploratory_id=r['original_id'],exploration=r['exploration'],exploratory_uri=r['exploratory_uri'],actual_uri=r['actual_uri'],input_sha256=r['input_sha256'])for r in rows],excluded=json.loads((stage/'excluded.json').read_bytes()))
Path('target/m2/stage10-promotion.json').write_bytes(c.encoded(promotion));print(len(proposed),'newcases;',len(current['cases']),'total;3newrelations;prior1059definitions+bytespreserved')
