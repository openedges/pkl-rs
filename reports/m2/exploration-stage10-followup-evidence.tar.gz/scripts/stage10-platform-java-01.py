from pathlib import Path
import json, sys
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'tools'))
import oracle, m2_language as runner, m2_manifest as manifest
out=ROOT/'target/m2/stage10-platform-java-01'
out.mkdir(parents=True,exist_ok=False)
meta=oracle.ensure_oracle(ROOT,fetch=False)
(out/'oracle.json').write_bytes(manifest.encoded(meta))
helper=out/'M2BoundaryProbe.java'
helper.write_bytes((ROOT/'target/m2/stage7-platform-java-02/M2BoundaryProbe.java').read_bytes())
classes=out/'classes';classes.mkdir()
v=runner.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(classes),str(helper)],out,'javac',meta['environment'])
assert v['exit_code']==0
cases=[
('paths-rendering','''import "pkl:ref" as deferred
class D extends deferred.Domain {
  function renderReference(r): String = r.getData() + "/" + r.getPath()[0].property + "[" + r.getPath()[1].key + "]"
}
class Holder { values: Mapping<String, String> = throw("referent must stay deferred") }
local r = deferred.Reference(new D {}, Holder, "root").values["x"]
result = "resolved: \(r)"
'''),
('equality-types','''import "pkl:ref"
class D extends ref.Domain { function renderReference(r): String = throw("comparison must not render") }
class A { value: String(length > 0) = throw("left referent must stay deferred") }
class B { value: String = throw("right referent must stay deferred") }
local d = new D {}
local left = ref.Reference(d, A, 42).value
local right = ref.Reference(d, B, 42).value
result = left == right && left is ref.Reference<D, String> && left.getPath()[0].isProperty
'''),
('constructor-diagnostic','''import "pkl:ref"
result = ref.Reference(42, String, null)
'''),
('render-diagnostic','''import "pkl:ref"
class D extends ref.Domain { function renderReference(r): String = throw("domain render failed") }
result = ref.Reference(new D {}, String, null).toString()
''')]
prefix=meta['command'][:meta['command'].index('-cp')]
rows=[]
for name,src in cases:
 d=out/name;d.mkdir();p=d/'input.pkl';p.write_text(src)
 cmd=[*prefix,'-cp',str(classes)+':'+meta['artifact'],'M2BoundaryProbe',str(p),'file:///m2-platform.pkl','false',str(d/'java.outcome.bin')]
 result=runner.capture(cmd,d,'java',meta['environment'])
 rows.append(dict(id=name,source=src,source_sha256=oracle.sha256(p),capture=result,outcome_sha256=oracle.sha256(d/'java.outcome.bin'),stdout=(d/'java.stdout.bin').read_text(),stderr=(d/'java.stderr.bin').read_text()))
 print(name,result['exit_code'],repr(rows[-1]['stdout']),flush=True)
(out/'report.json').write_bytes(manifest.encoded(dict(scope='Pinned Java captures at exact JS adapter URI; candidate/platform verification separate.',helper_sha256=oracle.sha256(helper),uri='file:///m2-platform.pkl',results=rows)))
