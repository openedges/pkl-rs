from pathlib import Path
import sys,json
sys.path.insert(0,'tools')
import oracle,m2_manifest as c,m2_language as l
matrix=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(c.ROOT,fetch=False);(out/'oracle.json').write_bytes(c.encoded(meta));(out/'matrix.json').write_bytes(matrix.read_bytes())
paths=['target/m2/stage10_matrix_run.py',str(matrix.relative_to(c.ROOT)),'tools/m2_language.py','tools/m2_manifest.py','tools/oracle.py','tools/java/M2LanguageProbe.java','oracle.lock.json','references.lock']
identities={}
for p in paths:
 dest=out/'sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(Path(p).read_bytes());identities[p]=oracle.sha256(Path(p))
(out/'source-identities.json').write_bytes(c.encoded(identities));classes=out/'artifacts/java';classes.mkdir(parents=True)
a=l.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(classes),str((out/'sources/tools/java/M2LanguageProbe.java').resolve())],out,'javac',meta['environment']);assert a['exit_code']==0
results=[]
for row in json.loads(matrix.read_bytes()):
 folder=out/'cases'/row['id'];folder.mkdir(parents=True);src=folder/'input.pkl';src.write_text(row['source'])
 java=l.capture_java(meta,out/'artifacts/language_probe',row['id'],src,row['expression'],folder)
 results.append(dict(id=row['id'],input_uri=src.as_uri(),input_sha256=oracle.sha256(src),expected_outcome=row['expected_outcome'],java=java))
 print(row['id'],java['exit_code'],repr((folder/'java.stdout.bin').read_bytes()),flush=True)
(out/'results.json').write_bytes(c.encoded(results));(out/'evidence-sha256.json').write_bytes(c.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
