from pathlib import Path
import sys, json, shutil
sys.path.insert(0, 'tools')
import oracle, m2_manifest as c, m2_language as l
out=Path(sys.argv[1]).resolve(); out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(c.ROOT,fetch=False)
(out/'oracle.json').write_bytes(c.encoded(meta))
base_source='''import "pkl:ref"
class D extends ref.Domain {
  function renderReference(r): String = r.getData().toString()
}
local d = new D {}
'''
rows=[]
def add(id,body,expression='result',failure=False,group='core',prefix=base_source):
 rows.append(dict(id=id,source=prefix+body,expression=expression,expected_outcome='failure' if failure else 'success',group=group))
add('constructor-data','local r = ref.Reference(d, String, "root")\nresult = r.getData()\n')
add('constructor-domain','local r = ref.Reference(d, String, null)\nresult = r.getDomain() == d\n')
add('constructor-empty-path','result = ref.Reference(d, String, null).getPath().length\n')
add('constructor-class','result = ref.Reference(d, String, null) is ref.Reference<D, String>\n')
add('domain-invalid','result = ref.Reference("wrong", String, null)\n',failure=True)
add('class-invalid','result = ref.Reference(d, 42, null)\n',failure=True)
add('new-reference-invalid','result = new ref.Reference {}\n',failure=True)
add('property-unforced','class A { value: String = throw("not evaluated") }\nresult = ref.Reference(d, A, null).value is ref.Reference<D, String>\n',group='metadata')
add('property-inherited','open class A { value: String = throw("not evaluated") }\nclass B extends A\nresult = ref.Reference(d, B, null).value is ref.Reference<D, String>\n',group='metadata')
add('property-override','open class A { value: String | Int }\nclass B extends A { value: String }\nresult = ref.Reference(d, B, null).value is ref.Reference<D, String>\n',group='metadata')
add('property-hidden','class A { hidden value: String }\nresult = ref.Reference(d, A, null).value is ref.Reference<D, String>\n',group='metadata')
add('property-local','class A { local value: String = "x" }\nresult = ref.Reference(d, A, null).value\n',failure=True,group='metadata')
add('property-fixed','class A { fixed value: String = throw("not evaluated") }\nresult = ref.Reference(d, A, null).value is ref.Reference<D, String>\n',group='metadata')
add('property-missing','class A { value: String }\nresult = ref.Reference(d, A, null).absent\n',failure=True,group='metadata')
add('property-method','class A { function value() = 1 }\nresult = ref.Reference(d, A, null).value\n',failure=True,group='metadata')
add('property-string-external','result = ref.Reference(d, String, null).length\n',failure=True,group='metadata')
add('property-path','class A { value: String }\nlocal r = ref.Reference(d, A, "root").value\nresult = r.getPath().length == 1 && r.getPath()[0].property == "value" && r.getPath()[0].key == null && r.getPath()[0].isProperty && !r.getPath()[0].isSubscript && r.getData() == "root" && r.getDomain() == d\n')
for cls in ['List','Listing','Map','Mapping','Dynamic']:
 key='-9' if cls in ['List','Listing'] else '"missing"'
 add('subscript-bare-'+cls.lower(),f'local r = ref.Reference(d, {cls}, null)[{key}]\nresult = r is ref.Reference<D, String> && r.getPath()[0].isSubscript && !r.getPath()[0].isProperty && r.getPath()[0].property == null && r.getPath()[0].key == {key}\n',group='subscript')
for cls,ty,key in [('List','List<String>','-1'),('Listing','Listing<Int>','9223372036854775807'),('Map','Map<String, Int>','"missing"'),('Mapping','Mapping<String, String?>','"missing"')]:
 target='String' if cls=='List' else ('Int' if cls in ['Listing','Map'] else 'String?')
 add('subscript-typed-'+cls.lower(),f'class H {{ p: {ty} }}\nresult = ref.Reference(d, H, null).p[{key}] is ref.Reference<D, {target}>\n',group='subscript')
for cls in ['List','Listing']:
 add('subscript-invalid-'+cls.lower(),f'result = ref.Reference(d, {cls}, null)["wrong"]\n',failure=True,group='subscript')
for cls in ['Map','Mapping']:
 add('subscript-keytype-'+cls.lower(),f'class H {{ p: {cls}<String, Int> }}\nresult = ref.Reference(d, H, null).p[42]\n',failure=True,group='subscript')
add('subscript-keyliteral','class H { p: Mapping<"key", Int> }\nresult = ref.Reference(d, H, null).p["key"] is ref.Reference<D, Int>\n',group='subscript')
add('subscript-keyliteral-invalid','class H { p: Mapping<"key", Int> }\nresult = ref.Reference(d, H, null).p["other"]\n',failure=True,group='subscript')
add('subscript-keyconstraint-erased','class H { p: Mapping<Int(this > 0), String> }\nresult = ref.Reference(d, H, null).p[-1] is ref.Reference<D, String>\n',group='subscript')
add('subscript-keyclass-exact','open class K {}\nclass Child extends K\nclass H { p: Mapping<K, String> }\nresult = ref.Reference(d, H, null).p[new Child {}]\n',failure=True,group='subscript')
add('subscript-key-null','class H { p: Mapping<Null, String> }\nresult = ref.Reference(d, H, null).p[null].getPath()[1].key == null && ref.Reference(d, H, null).p[null].getPath()[1].isSubscript\n',group='subscript')
for cls in ['Dynamic','Listing','Mapping']:
 add('default-forbidden-'+cls.lower(),f'result = ref.Reference(d, {cls}, null).default\n',failure=True,group='metadata')
add('dynamic-unknown','result = ref.Reference(d, Dynamic, null).absent[null].another is ref.Reference<D, Int>\n')
add('null-chain','result = ref.Reference(d, Null, null).absent["key"].another is ref.Reference<D, Null>\n')
add('any-property-invalid','result = ref.Reference(d, Any, null).absent\n',failure=True)
add('constraints-erased','class H { p: String(throw("not evaluated")) }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, String>\n',group='normalization')
add('alias-erased','typealias Name = String(length > 10)\nclass H { p: Name }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, String>\n',group='normalization')
add('nullable','class H { p: String? }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, String?>\n',group='normalization')
add('nullable-narrow-false','class H { p: String? }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, String>\n',group='normalization')
add('nullable-property','class A { x: String }\nclass H { p: A? }\nresult = ref.Reference(d, H, null).p.x is ref.Reference<D, String?>\n',group='normalization')
add('union-property','class A { x: String }\nclass B { x: Int }\nclass H { p: A | B }\nresult = ref.Reference(d, H, null).p.x is ref.Reference<D, Int | String>\n',group='normalization')
add('union-order','class H { p: String | Int | Boolean; q: Boolean | String | Int }\nresult = (ref.Reference(d, H, null).p is ref.Reference<D, Boolean | Int | String>) && (ref.Reference(d, H, null).q is ref.Reference<D, String | Boolean | Int>)\n',group='normalization')
add('union-property-invalid','class A { x: String }\nclass H { p: A | Int }\nresult = ref.Reference(d, H, null).p.x\n',failure=True,group='normalization')
add('nested-typeargs','class H { p: List<String | Boolean | Int> }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, List<Int | String | Boolean>>\n',group='normalization')
add('reference-constraint-forbidden','result = ref.Reference(d, String, null) is ref.Reference<D, String(true)>\n',failure=True,group='normalization')
add('reference-nested-constraint-forbidden','result = ref.Reference(d, String, null) is ref.Reference<D, List<String(true)>>\n',failure=True,group='normalization')
add('reference-domain-false','class D2 extends ref.Domain { function renderReference(r): String = "other" }\nresult = ref.Reference(new D2 {}, String, null) is ref.Reference<D, String>\n')
add('reference-covariant','open class A {}\nclass B extends A\nresult = ref.Reference(d, B, null) is ref.Reference<ref.Domain, A>\n')
add('reference-cast-invalid','result = ref.Reference(d, String, null) as ref.Reference<D, Int>\n',failure=True)
add('literal-subtype','class H { p: "name" }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, String>\n',group='normalization')
add('intalias-preserved','class H { p: Int8 }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, Int16>\n',group='normalization')
add('intalias-float','class H { p: Int8 }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, Float>\n',group='normalization')
add('intalias-narrow-false','class H { p: Int16 }\nresult = ref.Reference(d, H, null).p is ref.Reference<D, Int8>\n',group='normalization')
add('equality-same','result = ref.Reference(d, String, "x") == ref.Reference(d, String, "x")\n',group='equality')
add('equality-type-false','result = ref.Reference(d, String, "x") == ref.Reference(d, Int, "x")\n',group='equality')
add('equality-domain-structural','result = ref.Reference(new D {}, String, null) == ref.Reference(new D {}, String, null)\n',group='equality')
add('equality-path-false','class H { a: String; b: String }\nresult = ref.Reference(d, H, null).a == ref.Reference(d, H, null).b\n',group='equality')
add('equality-constraint-erased','class A { x: String(length > 10) }\nclass B { x: String }\nresult = ref.Reference(d, A, null).x == ref.Reference(d, B, null).x\n',group='equality')
add('equality-data-false','result = ref.Reference(d, String, "x") == ref.Reference(d, String, "y")\n',group='equality')
add('hash-set','result = Set(ref.Reference(d, String, "x"), ref.Reference(d, String, "x"), ref.Reference(d, Int, "x")).length\n',group='equality')
add('hash-map','result = Map(ref.Reference(d, String, "x"), 42)[ref.Reference(new D {}, String, "x")]\n',group='equality')
add('render-to-string','result = ref.Reference(d, String, "root").toString()\n',group='render')
add('render-interpolation','result = "before:\\(ref.Reference(d, String, "root")):after"\n',group='render')
add('render-domain-throw','class Bad extends ref.Domain { function renderReference(r): String = throw("domain failed") }\nresult = ref.Reference(new Bad {}, String, null).toString()\n',failure=True,group='render')
add('render-path','class H { p: Listing<String> }\nclass PathDomain extends ref.Domain { function renderReference(r): String = "\\(r.getData())/\\(r.getPath()[0].property)/\\(r.getPath()[1].key)" }\nresult = ref.Reference(new PathDomain {}, H, "root").p[-1].toString()\n',group='render')
# Freeze helpers, upstream semantic authority, and original selection before executing.
paths=['target/m2/stage10_explore.py','tools/m2_language.py','tools/m2_manifest.py','tools/oracle.py','tools/java/M2LanguageProbe.java','oracle.lock.json','references.lock','tests/fixtures/m2/cases.json','external/pkl/stdlib/ref.pkl','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmReference.java']
paths += [str(p) for p in Path('external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/errors').glob('reference*.pkl')]
paths += ['external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/reference.pkl','external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/reference.pkl']
identities={}
for p in paths:
 src=Path(p); dest=out/'sources'/p; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(src.read_bytes()); identities[p]=oracle.sha256(src)
(out/'source-identities.json').write_bytes(c.encoded(identities));(out/'matrix.json').write_bytes(c.encoded(rows))
classes=out/'artifacts/java';classes.mkdir(parents=True)
javac=Path(meta['java']).with_name('javac');compile=l.capture([str(javac),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(classes),str((out/'sources/tools/java/M2LanguageProbe.java').resolve())],out,'javac',meta['environment']);assert compile['exit_code']==0
results=[]
for row in rows:
 folder=out/'cases'/row['id'];folder.mkdir(parents=True);src=folder/'input.pkl';src.write_text(row['source']);java=l.capture_java(meta,out/'artifacts/language_probe',row['id'],src,row['expression'],folder)
 result=dict(id=row['id'],input_uri=src.as_uri(),input_sha256=oracle.sha256(src),expected_outcome=row['expected_outcome'],java=java);results.append(result)
 print(row['id'],java['exit_code'],repr((folder/'java.stdout.bin').read_bytes()),flush=True)
(out/'results.json').write_bytes(c.encoded(results));(out/'evidence-sha256.json').write_bytes(c.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
