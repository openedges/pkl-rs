"""Preserve all stage10 observations, including superseded failures and drafts."""
from pathlib import Path
import sys,json,shutil,collections
sys.path.insert(0,'tools')
import oracle,evidence,m2_language as lang
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
names=[f'stage10-exploration-{n:02d}'for n in range(1,12)]+['stage10-candidate-replay-01','stage10-candidate-replay-02','stage10-candidate-replay-03','stage10-candidate-key-replay-01','stage10-candidate-key-types-replay-01','stage10-selection-baseline-01','stage10-actual-uri-01','stage10-frontend-exploration-01','stage10-frontend-exploration-02','stage10-frontend-exploration-03','stage10-frontend-frames-01','stage10-frontend-new-01','stage10-platform-java-01','stage10-adapter-debug-01','prior-selection-stage10-provisional-01','prior-selection-stage10-provisional-02']
for name in names:
 src=Path('target/m2')/name;assert src.is_dir(),src
 index=src/'evidence-sha256.json'
 if index.exists():
  for rel,sha in json.loads(index.read_bytes()).items():assert oracle.sha256(src/rel)==sha,(name,rel)
 shutil.copytree(src,out/name)
shutil.copytree('target/m2/stage10-exploration-review-01/additional-pinned-dependencies',out/'additional-pinned-dependencies')
files=['stage10_explore.py','stage10_supplement.py','stage10_matrix_run.py','stage10_compare.py','stage10_stage_selection.py','stage10_promote.py','stage10_package_explorations.py','stage10_package_followup.py','replay_prior_selection_stage10_provisional.py','stage10-platform-java-01.py','stage10-promotion.json','stage10-proposed-ids.json']+[f'stage10-matrix-{n:02d}.json'for n in range(3,12)]
for name in files:
 p=out/'scripts'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(Path('target/m2')/name,p)
# Retain the exact reused Java subset so the two prior-selection comparisons
# can be checked independently of mutable target paths. The original complete
# baseline archive is linked by its checksum and is not replaced by this subset.
baseline=Path('target/m2/language-stage9-final-02');oldreport=json.loads((baseline/'report.json').read_bytes());java=out/'reused-prior-java';java.mkdir()
for name in ['report.json','oracle.json']:shutil.copy2(baseline/name,java/name)
for row in oldreport['results']:
 src=baseline/'cases'/row['id'];dest=java/'cases'/row['id'];dest.mkdir(parents=True)
 for name in ['input.pkl','java.stdout.bin','java.stderr.bin','java.outcome.bin','java.process.json']:shutil.copy2(src/name,dest/name)
 for channel in ('stdout','stderr'):assert oracle.sha256(dest/f'java.{channel}.bin')==row['java'][channel+'_sha256']
 assert oracle.sha256(dest/'java.outcome.bin')==row['java']['outcome_sha256']
rows=[]
for n in range(1,12):
 p=Path(f'target/m2/stage10-exploration-{n:02d}');matrix={r['id']:r for r in json.loads((p/'matrix.json').read_bytes())}
 for r in json.loads((p/'results.json').read_bytes()):
  folder=p/'cases'/r['id'];process=r['java'];assert not process['timed_out'];outcome=(folder/'java.outcome.bin').read_bytes();assert outcome in (b'success\n',b'pkl-exception\torg.pkl.core.PklException\n')
  rows.append(dict(exploration=p.name,id=r['id'],input_uri=r['input_uri'],input_sha256=r['input_sha256'],expression=matrix[r['id']]['expression'],group=matrix[r['id']]['group'],provisional_expected_outcome=r['expected_outcome'],observed_java_outcome='success'if process['exit_code']==0 else'pkl-exception',expectation_matches=(r['expected_outcome']=='success')==(process['exit_code']==0)))
promotion=json.loads(Path('target/m2/stage10-promotion.json').read_bytes());final=json.loads(Path('target/m2/stage10-candidate-replay-03/results.json').read_bytes());actual=json.loads(Path('target/m2/stage10-actual-uri-01/results.json').read_bytes())
assert len(rows)==191 and len(actual)==143 and all(r['status']=='pass'for r in actual);assert promotion['selected_count']==143
summary=dict(schema_version=1,scope='Bounded Reference/declaration-type metadata and scalar evaluateExpressionString probes. Selected upstream API expressions do not execute the full original LanguageSnippetTests, test assertion, renderer, or JVM public API contracts. All remaining unsupported or unmapped scope stays open; no new development exceptions.',native_java_calls=len(rows),observed_java_outcomes=dict(collections.Counter(r['observed_java_outcome']for r in rows)),upstream_selected_expression_calls=sum(r['group']=='upstream-selected-expression'for r in rows),expectation_drift=[r for r in rows if not r['expectation_matches']],final_exploratory_comparison=dict(counts=dict(collections.Counter(r['status']for r in final)),known_remaining=[dict(exploration=Path(r['baseline']).name,id=r['id'])for r in final if r['status']!='pass'],source_binding='Unbound caller-supplied frozen artifacts and source snapshots; the subsequent recorded-build main language acquisition is separate.'),actual_fixture_uri_comparison=dict(cases=len(actual),counts=dict(collections.Counter(r['status']for r in actual)),metamorphic_relations_added=3,total_selected=1202,total_relations=44,original1059_definitions_and_input_bytes_preserved=True),prior_selection_replay=dict(cases=1059,counts=json.loads(Path('target/m2/prior-selection-stage10-provisional-02/report.json').read_bytes())['status_counts'],java='Reused complete original Java raw bytes at original unchanged input URIs; no fresh Java acquisition is claimed.',original_complete_baseline_archive=dict(path='reports/m2/language-stage9-final-evidence.tar.gz',sha256=oracle.sha256(Path('reports/m2/language-stage9-final-evidence.tar.gz')))),early_frontend_observations=dict(unbound_without_frozen_candidate=['stage10-frontend-exploration-01','stage10-frontend-exploration-02'],targeted_frozen_artifact_without_complete_matching_source_tree=['stage10-frontend-exploration-03','stage10-frontend-new-01','stage10-frontend-frames-01'],reason='Preserved provisional observations only. Never infer missing artifact/source identities; use native frozen replay03 plus exact actual-URI revalidation and the subsequent recorded-build final acquisition for current claims.'),additional_platform_java='Four separately scoped Java captures at exact JS URIs retain their own metadata/helper/process/raw records in stage10-platform-java-01; not counted as native191.',initial_158_call_archive=dict(path='reports/m2/exploration-stage10-evidence.tar.gz',sha256=oracle.sha256(Path('reports/m2/exploration-stage10-evidence.tar.gz')),preserved_unchanged=True),cases=rows)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');evidence.create(out,Path('reports/m2/exploration-stage10-followup-evidence.tar.gz'),[]);print(json.dumps({k:v for k,v in summary.items()if k not in('cases','expectation_drift','final_exploratory_comparison')},indent=2))
