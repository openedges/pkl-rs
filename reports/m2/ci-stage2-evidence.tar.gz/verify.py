"""Recheck downloaded evidence against the exact CI commit without running its binaries."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ARTIFACT = HERE / "artifact/ci-language"
IDENTIFIERS = HERE / "artifact/ci-identifier"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def committed(path, commit):
    return subprocess.run(
        ["git", "show", f"{commit}:{path}"], check=True, capture_output=True
    ).stdout


run = json.loads((HERE / "run.json").read_bytes())
jobs = json.loads((HERE / "jobs.json").read_bytes())["jobs"]
assert run["head_sha"] == "281ef6ccdf050a0a23b90eea8006590fc53752c9"
assert run["id"] == 39386841661
assert run["conclusion"] == "success"
assert len(jobs) == 6 and all(job["conclusion"] == "success" for job in jobs)
metadata = next(
    row for row in json.loads((HERE / "artifacts.json").read_bytes())["artifacts"]
    if row["name"] == "m2-language-evidence"
)
assert metadata["digest"] == "sha256:" + sha(HERE / "artifact.zip")
report = json.loads((ARTIFACT / "report.json").read_bytes())
for path, digest in report["source_sha256"].items():
    assert sha(ARTIFACT / "sources" / path) == digest, path
    assert hashlib.sha256(committed(path, run["head_sha"])).hexdigest() == digest, path

# Import only source files whose bytes were just checked against this CI commit.
# Their default inventory root is the frozen snapshot. URI checks use the
# original acquisition root, preserving the recorded absolute paths verbatim.
sys.path.insert(0, str(ARTIFACT / "sources/tools"))
import m2_language as frozen

original = Path(report["candidate"]["build"]["command"][-1]).parent
frozen.ROOT = original
assert frozen.check_report(ARTIFACT) == report
assert report["candidate"]["source_binding"] == "recorded-build"
assert frozen.development_passes(report, ARTIFACT)
assert not frozen.subset_passes(report)
assert report["full_gate_failures"]
assert {row["id"] for row in report["results"] if row["status"] != "pass"} == {
    "error-cycle", "error-remainder-zero",
}

identifier = json.loads((IDENTIFIERS / "report.json").read_bytes())
assert identifier["exit_code"] == 0 and identifier["source_stability"]
files = {
    str(path.relative_to(IDENTIFIERS))
    for path in IDENTIFIERS.rglob("*")
    if path.is_file() and path.name != "report.json"
}
assert files == set(identifier["evidence_sha256"])
for path, digest in identifier["evidence_sha256"].items():
    assert sha(IDENTIFIERS / path) == digest, path
for path, digest in identifier["sources"].items():
    assert sha(IDENTIFIERS / "sources" / path) == digest, path
    if path.startswith("external/pkl/"):
        revision = identifier["oracle"]["source"]["revision"]
        upstream = subprocess.run(
            ["git", "-C", "external/pkl", "show", f"{revision}:{path.removeprefix('external/pkl/')}"],
            check=True, capture_output=True,
        ).stdout
        assert hashlib.sha256(upstream).hexdigest() == digest, path
    else:
        assert hashlib.sha256(committed(path, run["head_sha"])).hexdigest() == digest, path
assert (IDENTIFIERS / "unicode_identifier.rs").read_bytes() == committed(
    "crates/pkl-runtime/src/parser/unicode_identifier.rs", run["head_sha"]
)
import m2_identifier_tables as identifier_tool

assert identifier_tool.render(
    (IDENTIFIERS / "stdout.bin").read_bytes(),
    identifier["oracle"],
    identifier["sources"]["tools/java/M2IdentifierProbe.java"],
) == (IDENTIFIERS / "unicode_identifier.rs").read_bytes()
assert not (IDENTIFIERS / "stderr.bin").read_bytes()

summary = {
    "run_id": run["id"],
    "commit": run["head_sha"],
    "url": run["html_url"],
    "jobs": [{"name": job["name"], "conclusion": job["conclusion"]} for job in jobs],
    "artifact_id": metadata["id"],
    "artifact_sha256": sha(HERE / "artifact.zip"),
    "exact_committed_source_files_verified": len(report["source_sha256"]),
    "language_evidence_files_verified": len(report["evidence_sha256"]),
    "identifier_evidence_files_verified": len(identifier["evidence_sha256"]),
    "raw_comparisons": report["status_counts"],
    "metamorphic_relations": len(report["metamorphic_results"]),
    "identifier_intervals": identifier["interval_counts"],
    "strict_subset_complete": False,
    "full_m2_complete": False,
    "scope": "Stage 2 CI and downloaded evidence; cycle/remainder diagnostics and remaining language requirements stay incomplete.",
}
(HERE / "verification.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, sort_keys=True))
