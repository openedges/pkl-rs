# Persistent class-publication evidence

The final candidate compares 18 ordered call sequences, each repeated in a new Java evaluator and Rust VM/module: 36 sequence executions and 194 matching raw status/stdout/stderr call results. Each evaluator remains alive across successful and failed calls. The Rust adapter retains the module through GC between calls. Sources, fixture order, oracle/JDK, runtime/compiler and candidate artifacts are identified in the acquisition report.

`stage12-class-lifecycle-03` is the passing selected candidate. `stage12-class-lifecycle-02` retains 22 genuine diagnostic mismatches; it passes its frozen acquisition checker and fails its selected contract. `stage12-class-lifecycle-01` preserves a source-drift rejection before comparisons. Java-only observations preserve unsupported paths, exploratory errors and two30second cyclic-hierarchy traversal timeouts. `SUMMARY.json` identifies their precise scope.

This is a distinct bounded sequence denominator. It does not change the1291single-expression inputs or46metamorphic relations, establish full M2/API compatibility, turn internal scheduler tests into Java language comparisons, or establish performance/memory goals. Actual Java Host reentry during annotation construction is observed separately; Rust annotation syntax remains unsupported. Full multi-source module-cache parity and cyclic traversal remain unverified.

Rebuild intermediates under each original `build/` are omitted. Original source snapshots, cargo/compiler/process captures, copied native executables, compiled Java classes and raw per-call outputs remain. Acquisition inventories exclude rebuild intermediates. Use Python `-B` when invoking a frozen source checker to keep bytecode caches out of evidence trees.
