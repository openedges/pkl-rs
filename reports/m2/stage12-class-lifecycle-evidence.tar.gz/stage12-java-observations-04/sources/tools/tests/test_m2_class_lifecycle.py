"""Failure detection for persistent class evidence, independent of Pkl semantics."""
import copy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import m2_class_lifecycle as tool


class ClassLifecycleEvidenceTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.calls = ['trigger', 'trigger', 'early']

    def process(self, directory, values=None):
        directory.mkdir(parents=True)
        values = values or [('error', b'', b'full error \n'), ('success', b'true', b''), ('success', b'10', b'')]
        result = {'status': 'executed', 'exit_code': 0}
        protocol = ''.join(f'call={i} completed\n' for i in range(len(values))).encode() + b'closed\n'
        for name, data in [('stdout', protocol), ('stderr', b'')]:
            (directory / (name + '.bin')).write_bytes(data)
            result[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        for index, (status, stdout, stderr) in enumerate(values):
            for name, data in [('status', (status + '\n').encode()), ('stdout', stdout), ('stderr', stderr), ('error-class', b'')]:
                (directory / f'{index}.{name}.bin').write_bytes(data)
        return result

    def pair(self):
        row = {language: self.process(self.root / language) for language in ['java', 'rust']}
        return row

    def test_raw_whitespace_difference_is_preserved(self):
        row = self.pair()
        (self.root / 'rust/0.stderr.bin').write_bytes(b'full error\n')
        result = tool.observe_pair(self.root, row, self.calls, ['java', 'rust'])
        self.assertEqual([r['status'] for r in result['comparisons']], ['mismatch', 'pass', 'pass'])

    def test_missing_duplicate_or_reordered_protocol_fails_acquisition(self):
        for protocol in [b'', b'call=0 completed\nclosed\n', b'call=1 completed\ncall=0 completed\ncall=2 completed\nclosed\n']:
            with tempfile.TemporaryDirectory() as temporary:
                directory = Path(temporary)
                result = self.process(directory / 'rust')
                (directory / 'rust/stdout.bin').write_bytes(protocol)
                result['stdout'] = {'bytes': len(protocol), 'sha256': hashlib.sha256(protocol).hexdigest()}
                self.assertEqual(tool.observe_process(directory / 'rust', result, self.calls)['status'], 'acquisition-failed')

    def test_process_failure_does_not_grant_call_passes(self):
        row = self.pair()
        for key, value in [('exit_code', 2), ('status', 'timeout')]:
            changed = copy.deepcopy(row); changed['rust'][key] = value
            result = tool.observe_pair(self.root, changed, self.calls, ['java', 'rust'])
            self.assertTrue(all(r['status'] == 'unexecuted' for r in result['comparisons']))

    def test_missing_extra_or_inconsistent_call_capture_rejected(self):
        row = self.pair()
        extra = self.root / 'rust/3.status.bin'; extra.write_bytes(b'success\n')
        with self.assertRaisesRegex(ValueError, 'extra'):
            tool.observe_pair(self.root, row, self.calls, ['java', 'rust'])
        extra.unlink()
        (self.root / 'rust/0.stderr.bin').write_bytes(b'')
        with self.assertRaisesRegex(ValueError, 'inconsistent'):
            tool.observe_pair(self.root, row, self.calls, ['java', 'rust'])

    def test_oracle_internal_error_never_passes_even_when_equal(self):
        row = self.pair()
        for language in ['java', 'rust']:
            (self.root / language / '0.status.bin').write_bytes(b'oracle-error\n')
        result = tool.observe_pair(self.root, row, self.calls, ['java', 'rust'])
        self.assertTrue(result['comparisons'][0]['raw_equal'])
        self.assertEqual(result['comparisons'][0]['status'], 'mismatch')

    def test_java_only_and_empty_evidence_cannot_pass_contract(self):
        self.assertFalse(tool.contract_passes({'languages': ['java'], 'cases': [{'observations': {'comparisons': []}}]}))
        self.assertFalse(tool.contract_passes({'languages': ['java', 'rust'], 'cases': []}))

    def test_process_channel_tampering_rejected(self):
        row = self.pair()
        (self.root / 'rust/stdout.bin').write_bytes(b'changed')
        with self.assertRaisesRegex(ValueError, 'identity'):
            tool.observe_pair(self.root, row, self.calls, ['java', 'rust'])

    def test_fixture_manifest_has_nonempty_supported_queries(self):
        manifest = tool.manifest_at(tool.ROOT)
        self.assertGreater(len(manifest['sequences']), 0)
        self.assertTrue(manifest['unexecuted_groups'])


if __name__ == '__main__':
    unittest.main()
