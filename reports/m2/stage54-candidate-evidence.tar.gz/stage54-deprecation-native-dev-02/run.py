import sys, os, json, hashlib, shutil, subprocess
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import benchmark
ROOT=Path.cwd()
OUT=ROOT/'target/m2/stage54-deprecation-native-dev-02'
ORACLE=ROOT/'target/m2/stage54-deprecation-oracle-03'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted([p for p in (ROOT/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.toml')]+[ROOT/'Cargo.toml',ROOT/'Cargo.lock',ROOT/'rust-toolchain.toml'])
env={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL','TZ','TERM','RUSTUP_HOME','CARGO_HOME')}
env['CARGO_INCREMENTAL']='0'
report={'scope':'Exploratory candidate observations while implementation is mutable; not final compatibility evidence','source_before':{str(p.relative_to(ROOT)):sha(p) for p in paths},'environment':env,'results':[]}
benchmark.write_json(OUT/'report.json',report)
result=benchmark.capture(['cargo','build','-p','pkl-runtime','--example','deprecation_fixture_probe','--locked'],ROOT,env,OUT/'build',timeout=180)
report['build']=result
report['source_after_build']={str(p.relative_to(ROOT)):sha(p) for p in paths}
benchmark.write_json(OUT/'report.json',report)
assert result['exit_code']==0
binary=OUT/'deprecation_fixture_probe'
shutil.copy2(ROOT/'target/debug/examples/deprecation_fixture_probe',binary)
report['artifact_sha256']=sha(binary)
cases=json.loads((ORACLE/'sources/tests/fixtures/m2-deprecation/cases.json').read_bytes())['cases']
selected={'closed-message-default-empty-custom','closed-retained-site','closed-fresh-query-sites','open-retained-site','super-retained-site'}
selected.update(row['id'] for row in cases if row['action'] in ('close','close-reenter','throw-once') or row['callback'])
for row in cases:
 if row['id'] not in selected: continue
 directory=OUT/'cases'/row['id'];directory.mkdir(parents=True)
 source=ORACLE/'sources/tests/fixtures/m2-deprecation'/row['source']
 shutil.copyfile(source,directory/'input.pkl')
 (directory/'expressions.txt').write_bytes(('\n'.join(row['expressions'])+'\n').encode())
 process=benchmark.capture([str(binary),str(directory),row['uri'],row['action'],row['callback'],str(row['callback_after'])],ROOT,env,directory/'process',timeout=30)
 expected=ORACLE/'cases'/row['id']/'0'
 common={p.name:p.read_bytes() for p in expected.glob('*.bin') if not p.name.endswith('.error-class.bin')}
 differences=[name for name,data in common.items() if not (directory/name).exists() or (directory/name).read_bytes()!=data]
 protocol=(directory/'process/stdout.bin').read_bytes()==(expected/'process/stdout.bin').read_bytes()
 result={'id':row['id'],'process':process,'differing_common_payloads':differences,'protocol_equal':protocol}
 report['results'].append(result)
 benchmark.write_json(OUT/'report.json',report)
 print(row['id'],process['exit_code'],len(differences),'protocol='+str(protocol),flush=True)
print('exploratory capture complete',flush=True)
