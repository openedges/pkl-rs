# 동결 native 정책 parser 독립 검토01

원래 parser e8fd0473 /test48a38746 소스와 raw 필드 계약을 읽었다. protocol mock에서 동일 token의 denied policy 중복행 및 callIndex 1→0 역전행을 받아들이는 두 결함을 확인했다. allowed policy의 누락된 reader는 예상대로 거절했다. mock-inputs/에 각 반례의 실제 UTF8/UTF16 raw 파일을 보존했다. 실제 Java/native/Node/browser 실행 결과가 아니다.

허용 정책과 read effect의 (callIndex, URI) 순서는 정확히 연결되고, counter continuity 및 마지막 consumed 파일집합 검사는 누락·추가 raw 레코드를 거절한다. UTF16과 별도로 저장한 UTF8 일치도 검사한다. 다만 이 join은 거부 policy 중복/순서를 보호하지 못하므로 token 유일성 및 callIndex 비감소 검사가 필요했다.

각 mock 구간에는 parser/test의 입력 hash 변화가 없었다. A 예제는 작업 중이므로 두 mock 사이 hash가 달라졌고 최종 candidate로 취급하지 않는다. 최초 봉인 시도는 root 수정 후 live 소스를 옛 소스로 복사하려는 hash guard에서 멈췄으며 그 실패를 seal-attempt-01.json에 보존했다. 과거 parser/test 소스는 root tests01의 정확한 snapshot hash를 확인하여 복사했다. 후속02는 별도 소스·결과이다. Java 행정 lifecycle 동등성을 주장하지 않는다.
