from pathlib import Path
import hashlib,importlib.util,json,sys,tempfile
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=[R/'tools/collection_transform_native.py',R/'tools/tests/test_collection_transform_native.py',R/'crates/pkl-runtime/examples/stage51_collection_probe.rs'];before={str(p):sha(p)for p in paths};assert before[str(paths[0])]=='e8fd047361a380bbe18f267358650f9cd866ede50354ba2529c83973d0bb8a4b';assert before[str(paths[1])]=='48a38746a349ab2f4a5fee6d5d68bed39c3ff26e3d29418ccae0da3b1b9d4e6c'
spec=importlib.util.spec_from_file_location('owner_tests',paths[1]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
def run(name,modify):
 t=m.NativeCaptureTests('test_policy_denial_preserved_without_reader_effect');t.setUp()
 try:
  modify(t)
  try:actual=m.MODULE.actual_session(t.fixture,t.root);result={'name':name,'accepted':True,'resourcePolicyRequests':actual['resourcePolicyRequests'],'effects':actual['effects']}
  except Exception as e:result={'name':name,'accepted':False,'error':repr(e)}
  results.append(result)
 finally:t.doCleanups()
def second(t):
 t.fixture['expected'].append({'index':1})
 for p in list(t.root.glob('call-0.*')):
  (t.root/p.name.replace('call-0.','call-1.')).write_bytes(p.read_bytes())
 t.put('calls','2');t.put('retained-1','answer');t.put('retained-output-buffers','2')
def duplicate(t):
 t.policy('prop:denied',False);t.put('resource-policy-requests','2')
 for p in list(t.root.glob('resource-policy-0.*')):(t.root/p.name.replace('resource-policy-0.','resource-policy-1.')).write_bytes(p.read_bytes())
def reversed_calls(t):
 second(t);t.policy('prop:denied',False,call=1);t.put('resource-policy-requests','2')
 for p in list(t.root.glob('resource-policy-0.*')):(t.root/p.name.replace('resource-policy-0.','resource-policy-1.')).write_bytes(p.read_bytes())
 t.put('resource-policy-1.call-index','0');t.put('resource-policy-1.token','different-resource-token')
run('duplicate-denied-policy-token-and-record',duplicate)
run('denied-policy-call-order-reversed',reversed_calls)
# Control: the already tested strict join rejects an allowed policy with no read.
run('allowed-without-read-rejected',lambda t:t.policy('ct:allowed',True))
after={str(p):sha(p)for p in paths};assert before==after
report={'scope':'Protocol-only counterexamples; no evaluator/native/Java/Node/browser execution or production mutation.','sourceBefore':before,'sourceAfter':after,'results':results}
(O/'protocol-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
