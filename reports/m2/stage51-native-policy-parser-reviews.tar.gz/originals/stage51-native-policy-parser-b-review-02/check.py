from pathlib import Path
import hashlib,importlib.util,json,shutil
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();paths=[R/'tools/collection_transform_native.py',R/'tools/tests/test_collection_transform_native.py'];before={str(p):sha(p)for p in paths}
assert before[str(paths[0])]=='a33db79c391cb6e42b44b93d6968539a76422c25e6bde519f0b4007887d6c386';assert before[str(paths[1])]=='85aec27c11f9d57e82923877c0b6dad7b507b944138b51d45e1d9e6edda65823'
spec=importlib.util.spec_from_file_location('parser',paths[0]);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
for name,match in [('duplicate-denied-policy-token-and-record','duplicate resource policy token'),('denied-policy-call-order-reversed','resource policy API call order differs'),('allowed-without-read-rejected','resource policy/read effect join differs')]:
 source=O.parent/'stage51-native-policy-parser-b-review-01/mock-inputs'/name;dest=O/'mock-inputs'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(source,dest);fixture={'id':'synthetic-protocol-only','expected':[{'index':i}for i in range(2 if name=='denied-policy-call-order-reversed'else 1)]}
 try:m.actual_session(fixture,dest)
 except ValueError as error:assert match in str(error);results.append({'name':name,'rejected':True,'error':str(error)})
 else:raise AssertionError('counterexample accepted: '+name)
spec=importlib.util.spec_from_file_location('owner_tests',paths[1]);tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
for name,allowed in [('valid-denied-with-lossless-units',False),('valid-allowed-read-join',True)]:
 t=tests.NativeCaptureTests('test_policy_denial_preserved_without_reader_effect');t.setUp()
 try:
  uri='ct:allowed'if allowed else 'prop:\U0001f60a';t.policy(uri,allowed)
  if allowed:t.reader(uri)
  else:t.put('resource-policy-0.message','denied-\U0001f60a\ud800')
  actual=m.actual_session(t.fixture,t.root)
  if not allowed:assert actual['resourcePolicyRequests'][0]['message'].encode('utf-16-be','surrogatepass')=='denied-\U0001f60a\ud800'.encode('utf-16-be','surrogatepass')
  shutil.copytree(t.root,O/'mock-inputs'/name);results.append({'name':name,'accepted':True,'resourcePolicyRequests':actual['resourcePolicyRequests']})
 finally:t.doCleanups()
after={str(p):sha(p)for p in paths};assert before==after
for p in paths:
 dest=O/'sources'/p.relative_to(R);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);assert sha(dest)==before[str(p)]
report={'scope':'Corrective parser protocol-only readback; no engine/Java/native/Node/browser execution.','sourceBefore':before,'sourceAfter':after,'results':results,'sameOriginalCounterexampleBytes':True,'sourceChanges':[]};(O/'protocol-results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
