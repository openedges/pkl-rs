# 수정 native 정책 parser 독립 검토02

수정 parser a33db79c /tests85aec27c를 원래 반례의 동일 raw 파일에 적용했다. duplicate resource token과 API callIndex 역전이 각각 새 guard에서 거절된다. 기존 allowed-but-missing-reader 통제 입력도 거절한다. 정상 allowed/read 쌍과 supplementary/unpaired UTF16 메시지를 가진 정상 denied policy는 보존하며 받아들인다. API effect 자체의 callIndex 비감소 guard 추가도 소스에서 확인했다.

protocol-only 실제 실행7ce6e9 exit0이며 Java/native/Node/browser 평가나 빌드는 하지 않았다. 소스 before/after hash는 동일하다. root의16개 회귀 테스트는 별도 producer 결과이며 중복 실행하지 않았다. 이 bounded parser 범위에서 남은 구체 blocker를 찾지 못했다. 전체 Java 행정 이벤트/카운터 및 evaluator 호환성 통과를 뜻하지 않는다.

선언된 모든 policy 필드의 UTF8/UTF16 쌍을 소비한다. 허용 policy↔read effect join, read/log before/after와 terminal counter, 실제 raw 파일집합의 exact coverage가 유지된다. 거부 policy를 reader effect로 합성하거나 Java 이벤트로 재분류하지 않는다. URI ct:.* lookingAt 경계는 pinned helper 설정에 따른 startsWith("ct:")이며 다른 정책으로 일반화하지 않는다. resource token의 세션 내 유일성은 host.rs의 session:context:request token 구조와 일치한다.
