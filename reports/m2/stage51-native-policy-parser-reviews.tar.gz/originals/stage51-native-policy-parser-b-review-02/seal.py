from pathlib import Path
import hashlib,json,shutil,stat
O=Path(__file__).resolve().parent;R=O.parents[2];old=O.parent/'stage51-native-policy-parser-b-review-01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((old/'raw-protocol-results.json').read_bytes())
for rel in ['tools/collection_transform_native.py','tools/tests/test_collection_transform_native.py']:
 src=O.parent/'stage51-native-policy-parser-tests-01/sources'/rel;assert sha(src)==original['sourceBefore'][str(R/rel)];dest=old/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
(old/'seal-attempt-01.json').write_text(json.dumps({'actualToolChunk':'ebcf4f','exitCode':1,'error':'AssertionError while requiring original source hashes before copying live files','reason':'Root corrective parser and A WIP example advanced after protocol captures; source guard correctly refused to label current bytes as original. No initial sealed handoff existed. Historical parser/test bytes are now copied from authenticated root tests01 snapshots.','engineExecution':False},indent=2)+'\n')
(old/'REVIEW.ko.md').write_text('''# 동결 native 정책 parser 독립 검토01

원래 parser e8fd0473 /test48a38746 소스와 raw 필드 계약을 읽었다. protocol mock에서 동일 token의 denied policy 중복행 및 callIndex 1→0 역전행을 받아들이는 두 결함을 확인했다. allowed policy의 누락된 reader는 예상대로 거절했다. mock-inputs/에 각 반례의 실제 UTF8/UTF16 raw 파일을 보존했다. 실제 Java/native/Node/browser 실행 결과가 아니다.

허용 정책과 read effect의 (callIndex, URI) 순서는 정확히 연결되고, counter continuity 및 마지막 consumed 파일집합 검사는 누락·추가 raw 레코드를 거절한다. UTF16과 별도로 저장한 UTF8 일치도 검사한다. 다만 이 join은 거부 policy 중복/순서를 보호하지 못하므로 token 유일성 및 callIndex 비감소 검사가 필요했다.

각 mock 구간에는 parser/test의 입력 hash 변화가 없었다. A 예제는 작업 중이므로 두 mock 사이 hash가 달라졌고 최종 candidate로 취급하지 않는다. 최초 봉인 시도는 root 수정 후 live 소스를 옛 소스로 복사하려는 hash guard에서 멈췄으며 그 실패를 seal-attempt-01.json에 보존했다. 과거 parser/test 소스는 root tests01의 정확한 snapshot hash를 확인하여 복사했다. 후속02는 별도 소스·결과이다. Java 행정 lifecycle 동등성을 주장하지 않는다.
''')
(old/'report.json').write_text(json.dumps({'status':'CLOSED-with-two-protocol-findings','originalRawProofSha256':sha(old/'raw-protocol-results.json'),'initialProofSha256':sha(old/'protocol-results.json'),'protocolMockActualTerminals':[{'toolChunk':'551a7f','exitCode':0},{'toolChunk':'f6357b','exitCode':0}],'findings':2,'sourceBindings':original['sourceBefore'],'sourceChangedWithinMock':False,'wipExampleNotCandidate':True,'engineExecutions':0,'sourceEdits':0,'failedInitialSealRetained':True},indent=2)+'\n')
(old/'handoff.json').write_text(json.dumps({'reportSha256':sha(old/'report.json'),'reviewSha256':sha(old/'REVIEW.ko.md'),'rawProofSha256':sha(old/'raw-protocol-results.json'),'findings':2,'liveHandles':[]},indent=2)+'\n')
correct=json.loads((O/'protocol-results.json').read_bytes())
for p,h in correct['sourceBefore'].items():assert sha(Path(p))==h
(O/'REVIEW.ko.md').write_text('''# 수정 native 정책 parser 독립 검토02

수정 parser a33db79c /tests85aec27c를 원래 반례의 동일 raw 파일에 적용했다. duplicate resource token과 API callIndex 역전이 각각 새 guard에서 거절된다. 기존 allowed-but-missing-reader 통제 입력도 거절한다. 정상 allowed/read 쌍과 supplementary/unpaired UTF16 메시지를 가진 정상 denied policy는 보존하며 받아들인다. API effect 자체의 callIndex 비감소 guard 추가도 소스에서 확인했다.

protocol-only 실제 실행7ce6e9 exit0이며 Java/native/Node/browser 평가나 빌드는 하지 않았다. 소스 before/after hash는 동일하다. root의16개 회귀 테스트는 별도 producer 결과이며 중복 실행하지 않았다. 이 bounded parser 범위에서 남은 구체 blocker를 찾지 못했다. 전체 Java 행정 이벤트/카운터 및 evaluator 호환성 통과를 뜻하지 않는다.

선언된 모든 policy 필드의 UTF8/UTF16 쌍을 소비한다. 허용 policy↔read effect join, read/log before/after와 terminal counter, 실제 raw 파일집합의 exact coverage가 유지된다. 거부 policy를 reader effect로 합성하거나 Java 이벤트로 재분류하지 않는다. URI ct:.* lookingAt 경계는 pinned helper 설정에 따른 startsWith("ct:")이며 다른 정책으로 일반화하지 않는다. resource token의 세션 내 유일성은 host.rs의 session:context:request token 구조와 일치한다.
''')
root_test=O.parent/'stage51-native-policy-parser-tests-02/report.json'
report={'status':'CLOSED-corrective-read-only-parser-review-no-remaining-concrete-blocker','sourceBefore':correct['sourceBefore'],'sourceAfter':correct['sourceAfter'],'protocolActualToolChunk':'7ce6e9','protocolActualExitCode':0,'rawProofSha256':sha(O/'protocol-results.json'),'originalCounterexamplesByteIdentical':True,'originalReview':str(old),'originalFindingsClosed':2,'validControlsAccepted':2,'root16TestsReport':str(root_test),'root16TestsReportSha256':sha(root_test),'newEvaluatorExecutions':0,'sourceEdits':0,'fullJavaAdministrativeCompatibilityClaim':False,'liveHandles':[]}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');(O/'handoff.json').write_text(json.dumps({'reportSha256':sha(O/'report.json'),'reviewSha256':sha(O/'REVIEW.ko.md'),'rawProofSha256':sha(O/'protocol-results.json'),'originalReview':str(old),'liveHandles':[]},indent=2)+'\n')
for root in [old,O]:
 files={p.relative_to(root).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}for p in root.rglob('*')if p.is_file()and p.name not in ['inventory.json','closure.json','seal.stdout.bin','seal.stderr.bin']};(root/'inventory.json').write_text(json.dumps({'schema':1,'files':files},indent=2)+'\n');(root/'closure.json').write_text(json.dumps({'sealed':True,'handoffSha256':sha(root/'handoff.json'),'inventorySha256':sha(root/'inventory.json'),'liveHandles':[]},indent=2)+'\n');print(json.dumps({'root':str(root),'handoffSha256':sha(root/'handoff.json'),'reportSha256':sha(root/'report.json'),'closureSha256':sha(root/'closure.json'),'files':len(files)}))
