"""Retain closed Stage37 publication and independent source audit records."""
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent
ARCHIVE = ROOT / 'reports/m2/stage37-completion-evidence.tar.gz'
assert not ARCHIVE.exists()
commit = '646cf78a9b3775bf25e63e09146856c34225665e'

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def identity(name):
    p = ROOT / name
    return {'path': name, 'sha256': sha(p), 'bytes': p.stat().st_size}

def read(name):
    return json.loads((ROOT / name).read_text())

binding = read('reports/m2/stage37-source-binding.json')
assert binding['implementation_commit'] == commit and binding['source_binding_passed']
audit = read('target/m2/closeout-stage37-independent-audit-01/closure.json')
assert audit['status'] == 'closed'
process_root = ROOT / 'target/m2/closeout-stage37-01/processes'
processes = {}
for folder in sorted(process_root.iterdir()):
    report = json.loads((folder / 'process.json').read_text())
    assert report['exit_code'] == 0, folder
    for name in ['stdout.bin', 'stderr.bin']:
        assert sha(folder / name) == report[name]['sha256']
    processes[folder.name] = report
assert (process_root / 'implementation-remote/stdout.bin').read_text().split()[0] == commit

selected = [
    'target/m2/closeout-stage37-01',
    'target/m2/closeout-stage37-independent-audit-01',
    'target/m2/stage37-final-seal-01',
    'target/m2/stage37-final-seal-01.stdout.log',
    'target/m2/stage37-final-seal-01.stderr.log',
]
entries = {}
paths = {}
for name in selected:
    source = ROOT / name
    if source.is_file():
        files = [source]
    else:
        files = []
        for folder, dirs, names in os.walk(source):
            dirs[:] = sorted(dirs)
            assert not any((Path(folder) / d).is_symlink() for d in dirs)
            files.extend(Path(folder) / n for n in sorted(names))
    for p in files:
        assert p.is_file() and not p.is_symlink()
        key = str(p.relative_to(ROOT))
        assert key not in entries
        entries[key] = {'sha256': sha(p), 'bytes': p.stat().st_size}
        paths[key] = p
dependencies = [identity(name) for name in [
    'reports/m2/stage37-final-evidence.tar.gz',
    'reports/m2/stage37-final-summary.json',
    'reports/m2/stage37-origins-evidence.tar.gz',
    'reports/m2/stage37-origins-summary.json',
    'reports/m2/stage37-source-binding.json',
]]
inventory = {'scope': 'Closed Stage37 publication and independent archive/Git-source audit records.',
             'implementation_commit': commit, 'selected_roots': selected,
             'direct_dependencies': dependencies, 'files': entries,
             'helper_sha256': sha(Path(__file__))}
encoded = (json.dumps(inventory, indent=2) + '\n').encode()
(OUT / 'inventory.json').write_bytes(encoded)
metadata = {'inventory.json': encoded, 'seal.py': Path(__file__).read_bytes()}
with tarfile.open(ARCHIVE, 'w:gz') as archive:
    for name, p in paths.items():
        assert sha(p) == entries[name]['sha256'], name
        archive.add(p, arcname=name, recursive=False)
        assert sha(p) == entries[name]['sha256'], name
    for name, data in metadata.items():
        info = tarfile.TarInfo(name)
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
verified = set()
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    for member in archive:
        assert member.isfile() and member.name not in verified
        data = archive.extractfile(member).read()
        if member.name in metadata:
            assert data == metadata[member.name]
        else:
            assert member.name in entries
            assert len(data) == entries[member.name]['bytes']
            assert hashlib.sha256(data).hexdigest() == entries[member.name]['sha256']
        verified.add(member.name)
assert verified == set(entries) | set(metadata)
report = {
    'scope': inventory['scope'], 'implementation_commit': commit,
    'compatibility_complete': False, 'source_binding_passed': True,
    'distinct_committed_paths': binding['distinct_source_paths'],
    'original_files': len(entries), 'archive_files': len(verified),
    'processes': processes, 'direct_dependencies': dependencies,
    'independent_audit': identity('target/m2/closeout-stage37-independent-audit-01/report.json'),
    'independent_audit_closure': identity('target/m2/closeout-stage37-independent-audit-01/closure.json'),
    'archive': identity(str(ARCHIVE.relative_to(ROOT))),
}
text = json.dumps(report, indent=2) + '\n'
(OUT / 'report.json').write_text(text)
(ROOT / 'reports/m2/stage37-completion-captures.json').write_text(text)
print(json.dumps({'archive': report['archive'], 'original_files': len(entries),
                  'source_binding_passed': True, 'distinct_committed_paths': binding['distinct_source_paths']}), flush=True)
