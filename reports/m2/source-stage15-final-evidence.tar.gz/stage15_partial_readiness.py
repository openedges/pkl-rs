"""Read-only acquired Stage15 checks; full Java and exact commit remain pending."""
from pathlib import Path
import importlib
import json
import sys

sys.dont_write_bytecode = True
import package_stage15_final as package
import stage15_package_common as c

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
tools = {name: importlib.import_module(name) for name in
         ['m1_frontend', 'm1_lifecycle', 'm1_platforms', 'm2_class_lifecycle', 'm1_runtime']}
directories = {name: root / 'target/m2' / (('class-lifecycle' if name == 'classes' else name) + '-stage15-final')
               for name in ['language', 'validation', 'frontend', 'runtime', 'lifecycle', 'platforms', 'classes']}
data = dict(language={'source_sha256': {}},
    frontend=tools['m1_frontend'].check_report(directories['frontend']),
    lifecycle=tools['m1_lifecycle'].check_report(directories['lifecycle']),
    classes=tools['m2_class_lifecycle'].check_report(directories['classes']),
    runtime=c.load(directories['runtime'] / 'report.json'),
    platforms=c.load(directories['platforms'] / 'report.json'))
validation = c.validation_report(directories['validation'])
c.require(tools['m2_class_lifecycle'].contract_passes(data['classes']), 'persistent class contract failed')
previous = json.loads(package.old_archive('class-lifecycle', ['report.json'])['report.json'])
original_calls = 0
for current, old in zip(data['classes']['cases'], previous['cases']):
    c.require((current['id'], current['repetition']) == (old['id'], old['repetition']), 'original sequence order differs')
    c.require(current['observations']['comparisons'] == old['observations']['comparisons'], 'original comparison differs')
    for engine in ['java', 'rust']:
        c.require(current['observations']['processes'][engine]['calls'] == old['observations']['processes'][engine]['calls'],
                  'original complete class raw identity differs')
    original_calls += len(current['observations']['comparisons'])
c.require(original_calls == 406, 'original class call accounting differs')
c.DIRECTORIES['platforms'] = directories['platforms']
platforms = c.platform_claims(data['platforms'], tools['m1_platforms'])
c.require(data['platforms']['source_stability'] and tools['m1_platforms'].contract_matches(data['platforms']['comparisons']),
          'platform contract/stability differs')
for name, digest in data['platforms']['artifacts'].items():
    c.identity(directories['platforms'] / name, digest)
runtime_outcomes = []
for identity in data['runtime']['identities']:
    c.identity(Path(identity.get('snapshot', identity['path'])), identity['sha256'], identity.get('bytes'))
for row in data['runtime']['cases']:
    same = c.raw_process(row['java']) == c.raw_process(row['rust'])
    c.require(same == row['raw_equal'], 'runtime raw equality differs')
    runtime_outcomes.append(dict(id=row['id'], raw_equal=same, status=row['status']))
c.require([r['id'] for r in runtime_outcomes if not r['raw_equal']] == ['forcing-cycle'], 'runtime known mismatch differs')
copies = 0
for name, path, digest in package.source_rows(directories, data):
    c.identity(path, digest)
    c.identity(root / name, digest)
    copies += 1
result = dict(status='acquired-subset-ready', compatibility_complete=False,
    pending=['full fresh1513 Java language report', 'exact new implementation commit binding', 'final sealing'],
    validation={k:validation[k] for k in ['rust_passed','rust_intentionally_ignored','python_passed']},
    frontend_raw_matches=len(data['frontend']['results']), runtime=runtime_outcomes,
    lifecycle_protocol_matches=sum(r['observations']['protocol_raw_equal'] for r in data['lifecycle']['cases']),
    lifecycle_full_diagnostic_mismatches=sum(not e['raw_equal'] for r in data['lifecycle']['cases'] for e in r['observations']['diagnostics']),
    class_unique_sequences=len({r['id'] for r in data['classes']['cases']}), class_sequence_executions=len(data['classes']['cases']),
    class_passing_calls=sum(e['status']=='pass' for r in data['classes']['cases'] for e in r['observations']['comparisons']),
    original_class_call_raw_identities_preserved=original_calls, platforms=platforms,
    acquired_source_copies_equal_current_workspace=copies, captured_binaries_executed=False)
c.write_new(root / 'target/m2/stage15-partial-readiness.json', result)
print(json.dumps(result, sort_keys=True))
