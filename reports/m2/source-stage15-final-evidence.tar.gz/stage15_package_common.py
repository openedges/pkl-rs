"""Read-only Stage15 packaging primitives, reused from retained Stage14 helper."""
import json, hashlib, re
from pathlib import Path
ROOT = Path.cwd()
DIRECTORIES = {}
KNOWN_REGEX = {"regex-unicode-15-vs-16", "regex-zero-width-supplementary"}

def load(path):
    return json.loads(path.read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')

def identity(path, expected, size=None):
    if sha(path) != expected or (size is not None and path.stat().st_size != size):
        raise ValueError('Evidence identity differs: ' + str(path))

def source_map(directory, mapping):
    for name, digest in mapping.items():
        identity(directory / 'sources' / name, digest)
        identity(ROOT / name, digest)

def require(condition, message):
    if not condition:
        raise ValueError(message)

def exact_ids(rows, expected, label):
    actual = [row['id'] for row in rows]
    require(actual and len(actual) == len(set(actual)), label + ': empty or duplicate IDs')
    require(actual == expected, label + ': missing, unexpected, or reordered IDs')

def platform_claims(platforms, platform_tool):
    directory = DIRECTORIES['platforms']
    execution = load(directory / 'execution/execution.json')
    node = load(directory / 'execution/node-checks.json')
    browser = load(directory / 'execution/browser-checks.json')
    require(platforms['execution'] == execution, 'Platform execution differs from retained execution.json')
    require(execution['nodeChecks'] == node, 'Node checks differ from retained scenario list')
    require(execution['browserChecks'] == browser, 'Browser checks differ from retained scenario list')
    platform_tool.check_scenarios(execution)
    captures = {name: (directory / relative).read_bytes() for name, relative in [
        ('java', 'oracle-native/java.stdout.bin'), ('rust', 'oracle-native/rust.stdout.bin'),
        ('node', 'execution/node.stdout.bin'), ('browser', 'execution/browser.stdout.bin')]}
    rows = platform_tool.compare(platform_tool.generate_cases()['cases'], captures)
    require(rows == platforms['comparisons'], 'Platform comparisons disagree with raw captures')
    counts = dict(total=len(rows), shared_engine_passed=sum(row['shared_engine_match'] for row in rows),
                  oracle_passed={target: sum(row['oracle_matches'][target] for row in rows)
                                 for target in ['rust', 'node', 'browser']})
    for key, value in counts.items():
        require(platforms[key] == value, 'Platform exported raw count differs: ' + key)
    require(execution['total'] == counts['total'], 'Platform execution denominator differs')
    require(set(platforms['known_gaps']) == KNOWN_REGEX, 'Platform known regex gaps changed')
    return dict(counts, node_scenarios=len(node), browser_scenarios=len(browser),
                report_execution_equals_retained=True, scenario_lists_equal_retained=True,
                comparisons_recomputed_from_raw=True,
                oracle_mismatch_ids={target: [row['id'] for row in rows if not row['oracle_matches'][target]]
                                     for target in ['rust', 'node', 'browser']})

def raw_process(process):
    if process['status'] != 'executed':
        raise ValueError('Process was not executed: ' + repr(process['command']))
    values = []
    for name in ['stdout', 'stderr']:
        row = process[name]
        path = Path(row['path'])
        identity(path, row['sha256'], row['bytes'])
        values.append(path.read_bytes())
    return process['exit_code'], *values

def validation_report(directory):
    report = load(directory / 'report.json')
    required = [
        ['cargo', 'xtask', 'verify'], ['cargo', 'fmt', '--all', '--', '--check'],
        ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings'],
        ['cargo', 'test', '--workspace', '--locked'],
        ['cargo', 'check', '-p', 'pkl-runtime', '--target', 'wasm32-unknown-unknown', '--locked'],
    ]
    if [r['command'] for r in report['checks'][:5]] != required:
        raise ValueError('Required Rust verification command inventory differs')
    rust_output = python_output = None
    for index, row in enumerate(report['checks']):
        if row['exit_code'] != 0:
            raise ValueError('Required verification failed: ' + repr(row['command']))
        captures = {}
        for channel in ['stdout', 'stderr']:
            path = directory / f'{index}.{channel}.bin'
            identity(path, row[channel + '_sha256'])
            captures[channel] = path.read_bytes().decode()
        if row['command'] == required[3]:
            rust_output = captures['stdout'] + captures['stderr']
        if row['command'][1:] == ['-m', 'unittest', 'discover', '-s', 'tools/tests', '-v']:
            python_output = captures['stdout'] + captures['stderr']
    if len(report['checks']) != 7 or report['checks'][6]['command'][1:] != ['tools/m2_manifest.py', '--check']:
        raise ValueError('Python/inventory verification command inventory differs')
    rust_rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', rust_output or '')
    python_rows = re.findall(r'Ran (\d+) tests? in ', python_output or '')
    if not rust_rows or len(python_rows) != 1 or not re.search(r'\nOK\s*$', python_output or ''):
        raise ValueError('Missing successful raw Rust/Python test summaries')
    counts = dict(rust_passed=sum(int(row[0]) for row in rust_rows),
                  rust_intentionally_ignored=sum(int(row[2]) for row in rust_rows),
                  python_passed=int(python_rows[0]))
    if any(int(row[1]) for row in rust_rows) or not counts['rust_passed'] or not counts['python_passed']:
        raise ValueError('Failed or empty verification summaries')
    return dict(report, **counts, evidence_sha256={str(p.relative_to(directory)): sha(p)
                for p in sorted(directory.rglob('*')) if p.is_file()})
