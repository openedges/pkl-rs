# Stage49 admission 테스트 phase migration

할당된 생산 트리 변경은 crates/pkl-runtime/tests/m2_module_admission.rs 하나다. 15개 테스트를 삭제하거나 ignore하지 않았다. Cargo 집중 실행은 A의 공유 target 사용 허가 뒤 한 번 수행했고 실제 15/15 성공, 측정한 명시 입력 before=after다. 이후 A가 public lifecycle을 계속 수정하므로 이 결과는 최종 freeze/전체 호환성 판정이 아니다.

## 변경 이유와 원문 계약

- Java ImportNode:50–63은 성공 site hit를 먼저 반환하고, miss에서 edge check→새 ModuleResolver 선택을 수행한다.
- Java ModuleCache:82–164는 실제 singleton에서 cache-policy/resolve를 생략한다. 일반 key는 isCached를 조회한 뒤 URI hit 또는 Resolve/LoadSource로 진행한다.
- Java AstBuilder:1648–1654는 clause를 unused/명시alias여도 선택한다. implicit alias만 IoUtils:299–314의 fragment-path getter를 사용한다. ModuleCache:178–185/Java AstBuilder:329–339의 loaded source module-name 추론은 실제 source 성공 뒤 일어난다.
- 따라서 json의 최초 runtime 요청 2개 기대를 Check→SelectRuntime→CachePolicy→Resolve의 exact4개로, 별도 site URI hit는 exact3개로, singleton은 exact2개로 바꿨다. clause Select와 implicit name getter는 edge와 별도로 검증한다.
- cycle의 단일 old11개 scalar를 실제 call별 exact sequence29개로 교체했다. source2회와 각 class 값/오류 원래 기대는 유지했다. 두 module source의 name getter, 명시alias clause selection, partial cache hit 및 실패 site retry가 각각 구분된다.
- pending lifecycle은 Check/SelectRuntime/CachePolicy/Resolve/LoadSource/FragmentPaths 여섯 phase를 정확히 확인한 뒤 close 또는 cancel한다. SourceProbe terminal cancellation과 Vm nonterminal cancellation의 원래 차이를 유지한다.

## 보존·강화한 조건

| 범위 | 유지한 검증 |
| --- | --- |
| 값·오류 | 기존 true/null/7, partial class a#Good, 실패 root 원본 UTF16 동등성, raw Denied bypass, typed security catch/retry |
| 토큰 | 원래 wrong phase/bundled identity/stale token 거부 + 새 SelectKey wrong ID/wrong CachePolicy phase/CachePolicy wrong ID token 미소비 |
| GC | 12개 temporary importer 실제 stale, imported child 접근 성공, 원래 live/executable plateau exact equality, 모든 close slots=0 |
| 한도 | next/settle poll100000, instruction budget1, 원래 deadline1ms/만료시각2ms; 상향 없음 |
| 재진입 | held admission token 보존, inner stable=7, 복구 뒤 새 phase 순서 처리 |
| 취소 | public terminal 재시작 금지, Vm nonterminal stable=7 복구 및 새 request ID·CheckImport 재시도 |

GC 개수·객체 bound의 변경은 없다. 새 양수 inequality, 오류 정규화, 실패 건너뛰기, 관찰 mode 대체를 넣지 않았다. 요청 count 변경은 새 명시 phase가 추가된 결과이며 원래 source·값·오류 기대는 유지한다.

## 기록·한계

입력 map은 명시 tracked runtime/src와 Cargo 제어 입력, 할당 테스트 및 support/module_keys.rs다. 전체 candidate/source snapshot이나 실제 Java 동등성 증거로 확대하지 않는다. Java 기대 파일과 fixture는 수정하지 않았다. 새 생산 런타임 편집 및 다른 Rust 테스트는 A 소유다.

단일 파일 rustfmt가 #[path] support child까지 format하는 실수가 있었다. 직전 읽은 exact support 원본과 formatter 결과가 같은 내용임을 확인하고 원본 bytes로 복구했다. 의도치 않은 before/after를 target에 보존했고 support 의미·최종 bytes 변경은 없다. 이후 formatter가 필요하면 child traversal을 피하는 경로를 사용한다.
