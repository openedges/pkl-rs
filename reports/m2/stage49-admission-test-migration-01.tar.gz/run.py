from pathlib import Path
import subprocess,json,hashlib,time,os
root=Path('/Users/cody.ij.hwang/Projects/pkl-rs');out=Path(__file__).parent
cmd=['cargo','test','-p','pkl-runtime','--test','m2_module_admission','--locked','--','--nocapture'];start=time.time()
(out/'launch.json').write_text(json.dumps({'argv':cmd,'cwd':str(root),'wrapperPid':os.getpid(),'cargoTargetDirEnvironment':os.environ.get('CARGO_TARGET_DIR'),'startedUnix':start},indent=2)+'\n')
with(out/'stdout.bin').open('wb')as stdout,(out/'stderr.bin').open('wb')as stderr:r=subprocess.run(cmd,cwd=root,stdout=stdout,stderr=stderr)
before=json.loads((out/'inputs-before.json').read_text());after={'files':{f:{'length':len(b),'sha256':hashlib.sha256(b).hexdigest()} for f in before['files'] for b in [(root/f).read_bytes()]}}
(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
changed=[f for f in before['files'] if before['files'][f]!=after['files'][f]]
(out/'report.json').write_text(json.dumps({'scope':'Focused Rust admission architecture regression against work-in-progress inputs; raw failed outcomes preserved. No Java or platform compatibility claim.','argv':cmd,'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'sourceChanges':changed,'stdoutSha256':hashlib.sha256((out/'stdout.bin').read_bytes()).hexdigest(),'stderrSha256':hashlib.sha256((out/'stderr.bin').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'exitCode':r.returncode,'sourceChanges':changed,'output':str(out)}));raise SystemExit(r.returncode)
