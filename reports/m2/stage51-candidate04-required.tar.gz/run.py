"""Record the required workspace checks against the frozen Stage51 candidate."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BUILD = ROOT / "target/m2/stage51-candidate04-build"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")

assert not (OUT / "report.json").exists()
build = json.loads((BUILD / "report.json").read_bytes())
proof = json.loads((BUILD / "build-proof.json").read_bytes())
assert build["complete"] and build["sourceStable"]
assert sha(BUILD / "build-proof.json") == build["buildProofSha256"]
sources = dict(proof["sources"])
for name in ["tests/fixtures/m2-collection-transforms/manifest.json",
             "compatibility/m2-language.json"]:
    sources[name] = sha(ROOT / name)
assert all(sha(ROOT / path) == digest for path, digest in sources.items())
for path, digest in sources.items():
    destination = OUT / "sources" / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / path, destination)
    assert sha(destination) == digest
save("sources-before.json", sources)
report = {"schema": 1, "scope": "Actual local required Rust workspace checks; not a whole-language, product, or performance compatibility result.",
          "cwd": str(ROOT), "host": platform.platform(), "startedUtc": now(),
          "runnerSha256": sha(Path(__file__)), "buildProofSha256": sha(BUILD / "build-proof.json"),
          "environment": {k: os.environ.get(k) for k in ["RUSTUP_TOOLCHAIN", "CARGO_TARGET_DIR", "JAVA_HOME", "PKL_ORACLE_JAVA"]},
          "commands": [], "complete": False}
save("report.json", report)
commands = [
    ("rust-version", ["rustc", "-Vv"]),
    ("verify", ["cargo", "xtask", "verify"]),
    ("fmt", ["cargo", "fmt", "--all", "--", "--check"]),
    ("clippy", ["cargo", "clippy", "--workspace", "--all-targets", "--locked", "--", "-D", "warnings"]),
    ("test", ["cargo", "test", "--workspace", "--locked"]),
    ("wasm-check", ["cargo", "check", "-p", "pkl-runtime", "--target", "wasm32-unknown-unknown", "--locked"]),
]
try:
    for name, argv in commands:
        row = {"name": name, "argv": argv, "startedUtc": now()}
        with (OUT / (name + ".stdout.bin")).open("wb") as stdout, (OUT / (name + ".stderr.bin")).open("wb") as stderr:
            child = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
            row["pid"] = child.pid
            save("active.json", row)
            print("START", name, child.pid, flush=True)
            row["exitCode"] = child.wait()
        row.update(finishedUtc=now(), stdoutSha256=sha(OUT / (name + ".stdout.bin")), stderrSha256=sha(OUT / (name + ".stderr.bin")))
        report["commands"].append(row)
        save("report.json", report)
        print("DONE", name, row["exitCode"], flush=True)
    after = {path: sha(ROOT / path) for path in sources}
    save("sources-after.json", after)
    report["sourceStable"] = sources == after
    report["complete"] = True
    report["passed"] = report["sourceStable"] and all(row["exitCode"] == 0 for row in report["commands"])
except Exception as error:
    report["error"] = repr(error)
    report["passed"] = False
finally:
    report["finishedUtc"] = now()
    save("report.json", report)
    save("active.json", {"complete": report["complete"], "passed": report["passed"]})
    print(json.dumps(report), flush=True)
raise SystemExit(0 if report["passed"] else 1)
