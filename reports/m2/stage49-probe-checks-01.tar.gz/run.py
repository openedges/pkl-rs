from pathlib import Path
import hashlib,json,subprocess,time
root=Path.cwd();out=root/'target/m2/stage49-probe-checks-01'
previous=json.loads((root/'target/m2/stage49-modulekey-build03/sources-before.json').read_text())
def snap(): return {name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in previous}
def save(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
before=snap();save('sources-before.json',before)
delta=[name for name in previous if before[name]!=previous[name]]
assert delta==['crates/pkl-runtime/examples/stage49_modulekey_probe/module_keys.rs'],delta
save('delta-from-build03.json',delta)
rows=[]
for i,command in enumerate([['cargo','fmt','--all','--','--check'],['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']]):
    start=time.time()
    with (out/f'check-{i}.stdout').open('wb') as stdout,(out/f'check-{i}.stderr').open('wb') as stderr:
        p=subprocess.Popen(command,stdout=stdout,stderr=stderr);save('running.json',{'pid':p.pid,'command':command});code=p.wait()
    rows.append({'command':command,'pid':p.pid,'exitCode':code,'elapsedSeconds':time.time()-start});print(rows[-1],flush=True)
after=snap();save('sources-after.json',after)
report={'checks':rows,'sourceStable':before==after,'deltaFromBuild03':delta,'defaultFiveCoreEvidence':'target/m2/stage49-required-rust-01/report.json','status':'PASS' if before==after and all(r['exitCode']==0 for r in rows) else 'FAIL'}
save('report.json',report);print(json.dumps(report,indent=2));raise SystemExit(0 if report['status']=='PASS' else 1)
