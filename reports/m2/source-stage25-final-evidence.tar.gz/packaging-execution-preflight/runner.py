"""Run an immutable per-attempt copy of the Stage25 final packager."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,subprocess,sys,threading,time
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True,type=Path);parser.add_argument('arguments',nargs=argparse.REMAINDER);args=parser.parse_args()
arguments=args.arguments
if arguments and arguments[0]=='--':arguments=arguments[1:]
root=Path.cwd();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);(out/'runner.py').write_bytes(Path(__file__).read_bytes());helper=out/'helper/package_stage25_final.py';helper.parent.mkdir();shutil.copy2(root/'target/m2/package_stage25_final.py',helper);helper.chmod(0o444)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
helper_hash=sha(helper);command=[sys.executable,str(helper),*arguments]
(out/'invocation.json').write_text(json.dumps(dict(command=command,cwd=str(root),python=sys.executable,python_sha256=sha(Path(sys.executable)),helper=dict(path=str(helper.relative_to(root)),sha256=helper_hash,bytes=helper.stat().st_size),scope='Pre-execution immutable helper identity; final process outcome is retained separately after completion.'),indent=2)+'\n')
started=time.monotonic_ns();process=subprocess.Popen(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def pump(source,path,visible):
 with path.open('xb') as stream:
  while raw:=source.read1(65536):stream.write(raw);stream.flush();visible.write(raw);visible.flush()
threads=[threading.Thread(target=pump,args=(process.stdout,out/'stdout.bin',sys.stdout.buffer)),threading.Thread(target=pump,args=(process.stderr,out/'stderr.bin',sys.stderr.buffer))]
for thread in threads:thread.start()
code=process.wait()
for thread in threads:thread.join()
record=dict(command=command,cwd=str(root),exit_code=code,timed_out=False,elapsed_ns=time.monotonic_ns()-started,python=sys.executable,python_sha256=sha(Path(sys.executable)),helper=dict(path=str(helper.relative_to(root)),sha256_before=helper_hash,sha256_after=sha(helper),stable=helper_hash==sha(helper),bytes=helper.stat().st_size,execution='Immutable per-attempt source copy; actual helper bytes are retained here and copied into the final source archive when sealing.'))
for channel in ['stdout','stderr']:
 raw=(out/(channel+'.bin')).read_bytes();record[channel+'_sha256']=hashlib.sha256(raw).hexdigest();record[channel+'_bytes']=len(raw)
(out/'process.json').write_text(json.dumps(record,indent=2)+'\n');sys.exit(code if record['helper']['stable'] else 1)
