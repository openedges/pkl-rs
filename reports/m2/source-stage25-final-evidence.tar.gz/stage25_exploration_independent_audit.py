"""Independently inspect sealed exploration bytes; never execute retained artifacts."""
from pathlib import Path
import datetime,fnmatch,hashlib,json,os,platform,sys,tarfile
ROOT=Path.cwd()
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
def ident(path):return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest(path)}
def require(condition,description):
 if not condition:raise AssertionError(description)
index_path=ROOT/'target/m2/stage25-exploration-index.json';config_path=ROOT/'target/m2/stage25-exploration-configuration.json'
index=json.loads(index_path.read_bytes());config=json.loads(config_path.read_bytes())
require(index['scope']==config['scope'] and index['counts']==config['counts'],'index/config scope/count disagreement')
require(index['history_dependencies']==config['history_dependencies'],'history configuration disagreement')
require(index['captured_artifacts_executed'] is False,'index artifact execution claim')
archives=[index['main'],*index['additional_archives']];require(len(archives)==len(config['groups']) and archives,'exploration archive/configuration closure')
omissions=config.get('omitted_build_caches',[])
require(index.get('omitted_build_caches',[])==omissions,'index/config Cargo omission disagreement')
require(index.get('separately_packaged_core_roots',[])==config.get('separately_packaged_core_roots',[]),'index/config separate core disagreement')
omitted_paths=[row['path'] for row in omissions]
require(len(omitted_paths)==len(set(omitted_paths)),'duplicate Cargo omission root')
for row in omissions:
 name=row['path'];path=Path(name)
 require(set(row)=={'path','reason','payload_enumerated'} and row['payload_enumerated'] is False and bool(row['reason']),'Cargo omission must explicitly disclaim payload enumeration')
 require(not path.is_absolute() and '..' not in path.parts and path.name=='build' and path.parent.as_posix() in config['selected_original_roots'],'Cargo omission must be a direct build child of a selected original root')
 require((ROOT/path).is_dir() and not (ROOT/path).is_symlink(),'missing/linked omitted Cargo directory')
separate_cores=config.get('separately_packaged_core_roots',[])
require(len({row['root'] for row in separate_cores})==len(separate_cores),'duplicate separate core root')
for row in separate_cores:
 root=Path(row['root'])
 require(not root.is_absolute() and '..' not in root.parts and row['root'] not in config['selected_original_roots'],'unsafe or duplicated separately packaged core')
 require(row['report']['path']==(root/'report.json').as_posix(),'separate core report path differs')
 require(ident(ROOT/row['report']['path'])==row['report'],'separate core report identity differs')
def original_root_closure():
 roots=config['selected_original_roots'];require(roots and len(roots)==len(set(roots)),'missing/duplicate original root closure')
 files=set();seen_omitted=set()
 for name in roots:
  require(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe original root '+name)
  path=ROOT/name;require(path.exists() and not path.is_symlink(),'missing/linked original root '+name)
  if path.is_file():
   files.add(path.relative_to(ROOT).as_posix());continue
  for folder,dirs,names in os.walk(path):
   parent=Path(folder)
   for name in list(dirs):
    child=parent/name;relative=child.relative_to(ROOT).as_posix()
    require(not child.is_symlink() and child.resolve().is_relative_to(ROOT),'linked/outside original directory')
    if relative in omitted_paths:
     dirs.remove(name);seen_omitted.add(relative)
   for name in names:
    child=parent/name
    require(child.is_file() and not child.is_symlink() and child.resolve().is_relative_to(ROOT),'linked/outside original root child')
    files.add(child.relative_to(ROOT).as_posix())
 require(seen_omitted==set(omitted_paths),'explicit Cargo cache omission closure differs')
 return files
configured_paths=[name for group in config['groups'] for name in group['paths']]
require(len(configured_paths)==len(set(configured_paths)),'overlapping partition paths')
require(all(not group['excludes'] for group in config['groups']),'Stage25 retained-byte partitions must not exclude files; any separately pruned Cargo caches require explicit configuration accounting')
require(all((ROOT/name).is_file() for name in configured_paths),'partitions must enumerate files')
original_closure_before=original_root_closure()
require(set(configured_paths)==original_closure_before,'partition inventory does not cover complete original roots')
results=[];all_originals=set()
for expected,group in zip(archives,config['groups']):
 path=ROOT/expected['path'];require(ident(path)=={k:expected[k] for k in ['path','bytes','sha256']},'archive identity mismatch '+str(path))
 require(group['archive']==expected['path'],'archive group mismatch')
 with tarfile.open(path,'r:gz') as archive:
  members=archive.getmembers();names=[x.name for x in members];member_by_name={x.name:x for x in members}
  require(len(names)==len(set(names)) and 'EVIDENCE.json' in names,'duplicate/missing archive inventory')
  require(all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts for x in members),'unsafe archive path/type')
  require(all(x.mode==0o644 and x.mtime==0 for x in members),'unexpected deterministic header')
  inventory=json.load(archive.extractfile('EVIDENCE.json'));rows=inventory['files'];mapping={x['path']:x for x in rows}
  require(len(mapping)==len(rows) and set(mapping)==set(names)-{'EVIDENCE.json'},'incomplete evidence inventory')
  require(inventory['schema_version']==1 and inventory['excluded_patterns']==group['excludes'],'inventory exclusion configuration')
  payload_bytes=0
  for row in rows:
   data=archive.extractfile(member_by_name[row['path']]).read();payload_bytes+=len(data)
   require(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],'evidence payload mismatch '+row['path'])
  original=json.load(archive.extractfile('ORIGINAL_PATHS.json'));original_rows=original['files'];original_mapping={x['path']:x for x in original_rows}
  require(original['schema']==1 and len(original_mapping)==len(original_rows),'original mapping schema/duplicates')
  require(set(mapping)==set(original_mapping)|{'ORIGINAL_PATHS.json','PACKAGE.json','configuration.json','sealer.py'},'unmapped payload files')
  require(len(original_rows)==expected['original_files'],'index original count')
  for name,row in original_mapping.items():
   require(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe original path')
   require(row==mapping[name],'original and archive inventory disagree '+name)
   require(ident(ROOT/name)==row,'original filesystem bytes changed '+name)
   require(name not in all_originals,'duplicate path across archives '+name);all_originals.add(name)
  captured_config=json.load(archive.extractfile('configuration.json'));require(captured_config==config,'captured configuration mismatch')
  require(archive.extractfile('sealer.py').read()==(ROOT/'target/m2/stage25_seal_exploration.py').read_bytes(),'captured sealer mismatch')
  package=json.load(archive.extractfile('PACKAGE.json'))
  require(package['original_paths_preserved'] is True and package['captured_artifacts_executed'] is False,'package provenance flags')
  require(package['history_dependencies']==index['history_dependencies'] and package['counts']==index['counts'],'package history/count mismatch')
  require(package.get('omitted_build_caches',[])==omissions and package.get('separately_packaged_core_roots',[])==separate_cores,'package cache omission/separate core disagreement')
  require(package['excluded_patterns']==group['excludes'] and package['scope']==expected['scope'],'package scope/exclusions mismatch')
  candidates=set()
  for name in group['paths']:
   source=ROOT/name;require(source.exists() and not source.is_symlink(),'missing/linked configured source '+name)
   candidates.update([source] if source.is_file() else [p for p in source.rglob('*') if p.is_file()])
  candidate_paths={p.relative_to(ROOT).as_posix() for p in candidates}
  require(all(not p.is_symlink() and p.resolve().is_relative_to(ROOT) for p in candidates),'linked/outside configured child')
  excluded={name for name in candidate_paths if any(fnmatch.fnmatchcase(name,pattern) for pattern in group['excludes'])}
  excluded_rows=original['excluded_cache_files'];excluded_mapping={x['path']:x for x in excluded_rows}
  require(set(excluded_mapping)==excluded and len(excluded_mapping)==len(excluded_rows)==expected['excluded_cache_files'],'explicit excluded cache inventory mismatch')
  require(set(original_mapping)==candidate_paths-excluded,'retained configured path inventory mismatch')
  for name,row in excluded_mapping.items():require((ROOT/name).stat().st_size==row['bytes'],'excluded cache size changed '+name)
  results.append(dict(**ident(path),inventory_files=len(rows),inventory_payload_bytes=payload_bytes,original_paths=len(original_rows),original_bytes=sum(x['bytes'] for x in original_rows),excluded_cache_files=len(excluded_rows),excluded_cache_bytes=sum(x['bytes'] for x in excluded_rows),excluded_patterns=group['excludes'],original_mapping='ORIGINAL_PATHS.json',deterministic_headers_verified=True,status='pass'))
require(all_originals==original_closure_before==original_root_closure(),'sealed partitions or current original root closure differ')
for row in separate_cores:require(ident(ROOT/row['report']['path'])==row['report'],'separate core report changed during independent audit')
history=[]
for expected in index['history_dependencies']:
 actual=ident(ROOT/expected['path']);require(actual==expected,'history dependency mismatch '+expected['path']);history.append(actual)
helper=Path(__file__).resolve()
report=dict(status='pass',scope='Independent read-only audit of sealed Stage25 exploration archive bytes, evidence/original inventories, retained original-root closure, explicitly catalogued cache omissions, helper/config provenance and historical dependency identities. Reviewer authored resolver continuations, native frontend tests and platform wiring, but did not author the exploration configuration/sealer or Java captures. This is an independent archive/provenance audit, not an independent semantic review of authored inputs.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host=platform.platform(),python=sys.version,captured_artifacts_executed=False,retained_helpers_executed=False,archive_count=len(results),omitted_build_caches=omissions,omitted_build_cache_roots=len(omissions),separately_packaged_core_roots=separate_cores,selected_original_roots=len(set(config['selected_original_roots'])),root_closure_files=len(original_closure_before),root_closure_verified_before_and_after=True,inventory_files=sum(x['inventory_files'] for x in results),original_paths=len(all_originals),excluded_cache_files=sum(x['excluded_cache_files'] for x in results),archives=results,history_dependencies=history,helper_provenance=dict(audit_helper=ident(helper),reviewed_sealer=ident(ROOT/'target/m2/stage25_seal_exploration.py'),reviewed_inventory_implementation=ident(ROOT/'tools/evidence.py'),index=ident(index_path),configuration=ident(config_path)),limitations=['This validates archive bytes and provenance; it does not execute retained binaries or independently establish the semantic correctness of captured Java/Rust outcomes.','Historical dependencies were checked by exact archive/summary hashes and sizes; their internal inventories were not recursively re-audited in this check.','Tar headers use normalized0644 modes; ORIGINAL_PATHS maps bytes, size, and paths and does not claim restoration of original executable modes.','Explicit per-root Cargo build caches were not traversed or enumerated. Their payload file counts, sizes and hashes are intentionally unclaimed; omitted_build_cache_roots counts directories, while excluded_cache_files counts separately enumerated group exclusions only.','Authoritative core suites are not duplicated into exploration; their current report identities are checked and their full payloads remain separate final-packager obligations.'])
output=ROOT/'target/m2/stage25-exploration-independent-audit.json';require(not output.exists(),'audit output already exists');output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','archive_count','inventory_files','original_paths','excluded_cache_files','captured_artifacts_executed']},indent=2))
