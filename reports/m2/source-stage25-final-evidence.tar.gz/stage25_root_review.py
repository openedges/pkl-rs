"""Record root's bounded Stage25 source review and independent preservation checks."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path.cwd()
BASELINE = 'a22051329ef90fb76f8428852ee2cc2c14360ea3'
sha = lambda data: hashlib.sha256(data).hexdigest()
def prior(path):
    return subprocess.check_output(['git', 'show', BASELINE + ':' + path], cwd=ROOT)

sources = [
    'crates/pkl-runtime/src/parser.rs',
    'crates/pkl-runtime/src/resolver.rs',
    'crates/pkl-runtime/src/resolver/constant_keys.rs',
    'crates/pkl-runtime/src/syntax.rs',
    'crates/pkl-runtime/src/vm.rs',
    'crates/pkl-runtime/src/vm/compiler_expressions.rs',
    'crates/pkl-runtime/src/power_assertions.rs',
    'crates/pkl-runtime/tests/m2_frontend_lifecycle.rs',
    'tools/m1_platforms.py', 'tools/platform/run.mjs',
    'tools/platform/scenarios.mjs', 'tools/platform/frontend-depth-cases.mjs',
    'tools/tests/test_m1_platforms.py',
]
old_tests = subprocess.check_output([
    'git', 'ls-tree', '-r', '--name-only', BASELINE,
    'crates/pkl-runtime/tests'], text=True, cwd=ROOT).splitlines()
lifecycle = [path for path in old_tests if 'lifecycle' in path]
assert all((ROOT / path).read_bytes() == prior(path) for path in lifecycle)
old = json.loads(prior('tests/fixtures/m2/cases.json'))['cases']
new = json.loads((ROOT / 'tests/fixtures/m2/cases.json').read_bytes())['cases']
assert new[:len(old)] == old and len(new) - len(old) == 36
assert all((ROOT / row['input']).read_bytes() == prior(row['input']) for row in old)
native = json.loads((ROOT / 'target/m2/native-frontend-stage25-final-02/report.json').read_bytes())
assert native['source_stability']
assert native['source_sha256_before'] == native['source_sha256_after']
assert all(sha((ROOT / path).read_bytes()) == digest
           for path, digest in native['source_sha256_before'].items())
report = {
    'status': 'pass',
    'scope': 'Independent review of other agents\' bounded frontend implementation, resolver, native lifecycle tests and platform wiring; preservation checks. Not complete language compatibility, arbitrary grammar depth, or performance certification.',
    'source_sha256': {path: sha((ROOT / path).read_bytes()) for path in sources},
    'independence_exclusions': [
        'Root authored parser/type_parser.rs and the parser.rs type_expression wrapper/module declaration. Independent type-parser review is supplied by frontend and lifecycle reviewers; the parser.rs hash binds the complete file without claiming independent review of those authored lines.',
        'Root authored the existing test borrow/limit expectation migrations, documentation and resolver inventory link migration. Evidence reviewer separately inspected those changes.',
    ],
    'observations': [
        'Heap Pratt frames preserve precedence, right-associative power/coalescing, left-to-right arguments, delimiter expectations and source spans. ObjectBuild distinguishes expression postfixes from property/generator grammar and sequential entry amendments.',
        'Resolver Work variants preserve member validation before annotations/body, function duplicate checks before annotations, class superclass resolution before its const barrier, let initializer before lexical scope, eager receiver/const scope restoration, and body-first generator traversal. The independently found Uninitialized leaf omission is now restored explicitly.',
        'Compiler child work is emitted in source order; lazy branches are patched after their selected bodies. Function/property code swaps retain pending spans and owner context. Deferred errors inherit the active expression only when no explicit span exists. Fallback type/class/mixed-body recursion remains outside the small-stack success claim.',
        'Expr clone and destruction traverse ordinary/control/member expression edges iteratively; amendment parents are detached. Generator member cloning and owned Type edges retain bounded recursive structure. Derived Debug and PartialEq are not certified for deep trees.',
        'Constant List keys preserve arity and child order in a flat prefix representation; iterative rendering retains the existing UTF-16 truncation behavior. Power assertion anchor order/root propagation is preserved.',
        'Five native tests invoke process-isolated child tests on unchanged 262144-byte stacks with 60-second parent deadlines. They exercise accepted depth768 ordinary paths, width1024, accepted scope24/31, partial-tree cleanup, guard rejection, and real Host read failure/retry, reentry, cancellation and terminal release with collection at every yield/pending read.',
        'Type24/31 tests cover parse, Module clone and drop only. The removed nested lexical-string depth64 check remains a recorded SIGABRT, not a passing guard check. Unexecuted deeper full type-compiler and accepted nested lexical drafts remain distinct.',
        'Platform wiring compares complete Java-derived sequence payloads twice in both Node and actual Chromium. These scenarios do not substitute for native stack or real Host/GC assertions.',
    ],
    'preservation': {
        'baseline_commit': BASELINE,
        'historical_lifecycle_test_files_byte_identical': len(lifecycle),
        'original_selected_cases': len(old), 'current_selected_cases': len(new),
        'original_selected_inputs_byte_identical': True,
        'old_non_lifecycle_test_changes': 'Nine mechanical borrows in two files, plus intentional replacement of two obsolete ordinary-depth rejection expectations with value/span/member-chain success assertions on the original inputs. Original drafts and the subsequent tuple-pattern correction are preserved separately; no claim that all old test files are unchanged.',
    },
    'known_open_scope': [
        'Nested lexical string depth64 still aborts on the same 256 KiB stack; original raw capture is retained.',
        'Near-limit full type compilation, class/instance and mixed/generator compilation, generator/Type AST recursion, Debug/PartialEq, arbitrary authored depth and exact Java resource errors remain separate obligations.',
        'Existing first-error differences, all-language APIs and workload latency/peak-RSS requirements remain open; no new development exception or Java fallback was introduced.',
    ],
    'blocking_findings_in_reviewed_selected_paths': [],
    'verification_boundary': 'Source review and explicit preservation checks only. The full raw Java, platform and workspace outcomes are independently reported by their final suite captures.',
}
out = ROOT / 'target/m2/stage25-root-review-final-01.json'
with out.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({'status': report['status'], 'reviewed_sources': len(sources),
                  'historical_lifecycle_files': len(lifecycle)}))
