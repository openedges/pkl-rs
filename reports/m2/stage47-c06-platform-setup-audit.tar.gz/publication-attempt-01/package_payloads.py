"""Gather exact payloads, create/verify archives, independently read all bytes."""
from pathlib import Path
import collections
import hashlib
import json
import os
import stat
import subprocess
import sys
import tarfile

OUT=Path(__file__).resolve().parent
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
STAGE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
WORK=STAGE/'target/m2/stage47-c06-platform-workspace-01'
RUN=WORK/'target/m2/stage47-platform-acquisition-01'
TOOL=MAIN/'tools/evidence.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
def obj(p):return json.loads(p.read_bytes())
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
selected=obj(OUT/'selection.json');rows=selected['rows']
assert not (OUT/'groups').exists() and not (OUT/'archives').exists()
def original(row):
    p=Path(row['originalPath']);s=p.lstat()
    if row['kind']=='symlink':assert stat.S_ISLNK(s.st_mode);data=os.fsencode(os.readlink(p))
    else:assert stat.S_ISREG(s.st_mode);data=p.read_bytes()
    assert stat.S_IMODE(s.st_mode)==row['mode'] and len(data)==row['bytes'] and sha(data)==row['sha256'],p
    return data
roots=[RUN,MAIN/'target/m2/stage47-c06-platform-preparation-01',MAIN/'target/m2/stage47-c06-platform-audit-01']
coverage=[]
prunes=set(obj(OUT/'traversal-policy.json')['exactPrewalkExclusions'])
for root in roots:
    expected={str(Path(row['originalPath']).relative_to(root)) for row in rows if row['kind']=='regular' and Path(row['originalPath']).is_relative_to(root)}
    allowed={'.'}
    for name in expected:allowed.update(str(p) for p in Path(name).parents)
    pending=[root];actual=set()
    while pending:
        directory=pending.pop()
        assert str(directory) not in prunes
        with os.scandir(directory) as entries:
            for entry in entries:
                path=Path(entry.path);relative=path.relative_to(root).as_posix()
                if str(path) in prunes:continue
                mode=entry.stat(follow_symlinks=False).st_mode
                if stat.S_ISDIR(mode):
                    assert relative in allowed,('unexpected directory before descent',path)
                    pending.append(path)
                else:
                    assert stat.S_ISREG(mode),path
                    actual.add(relative)
    assert actual==expected,(root,actual-expected,expected-actual)
    coverage.append({'root':str(root),'selectedFiles':len(expected),'pathSetEqual':True,'unknownDirectoryTraversal':False})
save('producer-path-coverage.json',coverage)
save('original-before.json',rows)
bygroup=collections.defaultdict(list)
for row in rows:
    bygroup[row['group']].append(row)
    target=OUT/'groups'/row['group']/row['path'];target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(original(row))
    # The archive has deterministic0644 headers. Original kind/mode is in the
    # explicit source map; no executable or symlink identity is silently lost.
    target.chmod(0o644)
for group,items in bygroup.items():
    metadata={'schema':1,'group':group,'rows':items,'originalModeAndKindPreservedInMapping':True,
      'scope':'C06 actual platform capture only; excludes full-selected regression and full M2. Symlinks are literal-target payloads, never followed.'}
    (OUT/'groups'/group/'PUBLICATION-SOURCE.json').write_text(json.dumps(metadata,indent=2)+'\n')
commands=[]
def execute(label,argv):
    directory=OUT/'commands';directory.mkdir(exist_ok=True)
    p=subprocess.run([str(x) for x in argv],stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                     env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    (directory/(label+'.stdout.bin')).write_bytes(p.stdout);(directory/(label+'.stderr.bin')).write_bytes(p.stderr)
    row={'label':label,'argv':[str(x)for x in argv],'exitCode':p.returncode,'stdoutSha256':sha(p.stdout),'stderrSha256':sha(p.stderr)}
    commands.append(row);save('commands.json',commands)
    assert p.returncode==0,row
    print(label+': exit0',flush=True)
def inspect(archive,source,source_rows):
    expected={row['path']:row for row in source_rows}
    expected['PUBLICATION-SOURCE.json']=None
    count=0;rawbytes=0
    with tarfile.open(archive,'r:gz') as tar:
        members=tar.getmembers();names=[m.name for m in members]
        assert len(names)==len(set(names)) and set(names)==set(expected)|{'EVIDENCE.json'}
        indexed={m.name:m for m in members}
        evidence=json.load(tar.extractfile(indexed['EVIDENCE.json']))
        assert {row['path']for row in evidence['files']}==set(expected)
        for m in members:
            assert m.isfile() and m.mode==0o644 and m.mtime==0 and m.uid==m.gid==0
            data=tar.extractfile(m).read()
            if m.name=='EVIDENCE.json':continue
            assert data==(source/m.name).read_bytes()
            row=expected[m.name]
            if row is not None:assert data==original(row)
            count+=1;rawbytes+=len(data)
    assert archive.read_bytes()[4:8]==b'\0\0\0\0'
    return {'path':str(archive),'sha256':sha(archive.read_bytes()),'compressedBytes':archive.stat().st_size,
            'evidencePayloads':count,'payloadBytes':rawbytes,'independentAllMemberBytesEqual':True,
            'originalPayloads':len(source_rows),'allDeterministicHeadersChecked':True}
archives=[]
for group,items in sorted(bygroup.items()):
    source=OUT/'groups'/group;archive=OUT/'archives'/('stage47-c06-platform-'+group+'.tar.gz')
    execute(group+'-create',[sys.executable,TOOL,'create',source,archive])
    execute(group+'-verify',[sys.executable,TOOL,'verify',archive])
    archives.append(inspect(archive,source,items));save('archive-index.json',{'archives':archives})
    print(group+': full member/original readback0',flush=True)

# Recheck exact original files and all external Git-backed fixture/source aliases.
for row in rows:original(row)
for row in obj(OUT/'candidate-production-source-join.json')['rows']:
    for name in ['candidateSnapshot','buildWorkspacePath']:
        p=Path(row[name]);assert sha(p.read_bytes())==row['sha256'] and stat.S_IMODE(p.lstat().st_mode)==row['mode']
for row in obj(OUT/'git-fixture-reuse.json')['paths']:
    for p in [Path(row['candidateSnapshot']),WORK/row['path']]:
        assert stat.S_ISREG(p.lstat().st_mode) and sha(p.read_bytes())==row['sha256'] and stat.S_IMODE(p.lstat().st_mode)==row['mode']
save('original-after.json',{'rows':rows,'changes':[],
 'gitFixtureAliasPathsRechecked':len(obj(OUT/'git-fixture-reuse.json')['paths'])*2,
 'candidateProductionAliasPathsRechecked':len(obj(OUT/'candidate-production-source-join.json')['rows'])*2,
 'qualification':'Selected original path coverage was checked before gathering; only authenticated ancestor directories were descended. File kinds/modes/bytes and literal-link targets were rechecked after archive readback.'})
report={'schema':1,'scope':'Publication proposal of existing C06 actual platform evidence; no reports/docs/Git mutation or new evaluator/build/test execution.',
 'selectedPayloads':len(rows),'rawOriginalBytes':sum(r['bytes']for r in rows),'literalLinksSerialized':sum(r['kind']=='symlink'for r in rows),
 'groups':selected['groups'],'archives':archives,'compressedBytes':sum(x['compressedBytes']for x in archives),
 'gitFixtureFilesReused':len(obj(OUT/'git-fixture-reuse.json')['paths']),'candidateCanonicalSourceInputs':len(obj(OUT/'candidate-production-source-join.json')['rows']),
 'originalChanges':[],'allCreateAndSeparateVerifyCommandsExit0':True,'allMembersIndependentlyComparedToGatherAndOriginal':True,
 'sourceAndFixtureBindings':'candidate-production-source-join.json and git-fixture-reuse.json; old committed archives are not duplicated.',
 'evidenceTool':{'path':str(TOOL),'sha256':sha(TOOL.read_bytes())},
 'ownSelectionFailure':None,
 'compatibilityQualification':'Baseline6078 shared /6076 each vsJava with2regex failures; supplemental860/1008/252 eachNode+browser only; this package does not acquire full-selected regression or establish full M2.'}
save('report.json',report)
metadata=['select_payloads.py','package_payloads.py','selection.json','traversal-policy.json','git-fixture-reuse.json',
 'candidate-production-source-join.json','external-input-boundaries.json','producer-path-coverage.json',
 'original-before.json','original-after.json','archive-index.json','commands.json','report.json','git-tree.stdout.bin','git-tree.stderr.bin']
metadata+=['selection-execution-01/'+n for n in ['stdout.bin','stderr.bin','execution.json']]
for command in commands:
    for side in ['stdout','stderr']:metadata.append('commands/'+command['label']+'.'+side+'.bin')
closeout=OUT/'closeout-source';closeout.mkdir()
for name in metadata:
    p=closeout/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((OUT/name).read_bytes())
(closeout/'evidence.py').write_bytes(TOOL.read_bytes())
archive=OUT/'archives/stage47-c06-platform-publication-closeout.tar.gz'
execute('closeout-create',[sys.executable,TOOL,'create',closeout,archive])
execute('closeout-verify',[sys.executable,TOOL,'verify',archive])
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();expected=set(metadata)|{'evidence.py','EVIDENCE.json'}
    assert {m.name for m in members}==expected and len(members)==len(expected)
    for member in members:
        assert member.isfile() and member.mode==0o644 and member.mtime==0
        if member.name!='EVIDENCE.json':assert tar.extractfile(member).read()==(closeout/member.name).read_bytes()
save('closeout-index.json',{'path':str(archive),'sha256':sha(archive.read_bytes()),'compressedBytes':archive.stat().st_size,
 'payloads':len(metadata)+1,'allMembersIndependentlyCompared':True,'reviewedReportSha256':sha((OUT/'report.json').read_bytes()),
 'qualification':'Closeout archive preserves the main five-archive index and pre-outer-terminal report. Actual packaging wrapper terminal is a subsequent external receipt; no self-referential terminal claim.'})
print(json.dumps({'archives':len(archives)+1,'mainArchiveCompressedBytes':report['compressedBytes'],
 'closeoutCompressedBytes':archive.stat().st_size,'selectedPayloads':len(rows),'originalChanges':[]}))
