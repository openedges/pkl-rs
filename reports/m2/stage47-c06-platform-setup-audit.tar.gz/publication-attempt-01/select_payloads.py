"""Select exact C06 outputs without walking source/build/cache trees."""
from pathlib import Path
import hashlib
import json
import stat
import subprocess
import os

OUT=Path(__file__).resolve().parent
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
STAGE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
WORK=STAGE/'target/m2/stage47-c06-platform-workspace-01'
RUN=WORK/'target/m2/stage47-platform-acquisition-01'
CAND=STAGE/'target/m2/stage47-implementation-01/renderer-candidate-build-06'
AUDIT=MAIN/'target/m2/stage47-c06-platform-audit-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
def obj(p):return json.loads(p.read_bytes())
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
rows={}
def add(group,logical,source):
    assert not Path(logical).is_absolute() and '..' not in Path(logical).parts
    source=Path(source);s=source.lstat()
    assert stat.S_ISREG(s.st_mode),source
    data=source.read_bytes();row={'group':group,'path':logical,'originalPath':str(source),
        'kind':'regular','mode':stat.S_IMODE(s.st_mode),'bytes':len(data),'sha256':sha(data)}
    key=(group,logical);assert key not in rows;rows[key]=row
    return row
release=obj(CAND/'release.json');sm=obj(CAND/'source-after.json');modes=obj(CAND/'source-modes.json')
assert sha((CAND/'release.json').read_bytes())=='59543feca57c4994116708f9950fdabec97c3d7f3cbc261feafc2d8f074899c9'
assert obj(RUN/'outer-terminal.json')['exitCode']==0
assert obj(AUDIT/'closure.json')['closed']
save('traversal-policy.json',{'recursiveProducerTraversalUsed':False,
 'exactPrewalkExclusions':[str(WORK/'target/debug'),str(WORK/'target/release'),str(WORK/'target/wasm32-unknown-unknown'),
 str(WORK/'tools/platform/node_modules'),str(WORK/'.cache'),str(WORK/'external/pkl/.git'),str(WORK/'external/pkl-pantry/.git')],
 'selection':'Explicit maps, command filenames, session/call indexes and closure files only. Existing Git committed report archives and full51745 source duplicate tree are not walked/copied. No generic build-name exclusion.',
 'toolTraversal':'tools/evidence.py may rglob only freshly gathered regular files with no source/cache/link aliases.'})
top=obj(RUN/'report.json')
for name in ['report.json','run.py','active.json','outer-terminal.json','candidate-release.json','candidate-sources.json','cargo-config.toml']:
    add('build-baseline','acquisition/'+name,RUN/name)
for command in top['commands']:
    for side in ['stdout','stderr']:add('build-baseline','acquisition/'+command['name']+'.'+side+'.bin',RUN/(command['name']+'.'+side+'.bin'))
base=RUN/'baseline';br=obj(base/'report.json');bm=obj(base/'sources.json');commands=obj(base/'commands.json')
for name in ['report.json','sources.json','commands.json']:add('build-baseline','baseline/'+name,base/name)
for command in commands:
    for side in ['stdout','stderr']:add('build-baseline','baseline/'+command['name']+'.'+side+'.bin',base/(command['name']+'.'+side+'.bin'))
for name in br['artifacts']:add('build-baseline','baseline/'+name,base/name)
source_join=[]
for name,h in bm.items():
    row=add('build-baseline','baseline/sources/'+name,base/'sources'/name)
    assert row['sha256']==h==sm[name]
    original=CAND/'sources'/name;build=WORK/name
    assert sha(original.read_bytes())==sha(build.read_bytes())==h
    assert stat.S_IMODE(original.lstat().st_mode)==stat.S_IMODE(build.lstat().st_mode)==modes[name]==row['mode']
    source_join.append({'candidatePath':name,'candidateSnapshot':str(original),'buildWorkspacePath':str(build),
        'canonicalGroup':'build-baseline','canonicalArchivedPath':row['path'],'bytes':row['bytes'],'sha256':h,'mode':row['mode']})
for name in ['release.json','source-after.json','source-modes.json','report.json','environment.json']:
    add('build-baseline','candidate/'+name,CAND/name)
native=obj(base/'oracle-native/report.json')
for name in ['report.json','cases.json','input.tsv','java.stdout.bin','java.stderr.bin','rust.stdout.bin','rust.stderr.bin']:
    add('build-baseline','baseline/oracle-native/'+name,base/'oracle-native'/name)
for name,h in native['sources'].items():
    row=add('build-baseline','baseline/oracle-native/sources/'+name,base/'oracle-native/sources'/name)
    assert row['sha256']==h
for name in ['execution.json','node.stdout.bin','browser.stdout.bin','node-checks.json','browser-checks.json',
             'browser-launch.json','node-legacy-utf8-observations.json','browser-legacy-utf8-observations.json']:
    add('build-baseline','baseline/execution/'+name,base/'execution'/name)
for group,driver in [('renderer','compare-renderer.mjs'),('resource','compare-resource.mjs'),('module-preparation','compare-module-preparation.mjs')]:
    root=RUN/group
    for name in ['execution.json','fixtures.json','node.raw.json','browser.raw.json','preflight.stdout.bin','preflight.stderr.bin',
                 'preflight.process.json','resource-session.mjs',driver]+(['module-preparation-session.mjs'] if group=='module-preparation' else []):
        add(group,name,root/name)
    fixtures=obj(root/'fixtures.json')['fixtures']
    for target in ['node','browser']:
        actual=obj(root/(target+'.raw.json'));assert len(actual)==len(fixtures)
        for i,session in enumerate(actual):
            directory=root/target/str(i)
            for name in ['actual.json','expected.json','comparison.json']:
                add(group,target+'/'+str(i)+'/'+name,directory/name)
            for call in session['calls']:
                for channel in ['stdout','stderr']:
                    for encoding in ['utf16be','java-utf8']:
                        name=f'{call["index"]}.{channel}.{encoding}.bin'
                        add(group,target+'/'+str(i)+'/'+name,directory/name)
for number in [1]:
    root=MAIN/f'target/m2/stage47-c06-platform-preparation-{number:02}'
    for name in ['prepare.py','report.json','outer-terminal.json','active.json']:
        add('setup-audit',f'preparation-{number:02}/'+name,root/name)
    for command in obj(root/'report.json')['commands']:
        for side in ['stdout','stderr']:
            name=command['name']+'.'+side+'.bin';add('setup-audit',f'preparation-{number:02}/'+name,root/name)
restored=obj(MAIN/'target/m2/stage47-c06-platform-preparation-01/report.json')['restoredReferenceSymlinks']
for item in restored:
    p=WORK/'external'/item['reference']/item['path'];assert p.is_symlink();data=os.fsencode(os.readlink(p))
    assert data.hex()==item['targetHex'] and sha(data)==item['targetSha256']
    logical='reference-links/'+item['reference']+'/'+item['path']+'.literal-link.bin'
    rows['setup-audit',logical]={'group':'setup-audit','path':logical,'originalPath':str(p),'kind':'symlink',
        'mode':stat.S_IMODE(p.lstat().st_mode),'bytes':len(data),'sha256':sha(data),'targetHex':data.hex(),
        'gitBlob':item['blob'],'gitMode':'120000','qualification':'Literal target only; never follow the link.'}
closure=obj(AUDIT/'closure.json')
for item in closure['files']:
    row=add('setup-audit','independent-audit/'+item['path'],AUDIT/item['path'])
    assert row['sha256']==item['sha256'] and row['bytes']==item['bytes']
add('setup-audit','independent-audit/closure.json',AUDIT/'closure.json')

# Fixed Git tree resolves already committed golden fixture bytes without
# recursively duplicating their raw payloads or older report archives.
prefixes=['tests/fixtures/m2-renderer-portable','tests/fixtures/m2-resource-portable','tests/fixtures/m2-module-portable']
command=['git','ls-tree','-r','-z',release['base_commit'],'--',*prefixes]
process=subprocess.run(command,cwd=MAIN,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(OUT/'git-tree.stdout.bin').write_bytes(process.stdout);(OUT/'git-tree.stderr.bin').write_bytes(process.stderr)
assert process.returncode==0
tree={}
for record in process.stdout.split(b'\0'):
    if not record:continue
    header,path=record.split(b'\t',1);mode,kind,blob=header.decode().split(' ');tree[os.fsdecode(path)]=(mode,kind,blob)
git_rows=[]
fixture_inputs={name:h for name,h in sm.items() if any(name==prefix or name.startswith(prefix+'/') for prefix in prefixes)}
assert set(tree)==set(fixture_inputs)
for name,h in fixture_inputs.items():
    mode,kind,blob=tree[name];data=(CAND/'sources'/name).read_bytes()
    assert kind=='blob' and int(mode,8)==stat.S_IFREG|modes[name]
    assert sha(data)==h and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
    git_rows.append({'path':name,'bytes':len(data),'sha256':h,'mode':modes[name],'gitBlob':blob,'gitMode':mode,
                     'candidateSnapshot':str(CAND/'sources'/name)})
save('git-fixture-reuse.json',{'repository':str(MAIN),'commit':release['base_commit'],
 'command':command,'actualExitCode':process.returncode,'treeStdoutSha256':sha(process.stdout),'paths':git_rows,
 'qualification':'Exact bytes are available as immutable committed fixture blobs. Supplemental output copies fixtures.json and all actual target raw channels remain archived. Prior committed report/archive payloads are not duplicated.'})
save('candidate-production-source-join.json',{'rows':source_join,'count':len(source_join),
 'sourceMapSha256':release['source_map_sha256'],'regularMapCount':len(sm),
 'qualification':'All baseline-captured compilation inputs join actual immutable candidate bytes/modes and isolated workspace. Other51745-map inputs were directly verified in independent audit but are not all duplicated in these archives.'})
save('external-input-boundaries.json',{'candidateUnusedNativeArtifacts':release['artifacts'],
 'runtimeIdentityEvidence':'Preserved original reports carry Node/JDK/oracle/browser/wasm-bindgen hashes and pinned tool metadata; installed runtime/browser/npm dependency trees are not duplicated.',
 'notIncluded':['old committed reports archives','whole immutable51745 source duplicate tree','live newer heap/lifecycle tests','full language/lifecycle regression evidence'],
 'scope':'C06 intermediate selected actual platform only; no latest live-test, full Rust5 or fullM2 completion claim.'})
selection=sorted(rows.values(),key=lambda x:(x['group'],x['path']))
groups={}
for row in selection:
    group=groups.setdefault(row['group'],{'files':0,'bytes':0,'literalLinks':0})
    group['files']+=1;group['bytes']+=row['bytes'];group['literalLinks']+=row['kind']=='symlink'
save('selection.json',{'schema':1,'rows':selection,'groups':groups,'recursiveTraversalUsed':False,
 'modePolicy':'Original kinds/modes retained in mapping; evidence tool writes deterministic0644 tar headers. Symlinks serialized as raw target bytes, never followed.'})
print(json.dumps({'groups':groups,'selectedFiles':len(selection),'rawBytes':sum(r['bytes']for r in selection),
 'gitReusedFixtureFiles':len(git_rows),'canonicalSourceInputs':len(source_join)}))
