# C06 actual platform 독립 감사

기존 C06 원본을 read-only로 대조했으며 선택 계약에서 새 차단 결함은 찾지 못했다. 새 evaluator·Java·native·Node·browser·build·test를 실행하지 않았다.

## 정확한 후보와 실제 종료

- C06 release: `59543feca57c4994116708f9950fdabec97c3d7f3cbc261feafc2d8f074899c9`
- source map: `f736de4eef08949b42bca21b276da80ee1c914b5ce6dbd442fcc636feb5738f1`, regular paths51,745
- actual platform wrapper37946: exit0, report `b85f4b2c5aba32e20fd264071ec6a2300b4d450ce5f7e81f7c63a2294083dffd`
- baseline report: `8007819e2e65d8e44babde7518b1966074894997592fcd3bd14e38a8fd826dd6`

명시 source map의 모든 파일을 immutable candidate와 isolated build workspace 양쪽에서 직접 hash/mode 비교했다. Cargo controls와 stdlib literal inputs, typed bindings와 driver/tool inputs도 포함한다. Baseline이 별도 캡처한 compilation source와 produced native semantic probe/N-API addon/Wasm·glue/declaration을 source 및 artifact hash에 연결했다. C05 artifact에 새 이름만 붙인 결과가 아니다.

## Raw 결과

Baseline canonical hex transport 전체6,078개를 decode해 Rust/Node/browser의 full payload가 같은지 재비교했다. Java 대비 각6,076개 일치이며 정확히 `regex-unicode-15-vs-16`, `regex-zero-width-supplementary` 두 원시 차이가 남는다. Child oracle-native strict exit1을 architecture wrapper exit0과 구분한다. 과거 JavaUTF8-only fixture 그룹의 JS units는 별도 관찰로 남는다.

| Node와 Chromium 각각 | API | raw success/error | session | counted reader |
| --- | ---: | ---: | ---: | ---: |
| Renderer | 860 | 652 / 208 | 44 | 212 |
| Resource | 1,008 | 812 / 196 | 20 | 324 |
| Module preparation | 252 | 136 / 116 | 24 | 44 |

두 target 합계4,240 API의 expression/status, stdout/stderr의 UTF16BE·JavaUTF8 원문, 전후 reader count를 고정 fixture의 Java raw에 직접 연결했다. 별도 binary 파일도 raw JSON unit vector와 같다. 176개 session의 terminal slots0, consumed reader plan과 owned-view stability 기록을 확인했다. Ordinary error를 실행 성공으로 바꾸지 않고 기대된 full 오류와 같을 때만 비교 통과로 센다.

Module actual request를 exact provider identity에 다시 join했다. 각 target의 capabilities144, has-element392, resolve36, load-source36, counted read44, uncounted typed denied read28을 구분했다. 실제 요청 순서의 provider projection은 full per-call raw와 Java 선택 observable740개에 일치한다. Unordered input fact 전체를 Java SPI 호출·순서로 주장하지 않으며 denied read28개를 reader 실행으로 더하지 않는다. Primary/query admission 등 outsideContract 부분도 유지된다.

## Browser·HTTP·준비

기록한 Chrome 실행 파일을 launch의 `executablePath`에 명시했고 실제 binary SHA·Node 실행 파일·Playwright version/package lock을 대조했다. HTTP에서 실제 제공한 copied helper/Wasm bytes는 driver hash/postcheck에 포함된다. Copied driver/helper7개의 바이트가 C06 source와 같고, 세 missing asset probe는 actual404/empty body이다. Infrastructure/browser/input change 목록도 비었다. 설치 npm 전체 코드나 Java GC event trace까지 독립 입증했다는 주장은 아니다.

C06 preparation74277은 exit0이다. Git mode120000의 pinned reference symlink11개를 clean 검사 전에 복구했고, literal target·Git blob hash·target SHA와 real pinned checkout을 대조했다. C06 setup 실패가 따로 있었다고 쓰지 않는다. C05 initial94291 failure와24154 repair는 과거 C05 기록으로 보존되며 C06에 소급하지 않는다. Regular snapshot에 이 link를 과거부터 포함했던 것으로 바꾸지 않는다.

## 안정성·경계

명시 regular inputs121,273개와 literal link paths23개(원본/복사 reference 및 runtime alias 포함)의 전후 content/mode/target 변화는0이다. Source/cache tree의 recursive walk 없이 authenticated map·session index·command 기록만 읽었다. `traversal-policy.json`은 exact cache 경계와 direct exception을 남긴다.

이 범위는 C06의 baseline과 renderer860/Resource1008/module252 각 target이다. 추가 portable980, A의 originalCLI4 및 Rust5, B의 native1840은 별도 source-bound 기록이며 이 분모에 중복 합산하지 않는다. Policy84, explicit-close28, complete producer/constant-collection identity, stdlib admission, full selected regression·M2·성능 gate도 남는다. Source-bound owned-result/collection 측정을 Java GC와 같다고 표현하지 않는다.
