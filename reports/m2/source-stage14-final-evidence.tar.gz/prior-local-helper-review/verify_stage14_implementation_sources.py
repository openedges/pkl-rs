"""Bind each final local captured source copy to an exact implementation commit.

No captured binary is executed, and later PLAN/report-only changes need not
alter the implementation source commit. Prior exploratory candidate sources
remain separately identified and are not relabeled as final implementation.
"""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path.cwd()
BASE = ROOT / 'target/m2'


def load(path):
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.commit):
        raise ValueError('An exact full implementation commit SHA is required')
    def git(*arguments):
        return subprocess.run(['git', *arguments], cwd=ROOT, check=True,
                              capture_output=True, timeout=60).stdout
    if git('rev-parse', '--verify', args.commit + '^{commit}').decode().strip() != args.commit:
        raise ValueError('Implementation commit does not resolve exactly')
    @lru_cache(maxsize=None)
    def committed(name):
        path = Path(name)
        if path.is_absolute() or '..' in path.parts:
            raise ValueError('Unsafe captured source path')
        for prefix in ['external/pkl/', 'external/pkl-pantry/']:
            if name.startswith(prefix):
                repository = prefix.removesuffix('/')
                revision = git('rev-parse', args.commit + ':' + repository).decode().strip()
                return subprocess.run(['git', '-C', str(ROOT / repository), 'show',
                    revision + ':' + name.removeprefix(prefix)], check=True,
                    capture_output=True, timeout=60).stdout
        return git('show', args.commit + ':' + name)
    if args.output.exists():
        raise ValueError('Refusing to replace existing source-verification output')
    checks, reports, suite_counts = [], {}, {}
    def check(directory, rows):
        report_path = directory / 'report.json'
        report_name = str(report_path.relative_to(ROOT))
        if not rows or len({row[0] for row in rows}) != len(rows):
            raise ValueError('Missing or duplicate source rows: ' + str(directory))
        reports[report_name] = hashlib.sha256(report_path.read_bytes()).hexdigest()
        suite_counts[report_name] = len(rows)
        for name, snapshot, digest in rows:
            data = snapshot.read_bytes()
            if hashlib.sha256(data).hexdigest() != digest or data != committed(name):
                raise ValueError('Snapshot differs from implementation commit: ' + str(snapshot))
            checks.append(dict(source=name, snapshot=str(snapshot.relative_to(ROOT)), sha256=digest))
    for name, field in [('language', 'source_sha256'), ('frontend', 'source_sha256'), ('platforms', 'source_hashes')]:
        directory = BASE / (name + '-stage14-final')
        report = load(directory / 'report.json')
        check(directory, [(path, directory / 'sources' / path, digest)
                          for path, digest in report[field].items()])
    primitive = BASE / 'platforms-stage14-final/oracle-native'
    report = load(primitive / 'report.json')
    check(primitive, [(path, primitive / 'sources' / path, digest)
                      for path, digest in report['sources'].items()])
    for name in ['lifecycle-stage14-final', 'class-lifecycle-stage14-final']:
        directory = BASE / name
        report = load(directory / 'report.json')
        check(directory, [(row['path'], directory / row['snapshot'], row['sha256']) for row in report['sources']])
    directory = BASE / 'runtime-stage14-final'
    report = load(directory / 'report.json')
    check(directory, [(str(Path(row['snapshot']).relative_to(directory / 'sources')),
                       Path(row['snapshot']), row['sha256'])
                      for row in report['identities'] if 'snapshot' in row])
    result = dict(schema_version=1, implementation_commit=args.commit,
                  scope='Each final captured source copy equals exact Git implementation bytes. Prior exploratory candidate snapshots remain separate; no full language/API/performance completion claim.',
                  verified_source_snapshot_copies=len(checks), unique_source_files=len({r['source'] for r in checks}),
                  verified_source_suites=len(reports), source_suite_copies=suite_counts,
                  source_reports=reports, source_checks=checks,
                  verifier_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ['implementation_commit', 'verified_source_snapshot_copies', 'unique_source_files']}, sort_keys=True))


if __name__ == '__main__':
    main()
