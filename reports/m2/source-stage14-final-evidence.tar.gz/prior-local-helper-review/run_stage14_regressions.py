import subprocess,sys
for name in ['frontend','runtime','lifecycle']:
 command=[sys.executable,'target/m2/ci-stage14/capture_process.py','--output',f'target/m2/{name}-stage14-command-final','--',sys.executable,f'tools/m1_{name}.py','--output',f'target/m2/{name}-stage14-final']
 result=subprocess.run(command)
 if result.returncode: sys.exit(result.returncode)
