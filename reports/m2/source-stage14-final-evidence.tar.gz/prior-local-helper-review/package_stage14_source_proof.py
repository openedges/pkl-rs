"""Package exact-commit Stage 14 source proof after final captures are packaged.

This target-only helper never executes captured evaluation binaries or modifies
raw suites/archives. It refuses existing proof outputs and enriches only the
final summary that still explicitly marks its commit binding as pending.
"""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
COMMIT = None
PRIOR_COMMIT = '81f5a64330bcfaf4361ec27617a02c051311836d'


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def relative(name):
    path = Path(name)
    require(not path.is_absolute() and '..' not in path.parts,
            'Unsafe relative evidence path: ' + str(name))
    return path


def process(directory, filename='process.json', expected_exit=0):
    row = load(directory / filename)
    require(row['exit_code'] == expected_exit and row['timed_out'] is False,
            'Command did not complete successfully: ' + str(directory / filename))
    prefix = filename.removesuffix('process.json')
    for channel in ['stdout', 'stderr']:
        capture = directory / (prefix + channel + '.bin')
        require(sha(capture) == row[channel + '_sha256'],
                'Command capture digest differs: ' + str(capture))
        if channel + '_bytes' in row:
            require(capture.stat().st_size == row[channel + '_bytes'],
                    'Command capture size differs: ' + str(capture))
    return row


def git(*arguments):
    return subprocess.run(['git', *arguments], cwd=ROOT, check=True,
                          capture_output=True, timeout=60).stdout


@lru_cache(maxsize=None)
def committed(name):
    relative(name)
    for prefix in ['external/pkl/', 'external/pkl-pantry/']:
        if name.startswith(prefix):
            repository = prefix.removesuffix('/')
            revision = git('rev-parse', COMMIT + ':' + repository).decode().strip()
            return subprocess.run(['git', '-C', str(ROOT / repository), 'show',
                revision + ':' + name.removeprefix(prefix)], check=True,
                capture_output=True, timeout=60).stdout
    return git('show', COMMIT + ':' + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--source-process', default='source-stage14-final-process')
    parser.add_argument('--package-process', default='package-stage14-final-process')
    args = parser.parse_args()
    global COMMIT
    COMMIT = args.commit
    proof = BASE / 'source-stage14-final-evidence'
    archive = ROOT / 'reports/m2/source-stage14-final-evidence.tar.gz'
    summary_path = ROOT / 'reports/m2/stage14-final-summary.json'
    summary_temporary = summary_path.with_suffix('.source-proof.tmp')
    require(not any(p.exists() for p in [proof, archive, summary_temporary]),
            'Refusing to replace an existing source proof output')
    summary_original = summary_path.read_bytes()
    summary = json.loads(summary_original)
    require(summary['source_to_commit_binding'].startswith('Pending'),
            'Final summary is already bound; refusing to replace binding')
    require(git('rev-parse', '--verify', COMMIT + '^{commit}').decode().strip() == COMMIT,
            'Implementation commit does not resolve exactly')
    binding_path = BASE / 'source-verification-stage14-final.json'
    binding = load(binding_path)
    require(binding['implementation_commit'] == COMMIT, 'Wrong implementation binding')
    require(binding['verifier_sha256'] == sha(BASE / 'verify_stage14_implementation_sources.py'),
            'Source verifier differs from executed verifier')
    for name, digest in binding['source_reports'].items():
        require(sha(ROOT / relative(name)) == digest, 'Source report changed: ' + name)

    commands = [
        (args.source_process, 'source-binding-command'),
        (args.package_process, 'final-package-command'),
        ('language-stage14-command-final', 'language-command'),
        ('platforms-stage14-command-final', 'platforms-command'),
        ('validation-stage14-command-final', 'validation-command'),
        ('frontend-stage14-command-final', 'frontend-command'),
        ('runtime-stage14-command-final', 'runtime-command'),
        ('lifecycle-stage14-command-final', 'lifecycle-command'),
        ('prior-selection-stage14-command-final', 'prior-selection-command'),
    ]
    records = {destination: process(BASE / relative(name)) for name, destination in commands}
    source_command = records['source-binding-command']['command']
    require(COMMIT in source_command and '--output' in source_command
            and any(Path(arg).name == 'verify_stage14_implementation_sources.py'
                    for arg in source_command), 'Captured source-binding command differs')
    require(Path(source_command[source_command.index('--output') + 1]).resolve() == binding_path,
            'Captured source-binding command wrote another output')
    package_command = records['final-package-command']['command']
    require('--check-ready' not in package_command
            and any(Path(arg).name == 'package_stage14_final.py' for arg in package_command),
            'Captured packaging command is not final packaging')
    class_commands = BASE / 'class-lifecycle-stage14-command-final'
    for name in ['tests', 'integrity', 'contract']:
        process(class_commands, name + '.process.json')
    for name, digest in load(class_commands / 'evidence-sha256.json').items():
        require(sha(class_commands / relative(name)) == digest, 'Class command inventory differs')

    # Claims audit already belongs to the sealed regression package.
    claims_path = BASE / 'regressions-stage14-final/raw-claims-audit.json'
    claims = load(claims_path)
    require(claims['status'] == 'pass' and claims['captured_binaries_executed'] is False,
            'Final raw claims audit did not pass')
    for record in summary['archives'].values():
        path = ROOT / relative(record['path'])
        require(sha(path) == record['sha256'] and path.stat().st_size == record['bytes'],
                'Final raw archive identity changed: ' + str(path))
    regression_archive = summary['archives']['regressions']
    regression_path = ROOT / relative(regression_archive['path'])
    require(sha(regression_path) == regression_archive['sha256'], 'Regression archive changed')
    with tarfile.open(regression_path, 'r:gz') as stream:
        matches = [entry for entry in stream.getmembers()
                   if entry.isfile() and (entry.name.endswith('/raw-claims-audit.json')
                                          or entry.name == 'raw-claims-audit.json')]
        require(len(matches) == 1, 'Regression archive lacks one unique claims audit')
        require(stream.extractfile(matches[0]).read() == claims_path.read_bytes(),
                'Claims audit differs from sealed regression archive')

    reviewed = load(BASE / 'stage14-final-helper-review.json')
    for name, digest in reviewed['helpers'].items():
        require(sha(ROOT / relative(name)) == digest, 'Reviewed helper changed: ' + name)
    require(reviewed['syntax_valid'] is True, 'Helper syntax review missing')
    prior_dir = BASE / 'ci-stage14-prior-terminal-status'
    prior_status = load(prior_dir / 'status-summary.json')
    require(prior_status['commit'] == PRIOR_COMMIT
            and prior_status['all_six_jobs_succeeded'] is True,
            'Prior CI metadata identity/status differs')
    process(BASE / 'ci-stage14-prior-terminal-process')

    snapshots = binding['source_checks']
    require(binding['verified_source_suites'] == len(binding['source_reports']) == 7
            and sum(binding['source_suite_copies'].values()) == len(snapshots),
            'Source suite accounting differs')
    require(len(snapshots) == binding['verified_source_snapshot_copies'] and snapshots,
            'Source copy count differs')
    unique = {}
    for row in snapshots:
        source = str(relative(row['source']))
        snapshot = ROOT / relative(row['snapshot'])
        data = snapshot.read_bytes()
        require(hashlib.sha256(data).hexdigest() == row['sha256']
                and data == committed(source), 'Snapshot differs from exact commit: ' + str(snapshot))
        if source in unique:
            require(unique[source].read_bytes() == data, 'Duplicated source copies differ')
        unique[source] = snapshot
    require(len(unique) == binding['unique_source_files'], 'Unique source count differs')

    proof.mkdir()
    for name in ['source-verification-stage14-final.json', 'stage14-final-helper-review.json']:
        shutil.copyfile(BASE / name, proof / name)
    for name in reviewed['helpers']:
        shutil.copyfile(ROOT / name, proof / Path(name).name)
    for source, destination in commands:
        shutil.copytree(BASE / source, proof / destination)
    shutil.copytree(class_commands, proof / 'declaration-verification-commands')
    shutil.copyfile(claims_path, proof / 'raw-claims-audit.json')
    shutil.copytree(prior_dir, proof / 'prior-ci-terminal-status')
    shutil.copytree(BASE / 'ci-stage14-prior-terminal-process', proof / 'prior-ci-terminal-command')
    for source, snapshot in unique.items():
        destination = proof / 'implementation-sources' / source
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(snapshot, destination)
    write_new(proof / 'source-copy-index.json', {
        'implementation_commit': COMMIT,
        'source_snapshot_copies': binding['verified_source_snapshot_copies'],
        'unique_source_files': len(unique),
        'copies': [{ 'source': name, 'snapshot': 'implementation-sources/' + name,
                    'sha256': sha(path)} for name, path in sorted(unique.items())],
    })
    write_new(proof / 'scope.json', {
        'implementation_commit': COMMIT,
        'captured_binaries_executed': False,
        'source_snapshot_copies': binding['verified_source_snapshot_copies'],
        'unique_source_files': len(unique),
        'scope': 'Each captured source copy and deduplicated proof copy equals exact Git implementation bytes, including pinned submodule blobs. Original raw comparison suites remain in separate unchanged archives. No new compatibility or performance case is introduced.',
        'claims_audit': {'path': 'raw-claims-audit.json', 'sha256': sha(claims_path),
                         'original_archive': regression_archive},
        'review_preparation': 'Target-only helpers are syntax reviewed and retained with exact hashes; this is evidence provenance rather than an additional compatibility case.',
        'prior_ci': {'commit': PRIOR_COMMIT, 'run_id': prior_status['run_id'],
                     'scope': 'Separate prior reporting commit terminal status. Original metadata wording is preserved; this is not Stage 14 implementation CI or compatibility evidence.'},
    })
    subprocess.run([sys.executable, 'tools/evidence.py', 'create', str(proof), str(archive)], check=True)
    subprocess.run([sys.executable, 'tools/evidence.py', 'verify', str(archive)], check=True)
    with tarfile.open(archive, 'r:gz') as stream:
        archive_files = len(stream.getmembers())
    archive_identity = dict(path=str(archive.relative_to(ROOT)), sha256=sha(archive),
        bytes=archive.stat().st_size, files_including_inventory=archive_files, inventory_verified=True)
    require(summary_path.read_bytes() == summary_original,
            'Final summary changed concurrently; archive retained and summary not replaced')
    summary['implementation_commit'] = COMMIT
    summary['source_to_commit_binding'] = 'All final captured source copies match exact Git implementation bytes; retained raw suites and recorded-build identities remain separate evidence.'
    summary['implementation_source_verification'] = dict(
        source_snapshot_copies=binding['verified_source_snapshot_copies'],
        unique_source_files=len(unique), matched_exact_git_commit=True,
        report_sha256=sha(binding_path), evidence=archive_identity,
        method='Each captured full source byte string matches git show at the exact implementation commit, resolving external sources through that commit\'s pinned gitlinks. The proof also retains deduplicated exact source copies.')
    summary['final_claims_audit'].update(report_sha256=sha(claims_path),
        source_evidence_path='raw-claims-audit.json', new_compatibility_test_count=0,
        original_evidence=regression_archive)
    write_new(summary_temporary, summary)
    summary_temporary.replace(summary_path)
    print(json.dumps(dict(archive=archive_identity, implementation_commit=COMMIT,
        source_copies=binding['verified_source_snapshot_copies'], unique_source_files=len(unique)), sort_keys=True))


if __name__ == '__main__':
    main()
