import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path.cwd()
out=root/sys.argv[1]
out.mkdir(parents=True,exist_ok=False)
checks=[
 ['cargo','xtask','verify'],
 ['cargo','fmt','--all','--','--check'],
 ['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],
 ['cargo','test','--workspace','--locked'],
 ['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked'],
 [sys.executable,'-m','unittest','discover','-s','tools/tests','-v'],
 [sys.executable,'tools/m2_manifest.py','--check'],
]
rows=[]
for i,command in enumerate(checks):
 result=subprocess.run(command,cwd=root,capture_output=True)
 for kind,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  (out/f'{i}.{kind}.bin').write_bytes(data)
 row={'command':command,'exit_code':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
 rows.append(row)
 (out/'report.json').write_text(json.dumps({'scope':'M2 stage 14 development checks; full compatibility remains separate.','checks':rows},indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if result.returncode:
  print(result.stdout.decode(errors='replace')[-12000:]+result.stderr.decode(errors='replace')[-12000:],flush=True)
  sys.exit(1)
