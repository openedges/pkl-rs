"""Capture collector execution provenance without changing any producer roots."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
sha = lambda value: hashlib.sha256(value).hexdigest()
inputs = [OUT / "package.py", OUT / "collect.py", ROOT / "tools/evidence.py",
          OUT / "selection.json", OUT / "proposal.json", OUT / "exclusions.json", OUT / "gather-report.json"]
assert not (OUT / "archive-process.json").exists()
before = {str(path): sha(path.read_bytes()) for path in inputs}
command = [sys.executable, "-u", str(OUT / "package.py"), "archive"]
started = datetime.datetime.now(datetime.UTC).isoformat()
clock = time.monotonic()
with (OUT / "archive.stdout.bin").open("xb") as stdout, (OUT / "archive.stderr.bin").open("xb") as stderr:
    completed = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
after = {str(path): sha(path.read_bytes()) for path in inputs}
report = {"schema": 1, "argv": command, "cwd": str(ROOT), "host": platform.platform(), "python": sys.version,
          "started_utc": started, "finished_utc": datetime.datetime.now(datetime.UTC).isoformat(),
          "seconds": time.monotonic() - clock, "exit_code": completed.returncode,
          "input_hashes_before": before, "input_hashes_after": after, "inputs_stable": before == after,
          "stdout_sha256": sha((OUT / "archive.stdout.bin").read_bytes()),
          "stderr_sha256": sha((OUT / "archive.stderr.bin").read_bytes())}
(OUT / "archive-process.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"exit_code": completed.returncode, "inputs_stable": before == after, "seconds": report["seconds"]}))
raise SystemExit(completed.returncode)
