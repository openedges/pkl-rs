"""Select immutable classpath integration evidence; bind explicit Git commit only."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
COMMIT = "01971d0c0a231132bcb30a7dae6ac244b7fed953"
OLD = Path("/Users/cody.ij.hwang/Projects/pkl-rs.classpath")
REVIEW = Path("/Users/cody.ij.hwang/Projects/pkl-rs.stage45/target/m2/stage45-jvm-profile-review-01")
OLD_FOCUSED = OLD / "target/m2/classpath-m2-integration-01"
NEW_FOCUSED = ROOT / "target/m2/classpath-combined-focused-01"
GROUPS = {
    "original-proposal": [OLD / "target/m2/classpath-m2-integration-captures-01"],
    "original-focused": [OLD_FOCUSED, OLD / "target/m2/classpath-m2-integration-01-jvm-classpath-workspace"],
    "independent-review": [REVIEW],
    "combined-promotion": [ROOT / "target/m2/classpath-combined-promotion-01"],
    "combined-validation": [ROOT / ("target/m2/classpath-combined-validation-" + n) for n in ["01", "02", "03"]],
    "combined-focused": [NEW_FOCUSED, ROOT / "target/m2/classpath-combined-focused-01-jvm-classpath-workspace"],
    "combined-review": [ROOT / "target/m2/classpath-combined-integration-review-01"],
}
# Exact dependency/cache paths are declared BEFORE any traversal. Do not prune
# generic basenames, including build. No selected-root symlink is traversed.
EXCLUDED = set()
for root, focused in [(ROOT, NEW_FOCUSED), (OLD, OLD_FOCUSED)]:
    EXCLUDED.update(root / name for name in ["target/debug", "target/release", "target/wasm32-unknown-unknown", ".cache", ".git", "tools/platform/node_modules", "tools/__pycache__", "tools/tests/__pycache__"])
    EXCLUDED.update([focused / "build", focused / "jvm-classpath/build"])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")

def git(*args, cwd=ROOT):
    return subprocess.check_output(["git", *args], cwd=cwd)

def tree(commit, cwd=ROOT):
    rows = {}
    for item in git("ls-tree", "-rz", commit, cwd=cwd).split(b"\0"):
        if item:
            metadata, name = item.split(b"\t", 1)
            mode, kind, oid = metadata.decode().split()
            rows[name.decode()] = (mode, kind, oid)
    return rows

def binding():
    commit_tree = tree(COMMIT)
    pins = {}
    expanded = dict(commit_tree)
    for name in ["external/pkl", "external/pkl-pantry"]:
        mode, kind, pin = commit_tree[name]
        assert (mode, kind) == ("160000", "commit")
        pins[name] = pin
        expanded.update({name + "/" + path: value for path, value in tree(pin, cwd=ROOT / name).items()})
    groups = {}
    for label, focused in [("original", OLD_FOCUSED), ("combined", NEW_FOCUSED)]:
        parent = json.loads((focused / "report.json").read_bytes())
        child_path = focused / "jvm-classpath/report.json"
        child = json.loads(child_path.read_bytes())
        assert sha(child_path.read_bytes()) == parent["classpath_eval"]["child_report_sha256"]
        assert parent["source_sha256"] == child["sources"] == child["sources_after"]
        rows = {}
        for name, expected in parent["source_sha256"].items():
            data = (focused / "sources" / name).read_bytes()
            assert sha(data) == expected and data == (focused / "jvm-classpath/sources" / name).read_bytes(), name
            oid = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            actual = expanded.get(name)
            matches = bool(actual and actual[1:] == ("blob", oid))
            if label == "combined":
                assert matches, name
            rows[name] = {"captured_sha256": expected, "captured_git_blob": oid, "bytes": len(data),
                          "committed_git_blob": actual[2] if actual else None,
                          "matches_integration_commit": matches}
        write(label + "-source-map.json", rows)
        groups[label] = {"source_paths": len(rows), "source_map_sha256": sha((OUT / (label + "-source-map.json")).read_bytes()),
                         "parent_report_sha256": sha((focused / "report.json").read_bytes()),
                         "child_report_sha256": sha(child_path.read_bytes()),
                         "matches_integration_commit": sum(row["matches_integration_commit"] for row in rows.values()),
                         "historical_differences": [name for name, row in rows.items() if not row["matches_integration_commit"]],
                         "candidate_sha256": parent["classpath_candidate"]["sha256"]}
    assert groups["original"]["source_paths"] == 3813 and groups["combined"]["source_paths"] == 3823
    names = git("diff-tree", "--no-commit-id", "--name-only", "-r", COMMIT).decode().splitlines()
    snapshots = OUT / "committed-files"
    assert not snapshots.exists()
    snapshots.mkdir()
    changed = {}
    for name in names:
        data = git("show", COMMIT + ":" + name)
        destination = snapshots / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert commit_tree[name][1:] == ("blob", blob)
        changed[name] = {"sha256": sha(data), "git_blob": blob, "bytes": len(data), "mode": commit_tree[name][0]}
    write("committed-change-map.json", changed)
    (OUT / "commit.raw").write_bytes(git("cat-file", "commit", COMMIT))
    write("source-binding.json", {"schema": 1, "commit": COMMIT, "tree": git("rev-parse", COMMIT + "^{tree}").decode().strip(),
                                 "scope": "Combined captured inputs match actual integration-commit blobs and pinned reference blobs. Original proposal/execution remains historical and its exact differences are explicit. No current README or later HEAD is used for this binding.",
                                 "captures": groups, "pinned_gitlinks": pins, "committed_change_paths": len(changed),
                                 "committed_change_map_sha256": sha((OUT / "committed-change-map.json").read_bytes()),
                                 "commit_raw_sha256": sha((OUT / "commit.raw").read_bytes()),
                                 "git_writes": False, "full_selected_regression_claimed": False, "full_m2_complete": False})

def entry(path, archive_path, group):
    metadata = path.lstat()
    if stat.S_ISLNK(metadata.st_mode):
        data = os.readlink(os.fsencode(path)); kind = "symbolic-link-as-exact-target-bytes"
    else:
        assert stat.S_ISREG(metadata.st_mode), str(path)
        data = path.read_bytes(); kind = "regular-file"
    return {"source": str(path), "archive_path": archive_path, "group": group, "kind": kind,
            "bytes": len(data), "sha256": sha(data), "original_mode": stat.S_IMODE(metadata.st_mode)}

def main():
    assert not (OUT / "selection.json").exists()
    binding()
    GROUPS["committed-files"] = [OUT / "committed-files"]
    write("exclusions.json", {"declared_before_walk": True, "exact_absolute_paths": [str(path) for path in sorted(EXCLUDED)],
                              "generic_basename_exclusions": [], "symlink_policy": "Never follow; preserve raw os.readlink bytes, kind and original mode."})
    rows = []
    encountered = []
    for group, roots in GROUPS.items():
        for source in roots:
            assert source.is_dir() and not source.is_symlink(), str(source)
            for directory, dirs, files in os.walk(source, topdown=True, followlinks=False):
                directory = Path(directory)
                assert directory not in EXCLUDED
                keep = []
                for name in sorted(dirs):
                    child = directory / name
                    if child in EXCLUDED:
                        encountered.append(str(child))
                    elif child.is_symlink():
                        rows.append(entry(child, f"{group}/{source.name}/{child.relative_to(source).as_posix()}", group))
                    else:
                        keep.append(name)
                dirs[:] = keep
                for name in sorted(files):
                    child = directory / name
                    if child in EXCLUDED:
                        encountered.append(str(child)); continue
                    rows.append(entry(child, f"{group}/{source.name}/{child.relative_to(source).as_posix()}", group))
    rows.sort(key=lambda row: row["archive_path"])
    assert len({row["archive_path"] for row in rows}) == len(rows)
    write("selection.json", {"schema": 1, "groups": {group: [str(root) for root in roots] for group, roots in GROUPS.items()},
                             "rows": rows, "encountered_exact_exclusions": encountered,
                             "scope": "Complete selected producer roots and original source/artifact/raw-byte inputs. Failed unit test and orchestration attempts remain failed. No full-corpus claim.",
                             "compiled_artifact_policy": "Preserve all recorded immutable native, JAR and Java class artifacts, plus captured runtime identity files; exclude only the exact declared Cargo/dependency cache paths before descent."})
    counts = {}
    for group in GROUPS:
        selected = [row for row in rows if row["group"] == group]
        counts[group] = {"roots": len(GROUPS[group]), "payloads": len(selected), "bytes": sum(row["bytes"] for row in selected),
                         "kinds": dict(Counter(row["kind"] for row in selected))}
    write("proposal.json", {"schema": 1, "commit": COMMIT, "group_counts": counts, "payloads": len(rows), "bytes": sum(row["bytes"] for row in rows),
                            "selection_sha256": sha((OUT / "selection.json").read_bytes()),
                            "source_binding_sha256": sha((OUT / "source-binding.json").read_bytes()), "archive_created": False,
                            "original_evidence_changed": False, "git_writes": False})
    print((OUT / "proposal.json").read_text())

if __name__ == "__main__":
    main()
