# Candidate04 staged index 바이트 연결 감사

candidate04 declared437 source와 fixture75,863개 및 실행도구/의존helper/manifest/4개 테스트를 선택했다. 고유76,302개 파일 모두 실제 filesystem 바이트와 staged blob이 같다. 각3053고유 object는 raw cat-file 응답에서 Git object header+body hash 및 SHA256을 직접 계산했다. 외부 pkl21개는 submodule index와 main staged gitlink commit의 ls-tree까지 연결했다.

main/submodule의 선택된 index record는 실행 전후 같고, 전체 main index 파일 hash도 같았다. filesystem 후행변화가 없다. Git은 read-only 명령만 사용했고 optional locks를 비활성화했다. stdin 전체를 bulk로 넣지 않고 OID 하나마다 응답을 완전히 읽어 pipe 교착을 피했다. 원시 요청/응답/offset/PID/runtime/종료결과를 보존한다.

현재HEAD는 관측한 base460bfa5일 뿐이다. 이번 결과는 staged blob binding이며 아직 새 commit은 없다. Root가 commit 뒤 같은 경로/mode/OID를 그 commit에 join해야 한다. 과거 후보 source와 현재index가 같다고 주장하지 않는다. PLAN/docs는 후속 문서편집 범위이므로 선택하지 않았다.

도구 자체검토에서 마지막 proof drift 검사가 자기비교인 것을 발견했다. 그 검사를 신뢰하지 않으며, 별도 post-guard가 닫힌 build report의 proof SHA와 현재 proof,437개 바인딩행, frozen source SHA를 다시 연결했다. 기존 실제 byte대조나 staged record는 바꾸지 않았다. 생산도구나 Git index를 고치지 않았고 평가를 재실행하지 않았다.
