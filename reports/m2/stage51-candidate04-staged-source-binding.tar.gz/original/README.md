# Candidate04 staged Git blob binding

This is a read-only binding of 76,302 selected filesystem files to staged Git blob bytes. It covers all 437 declared candidate04 source inputs, 75,862 fixture payloads plus their manifest, five executed collection tools, two transitive helpers, two platform dependency manifests, and four Python/JavaScript test files. Overlapping paths are counted once.

The observed HEAD is 460bfa5d06044716a43997f829c41df9817cc9b8 only as a base marker; see the authoritative full value in report.json. These bytes are staged index content, not asserted HEAD content, and no future commit is bound. Root must join the same path/mode/OID rows to the final commit after creation. Historical candidate source snapshots are outside this binding. PLAN.md and docs are deliberately excluded.

Twenty-one external/pkl source files are staged blobs in the submodule repository, additionally verified against the tree of the main staged gitlink commit. The two reference gitlinks match references.lock. They are not falsely represented as ordinary main-index file entries.

Each unique blob was read through cat-file --batch using one request followed by the complete response, with stderr redirected to a regular file. Raw response streams, request streams, byte offsets, independently verified Git object hashes and SHA-256 values are preserved. Actual filesystem bytes were directly compared with blob bytes. Selected index records and filesystem hashes/modes stayed unchanged.

The original target-only script's trailing proof-file self-comparison is not relied on. post-guard.py independently authenticates the proof SHA against the closed candidate04 build report and joins all 437 staged rows to the authenticated map and frozen snapshots. This self-found limitation is preserved explicitly in post-guard-report.json.

No Git index, source, fixture or report was written; no evaluator or compatibility experiment was run. Only this new target output was created.
