from pathlib import Path
import hashlib,json,os,stat
O=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();r=json.loads((O/'report.json').read_bytes());post=json.loads((O/'post-guard-report.json').read_bytes());assert post['status'].startswith('PASS')and post['bindingReportSha256']==sha(O/'report.json')and post['fileBindingsSha256']==r['fileBindingsSha256']==sha(O/'file-bindings.json');assert r['candidate04SourcesBound']==437 and r['fixtureTotalFilesBound']==75863 and r['selectedUniqueFiles']==76302 and not r['filesystemChanges']
(O/'README.md').write_text('''# Candidate04 staged Git blob binding

This is a read-only binding of 76,302 selected filesystem files to staged Git blob bytes. It covers all 437 declared candidate04 source inputs, 75,862 fixture payloads plus their manifest, five executed collection tools, two transitive helpers, two platform dependency manifests, and four Python/JavaScript test files. Overlapping paths are counted once.

The observed HEAD is 460bfa5d06044716a43997f829c41dd1ec416cac1770fc1 only as a base marker; see the authoritative full value in report.json. These bytes are staged index content, not asserted HEAD content, and no future commit is bound. Root must join the same path/mode/OID rows to the final commit after creation. Historical candidate source snapshots are outside this binding. PLAN.md and docs are deliberately excluded.

Twenty-one external/pkl source files are staged blobs in the submodule repository, additionally verified against the tree of the main staged gitlink commit. The two reference gitlinks match references.lock. They are not falsely represented as ordinary main-index file entries.

Each unique blob was read through cat-file --batch using one request followed by the complete response, with stderr redirected to a regular file. Raw response streams, request streams, byte offsets, independently verified Git object hashes and SHA-256 values are preserved. Actual filesystem bytes were directly compared with blob bytes. Selected index records and filesystem hashes/modes stayed unchanged.

The original target-only script's trailing proof-file self-comparison is not relied on. post-guard.py independently authenticates the proof SHA against the closed candidate04 build report and joins all 437 staged rows to the authenticated map and frozen snapshots. This self-found limitation is preserved explicitly in post-guard-report.json.

No Git index, source, fixture or report was written; no evaluator or compatibility experiment was run. Only this new target output was created.
''')
# Correct the explanatory observed HEAD from the actual recorded value; no commit/tree inference.
p=O/'README.md';text=p.read_text();text=text.replace('460bfa5d06044716a43997f829c41dd1ec416cac1770fc1',r['headBefore']);p.write_text(text)
(O/'REVIEW.ko.md').write_text('''# Candidate04 staged index 바이트 연결 감사

candidate04 declared437 source와 fixture75,863개 및 실행도구/의존helper/manifest/4개 테스트를 선택했다. 고유76,302개 파일 모두 실제 filesystem 바이트와 staged blob이 같다. 각3053고유 object는 raw cat-file 응답에서 Git object header+body hash 및 SHA256을 직접 계산했다. 외부 pkl21개는 submodule index와 main staged gitlink commit의 ls-tree까지 연결했다.

main/submodule의 선택된 index record는 실행 전후 같고, 전체 main index 파일 hash도 같았다. filesystem 후행변화가 없다. Git은 read-only 명령만 사용했고 optional locks를 비활성화했다. stdin 전체를 bulk로 넣지 않고 OID 하나마다 응답을 완전히 읽어 pipe 교착을 피했다. 원시 요청/응답/offset/PID/runtime/종료결과를 보존한다.

현재HEAD는 관측한 base460bfa5일 뿐이다. 이번 결과는 staged blob binding이며 아직 새 commit은 없다. Root가 commit 뒤 같은 경로/mode/OID를 그 commit에 join해야 한다. 과거 후보 source와 현재index가 같다고 주장하지 않는다. PLAN/docs는 후속 문서편집 범위이므로 선택하지 않았다.

도구 자체검토에서 마지막 proof drift 검사가 자기비교인 것을 발견했다. 그 검사를 신뢰하지 않으며, 별도 post-guard가 닫힌 build report의 proof SHA와 현재 proof,437개 바인딩행, frozen source SHA를 다시 연결했다. 기존 실제 byte대조나 staged record는 바꾸지 않았다. 생산도구나 Git index를 고치지 않았고 평가를 재실행하지 않았다.
''')
h={'status':'CLOSED-staged-blob-binding-awaiting-future-root-commit-join','reportSha256':sha(O/'report.json'),'postGuardReportSha256':sha(O/'post-guard-report.json'),'fileBindingsSha256':sha(O/'file-bindings.json'),'gitObjectReadbackSha256':sha(O/'git-objects.json'),'sourceBuildProofSha256':r['sourceBuildProofSha256'],'candidate04SourcesBound':437,'fixtureFilesBound':75863,'uniqueFilesBound':76302,'uniqueGitBlobsRead':3053,'allFilesystemBytesEqualStagedBlobs':True,'allFrozenSourceBytesEqualStagedBlobs':True,'selectedIndexEntriesStable':True,'wholeIndexHashStable':r['wholeIndexHashStable'],'filesystemChanges':[],'submoduleFilesBoundViaStagedGitlinkTree':21,'baseHeadObserved':r['headBefore'],'newCommitBound':False,'actualBindingToolSession':12497,'actualBindingTerminalChunk':'628224','actualBindingExitCode':0,'actualProofPostGuardToolChunk':'7192d7','actualProofPostGuardExitCode':0,'gitWrites':False,'evaluationExecutions':0,'standardDocsExcluded':True,'historicalCandidateSourcesExcluded':True,'liveHandles':[]};(O/'handoff.json').write_text(json.dumps(h,indent=2)+'\n')
rows={p.name:{'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}for p in O.iterdir()if p.is_file()and p.name not in ['inventory.json','closure.json','seal.stdout.bin','seal.stderr.bin']};(O/'inventory.json').write_text(json.dumps({'schema':1,'files':rows},indent=2)+'\n');(O/'closure.json').write_text(json.dumps({'sealed':True,'handoffSha256':sha(O/'handoff.json'),'inventorySha256':sha(O/'inventory.json'),'liveHandles':[]},indent=2)+'\n');print(json.dumps({'handoffSha256':sha(O/'handoff.json'),'reportSha256':sha(O/'report.json'),'postGuardReportSha256':sha(O/'post-guard-report.json'),'fileBindingsSha256':sha(O/'file-bindings.json'),'closureSha256':sha(O/'closure.json'),'inventoryFiles':len(rows)},indent=2),flush=True)
