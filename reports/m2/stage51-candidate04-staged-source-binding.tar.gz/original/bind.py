"""Read-only exact byte binding to staged Git blobs, not HEAD or a future commit."""
from pathlib import Path,PurePosixPath
import collections,datetime,hashlib,json,os,platform,re,shutil,stat,subprocess,sys
O=Path(__file__).resolve().parent;R=O.parents[2];GIT=Path(shutil.which('git')).resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ENV={**os.environ,'GIT_OPTIONAL_LOCKS':'0'}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def need(x,s):
 if not x:raise ValueError(s)
commands=[]
def command(label,args,repo=R):
 argv=[str(GIT),'-c','gc.auto=0',*args];row={'argv':argv,'cwd':str(repo),'startedUtc':now(),'parentPid':os.getpid(),'environmentOverrides':{'GIT_OPTIONAL_LOCKS':'0'}}
 with(O/(label+'.stdout.bin')).open('wb')as out,(O/(label+'.stderr.bin')).open('wb')as err:
  child=subprocess.Popen(argv,cwd=repo,env=ENV,stdout=out,stderr=err);row['pid']=child.pid;save(O/(label+'.launch.json'),row);row['exitCode']=child.wait()
 row.update(finishedUtc=now(),stdoutSha256=sha(O/(label+'.stdout.bin')),stderrSha256=sha(O/(label+'.stderr.bin')));save(O/(label+'.terminal.json'),row);commands.append(row);need(row['exitCode']==0,'Git read failed '+label);return(O/(label+'.stdout.bin')).read_bytes()
def parse_stage(data):
 rows={}
 for raw in data.split(b'\0'):
  if not raw:continue
  header,path=raw.split(b'\t',1);mode,oid,stage=header.decode('ascii').split();rel=path.decode('utf-8');need(stage=='0','nonzero Git stage '+rel);need(rel not in rows,'duplicate staged path');rows[rel]={'mode':mode,'oid':oid,'stage':0}
 return rows
proof_path=O.parent/'stage51-candidate04-build/build-proof.json';proof=json.loads(proof_path.read_bytes());need(proof['status']=='CLOSED'and proof['sourceStable']and len(proof['sources'])==437,'candidate04 proof not closed437');snapshot=Path(proof['snapshotRoot']);need(snapshot==proof_path.parent/'sources','unexpected frozen snapshot');need(json.loads((proof_path.parent/'sources-before.json').read_bytes())==json.loads((proof_path.parent/'sources-after.json').read_bytes())==proof['sources'],'frozen maps differ')
fixture_rel='tests/fixtures/m2-collection-transforms';fixture=R/fixture_rel;manifest=fixture/'manifest.json';need(sha(manifest)=='a90cc8d0c409b03c783192f39cf265052e3efa48e0d9bc5f7d64818e57a2558d','fixture manifest pin differs');fm=json.loads(manifest.read_bytes());need(len(fm['files'])==75862,'fixture payload count differs')
selected={}
def add(rel,category,expected=None,size=None):
 p=PurePosixPath(rel);need(not p.is_absolute()and '..'not in p.parts and p.as_posix()==rel,'unsafe selected path');need(rel!='PLAN.md'and not rel.startswith('docs/'),'documentation excluded');row=selected.setdefault(rel,{'categories':[],'expectedSha256':None,'expectedBytes':None})
 if category not in row['categories']:row['categories'].append(category)
 if expected is not None:need(row['expectedSha256']in [None,expected],'authority hashes conflict '+rel);row['expectedSha256']=expected
 if size is not None:need(row['expectedBytes']in [None,size],'authority sizes conflict '+rel);row['expectedBytes']=size
for rel,h in proof['sources'].items():add(rel,'candidate04-declared-source',h)
for rel,row in fm['files'].items():add(fixture_rel+'/'+rel,'fixture-payload',row['sha256'],row['bytes'])
add(fixture_rel+'/manifest.json','fixture-manifest',sha(manifest),manifest.stat().st_size)
tools=['tools/collection_transform_fixtures.py','tools/collection_transform_native.py','tools/platform/collection-transform-session.mjs','tools/platform/compare-collection-transforms.mjs','tools/platform/compare-collection-transform-native.mjs']
helpers=['tools/platform/resource-session.mjs','tools/platform/module-policy-session.mjs'];toolchain=['tools/platform/package.json','tools/platform/package-lock.json'];tests=['tools/tests/test_collection_transform_fixtures.py','tools/tests/test_collection_transform_native.py','tools/platform/collection-transform-session.test.mjs','tools/platform/compare-collection-transforms.test.mjs']
for category,paths in [('executed-tool',tools),('transitive-helper',helpers),('platform-dependency-manifest',toolchain),('test',tests)]:
 for rel in paths:add(rel,category,sha(R/rel),(R/rel).stat().st_size)
# Authenticate allowed fixture directories before any descent; undeclared directories are rejected before scanning them.
allowed_dirs={''}
for rel in [*fm['files'],'manifest.json']:
 allowed_dirs.update(p.as_posix()for p in PurePosixPath(rel).parents if p.as_posix()!='.')
actual_fixture=set();todo=[fixture]
while todo:
 d=todo.pop()
 for e in os.scandir(d):
  p=Path(e.path);rel=p.relative_to(fixture).as_posix();need(not p.is_symlink(),'fixture symlink')
  if e.is_dir(follow_symlinks=False):need(rel in allowed_dirs,'undeclared fixture directory before descent');todo.append(p)
  else:need(e.is_file(follow_symlinks=False),'nonregular fixture');actual_fixture.add(rel)
need(actual_fixture==set(fm['files'])|{'manifest.json'},'filesystem fixture coverage differs')
version=command('git-version',['version','--build-options']).decode();exec_path=command('git-exec-path',['--exec-path']).decode().strip();head_before=command('head-before',['rev-parse','HEAD']).decode().strip();format_main=command('object-format-main',['rev-parse','--show-object-format']).decode().strip();need(head_before=='460bfa5d06044716a43997f829c41df9817cc9b8','unexpected precommit HEAD; do not relabel newcommit')
index_path=Path(command('index-path-main',['rev-parse','--path-format=absolute','--git-path','index']).decode().strip());index_before_sha=sha(index_path)
main_paths=sorted(p for p in selected if not p.startswith('external/')and not p.startswith(fixture_rel+'/'));pathspecs=main_paths+[fixture_rel,'external/pkl','external/pkl-pantry'];main_raw=command('ls-stage-main-before',['ls-files','--stage','-z','--',*pathspecs]);main_entries=parse_stage(main_raw)
expected_main={p for p in selected if not p.startswith('external/')};need(set(main_entries)==expected_main|{'external/pkl','external/pkl-pantry'},'narrow staged path coverage differs');need({p for p in main_entries if p.startswith(fixture_rel+'/')}=={fixture_rel+'/'+p for p in actual_fixture},'staged fixture coverage differs')
refs={line.split('=',1)[0]:line.split('=',1)[1]for line in(R/'references.lock').read_text().splitlines()if line and not line.startswith('#')};gitlinks={}
for path,pin in [('external/pkl',refs['pkl.revision']),('external/pkl-pantry',refs['pkl-pantry.revision'])]:
 row=main_entries[path];need(row['mode']=='160000'and row['oid']==pin,'staged reference gitlink differs');gitlinks[path]=row
external_paths=sorted(p.removeprefix('external/pkl/')for p in selected if p.startswith('external/pkl/'));need(len(external_paths)==21 and all(not p.startswith('external/')or p.startswith('external/pkl/')for p in selected),'unexpected external source scope')
repo_external=R/'external/pkl';format_external=command('object-format-pkl',['rev-parse','--show-object-format'],repo_external).decode().strip();sub_raw=command('ls-stage-pkl-before',['ls-files','--stage','-z','--',*external_paths],repo_external);sub_entries=parse_stage(sub_raw)
need(set(sub_entries)==set(external_paths),'submodule staged coverage differs');tree_raw=command('ls-tree-pkl-gitlink',['ls-tree','-r','-z',gitlinks['external/pkl']['oid'],'--',*external_paths],repo_external);tree={}
for raw in tree_raw.split(b'\0'):
 if not raw:continue
 header,path=raw.split(b'\t',1);mode,kind,oid=header.decode().split();need(kind=='blob','unexpected submodule tree kind');tree[path.decode()]={'mode':mode,'oid':oid}
need(set(tree)==set(sub_entries)and all(tree[p]['mode']==sub_entries[p]['mode']and tree[p]['oid']==sub_entries[p]['oid']for p in tree),'submodule staged blobs differ from main staged gitlink tree')
bindings={};objects=[]
def batch(label,repo,entries,path_prefix,object_format):
 groups=collections.defaultdict(list)
 for rel,row in entries.items():
  if row['mode']=='160000':continue
  full=path_prefix+rel;need(full in selected,'unexpected selected blob');groups[row['oid']].append((full,row))
 argv=[str(GIT),'-c','gc.auto=0','cat-file','--batch'];meta={'argv':argv,'cwd':str(repo),'parentPid':os.getpid(),'startedUtc':now(),'transport':'One OID written/flushed, then complete header/payload/newline read before next request. Stderr goes to a regular file; no bulk-input/output pipe cycle.'};requests=O/(label+'.stdin.bin');response=O/(label+'.stdout.bin')
 with requests.open('wb')as written,response.open('wb')as captured,(O/(label+'.stderr.bin')).open('wb')as err:
  child=subprocess.Popen(argv,cwd=repo,env=ENV,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,bufsize=0);meta['pid']=child.pid;save(O/(label+'.launch.json'),meta)
  try:
   for oid,members in sorted(groups.items()):
    request=oid.encode()+b'\n';written.write(request);child.stdin.write(request);child.stdin.flush();offset=captured.tell();header=child.stdout.readline();captured.write(header);parts=header.decode('ascii').rstrip('\n').split();need(len(parts)==3 and parts[0]==oid and parts[1]=='blob','unexpected cat-file response');size=int(parts[2]);data=bytearray();left=size
    while left:
     chunk=child.stdout.read(min(1024*1024,left));need(bool(chunk),'truncated Git blob');captured.write(chunk);data.extend(chunk);left-=len(chunk)
    end=child.stdout.read(1);captured.write(end);need(end==b'\n','cat-file framing differs');payload=bytes(data);h=hashlib.sha256(payload).hexdigest();object_hash=(hashlib.sha1 if object_format=='sha1'else hashlib.sha256)(b'blob '+str(size).encode()+b'\0'+payload).hexdigest();need(object_hash==oid,'independent Git object hash differs')
    objects.append({'repository':'.'if not path_prefix else'external/pkl','oid':oid,'kind':'blob','bytes':size,'sha256':h,'gitObjectHashVerified':True,'rawStream':response.name,'rawHeaderOffset':offset,'rawPayloadOffset':offset+len(header),'rawPayloadBytes':size,'boundFiles':len(members)})
    for full,row in members:
     p=R/full;need(p.is_file()and not p.is_symlink(),'nonregular selected filesystem file');actual=p.read_bytes();need(actual==payload,'filesystem bytes differ from staged blob '+full);authority=selected[full];need(authority['expectedSha256']in [None,h]and authority['expectedBytes']in [None,size],'frozen proof/fixture bytes differ '+full);mode=stat.S_IMODE(p.stat().st_mode);need(bool(mode&0o111)==(row['mode']=='100755'),'Git executable mode differs '+full)
     source_equal=None
     if 'candidate04-declared-source'in authority['categories']:source_equal=(snapshot/full).read_bytes()==payload;need(source_equal,'frozen snapshot differs from staged blob '+full)
     bindings[full]={'repository':'.'if not path_prefix else'external/pkl','repositoryRelative':full if not path_prefix else full.removeprefix(path_prefix),'gitMode':row['mode'],'gitBlob':oid,'stage':0,'gitBlobObjectHashVerified':True,'gitBlobBytes':size,'gitBlobSha256':h,'filesystemSha256':hashlib.sha256(actual).hexdigest(),'filesystemBytes':len(actual),'filesystemMode':mode,'filesystemBytesEqualStagedBlob':True,'candidate04SnapshotBytesEqualStagedBlob':source_equal,'categories':authority['categories'],'submoduleMainStagedGitlink':None if not path_prefix else gitlinks['external/pkl']['oid']}
   child.stdin.close();tail=child.stdout.read();captured.write(tail);need(not tail,'unexpected cat-file trailing output');code=child.wait();need(code==0,'cat-file failed')
  except BaseException:
   child.kill();child.wait();raise
 meta.update(exitCode=code,finishedUtc=now(),stdinSha256=sha(requests),stdoutSha256=sha(response),stderrSha256=sha(O/(label+'.stderr.bin')),objects=len(groups));save(O/(label+'.terminal.json'),meta);commands.append(meta)
batch('cat-main',R,main_entries,'',format_main);batch('cat-pkl',repo_external,sub_entries,'external/pkl/',format_external);need(set(bindings)==set(selected),'binding file coverage differs')
main_after=command('ls-stage-main-after',['ls-files','--stage','-z','--',*pathspecs]);sub_after=command('ls-stage-pkl-after',['ls-files','--stage','-z','--',*external_paths],repo_external);need(main_after==main_raw and sub_after==sub_raw,'selected staged entries changed during binding');head_after=command('head-after',['rev-parse','HEAD']).decode().strip();need(head_after==head_before,'HEAD changed before commit binding');index_after_sha=sha(index_path)
changes=[]
for rel,row in bindings.items():
 p=R/rel
 if sha(p)!=row['filesystemSha256']or p.stat().st_size!=row['filesystemBytes']or stat.S_IMODE(p.stat().st_mode)!=row['filesystemMode']:changes.append(rel)
need(not changes,'selected filesystem files changed after binding');need(sha(proof_path)==sha(proof_path),'proof guard')
save(O/'file-bindings.json',bindings);save(O/'git-objects.json',objects)
report={'status':'CLOSED-read-only-staged-Git-blob-binding-not-a-commit','root':str(R),'sourceBuildProof':str(proof_path),'sourceBuildProofSha256':sha(proof_path),'candidate04DeclaredSources':437,'candidate04SourcesBound':sum('candidate04-declared-source'in x['categories']for x in bindings.values()),'fixturePayloads':75862,'fixtureManifestFiles':1,'fixtureTotalFilesBound':sum(any(c.startswith('fixture-')for c in x['categories'])for x in bindings.values()),'selectedUniqueFiles':len(bindings),'uniqueObjects':len(objects),'tests':tests,'tools':tools,'transitiveHelpers':helpers,'toolchainManifests':toolchain,'manifestSha256':sha(manifest),'allFilesystemBytesEqualStagedBlobs':True,'allGitObjectHashesIndependentlyVerified':True,'allCandidate04FrozenSnapshotBytesEqualStagedBlobs':True,'selectedIndexEntriesStable':True,'filesystemChanges':changes,'gitlinks':gitlinks,'submoduleStagedBlobsMatchMainStagedGitlinkTree':True,'headBefore':head_before,'headAfter':head_after,'newCommitExistsOrBound':False,'stagedIndexPath':str(index_path),'wholeIndexSha256Before':index_before_sha,'wholeIndexSha256After':index_after_sha,'wholeIndexHashStable':index_before_sha==index_after_sha,'gitExecutable':str(GIT),'gitExecutableSha256':sha(GIT),'gitVersion':version,'gitExecPath':exec_path,'python':sys.version,'platform':platform.platform(),'commands':commands,'fileBindingsSha256':sha(O/'file-bindings.json'),'gitObjectReadbackSha256':sha(O/'git-objects.json'),'excludedDocs':['PLAN.md','docs/**'],'historicalCandidateSourcesBound':False,'gitIndexWrites':False,'engineExecutions':0,'scopeQualification':'Only staged blob identities are bound. Main current HEAD460bfa5 is an observed base, not a claim that these staged bytes belong to that commit. Root must join the same paths/OIDs to the future commit after commit creation. External21 files are submodule staged blobs also verified at the main staged gitlink commit.'};save(O/'report.json',report);print(json.dumps({k:report[k]for k in ['status','selectedUniqueFiles','candidate04SourcesBound','fixtureTotalFilesBound','uniqueObjects','allFilesystemBytesEqualStagedBlobs','selectedIndexEntriesStable','filesystemChanges','headBefore','newCommitExistsOrBound']}),flush=True)
