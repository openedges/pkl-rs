# Candidate04 staged source and fixture binding

This archive preserves the closed read-only index binding evidence: original table, Git commands/runtime/PIDs, source scripts, proof post-guard, raw blob streams and exact offsets. It covers all 437 declared candidate04 source paths, 75,863 fixture files and execution tools/helpers/manifests/four tests, with 76,302 distinct paths and 3,053 unique blobs. External21 files are submodule staged blobs also verified at the main staged gitlink tree.

These are staged blob bytes. Observed HEAD460bfa5 is a base marker; no new commit or historical candidate equivalence is asserted. Root must join the same paths/modes/OIDs to the final commit. PLAN/docs are excluded from artifact binding. The original target-only trailing self-comparison is not relied on: its independent proof post-guard is preserved.

All original audit files remain unchanged. Packaging separately reconstructs every raw object header/offset/request/body, verifies SHA1 and SHA256, and joins every binding row and all437 proof rows. No Git or evaluator command is reexecuted during packaging. The archive receives separate evidence verification and complete raw-member readback. Its own packaging receipts are finalized outside itself to avoid recursive self inclusion.
