from pathlib import Path
import json,hashlib,sys,os
from concurrent.futures import ThreadPoolExecutor
R=Path.cwd();O=R/'target/m2/stage38-default-host-oracle-01';D=O/'additional-empty-profile';D.mkdir();sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n');meta=json.loads((O/'oracle.json').read_bytes());env=json.loads((O/'environment.json').read_bytes());manifest=json.loads((O/'manifest.json').read_bytes());base=json.loads((O/'cases'/manifest[0]['id']/'0/record.json').read_bytes())['process']['command'];base=base[:base.index('Stage38DefaultHostProbe')];uri=manifest[0]['module_uri'];cases=[]
for name,operand in [('env-path','env:PATH'),('env-home','env:HOME'),('prop-user-home','prop:user.home'),('prop-java-version','prop:java.version')]:
 for nullable in [False,True]:
  cases.append(dict(id=name+('-nullable' if nullable else ''),source='result=read'+('?' if nullable else '')+'('+json.dumps(operand)+')\n',module_uri=uri,expression='result',scope='Known host/JVM keys must be absent under explicit empty builder maps'))
value=(O/'fixtures/base dir/data/value.txt').as_uri().replace('/data/value.txt','/data/%2E%2E/data/value.txt')
for field in ['uri','text']:cases.append(dict(id='file-encoded-dot-'+field,source='result=read('+json.dumps(value)+').'+field+'\n',module_uri=uri,expression='result',scope='Encoded dot path is preserved in resource URI, controlled filesystem lookup only'))
write(D/'manifest.json',cases)
for c in cases:
 d=D/'cases'/c['id'];d.mkdir(parents=True);(d/'input.pkl').write_bytes(c['source'].encode());write(d/'source-contract.json',c)
def run(pair):
 c,n=pair;d=D/'cases'/c['id']/str(n);d.mkdir();cmd=[*base,'Stage38DefaultHostProbe',str(d),str(d.parent/'input.pkl'),c['module_uri'],c['expression']];rec=benchmark.capture(cmd,R,env,d/'process',timeout=90);channels={p:sha(d/p) for p in ['status.bin','module-uri.bin','source.code-units.bin','value.code-units.bin','error.code-units.bin'] if (d/p).exists()};row=dict(id=c['id'],repeat=n,process=rec,channels_sha256=channels);write(d/'record.json',row);return row
with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(run,[(c,n) for c in cases for n in [0,1]]))
stable=True
for c in cases:
 a,b=[r for r in rows if r['id']==c['id']];stable &= a['channels_sha256']==b['channels_sha256'] and all(a['process'][k]['sha256']==b['process'][k]['sha256'] for k in ['stdout','stderr']) and a['process']['exit_code']==b['process']['exit_code']
write(D/'report.json',dict(scope='Additive Java-only default empty env/property known-key and controlled encoded-dot file controls. Base53 capture unchanged.',case_count=len(cases),repetitions=2,results=rows,repeat_raw_stability=stable,base_report_sha256=sha(O/'report.json'),helper_sha256=sha(O/'Stage38DefaultHostProbe.java'),driver_sha256=sha(O/'additional.py')));print('additional',len(cases),'cases',len(rows),'processes','stable',stable)
