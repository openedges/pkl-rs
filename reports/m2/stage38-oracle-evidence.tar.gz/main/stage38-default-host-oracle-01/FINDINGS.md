# Default scalar Host policy observations

This is Java-only evidence against pinned Pkl 0.32.0. It does not establish Rust compatibility, a completed resource loader, or complete M4 behavior. No tracked source was changed.

The acquisition contains 65 source/URI/expression contracts, each evaluated in two fresh Java processes: 53 initial controls, 10 additive empty-profile/file controls, and two exact prior scalar controls. All 130 evaluations are terminal. There are 40 values and 90 ordinary `PklException` outcomes, with no Java internal errors, timeouts, or missing captures. Status, complete stdout/stderr, module URI, source code units and returned value/error code units match exactly between repeats. `audit-report.json` binds the inputs, driver/helper, compiled class, pinned JAR and JDK identity.

The helper uses the same scalar builder settings as `tools/java/M2LanguageProbe.java`: `EvaluatorBuilder.preconfigured()`, no module cache, color/power assertions disabled, and explicit empty environment/external-property maps. Every contract records its exact `ModuleSource.create(uri, source)` pair. File reads use controlled fixtures under this evidence directory; the inline module source intentionally differs from the controlled resource bytes at its URI. Java process home/temp paths are confined to this directory.

## Observed results

| Controls | Verified behavior |
| --- | --- |
| `life-opaque`, `life-upper`, `life-mixed`, `http-denied`, `http-uppercase`, `env-uppercase`, `env-prefix-boundary` | Unknown/denied schemes receive the complete resource-allowlist diagnostic, including uppercase variants. `http` is denied by the default resource policy. |
| `life-hierarchical-normalized`, `life-opaque-not-normalized`, `life-encoded-dot` | `life:/a/../text` is diagnosed as `life:/text`; opaque `life:a/../text` is unchanged; `%2E%2E` remains encoded rather than becoming `..`. |
| `malformed-space`, `malformed-percent`, `malformed-leading-digit`, `empty-env-ssp`, `empty-life-ssp` | URI syntax errors precede allowlist refusal. Empty `env:` and `life:` report “Expected scheme-specific part.” |
| `backslash-after-colon` | The authored backslash operand becomes URI text `life:%5Ctext` in the allowlist diagnostic. This must not be inferred to be a normal relative file request. |
| `uri-unpaired-surrogate` | Java accepts the URI string far enough to produce an allowlist refusal containing the actual `D800` code unit. Java's UTF-8 output uses `?`; `error.code-units.bin` preserves `D800` losslessly. This is a distinct input/transport boundary, not an equivalent replacement string. |
| Missing `env:` / `prop:` controls and their nullable counterparts | `read` reports the original missing resource; `read?` returns `null`. `read?` still raises denied-policy and malformed-URI errors. |
| Additive `env-path`, `env-home`, `prop-user-home`, `prop-java-version` and nullable counterparts | These known process/JVM keys are absent because the explicit empty maps replace the builder's values. Nullable reads return `null`. |
| Controlled absolute/relative file controls | Resource text preserves CRLF and non-ASCII bytes. Relative `..`/`.` paths resolve against the exact module URI. `Resource.uri` reports the normalized resolved URI. Missing local files return `null` only through `read?`. |
| `file-relative-space`, `file-relative-literal-percent`, `file-absolute-encoded-space` | Relative path text containing a space selects `a b.txt`; relative `a%20b.txt` selects the literal-percent filename; an absolute file URI with `%20` selects the space filename. Raw URI parsing cannot be substituted for the path-escaping branch. |
| Additive `file-encoded-dot-uri`, `file-encoded-dot-text` | The reported resource URI retains encoded `%2E%2E`, while the controlled filesystem lookup reaches the same data bytes. URI normalization and filesystem resolution are distinct operations. |
| `read-type-before-uri`, `read-null-type-before-uri`, `operand-throw-before-uri` | Operand evaluation/type failure occurs before resource-policy handling. |

## Diagnostic provenance

The ordinary `result=obj.x` control includes the actual `obj.x` read frame, the `result=obj.x` caller, and the REPL expression frame. No-op `trace(obj)` and strict `trace(List(obj))` forcing expose the `obj.x` read frame and REPL expression frame, omitting the outer result/trace callsite. Nested forcing names the actual `obj.child.x` member. The complete diagnostic bytes are retained; no frames are appended or removed by this acquisition.

The two controls under `prior-exact-controls` copy the original Stage37 source bytes and use `file:///m2-platform.pkl`. Their complete stdout/stderr equal the earlier pinned fixed-URI Java captures. The initial newly authored forcing controls include different unused outer expression text; they remain separate contracts even where their rendered errors coincide. The initial audit's incorrect source-equality assertion is preserved in `initial-audit.*`; neither acquisition was altered to satisfy it.

## Pinned source ordering

The source snapshots support the observed order:

1. `EvaluatorBuilder.java:105` installs the preconfigured readers and default policies. `SecurityManagers.java:56` permits the case-sensitive resource prefixes `prop:`, `env:`, `file:`, `modulepath:`, `package:`, `projectpackage:`, and `https:`. `checkRead` at line208 uses `Pattern.lookingAt()`.
2. `AbstractReadNode.java:42` parses with `IoUtils.toUri`, resolves against the declaration's module key, then calls `ResourceManager`.
3. `IoUtils.java:118` distinguishes URI-like strings from escaped path strings. Its parser/escaping behavior cannot be replaced by a raw textual prefix test.
4. `ResourceManager.java:98` normalizes the URI and checks the resource policy before reporting an absent reader. HTTP/HTTPS readers defer the check to their HTTP client.
5. `ResourceReaders.java:349` provides the policy checker to the HTTP client. `RequestRewritingClient.java:116` calls that checker before delegating a send. The valid HTTP controls therefore fail before transport. No allowed HTTPS URI was evaluated; no packet trace or transport interception is claimed.
6. `ReadNode.java:33` turns an absent result into `cannotFindResource`; `ReadOrNullNode.java:33` turns only an absent result into null. URI/policy exceptions are not suppressed.

## Design implications and limits

A shared default scalar Host policy needs URI parsing, path escaping, module-relative resolution and normalization before reader-policy decisions. Those are prerequisites, not a scheme-name fixture table. The existing shared VM's ordinary failed-read completion path can carry the original read location through trace forcing; A's separate completion-path proof supplies the native evidence for that mechanism, while this directory supplies Java policy outcomes.

No Rust evaluator was executed here. Native `read?` syntax is an explicit dependency until implemented and independently compared. This acquisition does not cover allowed HTTP/HTTPS transport, redirects, package/modulepath behavior, project dependencies, globs, binary decoding failures, resource-cache mutation/reentry, symlinks/root directories, generic module loading, or full Java Evaluator API equivalence. Those remain separate work.
