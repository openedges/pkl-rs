from pathlib import Path
import json,hashlib,sys,collections
R=Path.cwd();O=R/'target/m2/stage38-default-host-oracle-01';W=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage37');sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes());base=rd(O/'report.json');extra=rd(O/'additional-empty-profile/report.json');meta=rd(O/'oracle.json');counts=collections.Counter();records=[];surrogate_count=0
assert base['repeat_raw_stability'] and base['source_stability'] and extra['repeat_raw_stability'] and extra['base_report_sha256']==sha(O/'report.json')
assert base['helper_sha256']==extra['helper_sha256']==sha(O/'Stage38DefaultHostProbe.java') and base['driver_sha256']==sha(O/'run.py') and extra['driver_sha256']==sha(O/'additional.py')
for rel,h in base['sources'].items():assert sha(R/rel)==h==sha(O/'sources'/rel)
for rel,h in base['controlled_fixture_sha256'].items():assert sha(O/rel)==h
assert sha(Path(meta['artifact']))==meta['artifact_sha256']==base['jar_sha256']
assert sha(Path(meta['java']))==meta['jdk']['executable_sha256'];jdk=Path(meta['jdk']['properties']['java.home']);assert sha(jdk/'lib/modules')==meta['jdk']['runtime_modules_sha256'] and sha(jdk/'release')==meta['jdk']['release_sha256']
for rec in [base['java_identity'],base['java_version'],base['compile']]:
 assert rec['status']=='executed' and rec['exit_code']==0
 for channel in ['stdout','stderr']:benchmark.raw_channel(rec,channel)
for root,report in [(O,base),(O/'additional-empty-profile',extra)]:
 manifest=rd(root/'manifest.json');assert len(manifest)==report['case_count'] and len(report['results'])==2*len(manifest);pairs=set()
 for row in report['results']:
  key=(row['id'],row['repeat']);assert key not in pairs;pairs.add(key);c=next(c for c in manifest if c['id']==row['id']);d=root/'cases'/row['id']/str(row['repeat']);assert rd(d/'record.json')==row
  source=(d.parent/'input.pkl').read_bytes();assert source==c['source'].encode('utf-8') and (d/'source.code-units.bin').read_bytes()==c['source'].encode('utf-16-be') and (d/'module-uri.bin').read_bytes()==c['module_uri'].encode()
  for name,h in row['channels_sha256'].items():assert sha(d/name)==h
  rec=row['process'];assert rec['status']=='executed' and rec['exit_code'] in [0,1];out=benchmark.raw_channel(rec,'stdout');err=benchmark.raw_channel(rec,'stderr');status=(d/'status.bin').read_bytes()
  if status==b'success\n':assert rec['exit_code']==0 and not err;counts['value']+=1
  else:assert status==b'pkl-exception\torg.pkl.core.PklException\n' and rec['exit_code']==1 and not out;counts['language-error']+=1
  for channel,raw in [('value',out),('error',err)]:
   units=(d/(channel+'.code-units.bin')).read_bytes();text=units.decode('utf-16-be','surrogatepass');assert text.encode('utf-8','replace')==raw
   if row['id']=='uri-unpaired-surrogate' and channel=='error':assert '\ud800' in text and b'life:?' in raw;surrogate_count+=1
  records.append({'id':row['id'],'repeat':row['repeat'],'status_sha256':sha(d/'status.bin'),'stdout_sha256':hashlib.sha256(out).hexdigest(),'stderr_sha256':hashlib.sha256(err).hexdigest()})
 assert pairs=={(c['id'],n) for c in manifest for n in [0,1]}
 for c in manifest:
  d=root/'cases'/c['id'];assert all((d/'0'/name).read_bytes()==(d/'1'/name).read_bytes() for name in ['status.bin','module-uri.bin','source.code-units.bin','value.code-units.bin','error.code-units.bin','process/stdout.bin','process/stderr.bin'])
# Exact previously observed source/URI controls bind to independent fresh captures.
for fresh,old in [('noop-trace-object-frame','trace-stage37-noop-force-read'),('noop-trace-strict-list-frame','trace-stage37-strict-list-force')]:
 d=O/'cases'/fresh/'0';prior=W/'target/m2/stage37-selected-oracle-01/cases'/old
 assert (d.parent/'input.pkl').read_bytes()==(prior/'input.pkl').read_bytes()
 assert (d/'process/stderr.bin').read_bytes()==(prior/'java-fixed.stderr.bin').read_bytes()
 assert (d/'process/stdout.bin').read_bytes()==(prior/'java-fixed.stdout.bin').read_bytes()
assert surrogate_count==2 and counts=={'language-error':86,'value':40}
report={'scope':'Java-only63 source cases/126 fresh evaluations, raw bytes and UTF16 snapshots independently audited. This is no Rust compatibility result or complete M4 claim.','passed':True,'base_report_sha256':sha(O/'report.json'),'additional_report_sha256':sha(O/'additional-empty-profile/report.json'),'case_count':63,'process_count':126,'outcomes':dict(counts),'repeat_raw_stability':True,'source_stability':True,'jar_sha256':meta['artifact_sha256'],'jdk_executable_sha256':meta['jdk']['executable_sha256'],'jdk_runtime_modules_sha256':meta['jdk']['runtime_modules_sha256'],'classes_sha256':{str(p.relative_to(O)):sha(p) for p in (O/'classes').glob('*.class')},'lossless_unpaired_surrogate_error_snapshots':surrogate_count,'fresh_trace_controls_exact_previous_java_raw':True,'process_channel_sha256':records,'script_sha256':sha(Path(__file__))}
benchmark.write_json(O/'audit-report.json',report);print('Java-only audit passed',dict(counts))
