# Stage38 기본 resource Host 설계 초안

## 현재 확인한 문제

`evaluation::poll`은 `VmPoll::Pending`에서 VM을 취소하고 위치 없는 Unsupported 오류를 만든다. 이 때문에 기본 Java evaluator가 `life:text`를 resource allowlist에서 거부하는 두 실제 trace 소스가 불일치한다. trace 강제 평가 자체는 정상이며, 올바른 실패 결과를 기존 `Vm::resume`으로 전달하면 `obj.x`와 REPL 프레임이 모두 복원된다. 동결된 release rlib를 사용한 target 전용 실험은 두 원본 stdout/stderr 전체 바이트 일치를 확인했다. 이 실험은 policy 구현이나 새 호환성 통과가 아니다.

증거는 `target/m2/stage37-default-resource-review-01/resume-proof.json`에 있다. Stage37 최종 실제 Host 42개 비교는 별도 계약이며, 이 scalar 기본 Host 불일치를 해소했다고 주장하지 않는다. MAIN 및 이전 worktree의 생산 소스는 변경하지 않았다.

## Java의 처리 순서

1. `AbstractReadNode`가 authored 문자열을 `IoUtils.toUri`로 파싱한다. `uriLike` 정규식에 맞지 않는 문자열은 상대 경로로 escape한다.
2. 현재 표현식의 선언 모듈 `ModuleKey`를 기준으로 URI를 해석한다. 단순히 evaluator의 최초 URI나 현재 receiver를 기준으로 삼으면 향후 외부 모듈 함수에서 틀린다.
3. `ResourceManager.read`가 URI를 정규화하고 resource cache를 조회한다.
4. 기본 policy가 `prop:`, `env:`, `file:`, `modulepath:`, `package:`, `projectpackage:`, `https:`를 대소문자 구분 prefix로 허용한다. reader가 등록되지 않았더라도 policy 거부가 먼저다. HTTP/HTTPS reader는 HttpClient에 policy 검사를 위임한다.
5. 허용된 reader를 실행하고, 실패는 원래 `ReadNode` 위치에 연결한다. nullable read는 찾지 못한 결과에만 적용되며 policy 거부를 숨겨서는 안 된다.

기준 소스는 `SecurityManagers.java`, `ResourceManager.java`, `AbstractReadNode.java`, `IoUtils.java`, `errorMessages.properties`이다. C가 `target/m2/stage38-default-host-oracle-01`에 수집한 65개 계약 × 2회 실행이 종료되었다. 90개 일반 언어 오류와 40개 값이 기록되었으며, 전체 바이트와 UTF-16 snapshot의 반복 안정성이 확인되었다. Java 내부 오류나 시간 초과는 없고, Rust 호환성 결과로 취급하지 않는다.

## 구현 경계

- 공유 Host 계층에 기본 resource policy를 둔다. native/Wasm/NAPI adapter에 Java 오류 문자열이나 URI 판정 로직을 복제하지 않는다.
- URI 파싱/해석/정규화와 policy 판정을 분리한다. 파싱에 실패했거나 아직 지원하지 않는 상대/복합 URI를 무조건 allowlist 거부로 바꾸지 않는다. Java URI와 다른 WHATWG URL 규칙을 암묵적으로 채택하지 않는다.
- policy 입력은 검증된 URI이어야 한다. 일반화된 URI 선행 처리가 필요하면 별도 공유 타입으로 구현하며 authored 표현과 정규화된 표현을 구분한다. 해석 모듈의 URI는 실행 문맥의 실제 소스 메타데이터에서 얻는다.
- scalar 경계는 policy 결과를 `Vm::resume(request.id, Err(error))`에 전달한 뒤 정상 poll을 계속한다. 현재의 cancel 후 새 오류 생성 경로를 제거하여 기존 frame 수집, lazy attempt 정리, trace force mark 정리가 작동하게 한다.
- 명시적으로 설정된 Host reader의 URI/응답 계약을 보존한다. 기본 Java policy를 모든 custom Host에 몰래 적용하지 않는다.
- 허용된 파일/네트워크/package I/O, 설정 가능한 security manager, module loader, resource cache, TestRunner 등의 미완료 범위는 별도로 남긴다. 허용됨과 실제 reader가 구현됨은 다른 사실이다. scalar adapter의 빈 env/prop 설정도 Java helper의 명시적 구성에 근거해야 한다.

예상 내부 인터페이스의 역할은 다음과 같다. 이름과 공개 여부는 실제 구현 시 소유자와 확정한다.

```rust
// URI 처리는 공유 엔진/Host 계층에 위치한다.
fn parse_resource_uri(authored: &PklString) -> Result<ResourceUri, RuntimeError>;
fn resolve_resource_uri(uri: ResourceUri, module: &ModuleUri)
    -> Result<ResolvedResourceUri, RuntimeError>;
fn authorize_preconfigured_resource(uri: &ResolvedResourceUri)
    -> Result<(), RuntimeError>;
```

`ReadRequest.uri`는 현재 UTF-8 문자열이고 URI 파서가 없다. unmatched UTF-16 URI, malformed percent escape, authority/IPv6, 상대 경로, encoded dot segment, Java의 opaque/hierarchical 구분을 검증 없이 처리했다고 선언하지 않는다. matrix가 확인한 단순 사례에만 맞춘 문자열 분기는 피하고, 일반적인 표현에 적용되는 URI 규칙과 명시적 미지원 경계를 구현한다.

## 소유권과 검증

A는 공유 Host policy/URI primitive, 필요한 VM request provenance와 회귀 테스트를 담당하는 구성이 적절하다. C는 shared `evaluation::poll`의 completion 연결 및 기본 scalar 경계 테스트를 담당할 수 있다. B/root가 원본 fixture, oracle 기대값, 선택 목록과 최종 harness를 소유한다. 생산 구현은 root가 제공할 별도 checkout에서 시작한다.

필수 검증은 다음과 같다.

- 원본 두 trace fixture를 변경하지 않고 native/Node/browser 전체 raw 진단을 비교한다.
- 임의의 알려지지 않은 scheme, prefix 대소문자, malformed URI의 우선순위, opaque와 hierarchical 정규화, 상대 경로 escaping, 빈 env/prop, nullable read를 Java로 확인한다.
- 직접 read, trace 객체 강제 평가, strict collection 내부 read, method/중첩 property의 전체 프레임을 비교한다.
- reader 실패 후 같은 evaluator 재시도에서 초기화/멤버 cache와 force mark의 소유권이 유지되는지 검사한다. 성공한 callback cache를 이전 실패 시도가 제거해서는 안 된다.
- configured custom reader의 실제 suspend/reentry/GC/cancel/close 계약은 기존 42개 실제 Host 원본으로 보존한다.
- 기본 policy 판정에서 외부 네트워크나 파일 I/O를 사용하지 않는다. 허용된 I/O가 미구현이면 그 실패를 숨기지 않는다.
- 이전 Stage37 전체 결과는 동결된 역사적 증거로 유지하고, 새 후보는 새 디렉터리에서 재검증한다. Java 내부 오류는 통과로 계산하지 않는다.

## 닫힌 Java matrix로 확정한 요구

- 거부 진단은 정규화된 URI를 표시한다. `life:/a/../text`는 `life:/text`가 되지만 opaque URI와 encoded `%2E%2E`는 그대로다. 반면 `cannotFindResource`는 authored 문자열을 사용한다. 두 표현을 동일 필드로 덮어쓰면 안 된다.
- `env:`와 `life:`는 scheme-specific part가 없다는 구문 오류다. malformed space/percent/leading-digit도 policy보다 먼저 실패한다. backslash-after-colon은 Java의 path escaping을 거쳐 `life:%5Ctext` 거부가 된다.
- 상대 `a%20b.txt`는 percent가 실제 파일 이름인 경로를 가리키고, 절대 URI의 `%20`는 공백 파일을 가리킨다. URI 정규화는 encoded dot을 보존하지만 파일 경로 해석은 별도 동작이다. 이 둘을 하나의 URL 정규화로 대체하지 않는다.
- 빈 env/prop 설정은 실제 프로세스의 PATH/HOME 또는 JVM property를 노출하지 않는다. `read?`는 missing 결과에만 null을 반환하며 denied/malformed 오류는 전파한다. 현재 frontend의 `read?` 미지원은 구현 범위 결정 시 명시해야 한다.
- unmatched `D800`은 Java 거부 메시지에 실제 UTF-16 unit으로 남는다. Java UTF-8 출력의 `?`와 lossless snapshot은 별개다. 현재 UTF-8 기반 ReadRequest/RuntimeError-message 경계를 지원했다고 주장하지 않으며, 해당 원본을 유지한다.
- 일반 property read는 실제 read 프레임, caller, REPL 프레임을 보인다. trace/strict collection forcing에서는 실제 read 프레임과 REPL만 보이며 nested forcing은 실제 자식 멤버 이름을 사용한다. 기존 VM completion으로 두 원본 진단 바이트가 일치하므로 별도 frame 합성은 불필요하다.

이 계획은 구현 시작 전 설계 체크포인트이다. 기존 Stage37 증거/소스는 수정하지 않으며, 다음 checkout에서 원본 사례를 유지한 채 구현과 검증 범위를 root와 확정한다.
