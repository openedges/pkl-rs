from pathlib import Path
import json,os,hashlib,sys,shutil,collections
from concurrent.futures import ThreadPoolExecutor
R=Path.cwd();O=R/'target/m2/stage38-review-uri-edges-01';ORIGIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage38-default-host-oracle-01');sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes());write=lambda p,x:benchmark.write_json(p,x);meta=rd(ORIGIN/'oracle.json');assert sha(Path(meta['artifact']))==meta['artifact_sha256']
for d in ['home','tmp','classes']:(O/d).mkdir()
env=dict(meta['environment']);env.update(HOME=str(O/'home'),TMPDIR=str(O/'tmp'),TMP=str(O/'tmp'),TEMP=str(O/'tmp'));base=list(meta['command'][:-1]);base=[('-Duser.home='+str(O/'home')) if x.startswith('-Duser.home=') else ('-Djava.io.tmpdir='+str(O/'tmp')) if x.startswith('-Djava.io.tmpdir=') else x for x in base];base[base.index('-cp')+1]=str(O/'classes')+os.pathsep+meta['artifact'];shutil.copyfile(ORIGIN/'Stage38DefaultHostProbe.java',O/'Stage38DefaultHostProbe.java');write(O/'oracle.json',meta);write(O/'environment.json',env)
compile=benchmark.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(O/'classes'),str(O/'Stage38DefaultHostProbe.java')],R,env,O/'javac',timeout=90);assert compile['exit_code']==0
rows=[('http-opaque','result=read("http:opaque")\n'),('http-invalid-host','result=read("http://bad_host/x")\n'),('http-nonnumeric-port','result=read("http://host:bad/x")\n'),('http-large-port','result=read("http://host:70000/x")\n'),('http-fragment','result=read("http://host/x#frag")\n'),('read-lazy-dynamic-type','result=read(new Dynamic { x=throw("lazy") })\n'),('read-list-type','result=read(List(1))\n')];manifest=[dict(id=n,source=s,module_uri='file:///stage38-uri-edges.pkl',expression='result') for n,s in rows];write(O/'manifest.json',manifest)
for c in manifest:
 d=O/'cases'/c['id'];d.mkdir(parents=True);(d/'input.pkl').write_bytes(c['source'].encode())
def run(pair):
 c,n=pair;d=O/'cases'/c['id']/str(n);d.mkdir();rec=benchmark.capture([*base,'Stage38DefaultHostProbe',str(d),str(d.parent/'input.pkl'),c['module_uri'],c['expression']],R,env,d/'process',timeout=90);status=(d/'status.bin').read_bytes() if (d/'status.bin').exists() else b'';kind='value' if status==b'success\n' else 'language-error' if status==b'pkl-exception\torg.pkl.core.PklException\n' else 'oracle-error';r=dict(id=c['id'],repeat=n,classification=kind,process=rec,channels_sha256={p:sha(d/p) for p in ['status.bin','module-uri.bin','source.code-units.bin','value.code-units.bin','error.code-units.bin'] if (d/p).exists()});write(d/'record.json',r);return r
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,[(c,n) for c in manifest for n in [0,1]]))
stable=True
for c in manifest:
 a,b=[r for r in results if r['id']==c['id']];stable &= a['channels_sha256']==b['channels_sha256'] and all(a['process'][k]['sha256']==b['process'][k]['sha256'] for k in ['stdout','stderr']) and a['process']['exit_code']==b['process']['exit_code']
write(O/'report.json',dict(scope='Additional actual-source Java HTTP request-construction/denial ordering and read operand type controls. Java internal errors stay oracle-errors, not compatibility passes. No original65 rerun or Rust compatibility claim.',results=results,case_count=7,repetitions=2,status_counts=dict(collections.Counter(r['classification'] for r in results)),repeat_raw_stability=stable,helper_sha256=sha(O/'Stage38DefaultHostProbe.java'),driver_sha256=sha(O/'run.py'),jar_sha256=sha(Path(meta['artifact'])),compile=compile,network_scope='All HTTP is default-disallowed; invalid request construction can fail first. No allowed network request or HTTPS URL.'))
print('terminal',collections.Counter(r['classification'] for r in results),'stable',stable)
for c in manifest:
 d=O/'cases'/c['id']/'0';print(c['id'],(d/'status.bin').read_bytes(),benchmark.raw_channel(next(r['process'] for r in results if r['id']==c['id'] and r['repeat']==0),'stderr').decode()[:500])
