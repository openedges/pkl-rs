# Additional Java HTTP and operand controls

These seven fresh source contracts extend the independent Stage38 design review. They do not replace or rerun the closed 65-case matrix. Fourteen fresh Java processes preserve both raw repeats, exact `ModuleSource` source/URI, outcome class, complete output/error bytes and UTF-16 snapshots.

| Source operand | Observed Java outcome |
| --- | --- |
| `read("http:opaque")` | `PklBugException`: `IllegalArgumentException` for unsupported URI, before resource-allowlist refusal. |
| `read("http://bad_host/x")` | Same internal-error boundary: Java URI has registry-style authority rather than a usable HTTP host. |
| `read("http://host:bad/x")` | Same internal-error boundary for a nonnumeric port. |
| `read("http://host:70000/x")` | Ordinary complete allowlist refusal. The request constructor does not reject this port before the policy check. |
| `read("http://host/x#frag")` | Ordinary complete allowlist refusal preserving the fragment in the displayed URI. |
| `read(new Dynamic { x=throw("lazy") })` | Ordinary `read` operand-type error, `Operand: new Dynamic { x = ? }`; the lazy member is not forced by this diagnostic display. |
| `read(List(1))` | Ordinary `read` operand-type error, `Operand: List(1)`. |

There are eight ordinary language-error evaluations and six Java internal-error evaluations. All raw repeats are identical. Internal errors remain oracle errors and are not passes or expected ordinary policy errors.

`ResourceReaders.UrlResource.read` constructs `HttpRequest` before passing the request to its policy-checking client. Therefore a generic `java.net.URI`-valid shape does not imply that default HTTP evaluation reaches allowlist checking. The implementation must not silently move policy ahead of this construction step. A bounded implementation can retain unsupported HTTP request shapes as explicit gaps rather than manufacture the Java internal-error output.

`UnaryExpressionNode.fallback` adds a `ProgramValue` named `Operand`. `VmException.ProgramValue.toString` uses `VmValueRenderer.singleLine(80)`, whose value traversal does not force members. These controls support the nonforcing Dynamic/List operand display; they do not complete diagnostic rendering with object-key hash callbacks or asynchronous Host operations.

No allowed network URL was evaluated. The invalid HTTP requests fail construction; the other HTTP requests are denied by the default policy before transport. No network packet trace is claimed. No Rust compatibility result follows from this Java-only directory.
