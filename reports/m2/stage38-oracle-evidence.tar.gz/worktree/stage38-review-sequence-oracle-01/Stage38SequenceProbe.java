import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.URI;
import java.util.Map;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
import org.pkl.core.PklException;
public final class Stage38SequenceProbe {
  static void units(Path path, String value) throws Exception {
    try (var out = new DataOutputStream(Files.newOutputStream(path))) {
      for (int i=0; i<value.length(); i++) out.writeChar(value.charAt(i));
    }
  }
  public static void main(String[] args) throws Exception {
    Path out=Path.of(args[0]);
    String source=Files.readString(Path.of(args[1]),StandardCharsets.UTF_8);
    var module=ModuleSource.create(URI.create(args[2]),source);
    var expressions=Files.readAllLines(Path.of(args[3]),StandardCharsets.UTF_8);
    try (var evaluator=EvaluatorBuilder.preconfigured().setModuleCacheDir(null)
        .setPowerAssertionsEnabled(false).setColor(false)
        .setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      for (int i=0;i<expressions.size();i++) {
        String prefix="call-"+i;
        try {
          String value=evaluator.evaluateExpressionString(module,expressions.get(i));
          Files.writeString(out.resolve(prefix+".status.bin"),"success\n",StandardCharsets.UTF_8);
          Files.write(out.resolve(prefix+".stdout.bin"),value.getBytes(StandardCharsets.UTF_8));
          Files.write(out.resolve(prefix+".stderr.bin"),new byte[0]);
          units(out.resolve(prefix+".value.code-units.bin"),value);
          units(out.resolve(prefix+".error.code-units.bin"),"");
          System.out.println("call="+i+" success");
        } catch (PklException error) {
          Files.writeString(out.resolve(prefix+".status.bin"),"pkl-exception\t"+error.getClass().getName()+"\n",StandardCharsets.UTF_8);
          Files.write(out.resolve(prefix+".stdout.bin"),new byte[0]);
          Files.write(out.resolve(prefix+".stderr.bin"),error.getMessage().getBytes(StandardCharsets.UTF_8));
          units(out.resolve(prefix+".value.code-units.bin"),"");
          units(out.resolve(prefix+".error.code-units.bin"),error.getMessage());
          System.out.println("call="+i+" error");
        }
      }
    }
  }
}
