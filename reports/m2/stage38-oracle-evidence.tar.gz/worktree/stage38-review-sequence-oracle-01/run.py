from pathlib import Path
import json,os,sys,hashlib
R=Path.cwd();O=R/'target/m2/stage38-review-sequence-oracle-01';ORIGIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage38-default-host-oracle-01');sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes());meta=rd(ORIGIN/'oracle.json')
for d in ['home','tmp','classes']:(O/d).mkdir()
source='first = read("life:unsupported")\nsecond = 42\n';uri='file:///m2-platform.pkl';expressions=['first','first','second','first'];(O/'input.pkl').write_bytes(source.encode());(O/'expressions.txt').write_text('\n'.join(expressions)+'\n');benchmark.write_json(O/'source-contract.json',dict(source=source,module_uri=uri,module_name='m2-platform',expressions=expressions));benchmark.write_json(O/'oracle.json',meta)
env=dict(meta['environment']);env.update(HOME=str(O/'home'),TMPDIR=str(O/'tmp'),TMP=str(O/'tmp'),TEMP=str(O/'tmp'));base=list(meta['command'][:-1]);base=[('-Duser.home='+str(O/'home')) if x.startswith('-Duser.home=') else ('-Djava.io.tmpdir='+str(O/'tmp')) if x.startswith('-Djava.io.tmpdir=') else x for x in base];base[base.index('-cp')+1]=str(O/'classes')+os.pathsep+meta['artifact'];compile=benchmark.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(O/'classes'),str(O/'Stage38SequenceProbe.java')],R,env,O/'javac',timeout=90);assert compile['exit_code']==0
records=[]
for repeat in [0,1]:
 d=O/str(repeat);d.mkdir();rec=benchmark.capture([*base,'Stage38SequenceProbe',str(d),str(O/'input.pkl'),uri,str(O/'expressions.txt')],R,env,d/'process',timeout=90);records.append(rec);assert rec['exit_code']==0 and not benchmark.raw_channel(rec,'stderr')
 for call in range(4):assert (d/f'call-{call}.status.bin').exists()
for p in (O/'0').glob('*.bin'):assert p.read_bytes()==(O/'1'/p.name).read_bytes()
assert (O/'0/call-2.stdout.bin').read_bytes()==b'42' and (O/'0/call-2.status.bin').read_bytes()==b'success\n'
assert all((O/'0'/f'call-{n}.stderr.bin').read_bytes()==(O/'0/call-0.stderr.bin').read_bytes() for n in [1,3])
benchmark.write_json(O/'report.json',dict(scope='Fresh actual-source Java persistent retry control for existing scalar sequence test. Same source/URI and evaluator preserved across4calls; no Rust result generation.',source_sha256=sha(O/'input.pkl'),module_uri=uri,expressions=expressions,helper_sha256=sha(O/'Stage38SequenceProbe.java'),driver_sha256=sha(O/'run.py'),jar_sha256=sha(Path(meta['artifact'])),compile=compile,processes=records,repeat_raw_stability=True,failed_calls=[0,1,3],successful_calls=[2],raw_sha256={str(p.relative_to(O)):sha(p) for folder in ['0','1'] for p in (O/folder).glob('*.bin')}));print('complete error:');print((O/'0/call-0.stderr.bin').read_bytes().decode());print('second42',repr((O/'0/call-2.stdout.bin').read_bytes()))
