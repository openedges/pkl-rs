from pathlib import Path
import json,os,hashlib,sys
from concurrent.futures import ThreadPoolExecutor
R=Path.cwd();O=R/'target/m2/stage38-method-diagnostic-oracle-01';sys.path.insert(0,str(R/'tools'));import benchmark
meta=json.loads(Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage37-trace-final-01/report.json').read_text())['oracle']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(meta['artifact']))==meta['artifact_sha256']
for d in ('home','tmp','classes','cases','sources'):(O/d).mkdir(exist_ok=True)
env=dict(meta['environment']);env.update(HOME=str(O/'home'),TMPDIR=str(O/'tmp'),TMP=str(O/'tmp'),TEMP=str(O/'tmp'))
base=list(meta['command'][:-1]);base=[('-Duser.home='+str(O/'home')) if s.startswith('-Duser.home=') else ('-Djava.io.tmpdir='+str(O/'tmp')) if s.startswith('-Djava.io.tmpdir=') else s for s in base];base[base.index('-cp')+1]=str(O/'classes')+os.pathsep+meta['artifact']
cases=[('implicit-empty', 'result=absent(throw("argument"))\n'), ('implicit-nonempty', 'function zeta(x,y)=x\nresult=absent(1)\n'), ('implicit-typo-method', 'function calculate(x)=x\nresult=calclate(1)\n'), ('implicit-typo-arity', 'function calculate(x)=x\nresult=calclate(1,2)\n'), ('implicit-property', 'value=1\nresult=value()\n'), ('implicit-local-method', 'local function calculate(x)=x\nresult=calclate(1)\n'), ('implicit-inherited-method', 'result=toStrng()\n'), ('implicit-class-method', 'class C {function nearby(x)=x; answer=nearb(1)}\nresult=new C {}.answer\n'), ('implicit-class-empty', 'class C {answer=absent(1)}\nresult=new C {}.answer\n'), ('explicit-module-empty', 'result=module.absent(1)\n'), ('explicit-module-nonempty', 'function zeta(x,y)=x\nresult=module.absent(1)\n'), ('implicit-base-constructor', 'result=Lits(1)\n')]
manifest=[{'id':i,'source':s,'expression':'result','uri':'file:///stage38-read-frontend.pkl'} for i,s in cases]
(O/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(O/'oracle.json').write_text(json.dumps(meta,indent=2)+'\n');(O/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
paths=['external/pkl/pkl-parser/src/main/java/org/pkl/parser/Lexer.java','external/pkl/pkl-parser/src/main/java/org/pkl/parser/ParserImpl.java','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/builder/AstBuilder.java','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ReadOrNullNode.java','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/unary/AbstractReadNode.java','references.lock','oracle.lock.json']
for p in paths:
 d=O/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((R/p).read_bytes())
javac=benchmark.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(O/'classes'),str(O/'Stage38DefaultHostProbe.java')],R,env,O/'javac',timeout=120);assert javac['exit_code']==0
for c in manifest:(O/'cases'/c['id']).mkdir();(O/'cases'/c['id']/'input.pkl').write_bytes(c['source'].encode())
def run(c):
 d=O/'cases'/c['id']/'java';d.mkdir();record=benchmark.capture([*base,'Stage38DefaultHostProbe',str(d),str(d.parent/'input.pkl'),c['uri'],c['expression']],R,env,d/'process',timeout=60)
 return {'id':c['id'],'process':record,'status':(d/'status.bin').read_text(),'files':{str(p.relative_to(O)):sha(p) for p in sorted(d.rglob('*')) if p.is_file()}}
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,manifest))
report={'scope':'Pinned Java-only frontend syntax/name/span controls; unchanged original65 remains separate. No Rust-derived expectations.','oracle_artifact_sha256':meta['artifact_sha256'],'helper_sha256':sha(O/'Stage38DefaultHostProbe.java'),'javac':javac,'cases':manifest,'results':results,'source_hashes':{p:sha(R/p) for p in paths}}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'count':len(results),'exit_codes':[r['process']['exit_code'] for r in results]}))
