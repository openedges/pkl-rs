from pathlib import Path
import json,hashlib,sys,collections
R=Path.cwd();O=R/'target/m2/stage38-platform-oracle-01';sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes());r=rd(O/'report.json');payload=rd(O/'fixed-payloads.json');rows=rd(O/'selected-rows.json');assert len(rows)==len(payload)==91 and len(r['results'])==182;assert r['status_counts']=={'language-error':144,'value':32,'oracle-error':6};assert r['repeat_raw_stability'] and r['source_stability'] and r['manifest_stability'];assert sha(O/'fixed-payloads.json')==r['payload_sha256'];assert sha(O/'run.py')==r['driver_sha256'] and sha(O/'Stage38PlatformProbe.java')==r['helper_sha256'];assert r['source_hashes_before']==r['source_hashes_after'];assert r['compile']['exit_code']==0
channels=0
for case,p in zip(rows,payload):
 assert case['id']==p['id'];d=O/'cases'/case['id'];assert sha(d/'input.pkl')==case['input_sha256']==p['sourceSha256'];assert (d/'input.pkl').read_bytes()==p['source'].encode();assert p['expression']==case['expression'] and p['powerAssertions']==case.get('power_assertions',False)
 a,b=[x for x in r['results'] if x['id']==case['id']];assert a['classification']==b['classification'];assert a['channels_sha256']==b['channels_sha256'];assert p['oracleError']==(a['classification']=='oracle-error');assert p['oracleClassification']==a['classification'];assert ('expectedValue' in p)!=('expectedError' in p)
 for rec in [a,b]:
  n=rec['repeat'];assert rd(d/str(n)/'record.json')==rec;assert rec['process']['status']=='executed' and rec['process']['exit_code'] in [0,1];assert rec['process']['command'][-3:]==['file:///m2-platform.pkl',case['expression'],str(case.get('power_assertions',False)).lower()]
  for ch in ['stdout','stderr']:benchmark.raw_channel(rec['process'],ch)
  for rel,h in rec['channels_sha256'].items():assert sha(d/str(n)/rel)==h;channels+=1
 expected=benchmark.raw_channel(a['process'],'stdout' if a['classification']=='value' else 'stderr');assert p.get('expectedValue',p.get('expectedError')).encode()==expected
 units=(d/'0'/('value.code-units.bin' if a['classification']=='value' else 'error.code-units.bin')).read_bytes();assert units.hex()==p['expectedCodeUnitsHex'];assert sha(d/'0/status.bin')==p['captureSha256']['status'];assert hashlib.sha256(units).hexdigest()==p['captureSha256']['payloadCodeUnits']
 for ch in ['stdout','stderr']:assert benchmark.raw_channel(a['process'],ch)==benchmark.raw_channel(b['process'],ch)
assert sum(p['powerAssertions'] for p in payload)==2;assert sum(p['oracleError'] for p in payload)==3
benchmark.write_json(O/'audit-report.json',dict(passed=True,scope='Independent source/URI/flags/full raw+UTF16/repeat/payload audit of91Java contracts. Three internal-error contracts explicitly retained.',report_sha256=sha(O/'report.json'),payload_sha256=sha(O/'fixed-payloads.json'),module_sha256=sha(R/'tools/platform/read-cases.mjs'),cases=91,processes=182,raw_files_verified=channels,power_true_ids=[p['id'] for p in payload if p['powerAssertions']],oracle_error_ids=[p['id'] for p in payload if p['oracleError']],source_stability=True,repeat_raw_stability=True,script_sha256=sha(Path(__file__))))
print('audit passed')
