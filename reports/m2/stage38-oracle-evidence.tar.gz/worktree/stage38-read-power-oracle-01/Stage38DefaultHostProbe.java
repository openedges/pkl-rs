import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.URI;
import java.util.Map;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
import org.pkl.core.PklException;

public final class Stage38DefaultHostProbe {
  static void units(Path path, String value) throws Exception {
    try (var output = new DataOutputStream(Files.newOutputStream(path))) {
      for (int index = 0; index < value.length(); index++) output.writeChar(value.charAt(index));
    }
  }
  public static void main(String[] args) throws Exception {
    Path output = Path.of(args[0]);
    String source = Files.readString(Path.of(args[1]), StandardCharsets.UTF_8);
    URI uri = URI.create(args[2]);
    String expression = args[3];
    Files.writeString(output.resolve("module-uri.bin"), args[2], StandardCharsets.UTF_8);
    units(output.resolve("source.code-units.bin"), source);
    units(output.resolve("value.code-units.bin"), "");
    units(output.resolve("error.code-units.bin"), "");
    try (var evaluator = EvaluatorBuilder.preconfigured().setModuleCacheDir(null)
        .setPowerAssertionsEnabled(true).setColor(false)
        .setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      try {
        String value = evaluator.evaluateExpressionString(ModuleSource.create(uri, source), expression);
        Files.writeString(output.resolve("status.bin"), "success\n", StandardCharsets.UTF_8);
        units(output.resolve("value.code-units.bin"), value);
        System.out.write(value.getBytes(StandardCharsets.UTF_8));
      } catch (PklException error) {
        Files.writeString(output.resolve("status.bin"), "pkl-exception\t" + error.getClass().getName() + "\n", StandardCharsets.UTF_8);
        units(output.resolve("error.code-units.bin"), error.getMessage());
        System.err.write(error.getMessage().getBytes(StandardCharsets.UTF_8));
        System.exit(1);
      }
    }
  }
}
