from pathlib import Path
from collections import Counter
import hashlib,json,re
R=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage38');MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');O=R/'target/m2/stage38-corpus-independent-audit-01'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def identity(p):return {'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
old=read(MAIN/'tests/fixtures/m2/cases.json');new=read(R/'tests/fixtures/m2/cases.json');cases=new['cases'];prior=old['cases'];assert len(prior)==3427 and len(cases)==3518 and cases[:3427]==prior
assert len({c['id'] for c in cases})==len(cases)
oldinputs=[]
for c in prior:
 a=MAIN/c['input'];b=R/c['input'];assert a.read_bytes()==b.read_bytes(),c['id'];oldinputs.append({'id':c['id'],'input':c['input'],'sha256':sha(a)})
supp=cases[3427:];assert Counter('read' if c['id'].startswith('read-stage38-') else 'method' if c['id'].startswith('method-stage38-') else 'bad' for c in supp)=={'read':79,'method':12}
reports=[read(R/f'target/m2/stage38-corpus-addition-{i:02}/report.json') for i in (1,2,3)];origins=sum((r['origins'] for r in reports),[]);assert [x['id'] for x in origins]==[c['id'] for c in supp]
expected_power={c['id'] for c in supp if c.get('power_assertions',False)};assert expected_power=={'read-stage38-power-power-read-null-comparison','read-stage38-power-power-read-lexical-operand'}
originrows=[];oracle_statuses={};sources_by_group=Counter()
for c,origin in zip(supp,origins):
 manifest=Path(origin['manifest']);report=Path(origin['report']);assert sha(manifest)==origin['manifest_sha256'] and sha(report)==origin['report_sha256']
 oc=next(x for x in read(manifest) if x['id']==origin['origin_id']);data=oc['source'].encode('utf-8');assert data==(R/c['input']).read_bytes();assert sha(R/c['input'])==origin['source_sha256'];assert c['expression']==oc['expression']
 capture=manifest.parent/'cases'/oc['id']/'input.pkl';assert capture.read_bytes()==data,c['id']
 uri=oc.get('module_uri',oc.get('uri'));assert uri==origin['original_uri']
 power='stage38-read-power-oracle-01' in str(manifest);assert c.get('power_assertions',False)==power
 rows=[x for x in read(report)['results'] if x['id']==oc['id']];assert rows
 exits=[x['process']['exit_code'] for x in rows];assert len(set(exits))==1 and exits[0] in (0,1)
 assert c['expected_outcome']==('success' if exits[0]==0 else 'failure'),c['id']
 for row in rows:assert not row['process'].get('timed_out',False)
 statuses=[x.get('status',x.get('classification','unknown')) for x in rows];oracle_statuses[c['id']]=statuses
 sources_by_group[str(manifest)]+=1;originrows.append({'id':c['id'],'origin_manifest':str(manifest),'origin_id':oc['id'],'source_sha256':sha(capture),'original_uri':uri,'power_assertions':power,'origin_exits':exits,'expected_outcome':c['expected_outcome']})
# Verify the bad-label attempt and ensure only the 63 new labels changed.
p1=read(R/'target/m2/stage38-corpus-addition-01/prior-cases.json');p2=read(R/'target/m2/stage38-corpus-addition-02/prior-cases.json');p3=read(R/'target/m2/stage38-corpus-addition-03/prior-cases.json')
assert p1==old and len(p2['cases'])==3498 and len(p3['cases'])==3506
corrected=[]
for oldc,newc in zip(p3['cases'],cases):
 if oldc!=newc:
  oc=dict(oldc);assert oc['id'] in {c['id'] for c in supp} and oc['expected_outcome']=='error' and newc['expected_outcome']=='failure';oc['expected_outcome']='failure';assert oc==newc;corrected.append(newc['id'])
assert corrected==reports[2]['outcome_label_corrections'] and len(corrected)==63
assert (R/'target/m2/stage38-corpus-manifest-01.stderr.log').read_bytes()==b'M2 manifest error: expected Java outcome is unspecified\n'
# Independently preserve and verify the original complete65 observations.
origroot=MAIN/'target/m2/stage38-default-host-oracle-01';closed=read(origroot/'closure.json');assert closed['frozen']
for n,h in closed['files_sha256'].items():assert sha(origroot/n)==h,n
orig65=[]
for rel in ('manifest.json','additional-empty-profile/manifest.json','prior-exact-controls/manifest.json'):
 group=origroot/rel;defs=read(group);rr=read(group.parent/'report.json')
 for c in defs:
  assert (group.parent/'cases'/c['id']/'input.pkl').read_bytes()==c['source'].encode()
  original=[x for x in rr['results'] if x['id']==c['id']];assert len(original)==2
  for x in original:assert x['process']['exit_code'] in (0,1)
  orig65.append({'id':c['id'],'manifest':str(group),'source_sha256':hashlib.sha256(c['source'].encode()).hexdigest(),'evaluations':len(original)})
assert len(orig65)==65 and sum(x['evaluations'] for x in orig65)==130
excluded=reports[0]['not_relocated_original_contracts'];assert len(excluded)==14
for x in excluded:assert any(v['id']==x['id'] and v['manifest']==x['origin'] for v in orig65)
prior_exact=read(origroot/'prior-exact-controls/manifest.json')
for x in prior_exact:
 c=next(c for c in prior if c['id']==x['id']);assert (R/c['input']).read_bytes()==x['source'].encode()
# Verify retained source-path79 acquisition from before label correction.
jroot=R/'target/m2/stage38-corpus-java-01';j=read(jroot/'report.json');assert j['source_stability'] and not j['rust_executed'] and j['all_expected_exits_observed']
assert j['cases']==p3['cases'][3427:] and len(j['results'])==79
for n,h in j['files'].items():assert sha(jroot/n)==h,n
internal=[]
for c,row in zip(cases[3427:3506],j['results']):
 assert c['id']==row['id'];assert (jroot/'cases'/c['id']/'input.pkl').read_bytes()==(R/c['input']).read_bytes()
 for ch in ('stdout','stderr'):
  assert sha(jroot/'cases'/c['id']/f'java.{ch}.bin')==row['process'][f'{ch}_sha256']
 outcome=(jroot/'cases'/c['id']/'java.outcome.bin').read_bytes();assert outcome.decode()==row['outcome']
 assert (row['process']['exit_code']==0)==(c['expected_outcome']=='success') and not row['process']['timed_out']
 command=row['process']['command'];assert command[-2:]==[str(R/c['input']),c['expression']] if not c.get('power_assertions') else command[-3:]==[str(R/c['input']),c['expression'],'--power-assertions']
 if b'PklBugException' in outcome:internal.append(c['id'])
assert len(internal)==3
# Old mapping definitions and exception implementations remain exact.
oldmap=read(MAIN/'compatibility/m2-mappings.json');mapping=read(R/'compatibility/m2-mappings.json');before={x['requirement']:x for x in oldmap['requirements']};after={x['requirement']:x for x in mapping['requirements']}
assert all(after[k]==v for k,v in before.items());extra=set(after)-set(before);assert len(extra)==3
newmaprows=[]
for k in sorted(extra):
 m=after[k];assert m['implementation']['state']==m['tests']['state']=='partial' and m['remaining']
 for link in m['implementation']['links']:
  p=R/link['path'];assert p.is_file() and link['symbol'] in p.read_text()
 assert all(id in {c['id'] for c in supp} for id in m['tests']['case_ids'])
 newmaprows.append({'requirement':k,'implementation_state':'partial','tests_state':'partial','linked_cases':len(m['tests']['case_ids']),'remaining':m['remaining']})
assert (R/'tools/m2_language.py').read_bytes()==(MAIN/'tools/m2_language.py').read_bytes()
manifest=read(R/'compatibility/m2-language.json');baseline=read(MAIN/'compatibility/m2-language.json');assert manifest['requirements'][:0]==[]
assert {x['id'] for x in manifest['requirements']}=={x['id'] for x in baseline['requirements']}
assert manifest['counts']['requirements_by_kind']==baseline['counts']['requirements_by_kind']
old_generated={c['id']:c for c in baseline['cases']};new_generated={c['id']:c for c in manifest['cases']}
for c in prior:assert new_generated[c['id']]==old_generated[c['id']]
for c in supp:assert new_generated[c['id']]['input_sha256']==sha(R/c['input']) and new_generated[c['id']]['execution']['state']=='ready'
for n,h in manifest['sources'].items():assert sha(R/n)==h,n
# Portable coverage/schema/source identity, leaving full raw UTF16 audit to C.
js=(R/'tools/platform/read-cases.mjs').read_text();decoder=json.JSONDecoder();context,_=decoder.raw_decode(js.split('export const context =',1)[1].lstrip());portable,_=decoder.raw_decode(js.split('export const cases =',1)[1].lstrip());payload=read(R/'target/m2/stage38-platform-oracle-01/fixed-payloads.json');pr=read(R/'target/m2/stage38-platform-oracle-01/report.json')
assert portable==payload and [x['id'] for x in portable]==[c['id'] for c in supp] and len(portable)==91
for c,p in zip(supp,portable):
 assert p['source'].encode()==(R/c['input']).read_bytes() and p['sourceSha256']==sha(R/c['input']) and p['expression']==c['expression'] and p['powerAssertions']==c.get('power_assertions',False)
 assert ('expectedValue' in p)!=('expectedError' in p)
 assert (p.get('oracleClassification')=='value')==(c['expected_outcome']=='success')
assert context['uri']=='file:///m2-platform.pkl' and pr['case_count']==91 and pr['repetitions']==2 and len(pr['results'])==182
assert pr['source_stability'] and pr['manifest_stability'] and pr['repeat_raw_stability']
assert {p['id'] for p in portable if p['oracleClassification']=='oracle-error'}==set(internal)
assert context['oracle']['acquisitions'][0]['reportSha256']==sha(R/'target/m2/stage38-platform-oracle-01/report.json') and context['oracle']['acquisitions'][0]['payloadSha256']==sha(R/'target/m2/stage38-platform-oracle-01/fixed-payloads.json')
# Distinguish fixed versus path URI contracts with one exact full-error example.
first=supp[0];origin=origins[0];base=Path(origin['manifest']).parent/'cases'/origin['origin_id']/'0/process/stderr.bin';fresh=jroot/'cases'/first['id']/'java.stderr.bin';assert base.read_bytes()!=fresh.read_bytes()
save('original3427-preservation.json',oldinputs);save('new91-provenance.json',originrows);save('original65-accounting.json',{'cases':orig65,'not_relocated':excluded,'prior_exact_controls_already_in_original3427':[x['id'] for x in prior_exact]})
report={'status':'closed','scope':'Independent read-only Stage38 corpus/source/Java-origin/partial-mapping integration audit. No runtime reruns; C full portable raw/UTF16 audit remains separate.','selection':{'old_definitions_order_inputs_preserved':3427,'new_read_cases':79,'new_method_cases':12,'total':3518,'new_outcomes':dict(Counter(c['expected_outcome'] for c in supp)),'power_assertion_cases':sorted(expected_power)},'new_origin_groups':dict(sources_by_group),'original65_preserved':{'definitions':65,'java_processes':130,'closure_files_rehashed':len(closed['files_sha256']),'not_relocated_file_controls':14,'prior_exact_controls_already_selected':2},'invalid_outcome_attempt':{'initial_failure_preserved':True,'new_error_labels_corrected_only':63,'older3427_changed':False,'java79_acquired_before_label_correction':True,'java79_source_input_exit_and_raw_hashes_verified':True,'new_actual_path_java_generic12_not_yet_acquired_in_root79':True},'source_path_java_internal_errors_retained':internal,'mapping':{'old_entries_preserved':len(before),'new_partial_entries':newmaprows,'new_semantic_families':0,'development_exception_tool_bytes_unchanged':True},'generated_manifest_counts':manifest['counts'],'portable_coverage':{'cases':91,'java_executions':182,'exact_module_equals_closed_payload':True,'all_ids_order_sources_expressions_power_flags_match':True,'oracle_internal_errors_retained':internal,'full_raw_utf16_audit_owner':'C; not duplicated here'},'uri_boundaries':{'original_fixed_uri':origin['original_uri'],'new_source_path':str(R/first['input']),'sample_raw_errors_differ':True,'original_raw_bytes_reused_as_source_path_expectations':False},'logs':{'manifest01_rejected_error_label':True,'manifest02_generated_counts':(R/'target/m2/stage38-corpus-manifest-02.stdout.log').read_text(),'tooling_tests':33},'identities':{'selection':identity(R/'tests/fixtures/m2/cases.json'),'mappings':identity(R/'compatibility/m2-mappings.json'),'generated_manifest':identity(R/'compatibility/m2-language.json'),'portable_module':identity(R/'tools/platform/read-cases.mjs')},'compatibility_complete':False,'limitations':['Original fixed-URI/filesystem matrix and ordinary source-path corpus are distinct contracts. All14 nonrelocated file controls and original2 exact trace controls remain preserved.','Pinned Java PklBug observations remain explicit failure dependencies; expected_outcome failure does not establish ordinary language compatibility.','No final Rust candidate pass or complete Host/URI coverage is claimed.']}
save('report.json',report);print(json.dumps({'selected':3518,'new':91,'old':3427,'new_outcomes':report['selection']['new_outcomes'],'portable':91,'old_mappings':len(before),'new_partial':len(extra),'internal_errors':internal}),flush=True)
