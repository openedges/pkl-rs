"""Recheck downloaded raw evidence using the complete exact-commit verifier."""
from pathlib import Path
import importlib.util
import json

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('ci_m1_verifier', BASE / 'verify_evidence.py')
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
summary = json.loads((BASE / 'verification.json').read_bytes())
if verifier.sha(BASE / 'm1-experiment-evidence.zip') != summary['github_artifact']['sha256']:
    raise ValueError('GitHub ZIP changed since verified download')
verified = verifier.verify(BASE / 'artifact')
summary['verified_outcomes'] = verified
summary['independent_complete_recheck'] = True
summary['verifier_sha256'] = verifier.sha(BASE / 'verify_evidence.py')
(BASE / 'verification-complete.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(verified, indent=2))
