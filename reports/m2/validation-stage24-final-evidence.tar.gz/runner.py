"""Capture required checks with complete before/after project-source identities."""
import hashlib,json,pathlib,subprocess,sys
sys.dont_write_bytecode=True
root=pathlib.Path.cwd()
out=root/sys.argv[1]
out.mkdir(parents=True,exist_ok=False)
def digest(data): return hashlib.sha256(data).hexdigest()
def paths():
    names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
    return sorted({name for name in names if name and (root/name).is_file() and
        (name.startswith(('crates/','tools/','tests/','compatibility/','.github/')) or name in
        ['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','oracle.lock.json','.cargo/config.toml'])})
def snapshot(): return {name:digest((root/name).read_bytes()) for name in paths()}
before=snapshot()
for name in before:
    destination=out/'sources'/name
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes((root/name).read_bytes())
(out/'runner.py').write_bytes(pathlib.Path(__file__).read_bytes())
identity={}
for name,command in [('rustc',['rustc','-vV']),('cargo',['cargo','--version']),('host',['uname','-a']),('python',[sys.executable,'--version'])]:
    result=subprocess.run(command,cwd=root,capture_output=True)
    identity[name]={'command':command,'exit_code':result.returncode}
    for channel,data in [('stdout',result.stdout),('stderr',result.stderr)]:
        (out/f'{name}.{channel}.bin').write_bytes(data)
        identity[name][channel+'_sha256']=digest(data)
    assert result.returncode==0
checks=[
 ['cargo','xtask','verify'],
 ['cargo','fmt','--all','--','--check'],
 ['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],
 ['cargo','test','--workspace','--locked'],
 ['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked'],
 [sys.executable,'-m','unittest','discover','-s','tools/tests','-v'],
 [sys.executable,'tools/m2_manifest.py','--check'],
]
rows=[]
for i,command in enumerate(checks):
 result=subprocess.run(command,cwd=root,capture_output=True)
 for kind,data in [('stdout',result.stdout),('stderr',result.stderr)]:
  (out/f'{i}.{kind}.bin').write_bytes(data)
 row={'command':command,'exit_code':result.returncode,'stdout_sha256':digest(result.stdout),'stderr_sha256':digest(result.stderr)}
 rows.append(row)
 after=snapshot()
 report={'scope':'M2 Stage24 required local development checks; full compatibility and performance remain separate.', 'checks':rows,
 'identities':identity,'source_sha256_before':before,'source_sha256_after':after,'source_stability':before==after}
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if result.returncode or before!=after:
  print(result.stdout.decode(errors='replace')[-12000:]+result.stderr.decode(errors='replace')[-12000:],flush=True)
  sys.exit(1)
