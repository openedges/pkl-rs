from pathlib import Path
import json,hashlib
B=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42/target/m2')
F=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage45/target/m2')
O=B/'stage45-oracle-platform-handoff-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def receipt(p):return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
old='stage45-bootstrap-audit-01 stage45-bootstrap-consumer-01 stage45-bootstrap-native-01 stage45-bootstrap-native-02 stage45-bootstrap-oracle-01 stage45-bootstrap-oracle-02 stage45-bootstrap-portable-01 stage45-classpath-tooling-review-01 stage45-guest-catch-fixtures-01 stage45-guest-catch-fixtures-02 stage45-guest-catch-oracle-01 stage45-guest-catch-oracle-02 stage45-guest-catch-oracle-03 stage45-guest-catch-oracle-04 stage45-guest-catch-oracle-05 stage45-implementation-review-01 stage45-jdk-digit-oracle-01 stage45-moduleinfo-fixtures-01 stage45-moduleinfo-oracle-01 stage45-moduleinfo-portable-01 stage45-original6-java-01 stage45-original6-java-audit-01 stage45-original6-native-01 stage45-original6-native-02 stage45-original6-native-03 stage45-original6-native-04 stage45-original6-native-05 stage45-original6-native-audit-01 stage45-original6-native-audit-02 stage45-original6-native-audit-03 stage45-original6-native-audit-04 stage45-original6-native-audit-05 stage45-original6-native-seal-addendum-01 stage45-portable-promotion-01 stage45-portable-promotion-02 stage45-security-denial-fixtures-01 stage45-security-denial-oracle-01'.split()
new='stage45-original6-native-final-01 stage45-original6-native-final-audit-01 stage45-bootstrap-native-final-01 stage45-guest-catch-platform-01 stage45-moduleinfo-platform-01 stage45-security-denial-platform-01 stage45-bootstrap-platform-01 stage45-supplemental-platform-audit-01 stage45-supplemental-platform-audit-02 stage45-supplemental-platform-audit-03 stage45-native-final-extra-audit-01 stage45-native-final-extra-audit-02'.split()
roots=[]
for base,names in [(B,old),(F,new)]:
 for n in names:
  p=base/n;assert p.is_dir(),p
  files=[]
  # Only immediate named evidence metadata. No recursive walk or Cargo inspection.
  for name in ['report.json','execution.json','inventory.json','closure.json','terminal.json','exclusions.json','closure-exclusions.json','checks.json','portable-checks.json','promotion-manifest.json','authored-files.json','authored-files-addendum-01.json']:
   q=p/name
   if q.is_file():files.append(receipt(q))
  roots.append({'root':str(p),'metadata':files,'closed':read(p/'closure.json').get('closed') if (p/'closure.json').exists() else None})
promotion=B/'stage45-portable-promotion-02/promotion-manifest.json'
prom=read(promotion)
for e in prom['entries']:
 assert sha(Path(e['source']))==e['sha256']
sourcepackages=[]
for n in ['stage45-bootstrap-consumer-01','stage45-moduleinfo-fixtures-01','stage45-security-denial-fixtures-01','stage45-guest-catch-fixtures-02']:
 p=B/n;files=[]
 for rel,decl in read(p/'authored-files.json').items():
  q=p/'workspace'/rel
  files.append(dict(receipt(q),relativeTarget=rel,originalAuthoredSha256=decl['sha256'],identicalToOriginalAuthoredRecord=sha(q)==decl['sha256']))
 sourcepackages.append({'root':str(p),'sources':files,'checks':read(p/'checks.json'),'scope':'Original authored records are preserved; a runner addendum or later core integration can differ. Actual portable execution bytes are bound separately by promotion02.'})
audit=read(F/'stage45-supplemental-platform-audit-03/report.json')
selection={'schema':1,'owner':'/root/m2_stage45_oracle_resume','roots':[str(B/n) for n in old]+[str(F/n) for n in new]+[str(O)],'excludedOwnedDisposableRoot':str(B/'stage45-original6-workspace-01'),'excludedCoreOwnedRoot':str(B/'stage45-stdlib-implementation-01'),'sharedCompiledArtifacts':'Preserve sealed comparison-root binary duplicates. Core publication owns full platform-candidate-01/native-final-01 build artifacts and source snapshots; supplement execution inputs reference their exact hashes.','dependencyCachePruneBeforeAnyArchiveWalk':{'coreOwnedCargoExactPath':str(B/'stage45-stdlib-implementation-01/cargo-target'),'excludedEntireCoreRootFromThisSelection':True,'ownPythonCaches':[str(B/n/'workspace'/q) for n in ['stage45-bootstrap-consumer-01','stage45-moduleinfo-fixtures-01','stage45-security-denial-fixtures-01','stage45-guest-catch-fixtures-02'] for q in ['tools/__pycache__','tools/tests/__pycache__']],'instruction':'Declare these exact paths before any archive traversal; do not use blanket build basename pruning. Preserve existing inventories and their own exclusions.'}}
(O/'archive-selection.json').write_text(json.dumps(selection,indent=2)+'\n')
report={
 'schema':1,'status':'Final selected evidence complete and closed; compatibility failures and partial/unexecuted scope retained.','changes':'No Git or production writes by this agent. Oracle acquisition/fixture/verifier/native and portable consumers authored in separate staging; root/core integrated explicitly. No Java reacquisition for final comparisons.',
 'finalOriginalSix':{'report':receipt(F/'stage45-original6-native-final-01/report.json'),'audit':receipt(F/'stage45-original6-native-final-audit-01/report.json'),'counts':{'cases':6,'repeats':2,'rawPass':12},'cases':['api/moduleOutput','basic/boolean','modules/supercalls3','modules/typedModuleMethods1','parser/newline','modules/equality'],'javaSource':str(B/'stage45-original6-java-01'),'scope':'Exact captured original source/URI/argv/env/cwd/files/stdout/stderr reused; selected original cases only.'},
 'finalBootstrapAndModuleInfoNative':{'report':receipt(F/'stage45-bootstrap-native-final-01/report.json'),'audit':receipt(F/'stage45-native-final-extra-audit-02/report.json'),'accounting':{'pass':350,'unsupported':192,'mismatch':214,'isolatedFollowupControls':56,'javaInternalBoundaries':12,'total':824},'ordinaryModuleInfoRawPass':156,'bootstrap600':{'pass':194,'unsupported':192,'mismatch':214},'strictComparisonExitCode':1},
 'actualPortable':audit['audits'],
 'portableReports':{n:receipt(F/n/'execution.json') for n in ['stage45-guest-catch-platform-01','stage45-moduleinfo-platform-01','stage45-security-denial-platform-01','stage45-bootstrap-platform-01']},
 'independentAudits':{'portable':receipt(F/'stage45-supplemental-platform-audit-03/report.json'),'nativeModuleInfoBootstrap':receipt(F/'stage45-native-final-extra-audit-02/report.json'),'originalSix':receipt(F/'stage45-original6-native-final-audit-01/report.json')},
 'artifactAndSourceBinding':{'nativeMetadata':receipt(F/'stage45-native-final-01/artifacts.json'),'nativeModuleEvalSha256':'3c3651704ef2b92a2f529abeaba0fa48edcd08b7cc1a5c150386980e876afce2','nativeAnnotationSha256':'5ffd0f5f15257d17a8721cc18f97efed62555bb53ff23d9c51442775cac340d1','platformArtifacts':audit['finalSharedArtifacts'],'mainPlatformReportSha256':audit['mainPlatformReportSha256'],'sourceBinding':audit['sourceBinding'],'chronology':audit['chronology'],'qualification':'M1 suffix collector omits modules.txt. Complete earlier PRE-platform and all five POST-Rust5 maps and later native capture include all77 production inputs. This does not retroactively make omitted bytes M1-captured. Per-artifact processUTC not recorded; wrapperUTC and filesystem bounds remain distinct.'},
 'toolingPromotion':{'manifest':receipt(promotion),'actions':prom['actions'],'productionChanges':0,'entries':prom['entries'],'checks':prom['checks'],'unchangedCapturedRuntimeBytes':True,'totalPortableUnitTestsPassed':22,'note':'Promotion02 corrects only guest test-capture link from01; source/actions identical. Root separately reported final fixture verifiers3, Python27 and JS22 passed after exact nine-file promotion; those root checks are not relabeled as this agent executions.'},
 'otherAuthoredSourcesAndChecks':sourcepackages,
 'oracleProvenance':{'bootstrap':{'root':str(B/'stage45-bootstrap-oracle-02'),'calls':600,'jvms':8,'evaluators':24,'repeatsRawIdentical':True,'audit':str(B/'stage45-bootstrap-audit-01/report.json')},'moduleInfo':{'root':str(B/'stage45-moduleinfo-oracle-01'),'sources':28,'calls':224,'ordinary':156,'javaInternal':12,'sameEvaluatorFollowups':56},'unicodeDigits':{'root':str(B/'stage45-jdk-digit-oracle-01'),'codePointsPerRepeat':1114112,'repeats':2,'decimalDigitPoints':680,'ranges':64,'scope':'Pinned Character.isDigit / UNICODE_PATTERN digit / exact ModuleInfo1-2 codepoint pattern equivalence only; not full regex parity.'},'security':{'root':str(B/'stage45-security-denial-oracle-01'),'actualPolicy':'Actual StandardSecurityManager rejects excluded existing child URI; delegated exception retained unchanged. Default file loader; no source read after denied resolve.','calls':10,'success':8,'ordinaryErrors':2,'denials':6,'scope':'Typed security-manager-exception resolve completion only; generic Denied/rawHost remain bypass and source-load typed completion rejected.'}},
 'knownFailuresAndUnverifiedScope':[
 'Main m1 platforms retain two Java regex mismatches: regex-unicode-15-vs-16 and regex-zero-width-supplementary. Contract pass is not strict compatibility pass.',
 'Bootstrap each final native/Node/Chromium600:194pass192unsupported214mismatch.360 raw Java string matches;166 mismatch cases differ only in host read counters;48 other mismatches preserve JVM-global successful pkl:test output-cache behavior. JSON/reflect192 unsupported.',
 'ModuleInfo12 actual Java internal outcomes explicitly Unsupported;56 same-evaluator independent-root followups unexecuted by native/portable API. Native isolated string controls are not those shared-evaluator calls.',
 'Guest each target24 ordinary sessions166 actual API completions,10 constructor-only boundaries comparing60 recorded Java diagnostics,8 terminal partial sessions with12 exact API subset calls. Constructor diagnostics are not60 native API passes; later terminal behavior remains partial.',
 'Security10 rawAPI passes per target prove typed VM catch behavior with original policy-cause provenance, not full native security policy/source-load parity.',
 'M1 source suffix omission modules.txt remains explicit and requires future collector fix plus new acquisition; complete independent frozen maps bind its exact bytes here.',
 'Selected successes do not complete Stage45/M2/full language/API/performance gates. Full corpus, Linux/Windows and performance targets remain unverified by this work.'
 ],
 'historicalAttemptsPreserved':[
 'original6-native-01 initial failures; native-02 tenpass/twoBooleanxor mismatches. Native03/04/05 interim12pass remain distinct from final combined-source12pass.',
 'guest oracle01/04 authored invalid fixtures remain not-reached; corrected later fixtures/oracles do not rewrite them.',
 'bootstrap-oracle01 alias expressions did not reach intended API boundaries; corrected public-property oracle02 is final source.',
 'bootstrap-native01 candidate04 and native02 candidate05 failed strict comparisons preserved alongside final strict failures.',
 'supplemental audit01 wrong hardcoded Playwright1.56.0 failed against actual pinned1.64.1; audit02 assumed wrong source-after filename failed. Audit03 fixes audit assumptions only; actual acquisitions were not rerun.',
 'native-final-extra-audit01 inline review preserved; audit02 persists replayable independent script and confirms same results.',
 'portable-promotion01 metadata link error preserved;02 source/actions unchanged.'
 ],
 'cacheExclusions':{'finalCompleteSource':read(F/'stage45-rust5-02/exclusions.json'),'sourceAudits':'Read explicit14216 input-map entries; no directory or Cargo-cache walks.','archiveSelection':receipt(O/'archive-selection.json'),'ownEvidenceClosures':'Only each fresh output subtree; dependency caches absent. Python caches excluded by exact staged path declared before enumeration. No generic build basename exclusion.'},
 'evidenceRoots':roots,'archiveSelection':receipt(O/'archive-selection.json'),'liveHandles':[],
 'completionQualification':'All authorized selected verification and portable tooling handoff finished; compatibility failures, Java internal boundaries, unexecuted scope and incomplete full M2 gate remain explicit.'
}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
# This is a new tiny handoff subtree; explicit immediate files only.
inventory={q.name:{'sha256':sha(q),'bytes':q.stat().st_size} for q in [O/'exclusions.json',O/'build_handoff.py',O/'archive-selection.json',O/'report.json']}
(O/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for name,m in inventory.items():assert sha(O/name)==m['sha256']
(O/'closure.json').write_text(json.dumps({'closed':True,'reportSha256':sha(O/'report.json'),'inventorySha256':sha(O/'inventory.json'),'allPayloadHashesVerified':True,'files':len(inventory),'liveHandles':[]},indent=2)+'\n')
print(json.dumps({'root':str(O),'reportSha256':sha(O/'report.json'),'inventorySha256':sha(O/'inventory.json'),'archiveSelectionSha256':sha(O/'archive-selection.json'),'roots':len(roots),'portableSources':len(prom['entries']),'passed':True},indent=2))
