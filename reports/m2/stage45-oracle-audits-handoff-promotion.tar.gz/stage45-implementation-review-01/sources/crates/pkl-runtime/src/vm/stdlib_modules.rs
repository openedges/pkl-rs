//! Evaluator-owned standard-library modules share ordinary module/class/member
//! identities and the same code arena as user declarations. External bindings
//! retain their pinned declaration source; missing bindings fail explicitly.
use super::*;
use crate::modules::{ModuleIdentity, UnitId};
use crate::syntax::ExprKind;

impl Vm {
    pub(super) fn import_stdlib(&mut self, uri: &str) -> Result<bool, RuntimeError> {
        let source = match uri {
            "pkl:base" => crate::stdlib_sources::base(),
            "pkl:test" => crate::stdlib_sources::test(),
            "pkl:ref" => crate::stdlib_sources::reference(),
            _ if uri.starts_with("pkl:") => {
                if include_str!("../stdlib/modules.txt").lines().any(|name| name == uri) {
                    return Err(RuntimeError::new(ErrorKind::Unsupported,
                        format!("Standard-library module `{uri}` is not implemented.")));
                }
                let mut error = RuntimeError::new(ErrorKind::Type,
                    format!("Cannot find standard library module `{uri}`."));
                error.hint = Some(format!("Available standard library modules:\n{}", include_str!("../stdlib/modules.txt").strip_suffix('\n').unwrap()).into());
                return Err(error);
            }
            _ => return Ok(false),
        };
        if let Some(modules::CachedModule::Value(id)) = self.modules_original.get(uri) {
            self.stack.push(Value::Object(*id));
            return Ok(true);
        }
        let program = Arc::make_mut(&mut self.program);
        let unit = append_definition(program, uri, source)?;
        let definition = program.units[unit.0 as usize].clone();
        let members = program.objects[definition.template].clone();
        let parent = self.builtin_class(builtins::ty(output::MODULE)).heap_id();
        let id = self.heap.allocate(Object {
            is_module: true,
            ref_module: uri == "pkl:ref",
            module_unit: Some(unit),
            class_definition: Some(Class {
                module: None,
                id: definition.class_id,
                name: definition.name,
                open: definition.modifiers & crate::syntax::ModifierKind::Open.flag() != 0,
                abstract_: false,
            }),
            class_superclass_initialized: true,
            published_module_members: members.iter().map(|member| member.code).collect(),
            members,
            parent,
            ..Object::default()
        });
        self.modules_original.insert(uri.into(), modules::CachedModule::Value(id));
        self.modules_resolved.insert(uri.into(), modules::CachedModule::Value(id));
        self.stack.push(Value::Object(id));
        Ok(true)
    }
}

fn append_definition(program: &mut Program, uri: &str, source: Arc<crate::value::RuntimeSource>) -> Result<UnitId, RuntimeError> {
    if let Some(unit) = program.units.iter().find(|unit| unit.identity.as_ref().is_some_and(|identity| identity.original_uri.as_ref() == uri)) {
        return Ok(unit.id);
    }
    let parsed = crate::parser::parse_module(&source.text).map_err(|error|
        RuntimeError::new(ErrorKind::Unsupported, PklString::from("Standard-library declaration parsing: ").concat(&error.message)))?;
    let checkpoint = modules::ArenaCheckpoint::new(program);
    let result = append_members(program, uri, source, &parsed);
    if result.is_err() { checkpoint.rollback(program); }
    result
}

fn append_members(program: &mut Program, uri: &str, source: Arc<crate::value::RuntimeSource>, parsed: &crate::syntax::Module) -> Result<UnitId, RuntimeError> {
    let unit = UnitId(program.units.len().try_into().map_err(|_| invalid("module unit limit"))?);
    let class_id = program.next_declaration + source.text.len() + 1;
    program.next_declaration = class_id.checked_add(1).ok_or_else(|| invalid("declaration identity limit"))?;
    let mut members = Vec::new();
    for declaration in &parsed.members {
        let method = matches!(declaration.expr.kind, ExprKind::Function { method: true, .. });
        let mut ty = None;
        let mut type_span = None;
        let mut body = if uri == "pkl:base" {
            base_binding(declaration)
        } else if uri == "pkl:ref" {
            match declaration.name.as_str() {
                "Reference" if !method => vec![Instruction::BuiltinClass(TypeCheck::Reference { domain: Box::new(TypeCheck::Any), referent: Box::new(TypeCheck::Any) })],
                "Domain" if !method => vec![Instruction::BuiltinClass(TypeCheck::RefDomain)],
                "Access" if !method => vec![Instruction::BuiltinClass(TypeCheck::Class { module: None, id: reference::ACCESS_ID, name: "Access".into() })],
                _ => unsupported_binding(uri, declaration),
            }
        } else {
            match declaration.name.as_str() {
                "facts" | "examples" if !method => {
                    let value_type = if declaration.name == "facts" { TypeCheck::Boolean } else { TypeCheck::Unknown };
                    let listing = TypeCheck::ParameterizedCollection {
                        kind: crate::heap::CollectionKind::Listing,
                        arguments: vec![(value_type, declaration.ty.as_ref().unwrap().span)],
                    };
                    let mapping = TypeCheck::ParameterizedCollection {
                        kind: crate::heap::CollectionKind::Mapping,
                        arguments: vec![(TypeCheck::String, declaration.ty.as_ref().unwrap().span), (listing, declaration.ty.as_ref().unwrap().span)],
                    };
                    let check = TypeCheck::Nullable(Box::new(mapping.clone()));
                    ty = Some(check.clone());
                    type_span = declaration.ty.as_ref().map(|ty| ty.span);
                    // A nullable Mapping retains its collection default for amendments.
                    vec![Instruction::ResolvedDefault { ty: check, origin: Some(RuntimeFrame { source: Some(source.clone()), span: type_span.unwrap(), member: format!("#{}", declaration.name).into() }) }]
                }
                "catch" | "catchOrNull" if method => {
                    let ExprKind::Function { parameters, header_span, .. } = &declaration.expr.kind else { unreachable!() };
                    let argument_span = parameters[0].ty.as_ref().expect("pinned catch argument").span;
                    let block = program.blocks.len();
                    program.blocks.push(vec![
                        Instruction::LoadLocal(0),
                        Instruction::CheckType(TypeCheck::Function { parameters: Some(Vec::new()), result: Box::new(TypeCheck::Any), syntax: true }),
                        Instruction::GuestCatch { or_null: declaration.name == "catchOrNull" },
                        Instruction::Return,
                    ]);
                    program.metadata.push(BlockMetadata {
                        unit: Some(unit), source: Some(source.clone()),
                        member: format!("#{}", declaration.name).into(),
                        declaration: Some(*header_span),
                        spans: vec![None, Some(argument_span), None, None],
                        ..Default::default()
                    });
                    vec![Instruction::MakeFunction { block, arity: 1, method: true, capture_custom_this: false }]
                }
                _ => unsupported_binding(uri, declaration),
            }
        };
        body.push(Instruction::Return);
        let block = program.blocks.len();
        let spans = vec![Some(declaration.name_span); body.len()];
        program.blocks.push(body);
        program.metadata.push(BlockMetadata {
            unit: Some(unit), source: Some(source.clone()),
            member: format!("#{}", declaration.name).into(),
            declaration: Some(declaration.name_span), spans,
            ..Default::default()
        });
        members.push(Member {
            flags: Member::declaration_flags(declaration),
            entry: false, name: declaration.name.clone().into(), code: block,
            local: declaration.local, method, ty, type_span,
            constant: declaration.modifiers.iter().any(|modifier| modifier.kind == crate::syntax::ModifierKind::Const)
                || matches!(declaration.expr.kind, ExprKind::Class { .. } | ExprKind::TypeAlias { .. }),
            fixed: false,
        });
    }
    let template = program.objects.len();
    program.objects.push(members.clone());
    program.units.push(modules::ModuleUnit {
        id: unit, identity: Some(ModuleIdentity { original_uri: uri.into(), resolved_uri: uri.into() }),
        source: Some(source.clone()), name: source.module_name.clone(), template,
        entry: usize::MAX, initial_members: members, class_id,
        mode: modules::ModuleMode::Plain,
        modifiers: parsed.declaration.as_ref().map_or(0, |declaration| crate::syntax::modifier_flags(&declaration.modifiers)),
    });
    Ok(unit)
}

fn base_binding(declaration: &crate::syntax::Member) -> Vec<Instruction> {
    let name = declaration.name.as_str();
    match &declaration.expr.kind {
        ExprKind::Class { .. } => {
            if let Some(ty) = reference::base_type(name).or_else(|| builtins::id(name).map(builtins::ty)) {
                return vec![Instruction::BuiltinClass(ty)];
            }
        }
        ExprKind::TypeAlias { .. } if matches!(name, "NonNull" | "Int8" | "Int16" | "Int32" | "UInt8" | "UInt16" | "UInt32" | "UInt") => {
            return vec![Instruction::BuiltinTypeAlias(name.into())];
        }
        _ if matches!(name, "NaN" | "Infinity") => {
            return vec![Instruction::Constant(Value::Float(if name == "NaN" { f64::NAN } else { f64::INFINITY }))];
        }
        _ => {}
    }
    unsupported_binding("pkl:base", declaration)
}

fn unsupported_binding(uri: &str, declaration: &crate::syntax::Member) -> Vec<Instruction> {
    vec![Instruction::Fail(RuntimeError::new(ErrorKind::Unsupported,
        format!("Standard-library binding `{uri}#{}` is not implemented.", declaration.name)))]
}
