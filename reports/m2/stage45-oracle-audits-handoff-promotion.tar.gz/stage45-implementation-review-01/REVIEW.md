# Stage45 initial coherent implementation review

This review binds twelve Rust source files copied while A held production at candidate-build-01. Each copied source hash exactly matched that build's source-after map. The copied candidate report records source-stable build success; the artifact SHA is 5292423b795f22e492b5dd4fe0c387694981a8fe94eceeae229a3365b6e7e409. This is an initial development snapshot, not full implementation or compatibility signoff. No builds, evaluator calls, Java processes, or Git operations were performed by this review.

## Actionable gap: typed missing and resource language failures bypass catch

`guest_catch_boundary` admits ErrorKind::Host only when `host_language_exception` is true. IoFailure correctly marks its supported IOException mapping. However, `ModuleHostError::NotFound` creates an unmarked Host error. Pinned ModuleCache.resolve turns file-not-found into ordinary cannotFindModule VmException, which TestNodes catches. The convenience mapping therefore needs ordinary-language provenance without making generic Host reject/logger errors catchable. A accepted this finding.

The same gap appears in existing shared resource policy mappings: configured_result's allowlist refusal and missing env/prop, and ResourceUri syntax failures, use unmarked Host errors. Pinned AbstractReadNode/ResourceManager wrap these implemented language cases in VmException. Unsupported allowed-I/O/URI capability gaps must continue to bypass catch. Arbitrary Denied/raw injected text must not be assumed to represent a supported Java exception taxonomy.

## Confirmed queued correction: inferred-parent conversion crosses handler

Vm::fail searches the entire current stack for InferPropertyParent when converting undefined. An outer retained inferred-parent frame must not replace the undefined error caught by a more deeply nested guest handler. A independently identified and queued a suffix-only search below the guest boundary. The copied snapshot retains the original implementation and this issue explicitly.

## Ownership and renderer observations

The current handler is installed after the external Function0 type check and invokes the captured function through ordinary VM function application. It is retired before normal-return expectedAnException; catchOrNull returns plain null and discards the successful callback result. Handler fields contain only stack index and mode, while the function/captures remain ordinary frame/stack roots.

Failure cleanup is bounded after the handler. Evaluating-cache cleanup checks both retained current frames and suspended contexts; module-failure caching iterates only removed frames. Completed inner publications remain. The caller stack prefix, inputs, Host contexts and shared deadline survive. Standard module receivers are rooted by the existing original/resolved module cache roots; close clears these maps. These are source observations, not independent lifecycle execution results.

Nearest guest versus allow-undefined force interception is now represented explicitly by passing the guest index into catch_force_undefined. The inner guest wins over an outer force boundary. The existing entered-member ownership requirement and inference conversion remain relevant.

Caught rendering uses canonical PklString, power disabled and no hints/frames. Java CR/LF/CRLF lines, skip-first, ASCII-space join and Java whitespace strip are applied as the builtin semantics, preserving unmatched units and Java non-whitespace NBSP/NEL. Error-kind/disposition guards bypass cancellation/timeout/closed/unsupported/internal paths and raw Host failures; actual Java bug/terminal observations remain separate nonpasses where not represented.

## Explicit unfinished stdlib scope

The current base/test/ref declaration graph shares builtin class identities and test defaults/catch functions, but A explicitly reports eager stdlib bootstrap, base output and ModuleInfo annotation metadata unfinished. Pinned StdLibModule uses a private empty-property/environment context, force(false,true), and an additional base-output force; caller effects must not leak into that initialization. A known unimplemented declaration fails Unsupported rather than being claimed as a valid absent language member. No parity claim follows from the two architecture tests or from parsing declaration source.

B's closed first Java batch retains four authored syntax-blocked sources, with the corrected four in a separate batch. Those original failures remain immutable. The actual six original CLI contracts and all fourteen plus corrected API inputs remain obligations; no fixture rewrite or selection reduction is proposed. C did not rerun those observations.

A's brief source hold was released only after exact copies completed. Follow-up correction review must bind a new coherent source version; this report does not relabel the copied candidate after later edits.
