from pathlib import Path
import hashlib,json,collections,datetime
A=Path(__file__).resolve().parent;T=A.parent;R=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage45');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def unit_bytes(values):return b''.join(int(x).to_bytes(2,'big')for x in values)
def java_bytes(values):return unit_bytes(values).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
def check_call(actual,folder,prefix=None):
 prefix=prefix or actual['prefix'];channel='stdout'if actual['kind']=='value'else'stderr';opposite='stderr'if channel=='stdout'else'stdout';status=b'success\n'if channel=='stdout'else b'error\n';units=(folder/(prefix+'.'+channel+'.code-units.bin')).read_bytes();raw=(folder/(prefix+'.'+channel+'.bin')).read_bytes()
 return (status==(folder/(prefix+'.status.bin')).read_bytes()and unit_bytes(actual['units'])==units and java_bytes(actual['units'])==raw and not(folder/(prefix+'.'+opposite+'.bin')).read_bytes()and not(folder/(prefix+'.'+opposite+'.code-units.bin')).read_bytes())
def check_units(actual,path):assert unit_bytes(actual)==path.read_bytes(),str(path)
def record_identity(category):
 root=T/('stage45-'+category+'-platform-01');e=json.loads((root/'execution.json').read_text());assert not e['infrastructureErrors']and not e['browserErrors']and not e['changedInputs'];assert e['playwrightPin']==json.loads((R/'tools/platform/package.json').read_text())['devDependencies']['playwright']
 for path,digest in e['artifactAndInputHashes'].items():assert sha(Path(path))==digest,path
 assert sha(Path(e['browserExecutable']))==e['browserExecutableSha256'];return root,e
platform=T/'stage45-platform-candidate-01';main=json.loads((platform/'report.json').read_text());assert main['source_stability']and main['total']==6078 and main['shared_engine_passed']==6078 and main['oracle_passed']=={'rust':6076,'node':6076,'browser':6076};assert main['compatibility_status']=='fail'and main['experiment_contract_status']=='pass';assert main['known_gaps']==['regex-unicode-15-vs-16','regex-zero-width-supplementary']
complete=T/'stage45-rust5-02/source-before.json';native=T/'stage45-native-final-01/source-after.json';assert sha(complete)==sha(native)=='2a84330b4e9d1b47703a84b1eef72845c4449d41fcadcd48d94ded2e4a1d3830';mapping=json.loads(native.read_text());prefixes=('crates/pkl-runtime/src/','crates/pkl-napi/src/','crates/pkl-wasm/src/');prod=[p for p in mapping if p.startswith(prefixes)];assert len(prod)==77;missing=[p for p in prod if p not in main['source_hashes']];assert missing==['crates/pkl-runtime/src/stdlib/modules.txt']
for p in prod:
 assert sha(R/p)==mapping[p],p
 if p in main['source_hashes']:assert main['source_hashes'][p]==mapping[p],p
post=T/'stage45-rust5-02/source-after.json';assert sha(post)==sha(complete)
source_binding={'productionInputs':77,'completeAfterRust5Sha256':sha(post),'directMainPlatformCapturedHashMatches':76,'completeBeforePlatformFreezeSha256':sha(complete),'nativeFinalSourceMapSha256':sha(native),'collectorOmissions':missing,'omittedInputBindings':{p:mapping[p]for p in missing},'scope':'The M1 suffixcollector did not capture modules.txt. Its bytes are bound by the complete earlier frozen manifest,identical final native source snapshot and current immutable implementation;not relabeled as M1-captured.'}
artifacts={'pkl_napi.node':'92a713ee8572c57f04d78cc53928bf4b05dcb741744cae7651f2a79eed290971','wasm/pkl_wasm_bg.wasm':'5efa5176e6b0ab4121c5b4d4e82bb060daf1efa2c606cd8004db1ac2c9c77eed','wasm/pkl_wasm.js':'296ca2b784c41e58891fbbe573a809e01eeceb19b85881c0f4d3ca669037e359'}
for p,d in artifacts.items():assert sha(platform/p)==d
results={}
# Guest: full ordinary calls/events/logs/counters versus original raw fixture payloads.
root,e=record_identity('guest-catch');fixtures=json.loads((root/'fixture-data.json').read_text());fixture_root=R/'tests/fixtures/m2-guest-catch';targets={}
for target in ['node','browser']:
 rows=json.loads((root/(target+'.raw.json')).read_text());assert len(rows)==42;full=constructors=constructor_diagnostics=terminal_calls=0
 for f,a in zip(fixtures,rows):
  assert(a['group'],a['id'],a['repeat'])==(f['group'],f['id'],f['repeat']);expected=fixture_root/f['group']/'cases'/f['id']/str(f['repeat'])/'calls'
  if f['comparisonScope']=='frontend-constructor-only':
   assert a['constructorError']['isError']and not a['calls'];constructors+=1
   for call in f['expected']['calls']:
    assert call['kind']=='error';check_units(a['constructorError']['messageUnits'],expected/(call['prefix']+'.stderr.code-units.bin'));assert java_bytes(a['constructorError']['messageUnits'])==(expected/(call['prefix']+'.stderr.bin')).read_bytes();constructor_diagnostics+=1
   continue
  assert a['constructorError']is None and a['acquisitionError']is None and a['architecture']['terminalSlots']==0 and a['architecture']['ownedResultsStable']
  for call in a['calls']:assert check_call(call,expected),(target,f['id'],call['prefix'])
  if f['comparisonScope']=='full-ordered-api':
   assert [c['prefix']for c in a['calls']]==[c['prefix']for c in f['expected']['calls']];full+=len(a['calls'])
   assert b''.join((key+'='+str(a['counts'][key])+'\n').encode()for key in ['resolve','source','read','log','callback','event'])==(expected/'counters.bin').read_bytes()
   assert len(a['events'])==a['counts']['event']
   for i,event in enumerate(a['events']):assert event.encode('utf-8')==(expected/f'event-{i}.bin').read_bytes()
   assert len(a['logs'])==a['counts']['log']
   for i,log in enumerate(a['logs']):
    stem='log-'+str(i);assert log['level'].encode()==(expected/(stem+'.level.bin')).read_bytes();check_units(log['message'],expected/(stem+'.message.code-units.bin'));assert java_bytes(log['message'])==(expected/(stem+'.message.bin')).read_bytes();check_units(log['moduleUri'],expected/(stem+'.uri.code-units.bin'));assert java_bytes(log['moduleUri'])==(expected/(stem+'.uri.bin')).read_bytes();assert str(log['memberName']is None).lower().encode()==(expected/(stem+'.member-null.bin')).read_bytes();check_units(log['memberName']or[],expected/(stem+'.member.code-units.bin'));assert ':'.join(str(log[k])for k in ['startLine','startColumn','endLine','endColumn']).encode()==(expected/(stem+'.position.bin')).read_bytes();assert str(len(log['sourceLines'])).encode()==(expected/(stem+'.source-count.bin')).read_bytes()
    for n,line in enumerate(log['sourceLines']):check_units(line,expected/(stem+f'.source-{n}.code-units.bin'));assert java_bytes(line)==(expected/(stem+f'.source-{n}.bin')).read_bytes()
  else:
   assert a['followupRejections']==[True,True];terminal_calls+=len(a['calls'])
   if f['mode'].endswith('-timeout'):
    assert a['terminalFailure']['kind']=='error'and a['terminalFailure']['disposition']=='language-error';aborted=a['architecture']['cancelledReads']if f['id'].startswith('read-')else a['architecture']['cancelledModules'];assert aborted==[a['pendingToken']]
 assert(full,constructors,constructor_diagnostics,terminal_calls)==(166,10,60,12);assert e['targets'][target]['statusCounts']=={'constructor-boundary-pass':10,'pass':24,'terminal-partial-pass':8};targets[target]={'fullOrdinaryApiCalls':full,'constructorBoundaries':constructors,'preservedJavaConstructorDiagnosticCalls':constructor_diagnostics,'exactTerminalSubsetCalls':terminal_calls,'terminalPartialSessions':8}
results['guest-catch']={'reportSha256':sha(root/'execution.json'),'passed':True,'targets':targets,'scope':'Constructor/API timing and full terminal/API parity remain separate boundaries.'}
# ModuleInfo: all ordinary strings;Java internal parser outcomes remain explicitUnsupported.
root,e=record_identity('moduleinfo');froot=R/'tests/fixtures/m2-moduleinfo/oracle';targets={}
for target in ['node','browser']:
 rows=json.loads((root/(target+'.raw.json')).read_text());ordinary=internal=0
 for row in rows:
  folder=froot/'repeats'/str(row['repeat'])/'calls'/row['id'];assert row['constructorError']is None and row['acquisitionError']is None and row['architecture']['terminalSlots']==0 and row['architecture']['ownedResultsStable'];assert len(row['calls'])==3
  for call in row['calls']:
   if row['scope']=='ordinary-full-diagnostic':assert check_call(call,folder),(target,row['id'],call['prefix']);ordinary+=1
   else:assert(folder/(call['prefix']+'.error-class.bin')).read_bytes()==b'org.pkl.core.PklBugException';assert call['kind']=='error'and call['disposition']=='unsupported';internal+=1
 assert(ordinary,internal)==(156,12);assert not e['strictJavaCompatibilityPassed'];targets[target]={'ordinaryRawPass':ordinary,'javaInternalUnsupportedBoundaries':internal,'sharedEvaluatorFollowupsUnexecuted':56}
results['moduleinfo']={'reportSha256':sha(root/'execution.json'),'passed':True,'targets':targets}
# Security: actual policy-produced cause into typed resolution completion only.
root,e=record_identity('security-denial');froot=R/'tests/fixtures/m2-security-denial';targets={}
for target in ['node','browser']:
 rows=json.loads((root/(target+'.raw.json')).read_text());calls=0
 for row in rows:
  folder=froot/'oracle/repeats'/str(row['repeat'])/'calls';assert row['constructorError']is None and row['acquisitionError']is None and row['architecture']['terminalSlots']==0 and row['architecture']['ownedResultsStable'];assert len(row['calls'])==5 and len(row['denials'])==3
  for i,call in enumerate(row['calls']):assert check_call(call,folder),(target,i);assert call['denialsAfter']==[1,2,3,3,3][i];calls+=1
  for i,denial in enumerate(row['denials']):assert denial['kind']=='resolve'and denial['originalUri']==(froot/'denied-uri.txt').read_text();assert(folder/f'denial-{i}.error-class.bin').read_bytes()==b'org.pkl.core.SecurityManagerException'
 assert calls==10;targets[target]={'ordinaryRawApiPass':10,'actualTypedDeniedResolveCompletions':6,'fullNativeSecurityPolicyParity':False}
results['security-denial']={'reportSha256':sha(root/'execution.json'),'passed':True,'targets':targets,'scope':'Reference Standard-policy cause provenance and VM catch behavior,not general rawDenied/fullpolicy/source-load equivalence.'}
# Bootstrap: preserve all failures;also compare all three actual Rust execution targets.
root,e=record_identity('bootstrap');oracle=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42/target/m2/stage45-bootstrap-oracle-02');java=json.loads((oracle/'report.json').read_text());native=T/'stage45-bootstrap-native-final-01';nreport=json.loads((native/'report.json').read_text());nrows={(c['case'],c['repeat'],c['session'],c['prefix']):c for c in nreport['comparisons']if c['suite']=='bootstrap'};fixtures=json.loads((root/'fixture-data.json').read_text());targets={}
for target in ['node','browser']:
 rows=json.loads((root/(target+'.raw.json')).read_text());counts=collections.Counter();raw_matches=counter_only=shared=0
 for f,row in zip(fixtures,rows):
  for session in row['sessions']:
   assert session['constructorError']is None and session['acquisitionError']is None and session['architecture']['terminalSlots']==0 and session['architecture']['ownedResultsStable'];assert len(session['calls'])==25
   for call in session['calls']:
    old=next(c for c in f['expected']if c['session']==session['index']and c['prefix']==call['prefix']);prefix=Path(old['rawPrefix']);folder=oracle/prefix.parent;match=check_call(call,folder);raw_matches+=match;read_match=f['reader']!='counted'or(call['readsBefore']==old['readsBefore']and call['readsAfter']==old['readsAfter']);status='unsupported'if call['disposition']=='unsupported'else'pass'if match and read_match else'mismatch';counts[status]+=1;counter_only+=status=='mismatch'and match
    nr=nrows[(row['id'],row['repeat'],session['index'],call['prefix'])];nf=native/nr['actualDirectory'];assert unit_bytes(call['units'])==(nf/(call['prefix']+('.stdout.code-units.bin'if call['kind']=='value'else'.stderr.code-units.bin'))).read_bytes();assert (b'success\n'if call['kind']=='value'else b'error\n')==(nf/(call['prefix']+'.status.bin')).read_bytes();assert str(call['readsBefore']).encode()==(nf/(call['prefix']+'.reads-before.bin')).read_bytes();assert str(call['readsAfter']).encode()==(nf/(call['prefix']+'.reads-after.bin')).read_bytes();shared+=1
 assert counts=={'pass':194,'unsupported':192,'mismatch':214};assert shared==600;targets[target]={'counts':dict(counts),'rawJavaStringMatches':raw_matches,'counterOnlyMismatches':counter_only,'fullNativeNodeBrowserRawApiAndReadCountMatches':shared}
assert e['acquisitionPassed']and e['nodeBrowserSharedResults']and not e['strictJavaCompatibilityPassed'];results['bootstrap']={'reportSha256':sha(root/'execution.json'),'passedAcquisitionIntegrity':True,'strictCompatibilityPassed':False,'targets':targets}
rust5=json.loads((T/'stage45-rust5-02/report.json').read_text());launch=json.loads((T/'stage45-platform-launch-01/report.json').read_text());native_build=json.loads((T/'stage45-native-final-01/report.json').read_text())
def utc(value):return datetime.datetime.fromisoformat(value)
def fs_utc(path,field):return datetime.datetime.fromtimestamp(getattr(path.stat(),field),datetime.timezone.utc).isoformat()
assert utc(rust5['start_utc'])<utc(rust5['end_utc'])<utc(launch['started_utc'])<utc(launch['finished_utc'])
native_dir=T/'stage45-native-final-01';birth=fs_utc(native_dir,'st_birthtime');assert utc(launch['finished_utc'])<utc(birth)
chronology={'completePrePostManifestIncludesAll77ProductionInputs':True,'completePrePostInputCount':len(mapping),'rust5Utc':{'start':rust5['start_utc'],'end':rust5['end_utc'],'report':str(T/'stage45-rust5-02/report.json'),'reportSha256':sha(T/'stage45-rust5-02/report.json')},'exactM1WrapperAcquisitionUtc':{'start':launch['started_utc'],'end':launch['finished_utc'],'report':str(T/'stage45-platform-launch-01/report.json'),'reportSha256':sha(T/'stage45-platform-launch-01/report.json')},'perM1ArtifactBuildProcessUtc':'Not recorded separately;native/NAPI/Wasm command sequencing is recorded within exact wrapper interval.','nativeFinalBuild':{'elapsedSeconds':native_build['seconds'],'exactProcessUtc':'Not recorded;filesystemcopy/writebounds below are not relabeled processstart/end.','filesystemBoundsUtc':{'directoryBirth':birth,'sourceAfterWrite':fs_utc(native_dir/'source-after.json','st_mtime'),'buildReportWrite':fs_utc(native_dir/'report.json','st_mtime'),'artifactMetadataWrite':fs_utc(native_dir/'artifacts.json','st_mtime')},'ordering':'Nativefinaldirectory creation and snapshot/binarycopy capture followcompletedM1 wrapper;copy2beforemapmtimeis inherited and not usedasprocessUTC.'}}
report={'passed':True,'scope':'Independent rawcapture/input/source/artifact audit only. Explicit compatibility failures and internal/API boundaries remain failures/unexecuted.','chronology':chronology,'mainPlatformReportSha256':sha(platform/'report.json'),'finalSharedArtifacts':artifacts,'sourceBinding':source_binding,'audits':results};(A/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
