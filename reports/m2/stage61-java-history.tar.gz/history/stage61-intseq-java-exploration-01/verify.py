"""Offline whole-protocol and raw-channel check of the IntSeq Java exploration."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
CAPTURE = HERE / "capture-03"
ROOT = HERE.parents[2]
STRINGS = ("mode", "expression", "result.stdout", "result.stderr", "result.error-class",
           "result.exception-to-string", "result.cause-class", "result.cause-message",
           "result.cause-to-string", "result.java-type")
CHANNELS = {"result.status.bin"} | {name + suffix for name in STRINGS
                                    for suffix in (".bin", ".code-units.bin")}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def checked(folder, name):
    raw = (folder / (name + ".bin")).read_bytes()
    units = (folder / (name + ".code-units.bin")).read_bytes()
    need(len(units) % 2 == 0 and
         units.decode("utf-16-be", "surrogatepass").encode("utf-8", "replace") == raw,
         f"UTF-8/UTF-16 producer channels differ: {folder}/{name}")
    return raw.decode("utf-8")


def main():
    cases = json.loads((CAPTURE / "cases.json").read_bytes())
    provenance = json.loads((CAPTURE / "provenance.json").read_bytes())
    audit = json.loads((CAPTURE / "audit.json").read_bytes())
    rows = cases["rows"]
    need(len(rows) == 232 and cases["module_uri"] == "file:///stage61/intseq-exploration.pkl"
         and cases["repetitions"] == 2 and
         (CAPTURE / "queries.tsv").read_text() == "".join(
             f"{row['mode']}\t{row['id']}\t{row['expression']}\n" for row in rows),
         "authored input/order differs")
    need(len({row["id"] for row in rows}) == len(rows)
         and all(set(row) == {"id", "group", "mode", "expression"}
                 and re.fullmatch(r"[a-z0-9-]+", row["id"]) for row in rows),
         "authored row schema differs")
    need(provenance["stable"] and provenance["raw_equal"] and provenance["complete"]
         and provenance["raw_differences"] == [] and len(provenance["sessions"]) == 2,
         "capture stability or ordered repetition differs")
    need(provenance["input_before"] == provenance["input_after"] and
         provenance["source_before"] == provenance["source_after"] and
         provenance["artifact_sha256"] == provenance["artifact_after_sha256"],
         "pre/post identity differs")
    for name, expected in provenance["input_before"].items():
        need(sha(CAPTURE / name) == expected, f"copied input differs: {name}")
    for name, expected in provenance["source_before"].items():
        need(sha(CAPTURE / "sources" / name) == expected, f"copied source differs: {name}")
    lock = json.loads((CAPTURE / "sources/oracle.lock.json").read_bytes())
    need(lock["version"] == "0.32.0" and
         lock["source"]["revision"] == provenance["reference_revision"] and
         lock["artifact"]["sha256"] == provenance["artifact_sha256"],
         "reference source/artifact pin differs")
    need(all(provenance["jdk"]["properties"].get(name) == value
             for name, value in lock["jdk"]["properties"].items()),
         "JDK property pin differs")
    need(provenance["sessions"][0]["repeat"] == 0 and
         provenance["sessions"][1]["repeat"] == 1 and
         provenance["sessions"][0]["pid"] != provenance["sessions"][1]["pid"] and
         provenance["sessions"][0]["finished_epoch"] <= provenance["sessions"][1]["started_epoch"],
         "fresh ordered JVM identity differs")
    observations = []
    raw_hashes = []
    session_counts = []
    for session in provenance["sessions"]:
        repeat = session["repeat"]
        folder = CAPTURE / f"repeat-{repeat}"
        need(session["exit_code"] == 0 and session["query_directories"] == len(rows),
             "Java process coverage differs")
        for stream in ("stdout", "stderr"):
            path = folder / f"process.{stream}.bin"
            need(sha(path) == session[stream + "_sha256"] and
                 path.stat().st_size == session[stream + "_bytes"],
                 "raw process channel differs")
        need((folder / "process.stderr.bin").read_bytes() == b"", "Java process stderr differs")
        protocol = [f"session-open mode=mixed rows={len(rows)}"]
        counts = Counter()
        hash_set = {}
        for index, row in enumerate(rows):
            case = folder / f"{index:03d}-{row['id']}"
            need(case.is_dir() and {path.name for path in case.iterdir()} == CHANNELS,
                 f"row channel set differs: {row['id']}")
            need(checked(case, "mode") == row["mode"] and
                 checked(case, "expression") == row["expression"],
                 f"executed query differs: {row['id']}")
            values = {name: checked(case, name) for name in STRINGS[2:]}
            status = (case / "result.status.bin").read_bytes()
            need(status in (b"success\n", b"error\n", b"oracle-error\n", b"api-exception\n"),
                 "row status differs")
            if status == b"success\n":
                need(all(values[name] == "" for name in (
                    "result.stderr", "result.error-class", "result.exception-to-string",
                    "result.cause-class", "result.cause-message", "result.cause-to-string")),
                    "success metadata differs")
            else:
                cls = values["result.error-class"]
                need(values["result.stdout"] == "" and values["result.stderr"] and
                     cls and values["result.exception-to-string"].startswith(cls + ": "),
                     "failure metadata differs")
            clean = status.decode().strip()
            counts[clean] += 1
            call = f"{row['mode']}-{index}-{row['id']}"
            protocol.extend((f"call-enter={call}", f"call-exit={call} status={clean}"))
            for path in case.iterdir():
                hash_set[path.relative_to(folder).as_posix()] = sha(path)
            if repeat == 0:
                stderr = values["result.stderr"].splitlines()
                observations.append({"id": row["id"], "group": row["group"],
                                     "mode": row["mode"], "expression": row["expression"],
                                     "status": clean, "stdout_sha256": sha(case / "result.stdout.bin"),
                                     "stderr_sha256": sha(case / "result.stderr.bin"),
                                     "stdout": values["result.stdout"],
                                     "first_error_line": stderr[1] if len(stderr) > 1 else "",
                                     "error_class": values["result.error-class"]})
        protocol.append(f"session-closed mode=mixed rows={len(rows)} public-calls={len(rows)} "
                        f"success={counts['success']} errors={len(rows)-counts['success']}")
        need((folder / "process.stdout.bin").read_bytes() == ("\n".join(protocol) + "\n").encode(),
             "complete process protocol differs")
        hash_set["process.stdout.bin"] = sha(folder / "process.stdout.bin")
        hash_set["process.stderr.bin"] = sha(folder / "process.stderr.bin")
        need(len(hash_set) == provenance["raw_files"] == len(rows) * len(CHANNELS) + 2,
             "session raw file count differs")
        raw_hashes.append(hash_set)
        session_counts.append(dict(counts))
    need(raw_hashes[0] == raw_hashes[1], "raw repetition files differ")
    need(session_counts == [{"success": 190, "error": 42}] * 2,
         "exploratory status vector differs")
    expected_audit = {"schema": 1, "scope": provenance["scope"], "rows": len(rows),
                      "statuses": session_counts[0], "observations": observations,
                      "candidate_compatibility_passes_claimed": 0,
                      "limits": ["Exploratory authored expressions only; original upstream snippets are source evidence, not replayed modules.",
                                 "Rust, browser, Node, typed export adapters, full M2 and performance gates remain unverified."]}
    need(audit == expected_audit, "derived raw audit differs")
    report = {"schema": 1, "capture": "target/m2/stage61-intseq-java-exploration-01/capture-03",
              "rows": len(rows), "statuses_per_session": session_counts[0],
              "fresh_ordered_jvms": [session["pid"] for session in provenance["sessions"]],
              "raw_files_per_session": provenance["raw_files"], "raw_repetitions_equal": True,
              "source_and_input_stable": True, "whole_protocol_verified": True,
              "candidate_compatibility_passes_claimed": 0,
              "verifier_sha256": sha(HERE / "verify.py"),
              "provenance_sha256": sha(CAPTURE / "provenance.json"),
              "audit_sha256": sha(CAPTURE / "audit.json")}
    (HERE / "verification.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
