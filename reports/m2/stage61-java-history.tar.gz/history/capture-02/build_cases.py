"""Author bounded Stage 61 IntSeq Java-only exploratory expressions."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
rows = []

def add(group, name, expr, mode="string"):
    assert all(row["id"] != name for row in rows), name
    assert "\t" not in expr and "\n" not in expr
    rows.append({"id": name, "group": group, "expression": expr, "mode": mode})

values = {
    "asc": "IntSeq(1, 4)",
    "zero": "IntSeq(0, 0)",
    "one": "IntSeq(1, 1)",
    "empty": "IntSeq(5, 2)",
    "empty-neg": "IntSeq(0, 2).step(-1)",
    "desc": "IntSeq(5, 1).step(-1)",
    "desc-two": "IntSeq(5, 0).step(-2)",
    "asc-two": "IntSeq(0, 5).step(2)",
    "asc-over": "IntSeq(0, 1).step(3)",
    "cross": "IntSeq(-3, 2).step(2)",
    "min-single": "IntSeq(minInt, minInt)",
    "max-single": "IntSeq(maxInt, maxInt)",
    "extreme-up": "IntSeq(minInt, maxInt).step(maxInt)",
    "extreme-down": "IntSeq(maxInt, minInt).step(minInt)",
    "min-step-empty": "IntSeq(0, 1).step(minInt)",
}
for name, value in values.items():
    for prop in ("start", "end", "step"):
        add("properties", f"{name}-{prop}", f"{value}.{prop}")
    add("representation", f"{name}-string", f"{value}.toString()")

for name in ("asc", "zero", "one", "empty", "empty-neg", "desc", "desc-two", "asc-two", "asc-over", "cross", "min-single", "max-single", "extreme-up", "extreme-down", "min-step-empty"):
    value = values[name]
    add("bounded-iteration", f"{name}-list", f"{value}.toList()")
    add("bounded-iteration", f"{name}-map", f"{value}.map((n) -> n)")
    add("bounded-iteration", f"{name}-fold", f"{value}.fold(List(), (acc, n) -> acc.add(n))")
    if name not in ("extreme-up", "extreme-down"):
        add("bounded-iteration", f"{name}-listing", f"{value}.toListing()")

pairs = [
    ("same", "IntSeq(2,5)", "IntSeq(2,5)"),
    ("different", "IntSeq(2,5)", "IntSeq(2,6)"),
    ("empty-origins", "IntSeq(5,2)", "IntSeq(100,0)"),
    ("empty-direction", "IntSeq(5,2)", "IntSeq(0,2).step(-1)"),
    ("aligned-end-up", "IntSeq(0,4).step(2)", "IntSeq(0,5).step(2)"),
    ("aligned-end-down", "IntSeq(5,1).step(-2)", "IntSeq(5,0).step(-2)"),
    ("singleton-step", "IntSeq(1,1)", "IntSeq(1,1).step(2)"),
    ("singleton-negative", "IntSeq(1,1)", "IntSeq(1,1).step(-1)"),
    ("nondivisible-step", "IntSeq(0,5).step(2)", "IntSeq(0,4).step(2)"),
    ("opposite-direction", "IntSeq(1,3)", "IntSeq(3,1).step(-1)"),
    ("cross-type-list", "IntSeq(1,3)", "List(1,2,3)"),
    ("extreme-up-self", "IntSeq(minInt,maxInt).step(maxInt)", "IntSeq(minInt,maxInt).step(maxInt)"),
]
for name,left,right in pairs:
    add("equality-hash", f"eq-{name}", f"{left} == {right}")
    add("equality-hash", f"neq-{name}", f"{left} != {right}")
for name,expr in [
    ("set-empty", "Set(IntSeq(5,2),IntSeq(100,0)).length"),
    ("set-aligned", "Set(IntSeq(0,4).step(2),IntSeq(0,5).step(2)).length"),
    ("set-singleton-step", "Set(IntSeq(1,1),IntSeq(1,1).step(2)).length"),
    ("map-empty", "Map(IntSeq(5,2),\"a\",IntSeq(100,0),\"b\").length"),
    ("map-aligned", "Map(IntSeq(0,4).step(2),\"a\",IntSeq(0,5).step(2),\"b\").length"),
    ("map-singleton-step", "Map(IntSeq(1,1),\"a\",IntSeq(1,1).step(2),\"b\").length"),
    ("set-threshold-five", "Set(IntSeq(1,1),IntSeq(2,2),IntSeq(3,3),IntSeq(4,4),IntSeq(1,1)).length"),
]: add("equality-hash", name, expr)

for name,seq in [("asc", "IntSeq(1,3)"),("empty", "IntSeq(3,1)"),("desc", "IntSeq(3,1).step(-1)"),("step", "IntSeq(0,5).step(2)"),("extreme-up",values["extreme-up"]),("extreme-down",values["extreme-down"])]:
    add("generator", f"for-values-{name}", f"new Listing {{ for (n in {seq}) {{ n }} }}")
    add("generator", f"for-pairs-{name}", f"new Listing {{ for (i, n in {seq}) {{ Pair(i,n) }} }}")
    add("generator", f"spread-listing-{name}", f"new Listing {{ ...{seq} }}")
    add("generator", f"spread-dynamic-{name}", f"new Dynamic {{ ...{seq} }}")
for name,expr in [
    ("typed-for-key", "new Listing { for (i: String, n: Int in IntSeq(1,3)) { n } }"),
    ("typed-for-value", "new Listing { for (i: Int, n: String in IntSeq(1,3)) { n } }"),
    ("typed-for-empty-key", "new Listing { for (i: String, n: Int in IntSeq(3,1)) { n } }"),
    ("typed-for-empty-value", "new Listing { for (i: Int, n: String in IntSeq(3,1)) { n } }"),
    ("spread-mapping", "new Mapping { ...IntSeq(1,3) }"),
    ("spread-empty-mapping", "new Mapping { ...IntSeq(3,1) }"),
    ("spread-typed-object", "new SeqHolder { ...IntSeq(1,3) }"),
    ("spread-empty-typed-object", "new SeqHolder { ...IntSeq(3,1) }"),
]: add("generator-errors", name, expr)

for name,expr in [
    ("class", "IntSeq(1,3).getClass().simpleName"),
    ("string", "IntSeq(1,3).toString()"),
    ("ifnonnull-start", "IntSeq(1,3).ifNonNull((x) -> x.start)"),
    ("ifnonnull-length", "IntSeq(1,3).ifNonNull((x) -> x.length)"),
    ("is-intseq", "IntSeq(1,3) is IntSeq"),
    ("is-list", "IntSeq(1,3) is List"),
    ("as-intseq", "IntSeq(1,3) as IntSeq"),
    ("missing-length", "IntSeq(1,3).length"),
    ("missing-isempty", "IntSeq(1,3).isEmpty"),
    ("missing-subscript", "IntSeq(1,3)[0]"),
    ("missing-plus", "IntSeq(1,3) + IntSeq(4,5)"),
    ("missing-member", "IntSeq(1,3).unknown"),
]: add("any", name, expr)

for name,expr in [
    ("ctor-arity-none", "IntSeq()"),
    ("ctor-arity-one", "IntSeq(1)"),
    ("ctor-arity-three", "IntSeq(1,2,3)"),
    ("ctor-string-first", "IntSeq(\"1\",2)"),
    ("ctor-string-second", "IntSeq(1,\"2\")"),
    ("ctor-null-first", "IntSeq(null,2)"),
    ("ctor-throw-first", "IntSeq(throw(\"first\"),throw(\"second\"))"),
    ("ctor-throw-second", "IntSeq(1,throw(\"second\"))"),
    ("step-zero", "IntSeq(1,3).step(0)"),
    ("step-string", "IntSeq(1,3).step(\"2\")"),
    ("step-null", "IntSeq(1,3).step(null)"),
    ("step-missing", "IntSeq(1,3).step()"),
    ("step-extra", "IntSeq(1,3).step(1,2)"),
    ("step-throw", "IntSeq(1,3).step(throw(\"step\"))"),
    ("map-missing", "IntSeq(1,3).map()"),
    ("map-wrong-type", "IntSeq(1,3).map(1)"),
    ("map-wrong-arity", "IntSeq(1,3).map((a,b) -> a+b)"),
    ("map-empty-wrong-arity", "IntSeq(3,1).map((a,b) -> a+b)"),
    ("map-callback-throw", "IntSeq(1,3).map((n) -> throw(n.toString()))"),
    ("fold-missing", "IntSeq(1,3).fold(0)"),
    ("fold-wrong-type", "IntSeq(1,3).fold(0,1)"),
    ("fold-wrong-arity", "IntSeq(1,3).fold(0,(a)->a)"),
    ("fold-empty-wrong-arity", "IntSeq(3,1).fold(0,(a)->a)"),
    ("fold-empty-initial", "IntSeq(3,1).fold(\"seed\",(a,n)->a+n.toString())"),
    ("fold-callback-throw", "IntSeq(1,3).fold(0,(a,n)->throw(n.toString()))"),
    ("tolist-extra", "IntSeq(1,3).toList(1)"),
    ("tolisting-extra", "IntSeq(1,3).toListing(1)"),
    ("new-intseq", "new IntSeq {}"),
]: add("errors", name, expr)

for name,expr in [
    ("export-asc", "IntSeq(1,3)"),
    ("export-empty", "IntSeq(3,1)"),
    ("export-extreme", "IntSeq(minInt,maxInt).step(maxInt)"),
]: add("public-export", name, expr, "export")

module = '''// Stage61 bounded IntSeq Java exploration; no Rust candidate.
+import "pkl:math"
+class SeqHolder { value: Int = 0 }
+minInt = math.minInt
+maxInt = math.maxInt
+marker = "stage61-intseq"
+'''.replace("\n+", "\n")
(ROOT / "module.pkl").write_text(module)
manifest = {"schema": 1, "baseline": "Pkl 0.32.0", "module_uri": "file:///stage61/intseq-exploration.pkl",
            "boundary": "public-string-and-typed-export", "repetitions": 2, "rows": rows,
            "materialization_policy": "All rows expected bounded by authored sequence cardinality; extreme calculations inspected against pinned VmIntSeq before capture."}
(ROOT / "cases.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
(ROOT / "queries.tsv").write_text("".join(f"{row['mode']}\t{row['id']}\t{row['expression']}\n" for row in rows))
from collections import Counter
print(len(rows), dict(Counter(row["group"] for row in rows)))
