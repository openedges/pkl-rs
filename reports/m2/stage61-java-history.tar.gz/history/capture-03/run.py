"""Acquire two independent pinned Java 0.32.0 public IntSeq exploratory sessions."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "capture-03"
INPUTS = ("build_cases.py", "IntSeqExplore.java", "run.py", "module.pkl", "queries.tsv", "cases.json")
SOURCES = (
    "external/pkl/stdlib/base.pkl",
    "external/pkl/stdlib/math.pkl",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmIntSeq.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/IntSeqNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/BaseNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/generator/GeneratorForNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/generator/GeneratorSpreadNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmValueRenderer.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/PcfRenderer.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/JsonRendererNodes.java",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/intseq.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/intseq.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/bytes.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/bytes.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/any.pkl",
    "oracle.lock.json", "references.lock",
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def files(root):
    return {path.relative_to(root).as_posix(): sha(path) for path in root.rglob("*") if path.is_file()}


def main():
    if OUTPUT.exists():
        raise ValueError("fresh IntSeq exploration output required")
    lock = json.loads((ROOT / "oracle.lock.json").read_bytes())
    if lock["version"] != "0.32.0" or lock["source"]["revision"] != "e51fb2f91774265666f94980ec630db794a4db2d":
        raise ValueError("oracle source pin differs")
    jar = ROOT / ".cache/oracle" / lock["artifact"]["filename"]
    if sha(jar) != lock["artifact"]["sha256"]:
        raise ValueError("oracle artifact differs")
    cases = json.loads((HERE / "cases.json").read_bytes())
    rows = cases["rows"]
    if cases["module_uri"] != "file:///stage61/intseq-exploration.pkl" or len(rows) != 232:
        raise ValueError("authored row set differs")
    if (HERE / "queries.tsv").read_text() != "".join(
            f"{row['mode']}\t{row['id']}\t{row['expression']}\n" for row in rows):
        raise ValueError("authored ordered queries differ")
    OUTPUT.mkdir()
    for name in INPUTS:
        shutil.copyfile(HERE / name, OUTPUT / name)
    for name in SOURCES:
        target = OUTPUT / "sources" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    java = Path(os.environ.get("PKL_ORACLE_JAVA", "/usr/bin/java")).resolve()
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC",
           "TERM": "dumb", "NO_COLOR": "1", "COLUMNS": "80"}
    identity = subprocess.run([str(java), "-XshowSettings:properties", "-version"], cwd=OUTPUT,
                              env=env, capture_output=True, timeout=60)
    (OUTPUT / "java-identity.stdout.bin").write_bytes(identity.stdout)
    (OUTPUT / "java-identity.stderr.bin").write_bytes(identity.stderr)
    if identity.returncode:
        raise ValueError("Java identity failed; raw output retained")
    properties = dict(re.findall(r"^\s+([\w.]+) = (.*)$", identity.stderr.decode(), re.M))
    for name, value in lock["jdk"]["properties"].items():
        if properties.get(name) != value:
            raise ValueError(f"pinned Java property {name} differs; raw output retained")
    home = Path(properties["java.home"])
    jdk = {"executable": str(java), "executable_sha256": sha(java),
           "modules_sha256": sha(home / "lib/modules"), "release_sha256": sha(home / "release"),
           "properties": properties}
    options = [*lock["jvm_options"], f"-Duser.home={env['HOME']}", f"-Djava.io.tmpdir={env['TMPDIR']}"]
    provenance = {"schema": 1, "scope": "Independent public IntSeq Java string and typed-export exploration; no Rust candidate",
                  "host": platform.platform(), "oracle_lock_sha256": sha(ROOT / "oracle.lock.json"),
                  "references_lock_sha256": sha(ROOT / "references.lock"),
                  "reference_revision": lock["source"]["revision"],
                  "artifact": str(jar), "artifact_sha256": sha(jar), "jdk": jdk, "environment": env,
                  "input_before": {name: sha(OUTPUT / name) for name in INPUTS},
                  "source_before": {name: sha(ROOT / name) for name in SOURCES}, "sessions": []}
    save(OUTPUT / "provenance.json", provenance)
    for repeat in range(2):
        folder = OUTPUT / f"repeat-{repeat}"
        folder.mkdir()
        command = [str(java), *options, "-cp", str(jar), str(OUTPUT / "IntSeqExplore.java"),
                   str(folder), str(OUTPUT), cases["module_uri"]]
        started = time.time()
        process = subprocess.Popen(command, cwd=OUTPUT, env=env,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            stdout, stderr = process.communicate(timeout=240)
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            (folder / "process.stdout.bin").write_bytes(stdout)
            (folder / "process.stderr.bin").write_bytes(stderr)
            raise ValueError("Java session timed out; raw attempt retained")
        (folder / "process.stdout.bin").write_bytes(stdout)
        (folder / "process.stderr.bin").write_bytes(stderr)
        entry = {"repeat": repeat, "pid": process.pid, "command": command, "cwd": str(OUTPUT),
                 "exit_code": process.returncode, "started_epoch": started, "finished_epoch": time.time(),
                 "stdout_sha256": sha(folder / "process.stdout.bin"),
                 "stderr_sha256": sha(folder / "process.stderr.bin"),
                 "stdout_bytes": len(stdout), "stderr_bytes": len(stderr),
                 "query_directories": sum(path.is_dir() for path in folder.iterdir())}
        provenance["sessions"].append(entry)
        save(OUTPUT / "provenance.json", provenance)
        print(json.dumps({"repeat": repeat, "pid": process.pid, "exit_code": process.returncode,
                          "rows": entry["query_directories"]}), flush=True)
        if process.returncode or entry["query_directories"] != len(rows):
            raise ValueError("Java session failed; raw attempt retained")
    provenance["input_after"] = {name: sha(OUTPUT / name) for name in INPUTS}
    provenance["source_after"] = {name: sha(ROOT / name) for name in SOURCES}
    provenance["artifact_after_sha256"] = sha(jar)
    provenance["stable"] = (provenance["input_before"] == provenance["input_after"] and
                            provenance["source_before"] == provenance["source_after"] and
                            provenance["artifact_sha256"] == provenance["artifact_after_sha256"])
    first, second = files(OUTPUT / "repeat-0"), files(OUTPUT / "repeat-1")
    provenance["raw_equal"] = first == second
    provenance["raw_files"] = len(first)
    provenance["raw_differences"] = [name for name in sorted(first.keys() | second.keys())
                                     if first.get(name) != second.get(name)]
    provenance["complete"] = provenance["stable"] and provenance["raw_equal"] and len(provenance["sessions"]) == 2
    save(OUTPUT / "provenance.json", provenance)
    observations = []
    for index, row in enumerate(rows):
        folder = OUTPUT / "repeat-0" / f"{index:03d}-{row['id']}"
        status = (folder / "result.status.bin").read_text().strip()
        stderr = (folder / "result.stderr.bin").read_text()
        observations.append({"id": row["id"], "group": row["group"], "mode": row["mode"],
                             "expression": row["expression"], "status": status,
                             "stdout_sha256": sha(folder / "result.stdout.bin"),
                             "stderr_sha256": sha(folder / "result.stderr.bin"),
                             "stdout": (folder / "result.stdout.bin").read_text(),
                             "first_error_line": stderr.splitlines()[1] if len(stderr.splitlines()) > 1 else "",
                             "error_class": (folder / "result.error-class.bin").read_text()})
    audit = {"schema": 1, "scope": provenance["scope"], "rows": len(observations),
             "statuses": dict(Counter(row["status"] for row in observations)),
             "observations": observations, "candidate_compatibility_passes_claimed": 0,
             "limits": ["Exploratory authored expressions only; original upstream snippets are source evidence, not replayed modules.",
                        "Rust, browser, Node, typed export adapters, full M2 and performance gates remain unverified."]}
    save(OUTPUT / "audit.json", audit)
    if not provenance["complete"]:
        raise ValueError("acquisition incomplete; raw attempt retained")
    print(json.dumps(audit["statuses"], sort_keys=True))


if __name__ == "__main__":
    main()
