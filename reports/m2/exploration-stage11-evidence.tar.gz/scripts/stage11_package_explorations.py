"""Preserve fixed-property observations, including superseded failures and drafts."""
from pathlib import Path
import sys,json,shutil,collections,subprocess
sys.path.insert(0,'tools')
import oracle,evidence,m2_language as l
out=Path(sys.argv[1]).resolve();replay=Path(sys.argv[2]).resolve();extra=[Path(x).resolve()for x in sys.argv[3:]];out.mkdir(exist_ok=False)
observations=json.loads(Path('target/m2/stage11-java-observations.json').read_bytes())
baselines=[Path(p)for p in observations['baselines']]
names=[*baselines,Path('target/m2/stage11-carry-java-01'),Path('target/m2/stage11-candidate-debug-replay-01'),Path('target/m2/stage11-carry-debug-replay-01'),Path('target/m2/stage11-selection-baseline-01'),Path('target/m2/stage11-actual-uri-01'),Path('target/m2/stage11-actual-uri-02'),Path('target/m2/stage11-platform-java-01'),Path('target/m2/stage11-class-retry-java-01'),Path('target/m2/stage11-class-retry-java-02'),Path('target/m2/stage11-class-retry-rust-01'),Path('target/m2/stage11-release-build-01'),Path('target/m2/stage11-release-build-02'),replay,*extra]
for src in names:
 assert src.is_dir(),src
 index=src/'evidence-sha256.json'
 if index.exists():
  for rel,sha in json.loads(index.read_bytes()).items():assert oracle.sha256(src/rel)==sha,(src,rel)
 assert not(out/src.name).exists(),src
 shutil.copytree(src,out/src.name)
# Preserve exact scripts, matrices, author logs, promotion and draft-category summary.
scripts=out/'scripts';scripts.mkdir()
for path in sorted(Path('target/m2').glob('stage11*')):
 if path.is_file()and path.suffix in('.py','.json','.log'):
  shutil.copy2(path,scripts/path.name)
# Selected upstream snippets retain their original names and pinned dependency bytes.
pinned=out/'additional-pinned-upstream';identities={}
for base in baselines:
 for row in json.loads((base/'matrix.json').read_bytes()):
  if not row.get('input'):continue
  src=Path(row['input']);relative=str(src.relative_to('external/pkl'))
  data=subprocess.run(['git','-C','external/pkl','show','e51fb2f91774265666f94980ec630db794a4db2d:'+relative],check=True,capture_output=True).stdout
  assert src.read_bytes()==data
  dest=pinned/src;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);identities[str(src)]=oracle.sha256(dest)
rows=json.loads((replay/'results.json').read_bytes());actual_dir=Path('target/m2/stage11-actual-uri-02');actual=json.loads((actual_dir/'results.json').read_bytes());promotion=json.loads(Path('target/m2/stage11-promotion.json').read_bytes())
assert len(rows)==111 and len(actual)==promotion['selected_count']and all(r['status']=='pass'for r in actual)
summary=dict(schema_version=1,scope='Bounded fixed-property evaluateExpressionString observations. Upstream selected-expression calls do not execute their original LanguageSnippetTests/assertion/renderer contracts. Full language, reflection, public API, lifecycle and performance compatibility remain unproven. No new development exceptions.',java_observations=observations,native_java_calls=111,additional_java_acquisition_counts=dict(superseded_carry_metadata_calls=3,partial_actual_uri_calls=78,complete_actual_uri_calls=89),upstream_selected_expression_calls=14,additional_pinned_upstream=identities,final_exploratory_comparison=dict(cases=len(rows),counts=dict(collections.Counter(r['status']for r in rows)),known_remaining=[dict(exploration=Path(r['baseline']).name,id=r['id'],java_exception_class=(Path(r['baseline'])/'cases'/r['id']/'java.outcome.bin').read_text())for r in rows if r['status']!='pass'],source_binding='Frozen caller-supplied candidate with copied source snapshots; no recorded-build source binding is inferred. Formal final acquisition is separate.'),partial_actual_uri_capture=dict(path='stage11-actual-uri-01',reason='Author staging helper failed at first relation metadata construction; partial raw captures and fixture bytes preserved. Fresh complete acquisition uses stage11-actual-uri-02.'),actual_fixture_uri_comparison=dict(cases=len(actual),counts=dict(collections.Counter(r['status']for r in actual)),metamorphic_relations_added=2,total_selected=promotion['total_selected'],total_relations=46,original1202_definitions_and_input_bytes_preserved=True),persistent_evaluator_java=dict(scope='stage11-class-retry-java-01 and -02 use a separate same-evaluator multi-expression protocol; not counted among independent native111 cases.',rust_comparison=json.loads(Path('target/m2/stage11-class-retry-rust-01/comparison.json').read_bytes()),limitation='First raw error matches; Java retains a partially initialized class for subsequent accesses while Rust retries and repeats the error. This lifecycle mismatch remains open without a development exception.'),platform_java='Separately scoped captures at exact browser/Node module URI; retained helper, provenance, process and raw channels. Not counted among native111.',reused_baseline_archives=[dict(path=str(p),sha256=oracle.sha256(p))for p in [Path('reports/m2/language-stage10-final-evidence.tar.gz'),Path('reports/m2/exploration-stage10-followup-evidence.tar.gz')]],reused_observation_comparisons=[str(p)for p in extra],excluded=json.loads((actual_dir/'excluded.json').read_bytes()))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');evidence.create(out,Path('reports/m2/exploration-stage11-evidence.tar.gz'),[]);print(json.dumps({k:v for k,v in summary.items()if k not in('java_observations','excluded','additional_pinned_upstream')},indent=2))
