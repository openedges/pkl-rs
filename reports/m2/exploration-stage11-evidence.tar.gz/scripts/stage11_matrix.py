"""Bounded fixed-property probes; upstream selected expressions are observations only."""
from pathlib import Path
import json
rows=[]
def add(identifier, source, failure=False, group='fixed-declaration', expression='result', **extra):
 rows.append(dict(id=identifier,source=source,expression=expression,expected_outcome='failure'if failure else'success',group=group,**extra))
add('module-fixed-value','fixed p: String = "ok"\nresult = p\n')
add('class-fixed-value','class A { fixed p: String = "ok" }\nresult = new A {}.p\n')
add('fixed-derived-late-binding','class A { n: Int = 2; fixed p: Int = n + 1 }\nresult = new A { n = 8 }.p\n')
add('fixed-default-literal','class A { fixed p: "ok" }\nresult = new A {}.p\n')
add('fixed-default-nullable','class A { fixed p: String? }\nresult = new A {}.p == null\n')
add('fixed-default-missing','class A { fixed p: String }\nresult = new A {}.p\n',True)
add('fixed-typecheck','class A { fixed p: Int = "bad" }\nresult = new A {}.p\n',True)
for ident,decl in [('duplicate','fixed fixed p = 1'),('local','local fixed p = 1'),('const','const fixed p = 1'),('abstract','abstract fixed p: Int')]:
 add('module-modifier-'+ident,decl+'\nresult = 1\n',True,'modifier-validation')
for ident,decl,expression in [('hidden','hidden fixed p: Int = 1','new A {}.p'),('local','local fixed p: Int = 1','A'),('abstract','abstract fixed p: Int','A'),('const','const fixed p: Int = 1','A')]:
 add('class-modifier-'+ident,'abstract class A { '+decl+' }\nresult = '+expression+'\n',ident!='hidden','modifier-validation')
for ident,source in [('method','fixed function p() = 1'),('class','fixed class A'),('module','fixed module example'),('object','result = new Dynamic { fixed p = 1 }'),('listing','result = new Listing { fixed p = 1 }')]:
 add('invalid-fixed-'+ident,source+'\n'+('result = 1\n'if ident not in ('object','listing')else''),True,'modifier-validation')
add('fixed-unused-initializer','class A { fixed p: Int = throw("unused initializer") }\nresult = new A {}.getClass() == A\n',group='lazy-order')
add('fixed-unused-bad-type','class A { fixed p: Missing = throw("body") }\nresult = "ok"\n',group='lazy-order')
add('fixed-class-forces-bad-type','class A { fixed p: Missing = throw("body") }\nresult = A\n',True,'lazy-order')
add('fixed-class-keeps-body-lazy','class A { fixed p: Int = throw("body") }\nresult = A == A\n',group='lazy-order')
add('fixed-throw-before-later','class A { fixed p: Int = throw("fixed first"); q: Int = throw("later") }\nresult = new A {}.p\n',True,'lazy-order')
# Inheritance fixedness is checked during class initialization, not member forcing.
for ident,parent,child,failure in [('preserve','fixed p: Int = 1','fixed p: Int = 2',False),('drop','fixed p: Int = 1','p: Int = 2',True),('add','p: Int = 1','fixed p: Int = 2',True),('plain','p: Int = 1','p: Int = 2',False),('hidden-preserve','hidden fixed p: Int = 1','hidden fixed p: Int = 2',False),('hidden-drop','hidden fixed p: Int = 1','hidden p: Int = 2',True),('fixed-to-const','fixed p: Int = 1','const p: Int = 2',True),('const-to-fixed','const p: Int = 1','fixed p: Int = 2',True),('const-preserve','const p: Int = 1','const p: Int = 2',False)]:
 add('inherit-'+ident,f'open class A {{ {parent} }}\nclass B extends A {{ {child} }}\nresult = new B {{}}.p\n',failure,'inheritance')
add('inherit-indirect-fixed','open class A { fixed p: Int = 1 }\nopen class B extends A\nclass C extends B { fixed p: Int = 3 }\nresult = new C {}.p\n',group='inheritance')
add('inherit-indirect-drop','open class A { fixed p: Int = 1 }\nopen class B extends A\nclass C extends B { p: Int = 3 }\nresult = C\n',True,'inheritance')
add('inherit-unforced-bad-override','open class A { fixed p: Int = 1 }\nclass B extends A { p: Int = 2 }\nresult = "ok"\n',group='lazy-order')
add('inherit-class-bad-override','open class A { fixed p: Int = 1 }\nclass B extends A { p: Int = throw("body") }\nresult = B\n',True,'lazy-order')
add('inherit-type-before-fixed','open class A { fixed p: Int = 1 }\nclass B extends A { p: Missing = throw("body") }\nresult = B\n',True,'lazy-order')
add('inherit-first-property-error','open class A { fixed first: Int = 1; fixed second: Int = 2 }\nclass B extends A { first = 3; second = 4 }\nresult = B\n',True,'lazy-order')
add('inherit-abstract-default','abstract class A { fixed p: Int }\nclass B extends A { fixed p: Int = 2 }\nresult = new B {}.p\n',group='inheritance')
add('inherit-narrow-default','abstract class A { fixed p: String }\nclass B extends A { fixed p: "ok" }\nresult = new B {}.p\n',group='inheritance')
add('inherit-local-shadows-fixed','open class A { fixed p: Int = 1 }\nclass B extends A { local p: Int = 2; q: Int = p }\nresult = new B {}.q\n',group='inheritance')
add('inherit-fixed-shadows-local','open class A { local p: Int = 1 }\nclass B extends A { fixed p: Int = 2 }\nresult = new B {}.p\n',group='inheritance')
for ident,statement,expr in [('constant','p = 2','new A { p = 2 }.p'),('computed','local n = 2; p = n','new A { local n = 2; p = n }.p'),('throw','p = throw("rhs")','new A { p = throw("rhs") }.p'),('other-force','p = 2','new A { p = 2 }.q')]:
 add('instance-assign-'+ident,'class A { fixed p: Int = 1; q: Int = 9 }\nresult = '+expr+'\n',ident!='other-force','instance-assignment')
add('instance-unused-object','class A { fixed p: Int = 1 }\nlocal bad = new A { p = 2 }\nresult = "ok"\n',group='lazy-order')
add('instance-fixed-rhs-versus-body','class A { fixed p: Int = throw("base body") }\nresult = new A { p = throw("override body") }.p\n',True,'lazy-order')
add('instance-indirect-assign','open class A { fixed p: Int = 1 }\nclass B extends A\nresult = new B { p = 2 }.p\n',True,'instance-assignment')
add('instance-fixed-object-local-shadow','class A { fixed p: Int = 1; q: Int = p }\nresult = new A { local p = 2 }.q\n',group='instance-assignment')
add('instance-hidden-fixed','class A { hidden fixed p: Int = 1 }\nresult = new A { p = 2 }.p\n',True,'instance-assignment')
add('instance-const','class A { const p: Int = 1 }\nresult = new A { p = 2 }.p\n',True,'instance-assignment')
for ident,body,expression in [('object','p { n = 2 }','new A { p { n = 2 } }.p.n'),('assignment','p = new Dynamic { n = 2 }','new A { p = new Dynamic { n = 2 } }.p.n'),('other-force','p { n = 2 }','new A { p { n = 2 } }.q')]:
 add('instance-amend-'+ident,'class A { fixed p: Dynamic = new { n = 1 }; q: Int = 9 }\nresult = '+expression+'\n',ident!='other-force','instance-amendment')
add('instance-amend-direct','class A { fixed p: Int = 1 }\nlocal a = new A {}\nresult = (a) { p = 2 }.p\n',True,'instance-amendment')
add('instance-amend-empty','class A { fixed p: Int = 1 }\nlocal a = new A {}\nresult = (a) {}.p\n',group='instance-amendment')
add('amend-extracted-fixed-value','class A { fixed p: Dynamic = new { n = 1 } }\nlocal a = new A {}\nresult = (a.p) { n = 2 }.n\n',group='instance-amendment')
ref='import "pkl:ref"\nclass D extends ref.Domain { function renderReference(r): String = "ok" }\nlocal d = new D {}\n'
for ident,decl,klass,prop,failure in [('fixed','class A { fixed p: String = throw("referent") }','A','p',False),('hidden','class A { hidden fixed p: String = throw("referent") }','A','p',False),('inherited','open class A { fixed p: String = throw("referent") }\nclass B extends A','B','p',False),('indirect','open class A { fixed p: String = throw("referent") }\nopen class B extends A\nclass C extends B','C','p',False),('override','open class A { fixed p: String | Int = throw("referent") }\nclass B extends A { fixed p: String = throw("override") }','B','p',False),('invalid-override','open class A { fixed p: String = throw("referent") }\nclass B extends A { p: String = throw("override") }','B','p',True),('unrelated-invalid-override','open class A { fixed bad: String = throw("referent") }\nclass B extends A { bad: String = throw("override"); p: String }','B','p',True),('unrelated-bad-type','class A { fixed bad: Missing; p: String }','A','p',True),('local','class A { local p: String = throw("referent") }','A','p',True),('constraint','class A { fixed p: String(throw("constraint")) = throw("referent") }','A','p',False)]:
 add('reference-metadata-'+ident,ref+decl+f'\nresult = ref.Reference(d, {klass}, throw("data")) .{prop} is ref.Reference<D, String>\n',failure,'reference-metadata')
# Use null data for valid metadata probes: constructor arguments are evaluated, referent initializers are not.
for row in rows:
 if row['group']=='reference-metadata': row['source']=row['source'].replace('throw("data")','null')
base=Path('external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input')
for relative,expression,failure in [('basic/fixedProperty1.pkl','res1',False),('basic/fixedProperty2.pkl','p.name',False),('basic/fixedProperty3.pkl','res1',False),('basic/fixedProperty4.pkl','"ok"',True),('basic/fixedProperty5.pkl','myObj.bar',True),('basic/fixedProperty6.pkl','foo()',True),('errors/cannotChangeFixed1.pkl','Dog',True),('errors/cannotChangeFixed2.pkl','Dog',True),('errors/cannotAssignFixedProperty1.pkl','p.name',True),('errors/cannotAssignFixedProperty2.pkl','res1',True),('errors/cannotAssignFixedProperty3.pkl','p.name',True),('errors/cannotAmendFixedProperty1.pkl','n.bird.name',True),('errors/cannotAmendFixedProperty2.pkl','res3.name',True),('errors/localFixedMember.pkl','"ok"',True)]:
 p=base/relative;add('upstream-'+p.stem,p.read_text(),failure,'upstream-selected-expression',expression,input=str(p),limitation='Selected-expression observation at original upstream URI; original suite contract remains required and unchanged.')
assert len({row['id']for row in rows})==len(rows)
p=Path('target/m2/stage11-matrix.json');p.write_text(json.dumps(rows,indent=2,sort_keys=True)+'\n');print(len(rows),p)
