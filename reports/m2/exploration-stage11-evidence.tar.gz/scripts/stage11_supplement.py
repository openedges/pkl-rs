from pathlib import Path
import json
rows=[]
def add(id,source,failure=False,group='modifier-arithmetic'):
 rows.append(dict(id=id,source=source,expression='result',expected_outcome='failure'if failure else'success',group=group))
add('duplicate-fixed-implies-const-read','n = 7\nfixed fixed p = n\nresult = p\n',True)
add('duplicate-fixed-instance-override','class A { fixed fixed p: Int = 1 }\nresult = new A { p = 2 }.p\n',True)
add('duplicate-hidden-implies-fixed','class A { hidden hidden p: Int = 1 }\nresult = new A { p = 2 }.p\n',True)
add('duplicate-local-implies-hidden','local local p = 1\nresult = p\n')
add('duplicate-const','const const p = 1\nresult = p\n')
add('modifier-fixed-const-order','class A { fixed const p: Int = 1 }\nresult = new A {}.p\n')
add('modifier-fixed-abstract-order','abstract class A { fixed abstract p: Int }\nclass B extends A { fixed p: Int = 2 }\nresult = new B {}.p\n')
add('modifier-hidden-fixed-concrete','class A { hidden fixed p: Int = 1 }\nresult = new A {}.p\n')
add('modifier-abstract-fixed-concrete','abstract class A { abstract fixed p: Int }\nclass B extends A { fixed p: Int = 2 }\nresult = new B {}.p\n')
add('order-fixed-before-unknown','class A { fixed p: Int = 1 }\nresult = new A { p = 2; missing = 3 }.getClass()\n',True,'object-initialization-order')
add('order-unknown-before-fixed','class A { fixed p: Int = 1 }\nresult = new A { missing = 3; p = 2 }.getClass()\n',True,'object-initialization-order')
add('order-fixed-before-const','class A { fixed p: Int = 1; const q: Int = 2 }\nresult = new A { p = 3; q = 4 }.getClass()\n',True,'object-initialization-order')
add('order-const-before-fixed','class A { fixed p: Int = 1; const q: Int = 2 }\nresult = new A { q = 4; p = 3 }.getClass()\n',True,'object-initialization-order')
add('class-const-override-nonconst','open class A { const p: Int = 1 }\nclass B extends A { p: Int = 2 }\nresult = B\n',True,'class-initialization-order')
add('class-type-before-const','open class A { const p: Int = 1 }\nclass B extends A { p: Missing = 2 }\nresult = B\n',True,'class-initialization-order')
Path('target/m2/stage11-supplement-matrix.json').write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n');print(len(rows))
