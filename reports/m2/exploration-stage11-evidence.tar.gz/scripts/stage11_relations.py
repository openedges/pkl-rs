from pathlib import Path
import json
rows=[]
def pair(name,left,right,domain,group):
 ids=['relation-'+name+'-'+side for side in ['left','right']]
 for id,source in zip(ids,[left,right]):
  rows.append(dict(id=id,source=source,expression='result',expected_outcome='success',group=group,relation=dict(kind='equal-stdout',case_ids=ids,domain=domain)))
pair('fixed-receiver','open class A { n: Int = 2; fixed p: Int = n + 1 }\nclass B extends A\nresult = new B { n = 8 }.p\n','result = 8 + 1\n','An inherited fixed computed property uses the amended receiver field and equals the explicit computation for that receiver.','fixed-late-binding-relation')
ref='import "pkl:ref"\nclass D extends ref.Domain { function renderReference(r): String = "ok" }\nlocal d = new D {}\n'
pair('reference-unforced-fixed',ref+'class A { fixed p: String = "value" }\nresult = ref.Reference(d, A, null).p is ref.Reference<D, String>\n',ref+'class A { fixed p: String = throw("referent must stay unforced") }\nresult = ref.Reference(d, A, null).p is ref.Reference<D, String>\n','Fixed property Reference metadata is unchanged when the initializer changes from a String literal to a throwing body; metadata access must not force that body.','reference-unforced-relation')
Path('target/m2/stage11-relations-matrix.json').write_text(json.dumps(rows,sort_keys=True,indent=2)+'\n')
