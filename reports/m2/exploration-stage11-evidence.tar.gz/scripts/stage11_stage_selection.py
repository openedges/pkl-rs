"""Stage useful new fixture URIs; acquire fresh Java and compare a frozen caller artifact."""
from pathlib import Path
import sys,json,shutil
sys.path.insert(0,'tools')
import oracle,m2_manifest as c,m2_language as l
replay=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
baseline=Path('target/m2/stage11-selection-baseline-01');original=json.loads((baseline/'selection.json').read_bytes());assert json.loads(Path(c.SELECTION).read_bytes())==original
for row in original['cases']:assert Path(row['input']).read_bytes()==(baseline/'inputs'/row['input']).read_bytes(),row['id']
excluded={
 'class-modifier-hidden':'Draft abstract-class instantiation failure does not isolate hidden fixed semantics; concrete case retained.',
 'module-modifier-duplicate':'Draft leaves property unforced; supplemental duplicate-fixed const-context and override probes observe the behavior.',
 'module-modifier-const':'Draft leaves property unforced; concrete fixed/const case retained.',
 'module-modifier-abstract':'Draft leaves abstract property unforced; concrete abstract fixed cases retained.',
 'class-modifier-const':'Draft only renders class; concrete fixed/const case retained.',
 'class-modifier-abstract':'Draft only renders class; concrete abstract fixed cases retained.',
 'duplicate-hidden-implies-fixed':'Caught upstream PklBugException retained as exploration, not an ordinary compatibility selection.',
 'duplicate-local-implies-hidden':'Caught upstream PklBugException retained as exploration, not an ordinary compatibility selection.',
}
meta=oracle.ensure_oracle(c.ROOT,fetch=False);(out/'oracle.json').write_bytes(c.encoded(meta));art=out/'artifacts';art.mkdir();frozen=art/'language_probe';frozen.write_bytes((replay/'artifacts/language_probe').read_bytes());frozen.chmod(0o755)
paths=['target/m2/stage11_stage_selection.py','tools/m2_language.py','tools/m2_manifest.py','tools/oracle.py','tools/java/M2LanguageProbe.java','oracle.lock.json','references.lock']
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(Path(p).read_bytes())
if (replay/'sources/crates').exists():shutil.copytree(replay/'sources/crates',out/'sources/crates')
classes=art/'java';classes.mkdir();r=l.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(classes),str((out/'sources/tools/java/M2LanguageProbe.java').resolve())],out,'javac',meta['environment']);assert r['exit_code']==0
proposed=[];observations=[];rejected=[]
for record in json.loads((replay/'results.json').read_bytes()):
 id=record['id'];base=Path(record['baseline']);mat=next(r for r in json.loads((base/'matrix.json').read_bytes())if r['id']==id)
 if id.startswith('upstream-')or id in excluded or record['status']!='pass':
  rejected.append(dict(id=id,exploration=str(base),status=record['status'],reason='Original selected-expression observation does not replace original upstream suite contract.'if id.startswith('upstream-')else excluded.get(id,'Candidate does not match complete raw Java outcome.')));continue
 identifier='fixed-stage11-'+id;path=Path('tests/fixtures/m2')/(identifier+'.pkl');data=(base/'cases'/id/'input.pkl').read_bytes()
 if path.exists():assert path.read_bytes()==data,path
 else:path.write_bytes(data)
 source=path.resolve();folder=out/'cases'/identifier;folder.mkdir(parents=True);(folder/'input.pkl').write_bytes(source.read_bytes())
 java=l.capture_java(meta,frozen,identifier,source,mat['expression'],folder);rust=l.capture([str(frozen),str(source),mat['expression']],folder,'rust',meta['environment'])
 outcome='success'if java['exit_code']==0 else'failure';status=l.status(dict(expected_outcome=outcome),java,rust,*((folder/f'{name}.{channel}.bin').read_bytes()for name in('java','rust')for channel in('stdout','stderr')),(folder/'java.outcome.bin').read_bytes())
 requirements=['semantic:modifiers'];group=mat['group'];body=mat['source']
 if 'class 'in body:requirements.append('semantic:classes')
 if group in('instance-assignment','instance-amendment','object-initialization-order'):requirements.append('semantic:objects')
 if group=='instance-amendment'or'amendment-body'in id:requirements.append('semantic:amendment')
 if group=='lazy-order'or'throw('in body or 'reference-'in group:requirements.append('semantic:lazy-evaluation')
 if group.startswith('reference-'):requirements.extend(['semantic:reference','semantic:reflection-metadata'])
 if group=='fixed-late-binding-relation'or'late-binding'in id:requirements.append('semantic:name-resolution')
 if 'Missing'in body or'typecheck'in id:requirements.append('semantic:types')
 if outcome=='failure':requirements.append('semantic:diagnostics')
 case=dict(id=identifier,input=str(path),expression=mat['expression'],requirements=list(dict.fromkeys(requirements)),expected_outcome=outcome)
 if 'relation'in mat:case['metamorphic_relation']={**mat['relation'],'case_ids':['fixed-stage11-'+x for x in mat['relation']['case_ids']]}
 proposed.append(case);observations.append(dict(id=identifier,original_id=id,exploration=str(base),exploratory_uri=record['input_uri'],actual_uri=source.as_uri(),input_sha256=oracle.sha256(source),expression=mat['expression'],status=status,java=java,rust=rust));print(identifier,status,flush=True)
(out/'proposed.json').write_bytes(c.encoded(proposed));(out/'results.json').write_bytes(c.encoded(observations));(out/'excluded.json').write_bytes(c.encoded(rejected));(out/'candidate.json').write_bytes(c.encoded(dict(source_binding='frozen-from-exploratory-replay-unbound-caller-supplied',replay=str(replay),sha256=oracle.sha256(frozen))));(out/'evidence-sha256.json').write_bytes(c.encoded({str(p.relative_to(out)):oracle.sha256(p)for p in sorted(out.rglob('*'))if p.is_file()}))
