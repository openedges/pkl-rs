"""Add bounded fixed semantics mappings without replacing prior reviewed scope."""
from pathlib import Path
import json
selection=json.loads(Path('tests/fixtures/m2/cases.json').read_bytes())
new=[r for r in selection['cases']if r['id'].startswith('fixed-stage11-')];assert new
mapping=json.loads(Path('compatibility/m2-mappings.json').read_bytes());by_id={r['requirement']:r for r in mapping['requirements']}
def link(path,symbol):return dict(path='crates/pkl-runtime/src/'+path,symbol=symbol)
def ids(semantic):return[r['id']for r in new if semantic in r['requirements']]
def add(req,links,cases,scope,remaining):
 assert req not in by_id and cases
 row=dict(requirement=req,implementation=dict(state='partial',links=links),tests=dict(state='partial',case_ids=cases),scope=scope,remaining=remaining)
 mapping['requirements'].append(row);by_id[req]=row
vm=[link('heap.rs','Member'),link('vm.rs','validate_class_override'),link('vm.rs','validate_object_override'),link('vm.rs','initialize_member_types')]
fixed_scope='Selected class fixed properties preserve declaration fixedness through inheritance, reject instance assignment and amendment before forcing bodies, and retain member/type initialization error order. Raw comparisons cover only the linked fixtures at their actual URIs.'
remaining=['Module extends/amends and the original upstream fixed-property snippet suite contracts remain unimplemented or unexecuted.','Full modifier combinations, annotation metadata, generic class inheritance and the complete class/member error corpus remain outside this bounded selection.','Caught upstream PklBugException duplicate hidden/local outputs and any recorded exploratory mismatches remain separate failures, without development exceptions.']
add('semantic:modifiers',vm+[link('resolver.rs','validate_modifiers')],ids('semantic:modifiers'),fixed_scope,remaining)
add('semantic:classes',vm,ids('semantic:classes'),fixed_scope,remaining)
add('semantic:amendment',[link('vm.rs','validate_object_override'),link('vm.rs','inherited_member')],ids('semantic:amendment'),'Selected fixed instance amendments are rejected; extracting the fixed property value still permits amendment of that value. Empty receiver amendments preserve fixed values.', ['General module amendments, function amendments, generic and cyclic object inheritance, and the complete amendment corpus remain open.'])
add('semantic:lazy-evaluation',[link('vm.rs','initialize_member_types'),link('vm.rs','validate_class_override'),link('vm/reference.rs','reference_candidate')],ids('semantic:lazy-evaluation'),'Selected probes preserve unforced fixed initializers, class type-before-modifier errors, fixed override checks before body forcing, and fixed Reference metadata without evaluating referent bodies.', ['Complete lazy error ordering, successful memoization, retry semantics, cycles and failure-path diagnostics require the original inventory and broader differential execution.'])
manifest=json.loads(Path('compatibility/m2-language.json').read_bytes())
fixed=[r['id']for r in manifest['requirements']if r['kind']=='specification'and r['description']=='Fixed properties'];assert len(fixed)==1
add(fixed[0],vm,ids('semantic:modifiers'),fixed_scope,remaining)
for req,semantic in [('semantic:reference','semantic:reference'),('semantic:reflection-metadata','semantic:reflection-metadata'),('semantic:diagnostics','semantic:diagnostics')]:
 row=by_id[req];row['tests']['case_ids']=list(dict.fromkeys([*row['tests']['case_ids'],*ids(semantic)]))
 row['scope']+=' Stage11 adds selected fixed declaration, inherited metadata and complete raw diagnostics through the shared VM.'
Path('compatibility/m2-mappings.json').write_text(json.dumps(mapping,indent=2)+'\n');print(len(new),'new fixed cases mapped;',len(mapping['requirements']),'reviewed partial requirements')
