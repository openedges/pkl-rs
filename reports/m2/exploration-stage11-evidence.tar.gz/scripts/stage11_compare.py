"""Exploratory exact-process comparison; never a selected/full completion gate."""
from pathlib import Path
import sys,json,shutil
sys.path.insert(0,'tools')
import oracle,m2_manifest as c,m2_language as l
out=Path(sys.argv[1]).resolve();candidate=Path(sys.argv[2]).resolve();baselines=[Path(p).resolve()for p in sys.argv[3:]];out.mkdir(exist_ok=False)
art=out/'artifacts';art.mkdir();frozen=art/'language_probe';frozen.write_bytes(candidate.read_bytes());frozen.chmod(0o755)
meta=oracle.ensure_oracle(c.ROOT,fetch=False);(out/'oracle.json').write_bytes(c.encoded(meta));sources={}
for p in ['target/m2/stage11_compare.py','tools/m2_language.py','tools/m2_manifest.py','tools/oracle.py','oracle.lock.json','Cargo.lock',*[str(p)for p in Path('crates').rglob('*.rs')],*[str(p)for p in Path('crates').rglob('*.pkl')]]:
 dest=out/'sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(Path(p).read_bytes());sources[p]=oracle.sha256(dest)
(out/'source-identities.json').write_bytes(c.encoded(sources));rows=[]
for baseline in baselines:
 matrix=json.loads((baseline/'matrix.json').read_bytes());original={r['id']:r for r in json.loads((baseline/'results.json').read_bytes())}
 for case in matrix:
  id=case['id'];previous=original[id];old=baseline/'cases'/id;folder=out/baseline.name/id;folder.mkdir(parents=True)
  source=Path(previous['java']['command'][-2]);assert oracle.sha256(source)==previous['input_sha256'],source
  rust=l.capture([str(frozen),str(source),case['expression']],folder,'rust',meta['environment'])
  oldp=previous['java'];jout=(old/'java.stdout.bin').read_bytes();jerr=(old/'java.stderr.bin').read_bytes();rout=(folder/'rust.stdout.bin').read_bytes();rerr=(folder/'rust.stderr.bin').read_bytes()
  match=(oldp['exit_code'],oldp['timed_out'],jout,jerr)==(rust['exit_code'],rust['timed_out'],rout,rerr)
  valid=not oldp['timed_out']and ((oldp['exit_code']==0 and not jerr and (old/'java.outcome.bin').read_bytes()==b'success\n')or(oldp['exit_code']==1 and not jout and l.valid_exception_outcome((old/'java.outcome.bin').read_bytes())))
  row=dict(baseline=str(baseline),id=id,input_uri=previous['input_uri'],input_sha256=previous['input_sha256'],expression=case['expression'],expected_outcome=('success'if oldp['exit_code']==0 else'failure'),draft_expected_outcome=case['expected_outcome'],expectation_matches=(case['expected_outcome']=='success')==(oldp['exit_code']==0),valid_java_outcome=valid,status='pass'if match and valid else('mismatch'if valid else'oracle-error'),rust=rust);rows.append(row)
  print(baseline.name,id,row['status'],flush=True)
(out/'results.json').write_bytes(c.encoded(rows));(out/'candidate.json').write_bytes(c.encoded(dict(original_path=str(candidate),frozen_sha256=oracle.sha256(frozen),source_binding='unbound-caller-supplied',source_stability=all(oracle.sha256(Path(p))==s for p,s in sources.items()))));(out/'baseline-identities.json').write_bytes(c.encoded({str(p):oracle.sha256(p/'evidence-sha256.json')for p in baselines}));(out/'evidence-sha256.json').write_bytes(c.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
