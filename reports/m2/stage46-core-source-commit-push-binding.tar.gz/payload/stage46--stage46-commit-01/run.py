from pathlib import Path
import datetime, hashlib, json, os, subprocess
root=Path.cwd()
out=root/'target/m2/stage46-commit-01'
assert not (out/'report.json').exists()
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')
report={'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(root),'commands':[],'complete':False}
def run(label,args):
 p=subprocess.run(args,cwd=root,env=env,capture_output=True)
 for stream in ['stdout','stderr']:(out/(label+'.'+stream+'.bin')).write_bytes(getattr(p,stream))
 report['commands'].append({'label':label,'argv':args,'exitCode':p.returncode,'stdoutSha256':hashlib.sha256(p.stdout).hexdigest(),'stderrSha256':hashlib.sha256(p.stderr).hexdigest()})
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(label,p.returncode,p.stdout.decode(errors='replace')[-1200:],p.stderr.decode(errors='replace')[-1200:],flush=True)
 assert p.returncode==0,label
 return p.stdout
assert run('branch',['git','branch','--show-current']).strip()==b'm2/stage46-resource'
assert run('head-before',['git','rev-parse','HEAD']).strip()==b'e878e993d557256429a34ab9c4ce68ad8254de92'
assert len(run('staged-paths',['git','diff','--cached','--name-only','-z']).split(b'\0'))-1==467
assert not run('unstaged',['git','diff','--name-only','-z'])
run('whitespace',['git','diff','--cached','--check'])
tree=run('staged-tree',['git','write-tree']).decode().strip()
expected=(out/'expected-tree.txt').read_text().strip()
assert tree==expected,(tree,expected)
run('commit',['git','commit','-m','feat(runtime): add typed Resource caching and module URI preparation'])
commit=run('head-after',['git','rev-parse','HEAD']).decode().strip()
assert run('committed-tree',['git','rev-parse','HEAD^{tree}']).decode().strip()==expected
assert not run('status-after',['git','status','--porcelain'])
report.update(complete=True,commit=commit,tree=tree,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
