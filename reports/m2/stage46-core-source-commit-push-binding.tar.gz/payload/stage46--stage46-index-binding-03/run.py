from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1")
CANDIDATE = ROOT / "target/m2/stage46-implementation-01/resource-candidate-build-06"
CORRECTIONS = ROOT / "target/m2/stage46-http-server-correction-01/final-application.json"
COMMANDS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def git(where, args, raw_name=None):
    result = subprocess.run(["git", *args], cwd=where, env=ENV, capture_output=True)
    COMMANDS.append({"cwd": str(where), "argv": ["git", *args],
                     "exitCode": result.returncode, "stdoutSha256": sha(result.stdout),
                     "stderrSha256": sha(result.stderr), "optionalLocks": "0"})
    if raw_name:
        (OUT / raw_name).write_bytes(result.stdout)
        (OUT / (raw_name + ".stderr")).write_bytes(result.stderr)
    assert result.returncode == 0, (where, args, result.stderr)
    return result.stdout


def entries(data, index=False):
    result = {}
    for row in data.split(b"\0"):
        if not row:
            continue
        header, name = row.split(b"\t", 1)
        fields = header.decode().split()
        if index:
            mode, oid, stage = fields
            assert stage == "0", (name, stage)
        else:
            mode, kind, oid = fields
            assert kind == ("commit" if mode == "160000" else "blob")
        path = name.decode("utf-8")
        assert not Path(path).is_absolute() and ".." not in Path(path).parts
        assert path not in result
        result[path] = {"mode": mode, "oid": oid}
    return result


def object_oid(kind, data):
    return hashlib.sha1(kind.encode() + b" " + str(len(data)).encode() + b"\0" + data).hexdigest()


def tree_oid(files):
    tree = {}
    for path, entry in files.items():
        parts = path.encode().split(b"/")
        target = tree
        for component in parts[:-1]:
            target = target.setdefault(component, {})
            assert isinstance(target, dict)
        assert parts[-1] not in target
        target[parts[-1]] = (entry["mode"], entry["oid"])

    def encode(node):
        rows = []
        for name, child in node.items():
            mode, oid = ("40000", encode(child)) if isinstance(child, dict) else child
            rows.append((name + (b"/" if mode == "40000" else b""),
                         mode.encode() + b" " + name + b"\0" + bytes.fromhex(oid)))
        return object_oid("tree", b"".join(row for _, row in sorted(rows)))
    return encode(tree)


def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    release_bytes = (CANDIDATE / "release.json").read_bytes()
    release = json.loads(release_bytes)
    map_path = Path(release["source_map"])
    map_bytes = map_path.read_bytes()
    assert sha(map_bytes) == release["source_map_sha256"] == "8df1d6bb56a4467088d8e07a4e12ee39b651d6a91a1c0ab1a11c64ff95c93370"
    source_map = json.loads(map_bytes)
    assert len(source_map) == 32847
    snapshot = Path(release["source_snapshot"])
    correction_bytes = CORRECTIONS.read_bytes()
    corrections = {entry["path"]: entry for entry in json.loads(correction_bytes)["files"]}
    assert len(corrections) == 6
    for path, entry in corrections.items():
        assert path.startswith("tools/platform/") and path.endswith(".mjs")
        assert source_map[path] == entry["before"] and entry["before"] != entry["after"]
    pins = {}
    for line in (ROOT / "references.lock").read_text().splitlines():
        if line and not line.startswith("#"):
            key, value = line.split("=", 1)
            pins[key] = value
    index_path = Path(git(ROOT, ["rev-parse", "--git-path", "index"]).decode().strip())
    if not index_path.is_absolute():
        index_path = ROOT / index_path
    assert not Path(str(index_path) + ".lock").exists()
    index_binary = index_path.read_bytes()
    index_raw = git(ROOT, ["ls-files", "--stage", "-z"], "index-before.bin")
    root_entries = entries(index_raw, True)
    head = git(ROOT, ["rev-parse", "HEAD"]).decode().strip()
    assert git(ROOT, ["rev-parse", "--show-object-format"]).strip() == b"sha1"
    repositories = [("", root_entries, None)]
    pin_records = []
    for name in ["pkl", "pkl-pantry"]:
        prefix = pins[name + ".path"]
        pin = pins[name + ".revision"]
        assert root_entries[prefix] == {"mode": "160000", "oid": pin}
        where = ROOT / prefix
        actual_head = git(where, ["rev-parse", "HEAD"]).decode().strip()
        assert actual_head == pin
        assert git(where, ["rev-parse", "--show-object-format"]).strip() == b"sha1"
        commit = git(where, ["cat-file", "commit", pin], name + "-commit.bin")
        assert object_oid("commit", commit) == pin
        pinned_tree = commit.splitlines()[0].decode().removeprefix("tree ")
        raw_tree = git(where, ["ls-tree", "-r", "-z", pin], name + "-tree.bin")
        files = entries(raw_tree)
        assert tree_oid(files) == pinned_tree
        repositories.append((prefix, files, pin))
        pin_records.append({"path": prefix, "rootIndexGitlink": pin, "actualHead": actual_head,
                            "commitObjectSha1Verified": True, "pinnedTree": pinned_tree,
                            "completeTreeReconstructedFromBlobsAndModes": True,
                            "treeEntryCount": len(files), "treeListingSha256": sha(raw_tree)})

    checkout_boundaries = {}
    for name in ["pkl", "pkl-pantry"]:
        prefix = "external/" + name
        repo = ROOT / prefix
        blob = git(repo, ["cat-file", "blob", pins[name + ".revision"] + ":gradlew.bat"], name + "-gradlew-git.bin")
        attributes = git(repo, ["cat-file", "blob", pins[name + ".revision"] + ":.gitattributes"], name + "-gitattributes-git.bin")
        observed = git(repo, ["check-attr", "-z", "text", "eol", "--", "gradlew.bat"], name + "-gradlew-attributes.bin")
        assert observed == b"gradlew.bat\0text\0set\0gradlew.bat\0eol\0crlf\0"
        assert any(line.split() == [b"*.bat", b"text", b"eol=crlf"] for line in attributes.splitlines())
        path = prefix + "/gradlew.bat"
        live = (ROOT / path).read_bytes()
        frozen = (snapshot / path).read_bytes()
        assert b"\r" not in blob and blob.replace(b"\n", b"\r\n") == live == frozen
        (OUT / (name + "-gradlew-checkout.bin")).write_bytes(live)
        (OUT / (name + "-gradlew-c06.bin")).write_bytes(frozen)
        checkout_boundaries[path] = {"rawGitBlobSha256": sha(blob), "rawGitBlobBytes": len(blob),
                                    "checkoutSha256": sha(live), "checkoutBytes": len(live),
                                    "c06Sha256": sha(frozen), "lfCount": blob.count(b"\n"),
                                    "exactDeclaredCheckoutTransformVerified": True,
                                    "pinnedGitattributesSha256": sha(attributes),
                                    "boundary": "Pinned *.bat text eol=crlf checkout conversion. Raw Git, checkout and C06 bytes are separately retained; no evaluator outputs or source files were normalized or edited."}
    write("checkout-boundaries.json", checkout_boundaries)
    file_records = {}
    nonregular = []
    failures = []
    actual_differences = []
    snapshot_mode_differences = []
    total_bytes = 0
    for prefix, files, pin in repositories:
        where = ROOT / prefix
        label = prefix.replace("/", "-") or "root-index"
        with (OUT / (label + "-cat-file.stderr.bin")).open("wb") as errors:
            process = subprocess.Popen(["git", "cat-file", "--batch"], cwd=where, env=ENV,
                                       stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors)
            for local, entry in sorted(files.items()):
                if entry["mode"] == "160000":
                    continue
                path = prefix + "/" + local if prefix else local
                live_path = ROOT / path
                process.stdin.write(entry["oid"].encode() + b"\n")
                process.stdin.flush()
                oid, kind, size = process.stdout.readline().decode().strip().split()
                assert oid == entry["oid"] and kind == "blob"
                size = int(size)
                object_hash = hashlib.sha1(b"blob " + str(size).encode() + b"\0")
                digest = hashlib.sha256()
                remaining = size
                if entry["mode"] == "120000":
                    blob = process.stdout.read(size)
                    assert len(blob) == size
                    digest.update(blob)
                    object_hash.update(blob)
                    assert process.stdout.read(1) == b"\n"
                    assert object_hash.hexdigest() == oid
                    assert live_path.is_symlink() and os.fsencode(os.readlink(live_path)) == blob
                    assert path not in source_map
                    nonregular.append({"path": path, "mode": entry["mode"], "gitBlob": oid,
                                       "gitBlobSha256": digest.hexdigest(), "linkTargetHex": blob.hex(),
                                       "liveLinkBytesEqualPinnedBlob": True,
                                       "includedInC06SourceMap": False,
                                       "boundary": "C06 collector records regular files only. This pinned symlink is independently bound here; not counted among the 32847 captured source files."})
                    continue
                assert entry["mode"] in {"100644", "100755"}
                assert path in source_map, ("regular index/tree entry not captured", path)
                source_path = snapshot / path
                assert stat.S_ISREG(live_path.lstat().st_mode) and stat.S_ISREG(source_path.lstat().st_mode)
                live_mode = "100755" if live_path.stat().st_mode & stat.S_IXUSR else "100644"
                snapshot_mode = "100755" if source_path.stat().st_mode & stat.S_IXUSR else "100644"
                assert live_mode == entry["mode"], path
                if snapshot_mode != entry["mode"]:
                    snapshot_mode_differences.append({"path": path, "indexMode": entry["mode"],
                                                      "liveMode": live_mode, "snapshotMode": snapshot_mode,
                                                      "boundary": "The C06 source map binds bytes, not permissions; snapshot metadata is separately recorded and not silently counted as equal."})
                live_hash = hashlib.sha256()
                frozen_hash = hashlib.sha256()
                live_equal = True
                frozen_equal = True
                with live_path.open("rb") as live, source_path.open("rb") as frozen:
                    while remaining:
                        chunk = process.stdout.read(min(1048576, remaining))
                        assert chunk
                        remaining -= len(chunk)
                        object_hash.update(chunk)
                        digest.update(chunk)
                        left, right = live.read(len(chunk)), frozen.read(len(chunk))
                        live_hash.update(left)
                        frozen_hash.update(right)
                        live_equal &= left == chunk
                        frozen_equal &= right == chunk
                    extra_live, extra_frozen = live.read(), frozen.read()
                    live_hash.update(extra_live)
                    frozen_hash.update(extra_frozen)
                    live_equal &= not extra_live
                    frozen_equal &= not extra_frozen
                assert process.stdout.read(1) == b"\n"
                assert object_hash.hexdigest() == oid, path
                total_bytes += size
                assert frozen_hash.hexdigest() == source_map[path], ("snapshot changed", path)
                expected = corrections[path]["after"] if path in corrections else source_map[path]
                if path in checkout_boundaries:
                    boundary = checkout_boundaries[path]
                    ok = digest.hexdigest() == boundary["rawGitBlobSha256"] and live_hash.hexdigest() == expected == boundary["checkoutSha256"]
                else:
                    ok = live_equal and digest.hexdigest() == live_hash.hexdigest() == expected
                if not ok:
                    failures.append(path)
                if live_hash.hexdigest() != frozen_hash.hexdigest():
                    actual_differences.append(path)
                file_records[path] = {"repository": prefix or ".", "pin": pin,
                                      "gitMode": entry["mode"], "liveGitMode": live_mode, "snapshotGitMode": snapshot_mode, "gitBlob": oid,
                                      "blobObjectSha1Verified": True, "blobSize": size,
                                      "gitBlobSha256": digest.hexdigest(),
                                      "liveSha256": live_hash.hexdigest(),
                                      "c06Sha256": frozen_hash.hexdigest(),
                                      "liveBytesEqualGitBlob": live_equal,
                                      "c06BytesEqualGitBlob": frozen_equal,
                                      "approvedHttpCorrection": path in corrections,
                                      "declaredGitCheckoutTransform": path in checkout_boundaries}
            process.stdin.close()
            assert process.wait() == 0
            COMMANDS.append({"cwd": str(where), "argv": ["git", "cat-file", "--batch"],
                             "pid": process.pid, "exitCode": 0, "optionalLocks": "0",
                             "purpose": "Read and hash every actual indexed/pinned Git blob, with byte comparisons to live and frozen files."})
        print(label, len(files), "entries checked", flush=True)

    unbound_sources = sorted(set(source_map) - set(file_records))
    write("file-bindings.json", file_records)
    write("byte-check-findings.json", {"unboundSources": unbound_sources, "unexpectedByteDifferences": failures,
                                       "liveVsC06Differences": actual_differences, "checkoutBoundaries": checkout_boundaries})
    assert not unbound_sources and not failures
    assert set(actual_differences) == set(corrections)
    after_raw = git(ROOT, ["ls-files", "--stage", "-z"], "index-after.bin")
    after_binary = index_path.read_bytes()
    assert index_raw == after_raw and index_binary == after_binary
    assert not Path(str(index_path) + ".lock").exists()
    assert git(ROOT, ["rev-parse", "HEAD"]).decode().strip() == head
    for record in pin_records:
        assert git(ROOT / record["path"], ["rev-parse", "HEAD"]).decode().strip() == record["actualHead"]
    assert map_path.read_bytes() == map_bytes and CORRECTIONS.read_bytes() == correction_bytes
    write("file-bindings.json", file_records)
    write("symlinks-outside-c06-map.json", nonregular)
    write("snapshot-mode-boundaries.json", snapshot_mode_differences)
    write("commands.json", COMMANDS)
    report = {"schema": 1, "scope": "Read-only staged implementation index and pinned submodule blob binding. No Git index, working source, object store, commit or publication mutation was performed.",
              "startedUtc": started, "finishedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "elapsedSeconds": time.monotonic() - clock, "root": str(ROOT), "head": head,
              "release": str(CANDIDATE / "release.json"), "releaseSha256": sha(release_bytes),
              "sourceMap": str(map_path), "sourceMapSha256": sha(map_bytes), "sourceCount": len(source_map),
              "httpCorrection": str(CORRECTIONS), "httpCorrectionSha256": sha(correction_bytes),
              "indexEntryCount": len(root_entries), "rootRegularFiles": len(root_entries) - 2,
              "sourceFilesBound": len(file_records), "actualBlobBytesRead": total_bytes,
              "directGitBlobEqualsLiveCount": sum(row["liveBytesEqualGitBlob"] for row in file_records.values()),
              "directGitBlobEqualsC06Count": sum(row["c06BytesEqualGitBlob"] for row in file_records.values()),
              "declaredGitCheckoutTransformCount": len(checkout_boundaries),
              "declaredGitCheckoutTransforms": checkout_boundaries,
              "differenceScope": "exactSixDifferences compares actual live/index checkout bytes with C06 snapshot bytes; the two separately declared .bat checkout conversions are not postbuild source edits.",
              "gitObjectFormat": "sha1", "prospectiveIndexTreeSha1": tree_oid(root_entries),
              "treeHashMethod": "Pure Python Git tree encoding from unchanged stage-0 mode/path/blob/gitlink entries; no git write-tree invocation or object-store write.",
              "indexBeforeAfterIdentical": True, "indexListingSha256": sha(index_raw),
              "indexBinarySha256": sha(index_binary), "headAndPinsUnchanged": True,
              "pins": pin_records, "exactSixDifferences": sorted(actual_differences),
              "unexpectedDifferences": failures, "unboundSourceMapPaths": unbound_sources,
              "symlinksOutsideSourceMap": len(nonregular),
              "snapshotModeBoundaries": snapshot_mode_differences,
              "priorAuditFailure": str(ROOT / "target/m2/stage46-index-binding-01/failure.json"),
              "priorAuditFailurePreserved": True,
              "priorCheckoutAuditFailure": str(ROOT / "target/m2/stage46-index-binding-02/failure.json"),
              "priorCheckoutLocator": str(ROOT / "target/m2/stage46-index-binding-02/located-byte-mismatches.json"),
              "symlinkBoundary": "11 pinned upstream symlinks were excluded by the C06 regular-file collector; their Git blobs and live link-target bytes were independently verified and recorded, without counting them as C06 snapshot inputs.",
              "fileBindingsSha256": sha((OUT / "file-bindings.json").read_bytes()),
              "symlinkBindingsSha256": sha((OUT / "symlinks-outside-c06-map.json").read_bytes()),
              "scriptSha256": sha(Path(__file__).read_bytes()), "passed": True,
              "nextBinding": "Root may compare the implementation commit tree to prospectiveIndexTreeSha1; this audit does not claim that a future commit or push has happened."}
    write("report.json", report)
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        write("failure.json", {"type": type(error).__name__, "message": str(error),
                               "commands": COMMANDS})
        raise
