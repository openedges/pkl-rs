"""Replay immutable stage10 Java bytes; this is not a fresh Java acquisition."""
from pathlib import Path
import concurrent.futures,json,sys,shutil
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
baseline=Path('target/m2/language-stage10-final').resolve();current=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
report=json.loads((baseline/'report.json').read_bytes());metadata=json.loads((baseline/'oracle.json').read_bytes());selection=json.loads(Path('tests/fixtures/m2/cases.json').read_bytes());original=json.loads((baseline/'sources/tests/fixtures/m2/cases.json').read_bytes());assert len(original['cases'])==1202 and len(report['results'])==1202;assert selection['cases'][:1202]==original['cases'];newcases={c['id']:c for c in original['cases']}
(out/'artifacts').mkdir();frozen=out/'artifacts/language_probe';frozen.write_bytes((current/'artifacts/language_probe').read_bytes());frozen.chmod(0o755)
(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(frozen),sha256=oracle.sha256(frozen),source_binding='unbound-caller-supplied frozen exploratory candidate; not a recorded current language acquisition build',exploratory_candidate=str(current))))
(out/'baseline.json').write_bytes(contract.encoded(dict(path=str(baseline),report_sha256=oracle.sha256(baseline/'report.json'),oracle=metadata,scope='Reuse unchanged prior1202 complete raw Java bytes; fresh current Java acquisition remains separate. No normalization or new exceptions.')))
(out/'original-selection.json').write_bytes((baseline/'sources/tests/fixtures/m2/cases.json').read_bytes());shutil.copy2('target/m2/replay_prior_selection_stage11_provisional.py',out/'replay_prior_selection_stage11_provisional.py')
if(current/'sources/crates').exists():shutil.copytree(current/'sources/crates',out/'sources/crates')
def run(prior):
 c=newcases[prior['id']];b=baseline/'cases'/c['id'];d=out/'cases'/c['id'];d.mkdir(parents=True);source=contract.ROOT/c['input'];assert source.read_bytes()==(b/'input.pkl').read_bytes();assert oracle.sha256(source)==report['source_sha256'][c['input']];(d/'input.pkl').write_bytes(source.read_bytes())
 for channel in('stdout','stderr'):assert oracle.sha256(b/f'java.{channel}.bin')==prior['java'][channel+'_sha256']
 assert oracle.sha256(b/'java.outcome.bin')==prior['java']['outcome_sha256']
 row=lang.capture([str(frozen),*lang.expression_arguments(source,c['expression'],c.get('power_assertions',False))],d,'rust',metadata['environment']);status=lang.status(c,prior['java'],row,*[(b/f'java.{ch}.bin').read_bytes()for ch in('stdout','stderr')],*[(d/f'rust.{ch}.bin').read_bytes()for ch in('stdout','stderr')],(b/'java.outcome.bin').read_bytes());return dict(id=c['id'],input_sha256=oracle.sha256(source),status=status,rust=row)
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:results=list(pool.map(run,report['results']))
from collections import Counter
summary=dict(results=results,status_counts=dict(Counter(r['status']for r in results)),prior1202_definitions_preserved=True,prior1202_input_bytes_preserved=True)
(out/'report.json').write_bytes(contract.encoded(summary));(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p)for p in sorted(out.rglob('*'))if p.is_file()}));print(summary['status_counts'])
for r in results:
 if r['status']!='pass':print(r['id'],r['status'])
