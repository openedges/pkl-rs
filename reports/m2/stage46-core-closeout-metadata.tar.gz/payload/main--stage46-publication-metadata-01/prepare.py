"""Prepare a factual implementation checkpoint from completed local evidence."""
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path.cwd()
CAP = ROOT.parent / "pkl-rs.stage46/target/m2"
OUT = ROOT / "target/m2/stage46-publication-metadata-01"
COMMIT = "a3eb3634558cef6f36189320498fe7e013296c48"
EVIDENCE = {}


def load(name, path):
    data = path.read_bytes()
    EVIDENCE[name] = {"path": str(path), "sha256": hashlib.sha256(data).hexdigest()}
    return json.loads(data)


release = load("candidate_release", CAP / "stage46-implementation-01/resource-candidate-build-06/release.json")
rust = load("rust_checks", CAP / "stage46-rust5-02/report.json")
load("rust_scope_erratum", CAP / "stage46-rust5-02/scope-erratum.json")
native = load("native_summary", CAP / "stage46-native-c06-audit-01/comparison-summary.json")
handoff = load("native_handoff", CAP / "stage46-native-c06-audit-01/handoff.json")
read = load("original_read", CAP / "stage46-original-read-native-04/report.json")
baseline = load("platform_baseline", CAP / "stage46-platform-baseline-02/report.json")
resource = load("portable_resource", CAP / "stage46-resource-platform-03/execution.json")
module = load("portable_module", CAP / "stage46-module-platform-03/execution.json")
http = load("platform_http_followup", CAP / "stage46-platform-http-followup-01/report.json")
integration = load("tool_integration", CAP / "stage46-module-portable-integration-01/report.json")
binding = load("index_binding", CAP / "stage46-index-binding-03/report.json")
commit = load("implementation_commit", CAP / "stage46-commit-01/report.json")
push = load("implementation_push", ROOT / "target/m2/stage46-implementation-push-01/report.json")
load("independent_platform_review", ROOT / "target/m2/stage46-server-tooling-review-01/followup-review.json")

assert rust["allPass"] and rust["sourceStable"] and len(rust["records"]) == 5
assert all(row["exitCode"] == 0 for row in rust["records"])
assert handoff["rawApiPass"] == 1724 and handoff["originalSourceAndArtifactsStable"]
assert sum(v["counts"]["pass"] for v in native["fileGroups"].values()) == 716
assert sum(v["counts"]["pass"] for v in native["resourceGroups"].values()) == 1008
assert read["all_pass"] and read["artifact_stable"] and read["workspace_stable"] and len(read["records"]) == 2
assert baseline["shared_engine_passed"] == 6078
assert baseline["oracle_passed"] == {"rust": 6076, "node": 6076, "browser": 6076}
assert baseline["experiment_contract_status"] == "pass" and baseline["compatibility_status"] == "fail"
for capture, count in [(resource, 1008), (module, 252)]:
    assert capture["selectedContractPassed"] and not capture["fullCompatibilityPassed"]
    assert capture["selectedApiCallsPerTarget"] == count and not capture["changedInputs"]
    assert capture["browserLaunchOptions"]["executablePath"] == capture["browserExecutable"]
    assert capture["serverMissingAssetProbe"] == {"path": "/__pkl_verification_missing_asset__.js", "status": 404, "bodyHex": ""}
    assert all(v["selectedContractPassed"] and v["complete"] for v in capture["targets"].values())
assert http["selectedAcquisitionPassed"] and not http["runtimeOrBuildConfigurationChanges"]
assert len(http["postBuildToolingChanges"]) == 6 and not http["sourceChangesDuringAcquisition"]
assert integration["passed"] and not integration["sourceChanges"]
assert binding["passed"] and binding["sourceFilesBound"] == 32847
assert not binding["unexpectedDifferences"] and not binding["unboundSourceMapPaths"]
assert commit["complete"] and commit["commit"] == COMMIT
assert commit["tree"] == binding["prospectiveIndexTreeSha1"]
assert push["complete"] and push["commit"] == push["remoteHead"] == COMMIT

result = {
    "schema": 1,
    "scope": "Stage46 shared Resource, evaluator cache and module URI preparation implementation checkpoint. Focused local comparisons; not full selected regression or M2 completion.",
    "createdUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "implementationCommit": COMMIT,
    "implementationTree": commit["tree"],
    "host": http["host"],
    "requiredRustChecks": [{"argv": r["argv"], "exitCode": r["exitCode"]} for r in rust["records"]],
    "rustEvidenceQualification": "The original Rust5 report's scope text says C05 in error. Its release, environment, source map and separate immutable erratum bind the actual C06 checks. Six subsequent HTTP verification-tool edits changed no runtime or build configuration and were independently checked and exercised in fresh platform acquisitions.",
    "originalRead": {"unchangedWholeProgram": "basic/read.pkl", "rawMatches": 2, "workspaceAndArtifactsStable": True},
    "native": {"selectedRawApiMatches": 1724, "resource": 1008, "fileLogicalCapability": 716, "constructorJavaApiCallsUnexecuted": 16, "resourceJavaApiCallsUnselected": 264, "filePolicyProjectionPass": 692, "capabilityPolicyProjectionUnrecognized": 24, "projectionQualification": "The historical File-only checker retains 24 capability SPI admission mismatches. Raw API agreement does not turn that projection into a pass. The new portable module contract separately declares admission events outside its observable projection."},
    "sharedPlatformBaseline": {k: baseline[k] for k in ["total", "shared_engine_passed", "oracle_passed", "compatibility_status", "known_gaps", "experiment_contract_status"]},
    "portable": {name: {"selectedApiCallsPerTarget": capture["selectedApiCallsPerTarget"], "javaApiCalls": capture["javaApiCalls"], "unexecutedApiBoundaries": len(capture["unexecutedApiBoundaries"]), "rawCountsByTarget": {target: value["rawApiCounts"] for target, value in capture["targets"].items()}, "browserExecutableSha256": capture["browserExecutableSha256"], "browserExecutableExplicitlySelected": True, "missingAssetProbe": capture["serverMissingAssetProbe"]} for name, capture in [("resource", resource), ("modulePreparation", module)]},
    "tooling": {"pythonTestsPassed": 26, "javascriptProtocolTestsPassed": 21, "fixtureCliAndInventoryFreshnessPassed": True, "earlierResourceFixtureCheckpointTests": 27, "earlierResourceTestsRepeatedHere": False},
    "sourceBinding": {"capturedRegularFiles": 32847, "unbound": 0, "postBuildHttpToolChanges": binding["exactSixDifferences"], "declaredBatCheckoutTransforms": 2, "pinnedSymlinksOutsideSourceMap": 11, "snapshotExecutableModeDifferences": len(binding["snapshotModeBoundaries"]), "qualification": "Raw Git, checkout and C06 bytes, symlink targets and snapshot permission metadata are recorded separately. No evaluation output was normalized."},
    "historicalFailures": ["Initial Resource and URI behavior failures remain in their original captures.", "Initial required-check failures remain separate from the successful C06 checks.", "The first C06 supplemental platform acquisitions failed in their HTTP harness; corrected fresh acquisitions pass.", "Older browser captures record a full-Chrome executable hash without proving that Playwright launched that executable. Historical results retain this provenance limitation; current captures explicitly select the recorded executable.", "Index audits 01 and 02 retain their metadata and checkout-transform assertions; audit03 records the exact boundaries and succeeds."],
    "fullSelectedRegression": {"status": "Started separately on the implementation commit; no completed result is claimed by this implementation checkpoint.", "output": str(CAP / "stage46-full-regression-01")},
    "remainingScope": ["Forced read*/import* glob execution, Resource digests/full Bytes API and other unselected boundaries.", "Remaining language/type/annotation/reflection/diagnostic and original-program dependencies.", "Complete product APIs, release platforms and speed/memory targets."],
    "fullM2Complete": False,
    "hostedCiClaimed": False,
    "performanceTargetClaimed": False,
    "evidence": EVIDENCE,
}
destination = ROOT / "reports/m2/stage46-implementation-checkpoint.json"
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + "\n")
(OUT / "report.json").write_text(json.dumps({"checkpoint": str(destination), "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "inputs": EVIDENCE, "allAssertionsPassed": True}, indent=2) + "\n")
print(destination)
