from pathlib import Path
import hashlib,json,platform,shutil,subprocess,time
root=Path.cwd(); out=root/'target/m2/stage49-modulekey-build04'
def snapshot():
    paths={p for p in (root/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.pkl','.toml')}
    paths.update([root/'Cargo.toml',root/'Cargo.lock',root/'rust-toolchain.toml',root/'references.lock',root/'crates/pkl-runtime/src/stdlib/modules.txt'])
    paths.update(p for p in (root/'.cargo').rglob('*') if p.is_file())
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
def save(name,value): (out/name).write_text(json.dumps(value,indent=2)+'\n')
before=snapshot(); save('sources-before.json',before)
for name in before:
    dest=out/'sources'/name; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(root/name,dest)
command=['cargo','build','-p','pkl-runtime','--example','stage49_modulekey_probe','--locked']
start=time.time()
with (out/'build.stdout').open('wb') as stdout,(out/'build.stderr').open('wb') as stderr:
    process=subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr)
    save('running.json',{'command':command,'pid':process.pid,'cwd':str(root),'startedUnix':start})
    result=process.wait()
after=snapshot(); save('sources-after.json',after)
artifact=out/'stage49_modulekey_probe'
if result==0: shutil.copy2(root/'target/debug/examples/stage49_modulekey_probe',artifact)
report={'command':command,'pid':process.pid,'cwd':str(root),'exitCode':result,'elapsedSeconds':time.time()-start,'host':platform.platform(),'sourceStable':before==after,'sourceCount':len(before),'artifact':str(artifact),'artifactSha256':hashlib.sha256(artifact.read_bytes()).hexdigest() if artifact.exists() else None,'rustc':subprocess.check_output(['rustc','-Vv'],text=True),'scope':'Stage49 typed keys, eager selection/name inference, public URI/contents/repl/query lifecycle, extended native adapter. Query/module code payload and captured environments are traced and retired; non-tail arena index slots still accumulate unbounded history metadata. Core runtime/bindings match build03 which passed default five Rust checks. The sole delta is native probe ELEMENT_DEFAULT input support; fresh build/fmt/clippy and oracle/platform acquisition are recorded separately.','status':'CLOSED' if result==0 and before==after else 'FAILED'}
save('build.json',report); print(json.dumps(report,indent=2)); raise SystemExit(0 if report['status']=='CLOSED' else 1)
