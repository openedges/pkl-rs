"""Record root source review and immutable baseline preservation after source freeze."""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();baseline='6d3f1a1340faa967f116ec553490a87cf6c48235'
paths=['crates/pkl-runtime/src/'+name for name in ['parser.rs','resolver.rs','vm.rs','vm/generics.rs','vm/generics/tests.rs','vm/reference.rs','vm/typecheck.rs']]
paths+=['crates/pkl-runtime/tests/m2_collection_type_lifecycle.rs','tools/m1_platforms.py','tools/platform/run.mjs','tools/platform/scenarios.mjs','tools/platform/collection-type-cases.mjs','tools/tests/test_m1_platforms.py']
old_tests=subprocess.check_output(['git','ls-tree','-r','--name-only',baseline,'crates/pkl-runtime/tests'],text=True).splitlines()
for name in old_tests:
    assert (root/name).read_bytes()==subprocess.check_output(['git','show',baseline+':'+name]),name
prior_metadata=subprocess.check_output(['git','show',baseline+':crates/pkl-runtime/src/vm/generics/tests.rs'])
current_metadata=(root/'crates/pkl-runtime/src/vm/generics/tests.rs').read_bytes()
old_tail=prior_metadata[prior_metadata.index(b'#[test]'):]
assert current_metadata.endswith(old_tail),'historical internal metadata tests changed'
record=dict(status='pass',scope='Root independent source review of Collection<T> runtime, empty explicit generic-argument parsing, native lifecycle assertions and actual-target wiring. Root authored documentation and final verification orchestration but no production implementation, test cases, platform payload or exploration captures.',source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},self_reviewed_sources=[],independently_reviewed_sources=paths,baseline_preservation=dict(commit=baseline,unchanged_native_test_files=len(old_tests),historical_internal_metadata_test_bytes_preserved=True),findings=[
 'CollectionBase is a distinct abstract type node, not a concrete heap CollectionKind. Bare checks accept only List or Set; parameterized checks retain the abstract executable type while dispatching to existing List/Set continuations.',
 'List elements retain nested lazy wrappers; Set checks remain eager and preserve original keys. Type-child indexing, active receivers and shared actual arguments continue through the common continuation and GC root model.',
 'Collection defaults construct empty Lists without constructing element defaults. Selected nullable and union defaults retain their attached List through the existing amendment path; nonnullable external-class amendment failures remain observable.',
 'Executable checker equivalence distinguishes separate parameterized Collection nodes, while Reference normalization and metadata keys retain structural Collection identity. List/Set covariance into Collection is handled separately from Collection-to-List/Set relationships.',
 'Collection children participate in generic substitution, deferred Reference validation, constraint traversal, shared last-owner reclamation, normalization, metadata keys, subtype and exported type-name traversal. The new 20,000-level metadata test uses a 256 KiB stack and leaves prior test bytes intact.',
 'The parser rejects an explicit empty type-argument list at the closing token. Trailing commas remain supported. The authored parser depth and node limits are unchanged.',
 'Seven native lifecycle cases cover List/Set timing, suspended constraint context, retained temporary receivers, Host reentry and retry, 24 cancellations, evaluator isolation, stale handles and terminal release. Poll and GC conditions are explicit and historical resource contracts remain unchanged.',
 'Both actual Node and browser scenario wiring compare complete Java-derived payloads over ordered calls, twice per fixture. Required scenario inventory is additive. The static browser route includes the new payload module; shared evaluation remains in Rust.'
],limits=[
 'Source review is separate from recorded Java comparisons, workspace validation and actual platform execution. Final suite reports establish those outcomes.',
 'Distinct-node and same-function wrapper observations do not establish complete alias-root identity or generic wrapper equivalence outside selected cases.',
 'Deep shared-metadata checks do not exercise deeply authored parser input or establish Java diagnostic, wall-time or peak-RSS parity.',
 'Early exploration retains exact artifact/input/outcome identities where full recorded build/source closure was absent; source binding is not inferred retroactively. Final recorded artifacts and fresh original-URI replays have separate provenance.',
 'General compound rendering, full collection APIs, JVM identity-dependent hashes, remaining type/Reference/module rules, complete upstream suites, product APIs and release-platform/performance requirements remain open.'
])
out=root/'target/m2/stage24-root-review-final-01.json'
with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(dict(reviewed_sources=len(paths),unchanged_native_test_files=len(old_tests),status='pass')))
