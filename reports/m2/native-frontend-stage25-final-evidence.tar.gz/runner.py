"""Capture authored frontend native stack and lifetime tests."""
from pathlib import Path
import datetime,hashlib,json,os,platform,shutil,signal,subprocess,sys,time
root=Path.cwd(); out=root/sys.argv[1]; out.mkdir(parents=True,exist_ok=False)
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=set()
for folder in ['crates/pkl-runtime/src']:
 paths.update(p for p in (root/folder).rglob('*') if p.is_file() and 'node_modules' not in p.parts and p.suffix in {'.rs','.pkl','.mjs','.json'})
paths.update(root/p for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','crates/pkl-runtime/Cargo.toml','crates/pkl-runtime/tests/m2_frontend_lifecycle.rs'])
before={str(p.relative_to(root)):sha(p) for p in sorted(paths)}
for p in sorted(paths):
 dest=out/'sources'/p.relative_to(root); dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
commands=[]
def execute(name,cmd,timeout):
 start=time.monotonic();p=subprocess.Popen(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed_out=False
 try:stdout,stderr=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
 (out/f'{name}.stdout.bin').write_bytes(stdout);(out/f'{name}.stderr.bin').write_bytes(stderr)
 row=dict(name=name,command=[str(x) for x in cmd],exit_code=p.returncode,timed_out=timed_out,timeout_seconds=timeout,elapsed_seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest());commands.append(row)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n'); print(json.dumps(row),flush=True)
 return stdout,p.returncode
execute('git-head',['git','rev-parse','HEAD'],10);execute('git-status',['git','status','--porcelain=v1'],10);execute('rust-version',['rustc','-Vv'],10)
raw,status=execute('build',['cargo','test','-p','pkl-runtime','--locked','--test','m2_frontend_lifecycle','--no-run','--message-format=json'],180)
artifacts=[]
if status==0:
 for line in raw.splitlines():
  obj=json.loads(line)
  if obj.get('reason')=='compiler-artifact' and obj.get('executable') and obj['target']['name']=='m2_frontend_lifecycle':
   p=Path(obj['executable']);dest=out/'artifacts'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest);artifacts.append(dict(path=str(dest.relative_to(out)),sha256=sha(dest),bytes=dest.stat().st_size))
   execute('native-lifecycle',[str(dest),'--nocapture','--test-threads=1'],360)
after={str(p.relative_to(root)):sha(p) for p in sorted(paths)}
report=dict(scope='Authored frontend stack safety and native Host lifetime; not Java equivalence or unrestricted syntax support',host=platform.platform(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),conditions=dict(expected_top_level_tests=5,thread_stack_bytes=262144,parent_deadline_seconds_per_test=60,authored_ordinary_depth=768,authored_module_width=1024,accepted_control_depths=[24,31],accepted_type_argument_depths=[24,31],type_near_boundary_scope='parse, Module clone and drop only; unchanged full type compiler excluded',accepted_amendment_parent_depth=64,excluded_observations=['deeply nested lexical strings on small stacks', 'near-boundary full recursive type compiler'],accepted_composed_type_named_layers=8,guarded_control_depth=64,guarded_composed_type_named_layers=16,guarded_composed_type_nullable_per_layer=16,grouping_layers_per_control_boundary=8,guarded_type_suffix_depth=64,guarded_generator_depth=64,work_budget_rejection_unary_depth=70000,shared_interpolation_budget_unary_depth_per_argument=20000,host_poll_budget=1,gc_cadence='every yielded Host poll and every pending read',max_polls_per_host_event=200000,frontend_lifecycle='parse, Module clone/drop, resolve, ResolvedModule clone/drop, compile, Program drop all on same stack',host_lifecycle='one authored-depth source: nested read, failed child retry, parent cancellation and terminal cleanup'),source_stability=before==after,source_sha256_before=before,source_sha256_after=after,artifacts=artifacts,commands=commands)
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');(out/'evidence-sha256.json').write_text(json.dumps({str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()},indent=2)+'\n')
raise SystemExit(int(not report['source_stability'] or any(x['exit_code']!=0 or x['timed_out'] for x in commands)))
