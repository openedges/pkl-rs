"""Bind frozen Stage57 source evidence to an explicitly supplied implementation B Git commit.

Prepared before B. Execute only after root supplies --commit and GO. No guests/builds/tests.
"""
import argparse,collections,datetime,gzip,hashlib,io,json,pathlib,re,stat,subprocess,tarfile
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=ROOT/'target/m2/stage57-source-binding-01'
PUBLIC=ROOT/'reports/m2/stage57-source-binding.json'
ARCHIVE=ROOT/'reports/m2/stage57-source-binding-evidence.tar.gz'
BASE='e05508fcc5200b6330011c15a5f1bcc6a34c3a13'
PIN={'external/pkl':'e51fb2f91774265666f94980ec630db794a4db2d','external/pkl-pantry':'904a68184e54da378b0a0e8a911a3fab3956f693'}
MANIFESTS={
 'rust_validation_03':('target/m2/stage57-rust-validation-03/sources.json','37176eaf2a34890a27ebd9ee68f9bc09a6fd292521b0b9746808951d7640536b',165210),
 'runtime_build_08':('target/m2/stage57-native-build-08/source-before.json','099aac28d07071e2c1389e01df0aeeeaa52f5a3466cacf47543bd3d22528c305',252),
 'native_comparison_02':('target/m2/stage57-native-comparison-02/sources.json','810fd34dc63d9c5a66013ec9ac56e49dc7dc04ecd2160709f80b655f4ac0a8f5',4586),
 'm1_platforms_contract_01':('target/m2/stage57-m1-platform-contract-01/sources.json','9197b7fc9ce6ce18f4c76e3b6d48bc278ff97883154c0b01d35b16b3012f786a',229),
 'capture_wrapper_04':('target/m2/stage57-platform-validation-04/acquisition-source-before.json','52c6e660b45c35c1ee0ea70841a94fc598f4cffba3e33e59387752391260b6b4',383),
 'original_17':('target/m2/stage57-original-data-size-01/sources.json','7827d943f69e97bda1510e2b9fbff2220108615e7fa8d9d29b0e78de633a330c',4573),
}
PUBLIC_ARCHIVES={
 'validation':'reports/m2/stage57-validation-evidence.tar.gz',
 'native':'reports/m2/stage57-native-evidence.tar.gz',
 'original':'reports/m2/stage57-original-evidence.tar.gz',
 'platform':'reports/m2/stage57-platform-evidence.tar.gz',
}
EXPECTED_ARCHIVE_SHA={
 'validation':'3017d9caec31b254414126bdba955ff604a653be54d1e93beefacede196595ad',
 'native':'664309fa174f20e721fb8bd260b1a974b4f0517f0b5bfb42ffa1c3cb52e726ed',
 'original':'85b7929f97de81e0d9e22b91079b2e870416e056fae77ee999f7fd3eabcf6bbb',
 'platform':'7c6f458fe3695ee83b641c6107958c9cbf1bbec51dc4d7cf371bf62595598fa5',
}
COPIES={
 'native_comparison_02':'target/m2/stage57-native-comparison-02/sources',
 'm1_platforms_contract_01':'target/m2/stage57-m1-platform-contract-01/sources',
 'original_17':'target/m2/stage57-original-data-size-01/sources',
}
ARCHIVE_MEMBERS={
 'native_comparison_02':('native','target/m2/stage57-native-comparison-02/sources/'),
 'm1_platforms_contract_01':('platform','evidence/stage57-m1-platform-contract-01/sources/'),
 'original_17':('original','target/m2/stage57-original-data-size-01/sources/'),
}

def digest(p):
 h=hashlib.sha256();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b);n+=len(b)
 return {'sha256':h.hexdigest(),'bytes':n}
def rawj(x):return(json.dumps(x,sort_keys=True,indent=2)+'\n').encode()
def run(*a):
 p=subprocess.run(a,cwd=ROOT,capture_output=True)
 assert p.returncode==0,(a,p.returncode,p.stderr[-1000:])
 return p.stdout
def tree(repo,commit):
 rows={}
 for entry in run('git','-C',str(repo),'ls-tree','-rz','--full-tree',commit).split(b'\0'):
  if not entry:continue
  head,path=entry.split(b'\t',1);mode,kind,oid=head.split(b' ')
  rows[path.decode('utf-8','surrogateescape')]=(mode.decode(),kind.decode(),oid.decode())
 return rows
def logical(name):
 if name.startswith('external/pkl-pantry/'):return 'external/pkl-pantry',name[len('external/pkl-pantry/'):]
 if name.startswith('external/pkl/'):return 'external/pkl',name[len('external/pkl/'):]
 return '.',name
def blob_audit(repo,oids):
 p=subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 result={}
 try:
  for oid in sorted(oids):
   p.stdin.write((oid+'\n').encode());p.stdin.flush()
   header=p.stdout.readline().strip().split(b' ')
   assert len(header)==3 and header[0].decode()==oid and header[1]==b'blob',(oid,header)
   size=int(header[2]);left=size;sha1=hashlib.sha1(b'blob '+str(size).encode()+b'\0');sha256=hashlib.sha256()
   while left:
    b=p.stdout.read(min(1<<20,left));assert b,(oid,left)
    sha1.update(b);sha256.update(b);left-=len(b)
   assert p.stdout.read(1)==b'\n' and sha1.hexdigest()==oid
   result[oid]={'sha256':sha256.hexdigest(),'bytes':size,'framed_sha1':sha1.hexdigest()}
  p.stdin.close();assert p.wait()==0,p.stderr.read()[-1000:]
  return result
 finally:
  if p.poll() is None:p.kill();p.wait()
def blob_bytes(repo,oid,expected):
 b=run('git','-C',str(repo),'cat-file','blob',oid)
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid
 assert {'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}==expected
 return b

def main(commit):
 assert ROOT==pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
 assert re.fullmatch(r'[0-9a-f]{40}',commit),'explicit B commit required'
 assert not PUBLIC.exists() and not ARCHIVE.exists() and not (OUT/'report.json').exists()
 assert run('git','cat-file','-t',commit).strip()==b'commit'
 repo={'.':ROOT,**{k:ROOT/k for k in PIN}}
 btree={'.':tree(ROOT,commit),**{k:tree(ROOT/k,v) for k,v in PIN.items()}}
 base_tree=tree(ROOT,BASE)
 for sub,pin in PIN.items():assert btree['.'].get(sub)==('160000','commit',pin),(sub,btree['.'].get(sub))
 manifests={};man_before={};copies_before={}
 for label,(rel,expected,count) in MANIFESTS.items():
  p=ROOT/rel;row=digest(p);assert row['sha256']==expected
  data=json.loads(p.read_bytes());assert isinstance(data,dict) and len(data)==count
  manifests[label]=data;man_before[rel]=row
 assert manifests['runtime_build_08']==json.loads((ROOT/'target/m2/stage57-native-build-08/source-after.json').read_bytes())
 assert manifests['capture_wrapper_04']==json.loads((ROOT/'target/m2/stage57-platform-validation-04/acquisition-source-after.json').read_bytes())
 for label,folder in COPIES.items():
  for name,value in manifests[label].items():
   p=ROOT/folder/name;assert p.is_file() and not p.is_symlink(),p
   row=digest(p);expected=value if isinstance(value,str) else value['sha256']
   assert row['sha256']==expected and (isinstance(value,str) or row['bytes']==value['bytes']),(label,name)
   copies_before[str(p.relative_to(ROOT))]=row
 archive_before={}
 for label,rel in PUBLIC_ARCHIVES.items():
  row=digest(ROOT/rel);assert row['sha256']==EXPECTED_ARCHIVE_SHA[label]
  archive_before[rel]=row
 # The actual B tree points to the public archive blobs, including historical transport bytes.
 required_oids={k:set() for k in repo}
 for rel in PUBLIC_ARCHIVES.values():
  entry=btree['.'].get(rel);assert entry and entry[:2]==('100644','blob'),(rel,entry)
  required_oids['.'].add(entry[2])
 rust=manifests['rust_validation_03'];copied=0;origin_counts=collections.Counter();prepared=[]
 for name,v in rust.items():
  origin=v['origin'];k,relative=logical(name);assert origin['kind'] in ('git-blob','captured-file')
  if origin['kind']=='git-blob':
   assert origin['repository']==k and origin['path']==relative
   expected_commit=BASE if k=='.' else PIN[k]
   assert origin['commit']==expected_commit
   historical=base_tree if k=='.' else btree[k]
   assert historical.get(relative)==(origin['mode'],'blob',origin['oid']),(name,origin)
   required_oids[k].add(origin['oid'])
   origin_counts['base_git' if k=='.' else 'pinned_submodule_git']+=1
  else:
   p=ROOT/'target/m2/stage57-rust-validation-03'/origin['path'];assert p.is_file() and not p.is_symlink()
   row=digest(p);assert row=={'sha256':v['sha256'],'bytes':v['bytes']}
   copies_before[str(p.relative_to(ROOT))]=row;copied+=1;origin_counts['captured_file']+=1
  prepared.append(('rust_validation_03',name,v['sha256'],v['bytes'],v.get('input_mode'),origin))
 assert copied==26 and sum(origin_counts.values())==165210
 for label in ('runtime_build_08','native_comparison_02','m1_platforms_contract_01','capture_wrapper_04','original_17'):
  for name,v in manifests[label].items():
   sha=v if isinstance(v,str) else v['sha256'];size=None if isinstance(v,str) else v.get('bytes')
   prepared.append((label,name,sha,size,None,None))
 for label,name,sha,size,mode,origin in prepared:
  k,relative=logical(name);entry=btree[k].get(relative)
  if entry and entry[1]=='blob':required_oids[k].add(entry[2])
 blob={k:blob_audit(repo[k],required_oids[k]) for k in repo}
 # Check all recorded Git origins against actual SHA1-framed blob bytes, including the 120000 symlink target.
 symlink=[]
 for name,v in rust.items():
  origin=v['origin']
  if origin['kind']=='git-blob':
   k,_=logical(name);actual=blob[k][origin['oid']]
   assert actual['sha256']==v['sha256'] and actual['bytes']==v['bytes']
   assert origin['mode']==v['input_mode']
   if origin['mode']=='120000':symlink.append((name,actual))
 assert len(symlink)==1 and symlink[0][1]['bytes']==6
 # Verify archived source payloads through the actual B Git archive blobs; M1 old JS is historical.
 archived_counts={};archived_sha={}
 for label,rel in PUBLIC_ARCHIVES.items():
  oid=btree['.'][rel][2];actual=blob['.'][oid];assert actual=={**archive_before[rel],'framed_sha1':oid}
  archived_sha[label]={'path':rel,'oid':oid,**archive_before[rel]}
 for category,(archive_label,prefix) in ARCHIVE_MEMBERS.items():
  rel=PUBLIC_ARCHIVES[archive_label];oid=btree['.'][rel][2]
  b=blob_bytes(ROOT,oid,archive_before[rel]);seen=set()
  with tarfile.open(fileobj=io.BytesIO(b),mode='r:gz') as tar:
   for name,value in manifests[category].items():
    member=tar.getmember(prefix+name);assert member.isfile() and member.name not in seen
    payload=tar.extractfile(member).read();expected=value if isinstance(value,str) else value['sha256']
    assert hashlib.sha256(payload).hexdigest()==expected
    if isinstance(value,dict):assert len(payload)==value['bytes']
    seen.add(member.name)
  assert len(seen)==len(manifests[category]);archived_counts[category]=len(seen)
 # Explicitly distinguish old M1 JS stored in committed archive from B's current source path.
 old_path='tools/platform/capture-data-size.mjs';old_sha=manifests['m1_platforms_contract_01'][old_path]
 assert old_sha=='082c0922ec9558a8607f0f2823c3608d6b00cdf8094fcadbbaca46b02faf2487'
 current_sha=manifests['capture_wrapper_04'][old_path]['sha256']
 assert current_sha=='66c77ba1d51ed6ee18373214656d83b7ac2129ebe1cd885a215c184fd260c962'
 assert old_sha!=current_sha
 platform_blob=blob_bytes(ROOT,btree['.'][PUBLIC_ARCHIVES['platform']][2],archive_before[PUBLIC_ARCHIVES['platform']])
 with tarfile.open(fileobj=io.BytesIO(platform_blob),mode='r:gz') as tar:
  for member,expected in [('evidence/stage57-m1-platform-contract-01/sources/'+old_path,old_sha),('current-source/'+old_path,current_sha)]:
   data=tar.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==expected
 statuses=collections.defaultdict(collections.Counter);examples=collections.defaultdict(list)
 rows=OUT/'rows.jsonl.gz'
 with rows.open('xb') as raw:
  with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0,compresslevel=6) as zipped:
   for label,name,expected,size,expected_mode,origin in prepared:
    k,relative=logical(name);entry=btree[k].get(relative)
    row={'category':label,'path':name,'repository':k,'expected_sha256':expected,'expected_bytes':size,'expected_mode':expected_mode}
    if origin:row['origin']=origin
    if entry is None:status='missing_in_B'
    elif entry[1]!='blob':status='nonblob_in_B';row.update(B_mode=entry[0],B_type=entry[1],B_oid=entry[2])
    else:
     mode,kind,oid=entry;v=blob[k][oid]
     row.update(B_mode=mode,B_oid=oid,B_sha256=v['sha256'],B_bytes=v['bytes'])
     equal=(v['sha256']==expected and (size is None or v['bytes']==size) and (expected_mode is None or mode==expected_mode))
     status='matches_B' if equal else 'differs_from_B_historical_snapshot'
     if label=='m1_platforms_contract_01' and name==old_path:
      assert not equal and archived_counts[label]==229
      status='historical_transport_archived_in_B';row['archive_member']='evidence/stage57-m1-platform-contract-01/sources/'+name
    row['status']=status;statuses[label][status]+=1
    if status!='matches_B' and len(examples[label])<30:examples[label].append({'path':name,'status':status,'expected_sha256':expected,'B_sha256':row.get('B_sha256')})
    zipped.write((json.dumps(row,sort_keys=True,separators=(',',':'))+'\n').encode())
 assert sum(statuses['rust_validation_03'].values())==165210
 assert statuses['runtime_build_08']=={'matches_B':252},statuses['runtime_build_08']
 for name,v in rust.items():
  if v['origin']['kind']=='captured-file':
   k,relative=logical(name);entry=btree[k].get(relative);assert entry and entry[1]=='blob'
   actual=blob[k][entry[2]];assert actual['sha256']==v['sha256'] and actual['bytes']==v['bytes'] and entry[0]==v['input_mode']
 assert statuses['m1_platforms_contract_01']['historical_transport_archived_in_B']==1
 assert sum(sum(v.values()) for v in statuses.values())==165210+252+4586+229+383+4573
 # Confirm all raw inputs are still byte-identical after Git reads and publication.
 assert {rel:digest(ROOT/rel) for rel in man_before}==man_before
 assert {rel:digest(ROOT/rel) for rel in archive_before}==archive_before
 assert {rel:digest(ROOT/rel) for rel in copies_before}==copies_before
 report={'schema':1,'kind':'Actual Git-object source binding for Stage57 implementation B','B_commit':commit,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'source_origin_method':'Actual e055 base/pinned submodule/B tree OIDs and mode, SHA1-framed Git blob reads plus raw SHA256/size; copied source bytes reread. B overlap and historical differences remain distinct.',
  'recorded_base_commit':BASE,'gitlinks':PIN,'manifests':{k:{'path':MANIFESTS[k][0],**man_before[MANIFESTS[k][0]],'rows':MANIFESTS[k][2]} for k in MANIFESTS},
  'category_statuses':{k:dict(v) for k,v in statuses.items()},'noncurrent_examples':dict(examples),'rust_origin_counts':dict(origin_counts),'rust_captured_26_match_B':True,'runtime_build_252_match_B':True,
  'symlink_120000_target_verified':{'path':symlink[0][0],'target_bytes':6,'sha256':symlink[0][1]['sha256']},'archived_source_member_counts':archived_counts,
  'historical_M1_transport':{'path':old_path,'old_sha256':old_sha,'B_current_sha256':current_sha,'status':'historical_transport_archived_in_B','archive':archived_sha['platform'],'old_member':'evidence/stage57-m1-platform-contract-01/sources/'+old_path,'current_member':'current-source/'+old_path},
  'B_archive_blobs':archived_sha,'unique_blob_objects_read':{k:len(v) for k,v in blob.items()},'copied_source_files_stable':len(copies_before),'row_details':{'path':str(rows.relative_to(ROOT)),**digest(rows)},
  'limitations':['Rows with historical bytes differing from B are identified individually and are not claimed as current B sources.','M1 old pre-favicon JavaScript is bound as a member of the committed platform archive, not the current source path.','Source binding does not rerun evaluators/builds/tests or prove full public API, whole M2 or performance targets.']}
 (OUT/'report.json').write_bytes(rawj(report))
 payloads={'report.json':OUT/'report.json','rows.jsonl.gz':rows,'binder.py':pathlib.Path(__file__)}
 inventory={n:{'mode':stat.S_IMODE(p.stat().st_mode),**digest(p)} for n,p in payloads.items()}
 manifest=rawj({'schema':1,'files':inventory})
 with ARCHIVE.open('xb') as a:
  with gzip.GzipFile(fileobj=a,mode='wb',filename='',mtime=0,compresslevel=6) as g:
   with tarfile.open(fileobj=g,mode='w|',format=tarfile.PAX_FORMAT) as t:
    for n,p in [('manifest.json',None),*sorted(payloads.items())]:
     data=manifest if p is None else p.read_bytes();entry=tarfile.TarInfo(n);entry.size=len(data);entry.mode=0o644 if p is None else inventory[n]['mode'];entry.uid=entry.gid=0;entry.uname=entry.gname='';entry.mtime=0;t.addfile(entry,io.BytesIO(data))
 assert digest(ARCHIVE)['bytes']<90*1024*1024
 seen={}
 with tarfile.open(ARCHIVE,'r:gz') as t:
  for e in t:
   assert e.isfile() and e.name not in seen and not e.name.startswith('/') and '..' not in pathlib.PurePosixPath(e.name).parts
   b=t.extractfile(e).read();seen[e.name]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'mode':e.mode}
 assert seen.pop('manifest.json')=={'sha256':hashlib.sha256(manifest).hexdigest(),'bytes':len(manifest),'mode':0o644}
 assert seen==inventory
 assert {n:{'mode':stat.S_IMODE(p.stat().st_mode),**digest(p)} for n,p in payloads.items()}==inventory
 publication={'schema':1,'binding_report':report,'evidence_archive':{'path':str(ARCHIVE.relative_to(ROOT)),**digest(ARCHIVE),'members':len(seen)+1},'full_archive_reread_verified':True,'original_sources_stable_before_after':True,'whole_M2_complete':False,'full_public_api_comparison_passed':False,'performance_targets_achieved':False}
 PUBLIC.write_bytes(rawj(publication))
 print(json.dumps({'B_commit':commit,'category_statuses':report['category_statuses'],'evidence_archive':publication['evidence_archive'],'report':digest(PUBLIC)},sort_keys=True))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--commit',required=True,help='Actual root supplied 40-hex implementation B commit')
 main(p.parse_args().commit)
