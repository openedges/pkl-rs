# Early Stage51 immutable history

This archive preserves one logical unit of the original diagnostic build01, initial 1,060-call native acquisition and readback, or candidate02's 1,272-call native/portable acquisition and authenticated readback. These are historical bounded results, not a final candidate or full language/API compatibility.

The initial Node comparison executable path and digest were not recorded. They remain unknown; current Node identity is not retroactively substituted. Frozen historical source snapshots are not claimed to be current Git blobs. Readback authenticates preserved raw observations and does not add an evaluator run or extra compatibility coverage.

Candidate02's first native parser rejected 12 sessions because it did not consume post-close api-error-kind.bin metadata. The failed report and all original raw files remain intact. Its later readback parsed all 1,272 original calls without evaluator reexecution, still leaving 12 ordinary mismatches and 12 post-close raw boundaries. Portable Node/Chromium results remain their separately recorded failed strict gates. Different 1,060/1,272 corpus totals must not be subtracted to infer feature fixes.

Every selected original file is retained, including copied fixtures, source snapshots, tools, outputs, errors, process metadata and recorded provenance limitations. No source/output duplicate exclusion or cache-name filter is applied to the nine explicit closed roots. CAPTURE_SELECTION.json records exact original paths, hashes, sizes and modes. Archive creation, separate verification, raw-member readback and original guards are recorded by the preparation producer. No Java, evaluator, native engine, browser, or build was run while packaging.
