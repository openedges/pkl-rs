from pathlib import Path
import json,hashlib
O=Path(__file__).parent;cases=[]
def case(name,mode,source,ops,other=None):
 p=O/'workspace'/name;p.mkdir(parents=True)
 (p/'main.pkl').write_text(source);(p/'other.pkl').write_text(source if other is None else other)
 (p/'operations.tsv').write_text('\n'.join('GC' if x=='GC' else '\t'.join(x) for x in ops)+'\n')
 row={'id':name,'mode':mode,'workspace':str(p),'sourceUri':(p/'main.pkl').as_uri(),'sourceSha256':hashlib.sha256((p/'main.pkl').read_bytes()).hexdigest(),'operations':ops,'evaluatorSessionsPerFreshJvm':2,'freshJvmRepeats':2};cases.append(row);return p
source='''b = import("pkl:base")
a = read("res:/a/../key")
bb = read("res:/key")
c = read?("res:/./key")
missingNullable = read?("res:/x/../missing").toString()
missingOrdinary = read("res:/missing")
missingOtherSpelling = read("res:/./missing")
retry = read("res:/retry")
retryNullable = read?("res:/./retry")
r = read("res:/resource")
rAlias = read("res:/x/../resource")
rUri = r.uri
rText = r.text
rBase64 = r.base64
rBytesBase64 = r.bytes.base64
rClass = r.getClass().toString()
rType = (r is Resource).toString()
rClassEquality = (r.getClass() == b.Resource).toString()
rEquality = (r == rAlias).toString()
renderer = new PcfRenderer {}
rRender = renderer.renderValue(r)
stable = "stable"
'''
ops=[('main.pkl',x) for x in ['a','bb','c','missingNullable','missingOrdinary','missingOrdinary','missingOtherSpelling','retry','stable','retry','retryNullable','rUri','rText','rBase64','rBytesBase64','rClass','rType','rClassEquality','rEquality','rRender']]+['GC']+[('main.pkl','rText'),('other.pkl','bb'),('other.pkl','missingNullable'),('other.pkl','rUri'),('other.pkl','retry')]
case('cache-text-resource-missing-retry','cache',source,ops)
uris=['res:/a/../key','res:/key','RES:/key','res:/%6a','res:/%6A','res:/j','res:/key#one','res:/key#two','res:./key','res:a/../key','res:key','res:/./key','res://HOST/key','res://host/key','res:///key','res:/space%20name','res:/é']
for order in ['lower-first','upper-first']:
 values=list(uris)
 if order=='upper-first':values=[values[2],values[1],values[0]]+values[3:]
 text=''.join('u'+str(i)+' = read('+json.dumps(uri,ensure_ascii=False)+')\n' for i,uri in enumerate(values))+'stable = "stable"\n'
 ops=[('main.pkl','u'+str(i)) for i in range(len(values))]+[('other.pkl','u1'),('main.pkl','stable')]
 p=case('uri-keys-'+order,'cache',text,ops);(p/'uris.json').write_text(json.dumps(values,indent=2,ensure_ascii=True)+'\n')
source='''a = read("res:/denied")
b = read?("res:/denied")
c = read("unknown:/ok")
d = read?("unknown:/ok")
e = read("forbidden:/x")
f = read?("forbidden:/x")
ioNull = read("res:/io-null")
ioNullQ = read?("res:/io-null")
ioEmpty = read("res:/io-empty")
ioUnits = read("res:/io-units")
stable = "stable"
'''
case('policy-no-reader-io','policy',source,[('main.pkl',x) for x in ['a','a','b','c','d','e','f','ioNull','ioNull','ioNullQ','ioEmpty','ioUnits','stable']])
vectors=[[],[0],[13,10],[65,13,10,0,66],[0xF0,0x9F,0x98,0x80],[0x80],[0xC0,0xAF],[0xC2],[0xE0,0xA0],[0xED,0xA0,0x80],[0xF0,0x90,0x80],[0xF4,0x90,0x80,0x80],[0xF5,0x80],[0xE1,0x80,65],[0xED,0xA0,65],[0xE0,0x80,0x80],[0xF0,0x80,0x80,0x80],[0xF0,0x90,65,0x80],[0xC2,65],[0xEF,0xBF,0xBD],[0xE1,0x80,0xC2,0xA0],[0xED,0xBF,0xBF],[0xF4,0x8F,0xBF,0xBF],[0xFE,0xFF]]
source='b = import("pkl:base")\nrenderer = new PcfRenderer {}\n';ops=[]
for i,v in enumerate(vectors):
 n='v'+str(i);source+=f'{n} = read("res:/vector{i}")\n{n}Text = {n}.text\n{n}Base64 = {n}.base64\n{n}BytesBase64 = {n}.bytes.base64\n{n}Uri = {n}.uri\n'
 ops += [('main.pkl',n+x) for x in ['Text','Base64','BytesBase64','Uri']]
source+='''className = v0.getClass().toString()
typeCheck = (v0 is Resource).toString()
classEquality = (v0.getClass() == b.Resource).toString()
resourceRender = renderer.renderValue(v3)
custom = new Resource { uri = "res:/custom"; text = "custom"; base64 = "QQ==" }
customClass = (custom.getClass() == Resource).toString()
customBytes = custom.bytes.base64
undefined = new Resource {}
undefinedClass = (undefined.getClass() == Resource).toString()
undefinedRender = renderer.renderValue(undefined)
bad = new Resource { uri = 7; text = "t"; base64 = "" }
badText = bad.text
badUri = bad.uri
stable = "stable"
'''
ops += [('main.pkl',x) for x in ['className','typeCheck','classEquality','resourceRender','customClass','customBytes','undefinedClass','undefinedRender','badText','badUri','stable']]+['GC']+[('main.pkl','v9Text'),('other.pkl','v9Text')]
p=case('resource-bytes-utf8','resource',source,ops);(p/'payloads').mkdir()
for i,v in enumerate(vectors):(p/'payloads'/f'vector{i}.bin').write_bytes(bytes(v))
(p/'vectors.json').write_text(json.dumps(vectors,indent=2)+'\n')
(O/'cases.json').write_text(json.dumps(cases,indent=2,ensure_ascii=True)+'\n')
print({'cases':len(cases),'opsPerJvm':sum(len([x for x in c['operations'] if x!='GC'])*2 for c in cases),'freshJvms':len(cases)*2})
