"""Target-only Set endpoint Java authority exploration inputs."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
URI = "file:///stage63/set-endpoints-exploration.pkl"
rows = []


def add(group, id, expression):
    assert "\t" not in expression and "\n" not in expression
    rows.append({"mode": "string", "group": group, "id": id, "expression": expression})


for id, expression in [
    ("set-empty-first", "Set().first"),
    ("set-empty-first-or-null", "Set().firstOrNull"),
    ("set-empty-last", "Set().last"),
    ("set-empty-last-or-null", "Set().lastOrNull"),
    ("list-empty-first", "List().first"),
    ("list-empty-first-or-null", "List().firstOrNull"),
    ("list-empty-last", "List().last"),
    ("list-empty-last-or-null", "List().lastOrNull"),
]: add("empty", id, expression)

for id, expression in [
    ("set-single-first", "Set(7).first"),
    ("set-single-first-or-null", "Set(7).firstOrNull"),
    ("set-single-last", "Set(7).last"),
    ("set-single-last-or-null", "Set(7).lastOrNull"),
    ("set-null-first", "Set(null).first"),
    ("set-null-first-or-null", "Set(null).firstOrNull"),
    ("set-null-last", "Set(null).last"),
    ("set-null-last-or-null", "Set(null).lastOrNull"),
    ("list-single-first", "List(7).first"),
    ("list-single-last", "List(7).last"),
]: add("single", id, expression)

for id, expression in [
    ("set-many-first", "Set(3, 1, 2).first"),
    ("set-many-first-or-null", "Set(3, 1, 2).firstOrNull"),
    ("set-many-last", "Set(3, 1, 2).last"),
    ("set-many-last-or-null", "Set(3, 1, 2).lastOrNull"),
    ("set-dup-first", "Set(3, 1, 3, 2, 1).first"),
    ("set-dup-first-or-null", "Set(3, 1, 3, 2, 1).firstOrNull"),
    ("set-dup-last", "Set(3, 1, 3, 2, 1).last"),
    ("set-dup-last-or-null", "Set(3, 1, 3, 2, 1).lastOrNull"),
    ("union-list-first", "(Set(1) + List(2, 1, 3)).first"),
    ("union-list-last", "(Set(1) + List(2, 1, 3)).last"),
    ("union-set-first", "(Set(1) + Set(2, 3)).first"),
    ("union-set-last", "(Set(1) + Set(2, 3)).last"),
    ("list-many-first", "List(3, 1, 2).first"),
    ("list-many-last", "List(3, 1, 2).last"),
]: add("order", id, expression)

for id, expression in [
    ("set-duration-first-unit", "Set(1.min, 60.s).first.unit"),
    ("set-duration-last-unit", "Set(1.min, 60.s).last.unit"),
    ("set-duration-reverse-first-unit", "Set(60.s, 1.min).first.unit"),
    ("set-duration-reverse-last-unit", "Set(60.s, 1.min).last.unit"),
    ("union-duration-left-unit", "(Set(1.min) + Set(60.s)).first.unit"),
    ("union-duration-right-unit", "(Set(60.s) + Set(1.min)).last.unit"),
    ("set-object-first-value", "Set(new Dynamic { value = 1 }).first.value"),
    ("set-object-last-value", "Set(new Dynamic { value = 1 }).last.value"),
    ("set-function-first-apply", "Set((x) -> x + 1).first.apply(2)"),
]: add("retained-value", id, expression)

for id, expression in [
    ("set-hash-before-first", 'Set(new Dynamic { value = throw("hash-first") }).first'),
    ("set-hash-before-last", 'Set(1, new Dynamic { value = throw("hash-last") }).last'),
    ("set-arg-before-empty-check", 'Set(throw("argument")).first'),
    ("list-lazy-first-class", 'List(new Dynamic { value = throw("nested") }).first.getClass()'),
    ("list-lazy-first-read", 'List(new Dynamic { value = throw("nested") }).first.value'),
    ("set-empty-first-fallback", 'Set().first ?? 9'),
    ("set-empty-or-null-fallback", 'Set().firstOrNull ?? 9'),
]: add("force", id, expression)

for id, expression in [
    ("set-first-as-method", "Set(1).first()"),
    ("set-last-as-method", "Set(1).last()"),
    ("set-first-or-null-as-method", "Set(1).firstOrNull()"),
    ("set-last-or-null-as-method", "Set(1).lastOrNull()"),
    ("set-empty-first-as-method", "Set().first()"),
    ("set-misspelled-first", "Set(1).frist"),
    ("set-method-argument-throw", 'Set(1).first(throw("argument"))'),
    ("set-empty-method-argument-throw", 'Set().first(throw("argument"))'),
    ("list-first-as-method", "List(1).first()"),
    ("list-last-as-method", "List(1).last()"),
]: add("diagnostic", id, expression)

(ROOT / "module.pkl").write_text('tag = "stage63-set-endpoints-exploration"\n')
(ROOT / "queries.tsv").write_text("".join(
    f"{row['mode']}\t{row['id']}\t{row['expression']}\n" for row in rows))
(ROOT / "cases.json").write_text(json.dumps({"schema": 1, "baseline": "Pkl 0.32.0",
    "module_uri": URI, "boundary": "string", "repetitions": 2,
    "rows": rows}, indent=2, sort_keys=True) + "\n")
print(len(rows))
