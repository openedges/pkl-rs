"""Target-only, independent Pkl 0.32.0 Java collection-addition exploration."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = HERE / "capture-01"
INPUTS = ("author.py", "run.py", "module.pkl", "queries.tsv", "cases.json", "CollectionConversionsOracle.java")
SOURCES = (
    "oracle.lock.json", "references.lock", "external/pkl/stdlib/base.pkl",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/binary/AdditionNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/binary/BinaryExpressionNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/builder/AstBuilder.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/BaseModule.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmBytes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmClass.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmCollection.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmDynamic.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmList.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmMap.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmObject.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmSet.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmNull.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmExceptionBuilder.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/ExternalPropertyNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmFunction.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmDuration.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/DurationNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/FunctionNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/lambda/ApplyVmFunction1Node.java",
    "external/pkl/pkl-core/src/main/resources/org/pkl/core/errorMessages.properties",
    "external/pkl/pkl-parser/src/main/java/org/pkl/parser/ParserImpl.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmUtils.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmValue.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmValueRenderer.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/ListNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/MapNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/SetNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/StringNodes.java",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/list.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/set.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/map.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/mappings/typeCheck.pkl",
)
CHANNELS = ("mode", "expression", "result.stdout", "result.stderr", "result.error-class",
            "result.exception-to-string", "result.cause-class", "result.cause-message",
            "result.cause-to-string", "result.java-type")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def tree(root):
    return {str(p.relative_to(root)): sha(p) for p in root.rglob("*") if p.is_file()}


def main():
    if OUT.exists():
        raise SystemExit("fresh capture path required; preserve prior attempts")
    cases = json.loads((HERE / "cases.json").read_bytes())
    rows = cases["rows"]
    assert cases["module_uri"] == "file:///stage63/set-endpoints-exploration-02.pkl"
    assert len(rows) == 70 and len({r["id"] for r in rows}) == len(rows)
    assert (HERE / "queries.tsv").read_text() == "".join(
        f"string\t{r['id']}\t{r['expression']}\n" for r in rows)
    lock = json.loads((ROOT / "oracle.lock.json").read_bytes())
    assert lock["version"] == "0.32.0" and lock["source"]["revision"] == "e51fb2f91774265666f94980ec630db794a4db2d"
    jar = ROOT / ".cache/oracle" / lock["artifact"]["filename"]
    assert sha(jar) == lock["artifact"]["sha256"]
    OUT.mkdir()
    for name in INPUTS:
        origin = ROOT / "tools/java/CollectionConversionsOracle.java" if name.endswith(".java") else HERE / name
        shutil.copyfile(origin, OUT / name)
    for name in SOURCES:
        target = OUT / "sources" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    java = Path(os.environ.get("PKL_ORACLE_JAVA", "/usr/bin/java")).resolve()
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC",
           "TERM": "dumb", "NO_COLOR": "1", "COLUMNS": "80"}
    identity_command = [str(java), "-XshowSettings:properties", "-version"]
    identity = subprocess.run(identity_command, cwd=OUT, env=env, capture_output=True, timeout=60)
    (OUT / "java-identity.stdout.bin").write_bytes(identity.stdout)
    (OUT / "java-identity.stderr.bin").write_bytes(identity.stderr)
    if identity.returncode:
        raise RuntimeError("Java identity failed; raw preserved")
    properties = dict(re.findall(r"^\s+([\w.]+) = (.*)$", identity.stderr.decode(), re.M))
    assert all(properties.get(k) == v for k, v in lock["jdk"]["properties"].items())
    home = Path(properties["java.home"])
    jdk = {"identity_command": identity_command, "identity_exit_code": identity.returncode,
           "identity_stdout_sha256": sha(OUT / "java-identity.stdout.bin"),
           "identity_stderr_sha256": sha(OUT / "java-identity.stderr.bin"),
           "executable": str(java), "executable_sha256": sha(java),
           "modules_sha256": sha(home / "lib/modules"), "release_sha256": sha(home / "release"),
           "properties": properties}
    options = [*lock["jvm_options"], f"-Duser.home={env['HOME']}", f"-Djava.io.tmpdir={env['TMPDIR']}"]
    record = {"schema": 1, "scope": "target-only independent pinned Java Set endpoint exploration",
              "host": platform.platform(), "root": str(ROOT), "module_uri": cases["module_uri"],
              "rows": len(rows), "java_helper_origin": "tools/java/CollectionConversionsOracle.java",
              "producer_boundary": "public evaluateExpressionString; internal Vm wrapper reference identity not observed",
              "oracle_lock_sha256": sha(ROOT / "oracle.lock.json"),
              "reference_revision": lock["source"]["revision"],
              "artifact": str(jar), "artifact_sha256": sha(jar), "jdk": jdk,
              "environment": env, "input_before": {n: sha(OUT / n) for n in INPUTS},
              "source_before": {n: sha(ROOT / n) for n in SOURCES},
              "source_copies": {n: sha(OUT / "sources" / n) for n in SOURCES}, "sessions": []}
    save(OUT / "provenance.json", record)
    for repeat in range(2):
        folder = OUT / f"repeat-{repeat}"
        folder.mkdir()
        command = [str(java), *options, "-cp", str(jar), str(OUT / "CollectionConversionsOracle.java"),
                   str(folder), str(OUT), cases["module_uri"]]
        started = time.time()
        process = subprocess.Popen(command, cwd=OUT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            stdout, stderr = process.communicate(timeout=600)
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            (folder / "process.stdout.bin").write_bytes(stdout)
            (folder / "process.stderr.bin").write_bytes(stderr)
            raise RuntimeError("Java session timed out; raw preserved")
        (folder / "process.stdout.bin").write_bytes(stdout)
        (folder / "process.stderr.bin").write_bytes(stderr)
        entry = {"repeat": repeat, "pid": process.pid, "command": command, "cwd": str(OUT),
                 "started_epoch": started, "finished_epoch": time.time(), "exit_code": process.returncode,
                 "stdout_sha256": sha(folder / "process.stdout.bin"), "stderr_sha256": sha(folder / "process.stderr.bin"),
                 "query_directories": sum(p.is_dir() for p in folder.iterdir())}
        record["sessions"].append(entry)
        save(OUT / "provenance.json", record)
        print(json.dumps(entry, sort_keys=True), flush=True)
        if process.returncode or entry["query_directories"] != len(rows):
            raise RuntimeError("Java producer failed; raw preserved")
    record["input_after"] = {n: sha(OUT / n) for n in INPUTS}
    record["source_after"] = {n: sha(ROOT / n) for n in SOURCES}
    record["artifact_after_sha256"] = sha(jar)
    first = tree(OUT / "repeat-0")
    second = tree(OUT / "repeat-1")
    record["raw_equal"] = first == second
    record["raw_files_per_session"] = len(first)
    record["stable"] = (record["input_before"] == record["input_after"]
                        and record["source_before"] == record["source_after"] == record["source_copies"]
                        and record["artifact_sha256"] == record["artifact_after_sha256"])
    observed = []
    for i, row in enumerate(rows):
        folder = OUT / "repeat-0" / f"{i:03d}-{row['id']}"
        expected_names = {"result.status.bin"} | {f"{channel}.bin" for channel in CHANNELS} | {
            f"{channel}.code-units.bin" for channel in CHANNELS}
        actual_names = {p.name for p in folder.iterdir() if p.is_file()}
        assert actual_names == expected_names
        assert (folder / "mode.bin").read_bytes() == b"string"
        assert (folder / "expression.bin").read_bytes() == row["expression"].encode()
        status = (folder / "result.status.bin").read_text().strip()
        stderr = (folder / "result.stderr.bin").read_text()
        observed.append({"index": i, "id": row["id"], "group": row["group"],
                         "expression": row["expression"], "status": status,
                         "stdout_sha256": sha(folder / "result.stdout.bin"),
                         "stderr_sha256": sha(folder / "result.stderr.bin"),
                         "stdout": (folder / "result.stdout.bin").read_text(),
                         "first_error_line": stderr.splitlines()[1] if len(stderr.splitlines()) > 1 else "",
                         "error_class": (folder / "result.error-class.bin").read_text()})
    record["statuses"] = dict(Counter(o["status"] for o in observed))
    record["complete"] = record["raw_equal"] and record["stable"] and len(record["sessions"]) == 2
    save(OUT / "provenance.json", record)
    save(OUT / "audit.json", {"schema": 1, "rows": len(rows), "statuses": record["statuses"],
        "observations": observed, "candidate_compatibility_passes_claimed": 0,
        "limitations": ["Exploration only; authored negative cases and Java producer errors remain raw evidence.",
                        "Public string calls do not establish internal Java reference identity.",
                        "No Rust comparison or original full-program replay was performed here."]})
    if not record["complete"]:
        raise RuntimeError("unstable/incomplete capture; raw preserved")
    print(json.dumps(record["statuses"], sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
