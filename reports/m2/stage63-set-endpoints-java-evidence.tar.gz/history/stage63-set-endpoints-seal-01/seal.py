"""Create and fully read back a single canonical Stage63 Set endpoint Java archive."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
CAPTURE = ROOT / "target/m2/stage63-set-endpoints-oracle-01"
FIXTURE = ROOT / "tests/fixtures/m2-set-endpoints"
PREFIX = "capture-01"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    archive_path = HERE / "oracle-evidence.tar.gz"
    if archive_path.exists() or (FIXTURE / "oracle-evidence.tar.gz").exists():
        raise ValueError("fresh seal output required; preserve earlier bytes")
    source_files = sorted(p for p in CAPTURE.rglob("*") if p.is_file())
    assert len(source_files) == 2990
    assert json.loads((CAPTURE / "provenance.json").read_bytes())["complete"] is True
    manifest = {}
    with archive_path.open("wb") as output:
        with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w") as archive:
                for path in source_files:
                    name = PREFIX + "/" + path.relative_to(CAPTURE).as_posix()
                    raw = path.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    import io
                    archive.addfile(info, io.BytesIO(raw))
                    manifest[name] = (len(raw), sha(raw))
    observed = {}
    fileset = hashlib.sha256()
    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive:
            assert member.isfile() and member.name in manifest and member.name not in observed
            raw = archive.extractfile(member).read()
            assert (len(raw), sha(raw)) == manifest[member.name]
            observed[member.name] = raw
            fileset.update(member.name.encode() + b"\0" + sha(raw).encode() + b"\n")
    assert len(observed) == len(manifest) == 2990
    for name in ("cases.json", "queries.tsv", "module.pkl"):
        assert observed[PREFIX + "/" + name] == (FIXTURE / name).read_bytes()
    identity = {"schema": 1, "archive_sha256": sha(archive_path.read_bytes()),
                "fileset_sha256": fileset.hexdigest(), "members": len(observed),
                "captures": {PREFIX: "stage63-set-endpoints-oracle-01"},
                "oracle_input_sha256": {name: sha(observed[PREFIX + "/" + name])
                    for name in ("CollectionConversionsOracle.java", "run.py", "module.pkl",
                                 "queries.tsv", "cases.json")}}
    shutil.copyfile(archive_path, FIXTURE / "oracle-evidence.tar.gz")
    save(FIXTURE / "archive-identity.json", identity)
    root_files = {p.name: sha(p.read_bytes()) for p in FIXTURE.iterdir() if p.is_file()
                  and p.name != "manifest.json"}
    save(FIXTURE / "manifest.json", {"schema": 1, "baseline": "Pkl 0.32.0", "files": root_files})
    save(HERE / "seal-report.json", {"schema": 1, "archive": str(archive_path),
                                    "fixture": str(FIXTURE), **identity,
                                    "readback_exact": True})
    print(json.dumps(identity, sort_keys=True))


if __name__ == "__main__":
    main()
