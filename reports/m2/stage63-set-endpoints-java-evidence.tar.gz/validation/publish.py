"""Publish and read back Stage63 Set endpoint Java A2 evidence without altering captures."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
REPORTS = ROOT / "reports/m2"
PUB = ROOT / "target/m2/stage63-set-endpoints-java-publication-01"
FIXTURE = ROOT / "tests/fixtures/m2-set-endpoints"
EXPECTED_HEAD = "0fb9df8460f81d18a1ce42771a6ee70d7fa9f6d4"
CAPTURES = (
    ("stage63-set-endpoints-exploration-01", "capture-01", 58, 39, 19,
     "First 58-row exploration; source closure omitted error messages, parser, function and Duration paths."),
    ("stage63-set-endpoints-exploration-02", "capture-01", 70, 47, 23,
     "Expanded 70-row exploration with seven added pinned source paths and endpoint controls."),
    ("stage63-set-endpoints-oracle-01", "", 70, 47, 23,
     "First canonical URI capture; archived run.py came from the collection addition producer, so source provenance is superseded."),
    ("stage63-set-endpoints-oracle-02", "", 70, 47, 23,
     "Final canonical capture with archived run.py byte-equal to the Set endpoint producer."),
)
DIRS = [
    "stage63-set-endpoints-exploration-01",
    "stage63-set-endpoints-exploration-02",
    "stage63-set-endpoints-oracle-01",
    "stage63-set-endpoints-oracle-02",
    "stage63-set-endpoints-canonical-prep-01",
    "stage63-set-endpoints-provisional-seal-01",
    "stage63-set-endpoints-seal-01",
    "stage63-set-endpoints-seal-02",
    "stage63-set-endpoints-test-attempt-01",
]



def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def head():
    return subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                          capture_output=True, check=True).stdout.decode().strip()


def paths_under(root, prefix):
    need(root.is_dir() and not root.is_symlink(), "publication input directory differs")
    result = {}
    for path in root.rglob("*"):
        need(not path.is_symlink(), "publication input symlink")
        if "__pycache__" in path.parts:
            continue
        if path.is_file():
            result[prefix + path.relative_to(root).as_posix()] = path
        else:
            need(path.is_dir(), "publication input nonregular path")
    return result


def check_capture(root, rows_count, successes, errors):
    provenance = json.loads((root / "provenance.json").read_bytes())
    audit = json.loads((root / "audit.json").read_bytes())
    cases = json.loads((root / "cases.json").read_bytes())
    rows = cases["rows"]
    need(len(rows) == rows_count and audit["rows"] == rows_count,
         "historical row count differs")
    need(audit["statuses"] == {"success": successes, "error": errors}
         and provenance["complete"] is True and provenance["stable"] is True
         and provenance["raw_equal"] is True,
         "historical status or completion differs")
    for name, digest in provenance["input_before"].items():
        need(identity(root / name)["sha256"] == digest == provenance["input_after"][name],
             "historical input differs")
    for name, digest in provenance["source_before"].items():
        need(identity(root / "sources" / name)["sha256"] == digest == provenance["source_after"][name],
             "historical copied source differs")
    sessions = provenance["sessions"]
    need(len(sessions) == 2 and [s["repeat"] for s in sessions] == [0, 1]
         and len({s["pid"] for s in sessions}) == 2
         and sessions[0]["finished_epoch"] <= sessions[1]["started_epoch"],
         "historical two fresh ordered JVMs differ")
    raw_sets = []
    for session in sessions:
        repeat = session["repeat"]
        folder = root / f"repeat-{repeat}"
        need(session["exit_code"] == 0 and session["query_directories"] == rows_count,
             "historical session incomplete")
        need(identity(folder / "process.stdout.bin")["sha256"] == session["stdout_sha256"]
             and identity(folder / "process.stderr.bin")["sha256"] == session["stderr_sha256"],
             "historical process hash differs")
        need((folder / "process.stderr.bin").read_bytes() == b"", "historical process stderr differs")
        protocol = [f"session-open mode=string rows={rows_count}"]
        counts = Counter()
        for index, row in enumerate(rows):
            folder_row = folder / f"{index:03d}-{row['id']}"
            need(folder_row.is_dir() and row["mode"] == "string"
                 and (folder_row / "expression.bin").read_text() == row["expression"],
                 "historical expression/order differs")
            status = (folder_row / "result.status.bin").read_text().strip()
            need(status in ("success", "error"), "historical status type differs")
            counts[status] += 1
            call = f"string-{index}-{row['id']}"
            protocol.extend((f"call-enter={call}", f"call-exit={call} status={status}"))
        need(dict(counts) == audit["statuses"], "historical row statuses differ")
        protocol.append(f"session-closed mode=string rows={rows_count} public-calls={rows_count} "
                        f"success={successes} errors={errors}")
        need((folder / "process.stdout.bin").read_bytes() == ("\n".join(protocol) + "\n").encode(),
             "historical whole process transcript differs")
        raw = {p.relative_to(folder).as_posix(): identity(p)["sha256"]
               for p in folder.rglob("*") if p.is_file()}
        need(len(raw) == rows_count * 21 + 2, "historical 21-channel file count differs")
        raw_sets.append(raw)
    need(raw_sets[0] == raw_sets[1], "historical raw repetition differs")
    return {"rows": rows_count, "statuses_per_session": audit["statuses"],
            "raw_files_per_session": len(raw_sets[0]), "pids": [s["pid"] for s in sessions],
            "source_count": len(provenance["source_before"]),
            "module_uri": cases["module_uri"],
            "artifact_sha256": provenance["artifact_sha256"],
            "source_stable": True, "raw_repetitions_equal": True}


def publish_archive(files):
    archive_path = REPORTS / "stage63-set-endpoints-java-evidence.tar.gz"
    need(not archive_path.exists(), "fresh Java A2 evidence archive required")
    entries = {name: path.read_bytes() for name, path in files.items()}
    before = {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in entries.items()}
    manifest = {"schema": 1, "scope": "Stage63 Set endpoint Java A2 canonical fixture, validation, and preserved history",
                "members": dict(sorted(before.items()))}
    entries["archive-manifest.json"] = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
    with archive_path.open("wb") as output:
        with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, raw in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(raw))
    after = {name: identity(path) for name, path in files.items()}
    need(before == after, "publication source changed during archive")
    observed = {}
    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive:
            need(member.isfile() and not member.name.startswith("/")
                 and ".." not in Path(member.name).parts and member.name not in observed,
                 "unsafe/duplicate archive member")
            raw = archive.extractfile(member).read()
            need(len(raw) == member.size, "archive member size differs")
            observed[member.name] = raw
    need(observed == entries and json.loads(observed["archive-manifest.json"]) == manifest,
         "full publication member readback differs")
    return {"path": archive_path.relative_to(ROOT).as_posix(),
            "identity": identity(archive_path), "members": len(observed),
            "member_hash_readback": True, "source_before_after_equal": before == after,
            "embedded_manifest_sha256": sha(observed["archive-manifest.json"])}


def main():
    need(head() == EXPECTED_HEAD, "Stage63 Set endpoint Java A2 baseline HEAD differs")
    validation = json.loads((HERE / "validation.json").read_bytes())
    need(validation["complete"] is True and validation["source_stable"] is True
         and validation["snapshot_matches"] is True and validation["baseline_head"] == EXPECTED_HEAD
         and len(validation["checks"]) == 8
         and all(check["exit_code"] == 0 for check in validation["checks"]),
         "recorded Java A2 validation incomplete")
    for name, expected in validation["source_before"].items():
        need(identity(HERE / "sources" / name)["sha256"] == expected == validation["source_after"][name],
             "validation source snapshot differs")
    import sys
    sys.path.insert(0, str(ROOT / "tools"))
    from set_endpoints_fixtures import verify
    verdict = verify(FIXTURE)
    need(verdict["rows"] == 70 and verdict["statuses"] == {"success": 47, "error": 23},
         "canonical fixture authority differs")
    historical = {}
    for dirname, child, rows, success, error, reason in CAPTURES:
        source = ROOT / "target/m2" / dirname
        root = source / child if child else source
        historical[dirname] = {**check_capture(root, rows, success, error),
                               "role": "canonical" if dirname.endswith("oracle-02") else "historical",
                               "reason": reason}
    need((ROOT / "target/m2/stage63-set-endpoints-oracle-01/run.py").read_bytes() !=
         (ROOT / "tools/set_endpoints_oracle.py").read_bytes(),
         "superseded producer closure reason differs")
    need((ROOT / "target/m2/stage63-set-endpoints-oracle-02/run.py").read_bytes() ==
         (ROOT / "tools/set_endpoints_oracle.py").read_bytes(),
         "canonical producer closure differs")
    fixture_id = json.loads((FIXTURE / "archive-identity.json").read_bytes())
    need(fixture_id["archive_sha256"] == identity(FIXTURE / "oracle-evidence.tar.gz")["sha256"]
         and fixture_id["members"] == 2990 and fixture_id["captures"] == {
             "capture-02": "stage63-set-endpoints-oracle-02"},
         "canonical archive identity differs")
    files = paths_under(HERE, "validation/")
    files.update(paths_under(FIXTURE, "fixture/"))
    for dirname in DIRS:
        files.update(paths_under(ROOT / "target/m2" / dirname, f"history/{dirname}/"))
    archive = publish_archive(files)
    need(head() == EXPECTED_HEAD, "baseline HEAD moved during Java publication")
    checkpoint = {"schema": 1, "kind": "stage63-set-endpoints-java-authority-checkpoint",
       "baseline": "Pkl 0.32.0", "baseline_head": EXPECTED_HEAD,
       "candidate_compatibility_passes_claimed": 0,
       "canonical": {"path": FIXTURE.relative_to(ROOT).as_posix(),
                     "module_uri": "file:///stage63/set-endpoints.pkl", "boundary": "string",
                     "rows": 70, "statuses_per_session": {"success": 47, "error": 23},
                     "archive_prefix": "capture-02", "archive": identity(FIXTURE / "oracle-evidence.tar.gz"),
                     "archive_members": fixture_id["members"],
                     "fileset_sha256": fixture_id["fileset_sha256"]},
       "java_runtime": {"reference_revision": "e51fb2f91774265666f94980ec630db794a4db2d",
                        "artifact_sha256": historical["stage63-set-endpoints-oracle-02"]["artifact_sha256"],
                        "jdk": json.loads((ROOT / "target/m2/stage63-set-endpoints-oracle-02/provenance.json").read_bytes())["jdk"]},
       "validation": {"directory": HERE.relative_to(ROOT).as_posix(),
                      "record": identity(HERE / "validation.json"),
                      "source_count": len(validation["source_before"]),
                      "source_stable": True, "checks": validation["checks"],
                      "manifest_freshness_pass_claimed": False,
                      "deferred_final_integration": validation["deferred_final_integration"]},
       "history": {"captures": historical},
       "publication": archive,
       "limits": ["Public Java string fixture makes no Vm reference identity claim.",
                  "No Rust candidate, typed export, Node, browser, full M2 or performance pass is claimed.",
                  "The throwing Set element errors occur during construction before endpoint evaluation.",
                  "M2 manifest freshness waits for concurrent Rust source freeze and regeneration."]}
    PUB.mkdir(parents=True, exist_ok=False)
    (PUB / "draft.json").write_text(json.dumps(checkpoint, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"draft": identity(PUB / "draft.json"), "publication": archive}, sort_keys=True))


if __name__ == "__main__":
    main()
