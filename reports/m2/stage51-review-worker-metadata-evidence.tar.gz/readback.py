import hashlib,json,stat,sys,tarfile
from pathlib import Path
archive,selection_path,output=map(Path,sys.argv[1:]);selection=json.loads(selection_path.read_text());base=Path(selection['base']);expected={r['path']:r for r in selection['files']};observed=[]
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();names=[m.name for m in members]
 assert len(names)==len(set(names)),'duplicate path'
 assert set(names)==set(expected)|{'EVIDENCE.json'},'entire pathset differs from original selection'
 for m in members:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts,'unsafe member'
  assert m.mode==0o644 and m.mtime==0,'archive header differs from evidence tool contract'
  data=tar.extractfile(m).read()
  if m.name=='EVIDENCE.json':
   inv=json.loads(data);assert inv['excluded_patterns']==[];assert {r['path'] for r in inv['files']}==set(expected);continue
  row=expected[m.name];src=base/m.name;s=src.lstat();original=src.read_bytes()
  assert stat.S_ISREG(s.st_mode) and stat.S_IMODE(s.st_mode)==row['mode'],m.name+' original mode/type changed'
  assert data==original,m.name+' raw byte difference'
  digest=hashlib.sha256(data).hexdigest();assert len(data)==row['bytes'] and digest==row['sha256'],m.name+' original selection hash/size mismatch'
  observed.append({'path':m.name,'bytes':len(data),'sha256':digest,'originalMode':row['mode'],'archiveMode':m.mode})
result={'scope':'Independent full-member byte/path readback directly against original selected files; does not infer compatibility.','archive':str(archive),'memberFilesIncludingInventory':len(members),'originalSelectedFileCount':len(expected),'exactPathset':True,'allSelectedMemberBytesEqualOriginal':True,'allOriginalModesEqualSelection':True,'headersMode':0o644,'headersMtime':0,'files':observed}
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
