import datetime, hashlib, json, os, platform, shutil, stat, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
BASE=ROOT/'target/m2'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def save(name,data): (OUT/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
NAMES=json.loads((OUT/'requested-roots.json').read_text())
DIRECT='stage51-candidate04-evidence-prep-01'
report={'schema':1,'scope':'Provenance packaging only; no compatibility, Java, Rust, browser, Git or production actions.','startedUtc':now(),'complete':False,'pid':os.getpid(),'ppid':os.getppid(),'argv':sys.argv,'cwd':str(Path.cwd()),'host':platform.uname()._asdict(),'python':{'executable':sys.executable,'version':sys.version},'commands':[]}
save('report.json',report)
def run(label,argv):
 rec={'label':label,'argv':list(map(str,argv)),'cwd':str(ROOT),'startedUtc':now()}
 with (OUT/(label+'.stdout.bin')).open('wb') as stdout,(OUT/(label+'.stderr.bin')).open('wb') as stderr:
  p=subprocess.Popen(rec['argv'],cwd=ROOT,stdout=stdout,stderr=stderr);rec['pid']=p.pid;save('active.json',rec);code=p.wait()
 rec.update(exitCode=code,finishedUtc=now())
 for channel in ['stdout','stderr']:
  data=(OUT/(label+'.'+channel+'.bin')).read_bytes();rec[channel+'Sha256']=sha(data);rec[channel+'Bytes']=len(data)
 report['commands'].append(rec);save('report.json',report)
 if code: raise RuntimeError(f'{label} exit {code}')
 return rec

def snapshot():
 files=[];dirs=[];special=[]
 for name in NAMES:
  root=BASE/name
  if not root.is_dir() or root.is_symlink(): raise RuntimeError(f'Missing/unsafe requested root {name}')
  paths=sorted(root.iterdir() if name==DIRECT else root.rglob('*'))
  dirs.append({'path':name,'mode':stat.S_IMODE(root.stat().st_mode)})
  for p in paths:
   rel=p.relative_to(BASE).as_posix();s=p.lstat()
   if stat.S_ISREG(s.st_mode):
    data=p.read_bytes();files.append({'path':rel,'bytes':len(data),'sha256':sha(data),'mode':stat.S_IMODE(s.st_mode)})
   elif stat.S_ISDIR(s.st_mode):
    if name!=DIRECT:dirs.append({'path':rel,'mode':stat.S_IMODE(s.st_mode)})
   else:special.append(rel)
 if special:raise RuntimeError(f'Nonregular evidence paths: {special}')
 return {'schema':1,'base':str(BASE),'selectionRule':'All regular files recursively under the 32 named roots; ONLY direct regular files of stage51-candidate04-evidence-prep-01. No deduplication. No own live output or live archive-audit/Git-index binding selection.','explicitExcludedSubtrees':[DIRECT+'/archives/'],'files':sorted(files,key=lambda x:x['path']),'directories':sorted(dirs,key=lambda x:x['path'])}
try:
 # A stale active.json is not a terminal-success assertion. Inspect process state.
 run('process-inspection',[sys.executable,'-B','-c',"import json,os; from pathlib import Path; d=json.loads(Path('target/m2/stage51-candidate04-evidence-prep-01/active.json').read_text()); pid=d['pid']; alive=True\ntry: os.kill(pid,0)\nexcept ProcessLookupError: alive=False\nprint(json.dumps({'record':d,'pidExistsAtInspection':alive,'qualification':'PID existence alone cannot identify a historical process or establish terminal success.'},indent=2))"])
 before=snapshot();save('selection-before.json',before)
 rootstates=[]
 for name in NAMES:
  p=BASE/name
  fields=[]
  for f in sorted(p.glob('*.json')):
   try:d=json.loads(f.read_text())
   except (ValueError,UnicodeError):continue
   if not isinstance(d,dict):continue
   selected={k:v for k,v in d.items() if k in ['status','complete','completed','passed','exitCode','actualExitCode','actualExit','actualAuditExit','actualReviewerAuditExit','producerActualExit','terminalExit','scope','qualification','failureSourceQualification','fullM2Complete','wholeM2Complete','wholeM2Complete','fullCompatibilityPassed','ordinaryContractPassed','strictSelectedContractPassed','rawApiPassed','fullJavaEventsCountersPassed','architectureContractPassed']}
   if selected:fields.append({'file':f.relative_to(BASE).as_posix(),'recordedFields':selected})
  fs=[r for r in before['files'] if r['path'].startswith(name+'/')]
  rootstates.append({'root':name,'exists':True,'closureAuthority':'Parent explicitly designated this root closed/immutable for packaging; original recorded statuses below retain their narrower historical meanings.','files':len(fs),'bytes':sum(r['bytes'] for r in fs),'recordedStatusEvidence':fields,'inferredCompatibilityPass':False})
 save('root-status-inspection.json',rootstates)
 qualifications=[
 'Packaging establishes selected byte/path integrity only; no new compatibility acquisition or source-to-current-engine equality claim.',
 'All original historical files selected without dedup exclusions; previous source snapshots retain their own versions and are not compared to the current engine.',
 'stage51-collection-c-review-03 preserves its original example source-copy mismatch; stage51-candidate03-three-target-audit-01 preserves actual auditor failure and missing independently redirected original raw bytes.',
 'Duration WIP reviews are immutable historical source observations, not final source or compatibility approvals.',
 'stage51-receiver-failure-01/-02 and setup/development receipts lack complete byte snapshots for every transient test revision; frozen/final guarded records are distinct.',
 'candidate03 ordinary failures remain historical failures. candidate04 recorded ordinary 2000/2000 matches per native/Node/Chromium do not erase 12 post-close raw failures per target, M1 two regex failures, full-event/counter gaps, or whole-M2/performance/platform gaps.',
 'stage51-candidate04-evidence-prep-01 direct regular files only; archives/ is excluded exactly because eight runtime archives are packaged separately by root. active.json is historical last-command metadata, not terminal proof; report.json retains per-command terminal records.',
 'tools/evidence.py intentionally writes regular archive headers mode 0644, mtime 0. Original file/directory modes are preserved separately in before/after selection records, not as original archive modes.',
 'This package does not invent terminal process evidence for old records with file presence alone. Closed selection authority is the explicit parent instruction; original raw status/closure/report files remain authoritative within their recorded scope.'
 ]
 save('qualifications.json',qualifications)
 (OUT/'archives').mkdir();payload=OUT/'payload';payload.mkdir()
 for row in before['files']:
  src=BASE/row['path'];dest=payload/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
  if dest.read_bytes()!=src.read_bytes():raise RuntimeError('Copy mismatch '+row['path'])
 shutil.copy2(ROOT/'tools/evidence.py',OUT/'evidence.py')
 report['runnerSha256']=sha(Path(__file__).read_bytes());report['evidenceToolSha256']=sha((OUT/'evidence.py').read_bytes());report['originalSelectedFiles']=len(before['files']);report['originalSelectedBytes']=sum(r['bytes'] for r in before['files']);report['rootCount']=len(NAMES)
 archive=OUT/'archives/stage51-review-metadata.tar.gz'
 run('metadata-create',[sys.executable,'-B',OUT/'evidence.py','create',payload,archive])
 if archive.stat().st_size>100_000_000:raise RuntimeError('Compressed archive exceeds 100MB; logical split required')
 run('metadata-verify',[sys.executable,'-B',OUT/'evidence.py','verify',archive])
 run('metadata-independent-readback',[sys.executable,'-B',OUT/'readback.py',archive,OUT/'selection-before.json',OUT/'readback.json'])
 after=snapshot();save('selection-after.json',after)
 if before!=after: raise RuntimeError('Original selection byte/mode/pathset changed')
 report.update(complete=True,finishedUtc=now(),originalSelectionUnchanged=True,entireMemberReadbackPassed=True,archive={'path':str(archive),'futureReportPath':'reports/m2/stage51-review-metadata-evidence.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'memberFiles':len(before['files'])+1},qualificationsFile='qualifications.json',rootStatusFile='root-status-inspection.json',beforeSha256=sha((OUT/'selection-before.json').read_bytes()),afterSha256=sha((OUT/'selection-after.json').read_bytes()),futureReportMetadata=['reports/m2/stage51-review-metadata-summary.json'])
 save('report.json',report);save('terminal.json',{'pid':os.getpid(),'exitCode':0,'finishedUtc':now(),'reportSha256':sha((OUT/'report.json').read_bytes()),'scope':'Terminal receipt written by runner immediately before successful return; external tool exit is separate.'})
 print(json.dumps({k:report[k] for k in ['complete','originalSelectedFiles','originalSelectedBytes','archive','originalSelectionUnchanged','entireMemberReadbackPassed']},indent=2))
except BaseException as e:
 report.update(complete=False,failure=repr(e),finishedUtc=now());save('report.json',report);raise
