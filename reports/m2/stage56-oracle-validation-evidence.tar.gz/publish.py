"""Publish recorded Java-only validation evidence without rerunning any guest/check."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import platform
import sys
import tarfile

ROOT = Path.cwd().resolve()
OUT = ROOT / 'target/m2/stage56-oracle-checkpoint-publication-01'
ARCHIVE = ROOT / 'reports/m2/stage56-oracle-validation-evidence.tar.gz'
CHECKPOINT = ROOT / 'reports/m2/stage56-oracle-checkpoint.json'
CANONICAL = ROOT / 'tests/fixtures/m2-class-values/oracle-evidence.tar.gz'


def record(data):
    return dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


def identity(path):
    return dict(path=path.relative_to(ROOT).as_posix(), **record(path.read_bytes()))


def load(path):
    return json.loads(path.read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode()


assert not ARCHIVE.exists() and not CHECKPOINT.exists() and not (OUT / 'manifest.json').exists()
final = load(ROOT / 'target/m2/stage56-class-publication-01/FINAL.json')
for name, expected in final['owned_files'].items():
    assert identity(ROOT / name) == expected
assert len(final['owned_files']) == 47
validation_root = ROOT / 'target/m2/stage56-class-verification-01'
for name, expected in final['raw_validation_files'].items():
    assert identity(validation_root / name) == expected
assert [row['exit_code'] for row in final['validation']] == [0, 0]
assert final['inventory_check']['exit_code'] == 0
assert b'Ran 15 tests in 97.244s\n\nOK\n' in (validation_root / 'tests.stderr.bin').read_bytes()
canonical_before = identity(CANONICAL)
assert canonical_before['sha256'] == 'a39060fbf155947212aaae5b2e950dc2cd04381a78cb2860a7f8b1675b3657fc'
member_records = load(ROOT / 'target/m2/stage56-class-publication-01/members.json')
assert len(member_records) == 25945

sources = {}
for folder in ['stage56-class-preparation-01', 'stage56-class-publication-01', 'stage56-class-verification-01']:
    directory = ROOT / 'target/m2' / folder
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            sources['evidence/' + path.relative_to(ROOT).as_posix()] = path
locations = {}
for name, expected in final['owned_files'].items():
    if name == canonical_before['path']:
        locations[name] = dict(kind='canonical-archive')
        continue
    match = next((prefix + '/sources/' + name for prefix in ['main', 'exports']
                  if member_records.get(prefix + '/sources/' + name) == {key: expected[key] for key in ['sha256', 'bytes']}), None)
    if match:
        locations[name] = dict(kind='canonical-member', member=match)
    else:
        member = 'verification-source-supplements/' + name
        sources[member] = ROOT / name
        locations[name] = dict(kind='publication-member', member=member)
for name in ['publish.py', 'verify.py', 'README.md']:
    sources[name] = OUT / name
payloads = {name: record(path.read_bytes()) for name, path in sorted(sources.items())}
manifest = dict(schema=1, scope='Recorded local Stage56 Java-only validation/publication, no test or guest reruns, no candidate results.',
    files=payloads, canonical_authority=canonical_before,
    canonical_member_manifest='evidence/target/m2/stage56-class-publication-01/members.json',
    owned_files=final['owned_files'], owned_file_locations=locations,
    actual_commit_binding='Pending authorized parent Java-A commit; no staging or commit performed.',
    original_outputs_modified_or_deleted=False, compatibility_passes_claimed=0)
(OUT / 'manifest.json').write_bytes(encoded(manifest))
ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
with ARCHIVE.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as stream:
            for name in ['manifest.json', *payloads]:
                data = (OUT / 'manifest.json').read_bytes() if name == 'manifest.json' else sources[name].read_bytes()
                if name != 'manifest.json':
                    assert record(data) == payloads[name]
                info = tarfile.TarInfo(name); info.mode = 0o644; info.size = len(data)
                stream.addfile(info, io.BytesIO(data))
for name, path in sources.items():
    assert record(path.read_bytes()) == payloads[name]
for name, expected in final['owned_files'].items():
    assert identity(ROOT / name) == expected
assert identity(CANONICAL) == canonical_before
spec = importlib.util.spec_from_file_location('stage56_java_publication_verify', OUT / 'verify.py')
verifier = importlib.util.module_from_spec(spec); spec.loader.exec_module(verifier)
publication = verifier.verify(ARCHIVE, CANONICAL)
publication.update(all_original_outputs_unchanged=True, canonical_raw_payloads_not_duplicated=True)
(OUT / 'report.json').write_bytes(encoded(publication))

main_report = load(ROOT / 'target/m2/stage56-class-oracle-04/report.json')
export_report = load(ROOT / 'target/m2/stage56-class-export-oracle-01/report.json')
metadata = main_report['oracle']
checkpoint = dict(schema=1, stage=56, kind='Java-only Class reference authority checkpoint',
    recorded_at=datetime.now(timezone.utc).isoformat(),
    scope='Actual pinned Java Class queries, module-key/logger observations, public exported-Class identity, preserved acquisition histories and recorded offline verifier/tooling checks. No Rust/candidate comparison or full API compatibility claim.',
    implementation_ancestor='f82060d395d6c1cb16aef2b94a48a2d8f28440b1',
    docs_only_ancestor_reported_by_parent='e0b52f9323722483e29654f7723c55ede152afdd',
    actual_Java_A_commit=None, actual_commit_binding='Pending actual authorized parent Java-A commit; no Git staging/commit/read performed by this publication.',
    local_provenance=dict(execution='Local macOS, not hosted CI', workspace=str(ROOT), Java_host=metadata['platform'],
        publication_Python=dict(executable=sys.executable, version=sys.version, sha256=record(Path(sys.executable).resolve().read_bytes())['sha256'], host=platform.platform()),
        validation_recording_limit='Original offline validation logs retain exact commands, exit codes and elapsed times; they did not independently snapshot the enclosing Python process full inherited environment at launch. Publication-time Python identity is labelled separately.'),
    reference_pins=dict(baseline='Pkl 0.32.0', pkl_revision=metadata['source']['revision'],
        pantry_revision='904a68184e54da378b0a0e8a911a3fab3956f693', oracle_artifact_sha256=metadata['artifact_sha256'],
        artifact_url=metadata['artifact_url'], exact_Java_command_prefix=metadata['command'], exact_Java_environment=metadata['environment'],
        JDK=metadata['jdk'], references_modified=False),
    fixture=dict(path='tests/fixtures/m2-class-values', archive=canonical_before,
        manifest=identity(ROOT / 'tests/fixtures/m2-class-values/manifest.json'), cases=identity(ROOT / 'tests/fixtures/m2-class-values/cases.json'),
        export_cases=identity(ROOT / 'tests/fixtures/m2-class-values/export-cases.json'),
        exact_canonical_member_manifest=identity(ROOT / 'target/m2/stage56-class-publication-01/members.json'), canonical_raw_files=25945),
    observations=final['verification'], semantic_corrections=final['semantic_corrections'], producer_boundaries=final['producer_boundaries'],
    main_acquisition=dict(report=identity(ROOT / 'target/m2/stage56-class-oracle-04/report.json'), sessions=44, JVM_processes=88,
        outer_evaluation_calls=554, reentrant_evaluation_calls=4, total_evaluation_calls=558,
        call_status_counts=dict(success=462, error=86, **{'oracle-error':6, 'api-exception':4}),
        logger_callbacks=10, warning_callbacks=0, repeated_raw_equal=44, Java_SPI_provider_callbacks=dict(create=578, resolve=10),
        candidate_common_query_comparison='Not performed in this Java-only checkpoint; parent candidate comparison is separate.',
        candidate_provider_API_parity='unexecuted/required; all actual Java provider bytes retained'),
    public_export_supplement=dict(report=identity(ROOT / 'target/m2/stage56-class-export-oracle-01/report.json'),
        sessions=1, JVM_processes=2, public_evaluation_calls=14, call_status_counts=dict(success=12, **{'api-exception':2}),
        identity_comparisons=8, evaluation_call_count_excludes_Object_reference_equals_comparisons_and_close_calls=True,
        actual_observations=final['verification']['public_export_supplement']['observations'],
        candidate_public_export_API_parity='unexecuted/required; Java value and exception classes remain producer provenance'),
    preserved_histories=dict(cohorts=['preserved-history-01', 'preserved-history-02', 'preserved-history-03'],
        sessions=[42,43,44], JVM_processes=[84,86,88], all_original_outputs_preserved=True,
        classification='Complete earlier acquisitions including invalid Null(42), local import/query scope errors and source refinements; not additional independent feature coverage or candidate passes.',
        known_failed_acquisition_or_harness_processes='None among these completed cohorts; all actual guest errors/oracle-errors/API exceptions remain recorded as observations, never relabelled as successful checks.'),
    validation=dict(recorded_commands=final['validation'], recorded_inventory_check=final['inventory_check'],
        actual_verifier_tests=15, verifier_test_elapsed_seconds=97.244, all_recorded_checks_exit_zero=True,
        raw_log_identities=final['raw_validation_files'], publication_re_runs_of_guests_tests_Cargo_or_candidates=0),
    owned_source_and_fixture_identities=final['owned_files'],
    publication=dict(archive=identity(ARCHIVE), verification=publication, publication_report=identity(OUT / 'report.json'),
        canonical_raw_payloads_omitted_by_exact_member_identity=True, all_original_outputs_unchanged=True),
    remaining_scope=['Candidate source-query/logger/protocol comparisons, provider SPI and public Class export API obligations remain separate and unexecuted here.',
        'Real Java oracle-errors and API exceptions remain nonpasses, not compatible-error passes.',
        'Class value, prototype, superclass, virtual getClass and intrinsic runtime class remain distinct; Typed-only converter ancestry cannot be generalized to all values.',
        'JVM-global stdlib/evaluator lifetime, full lifecycle/API behavior, remaining Typed/Dynamic projections, reflection, DataSize, module-relative paths and whole M2 remain open.',
        'Actual parent Java-A source/Git binding is pending; no full language/API, release-platform or speed/memory target completion claim.'],
    Rust_compatibility_passes_claimed=0, candidate_execution_performed=False, whole_M2_complete=False,
    public_API_complete=False, performance_claimed=False, hosted_CI_claimed=False)
assert metadata['source']['revision'] == 'e51fb2f91774265666f94980ec630db794a4db2d'
assert metadata['artifact_sha256'] == 'c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059'
assert '-Xms64m' in metadata['command'] and '-Xmx512m' in metadata['command']
with CHECKPOINT.open('xb') as stream:
    stream.write(encoded(checkpoint))
print(json.dumps(dict(checkpoint=identity(CHECKPOINT), publication=publication), indent=2))
