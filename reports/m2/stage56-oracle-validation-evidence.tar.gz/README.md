# Stage56 Java-only checkpoint publication

This archive preserves the previously executed Java authority validation logs, exact tested verification tools and the preparation/publication records. It does not rerun Java guests, tests, Cargo or candidates. Original captures and 47 owned fixture/tool/test files remain unchanged.

All 25,945 canonical raw files for the final main matrix, exported-Class supplement and three preserved acquisition histories are already retained in `tests/fixtures/m2-class-values/oracle-evidence.tar.gz`. This publication binds that archive by its exact independent SHA256 and every member identity. It does not duplicate those raw files. Source supplements cover the tested verifier/tests and fixture metadata that were created after acquisition; other owned source identities are bound to exact canonical members.

Run `python3 -B verify.py PUBLICATION.tar.gz --fixture-archive CANONICAL.tar.gz` to re-read both archives without extraction, guest execution or network access. Safe unique regular paths, every member hash/size, canonical coverage and all 47 owned identities are checked.

This is local Java-only evidence. Actual PklBugException and API exceptions remain nonpasses. Candidate provider SPI and public Class export parity remain unexecuted and required. Common query/logger evidence does not establish full API compatibility. The actual parent Java-A commit binding is pending; no Git staging or commit is performed here. No Rust, full M2, hosted CI or performance result is claimed.
