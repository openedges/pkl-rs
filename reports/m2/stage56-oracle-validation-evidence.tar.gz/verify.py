"""Re-read Java-only publication and external canonical raw archive, without extraction."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

CANONICAL = 'a39060fbf155947212aaae5b2e950dc2cd04381a78cb2860a7f8b1675b3657fc'


def record(data):
    return dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


def members(path):
    result = {}
    with tarfile.open(path, 'r:gz') as stream:
        for entry in stream:
            name = PurePosixPath(entry.name)
            assert entry.isfile() and not name.is_absolute() and '..' not in name.parts
            assert entry.name == name.as_posix() and entry.name not in result
            result[entry.name] = stream.extractfile(entry).read()
    return result


def verify(archive, canonical):
    raw = members(archive)
    manifest = json.loads(raw['manifest.json'])
    assert type(manifest['schema']) is int and manifest['schema'] == 1
    assert set(raw) == {'manifest.json', *manifest['files']}
    for name, expected in manifest['files'].items():
        assert record(raw[name]) == expected
        assert type(expected['bytes']) is int
        assert not name.endswith(('.rs', '.wasm', '.node', '.jar'))
    assert manifest['canonical_authority']['sha256'] == CANONICAL
    assert record(canonical.read_bytes()) == {key: manifest['canonical_authority'][key] for key in ['sha256', 'bytes']}
    canonical_raw = members(canonical)
    expected_members = json.loads(raw[manifest['canonical_member_manifest']])
    assert set(canonical_raw) == set(expected_members) and len(expected_members) == 25945
    assert {name.split('/')[0] for name in canonical_raw} == {'main', 'exports', 'preserved-history-01', 'preserved-history-02', 'preserved-history-03'}
    for name, expected in expected_members.items():
        assert record(canonical_raw[name]) == expected
    for name, expected in manifest['owned_files'].items():
        location = manifest['owned_file_locations'][name]
        if location['kind'] == 'canonical-archive':
            actual = record(canonical.read_bytes())
        elif location['kind'] == 'canonical-member':
            actual = record(canonical_raw[location['member']])
        else:
            assert location['kind'] == 'publication-member'
            actual = record(raw[location['member']])
        assert actual == {key: expected[key] for key in ['sha256', 'bytes']}
    assert len(manifest['owned_files']) == 47 and set(manifest['owned_files']) == set(manifest['owned_file_locations'])
    return dict(schema=1, archive=str(archive), archive_sha256=record(archive.read_bytes())['sha256'],
        archive_bytes=archive.stat().st_size, payload_members=len(manifest['files']), archive_members=len(raw),
        manifest_sha256=record(raw['manifest.json'])['sha256'], safe_paths_and_unique_regular_members=True,
        canonical_raw_files_verified_without_duplication=len(canonical_raw), owned_source_identities_verified=47,
        Java_only=True, candidate_execution_claimed=False, compatibility_passes_claimed=0)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--fixture-archive', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(verify(args.archive, args.fixture_archive), indent=2))
