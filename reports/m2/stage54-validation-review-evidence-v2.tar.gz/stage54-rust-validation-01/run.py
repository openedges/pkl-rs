import os,sys,json,hashlib,subprocess,datetime,platform
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage54-rust-validation-01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
before=json.loads((OUT/'sources.json').read_bytes());assert all(sha(ROOT/name)==digest for name,digest in before.items())
env=dict(os.environ,CARGO_INCREMENTAL='0',PYTHONDONTWRITEBYTECODE='1')
report={'scope':'Required Rust workspace checks on recorded code/fixture sources; not full language or API compatibility','host':platform.platform(),'cwd':str(ROOT),'started_utc':utc(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'environment_overrides':{'CARGO_INCREMENTAL':'0','PYTHONDONTWRITEBYTECODE':'1'},'source_count':len(before),'commands':[],'complete':False}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
commands=[('references',['cargo','xtask','verify']),('format',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),('workspace-tests',['cargo','test','--workspace','--locked']),('wasm-runtime',['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked'])]
save()
for name,command in commands:
 print('START',name,flush=True);row={'name':name,'command':command,'started_utc':utc()}
 with (OUT/(name+'.stdout.bin')).open('xb') as stdout,(OUT/(name+'.stderr.bin')).open('xb') as stderr:
  child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;(OUT/'active.json').write_text(json.dumps(row,indent=2)+'\n');row['exit_code']=child.wait()
 row['finished_utc']=utc();row['stdout_sha256']=sha(OUT/(name+'.stdout.bin'));row['stderr_sha256']=sha(OUT/(name+'.stderr.bin'));report['commands'].append(row);save();print('FINISH',name,row['exit_code'],flush=True)
 if row['exit_code']!=0:raise RuntimeError('Required check failed; original record preserved')
report['changed_sources']=[name for name,digest in before.items() if sha(ROOT/name)!=digest];report['finished_utc']=utc();report['complete']=True;save();assert not report['changed_sources'];print('REQUIRED RUST CHECKS COMPLETE',flush=True)
