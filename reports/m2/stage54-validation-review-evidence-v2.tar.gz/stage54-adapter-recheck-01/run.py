import os,sys,json,hashlib,subprocess,datetime
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage54-adapter-recheck-01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
before=json.loads((OUT/'sources.json').read_bytes());assert all(sha(ROOT/name)==digest for name,digest in before.items())
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');rows=[]
for name,command in [('portable-transport-tests',['node','--test','tools/platform/deprecation-session.test.mjs','tools/platform/capture-deprecation.test.mjs']),('inventory-freshness',[sys.executable,'tools/m2_manifest.py','--check'])]:
 with (OUT/(name+'.stdout.bin')).open('xb') as stdout,(OUT/(name+'.stderr.bin')).open('xb') as stderr:result=subprocess.run(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
 rows.append({'name':name,'command':command,'exit_code':result.returncode,'stdout_sha256':sha(OUT/(name+'.stdout.bin')),'stderr_sha256':sha(OUT/(name+'.stderr.bin'))});assert result.returncode==0;print(name,result.returncode,flush=True)
changed=[name for name,digest in before.items() if sha(ROOT/name)!=digest]
(OUT/'report.json').write_text(json.dumps({'commands':rows,'source_count':len(before),'source_changes':changed,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');assert not changed
