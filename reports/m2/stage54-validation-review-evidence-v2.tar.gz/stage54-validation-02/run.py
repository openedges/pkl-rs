import os,sys,json,hashlib,subprocess,datetime,platform
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage54-validation-02'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
before=json.loads((OUT/'sources.json').read_bytes());assert all(sha(ROOT/name)==digest for name,digest in before.items())
env=dict(os.environ,CARGO_INCREMENTAL='0',PYTHONDONTWRITEBYTECODE='1')
report={'scope':'Frozen Stage54 source, native build binding, Python verification and inventory checks; required Rust five-check and M1 platform records are separate','host':platform.platform(),'cwd':str(ROOT),'started_utc':utc(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'runner_sha256':sha(Path(__file__)),'source_count':len(before),'environment_overrides':{'CARGO_INCREMENTAL':'0','PYTHONDONTWRITEBYTECODE':'1'},'commands':[],'complete':False}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
commands=[('native-build',['cargo','build','-p','pkl-runtime','--example','deprecation_fixture_probe','--release','--locked']),('m2-freshness',[sys.executable,'tools/m2_manifest.py','--check']),('source-inventory',[sys.executable,'tools/inventory.py','--check']),('module-registry',[sys.executable,'tools/m2_module_eval.py','--check']),('fixture',[sys.executable,'tools/deprecation_fixtures.py']),('m2-tooling',[sys.executable,'-m','unittest','discover','-s','tools/tests','-p','test_m2_*.py']),('deprecation-tooling',[sys.executable,'-m','unittest','discover','-s','tools/tests','-p','test_deprecation_*.py']),('portable-transport-tests',['node','--test','tools/platform/deprecation-session.test.mjs','tools/platform/capture-deprecation.test.mjs'])]
save()
for name,command in commands:
 print('START',name,flush=True);row={'name':name,'command':command,'started_utc':utc()}
 with (OUT/(name+'.stdout.bin')).open('xb') as stdout,(OUT/(name+'.stderr.bin')).open('xb') as stderr:
  child=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr);row['pid']=child.pid;(OUT/'active.json').write_text(json.dumps(row,indent=2)+'\n');row['exit_code']=child.wait()
 row['finished_utc']=utc();row['stdout_sha256']=sha(OUT/(name+'.stdout.bin'));row['stderr_sha256']=sha(OUT/(name+'.stderr.bin'));report['commands'].append(row)
 if name=='native-build' and row['exit_code']==0:
  artifact=ROOT/'target/release/examples/deprecation_fixture_probe';report['native_artifact']={'path':str(artifact),'sha256':sha(artifact),'bytes':artifact.stat().st_size}
 save();print('FINISH',name,row['exit_code'],flush=True)
 if row['exit_code']!=0:raise RuntimeError('Required tooling check failed; raw attempt retained')
report['changed_sources']=[name for name,digest in before.items() if sha(ROOT/name)!=digest];report['finished_utc']=utc();report['complete']=True;save();assert not report['changed_sources'];assert sha(Path(__file__))==report['runner_sha256'];print('TOOLING AND BUILD VALIDATION COMPLETE',flush=True)
