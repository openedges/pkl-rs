from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime, hashlib, json, os, subprocess, sys
O = Path(__file__).resolve().parent
R = O.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
paths = ['tools/modulekey_extended_fixtures.py', 'tools/tests/test_modulekey_extended_fixtures.py',
    'tools/platform/compare-modulekey-extended.mjs', 'tools/platform/compare-modulekey-extended.test.mjs',
    'tools/platform/compare-modulekey.mjs', 'tools/platform/modulekey-session.mjs',
    'tools/platform/module-policy-session.mjs', 'tools/platform/resource-session.mjs',
    'tests/fixtures/m2-modulekey-extended/manifest.json']
before = {p: sha(R / p) for p in paths}; write(O / 'source-before.json', before)
commands = [
    ('python12', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_modulekey_extended_fixtures.py', '-v']),
    ('fixture-cli', [sys.executable, '-I', '-B', 'tools/modulekey_extended_fixtures.py', '--fixtures', 'tests/fixtures/m2-modulekey-extended']),
    ('driver-syntax', ['node', '--check', 'tools/platform/compare-modulekey-extended.mjs']),
    ('driver-test-syntax', ['node', '--check', 'tools/platform/compare-modulekey-extended.test.mjs']),
    ('driver10', ['node', '--test', 'tools/platform/compare-modulekey-extended.test.mjs']),
    *[(name, [sys.executable, '-B', 'tools/' + name + '.py', '--check'])
      for name in ['inventory', 'discover', 'smoke_manifest', 'regression_manifest']],
]
def capture(item):
    label, command = item; out = O / label; out.mkdir()
    row = {'label': label, 'command': command, 'cwd': str(R), 'parentPid': os.getpid(),
        'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (out / 'stdout.bin').open('wb') as stdout, (out / 'stderr.bin').open('wb') as stderr:
        p = subprocess.Popen(command, cwd=R, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=stdout, stderr=stderr)
        row['pid'] = p.pid; write(out / 'launch.json', row); row['exitCode'] = p.wait()
    row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), stdoutSha256=sha(out / 'stdout.bin'), stderrSha256=sha(out / 'stderr.bin'))
    write(out / 'terminal.json', row); return row
with ThreadPoolExecutor(max_workers=3) as pool:
    records = list(pool.map(capture, commands))
after = {p: sha(R / p) for p in paths}; write(O / 'source-after.json', after)
fixture = R / 'tests/fixtures/m2-modulekey-extended'
manifest = json.loads((fixture / 'manifest.json').read_bytes())
changes = [str(p) for rel, row in manifest['files'].items()
           if sha(p := fixture / rel) != row['sha256'] or p.stat().st_size != row['bytes']]
report = {'schema': 1, 'records': records, 'allCommandsZero': all(r['exitCode'] == 0 for r in records),
    'changedSources': [p for p in before if before[p] != after[p]], 'changedFixturePayloads': changes,
    'fixtureFiles': len(manifest['files']) + 1, 'fixtureManifestSha256': sha(fixture / 'manifest.json'),
    'scope': 'Python12, driver10 and syntax, hermetic fixture CLI and four pinned inventories only. No Java/native/browser engine execution.',
    'liveHandles': []}
write(O / 'report.json', report)
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['allCommandsZero'] and not report['changedSources'] and not changes else 1)
