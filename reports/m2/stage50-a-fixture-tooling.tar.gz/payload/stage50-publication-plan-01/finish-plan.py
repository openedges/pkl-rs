"""Finish target-only publication proposal; inspect only explicit directories and metadata."""
from pathlib import Path
import datetime,hashlib,json,stat
O=Path(__file__).resolve().parent
B=O.parent
R=B.parent.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value): (O/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
markers=['report.json','build.json','handoff.json','closure.json','outer-terminal.json','process-report.json','failure-qualification.json','artifact-pins.json','execute.terminal.json']
closed={
 'native02-producer':['stage50-native-controls-build02-launch-01','stage50-native-controls-build02-preflight-01','stage50-native-controls-build02-01'],
 'successor-build-and-checks':['stage50-storage-build02','stage50-required-rust-02','stage50-manifest-freshness-02'],
 'successor-M1':['stage50-platform-control-01'],
 'independent-native-audit-history':['stage50-native-build02-c-audit-01'],
}
def row(name,group,status):
 p=B/name; assert p.is_dir(),p
 return {'root':str(p),'group':group,'status':status,'topLevelChildren':[{'name':x.name,'mode':oct(stat.S_IMODE(x.lstat().st_mode)),'kind':'symlink' if x.is_symlink() else 'directory' if x.is_dir() else 'regular'} for x in sorted(p.iterdir())], 'metadataBindings':{n:{'sha256':sha(p/n),'bytes':(p/n).stat().st_size} for n in markers if (p/n).is_file()},'historicClosurePresent':(p/'closure.json').is_file(),'noInventedProducerClosure':True}
rows=[row(n,g,'closed-failed-auditor' if g=='independent-native-audit-history' else 'closed-bounded-capture') for g,names in closed.items() for n in names]
pending=[row('stage50-native-build02-c-audit-02','independent-native-audit','pending-authoritative-review-closure'),row('stage50-platform-integration-01','successor-platform-integration','pending-authoritative-terminal')]
assert json.loads((B/'stage50-storage-build02/build.json').read_bytes())['status']=='CLOSED'
assert sha(B/'stage50-storage-build02/build.json')=='65724103043d34db82cc43e8e69cb3006ca11c4a899e17eb11f23fffa49b8331'
assert sha(B/'stage50-required-rust-02/report.json')=='3ccdb2811b536d578882497c4bb4e81d88078feda056e496e77178b7f0950ada'
assert sha(B/'stage50-platform-control-01/report.json')=='4c680bfd862c4a95de59d303c1ee9ea33343fae8a5528b9a5f12e91fe158f9bd'
prunes=[]
for rel in ['stage50-modulekey-extended-tests-private','stage50-modulekey-extended-driver-tests-private','stage50-native-controls-plan-01/test-private']:
 p=B/rel; s=p.lstat(); assert p.is_dir() and not p.is_symlink(); children=sorted(x.name for x in p.iterdir())
 prunes.append({'path':str(p),'reason':'Temporary cloned fixture/admission/HTTP test workspace; exact exclusion before traversal, not a generic build/cache name rule.','observedImmediateChildren':children,'emptyAtPlanTime':not children,'mode':oct(stat.S_IMODE(s.st_mode))})
write('completion-update.json',{'schema':1,'asOfUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'initialCatalogPreserved':True,'initialExistingRoots':39,'newClosedOrFailedHistoryRoots':len(rows),'totalExplicitClosedHistoryRoots':39+len(rows),'mandatoryClosedHistoryRoots':37+len(rows),'optionalPlanningRoots':2,'addedRoots':rows,'currentlyPendingRoots':pending,'statusQualification':'Pending roots inspected only for exact paths/current metadata; partial reports do not imply final terminal. Later closure requires a new addendum.','noNewEngineExecution':True,'noArchivesCreated':True})
write('prewalk-prunes.json',{'schema':1,'exactPaths':prunes,'noGenericBuildTargetCacheExclusion':True,'noRecursiveTargetWalk':True,'futurePlatformCacheRule':'Only explicit producer-declared dependency cache paths may be excluded before traversal. Bundled source snapshots and built evaluator artifacts are evidence, not generic caches.'})
print(json.dumps({'closedHistoryRoots':39+len(rows),'mandatory':37+len(rows),'optional':2,'pendingObservedRoots':len(pending),'newEngineExecutions':0,'archivesCreated':0}))
