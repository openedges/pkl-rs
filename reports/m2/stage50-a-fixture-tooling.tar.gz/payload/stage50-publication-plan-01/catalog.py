"""Read explicit evidence roots/metadata only; no target/cache tree walk or archive creation."""
from pathlib import Path
import datetime, hashlib, json, stat, tarfile
O = Path(__file__).resolve().parent
R = O.parents[2]
B = O.parent
MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
groups = {
 'fixture-tooling-history': ['stage50-modulekey-extended-' + n for n in [
   'export-01', 'export-02', 'tests-01', 'tests-02', 'driver-tests-01', 'driver-tests-02',
   'driver-tests-03', 'final-checks-01', 'final-checks-02', 'handoff-01', 'handoff-02']],
 'helper-pipeline-reviews': ['stage50-portable944-c-design-review-01',
   *['stage50-extended-helper-c-unit-' + str(i).zfill(2) for i in range(1, 5)],
   'stage50-extended-pipeline-c-review-01', 'stage50-extended-pipeline-c-review-02',
   *['stage50-extended944-platform05-c-audit-' + str(i).zfill(2) for i in range(1, 4)]],
 'old05-actual-controls': ['stage50-extended-helper-native05-debug-01',
   'stage50-extended944-platform05-control-01', 'stage50-extended944-platform05-control-02'],
 'storage-discovery-and-candidate01': ['stage50-code-storage-discovery-01',
   'stage50-code-storage-focused-01', 'stage50-code-storage-c-review-01',
   'stage50-code-storage-cow-fix-01', 'stage50-code-storage-focused-02',
   'stage50-code-storage-c-review-02', 'stage50-storage-build01'],
 'required01-and-manifest': ['stage50-required-rust-01', 'stage50-manifest-freshness-01'],
 'native-orchestrator-preflights': ['stage50-native-controls-plan-01',
   'stage50-native-controls-preflight-01', 'stage50-native-controls-preflight-02'],
 'environment-metadata': ['stage50-platform-environment-01'],
 'optional-next-language-planning': ['stage50-next-language-triage-01', 'stage50-next-language-triage-02'],
}
pending = [
 ('stage50-storage-build02', 'Successor artifact may be CLOSED, but final publication bundle remains pending required02/native/platform/source binding.'),
 ('stage50-required-rust-02', 'Required five checks pending authoritative terminal and stable-source readback.'),
 ('stage50-platform-control-01', 'Stage50 M1/binding acquisition pending terminal, artifact/source readback and knownregex qualification.'),
 ('stage50-native-controls-build02-launch-01', 'Authorized native pipeline currently in flight; no completed publication claim.'),
 ('stage50-native-controls-build02-preflight-01', 'Admission only, not actual native compatibility completion.'),
 ('stage50-native-controls-build02-01', 'All provided212/public212/extended944 actual outcome+audit pending.'),
]
markers = ['report.json', 'handoff.json', 'closure.json', 'process-report.json', 'execution-receipt.json',
 'actual-terminal.json', 'outer-terminal.json', 'root-terminal-receipt.json', 'build.json', 'summary.json',
 'checks.json', 'actual/execution.json', 'actual/preflight.process.json', 'actual/postflight.process.json']
rows = []
for group, names in groups.items():
 for name in names:
  root = B / name
  assert root.is_dir(), root
  children = []
  for child in sorted(root.iterdir()):
   mode = child.lstat().st_mode
   children.append({'name': child.name, 'kind': 'symlink' if stat.S_ISLNK(mode) else 'directory' if stat.S_ISDIR(mode) else 'regular'})
  bound = {rel: {'sha256': sha(root / rel), 'bytes': (root / rel).stat().st_size}
           for rel in markers if (root / rel).is_file()}
  rows.append({'root': str(root), 'group': group, 'scope': 'Optional planning annex, not compatibility evidence.' if group.startswith('optional-') else 'Existing bounded history; failures/unknown historic terminal fields must be retained.',
   'topLevelChildren': children, 'metadataBindings': bound,
   'historicClosurePresent': (root / 'closure.json').is_file(),
   'noInventedProducerClosure': True})
write(O / 'existing-roots.json', {'schema': 1, 'asOfUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'groups': groups, 'roots': rows,
 'looseFiles': [{'path': str(B / 'stage50-modulekey-extended-driver-tail.txt'), 'sha256': sha(B / 'stage50-modulekey-extended-driver-tail.txt'), 'role': 'Original driver-generation source fragment; preserve as tooling history.'}]})
write(O / 'pending.json', {'schema': 1, 'roots': [{'root': str(B / n), 'exists': (B / n).exists(), 'publicationStatus': 'pending', 'reason': reason} for n, reason in pending],
 'notYetNamedCaptures': ['Final Stage50 public+provided212 and extended944 independent native audits',
   'Final Stage50 actual Node/Chromium original212 and extended944',
   'Existing legacy provider regressions and M1 same2regex strictfailures',
   'Full selected/lifecycle regression if assigned; independent summary/audit',
   'Final source/fixture/tool-to-Git blob and artifact-build binding',
   'Actual explicit archive selection, before/after original checks, evidence.py create+verify+memberreadback, publication closeout']})

# Planning-only hash join to already published Java archive inventories.
fixture = R / 'tests/fixtures/m2-modulekey-extended'
manifest = json.loads((fixture / 'manifest.json').read_bytes())
archives = {}; indexes = {}
for suffix in ['01-03', '04-07']:
 path = MAIN / ('reports/m2/stage49-java-controls' + suffix + '.tar.gz')
 with tarfile.open(path, 'r:gz') as archive:
  inventory = json.load(archive.extractfile('EVIDENCE.json'))
 indexes[suffix] = {r['path']: r for r in inventory['files']}
 archives[suffix] = {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
counts = {}; reused = 0; derived = {}
for rel, row in manifest['files'].items():
 parts = Path(rel).parts
 if parts[0] in ['original', 'provenance']:
  number = int(parts[1][-2:]); suffix = '01-03' if number <= 3 else '04-07'
  member = 'payload/stage49-oracle-modulekey-' + str(number).zfill(2) + '/' + '/'.join(parts[2:])
  proof = indexes[suffix][member]
  assert proof['sha256'] == row['sha256'] and proof['bytes'] == row['bytes'], rel
  counts[suffix] = counts.get(suffix, 0) + 1; reused += 1
 else: derived[rel] = row
derived['manifest.json'] = {'sha256': sha(fixture / 'manifest.json'), 'bytes': (fixture / 'manifest.json').stat().st_size}
write(O / 'fixture-reuse.json', {'schema': 1, 'fixtureRoot': str(fixture), 'totalFiles': len(manifest['files']) + 1,
 'manifestSha256': sha(fixture / 'manifest.json'), 'archiveInventoryHashJoinedFiles': reused,
 'countsByArchive': counts, 'publishedArchives': archives, 'newDerivedFiles': derived,
 'reconstructionRule': 'original|provenance/javaNN/relative -> payload/stage49-oracle-modulekey-NN/relative in archive01-03 or04-07.',
 'qualification': 'Exact SHA/length join against existing published EVIDENCE inventories for planning; not a new full archive member readback. Actual publication must authenticate references and final Git mapping separately.'})
write(O / 'catalog-receipt.json', {'schema': 1, 'existingRoots': len(rows), 'mandatoryRoots': sum(len(v) for k, v in groups.items() if not k.startswith('optional-')),
 'fixtureReusedFiles': reused, 'fixtureNewDerivedFiles': len(derived), 'newArchivesCreated': 0,
 'newEngineExecutions': 0, 'walkedTargetOrCacheTrees': False})
print((O / 'catalog-receipt.json').read_text())
