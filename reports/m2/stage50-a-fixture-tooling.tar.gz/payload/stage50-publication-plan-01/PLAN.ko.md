# Stage50 게시 증거 선택·분할 계획

이 문서는 TARGET 전용 게시 제안이다. archive 생성, `reports/` 변경, Git 작업, Java 재취득, 엔진 실행을 수행하지 않는다. 저장소 전체·`target/` 전체·캐시 트리를 재귀 탐색하지 않는다. 실제 선택은 명시된 producer inventory의 직접 경로를 우선 사용하고, 미봉인 기록은 경로·원래 실행 메타데이터와 실패를 그대로 보존한다.

## 목록과 현재 상태

경로 접두사는 `/Users/cody.ij.hwang/Projects/pkl-rs.stage50/target/m2/`이다. `existing-roots.json`은 최초 39개 root(필수 37개, 선택 계획 2개)의 실제 직접 자식·메타데이터 SHA를 기록한 불변 시점 목록이다. 당시 미완료였던 상태는 `pending.json`에 남겨 둔다. 최신 상태는 이를 덮어쓰지 않고 `completion-update.json`에 추가한다. 추가 종료/실패 기록 8개를 포함하면 현재 명시된 종료 기록은 **47개 root: 필수 45개, 선택 계획 2개**이다. 별도 loose file 1개가 있다. 독립 감사와 플랫폼 통합의 진행 중 root 2개는 종료 목록에 합산하지 않는다.

다음 표의 이름은 모두 정확한 디렉터리 이름이다. 각 root의 직접 자식 및 존재하는 `report.json`, `handoff.json`, `closure.json` 등은 JSON 목록에서 SHA·길이로 연결한다. 파일이 없으면 원래부터 봉인되었다고 추정하지 않는다.

| 논리 그룹 | 기존 명시 root |
|---|---|
| fixture/tool 이력 11개 | `stage50-modulekey-extended-export-01`, `-export-02`, `-tests-01`, `-tests-02`, `-driver-tests-01`, `-driver-tests-02`, `-driver-tests-03`, `-final-checks-01`, `-final-checks-02`, `-handoff-01`, `-handoff-02` (`stage50-modulekey-extended` 공통 접두사) |
| helper·독립 검토 10개 | `stage50-portable944-c-design-review-01`; `stage50-extended-helper-c-unit-01`부터 `-04`; `stage50-extended-pipeline-c-review-01`, `-02`; `stage50-extended944-platform05-c-audit-01`부터 `-03` |
| 과거 build05 실제 제어 3개 | `stage50-extended-helper-native05-debug-01`, `stage50-extended944-platform05-control-01`, `-02` |
| 저장 구조 발견·초기 후보 7개 | `stage50-code-storage-discovery-01`, `-focused-01`, `-c-review-01`, `-cow-fix-01`, `-focused-02`, `-c-review-02` (`stage50-code-storage` 접두사); `stage50-storage-build01` |
| 초기 필수 검사·freshness 2개 | `stage50-required-rust-01`, `stage50-manifest-freshness-01` |
| 네이티브 도구·초기 admission 3개 | `stage50-native-controls-plan-01`, `stage50-native-controls-preflight-01`, `-02` |
| 환경 1개 | `stage50-platform-environment-01` |
| 선택 계획 2개 | `stage50-next-language-triage-01`, `-02` |
| 추가 네이티브 producer 3개 | `stage50-native-controls-build02-launch-01`, `stage50-native-controls-build02-preflight-01`, `stage50-native-controls-build02-01` |
| 추가 후보·검사 3개 | `stage50-storage-build02`, `stage50-required-rust-02`, `stage50-manifest-freshness-02` |
| 새 코어 M1 1개 | `stage50-platform-control-01` |
| 독립 native 감사 초기 실패 1개 | `stage50-native-build02-c-audit-01` |

별도 원문 `stage50-modulekey-extended-driver-tail.txt`는 초기 driver 생성 조각이다. 최종 driver로 대체하지 않고 tooling 이력에 넣는다. `stage50-collection-transforms-design-01` 등 후속 언어 계획은 본 필수 선택에 포함하지 않는다. 선택 계획 2개도 구현·호환성 성과에 합산하지 않는다.

## 반드시 보존할 실패·수정 연결

- export01의 실제 37330/exit1은 원래 report의 문자열 `"false"`와 boolean 해석 차이로 fixture 생성 전에 종료했다. `initial-tool.py`와 raw stdout/stderr를 보존한다. export02 실제 38594/exit0과 installed copy 실제 48020/exit0은 별도 기록이다.
- Python tests01 실제 13966/exit1은 11 pass와 오류 문구 정규식 기대 1 fail이었다. tests02 실제 5012/exit0은 12 pass이다. driver 초기 8개·후속 10개·최종 11개 테스트 기록과 각 당시 소스를 구분한다.
- final-checks01 실제 17698/exit0은 9 commands, final-checks02 실제 99281/exit0은 4 commands이다. 후자는 변경 없는 Python 12개와 inventory 4개를 앞선 기록에서 명시 재사용한다. installed 32,968개 payload 및 도구의 전후 hash 변화 0을 보존한다.
- helper 초기 comparator는 null/unknown/limit-exceeded 오류를 ordinary compatible로 셀 수 있었다. 수정 후에는 양의 알려진 classification과 `success`/`language-error`만 ordinary 지원으로 취급하며, 잘못된 classification은 raw 보존 후 acquisition 실패이다. 최초·최종 helper와 C unit01–04 및 pipeline-review01–02를 함께 보존한다. 최종 unit04는 36/36이다.
- 과거 Stage49 build05를 사용한 control01 실제 8676/exit1은 Java03의 GC `{kind:'gc',value:''}`에 대한 driver 관찰 감사 불일치 4 sessions를 포함한다. fixture를 바꾸지 않고 auditor가 빈 operand를 확인한 뒤 zero-argument GC로 투영하도록 수정했다. nonempty operand는 거부한다. control02 실제 40111/exit1은 strict gate 실패를 유지하면서 acquisition/observation/cleanup은 true이다.
- 과거 build05 control02는 각 Node/Chromium 944 API 중 936 raw match = 836 ordinary compatible + 100 초기 의도 미도달 diagnostic-only, 8 Java internal boundary mismatch이다. full Java event/counter 및 full compatibility는 false이다. 이는 **Stage50 새 저장 엔진의 실행 증거가 아니다**. debug01도 Node 전용 과거 엔진 관찰이다.
- C portable 감사01은 없는 과거 `complete` 필드 가정, 감사02는 서로 다른 직접/상위 source-map 범위를 같다고 가정하여 실패했다. 원문·qualification을 남기고 최종 감사03을 별도로 연결한다. 원래 producer 실패로 재해석하지 않는다.
- storage discovery의 check/focused/lifetime/storage-unit 실패와 성공 로그를 모두 남긴다. focused01의 188개 검사와 focused02의 190개 guarded 검사, C 리뷰는 최종 Rust5와 별도이다. review01의 3개 unrelated segment COW mutation finding 및 source220/변경11개를 보존하고, review02의 수정 diff·snapshot/reentry tests와 연결한다. 논리 출력 실패가 입증된 것으로 확대하지 않는다.
- required01 실제 53297/exit1은 xtask/fmt/workspace test/Wasm 4개 성공과 clippy101(6 useless conversions)을 보존한다. 초기 후보01은 build 성공 후 admission만 수행했고 실제 native controls는 실행하지 않았다.
- native preflight01의 미실행 상태에서 빈 집계 boolean이 true인 점을 qualification으로 남긴다. 최종 runner는 `executed=false`, preflight integrity와 native acquisition을 분리한다. 앞선 소스·preflight를 덮어쓰지 않는다.
- native C 감사01 실제 wrapper4720/child63862/exit1은 valid `ModuleCompletion::KeyResolved`를 빠뜨린 auditor 가정이었다. `failure-qualification.json`과 원문을 보존한다. 후속 감사02의 결론을 앞선 실패에 소급하지 않는다.

## 후보02의 종료 증거와 아직 남은 것

후보02 build manifest는 `65724103043d34db82cc43e8e69cb3006ca11c4a899e17eb11f23fffa49b8331`, native probe는 `116f301c06b4c4cc25e2e4609d263e45a12dc61c49ade796c73b0c0cc33a39b6`이다. 실제 build93249/exit0, source227 bytes 전후 안정이다. 새 root에서 실행된 runner는 `9f1d881ab292401041e26a18ed7963c94719c0c132b2657061cf5f8b661685f8`이다. 기존 Stage49 binary를 새 후보라고 받아들이지 않으며, 실제 build source snapshot과 artifact identity를 비교에 연결한다.

native 실제 wrapper9504/worker60233은 exit0이다. UTC `2026-10-23T21:16:38.764950+00:00`부터 `21:17:59.469668+00:00`까지의 commands/PID/terminal이 launch root에 있다. provided212 36 processes·212 match, public212 36 processes·212 match, extended944 140 processes·936 raw match(836 ordinary +100 diagnostic-only)·8 internal mismatch이다. 모든 212 processes terminal exit0/slots0이며 미실행 API·changedInputs가 없다. provided/public 반복을 새로운 feature 수로 더하지 않는다. collector exit0은 full compatibility 성공을 뜻하지 않는다. full Java event/counter gate는 모든 profile에서 false이다.

native producer handoff SHA는 `0dd7cb4e7a0aa1ceade1ccdff33342b96551ad28a9aa3b8c20976a3c30e3a8c5`, closure는 `0c0b5137ea2db95b864231513e20a1978355223777bbe4304730665bd07e50f9`이다. 명시 payload 63,683개·15,490,972 bytes를 봉인했다. 이 producer seal은 C의 독립 raw readback을 대신하지 않는다.

required02 실제 44569/exit0은 필수 5개 검사 모두0, source86,455개 전후 안정이며 report SHA는 `3ccdb2811b536d578882497c4bb4e81d88078feda056e496e77178b7f0950ada`이다. freshness02는 초기 check1→생성0→재check0을 모두 보존한다. 구현 source hash 4개 경로만 바뀌었고 4,527 cases(ready3,664/unimplemented823/unmapped40), 475 requirements의 상태·개수는 바뀌지 않았다. freshness는 호환성 성공이 아니다.

새 코어 M1 실제 root53762/exit0은 native/Node/Chromium 6,078 shared equality, Java 각6,076 match 및 기존 regex 2 failures를 보존한다. architecture/acquisition true, source325 안정이다. report SHA `4c680bfd862c4a95de59d303c1ee9ea33343fae8a5528b9a5f12e91fe158f9bd`, artifact pins SHA `cc02e92d1fa9b589356dc531a9d01311ed105391ef2ccad539c8967578c5561c`를 연결한다.

다음은 아직 종료·최종 게시로 주장하지 않는다.

1. `stage50-native-build02-c-audit-02`: C 독립 raw/source227/artifact/counter/cleanup 감사의 authoritative terminal·handoff 대기. B가 전수 감사를 중복하지 않는다.
2. `stage50-platform-integration-01`: root actual78695의 11 drivers 실행 중이라는 전달 상태이며, 원래212 provided/public·extended944·renderer/resource/preparation/ModuleInfo/security/guestcatch/loader/inheritance의 최종 terminal·artifact/input guard·개별 strict 결과를 기다린다. 일부 child report가 있어도 전체 성공으로 승계하지 않는다.
3. Stage50 full selected/lifecycle regression이 배정되는 경우 별도 원문·감사. MAIN의 Stage49 full run은 Stage50 결과가 아니다.
4. 최종 source/tool/fixture Git blob 및 runtime/binding build 연결. 현재 source snapshot/build hash 증거를 Git commit 증거라고 부르지 않는다.
5. 최종 explicit selection, 모든 원본 전후 path/kind/mode/hash 대조, `tools/evidence.py` create·별도 verify·모든 raw member readback 및 publication closeout. 이번 계획에서는 수행하지 않는다.

## fixture 및 과거 원문 중복을 줄이는 방법

installed `tests/fixtures/m2-modulekey-extended`의 32,968 files/53,001,802 bytes와 export02 copy는 byte-identical 검증 기록을 참조한다. manifest SHA는 `eda9449570132c0f76ebf2ea67071a94b6b3a53b29fb9a49dfb982e66ad18bb2`이다. `fixture-reuse.json`은 32,964개 원문/provenance 파일을 기존 Stage49 Java archive의 `EVIDENCE.json` SHA·길이와 직접 join했다. 이는 이번 작업에서 archive member 전체를 다시 읽은 결과가 아니다.

- MAIN `reports/m2/stage49-java-controls01-03.tar.gz`: SHA `f86adbbced1d8fa918f3671557f435dc8135a3a91921a25d627756e9521ae126`, 3,412,494 bytes, 재사용 23,806개.
- MAIN `reports/m2/stage49-java-controls04-07.tar.gz`: SHA `769a0b2ae8e200abd21b0266a0cf9a38669d00255ac06f79a0aaca3c84173071`, 1,716,924 bytes, 재사용 9,158개.
- 변환은 `original|provenance/javaNN/relative` → `payload/stage49-oracle-modulekey-NN/relative`이다. semantic JSON 재직렬화·출력 정규화가 아닌 정확 byte hash/length mapping이다.
- 새 파생 파일 4개는 `fixtures.json`, `host-metadata.json`, `provenance-map.json`, `manifest.json`이다. 최종 commit에 실제 동일 blob이 있다면 blob/SHA/size 복원 mapping을 쓴다. 없으면 이 4개와 source-proof/verification metadata를 한 번 보존한다. 원문이나 export copy를 삭제하지 않는다.
- Stage49 native build05·platform artifacts는 기존 Stage49 published core/platform/source-binding 자료를 정확 hash로 참조한다. 이전 artifact를 Stage50 artifact로 재명명하지 않는다. 실제 새 build01/02 source bytes가 과거 blob과 다르면 원문을 보존한다.
- 과거 dependency 위치는 `fixture-reuse.json`, MAIN `reports/m2/stage49-oracle-index.json` 및 source/core/platform capture metadata로 연결한다. 과거 archive가 있다고만 쓰지 말고 최종 selection에 실제 archive SHA와 member 경로를 넣어 독립 복원이 가능하게 한다.

## archive 분할 제안

아래는 의미 단위 제안이며 archive 개수·압축 크기 확정이나 생성 완료 주장이 아니다. 실제 압축 후 각 파일이 **100,000,000 bytes 미만**인지 확인하고, 넘는 단위만 원본을 바꾸지 않고 다시 나눈다. 임의 48MiB gate는 두지 않는다.

| 단위 | 보존할 내용 | 중복 방지/범위 |
|---|---|---|
| A fixture·tool 이력 | exporter 실패·성공, Python/driver 원래·최종 소스와 tests, checks, handoffs, loose source fragment | golden 전체 중복 대신 위 exact reconstruction mapping; 새 파생4개는 단일 보존 |
| B helper·검토 | helper unit01–04, pipeline reviews01–02, portable C audits01–03, 환경, 선택 계획 annex | 최초 분류 오류/감사 가정 실패를 최종 성공으로 치환하지 않음 |
| C 과거 엔진 실제 제어 | build05 debug·control01 실패·control02 strict failure 및 commands/raw/session results | 과거 Stage49 엔진 의존성은 published hash reference; Stage50 엔진 성과와 분리 |
| D 저장 구조·후보 이력 | discovery/focused/COW fixes/C reviews, build01·02 source/artifact manifests·실제 raw logs | build01 초기 COW/clippy 한계를 보존; artifact/source byte 동일 복원만 허용 |
| E 검사·freshness | required01 실패와 required02 성공, freshness01·02의 check 실패/생성/성공 | 개수 불변·source hash 갱신을 호환성 향상으로 계산하지 않음 |
| F native 도구·실행 | runner·원래 producer/config scripts·preflights·build02 launch/actual63,683 payload 및 C 감사 실패·후속 최종 감사 | 실제 raw15.5MB는 단일 단위 가능성이 있으나 압축 후 결정; 새 엔진 실행을 재취득하지 않음 |
| G 새 플랫폼·최종 closeout | M1 actual/raw/artifacts/source binding, 완료 후 11driver captures·감사·선택/검증/원본 guard | 진행 중 플랫폼 root는 closure 후에만 최종 bundle로 편입; compiled dependency caches는 아래 규칙 |

storage/core·root 플랫폼·C 검토의 실제 archive 담당은 parent가 조정한다. 이 문서가 원본 소유권을 B로 옮기지는 않는다. 교차 archive에는 원문을 불필요하게 다시 넣지 않고 정확 참조를 남기며, 중복 삭제 때문에 실패 이력이나 입력 복원 가능성이 사라지지 않게 한다.

## 선택·prune·검증 절차

`prewalk-prunes.json`의 다음 **정확 absolute paths**는 임시 clone/test workspace로 선택 전에 제외한다. 계획 시 직접 자식 목록을 확인했고 모두 비어 있었다. 게시 시 다시 stat/direct-list를 기록하며 빈 상태를 가정하지 않는다.

- `/Users/cody.ij.hwang/Projects/pkl-rs.stage50/target/m2/stage50-modulekey-extended-tests-private`
- `/Users/cody.ij.hwang/Projects/pkl-rs.stage50/target/m2/stage50-modulekey-extended-driver-tests-private`
- `/Users/cody.ij.hwang/Projects/pkl-rs.stage50/target/m2/stage50-native-controls-plan-01/test-private`

`build`, `target`, `cache`, `sources`라는 일반 이름으로 제외하지 않는다. build source snapshot·compiled evaluator는 증거이다. 미래 플랫폼 dependency cache는 실제 producer가 선언한 정확 경로를 먼저 확정하고 traversal 전에 prune한다. 링크는 lstat로 kind/target bytes를 보존하며 따라가서 공유 dependency를 걷지 않는다. Cargo target와 node_modules 공유 링크는 명시 root 선택 바깥에 둔다.

실제 게시자는 다음을 순서대로 수행한다: sealed inventory의 직접 파일 경로 인증 → 필요한 미봉인 root의 명시 경로와 역할 추가 → exact cache prune 확정 → 원래 path/kind/mode/size/SHA selection → clean gathered source로 복사/복원 참조 작성 → `tools/evidence.py` archive 생성 → 독립 verify → 모든 선택 raw member의 source SHA·길이 readback → 원본 변화0 확인 → archive SHA/count/size/index/실제 commands·PID·exit 및 남은 실패를 기록. 원래 closure/terminal이 없는 기록에는 null/미확인을 유지하며 새로 과거 producer seal을 만들어 주지 않는다.

이번 문서는 source/metadata read-only 계획이며, 새 Java/native/browser/build 실행·archive 생성은 0이다. 목록에서 읽은 진행 중 상태는 이 문서 시점의 관찰일 뿐이다. 후속 terminal은 새 addendum으로 연결한다.
