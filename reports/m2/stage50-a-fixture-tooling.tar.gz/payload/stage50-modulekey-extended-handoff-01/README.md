# ModuleKey extended Java fixture and portable driver

The installed fixture preserves Java01–07's 35 cases, 140 evaluator sessions,
944 API outcomes, and 10,124 original ordered events. Of the API observations,
836 reached their ordinary intent, 100 preserve initial query-local alias errors,
and eight are Java internal-error boundaries. All remain present.

`tools/modulekey_extended_fixtures.py` authenticates seven independent original
report/inventory/closure pins, reconstructs raw expected channels and Host inputs,
and checks the exact fixture file set. Verification reads copied payloads only.
The source-load IO input has ASCII-derived transport units; API channels and
SecurityManagerException causes retain their separate original encoding evidence.

The driver requires 13 positional arguments:

```
node tools/platform/compare-modulekey-extended.mjs [--preflight-only] OUTPUT WASM_DIR ADDON FIXTURES_DIR HOST_METADATA VERIFIER PINNED_PACKAGE_JSON BROWSER_EXECUTABLE BROWSER_SHA256 ARTIFACT_PINS_JSON ARTIFACT_PINS_SHA256 COHORT public
```

`COHORT` is `java01` through `java07`, or `all944`. Use a fresh output. Browser
executable and artifact manifest hashes are explicit. `HOST_METADATA` must have
the exact authenticated fixture copy's bytes. Source/provider rules come from
the Java inputs, never Rust results. The shared runtime owns wrappers, URI
resolution, search order, caches, initialization and diagnostics.

Raw byte matches remain separate from request/observation integrity, constructor
and acquisition errors, cleanup, ordinary compatibility, and the full Java
event/counter gate. The latter remains false. Actual runs therefore retain a
strict exit1 even when every ordinary API matches; preflight-only may exit0.

The final source-bound checks include Python12, driver10, two syntax checks,
the hermetic fixture CLI and four inventory checks. This handoff does not claim
an actual driver Node/Chromium run or Stage50 runtime compatibility. Root owns
the separate extended session helper and frozen-artifact acquisition.

Earlier export and test failures are retained by exact references in handoff.json.
No Java was reacquired and no original evidence, MAIN files, Rust, or Git was changed.
