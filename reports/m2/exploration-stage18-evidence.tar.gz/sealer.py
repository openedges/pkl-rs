"""Seal Stage18 attempts with exact-byte deduplication and verified rehydration."""
from pathlib import Path
import hashlib,json,sys,tarfile,zlib
sys.path.insert(0,'tools')
import evidence
sys.path.insert(0,'target/m2')
from stage18_rehydrate_exploration import rehydrate
ROOT=Path.cwd();R=Path('target/m2');digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();encode=lambda x:(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode()
summary=json.loads((R/'stage18-exploration-summary-final.json').read_bytes());main=R/'stage18-exploration-store-main';main.mkdir(exist_ok=False)
items=[p for p in R.iterdir()if p.name.startswith(('stage18-','stage18_'))and not p.name.startswith(('stage18-exploration-','stage18-package-explorations'))]
for p in sorted(R.glob('stage18-superseded-final-*.json')):
 for name in json.loads(p.read_bytes())['affected_directories']:
  item=R/name
  if item.exists()and item not in items:items.append(item)
items.extend([R/'stage17-sequences-java-01',R/'stage15-java-01/cases/recursive-generic-shadow/input.pkl',R/'class-lifecycle-stage18-final-03'])
files={};excluded=[]
for item in items:
 candidates=[item]if item.is_file()else sorted(item.rglob('*'))
 for p in candidates:
  if not p.is_file():continue
  relative=p.relative_to(ROOT)if p.is_absolute()else p
  if any(x in relative.parts for x in ['build','node_modules','__pycache__','.git']):excluded.append(dict(path=str(relative),bytes=p.stat().st_size,reason='Disposable build/dependency cache; frozen executed artifacts and complete raw captures are retained separately.'));continue
  assert not p.is_symlink();files[str(relative)]=p
rows=[];unique={}
for name,p in sorted(files.items()):
 data=p.read_bytes();sha=hashlib.sha256(data).hexdigest();rows.append(dict(path=name,bytes=len(data),sha256=sha,mode=p.stat().st_mode&0o777,storage='payload/'+sha))
 if sha not in unique:unique[sha]=dict(path=p,bytes=len(data),compressed_estimate=len(zlib.compress(data,6)))
parts=[];current=[];size=0
for sha,record in sorted(unique.items()):
 if current and size+record['compressed_estimate']>48_000_000:parts.append(current);current=[];size=0
 current.append(sha);size+=record['compressed_estimate']
if current:parts.append(current)
archives=[]
for index,shas in enumerate(parts,1):
 folder=R/f'stage18-exploration-store-part-{index:02}';(folder/'payload').mkdir(parents=True,exist_ok=False)
 for sha in shas:
  data=unique[sha]['path'].read_bytes();assert hashlib.sha256(data).hexdigest()==sha;(folder/'payload'/sha).write_bytes(data)
 archive=Path(f'reports/m2/exploration-stage18-support-{index:02}-evidence.tar.gz');assert not archive.exists();evidence.create(folder,archive,[]);assert archive.stat().st_size<80_000_000
 archives.append(dict(path=str(archive),bytes=archive.stat().st_size,sha256=digest(archive),blob_count=len(shas),uncompressed_unique_bytes=sum(unique[sha]['bytes']for sha in shas),inventory_verified=True))
manifest=dict(schema=1,scope='Every included original file can be reconstructed at its original workspace-relative path. Identical bytes are stored once by SHA-256; no byte normalization, binary editing, or captured execution is performed.',files=rows,excluded_disposable_cache_files=excluded)
(main/'ORIGINALS.json').write_bytes(encode(manifest));(main/'SUPPORT_ARCHIVES.json').write_bytes(encode(dict(schema=1,archives=archives,extraction='Verify each archive individually, extract main and every support archive into a common new directory, then run rehydrate.py EXTRACTED_ROOT NEW_DESTINATION. EVIDENCE.json belongs to each individual archive; omit it when combining extracts.')));(main/'rehydrate.py').write_bytes((R/'stage18_rehydrate_exploration.py').read_bytes());summary['storage']=dict(original_files=len(rows),original_bytes=sum(r['bytes']for r in rows),unique_payloads=len(unique),unique_bytes=sum(r['bytes']for r in unique.values()),exact_byte_deduplication=True,support_archives=archives);(main/'SUMMARY.json').write_bytes(encode(summary));(main/'sealer.py').write_bytes(Path(__file__).read_bytes())
archive=Path('reports/m2/exploration-stage18-evidence.tar.gz');assert not archive.exists();evidence.create(main,archive,[])
extracted=R/'stage18-exploration-extracted-audit';extracted.mkdir(exist_ok=False)
for path in [archive,*[Path(a['path'])for a in archives]]:
 evidence.verify(path)
 with tarfile.open(path,'r:gz')as source:
  for member in source.getmembers():
   if member.name=='EVIDENCE.json':continue
   destination=extracted/member.name;destination.parent.mkdir(parents=True,exist_ok=True);data=source.extractfile(member).read()
   if destination.exists():assert destination.read_bytes()==data
   else:destination.write_bytes(data)
result=rehydrate(extracted,R/'stage18-exploration-rehydrated-audit')
for row in rows:
 original=files[row['path']];restored=R/'stage18-exploration-rehydrated-audit'/row['path'];assert original.read_bytes()==restored.read_bytes()and digest(original)==row['sha256']
result.update(original_file_bytes_compared_after_sealing=True,all_archives_inventory_verified=True,support_paths_disjoint=True,captured_binaries_executed=False)
(main/'REHYDRATION_VERIFICATION.json').write_bytes(encode(result));archive.unlink();evidence.create(main,archive,[]);assert archive.stat().st_size<80_000_000
index=dict(main=dict(path=str(archive),bytes=archive.stat().st_size,sha256=digest(archive),inventory_verified=True),support_archives=archives,rehydration=result,summary_sha256=digest(main/'SUMMARY.json'));(R/'stage18-exploration-sealed-index.json').write_bytes(encode(index));print(json.dumps(index,indent=2))
