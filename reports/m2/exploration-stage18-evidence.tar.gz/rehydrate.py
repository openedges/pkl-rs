"""Reconstruct sealed Stage18 exploration in a new directory, checking every byte.

Extract the main and all indexed support archives into one directory first.
This utility never executes a captured binary.
"""
from pathlib import Path
import hashlib,json,sys

def rehydrate(source,destination):
 source=Path(source).resolve();destination=Path(destination).resolve();destination.mkdir(parents=True,exist_ok=False);manifest=json.loads((source/'ORIGINALS.json').read_bytes());seen=set();count=0;size=0
 for row in manifest['files']:
  relative=Path(row['path']);assert not relative.is_absolute()and'..'not in relative.parts and str(relative)not in seen;seen.add(str(relative));data=(source/row['storage']).read_bytes();assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256'];target=destination/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);target.chmod(row['mode']);assert target.read_bytes()==data;count+=1;size+=len(data)
 actual={str(p.relative_to(destination))for p in destination.rglob('*')if p.is_file()};assert actual==seen
 return dict(status='pass',files=count,bytes=size,all_original_paths_sizes_hashes_and_bytes_verified=True,captured_binaries_executed=False)
if __name__=='__main__':print(json.dumps(rehydrate(sys.argv[1],sys.argv[2]),indent=2))
