"""Seal Stage15 local evidence and bind every final source copy to Git.

Read-only report verification does not execute any retained evaluator binary.
No CI acquisition, prior CI status, or hosted artifact is required.
"""
import argparse
from collections import Counter
import hashlib
import importlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
import stage15_package_common as c

ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
REPORTS = ROOT / 'reports/m2'
BASELINE = BASE / 'stage15-baseline-contract'
KNOWN = {'error-cycle', 'error-remainder-zero'}


def old_archive(name, members):
    """Read identified original bytes; original archives are never rewritten."""
    summary = c.load(REPORTS / 'stage14-final-summary.json')
    record = summary['archives'][name]
    path = ROOT / record['path']
    c.identity(path, record['sha256'], record['bytes'])
    with tarfile.open(path) as stream:
        return {name: stream.extractfile(name).read() for name in members}


def source_rows(directories, data):
    for suite, field in [('language', 'source_sha256'), ('frontend', 'source_sha256'), ('platforms', 'source_hashes')]:
        for name, digest in data[suite][field].items():
            yield name, directories[suite] / 'sources' / name, digest
    for suite in ['classes', 'lifecycle']:
        for row in data[suite]['sources']:
            yield row['path'], directories[suite] / row['snapshot'], row['sha256']
    for row in data['runtime']['identities']:
        if 'snapshot' in row:
            snapshot = Path(row['snapshot'])
            yield snapshot.relative_to(directories['runtime'] / 'sources').as_posix(), snapshot, row['sha256']
    directory = directories['platforms'] / 'oracle-native'
    for name, digest in c.load(directory / 'report.json')['sources'].items():
        yield name, directory / 'sources' / name, digest
    if 'prior' in data:
        for path in sorted((BASE / 'prior-selection-stage15-final/sources').rglob('*')):
            if path.is_file():
                yield path.relative_to(BASE / 'prior-selection-stage15-final/sources').as_posix(), path, c.sha(path)


def inspect(directories):
    sys.path.insert(0, str(ROOT / 'tools'))
    language_tool = importlib.import_module('m2_language')
    class_tool = importlib.import_module('m2_class_lifecycle')
    frontend_tool = importlib.import_module('m1_frontend')
    lifecycle_tool = importlib.import_module('m1_lifecycle')
    runtime_tool = importlib.import_module('m1_runtime')
    platform_tool = importlib.import_module('m1_platforms')
    data = dict(language=language_tool.check_report(directories['language']),
        classes=class_tool.check_report(directories['classes']),
        frontend=frontend_tool.check_report(directories['frontend']),
        lifecycle=lifecycle_tool.check_report(directories['lifecycle']),
        runtime=c.load(directories['runtime'] / 'report.json'),
        platforms=c.load(directories['platforms'] / 'report.json'),
        validation=c.validation_report(directories['validation']))
    language = data['language']
    c.require(language_tool.development_passes(language, directories['language']), 'selected development contract failed')
    c.require(not language_tool.subset_passes(language) and language['full_gate_failures'], 'known strict failures missing')
    c.require({r['id'] for r in language['results'] if r['status'] != 'pass'} == KNOWN, 'known selected failures changed')
    c.require(language['candidate']['source_binding'] == 'recorded-build', 'candidate lacks recorded build')
    c.require(all(r['status'] == 'pass' for r in language['metamorphic_results']), 'metamorphic failure')
    baseline = c.load(BASELINE / 'baseline.json')
    inventory = c.load(BASELINE / 'sha256.json')
    c.require(set(inventory) == {p.relative_to(BASELINE).as_posix() for p in BASELINE.rglob('*')
                              if p.is_file() and p.name != 'sha256.json'}, 'baseline inventory incomplete')
    for name, digest in inventory.items():
        c.identity(BASELINE / name, digest)
    original = c.load(BASELINE / 'cases.json')['cases']
    selected = c.load(directories['language'] / 'sources/tests/fixtures/m2/cases.json')['cases']
    c.require(len(original) == baseline['case_count'] and selected[:len(original)] == original,
              'original selected prefix definitions changed')
    c.exact_ids(language['results'], [r['id'] for r in selected], 'fresh language')
    for name, row in baseline['inputs'].items():
        c.identity(BASELINE / 'sources' / name, row['sha256'], row['bytes'])
        if name in ['tests/fixtures/m2/cases.json', 'compatibility/m2-class-lifecycle/manifest.json']:
            continue
        c.identity(ROOT / name, row['sha256'], row['bytes'])
    previous_language = json.loads(old_archive('language', ['report.json'])['report.json'])
    c.exact_ids(previous_language['results'], [r['id'] for r in original], 'original language')
    original_rows = language['results'][:len(original)]
    c.require([(r['id'], r['status']) for r in original_rows] ==
              [(r['id'], r['status']) for r in previous_language['results']], 'original selected outcomes changed')
    # Every originally passing case retains the identical complete channels;
    # known Java failures stay nonpasses with their original archives retained.
    for row, previous in zip(original_rows, previous_language['results']):
        if previous['status'] == 'pass':
            for engine in ['java', 'rust']:
                for channel in ['stdout', 'stderr']:
                    c.require(row[engine][channel + '_sha256'] == previous[engine][channel + '_sha256'],
                              'original passing raw bytes changed: ' + row['id'])
    prior_dir = BASE / 'prior-selection-stage15-final'
    if (prior_dir / 'report.json').is_file():
        prior = c.load(prior_dir / 'report.json')
        prior_inventory = c.load(prior_dir / 'evidence-sha256.json')
        observed = {p.relative_to(prior_dir).as_posix() for p in prior_dir.rglob('*')
                    if p.is_file() and p.name != 'evidence-sha256.json'}
        c.require(observed == set(prior_inventory), 'prior replay evidence coverage differs')
        for name, digest in prior_inventory.items():
            c.identity(prior_dir / name, digest)
        c.exact_ids(prior['results'], [r['id'] for r in original], 'prior replay')
        c.require(c.load(prior_dir / 'original-selection.json')['cases'] == original, 'prior replay definitions differ')
        candidate = c.load(prior_dir / 'candidate.json')
        c.identity(prior_dir / 'artifacts/language_probe', candidate['sha256'])
        build = candidate['build_provenance']
        c.require(build['source_binding'] == 'recorded-build' and build['source_stability'] and
                  build['source_sha256_before'] == build['source_sha256_after'] and
                  build['build']['exit_code'] == 0 and build['build']['timed_out'] is False and
                  build['candidate_sha256'] == build['frozen_sha256'] == candidate['sha256'],
                  'prior candidate recorded-build provenance differs')
        baseline_metadata = c.load(prior_dir / 'baseline.json')
        c.require(baseline_metadata['report_sha256'] == hashlib.sha256(old_archive('language', ['report.json'])['report.json']).hexdigest(),
                  'prior replay Java baseline differs from sealed original')
        baseline_dir = Path(baseline_metadata['path'])
        for row, previous, case in zip(prior['results'], previous_language['results'], original):
            folder, baseline_folder = prior_dir / 'cases' / row['id'], baseline_dir / 'cases' / row['id']
            c.require(c.load(folder / 'rust.process.json') == row['rust'], 'prior process metadata differs')
            c.identity(folder / 'input.pkl', row['input_sha256'])
            c.identity(folder / 'input.pkl', previous_language['source_sha256'][case['input']])
            captures = []
            for engine, process, directory in [('java', previous['java'], baseline_folder), ('rust', row['rust'], folder)]:
                for channel in ['stdout', 'stderr']:
                    path = directory / (engine + '.' + channel + '.bin'); c.identity(path, process[channel + '_sha256']); captures.append(path.read_bytes())
            outcome_path = baseline_folder / 'java.outcome.bin'; c.identity(outcome_path, previous['java']['outcome_sha256'])
            status = language_tool.status(case, previous['java'], row['rust'], *captures, outcome_path.read_bytes())
            c.require(status == row['status'] == previous['status'], 'prior replay raw verdict changed')
        c.require(prior['status_counts'] == dict(Counter(r['status'] for r in prior['results'])), 'prior replay count differs')
        data['prior'] = prior
    classes = data['classes']
    c.require(class_tool.contract_passes(classes), 'class selected contract failed')
    manifest = c.load(directories['classes'] / 'sources/compatibility/m2-class-lifecycle/manifest.json')
    old_manifest = c.load(BASELINE / 'class-manifest.json')
    c.require(len(old_manifest['sequences']) == baseline['sequence_count'] and
              manifest['sequences'][:baseline['sequence_count']] == old_manifest['sequences'], 'original sequence prefix changed')
    c.require(classes['repetitions'] == baseline['repetitions'], 'sequence repetitions changed')
    previous_classes = json.loads(old_archive('class-lifecycle', ['report.json'])['report.json'])
    prior_rows = classes['cases'][:len(previous_classes['cases'])]
    c.require([(r['id'], r['repetition']) for r in prior_rows] ==
              [(r['id'], r['repetition']) for r in previous_classes['cases']], 'original sequence row order changed')
    old_calls = 0
    for row, previous in zip(prior_rows, previous_classes['cases']):
        c.require(row['observations']['comparisons'] == previous['observations']['comparisons'], 'original class comparison changed')
        for engine in ['java', 'rust']:
            c.require(row['observations']['processes'][engine]['calls'] == previous['observations']['processes'][engine]['calls'],
                      'original class full raw capture identities changed')
        old_calls += len(row['observations']['comparisons'])
    c.require(old_calls == baseline['calls_per_repetition'] * baseline['repetitions'], 'original class call accounting differs')
    calls = [r for row in classes['cases'] for r in row['observations']['comparisons']]
    data['class_counts'] = dict(unique_sequences=len(manifest['sequences']), sequence_executions=len(classes['cases']),
        original_sequences=baseline['sequence_count'], added_sequences=len(manifest['sequences']) - baseline['sequence_count'],
        original_call_comparisons=old_calls, added_call_comparisons=len(calls) - old_calls,
        call_comparisons=len(calls), passing_calls=sum(r['status'] == 'pass' for r in calls),
        original_definitions_order_and_raw_bytes_preserved=True)
    c.DIRECTORIES['platforms'] = directories['platforms']
    data['platform_audit'] = c.platform_claims(data['platforms'], platform_tool)
    c.require(data['platforms']['source_stability'] and platform_tool.contract_matches(data['platforms']['comparisons']), 'platform architecture/source-stability contract failed')
    c.require(data['platforms']['compatibility_status'] == 'fail' and data['platforms']['experiment_contract_status'] == 'pass',
              'platform known failures relabeled')
    for name, digest in data['platforms']['artifacts'].items():
        c.identity(directories['platforms'] / name, digest)
    runtime = data['runtime']
    for row in runtime['identities']:
        c.identity(Path(row.get('snapshot', row['path'])), row['sha256'], row.get('bytes'))
        if 'snapshot' in row:
            c.identity(Path(row['path']), row['sha256'], row.get('bytes'))
    c.require([r['id'] for r in runtime['cases']] == list(runtime_tool.SUCCESS_CASES + runtime_tool.ERROR_CASES), 'runtime coverage differs')
    runtime_counts = Counter()
    mismatch_ids = []
    for row in runtime['cases']:
        java, rust = c.raw_process(row['java']), c.raw_process(row['rust'])
        c.require(row['raw_equal'] == (java == rust), 'runtime equality differs from raw')
        expected = 'bounded-value-bytes-match' if row['id'] in runtime_tool.SUCCESS_CASES else (
            'diagnostic-bytes-match' if java == rust else 'diagnostic-byte-mismatch')
        c.require(row['status'] == expected, 'runtime status differs')
        if expected == 'bounded-value-bytes-match':
            c.require(java == rust and java[0] == 0 and not java[2], 'runtime value failed')
        else:
            c.require(java[0] == rust[0] == 1, 'runtime error outcomes differ')
            if java != rust:
                c.require(row['id'] == 'forcing-cycle', 'new runtime diagnostic mismatch')
                mismatch_ids.append(row['id'])
        runtime_counts[expected] += 1
    c.require(mismatch_ids == ['forcing-cycle'], 'runtime known diagnostic mismatch inventory changed')
    data['regression_counts'] = dict(frontend_raw_matches=sum(r['passed'] for r in data['frontend']['results']),
        runtime_value_matches=runtime_counts['bounded-value-bytes-match'],
        runtime_diagnostic_matches=runtime_counts['diagnostic-bytes-match'],
        runtime_diagnostic_mismatches=runtime_counts['diagnostic-byte-mismatch'],
        runtime_known_diagnostic_mismatch_ids=mismatch_ids,
        lifecycle_protocol_matches=sum(r['observations']['protocol_raw_equal'] for r in data['lifecycle']['cases']),
        lifecycle_full_diagnostic_mismatches=sum(not e['raw_equal'] for r in data['lifecycle']['cases'] for e in r['observations']['diagnostics']))
    for name, path, digest in source_rows(directories, data):
        c.identity(path, digest)
        c.identity(ROOT / name, digest)
    data['selection_counts'] = dict(selected=len(selected), original_selected=len(original), added_selected=len(selected) - len(original),
        relations=len(language['metamorphic_results']), original_definitions_preserved=True,
        original_input_bytes_preserved=True, original_passing_raw_bytes_preserved=True,
        original_known_failures_preserved_separately=True, exact_result_order=True,
        frozen_selection_sha256=c.sha(directories['language'] / 'sources/tests/fixtures/m2/cases.json'),
        baseline_metadata_sha256=c.sha(BASELINE / 'baseline.json'))
    return data


def bind_sources(commit, directories, data, destination):
    """Read exact Git blobs in batches, resolving pinned submodule gitlinks."""
    c.require(len(commit) == 40 and all(ch in '0123456789abcdef' for ch in commit), 'full implementation SHA required')
    destination.mkdir(exist_ok=False)
    git_commands = destination / 'git-commands'
    git_commands.mkdir()
    captures = []
    def run_git(arguments, repository, payload=None):
        directory = git_commands / str(len(captures))
        directory.mkdir()
        command = ['git', *arguments]
        result = subprocess.run(command, cwd=repository, input=payload, capture_output=True, timeout=60)
        row = dict(command=command, cwd=str(repository), exit_code=result.returncode)
        for channel in ['stdout', 'stderr']:
            path = directory / (channel + '.bin'); path.write_bytes(getattr(result, channel))
            row[channel + '_sha256'] = c.sha(path)
        if payload is not None:
            (directory / 'stdin.bin').write_bytes(payload)
            row['stdin_sha256'] = c.sha(directory / 'stdin.bin')
        c.write_new(directory / 'process.json', row)
        captures.append(row)
        c.require(result.returncode == 0, 'Git source proof command failed; raw captures retained')
        return result.stdout
    def git(*args, repository=ROOT):
        return run_git(args, repository)
    c.require(git('rev-parse', commit + '^{commit}').decode().strip() == commit, 'commit differs')
    rows = list(source_rows(directories, data))
    unique = {name: path for name, path, _ in rows}
    groups = {}
    for name in unique:
        repo, spec = ROOT, commit + ':' + name
        for prefix in ['external/pkl/', 'external/pkl-pantry/']:
            if name.startswith(prefix):
                repo = ROOT / prefix.rstrip('/')
                revision = git('rev-parse', commit + ':' + prefix.rstrip('/')).decode().strip()
                spec = revision + ':' + name[len(prefix):]
        groups.setdefault(repo, []).append((name, spec))
    committed = {}
    for repo, group in groups.items():
        result = run_git(['cat-file', '--batch'], repo, ('\n'.join(spec for _, spec in group) + '\n').encode())
        position = 0
        for name, spec in group:
            end = result.index(b'\n', position)
            fields = result[position:end].split()
            c.require(len(fields) == 3 and fields[1] == b'blob', 'missing Git blob ' + spec)
            size = int(fields[2]); committed[name] = result[end + 1:end + 1 + size]
            position = end + size + 2
        c.require(position == len(result), 'unexpected Git batch payload')
    checks = []
    for name, path, digest in rows:
        payload = path.read_bytes()
        c.require(payload == committed[name] and hashlib.sha256(payload).hexdigest() == digest, 'source differs from exact commit: ' + name)
        checks.append(dict(source=name, snapshot=path.relative_to(ROOT).as_posix(), sha256=digest))
    for name, payload in committed.items():
        path = destination / 'implementation-sources' / name
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(payload)
    result = dict(implementation_commit=commit, source_snapshot_copies=len(rows), unique_source_files=len(unique),
        matched_exact_git_commit=True, pinned_submodule_blobs=True, source_checks=checks,
        source_reports={name: dict(path=str(path / 'report.json'), sha256=c.sha(path / 'report.json')) for name, path in directories.items()},
        method='Every full captured source byte string equals exact implementation Git bytes; submodule sources resolve through that commit gitlinks. Deduplicated exact copies retained.',
        captured_binaries_executed=False, git_command_captures=len(captures),
        validation_source_binding='Validation archive preserves raw command captures only; it does not add acquisition-time source snapshots. Other final suites retain full source snapshots.')
    c.write_new(destination / 'source-verification.json', result)
    for name in ['package_stage15_final.py', 'stage15_package_common.py']:
        shutil.copyfile(BASE / name, destination / name)
    for name in ['stage15_partial_readiness.py', 'stage15-partial-readiness.json',
                 'stage15_review_fixture_delta.py', 'stage15-fixture-delta-review.json',
                 'stage15-drafts-and-review.json', 'stage15-readme-review.json']:
        if (BASE / name).is_file():
            shutil.copyfile(BASE / name, destination / name)
    command_dirs = ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle', 'class-lifecycle', 'prior-selection', 'stage15-partial-readiness']
    for name in command_dirs:
        source = BASE / (name + '-command-final' if name == 'stage15-partial-readiness' else name + '-stage15-command-final')
        if not source.is_dir():
            continue
        for process_path in source.glob('*process.json'):
            row = c.load(process_path)
            c.require(row['exit_code'] == 0 and row.get('timed_out') is False, 'final acquisition command failed')
            prefix = process_path.name.removesuffix('process.json')
            for channel in ['stdout', 'stderr']:
                c.identity(source / (prefix + channel + '.bin'), row[channel + '_sha256'])
        shutil.copytree(source, destination / 'commands' / name)
    c.write_new(destination / 'packaging-invocation.json', dict(command=[sys.executable, *sys.argv], cwd=str(ROOT),
        implementation_commit=commit, helper_sha256={name:c.sha(BASE / name) for name in ['package_stage15_final.py','stage15_package_common.py']},
        scope='Current sealing invocation; wrapper stdout/stderr/process record is retained separately after this process exits.'))
    return result


def archive(source, name):
    path = REPORTS / (name + '-stage15-final-evidence.tar.gz')
    c.require(not path.exists(), 'refusing existing archive')
    sys.path.insert(0, str(ROOT / 'tools'))
    import evidence
    # create() verifies the completed archive once; no redundant verification.
    evidence.create(source, path, ['build/*', '__pycache__/*', '*/__pycache__/*'])
    with tarfile.open(path) as stream:
        count = len(stream.getmembers())
    return dict(path=path.relative_to(ROOT).as_posix(), sha256=c.sha(path), bytes=path.stat().st_size,
                files_including_inventory=count, inventory_verified=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-ready', action='store_true')
    parser.add_argument('--commit')
    for name in ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle', 'classes']:
        parser.add_argument('--' + name, type=Path, default=BASE / (('class-lifecycle' if name == 'classes' else name) + '-stage15-final'))
    args = parser.parse_args()
    directories = {name: getattr(args, name).resolve() for name in ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle', 'classes']}
    data = inspect(directories)
    claims = dict(status='pass', captured_binaries_executed=False, selection=data['selection_counts'],
        class_sequences=data['class_counts'], platforms=data['platform_audit'], regressions=data['regression_counts'])
    if args.check_ready:
        print(json.dumps(dict(claims, validation={k: data['validation'][k] for k in ['rust_passed','rust_intentionally_ignored','python_passed']}), sort_keys=True)); return
    c.require(args.commit, '--commit is required to seal exact implementation evidence')
    names = ['language', 'validation', 'platforms', 'gates', 'regressions', 'class-lifecycle', 'source']
    outputs = [REPORTS / (name + '-stage15-final-evidence.tar.gz') for name in names]
    outputs += [REPORTS / 'stage15-final-summary.json', REPORTS / 'validation-stage15-final.json']
    generated = {name: BASE / (name + '-stage15-final-evidence') for name in ['gates', 'regressions', 'source']}
    c.require(not any(p.exists() for p in [*outputs, *generated.values()]), 'refusing existing final output')
    binding = bind_sources(args.commit, directories, data, generated['source'])
    gates = []
    generated['gates'].mkdir()
    for name, expected in [('report', 0), ('development', 0), ('subset', 1), ('full', 1)]:
        command = [sys.executable, 'tools/m2_language.py', '--verify-' + name, str(directories['language'])]
        process = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=120)
        row = dict(gate=name, command=command, exit_code=process.returncode, expected_exit_code=expected)
        for channel in ['stdout', 'stderr']:
            path = generated['gates'] / (name + '.' + channel + '.bin'); path.write_bytes(getattr(process, channel))
            row[channel + '_sha256'] = c.sha(path)
        gates.append(row); c.require(process.returncode == expected, 'unexpected raw gate status: ' + name)
    c.write_new(generated['gates'] / 'report.json', dict(scope='Integrity/development pass; strict selected/full failures preserved.', rows=gates))
    generated['regressions'].mkdir()
    for name in ['frontend', 'runtime', 'lifecycle']:
        shutil.copytree(directories[name], generated['regressions'] / name, ignore=shutil.ignore_patterns('build', '__pycache__'))
    if 'prior' in data:
        shutil.copytree(BASE / 'prior-selection-stage15-final', generated['regressions'] / 'prior', ignore=shutil.ignore_patterns('build', '__pycache__'))
    if (BASE / 'stage15-exploration-summary-final.json').is_file():
        shutil.copyfile(BASE / 'stage15-exploration-summary-final.json', generated['regressions'] / 'stage15-exploration-summary-final.json')
    for name in ['stage15_review_fixture_delta.py', 'stage15-fixture-delta-review.json']:
        if (BASE / name).is_file():
            shutil.copyfile(BASE / name, generated['regressions'] / name)
    shutil.copytree(BASELINE, generated['regressions'] / 'immutable-stage15-baseline')
    c.write_new(generated['regressions'] / 'raw-claims-audit.json', claims)
    sources = dict(language=directories['language'], validation=directories['validation'], platforms=directories['platforms'],
                   **{'class-lifecycle':directories['classes']}, **generated)
    archives = {name: archive(sources[name], name) for name in names}
    language, platforms = data['language'], data['platforms']
    summary = dict(schema_version=1, implementation_commit=args.commit,
        scope='Stage15 bounded recursive constraint timing and generic class erased argument semantics; local macOS native/Wasm/Node/browser evidence. Full M2/API/performance completion remains open.',
        full_m2_complete=False, remote_ci_required=False, captured_binaries_executed=False,
        unavailable_platform_execution=['Linux', 'Windows'],
        source_to_commit_binding='All final captured source copies equal exact implementation Git bytes; build identities and retained raw outcomes remain separate evidence.',
        implementation_source_verification={k:v for k,v in binding.items() if k not in ['source_checks', 'source_reports']},
        language={k:language[k] for k in ['selected_count','status_counts','source_stability','artifact_stability','candidate','inventory_counts']},
        class_lifecycle=dict(data['class_counts'], compatibility_complete=False, unexecuted_groups=data['classes']['unexecuted_groups'], evidence=archives['class-lifecycle']),
        platforms={k:platforms[k] for k in ['total','oracle_passed','shared_engine_passed','compatibility_status','known_gaps','experiment_contract_status','source_stability']},
        regressions=data['regression_counts'], validation={k:data['validation'][k] for k in ['rust_passed','rust_intentionally_ignored','python_passed']},
        final_claims_audit=claims, gates=gates, archives=archives, source_report_identities=binding['source_reports'],
        reviewed_mappings=dict(count=len(c.load(ROOT / 'compatibility/m2-mappings.json')['requirements']), scope='Partial reviewed mappings; strict full failures retained.'),
        original_evidence_preserved=dict(stage14_summary='reports/m2/stage14-final-summary.json', stage14_ci_blocked='reports/m2/ci-stage14-summary.json',
            local_acceptance='reports/m2/local-acceptance-stage14.json', no_original_archive_modified=True))
    summary['implementation_source_verification']['evidence'] = archives['source']
    summary['language'].update(data['selection_counts'], source_snapshot_count=len(language['source_sha256']),
        metamorphic_relations=len(language['metamorphic_results']), metamorphic_statuses=[r['status'] for r in language['metamorphic_results']],
        full_gate_failure_reasons=len(language['full_gate_failures']),
        known_failures=[dict(id=r['id'], status=r['status']) for r in language['results'] if r['status'] != 'pass'])
    summary['platforms'].update(node_scenarios=len(platforms['execution']['nodeChecks']), browser_scenarios=len(platforms['execution']['browserChecks']))
    if 'prior' in data:
        summary['prior_selection_replay'] = dict(count=len(data['prior']['results']), status_counts=data['prior']['status_counts'],
            exact_original_ids_order_input_bytes_and_raw_verdicts=True,
            scope='Postfreeze Stage15 recorded-build candidate against retained original1472 complete Stage14 Java bytes. Fresh full Java acquisition remains separate.')
    if (BASE / 'stage15-exploration-summary-final.json').is_file():
        exploration = c.load(BASE / 'stage15-exploration-summary-final.json')
        path = REPORTS / 'exploration-stage15-evidence.tar.gz'
        c.identity(path, '5c49edd4105cf5a9a68c8cee95e6696b87a74af703a1ca4769954ce2913f734a', 10869925)
        summary['exploration'] = dict(archive=dict(path=path.relative_to(ROOT).as_posix(), sha256=c.sha(path), bytes=path.stat().st_size,
            inventory_verified_by_acquisition_owner=True),
            selected_replay=exploration['selected_release_replay'], observations=exploration['final_discovery_replay'],
            scope='Exploratory observations and five required open witnesses remain separate from selected compatibility counts; failed histories and originals are preserved.')
    if (BASE / 'stage15-fixture-delta-review.json').is_file():
        summary['fixture_delta_review'] = dict(report='stage15-fixture-delta-review.json',
            sha256=c.sha(BASE / 'stage15-fixture-delta-review.json'),
            scope='Independent acquisition-owner review retained separately in final regression/source archives; original exploration archive unchanged.')
    c.write_new(REPORTS / 'validation-stage15-final.json', data['validation'])
    c.write_new(REPORTS / 'stage15-final-summary.json', summary)
    print(json.dumps(dict(summary='reports/m2/stage15-final-summary.json', language=language['status_counts'],
        validation=summary['validation'], class_counts=data['class_counts'], source_copies=binding['source_snapshot_copies'],
        source_paths=binding['unique_source_files'], archives=archives), sort_keys=True))


if __name__ == '__main__':
    main()
