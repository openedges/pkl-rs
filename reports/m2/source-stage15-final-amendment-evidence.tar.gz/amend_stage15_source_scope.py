"""Preserve original seals and clarify measured source proof plus helper history."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
import tarfile

sys.dont_write_bytecode = True
import stage15_package_common as c

ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
REPORTS = ROOT / 'reports/m2'
sys.path.insert(0, str(ROOT / 'tools'))
import evidence


def main():
    destination = BASE / 'stage15-source-scope-amendment'
    destination.mkdir(exist_ok=False)
    summary_path = REPORTS / 'stage15-final-summary.json'
    original_summary = summary_path.read_bytes()
    summary = json.loads(original_summary)
    for row in summary['archives'].values():
        c.identity(ROOT / row['path'], row['sha256'], row['bytes'])
    source_record = summary['archives']['source']
    with tarfile.open(ROOT / source_record['path']) as stream:
        proof = json.load(stream.extractfile('source-verification.json'))
        external = [r for r in proof['source_checks'] if r['source'].startswith('external/')]
        commands = [r for r in stream.getmembers() if r.name.startswith('git-commands/') and r.name.endswith('/process.json')]
        for member in commands:
            row = json.load(stream.extractfile(member))
            prefix = member.name.removesuffix('process.json')
            c.require(row['exit_code'] == 0, 'retained Git proof command failed')
            for channel in ['stdout', 'stderr', 'stdin']:
                if channel + '_sha256' in row:
                    data = stream.extractfile(prefix + channel + '.bin').read()
                    c.require(hashlib.sha256(data).hexdigest() == row[channel + '_sha256'], 'retained Git capture differs')
    c.require(not external and len(commands) == 2, 'unexpected source proof coverage')
    original = c.load(BASE / 'stage15-baseline-contract/sources/compatibility/m2-language.json')
    current = c.load(BASE / 'language-stage15-final/sources/compatibility/m2-language.json')
    old_requirements, new_requirements = original['requirements'], current['requirements']
    c.require([r['id'] for r in old_requirements] == [r['id'] for r in new_requirements], 'requirement IDs/order changed')
    for old, new in zip(old_requirements, new_requirements):
        ignored = {'implementation', 'tests', 'reviewed_mapping'}
        c.require({k:v for k,v in old.items() if k not in ignored} == {k:v for k,v in new.items() if k not in ignored},
                  'original requirement definition changed')
        c.require(old['implementation']['state'] == new['implementation']['state'], 'implementation state relaxed')
        old_links = {(r['path'],r['symbol']) for r in old['implementation']['links']}
        new_links = {(r['path'],r['symbol']) for r in new['implementation']['links']}
        c.require(old_links <= new_links, 'old implementation link removed')
        c.require(old['tests']['state'] == new['tests']['state'] and
                  set(old['tests']['case_ids']) <= set(new['tests']['case_ids']), 'old test links/state relaxed')
        if 'reviewed_mapping' in old:
            c.require(old['reviewed_mapping']['source'] == new['reviewed_mapping']['source'] and
                      old['reviewed_mapping']['remaining'] == new['reviewed_mapping']['remaining'], 'remaining required scope changed')
    old_cases = original['cases']; old_ids = {r['id'] for r in old_cases}
    c.require([r for r in current['cases'] if r['id'] in old_ids] == old_cases, 'old case definitions/order changed')
    preservation = dict(status='pass', original_requirement_count=len(old_requirements), original_case_count=len(old_cases),
        ids_order_definitions_states_implementation_links_and_test_links_preserved=True,
        reviewed_mapping_remaining_scope_preserved=True,
        legitimate_changes='New case/test links and appended reviewed scope are additive; implementation link source hashes reflect the new implementation.',
        original_inventory_sha256=c.sha(BASE / 'stage15-baseline-contract/sources/compatibility/m2-language.json'),
        current_inventory_sha256=c.sha(BASE / 'language-stage15-final/sources/compatibility/m2-language.json'),
        captured_binaries_executed=False)
    c.write_new(destination / 'requirements-preservation.json', preservation)
    correction = dict(schema_version=1, implementation_commit=summary['implementation_commit'],
        source_snapshot_copies=proof['source_snapshot_copies'], unique_source_files=proof['unique_source_files'],
        external_source_snapshot_copies=0, retained_git_proof_commands=len(commands),
        upstream_source_blobs_verified=False,
        original_sealed_flag=proof['pinned_submodule_blobs'],
        correction='The sealed pinned_submodule_blobs:true flag was an unconditional helper flag and is vacuous for this capture. It is not positive evidence of upstream source-blob verification.',
        actual_scope='All2091 captured project source copies across1725 project paths match exact implementation Git blobs. No external source blob appears in the source-copy inventory.',
        separate_reference_evidence='Pinned reference checkout/gitlink checks are retained in validation cargo xtask verify; pinned source/artifact/JDK provenance is retained in oracle metadata. Those are separate from captured upstream source-blob proof.',
        original_source_archive=source_record, originals_unchanged=True, new_acquisition=False,
        captured_binaries_executed=False)
    c.write_new(destination / 'source-scope-correction.json', correction)
    for name in ['package-stage15-command-final', 'package-stage15-command-final-02']:
        shutil.copytree(BASE / name, destination / 'helper-history' / name)
    (destination / 'original-stage15-final-summary.json').write_bytes(original_summary)
    shutil.copyfile(BASE / 'package_stage15_final.py', destination / 'package_stage15_final-executed-v2.py')
    # Future helper wording is retained as an amendment; the sealed executed
    # helper and its original source-verification metadata remain unchanged.
    amended = (BASE / 'package_stage15_final.py').read_text()
    amended = amended.replace('matched_exact_git_commit=True, pinned_submodule_blobs=True, source_checks=checks,',
        "matched_exact_git_commit=True, pinned_submodule_blobs=any(name.startswith('external/') for name,_,_ in rows), external_source_snapshot_copies=sum(name.startswith('external/') for name,_,_ in rows), source_checks=checks,")
    amended = amended.replace('Every full captured source byte string equals exact implementation Git bytes; submodule sources resolve through that commit gitlinks. Deduplicated exact copies retained.',
        'Every captured project source byte string equals exact implementation Git bytes. Upstream blob proof exists only when external_source_snapshot_copies is positive. Reference pin validation remains separate.')
    (destination / 'package_stage15_final-amended.py').write_text(amended)
    shutil.copyfile(Path(__file__), destination / Path(__file__).name)
    narrative = dict(first_attempt=dict(path='helper-history/package-stage15-command-final', exit_code=1,
        reason='Guard erroneously compared regenerated M2 inventory bytes to the old inventory. It stopped before final output creation; no implementation or compatibility test failed.'),
        second_attempt=dict(path='helper-history/package-stage15-command-final-02', exit_code=0,
        correction='Original Pkl fixture bytes remain exact; regenerated inventory preserves all2472 old case objects/order. This amendment also independently rederives all474 old requirement definitions, states, implementation links and existing test links.'),
        acquisition_rerun=False, original_archives_unchanged=True)
    c.write_new(destination / 'helper-preparation-history.json', narrative)
    archive = REPORTS / 'source-stage15-final-amendment-evidence.tar.gz'
    c.require(not archive.exists(), 'refusing existing amendment archive')
    evidence.create(destination, archive, [])
    metadata = dict(path=archive.relative_to(ROOT).as_posix(), sha256=c.sha(archive), bytes=archive.stat().st_size,
                    inventory_verified=True, scope='Source coverage correction, independently rederived requirements preservation, both executed helper versions and original guard-failure/process evidence. No acquisition rerun or original archive rewrite.')
    final = json.loads(original_summary)
    final['implementation_source_verification'].update(pinned_submodule_blobs=False, external_source_snapshot_copies=0,
        upstream_source_blobs_verified=False,
        method='Every captured project source byte string equals exact implementation Git bytes. No upstream source blobs were captured; reference pins were verified separately by retained xtask/oracle evidence.')
    final['source_provenance_amendment'] = dict(evidence=metadata, correction=correction,
        requirements_preservation=preservation, helper_preparation_history=narrative)
    c.require(summary_path.read_bytes() == original_summary, 'summary changed concurrently; amendment archive preserved')
    summary_path.write_text(json.dumps(final, indent=2, sort_keys=True) + '\n')
    print(json.dumps(dict(archive=metadata, original_archives_unchanged=True,
        source_snapshot_copies=proof['source_snapshot_copies'], unique_source_files=proof['unique_source_files'],
        external_source_snapshot_copies=0, original_requirements_preserved=len(old_requirements)), sort_keys=True))


if __name__ == '__main__':
    main()
