"""Finite unsealed publication metadata extension; no archive or guest execution."""
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import stat

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
OUT = Path(__file__).parent
BASE = ROOT / 'target/m2/stage122-publication-catalog-prep-02'
PROTECTED = 'stage65-b-native-regressions-evidence.tar.gz.partial'
DEFERRED = (
)
SEED_FILES = [
    'stage122-m1-command-01/report.json',
    'stage122-m1-command-03/report.json',
    'stage122-m1-command-03/source-admission.json',
    'stage122-m1-command-03/preparation.json',
    'stage122-m1-command-03/run.py',
    'stage122-m1-command-03/seal_sources.py',
    'stage122-m1-command-03/launch-context.json',
    'stage122-m1-command-03/helper-inputs.json',
    'stage122-m1-command-03/inputs.before.json',
    'stage122-m1-command-03/inputs.after.json',
    'stage122-m1-command-03/experiment/report.json',
    'stage122-m1-independent-readback-01/report.json',
    'stage122-composed-lossless-portable-build-01/report.json',
    'stage122-composed-lossless-portable-build-04/report.json',
    'stage122-composed-lossless-portable-build-05/report.json',
    'stage122-composed-lossless-portable-build-05/admitted-inputs.json',
    'stage122-composed-lossless-portable-build-05/materialized-test-sources.json',
    'stage122-composed-lossless-portable-build-05/product-admission.json',
    'stage122-composed-lossless-portable-build-05/wasm-build-admission.json',
    'stage122-composed-lossless-portable-build-05/wasm-build-dependency-source-admission.json',
    'stage122-portable-products-independent-readback-02/report.json',
    'stage122-portable-products-independent-readback-03/report.json',
    'stage122-portable-products-independent-readback-04/report.json',
    'stage122-portable-products-independent-readback-05/report.json',
    'stage122-composed-lossless-portable-capture-01/report.json',
    'stage122-composed-lossless-portable-capture-02/report.json',
    'stage122-composed-lossless-portable-capture-03/report.json',
    'stage122-portable-napi-partial-independent-readback-01/report.json',
    'stage122-portable-napi-partial-independent-readback-01/new-portable-mismatches.json',
    'stage122-portable-napi-partial-independent-readback-01/glob-per-case.json',
    'stage122-portable-napi-partial-independent-readback-01/transport24-readback.json',
    'stage122-portable-napi-partial-independent-readback-01/full744-readback.json',
    'stage122-portable-generic-url-independent-source-review-01/report.json',
    'stage122-native-transport-check-01/report.json',
    'stage122-native-transport-check-01/admitted-inputs.json',
    'stage122-native-transport-check-01/materialized-sources.json',
    'stage122-native-transport-check-01/native-artifact-admission.json',
    'stage122-native-transport-independent-readback-01/report.json',
    'stage122-portable-native-source-independent-review-01/report.json',
    'stage122-workspace-replay-source-go-review-01/report.json',
    'stage122-workspace-replay-product-preflight-01/report.json',
    'stage122-core-freeze-02/runtime-and-bindings.json',
    'stage122-checks05-monitor-loss-01/report.json',
    'stage122-checks05-monitor-loss-01/processes-before.txt',
    'stage122-checks05-terminal-observer-prep-01/observe.py',
    'stage122-checks05-terminal-observer-01/report.json',
    'stage122-checks05-independent-terminal-qualification-02/report.json',
    'stage122-checks05-harness-qualification-independent-review-01/report.json',
    'stage122-canonical-checks-05/report.json',
    'stage122-canonical-checks-06/report.json',
    'stage122-canonical-checks-06/inputs.json',
    'stage122-canonical-checks-06/source-delta-from05.json',
    'stage122-workspace-aggregate-independent-readback-03/report.json',
    'stage122-workspace-aggregate-independent-readback-03/historical-source-identities.json',
    'stage122-workspace-aggregate-independent-readback-03/source-delta.json',
    'stage122-workspace-aggregate-independent-readback-03/verified-inputs.json',
    'stage122-workspace-aggregate-independent-readback-03/target-union.json',
    'stage122-canonical-final-test-driver-application-01/report.json',
    'stage122-historical-source-materialization-01/report.json',
    'stage122-historical-source-materialization-02/report.json',
    'stage122-historical-stream-prefix-materialization-01/report.json',
    'stage122-historical-additional-restoration-requests-01/report.json',
    'stage122-full-ready-commands-01/report.json',
    'stage122-workspace-replay-qualification-01/report.json',
    'stage122-full-ready-native-01.json',
    'stage122-full-ready-modules-01/report.json',
    'stage122-full-ready-historical-01/report.json',
    'stage122-full-ready-jvm-01/report.json',
    'stage122-full-ready-scalars-01/report.json',
    'stage122-full-ready-readback-01/report.json',
    'stage122-full-ready-completed-cohorts-independent-readback-01/report.json',
    'stage122-full-ready-independent-readback-01/report.json',
    'stage122-full-ready-independent-readback-01/full-gate-failures.json',
    'stage122-full-ready-independent-readback-01/acquisition-scope.json',
    'stage122-full-ready-independent-readback-01/transitions.json',
    'stage122-full-ready-independent-readback-prep-01/readiness.json',
    'stage122-full-ready-independent-readback-prep-01/actual-readback-seal.json',
    'stage122-portable-napi-glob03-independent-readback-01/report.json',
    'stage122-portable-napi-glob03-independent-readback-02/report.json',
    'stage122-portable-napi-glob03-independent-readback-03/report.json',
    'stage122-portable-napi-glob03-readback-prep-01/readback.py',
    'stage122-portable-napi-glob03-readback-prep-02/readback.py',
    'stage122-portable-napi-glob03-readback-prep-03/readback.py',
    'stage122-portable-napi-glob03-readback-prep-03/actual-readback-seal.json',
    'stage122-canonical-application-01/report.json',
    'stage122-canonical-application-01/admitted-copy-plan.json',
    'stage122-canonical-application-01/pre-format-rust.json',
    'stage122-canonical-application-01/post-format-rust.json',
    'stage122-canonical-application-01/formatted-runtime-and-bindings.json',
    'stage122-canonical-integration-prep-01/all-entries.json',
    'stage122-canonical-tests-migration-prep-01/copy-plan.json',
    'stage122-canonical-tests-migration-prep-03/copy-plan.json',
    'stage122-canonical-glob-frontend-repair-prep-01/copy-plan.json',
    'stage122-canonical-glob-frontend-repair-prep-01/report.json',
    'stage122-canonical-glob-frontend-repair-prep-01/seal.json',
    'stage122-canonical-resource-glob-repair-prep-01/copy-plan.json',
    'stage122-canonical-resource-glob-repair-prep-01/report.json',
    'stage122-canonical-unicode-diagnostic-repair-prep-01/copy-plan.json',
    'stage122-canonical-unicode-diagnostic-repair-prep-01/report.json',
    'stage122-canonical-diagnostic-output-application-01/report.json',
    'stage122-canonical-checks-05/inputs.json',
    'stage122-workspace-continuation-prep-01/run.py',
    'stage122-workspace-continuation-prep-01/cache-clone-report.json',
    'stage122-workspace-continuation-prep-01/cache-clone-inputs.json',
    'stage122-workspace-continuation-command-plan-01/commands.json',
    'stage122-canonical-checks-04/report.json',
    'stage122-test-repairs-independent-source-review-01/report.json',
    'stage122-continuation-sources-independent-review-01/report.json',
    'stage122-portable-capture-independent-source-review-01/report.json',
    'stage122-publication-docs-prep-03/README.draft.md',
    'stage122-publication-docs-prep-03/PLAN.snippet.md',
]
PREPS = [
    'stage122-workspace-replay-prep-03',
    'stage122-workspace-replay-prep-04',
    'stage122-composed-lossless-portable-capture-prep-02',
    'stage122-composed-lossless-portable-capture-prep-03',
    'stage122-native-transport-prep-01',
    'stage122-frame-policy-binding-source-prep-01',
    'stage122-composed-lossless-portable-capture-prep-04',
    'stage122-composed-lossless-portable-capture-prep-05',
    'stage122-portable-composed05-independent-readback-prep-01',
]
SEED_FILES.extend([
    'stage122-composed-lossless-portable-capture-04/report.json',
    'stage122-composed-lossless-portable-capture-05/report.json',
    'stage122-portable-chromium04-partial-independent-readback-01/report.json',
    'stage122-portable-chromium04-partial-readback-prep-01/readback.py',
    'stage122-portable-chromium04-readback-prep-01/readback.py',
    'stage122-chromium-large-listing-resource-audit-01/report.json',
    'stage122-portable05-independent-source-review-01/report.json',
    'stage122-portable-composed05-independent-readback-01/report.json',
    'stage122-composed-lossless-portable-capture-05/resource-experiment/report.json',
    'stage122-transport19-three-target-readback-01/report.json',
    'stage122-final-implementation-roster-01/report.json',
    'stage122-final-implementation-roster-01/implementation.json',
    'stage122-final-implementation-roster-02/report.json',
    'stage122-final-implementation-roster-02/implementation.json',
    'stage122-final-implementation-roster-independent-review-01/report.json',
    'stage122-final-implementation-roster-independent-review-01/nul-list-readback.json',
    'stage122-index-implementation-readback-01/report.json',
    'stage122-index-implementation-readback-01/source-bindings.json',
    'stage122-canonical-document-application-01/report.json',
    'stage122-archive-producer-prep-01/seal.json',
    'stage122-archive-independent-source-review-01/report.json',
])
SEED_TOP = ('readiness.json', 'seal.json', 'README.md', 'PLAN.md')
METADATA = re.compile(r'(report|readiness|seal|inputs?|sources?|origins?|manifest|pins|admission|qualification|materializ|reuse|product|recipe|lineage|authority|authorities|closure|fixture|bookend|dependency|dependencies|source-go|selection|cohort|accounting|control|preparation|context|scope|transport|process|runtime|observer|monitor|plan|format)', re.I)


def forbidden(path):
    return any(n == PROTECTED or n.endswith('.partial') or n.lower().startswith('stage86')
               or 'private8' in n.lower() for n in Path(path).parts)


def normalize(path):
    p = Path(path)
    if forbidden(p):
        return str(p)
    if p.is_absolute() and p.is_relative_to(ROOT):
        p = p.relative_to(ROOT)
    return str(p)


def pin(path):
    p = Path(path)
    if forbidden(p):
        raise ValueError('protected path rejected before metadata')
    p = p if p.is_absolute() else ROOT / p
    before = p.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError('metadata seed must be regular')
    body = p.read_bytes()
    after = p.lstat()
    if (before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise ValueError('metadata changed during read')
    return dict(path=normalize(p), bytes=len(body), mode=stat.S_IMODE(before.st_mode), sha256=hashlib.sha256(body).hexdigest())


def load_lines(name):
    return [json.loads(line) for line in (BASE / name).read_text().splitlines()]


def key(row):
    return row['path'], row['bytes'], row['sha256']


def emit(name, rows):
    (OUT / name).write_text(''.join(json.dumps(row, sort_keys=True) + '\n' for row in rows))


categories = {name: {key(row): row for row in load_lines(name + '.jsonl')}
              for name in ('paths', 'identity-only', 'prerequisites', 'canonical-source-aliases', 'unavailable')}
base_counts = {name: len(rows) for name, rows in categories.items()}
excluded = load_lines('excluded-before-metadata.jsonl')
base_variants = {row['path']: row for row in load_lines('historical-path-variants.jsonl')}
base_known = set().union(*(set(rows) for rows in categories.values()))
declared = collections.defaultdict(dict)
for rows in categories.values():
    for row in rows.values():
        declared[row['path']][(row['bytes'], row['sha256'])] = row
for path, row in base_variants.items():
    for variant in row['declared_variants']:
        declared[path][(variant['bytes'], variant['sha256'])] = variant

canonical = {}
for row in categories['identity-only'].values():
    if row['path'].startswith(('crates/', 'tools/', 'xtask/', 'tests/')):
        canonical.setdefault(row['path'], []).append(row)
for row in json.loads((ROOT / 'target/m2/stage122-core-freeze-02/runtime-and-bindings.json').read_text())['files']:
    canonical.setdefault(row['logical_path'], []).append(row)
deliverables = {normalize(row['path']): row for row in json.loads((ROOT / 'target/m2/stage122-composed-lossless-portable-capture-prep-03/actual-products.json').read_text())['products'].values()}

parsed = set()
queue = []
new_seeds = []
missing_seeds = []
metadata_reads = []
presence = []
deferred = []
classification_totals = collections.Counter()


def classify(row):
    name = row['path']
    p = Path(name)
    if forbidden(name):
        return 'excluded', 'protected name; excluded before metadata'
    if any(name.startswith(prefix) for prefix in DEFERRED):
        return 'deferred', 'active acquisition; terminal report/payload admission deferred'
    if p.is_absolute():
        return 'excluded', 'external installed/tool prerequisite identity only'
    if name == 'compatibility/m2-language.json' and row['sha256'] == '84d19bfbacc716fa1b7d04c2541b370556ca0d98b6318ae9e933c5184ef77829':
        return 'identity-only', 'historical predecessor_manifest_identity ancestry only; no Stage122 controller opens this body; mode unrecorded, body not selected or claimed available'
    if name.endswith(('.tar.gz', '.tgz', '.tar', '.zip', '.jar', '.gz', '.xz', '.zst')):
        return 'prerequisites', 'archive identity only; archive body never read'
    parts = p.parts
    if name in deliverables and row['sha256'] == deliverables[name]['sha256'] and row['bytes'] <= 32 * 1024**2:
        return 'paths', 'explicit current actual deliverable product exception; reusable compiler/dependency binaries omitted'
    if name == 'target/m2/stage122-native-transport-check-01/artifacts/native_transport' and row['bytes'] <= 32 * 1024**2:
        return 'paths', 'small actual Native transport driver; dependency bodies excluded'
    if name.startswith('target/m2/stage122-canonical-cargo-'):
        if name.endswith('.d') and any(p.name.startswith(n) for n in ('module_eval_probe', 'language_probe', 'jvm_snippet_probe')):
            return 'paths', 'exact current native product emitted dependency metadata'
        return 'identity-only', 'derived canonical Cargo clone member; retained lineage inventory authenticates inherited cache without copying its bodies'
    compiled_suffix = name.endswith(('.rlib', '.rmeta', '.o', '.a', '.dylib', '.so', '.node', '.wasm'))
    cargo_executable = ('target' in parts[2:] and '.fingerprint' not in parts
                        and (p.name == 'build-script-build' or p.name.startswith('build_script_build-') and not name.endswith('.d')
                             or row.get('mode', 0) & 0o111 and p.suffix not in ('.rs', '.json', '.d', '.py', '.sh', '.js', '.mjs')))
    if compiled_suffix or cargo_executable:
        return 'identity-only', 'compiled product/Cargo-cache body omitted; retain exact identity'
    if 'target' in parts[2:]:
        return 'paths', 'inspectable emitted dep-info/generated source/build metadata; Cargo subtree location does not omit evidence'
    if not name.startswith('target/m2/'):
        if name.startswith(('external/', 'vendor/')):
            return 'prerequisites', 'pinned upstream/vendor prerequisite; body not recopied'
        return 'identity-only', 'canonical source/fixture identity; bind final Git/source manifest once'
    stage = re.search(r'/stage(\d+)', name)
    if stage and int(stage.group(1)) < 122:
        return 'prerequisites', 'pinned prior authority; no old archive body read'
    return 'paths', 'declared finite raw/source/metadata payload'


inherited_cache_reclassified = []
for inherited_key, row in list(categories['paths'].items()):
    category, reason = classify(row)
    if category == 'identity-only' and ('target' in Path(row['path']).parts[2:]
            or row['path'].startswith('target/m2/stage122-canonical-cargo-')):
        migrated = dict(row, reason='inherited catalog02 reusable compiler/cache binary selection removed; retain exact identity/provenance only', classification_detail=reason)
        categories['identity-only'][inherited_key] = migrated
        categories['paths'].pop(inherited_key)
        inherited_cache_reclassified.append(migrated)


def add(record, owner, logical=None):
    if not isinstance(record.get('path'), str) or type(record.get('bytes')) is not int or not isinstance(record.get('sha256'), str):
        return
    row = {k: record[k] for k in ('path', 'bytes', 'sha256', 'mode') if k in record}
    row['path'] = normalize(row['path'])
    row['owners'] = [owner]
    category, reason = classify(row)
    classification_totals[category] += 1
    if category == 'excluded':
        excluded.append(dict(path=row['path'], owner=owner, identity={k: row[k] for k in ('bytes', 'sha256')}, reason=reason))
        return
    if category == 'deferred':
        deferred.append(dict(**row, reason=reason))
        return
    declared[row['path']].setdefault((row['bytes'], row['sha256']), row)
    if logical and category == 'paths' and key(row) not in base_known:
        matches = [r for r in canonical.get(logical, []) if r['bytes'] == row['bytes'] and r['sha256'] == row['sha256']]
        if matches and key(row) in categories['paths']:
            prior = categories['paths'].pop(key(row))
            prior.update(canonical_logical_path=logical, canonical_identity=dict(path=logical, **{k: matches[0][k] for k in ('bytes', 'sha256', 'mode') if k in matches[0]}), policy='omit duplicate snapshot body; bind final canonical source index', canonical_identity_provenance='declared source/freeze identity; final root source seal required')
            categories['canonical-source-aliases'][key(row)] = prior
    existing = [rows[key(row)] for rows in categories.values() if key(row) in rows]
    if existing:
        for old in existing:
            old['owners'] = sorted(set(old.get('owners', [])) | {owner})
        return
    if logical and category == 'paths':
        matches = [r for r in canonical.get(logical, []) if r['bytes'] == row['bytes'] and r['sha256'] == row['sha256']]
        if matches:
            category = 'canonical-source-aliases'
            row.update(canonical_logical_path=logical, canonical_identity=dict(path=logical, **{k: matches[0][k] for k in ('bytes', 'sha256', 'mode') if k in matches[0]}), policy='omit duplicate snapshot body; bind final canonical source index', canonical_identity_provenance='declared source/freeze identity; final root source seal required')
    if category != 'paths':
        row.setdefault('reason', reason)
    prior = categories[category].get(key(row))
    if prior:
        prior['owners'] = sorted(set(prior.get('owners', [])) | {owner})
        return
    categories[category][key(row)] = row
    if category == 'paths':
        p = ROOT / row['path']
        # No historical body is hashed here. Presence/mode/size only.
        try:
            s = p.lstat()
            ok = stat.S_ISREG(s.st_mode) and s.st_size == row['bytes'] and ('mode' not in row or stat.S_IMODE(s.st_mode) == row['mode'])
            presence.append(dict(path=row['path'], regular=stat.S_ISREG(s.st_mode), bytes=s.st_size, mode=stat.S_IMODE(s.st_mode), matches_declared_size_mode=ok))
            if not ok:
                categories['unavailable'][key(row)] = dict(**row, reason='current size/mode/nonregular differs; historical restoration or exact current variant required')
                categories['paths'].pop(key(row))
                return
        except FileNotFoundError:
            categories['unavailable'][key(row)] = dict(**row, reason='declared finite payload currently absent; restoration prerequisite required')
            categories['paths'].pop(key(row))
            return
        if p.suffix == '.json' and METADATA.search(p.name):
            queue.append(row)


def visit(value, owner):
    if isinstance(value, dict):
        logical = value.get('logical_path')
        for k, v in value.items():
            if isinstance(v, dict) and {'path', 'bytes', 'sha256'} <= set(v):
                add(v, owner, logical if k in ('snapshot', 'source', 'input', 'origin') else None)
        if {'path', 'bytes', 'sha256'} <= set(value):
            add(value, owner)
        for v in value.values():
            visit(v, owner)
    elif isinstance(value, list):
        for item in value:
            visit(item, owner)


seed_paths = ['target/m2/' + n for n in SEED_FILES]
seed_paths += ['target/m2/' + directory + '/' + name for directory in PREPS for name in SEED_TOP]
for name in seed_paths:
    if forbidden(name) or any(name.startswith(prefix) for prefix in DEFERRED):
        raise ValueError('invalid seed allowlist')
    try:
        row = pin(name)
    except FileNotFoundError:
        missing_seeds.append(dict(path=name, reason='optional finite seed unavailable; not admitted'))
        continue
    new_seeds.append(row)
    add(row, 'catalog03 explicit seed')
    if name.endswith('.json'):
        queue.append(row)

while queue:
    row = queue.pop(0)
    if key(row) in parsed:
        continue
    parsed.add(key(row))
    p = ROOT / row['path']
    actual = pin(p)
    if actual['bytes'] != row['bytes'] or actual['sha256'] != row['sha256']:
        categories['unavailable'][key(row)] = dict(**row, reason='metadata content differs from declared historical identity; not expanded')
        categories['paths'].pop(key(row), None)
        continue
    metadata_reads.append(actual)
    value = json.loads(p.read_bytes())
    visit(value, row['path'])

# Each newly selected declared raw path has one exact size/mode/current metadata
# observation. Payload content authentication remains the root archiver's job.
for rows in categories.values():
    for row in rows.values():
        row['owners'] = sorted(set(row.get('owners', [])))
mode_observations = []
for row in categories['paths'].values():
    if 'mode' not in row:
        path = ROOT / row['path']
        if forbidden(path):
            raise ValueError('protected mode source before metadata')
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode):
            raise ValueError('logical payload mode requires regular source')
        row['mode'] = stat.S_IMODE(info.st_mode)
        row['mode_provenance'] = 'current regular-file mode observed; acquisition content pin did not record mode'
        mode_observations.append(dict(path=row['path'], mode=row['mode'], bytes=info.st_size))
for row in categories['canonical-source-aliases'].values():
    if 'mode' not in row and 'mode' in row.get('canonical_identity', {}):
        row['mode'] = row['canonical_identity']['mode']
        row['mode_provenance'] = 'declared matching canonical source identity mode'

objects = {}
for row in categories['paths'].values():
    objects.setdefault((row['sha256'], row['bytes']), dict(sha256=row['sha256'], bytes=row['bytes'], member='objects/' + row['sha256'], source=row['path']))
variants = []
for path, choices in sorted(declared.items()):
    if len(choices) > 1 or path in base_variants:
        variants.append(dict(path=path, declared_variants=sorted(choices.values(), key=lambda r: (r['sha256'], r['bytes'])), status='unresolved historical identities retained; root must choose exact payload or explicit restoration prerequisite'))
assert len(variants) >= len(base_variants)
assert not any(forbidden(r['path']) for r in categories['paths'].values())
assert not any(any(r['path'].startswith(prefix) for prefix in DEFERRED) for r in categories['paths'].values())
assert not any(classify(r)[0] == 'identity-only' and 'target' in Path(r['path']).parts[2:] for r in categories['paths'].values())

for name, rows in categories.items():
    emit(name + '.jsonl', sorted(rows.values(), key=lambda r: (r['path'], r['sha256'])))
emit('objects.jsonl', sorted(objects.values(), key=lambda r: r['sha256']))
emit('historical-path-variants.jsonl', variants)
emit('excluded-before-metadata.jsonl', excluded)
emit('new-presence-size-mode.jsonl', presence)
emit('deferred.jsonl', deferred)
emit('missing-optional-seeds.jsonl', missing_seeds)
emit('logical-mode-observations.jsonl', mode_observations)
emit('inherited-cache-reclassified-identity-only.jsonl', inherited_cache_reclassified)
emit('inspectable-cargo-source-build-metadata.jsonl', [r for r in categories['paths'].values() if 'target' in Path(r['path']).parts[2:]])
emit('actual-deliverable-body-exceptions.jsonl', [dict(r, selection_reason=classify(r)[1]) for r in categories['paths'].values() if r['path'] in deliverables or r['path'].endswith('/artifacts/native_transport')])
emit('added-records.jsonl', [dict(category=name, record=row) for name, rows in categories.items() for k, row in sorted(rows.items()) if k not in base_known])
(OUT / 'source-epochs.json').write_text(json.dumps({
    'policy': 'Historical identities remain separate; no old raw result is relabeled as a later source epoch.',
    'inherited': 'Catalog02 retains composed05, composed07, earlier canonical check and portable-build source identities and prerequisites.',
    'current_core': 'Freeze02 runtime150 plus two binding files; bind exact final canonical source closure separately.',
    'M1_actual03': 'Actual command03/source-admission/independent-readback joins; distinct from earlier M1 attempts.',
    'portable_products': 'Actual Wasm build05 plus reused actual NAPI build04; recorded 217/218 equality is not all-218 equality.',
    'portable_capture02': 'Original forced incomplete capture; independently qualified 188-process NAPI subset remains separate, with four additional glob adapter failures retained.',
    'portable_capture03': 'Forced terminal capture03 remains a failed whole acquisition; scoped completed NAPI576 reader is separate. Chromium capture04 and its final readback remain pending.',
    'Native_transport01': 'New small driver linked to admitted portable-build04 release runtime; twenty dynamic controls and four static counterparts remain distinct.',
    'workspace_observation': 'Monitor loss and failed observer remain separate from successful harness qualification02. Composed aggregate03 admits285 harnesses/1779 passes/5 ignored; original Cargo exit remains null/unobserved/inconclusive. Fresh checks06 seven commands are a distinct actual acquisition.',
    'source_input_output_rosters': ['seed-inputs.json', 'metadata-read-pins.json', 'added-records.jsonl', 'new-presence-size-mode.jsonl'],
}, indent=2) + '\n')
(OUT / 'seed-inputs.json').write_text(json.dumps(new_seeds, indent=2) + '\n')
(OUT / 'metadata-read-pins.json').write_text(json.dumps(metadata_reads, indent=2) + '\n')
(OUT / 'base-catalog-pins.json').write_text(json.dumps(json.loads((BASE / 'metadata-pins.json').read_text()), indent=2) + '\n')
report = dict(
    status='incremental unsealed catalog03 metadata candidate; no archive payload admission or checkpoint completion',
    public_report='reports/m2/stage122-lossless-source-runtime',
    checkpoint='reports/m2/stage122-lossless-source-runtime-checkpoint.json',
    base_catalog='target/m2/stage122-publication-catalog-prep-02',
    base_counts=base_counts, new_explicit_seed_files=len(new_seeds), new_metadata_files_expanded=len(metadata_reads),
    added_declared_records=sum(k not in base_known for rows in categories.values() for k in rows),
    payload_logical_modes_complete=all('mode' in row for row in categories['paths'].values()),
    observed_modes_where_acquisition_omitted_mode=len(mode_observations),
    raw_path_records=len(categories['paths']), raw_logical_bytes=sum(r['bytes'] for r in categories['paths'].values()),
    unique_payloads=len(objects), unique_payload_bytes=sum(r['bytes'] for r in objects.values()),
    canonical_identical_snapshot_aliases=len(categories['canonical-source-aliases']), identity_only=len(categories['identity-only']),
    prior_prerequisites=len(categories['prerequisites']), unavailable_declared_path_versions=len(categories['unavailable']),
    inherited_cache_records_reclassified_identity_only=len(inherited_cache_reclassified),
    inherited_cache_logical_bytes_removed_from_payloads=sum(r['bytes'] for r in inherited_cache_reclassified),
    historical_paths_with_multiple_pins=len(variants), inherited_unresolved_historical_paths=len(base_variants),
    raw_payloads_freshly_rehashed=False, new_raw_presence_size_mode_only=True,
    old_archive_bodies_read=False, compiler_cache_dependency_binary_bodies_selected=False,
    inspectable_cargo_subtree_source_build_metadata=sum('target' in Path(r['path']).parts[2:] for r in categories['paths'].values()),
    actual_deliverable_body_exceptions=sum(r['path'] in deliverables or r['path'].endswith('/artifacts/native_transport') for r in categories['paths'].values()),
    small_native_driver_body_selected=any(r['path'].endswith('/artifacts/native_transport') for r in categories['paths'].values()),
    optional_missing_seed_files=len(missing_seeds), metadata_only_no_new_workloads=True,
    monitor_loss='Guarded stop attempt aborted before signal because stop condition no longer held; zero signals, producer unchanged; monitoring gap remains explicit.',
    bounded_coverage=dict(full_ready=dict(pass_count=4351,mismatches=15,unsupported=74,oracle_errors=2,total=4442,metamorphic_pass=88,old_pass_regressions=0),
                          current_strict_gate_overlapping_unmet_conditions=1768,
                          composed_workspace=dict(passed=1779,failed=0,ignored=5,harnesses=285,original_Cargo_exit='unobserved/inconclusive',composed_workspace_command_pass=None),
                          glob_per_target=dict(matches=524,nonmatches=52,sessions=576),
                          math=dict(typed_rendered_observations=824,values=778,exceptions=46,Java_implementation_class_fields_uncovered=92),
                          Chromium_resource=dict(scoped_large_cases=10,cap_bytes=3221225472,peak_sampled_owned_rss_bytes=2370224128,original_2GiB_failure_preserved=True,memory_parity_claimed=False)),
    pending=['root full-payload authentication, deterministic archives and independent new-archive byte readback; producer/readback receipts remain outside archives to avoid cycles',
             'original checks05 Cargo exit remains unobserved/inconclusive; preserve this required provenance limitation rather than inventing a successful full command',
             'final public document/descriptor Git publication and public-copy raw hash proof; no final public docs or cycle-bearing descriptor inside archives'],
    deferred_namespaces=list(DEFERRED), full_M2_API_platform_performance_completion_claimed=False)
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Incremental Stage122 publication catalog03

This is an unsealed metadata candidate extending catalog02. Only explicit seed
reports/preparation manifests and their declared finite pins were expanded; no
evidence tree was walked. Metadata read for expansion was authenticated. Historical
raw payload hashes remain acquisition declarations; newly selected raw payloads
received only regular-file/presence/size/mode checks. The root archiver must verify
their complete bytes once before final admission.

The catalog retains historical source epochs, failed acquisitions and control
attempts, canonical aliases, exact source/input/output rosters, and explicit
unavailable/variant records. Preserve each logical alias mode even when payloads
deduplicate. Reusable compiled artifacts, cache binaries, installed tools and
archive bodies are identity/prerequisite records only. Emitted dep-info, generated
Rust source inputs, compiler logs and build/qualification metadata remain selected
even within Cargo subtrees. Current actual deliverable products and the small
Native transport driver are explicit selected exceptions; the reused runtime and
157 host dependency bodies are omitted. Clone-inventory cache members remain
lineage identities, apart from exact native product dep-info selected for joins.

All bounded runtime acquisitions and independent readbacks are selected, including
the failed04 whole Chromium acquisition, qualified701-process subset and actual05
63-process continuation. The separate3GiB large-case resource experiment preserves
the original2GiB failure and establishes no memory parity. Archive execution and
final public documentation remain pending. Terminal full-ready raw reports and
the current exact1768-condition strict gate failure remain explicit.
The failed observer, successful harness qualifier02, actual checks06 and composed
aggregate03 remain separate; original checks05 Cargo exit stays unobserved and
inconclusive, and composed workspace command pass stays null. Forced capture03 and its independently scoped completed NAPI glob
reader remain separate acquisitions. The monitor-loss receipt records an aborted stop attempt before any
signal, zero signals and an unchanged old producer report; it does not establish
continuous resource monitoring. Actual Native20/four static counterparts, M1
actual03, portable-build05 admission, independently qualified old NAPI188 reuse,
source GO reports and sealed successor preparations remain distinct evidence.

Historical path variants and unavailable identities require explicit resolution.
Source repair, product admission and preparation never promote failed captures
or close full M2, public API, release-platform or performance requirements. Root
owns terminal admission, final canonical documentation, archive creation/readback
and Git. No archive or workload was created by this catalog preparation.
''')
metadata = [pin(p) for p in sorted(OUT.iterdir()) if p.name != 'metadata-pins.json']
(OUT / 'metadata-pins.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(report), flush=True)
