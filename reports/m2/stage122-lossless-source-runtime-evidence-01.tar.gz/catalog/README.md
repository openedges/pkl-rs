# Incremental Stage122 publication catalog03

This is an unsealed metadata candidate extending catalog02. Only explicit seed
reports/preparation manifests and their declared finite pins were expanded; no
evidence tree was walked. Metadata read for expansion was authenticated. Historical
raw payload hashes remain acquisition declarations; newly selected raw payloads
received only regular-file/presence/size/mode checks. The root archiver must verify
their complete bytes once before final admission.

The catalog retains historical source epochs, failed acquisitions and control
attempts, canonical aliases, exact source/input/output rosters, and explicit
unavailable/variant records. Preserve each logical alias mode even when payloads
deduplicate. Reusable compiled artifacts, cache binaries, installed tools and
archive bodies are identity/prerequisite records only. Emitted dep-info, generated
Rust source inputs, compiler logs and build/qualification metadata remain selected
even within Cargo subtrees. Current actual deliverable products and the small
Native transport driver are explicit selected exceptions; the reused runtime and
157 host dependency bodies are omitted. Clone-inventory cache members remain
lineage identities, apart from exact native product dep-info selected for joins.

All bounded runtime acquisitions and independent readbacks are selected, including
the failed04 whole Chromium acquisition, qualified701-process subset and actual05
63-process continuation. The separate3GiB large-case resource experiment preserves
the original2GiB failure and establishes no memory parity. Archive execution and
final public documentation remain pending. Terminal full-ready raw reports and
the current exact1768-condition strict gate failure remain explicit.
The failed observer, successful harness qualifier02, actual checks06 and composed
aggregate03 remain separate; original checks05 Cargo exit stays unobserved and
inconclusive, and composed workspace command pass stays null. Forced capture03 and its independently scoped completed NAPI glob
reader remain separate acquisitions. The monitor-loss receipt records an aborted stop attempt before any
signal, zero signals and an unchanged old producer report; it does not establish
continuous resource monitoring. Actual Native20/four static counterparts, M1
actual03, portable-build05 admission, independently qualified old NAPI188 reuse,
source GO reports and sealed successor preparations remain distinct evidence.

Historical path variants and unavailable identities require explicit resolution.
Source repair, product admission and preparation never promote failed captures
or close full M2, public API, release-platform or performance requirements. Root
owns terminal admission, final canonical documentation, archive creation/readback
and Git. No archive or workload was created by this catalog preparation.
