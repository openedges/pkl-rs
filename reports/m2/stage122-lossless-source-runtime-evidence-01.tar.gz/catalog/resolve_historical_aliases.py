"""Resolve declared source epochs using metadata only; no Git/archive/raw body reads."""
import collections
import json
from pathlib import Path
import stat

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
HERE = Path(__file__).parent
PARENT = 'c5cb95c0431fb8255d42edab79befe5af96dfd1f'


def protected(path):
    return any(p.endswith('.partial') or p.lower().startswith('stage86') or 'private8' in p.lower() for p in Path(path).parts)


def norm(path):
    p = Path(path)
    return str(p.relative_to(ROOT)) if p.is_absolute() and p.is_relative_to(ROOT) else str(p)


def load(path):
    if protected(path):
        raise ValueError('protected metadata name')
    return json.loads(Path(path).read_text())


records = []
replacement_inputs = collections.defaultdict(list)


def visit(value, owner):
    if isinstance(value, dict):
        if isinstance(value.get('destination'), str) and isinstance(value.get('copy_source'), dict):
            source = value['copy_source']
            if {'path', 'bytes', 'sha256'} <= set(source):
                replacement_inputs[value['destination']].append(source)
        if (isinstance(value.get('path'), str) and type(value.get('bytes')) is int
                and isinstance(value.get('sha256'), str)):
            records.append(dict(path=norm(value['path']), bytes=value['bytes'], sha256=value['sha256'],
                                mode=value.get('mode'), owner=owner))
        if 'canonical_logical_path' in value and isinstance(value.get('canonical_identity'), dict):
            row = value['canonical_identity']
            records.append(dict(path=value['canonical_logical_path'], bytes=row['bytes'], sha256=row['sha256'],
                                mode=row.get('mode'), owner=owner))
        for child in value.values():
            visit(child, owner)
    elif isinstance(value, list):
        for child in value:
            visit(child, owner)


for name in ['paths', 'identity-only', 'prerequisites', 'canonical-source-aliases', 'unavailable']:
    for line in (HERE / (name + '.jsonl')).open():
        visit(json.loads(line), name + '.jsonl')
for pin in load(HERE / 'metadata-read-pins.json'):
    path = ROOT / pin['path']
    if path.suffix == '.json':
        visit(load(path), pin['path'])

by_payload = collections.defaultdict(list)
by_path = collections.defaultdict(set)
for row in records:
    by_payload[(row['bytes'], row['sha256'])].append(row)
    by_path[row['path']].add((row['bytes'], row['sha256']))
current = {}
for name in ['target/m2/stage122-canonical-checks-05/inputs.json', 'target/m2/stage122-canonical-checks-06/inputs.json']:
    for row in load(ROOT / name):
        current[norm(row['path'])] = row
frozen = load(ROOT / 'target/m2/stage122-core-freeze-02/runtime-and-bindings.json')
for row in frozen['files']:
    current[row['logical_path']] = row

entries = load(ROOT / 'target/m2/stage122-canonical-integration-prep-01/all-entries.json')
original = {}
for entry in entries:
    row = entry.get('original_preimage')
    if isinstance(row, dict):
        original[(entry['destination'], row['bytes'], row['sha256'])] = row
pre_format = {row['path']: row for row in load(ROOT / 'target/m2/stage122-canonical-application-01/pre-format-rust.json')}
post_format = {row['path']: row for row in load(ROOT / 'target/m2/stage122-canonical-application-01/post-format-rust.json')}
copied = {row['destination'] for row in load(ROOT / 'target/m2/stage122-canonical-application-01/admitted-copy-plan.json')}


def priority(path):
    if 'historical-source-materialization' in path:
        return 0
    if '/before/' in path:
        return 1
    if '/overlay/' in path or '/source-tree/' in path:
        return 2
    if '/sources/' in path:
        return 3
    return 4 if path.startswith('target/m2/') else 5


def physical_candidates(size, digest):
    choices = {}
    for row in by_payload[(size, digest)]:
        name = row['path']
        if protected(name) or Path(name).is_absolute():
            continue
        if name.startswith(('external/', 'vendor/')) or not name.startswith('target/m2/') and name not in current:
            continue
        if name.startswith('target/m2/stage122-canonical-cargo-') or 'target' in Path(name).parts[2:]:
            continue
        if not name.startswith('target/m2/'):
            wanted = current.get(name, {})
            if wanted.get('sha256') != digest or wanted.get('bytes') != size:
                continue
        # Do not guess which same-size epoch currently occupies one physical path.
        epochs = {h for b, h in by_path[name] if b == size}
        if len(epochs) != 1 and current.get(name, {}).get('sha256') != digest:
            continue
        path = ROOT / name
        try:
            s = path.lstat()
        except FileNotFoundError:
            continue
        if not stat.S_ISREG(s.st_mode) or s.st_size != size:
            continue
        choices[name] = dict(path=name, bytes=size, sha256=digest, mode=stat.S_IMODE(s.st_mode),
                             declaration_owner=row['owner'], authentication='declared content identity plus current regular-file/size/mode; root final full hash required')
    return sorted(choices.values(), key=lambda row: (priority(row['path']), row['path']))


aliases = []
unresolved = []
git_probes = []
format_recipes = []
variants = [json.loads(line) for line in (HERE / 'historical-path-variants.jsonl').open()]
for variant in variants:
    logical = variant['path']
    for identity in variant['declared_variants']:
        size, digest = identity['bytes'], identity['sha256']
        ancestry_only = logical == 'compatibility/m2-language.json' and digest == '84d19bfbacc716fa1b7d04c2541b370556ca0d98b6318ae9e933c5184ef77829'
        candidates = physical_candidates(size, digest)
        declared_modes = {row['mode'] for row in by_payload[(size, digest)]
                          if row['path'] == logical and type(row['mode']) is int}
        if type(identity.get('mode')) is int:
            declared_modes.add(identity['mode'])
        mode_origin = 'explicit declared logical source identity'
        if not declared_modes:
            declared_modes = {row['mode'] for row in by_payload[(size, digest)] if type(row['mode']) is int}
            mode_origin = 'same-payload declared physical alias mode; original mode omitted'
        if not declared_modes and candidates:
            declared_modes = {candidates[0]['mode']}
            mode_origin = 'current physical alias mode; original declarations omitted mode'
        if not declared_modes:
            declared_modes = {None}
            mode_origin = 'unresolved mode'
        for mode in sorted(declared_modes, key=lambda value: -1 if value is None else value):
            row = dict(logical_path=logical, bytes=size, sha256=digest, mode=mode, mode_provenance=mode_origin,
                       body_required=not ancestry_only,
                       payload_member='objects/' + digest,
                       alias_member='historical-sources/' + digest + '.' + ('unknown' if mode is None else format(mode, '04o')),
                       declared_source_owners=sorted(set(identity.get('owners', []))))
            if ancestry_only:
                row.update(status='identity-only predecessor_manifest_identity ancestry; no Stage122 controller consumes the body; body not selected or claimed available',
                           payload_member=None, alias_member=None,
                           mode_provenance='not recorded; ancestry-only metadata makes no payload-mode claim')
            elif candidates:
                row.update(status='declared physical alias available; final full-hash admission pending', source=candidates[0],
                           alternate_physical_aliases=candidates[1:])
            else:
                row.update(status='unresolved payload version; no admissible physical source alias declared')
                unresolved.append(row)
                old = original.get((logical, size, digest))
                before, after = pre_format.get(logical), post_format.get(logical)
                unchanged_parent = (logical not in copied and before and after
                                    and all(before.get(k) == after.get(k) == identity.get(k) for k in ('bytes', 'sha256')))
                if old or unchanged_parent:
                    git_probes.append(dict(logical_path=logical, expected_bytes=size, expected_sha256=digest,
                                           expected_mode=mode, source_parent=PARENT,
                                           declared_preimage_match=old is not None,
                                           reason='explicit original preimage' if old else 'unchanged pre/post-format source outside integration copy destinations; Git bytes still require exact verification'))
                if after and before and after['bytes'] == size and after['sha256'] == digest:
                    sources = physical_candidates(before['bytes'], before['sha256'])
                    if sources:
                        format_recipes.append(dict(logical_path=logical, expected_bytes=size, expected_sha256=digest,
                                                   expected_mode=mode, input=sources[0],
                                                   rustfmt='/Users/cody.ij.hwang/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin/rustfmt',
                                                   arguments=['--edition', '2024', '--config', 'skip_children=true'],
                                                   scope='proposed exact reconstruction only; no formatter executed or output identity assumed'))
                if not old and not unchanged_parent and not any(r['expected_sha256'] == digest for r in format_recipes):
                    seen_inputs = set()
                    for source in replacement_inputs.get(logical, []):
                        if source['sha256'] in seen_inputs or source['sha256'] == digest:
                            continue
                        seen_inputs.add(source['sha256'])
                        sources = physical_candidates(source['bytes'], source['sha256'])
                        if sources and logical.endswith('.rs'):
                            format_recipes.append(dict(logical_path=logical, expected_bytes=size, expected_sha256=digest,
                                                       expected_mode=mode, input=sources[0],
                                                       rustfmt='/Users/cody.ij.hwang/.rustup/toolchains/1.98.1-aarch64-apple-darwin/bin/rustfmt',
                                                       arguments=['--edition', '2024', '--config', 'skip_children=true'],
                                                       scope='finite declared migration/candidate overlay formatting probe; exact recorded output hash is mandatory; no formatter executed or match assumed'))
            aliases.append(row)

objects = {}
for row in aliases:
    identity = (row['bytes'], row['sha256'], row['mode'])
    old = objects.get(identity)
    if old is None or 'source' not in old and 'source' in row:
        objects[identity] = {k: row[k] for k in ('bytes', 'sha256', 'mode', 'body_required', 'payload_member', 'alias_member', 'status', 'source') if k in row}
distinct_unresolved = [row for row in objects.values() if 'source' not in row and row['body_required']]


def emit(name, values):
    (HERE / name).write_text(''.join(json.dumps(row, sort_keys=True) + '\n' for row in values))


emit('historical-logical-aliases.jsonl', aliases)
emit('historical-object-sources.jsonl', sorted(objects.values(), key=lambda row: (row['sha256'], row['mode'] if row['mode'] is not None else -1)))
emit('unresolved-historical-identities.jsonl', distinct_unresolved)
emit('format-reconstruction-recipes.jsonl', format_recipes)
(HERE / 'additional-git-restoration-probes.json').write_text(json.dumps(git_probes, indent=2) + '\n')
report = dict(complete=True, metadata_resolution_only=True, historical_multiversion_logical_paths=len(variants),
              logical_alias_records=len(aliases), distinct_bytes_sha_mode_identities=len(objects),
              physical_alias_identities_available=sum('source' in row for row in objects.values()),
              identity_only_ancestry_references=sum(not row['body_required'] for row in objects.values()),
              unresolved_payload_identities=len(distinct_unresolved), unresolved_modes=sum(row['mode'] is None and row['body_required'] for row in objects.values()),
              proposed_additional_git_probes=len(git_probes), proposed_format_reconstructions=len(format_recipes),
              historical_raw_payloads_rehashed=False, old_archive_bodies_read=False, Git_or_formatter_executions=0,
              final_full_hash_admission_pending=True,
              scope='Deterministic aliases preserve distinct bytes/SHA/mode across historical source epochs. Availability is declared-source plus current metadata, never a substitute for root final full hash. Intentional compiled/cache binary omissions are not counted as missing source identities.')
(HERE / 'historical-alias-resolution.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
