"""Unsealed content-addressed archive plan. Metadata only; never write archives."""
import collections
import hashlib
import json
from pathlib import Path
import stat

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
HERE = Path(__file__).parent
LIMIT = 75 * 1024**2


def protected(path):
    return any(n.endswith('.partial') or n.lower().startswith('stage86') or 'private8' in n.lower() for n in Path(path).parts)


def rows(name):
    return [json.loads(line) for line in (HERE / name).open()]


def norm(path):
    p = Path(path)
    return str(p.relative_to(ROOT)) if p.is_absolute() and p.is_relative_to(ROOT) else str(p)


def metadata_pin(path):
    if protected(path):
        raise ValueError('protected metadata path')
    p = Path(path)
    p = p if p.is_absolute() else ROOT / p
    s = p.lstat()
    if not stat.S_ISREG(s.st_mode):
        raise ValueError('metadata must be regular')
    body = p.read_bytes()
    return dict(path=norm(p), bytes=len(body), mode=stat.S_IMODE(s.st_mode), sha256=hashlib.sha256(body).hexdigest())


def emit(name, values):
    (HERE / name).write_text(''.join(json.dumps(row, separators=(',', ':'), sort_keys=True) + '\n' for row in values))


raw = rows('paths.jsonl')
canonical = rows('canonical-source-aliases.jsonl')
historical = rows('historical-logical-aliases.jsonl')
resolution = json.loads((HERE / 'historical-alias-resolution.json').read_text())
if resolution['unresolved_payload_identities'] or resolution['unresolved_modes']:
    raise ValueError('all required historical payload identities/modes must resolve first')

physical = {}
objects = {}
logical = {}
current = {}
for input_name in ['stage122-canonical-checks-05/inputs.json', 'stage122-canonical-checks-06/inputs.json']:
    for row in json.loads((ROOT / 'target/m2' / input_name).read_text()):
        current[norm(row['path'])] = row


def physical_pin(path, size, digest):
    name = norm(path)
    if protected(name) or Path(name).is_absolute() or name.endswith(('.tar.gz', '.tgz', '.tar', '.zip', '.jar', '.gz', '.xz', '.zst')):
        raise ValueError('forbidden physical archive source')
    p = ROOT / name
    s = p.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_size != size:
        raise ValueError('physical source metadata differs: ' + name)
    row = dict(path=name, bytes=size, sha256=digest, mode=stat.S_IMODE(s.st_mode))
    previous = physical.get(name)
    if previous is not None and previous != row:
        raise ValueError('one physical path has ambiguous expected identities: ' + name)
    physical[name] = row
    return row


def priority(row):
    name = row['path']
    if 'historical-source-materialization' in name or 'historical-stream-prefix-materialization' in name:
        return 0, name
    if '/before/' in name:
        return 1, name
    if name.startswith('target/m2/'):
        return 2, name
    return 3, name


def body(pin):
    old = objects.get(pin['sha256'])
    if old and old['bytes'] != pin['bytes']:
        raise ValueError('same SHA has contradictory declared lengths')
    if old is None:
        objects[pin['sha256']] = dict(sha256=pin['sha256'], bytes=pin['bytes'], member='objects/' + pin['sha256'], source=pin)
    elif priority(pin) < priority(old['source']):
        old['source'] = pin


def alias(path, size, digest, mode, kind):
    if type(mode) is not int:
        raise ValueError('logical mode must be explicit')
    name = norm(path)
    key = name, size, digest, mode
    logical.setdefault(key, dict(path=name, bytes=size, sha256=digest, mode=mode, kind=kind))


# A saved document preimage avoids substituting later canonical documentation.
document_overrides = {}
doc = next((r for r in raw if r['path'] == 'docs/architecture.md'), None)
if doc:
    backup = HERE / 'architecture.preimage.md'
    if not backup.exists():
        source = ROOT / doc['path']
        actual = metadata_pin(source)
        if actual['bytes'] != doc['bytes'] or actual['sha256'] != doc['sha256']:
            raise ValueError('architecture preimage already changed; root restoration required')
        backup.write_bytes(source.read_bytes())
        backup.chmod(doc['mode'])
    snapshot = metadata_pin(backup)
    if snapshot['bytes'] != doc['bytes'] or snapshot['sha256'] != doc['sha256']:
        raise ValueError('saved architecture preimage differs')
    document_overrides[doc['path']] = snapshot

for row in raw:
    source = document_overrides.get(row['path'])
    pin = physical_pin(source['path'] if source else row['path'], row['bytes'], row['sha256'])
    body(pin)
    alias(row['path'], row['bytes'], row['sha256'], row['mode'], 'capture-or-declared-source')

for row in canonical:
    mode = row.get('mode', row.get('canonical_identity', {}).get('mode'))
    if mode is None:
        raise ValueError('canonical alias missing logical mode')
    pin = physical_pin(row['path'], row['bytes'], row['sha256'])
    body(pin)
    alias(row['path'], row['bytes'], row['sha256'], mode, 'canonical-identical-snapshot')

for row in historical:
    if not row['body_required']:
        continue
    source = row['source']
    pin = physical_pin(source['path'], row['bytes'], row['sha256'])
    body(pin)

# Bind current project source/fixtures once, rather than duplicate materialized
# source trees. Compiler/cache identities and upstream installed dependencies stay
# outside this selected body roster.
for row in rows('identity-only.jsonl'):
    name = row['path']
    permitted = name.startswith(('crates/', 'tools/', 'xtask/', 'tests/', 'compatibility/', '.cargo/', 'vendor/java_regex/src/')) or name in ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'references.lock', 'oracle.lock.json')
    if not permitted or protected(name):
        continue
    wanted = current.get(name)
    if wanted is None or wanted.get('bytes') != row['bytes'] or wanted.get('sha256') != row['sha256']:
        continue
    pin = physical_pin(name, row['bytes'], row['sha256'])
    body(pin)
    alias(name, row['bytes'], row['sha256'], wanted.get('mode', pin['mode']), 'current-project-source')

implementation_path = ROOT / 'target/m2/stage122-final-implementation-roster-02/implementation.json'
implementation_pin = metadata_pin(implementation_path)
if implementation_pin['sha256'] != '0d2aca74395b1720bd64f2b276e7c4a551ab4f823911b191becbb6313c4e154b':
    raise ValueError('final implementation roster changed')
implementation = json.loads(implementation_path.read_text())
if len(implementation) != 1888:
    raise ValueError('final1888 implementation roster required')
for row in implementation:
    pin = physical_pin(row['path'], row['bytes'], row['sha256'])
    if pin['mode'] != row['mode']:
        raise ValueError('final canonical implementation mode changed')
    body(pin)
    alias(row['path'], row['bytes'], row['sha256'], row['mode'], 'final-implementation')
body(physical_pin(implementation_pin['path'], implementation_pin['bytes'], implementation_pin['sha256']))
alias(implementation_pin['path'], implementation_pin['bytes'], implementation_pin['sha256'], implementation_pin['mode'], 'implementation-roster')
emit('final-implementation-alias-map.jsonl', [dict(row, payload_member='objects/' + row['sha256']) for row in implementation])

physical_values = sorted(physical.values(), key=lambda row: row['path'])
emit('physical-aliases.jsonl', physical_values)
physical_manifest = metadata_pin(HERE / 'physical-aliases.jsonl')
# The large physical verification roster is a content-addressed metadata payload,
# keeping part1 compact. The primary object pin authenticates this manifest itself;
# it is deliberately not recursively listed inside its own byte contents.
body(physical_manifest)
alias('catalog/physical-aliases.jsonl', physical_manifest['bytes'], physical_manifest['sha256'], physical_manifest['mode'], 'publication-metadata')

logical_values = sorted(logical.values(), key=lambda row: (row['path'], row['sha256'], row['mode']))
with (HERE / 'logical-alias-map.tsv').open('w') as stream:
    for row in logical_values:
        stream.write('\t'.join([json.dumps(row['path'], ensure_ascii=False), row['sha256'], str(row['bytes']), format(row['mode'], '04o'), row['kind']]) + '\n')
compact_historical = [{k: row[k] for k in ('logical_path', 'bytes', 'sha256', 'mode', 'body_required', 'alias_member', 'payload_member', 'status')} for row in historical]
emit('historical-alias-map.jsonl', compact_historical)
emit('identity-only-ancestry.jsonl', [row for row in compact_historical if not row['body_required']])
object_values = sorted(objects.values(), key=lambda row: row['sha256'])
emit('payload-objects.jsonl', object_values)

payload_parts = []
for row in sorted(object_values, key=lambda value: (-value['bytes'], value['sha256'])):
    if row['bytes'] > LIMIT:
        raise ValueError('single object exceeds75MiB: root must define bounded chunking without changing bytes')
    part = next((part for part in payload_parts if part['body_bytes'] + row['bytes'] <= LIMIT), None)
    if part is None:
        payload_parts.append(dict(part=len(payload_parts) + 2, kind='content-addressed-payloads', body_bytes=0, objects=[]))
        part = payload_parts[-1]
    part['objects'].append(row['sha256'])
    part['body_bytes'] += row['bytes']
for part in payload_parts:
    part['objects'].sort()

summary = dict(status='sealed for root full-byte authentication; runtime receipts complete; archives/readback/final publication pending',
               interface_frozen_for_root_authentication=True,
               schema_version=1, unique_payload_objects=len(objects), unique_payload_body_bytes=sum(r['bytes'] for r in object_values),
               selected_physical_aliases=len(physical_values), logical_aliases=len(logical_values),
               historical_aliases=len(historical), unresolved_required_historical_payloads=resolution['unresolved_payload_identities'],
               final_implementation_roster=implementation_pin, final_implementation_aliases=1888,
               identity_only_predecessor_ancestry=resolution['identity_only_ancestry_references'],
               payload_part_count=len(payload_parts), max_part_body_bytes=LIMIT,
               fresh_full_hash_admission_performed=False, old_archive_bodies_read=False,
               archives_written=0, final_publication_success_claimed=False,
               physical_alias_roster=physical_manifest,
               physical_alias_roster_payload_member='objects/' + physical_manifest['sha256'],
               logical_alias_tsv_columns=['JSON-encoded logical path', 'SHA256', 'bytes', 'mode octal', 'kind'],
               historical_alias_policy='Key by logical_path/bytes/SHA/mode; never overwrite one source epoch with another canonical spelling.',
               fresh_hash_contract='Root must authenticate every physical-aliases.jsonl row once, each additional primary object source once, and all part1 metadata once before writing content-deduplicated objects. Never hash/read excluded old archive bodies.',
               document_preimage_overrides=document_overrides)
(HERE / 'archive-interface-readiness.json').write_text(json.dumps(summary, indent=2) + '\n')
metadata_names = ['payload-objects.jsonl', 'logical-alias-map.tsv', 'historical-alias-map.jsonl',
                  'final-implementation-alias-map.jsonl',
                  'identity-only-ancestry.jsonl', 'archive-interface-readiness.json',
                  'prepare_archive_interface.py', 'resolve_historical_aliases.py', 'build_catalog.py',
                  'historical-alias-resolution.json', 'source-epochs.json', 'README.md']
metadata_files = [metadata_pin(HERE / name) for name in metadata_names]
(HERE / 'readiness-files.json').write_text(json.dumps(metadata_files, indent=2) + '\n')
part1_names = metadata_names + ['readiness-files.json', 'parts.json']
parts = dict(schema_version=1, status='sealed deterministic plan for root full-hash admission; payloads not yet authenticated',
             interface_frozen_for_root_authentication=True,
             max_payload_body_bytes=LIMIT,
             part1=dict(part=1, kind='new-interface-metadata-only', members=[dict(source=norm(HERE / name), member='catalog/' + name) for name in part1_names]),
             payload_parts=payload_parts, object_roster=norm(HERE / 'payload-objects.jsonl'),
             physical_alias_roster=physical_manifest,
             physical_alias_roster_archive_member='objects/' + physical_manifest['sha256'],
             required_historical_payloads_resolved=True, final_publication_sealed=False)
(HERE / 'parts.json').write_text(json.dumps(parts, indent=2) + '\n')
for _ in range(4):
    part1_bytes = sum((HERE / name).stat().st_size for name in part1_names)
    if part1_bytes > LIMIT:
        raise ValueError('compact metadata part1 exceeds75MiB')
    if summary.get('part1_metadata_body_bytes') == part1_bytes:
        break
    summary['part1_metadata_body_bytes'] = part1_bytes
    (HERE / 'archive-interface-readiness.json').write_text(json.dumps(summary, indent=2) + '\n')
    # Refresh pins after changing summary size; no self hash is embedded.
    metadata_files = [metadata_pin(HERE / name) for name in metadata_names]
    (HERE / 'readiness-files.json').write_text(json.dumps(metadata_files, indent=2) + '\n')
else:
    raise ValueError('part1 metadata byte accounting did not converge')
seal_names = part1_names + ['physical-aliases.jsonl']
(HERE / 'archive-interface-metadata-pins.json').write_text(json.dumps([metadata_pin(HERE / name) for name in seal_names], indent=2) + '\n')
print(json.dumps(summary), flush=True)
