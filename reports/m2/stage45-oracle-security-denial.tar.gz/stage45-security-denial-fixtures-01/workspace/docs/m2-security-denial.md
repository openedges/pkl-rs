# Typed module security-denial control

The Pkl 0.32.0 Java control uses the actual standard security manager, the default
file module loader, and an existing child file. The policy allows the exact main
module URI and `pkl:`/`repl:` URIs while excluding the child. A counting wrapper
delegates every policy operation and rethrows the original
`SecurityManagerException`, recording its complete message and UTF-16 units.

Two fresh JVMs execute `caught`, `nullable`, `ordinary`, `stable`, and `caught`
through one evaluator. All ten API captures and six actual exception causes are
preserved. `catch` and `catchOrNull` return the denial message, the ordinary
import retains its full diagnostic, the evaluator returns `7` afterward, and
the successful caught value is reused without another child denial.

```sh
python3 tools/security_denial_fixtures.py
python3 -m unittest discover -s tools/tests -p test_security_denial_fixtures.py
cargo test -p pkl-runtime --test m2_security_denial_oracle --locked
```

The native and portable consumers complete actual pending module **resolution**
requests with `security-manager-exception` and the captured cause units. They
compare complete statuses, UTF-16 units, Java UTF-8 bytes, and the three denied
child resolutions per repetition. Java's complete policy callback counters stay
in the fixture; they are distinct from this Host callback boundary. The
portable runner uses the recorded Wasm and Node artifacts:

```sh
node tools/platform/compare-security-denial.mjs OUTPUT WASM_DIR ADDON FIXTURES_DIR PINNED_PACKAGE_JSON
```

Generic `Denied` and raw Host rejection are separate contracts. This control does
not promote arbitrary messages to Java exception provenance, implement a full
security manager, establish source-load exception compatibility, or close M2.
Production evaluation remains in the shared Rust engine.
