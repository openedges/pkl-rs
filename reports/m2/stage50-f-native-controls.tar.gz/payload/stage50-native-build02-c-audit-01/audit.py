"""Read-only recorded native audit. Never starts a build, Java or evaluator."""
import argparse,collections,hashlib,json,pathlib,re,stat
R=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage50');M=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs');O=pathlib.Path(__file__).resolve().parent
PRODUCER=R/'target/m2/stage50-native-controls-build02-01';LAUNCH=R/'target/m2/stage50-native-controls-build02-launch-01';RUNNER=R/'target/m2/stage50-native-controls-plan-01/run.py';BUILD=R/'target/m2/stage50-storage-build02';F=R/'tests/fixtures/m2-modulekey-extended';OLD=M/'target/m2/stage49-oracle-native-consumer-03/inputs';TABLES=M/'target/m2/stage49-oracle-extended-transport-03'
RUNNER_SHA='9f1d881ab292401041e26a18ed7963c94719c0c132b2657061cf5f8b661685f8';BUILD_SHA='65724103043d34db82cc43e8e69cb3006ca11c4a899e17eb11f23fffa49b8331';ARTIFACT_SHA='116f301c06b4c4cc25e2e4609d263e45a12dc61c49ade796c73b0c0cc33a39b6';REPORT_SHA='9fc79cfdda684ba433b0b435f2fe27453693263342c49bd08656eb2cfedaf52f'
CAT={}
def get(p):
 p=pathlib.Path(p);assert stat.S_ISREG(p.lstat().st_mode),p;b=p.read_bytes();row={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};assert str(p)not in CAT or CAT[str(p)]==row,('changed',p);CAT[str(p)]=row;return b
def load(p):return json.loads(get(p))
def sha(p):return hashlib.sha256(get(p)).hexdigest()
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def safe(s):
 p=pathlib.Path(s);assert not p.is_absolute()and'..'not in p.parts and str(p)==s;return p
def u16(b):assert len(b)%2==0;return[int.from_bytes(b[i:i+2],'big')for i in range(0,len(b),2)]
def java8(us):return b''.join(u.to_bytes(2,'big')for u in us).decode('utf-16-be','surrogatepass').encode('utf8','replace')
def counters(b):return {k:int(v)for k,v in (line.split('=',1)for line in b.decode().splitlines())}
def count_bytes(requests,imports,resolves,events):return f'requests={requests}\nimport={imports}\nresolve={resolves}\nevent={events}\n'.encode()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--terminal',type=pathlib.Path,required=True);a=ap.parse_args()
 # Terminal gate runs before reading any acquisition results.
 t=load(a.terminal);assert a.terminal==LAUNCH/'execute.terminal.json' and t['stage']=='execute'and t['exitCode']==0 and t['finishedUtc'] and t['runnerSha256']==t['runnerAfterSha256']==RUNNER_SHA and t['buildAfterSha256']==BUILD_SHA
 assert t['command'][2:]==[str(RUNNER),'--build-json',str(BUILD/'build.json'),'--build-sha256',BUILD_SHA,'--output',str(PRODUCER),'--execute']
 assert sha(RUNNER)==RUNNER_SHA and sha(BUILD/'build.json')==BUILD_SHA and sha(PRODUCER/'report.json')==REPORT_SHA
 report=load(PRODUCER/'report.json');pre=load(PRODUCER/'preflight.json');assert report['executed']and not report['changedInputs']and report['preflightIntegrityPassed']and report['allAcquisitionIntegrityPassed']and not report['fullJavaEventCounterGatePassed']and report['liveHandles']==[]
 candidate=report['candidate'];assert candidate==pre['candidate']and candidate['buildSha256']==BUILD_SHA and candidate['artifactSha256']==ARTIFACT_SHA and candidate['sourceCount']==227
 b=load(BUILD/'build.json');sm=get(BUILD/'sources-before.json');assert sm==get(BUILD/'sources-after.json')and hashlib.sha256(sm).hexdigest()==candidate['sourceMapSha256'];mapping=json.loads(sm);assert len(mapping)==227 and b['status']=='CLOSED'and b['sourceStable']and b['exitCode']==0 and b==candidate['producerRecord']
 assert b['artifact']==str(BUILD/'stage49_modulekey_probe')and sha(b['artifact'])==ARTIFACT_SHA
 for rel,h in mapping.items():assert sha(BUILD/'sources'/safe(rel))==h
 reviewed=load(R/'target/m2/stage50-code-storage-c-review-02/source-map.json');assert all(mapping[k]==v for k,v in reviewed.items())
 for rel,h in candidate['adapterPins'].items():assert mapping[rel]==h
 assert len(candidate['adapterPins'])==3 and candidate['runtimeSourceChangesFromStage49']
 for p,h in pre['inputsBefore'].items():assert sha(p)==h
 manifest=load(OLD/'manifest.json');assert sha(OLD/'manifest.json')=='64b5198ef06501ba952306dfca844d27429de2069aba02d333d563dd986cd93c';old=load(OLD/'inputs.json');assert sha(OLD/'inputs.json')==manifest['files']['inputs.json']['sha256']
 fm=load(F/'manifest.json');assert sha(F/'manifest.json')=='eda9449570132c0f76ebf2ea67071a94b6b3a53b29fb9a49dfb982e66ad18bb2'
 for name in ['fixtures.json','host-metadata.json']:assert sha(F/name)==fm['files'][name]['sha256']
 bundle=load(F/'fixtures.json');profiles={p['id']:p for p in load(F/'host-metadata.json')['profiles']};assert(bundle['javaApiCalls'],bundle['javaOrderedEvents'])==(944,10124)
 index=load(TABLES/'index.json');assert sha(TABLES/'index.json')=='175130f4b2c0ed57968bb4a9bb42d11f6d99b6d6bc32d0676fde0acff3e09282';tables={(pathlib.Path(c['oracleRoot']).name[-2:],c['id']):c for c in index['cases']}
 jobs={}
 for name,profile in [('provided212','provided-primary-modulekey-v1'),('public212','public-module-source-uri-v1')]:
  jobs[name]=[{'key':c['key'],'fixture':c,'source':str(OLD/c['sourceFile']),'uri':c['uri'],'name':c['moduleName'],'ops':str(OLD/c['operationsFile']),'plan':str(OLD/c['modulePlanFile']),'policy':c['initialPolicy'],'cause':str(OLD/'causes.tsv'),'profile':profile}for c in old['cases']]
 jobs['extended944']=[]
 for f in bundle['fixtures']:
  table=tables[(f['oracleId'][-2:],f['caseId'])];jobs['extended944'].append({'key':f"stage49-oracle-modulekey-{f['oracleId'][-2:]}/{f['caseId']}/{f['repeat']}/{f['session']}",'fixture':f,'source':table['mainSource'],'uri':table['mainUri'],'name':'main','ops':table['operations'],'plan':table['config'],'policy':table['initialPolicy'],'cause':str(M/'target/m2/stage49-oracle-native-extended-consumer-02/causes.tsv'),'profile':'public-module-source-extended-v1'})
 assert {k:len(v)for k,v in jobs.items()}=={'provided212':36,'public212':36,'extended944':140}
 expected_phases={'unclassified','configuration','lexing','parsing','ast-validation','resolution','compilation','module-output'};summary={};mismatches=[];children=[]
 kind_debug={'select-key':'SelectKey','check-import':'CheckImport','query-cache-policy':'QueryCachePolicy','query-fragment-paths':'QueryFragmentPaths','resolve-import-uri':'ResolveImportUri','resolve':'Resolve','resolve-key':'ResolveKey','source':'LoadSource','capabilities':'Capabilities','has-element':'HasElement'}
 completion_tags={'select-key':['KeySelected('],'check-import':['ImportChecked('],'query-cache-policy':['CachePolicy('],'query-fragment-paths':['FragmentPaths('],'resolve-import-uri':['ImportUri('],'resolve':['Resolved('],'resolve-key':['Resolved('],'source':['Source('],'capabilities':['Capabilities('],'has-element':['HasElement(']}
 for cohort,planned in jobs.items():
  saved=report['cohorts'][cohort];assert len(saved['records'])==len(planned);total=collections.Counter();request_kinds=collections.Counter()
  for job,rec in zip(planned,saved['records']):
   path=PRODUCER/cohort/safe(job['key']);terminal=load(path/'terminal.json');assert terminal==rec['process']and terminal['key']==job['key']and terminal['parentPid']==t['pid']and terminal['exitCode']==0 and not terminal['timedOut']and terminal['startedUtc']<=terminal['finishedUtc']
   cmd=[b['artifact'],job['source'],job['uri'],job['name'],job['ops'],str(path/'raw'),'1',job['policy'],job['cause'],job['profile'],job['plan']];assert terminal['command']==cmd
   assert terminal['cwd']==str(RUNNER.parent)and terminal['environment']=={'TZ':'UTC','LANG':'C','LC_ALL':'C'}
   for channel in ['stdout','stderr']:assert sha(path/(channel+'.bin'))==terminal[channel+'Sha256']
   for arg in [job['source'],job['ops'],job['cause'],job['plan']]:assert str(pathlib.Path(arg))in pre['inputsBefore'];get(arg)
   assert load(path/'comparison.json')==rec
   raw=path/'raw/session-0';allow={'counters.bin','collections.bin','terminal-slots.bin','module-policy-profile.bin'}
   def read(name):allow.add(name);return get(raw/name)
   assert read('terminal-slots.bin')==b'0'and rec['terminalSlots']=='0'and rec['requestErrors']==[]and rec['acquisitionIntegrityPassed'];assert int(read('collections.bin'))>0
   assert read('module-policy-profile.bin').startswith(b'custom-key-first/separate-cache-policy/explicit-shared-default/file-host-v1\n')
   native_counts=counters(read('counters.bin'));assert set(native_counts)=={'requests','import','resolve','event'}
   requests=[];ids=set();tokens=set();previous=-1
   for j in range(native_counts['requests']):
    stem=f'module-{j}';fields={k:read(stem+'.'+k+'.bin').decode()for k in ['id','token','api-index','kind','request','completion','policy']};n=fields['id'];token=fields['token'];kind=fields['kind'];assert re.fullmatch('0|[1-9][0-9]*',n)and int(n)<=2**64-1 and int(n)>previous and n not in ids;previous=int(n);ids.add(n)
    assert re.fullmatch(r'\d+:\d+:\d+',token)and token not in tokens and token.split(':')[-1]==n;tokens.add(token)
    assert fields['api-index'].isdigit()and 0<=int(fields['api-index'])<len(job['fixture']['expected'])and kind in kind_debug and fields['request'].startswith(kind_debug[kind]+' {')
    assert fields['completion']=='shared-default-handled\n' or any(fields['completion'].startswith(tag)for tag in completion_tags[kind])
    for key_id in re.findall(r'(?:ModuleKeyId|ResolvedKeyId)\((\d+)\)',fields['request']):assert int(key_id)<=2**64-1
    extras=['importer-original-uri','importer-resolved-uri','import-uri']if kind in ['check-import','resolve']else[]
    if kind=='resolve':extras+=['original-uri']
    if kind=='source':extras=['original-uri','resolved-uri','source-uri']
    for key in extras:fields[key]=read(stem+'.'+key+'.bin').decode()
    wanted={'index':j,'id':n,'token':token,'apiIndex':fields['api-index'],'kind':kind};assert rec['requests'][j]==wanted
    requests.append(fields);request_kinds[kind]+=1
   assert len(rec['requests'])==len(requests)
   f=job['fixture'];assert len(rec['api'])==len(f['expected']);api_rows=[];reqs=imports=resolves=0;events=[];api_index=0;mode=job['policy'];local=collections.Counter()
   operations=[]
   for line in get(job['ops']).decode().splitlines():
    k,value=line.split('\t',1);operations.append((k,bytes.fromhex(value).decode()))
   for operation,value in operations:
    if operation not in ['evaluate','evaluate-source']:
     label={'gc':'native-explicit-collect','cache':'cache-profile ','policy':'policy-profile ','source':'source-profile ','factory':'factory-profile '}[operation];events.append(label if operation=='gc'else label+value)
     if operation=='policy':mode=value
     continue
    expected=f['expected'][api_index];call=rec['api'][api_index];prefix=f'outer-{api_index}';exp=f['expressions'][api_index]if'expr'not in expected else expected['expr'];assert read(prefix+'.expression.bin').decode()==exp
    if operation=='evaluate-source':
     sourceid,ex=value.split(':',1);sourceid=bytes.fromhex(sourceid).decode();ex=bytes.fromhex(ex).decode();assert ex==exp and sourceid==expected['sourceProfileId'];profile=profiles[f['providerProfileId']];sp=profile['sourceProfiles'][sourceid];assert read(prefix+'.source-uri.bin').decode()==sp['uri']and read(prefix+'.source-kind.bin').decode()==sp['kind']
     if sp['kind']!='uri':assert read(prefix+'.source-contents.bin').decode()==profile['sources'][sp['sourceId']]['text']
    assert read(prefix+'.counters-before.bin')==count_bytes(reqs,imports,resolves,len(events))
    current=[q for q in requests if int(q['api-index'])==api_index]
    for q in current:
     assert q['policy']==mode;reqs+=1
     if q['kind']=='check-import':imports+=1;events.append('policy-import '+q['importer-resolved-uri']+' -> '+q['import-uri'])
     if q['kind']in ['resolve','resolve-key']:resolves+=1
     if q['kind']=='resolve':events.append('policy-resolve-module '+q['import-uri'])
    status=read(prefix+'.status.bin');phase=read(prefix+'.phase.bin').decode();disposition=read(prefix+'.disposition.bin').decode();assert status in [b'success\n',b'error\n'];assert phase==''and disposition==''if status==b'success\n'else phase in expected_phases and disposition in ['language-error','unsupported','limit-exceeded','internal-failure']
    comparisons={'status.bin':status.hex()==expected['statusRawHex']};scope=expected.get('scope','ordinary')
    for ch in ['stdout','stderr']:
     data=read(prefix+'.'+ch+'.bin');unit_bytes=read(prefix+'.'+ch+'.code-units.bin');us=u16(unit_bytes);assert java8(us)==data
     comparisons[ch+'.bin']=data.hex()==expected[ch+'Hex'];comparisons[ch+'.code-units.bin']=us==expected[ch+'Units']
    matched=all(comparisons.values());compatible=scope=='ordinary'and matched and(status==b'success\n'or disposition=='language-error')
    assert call['index']==api_index and call['scope']==scope and call['comparisons']==comparisons and not call['missing']and call['rawBytesMatch']==matched and call['nativeStatusObserved']and call['nativePhase']==phase and call['nativeDisposition']==disposition and call['classificationKnown']and call['ordinaryCompatible']==compatible
    assert read(prefix+'.counters-after.bin')==count_bytes(reqs,imports,resolves,len(events))
    local['apiCalls']+=1;local['rawByteMatches']+=matched;local['rawMismatchOrMissing']+=not matched;local['ordinaryCompatibleCalls']+=compatible;local['diagnosticRawMatches']+=scope=='intent-not-reached-diagnostic'and matched;local['internalBoundaryRawMatches']+=scope=='internal-boundary'and matched;local['scope:'+scope]+=1
    if not matched:mismatches.append({'cohort':cohort,'key':job['key'],'index':api_index,'scope':scope,'javaErrorClass':call['javaErrorClass'],'nativeDisposition':disposition})
    api_index+=1
   assert api_index==len(f['expected'])and native_counts=={'requests':reqs,'import':imports,'resolve':resolves,'event':len(events)}
   for i,text in enumerate(events):assert u16(read(f'event-{i}.text.code-units.bin'))==list(text.encode('utf-16-be')[j]*256+text.encode('utf-16-be')[j+1]for j in range(0,len(text.encode('utf-16-be')),2))and read(f'event-{i}.text.bin')==text.encode()
   actual_paths=set()
   with __import__('os').scandir(raw)as entries:
    for entry in entries:assert entry.is_file(follow_symlinks=False);actual_paths.add(entry.name)
   assert actual_paths==allow,('unexpected native raw path set',job['key'],sorted(actual_paths-allow),sorted(allow-actual_paths))
   assert not rec['fullJavaEventCounterGate']['implemented']and not rec['fullJavaEventCounterGate']['passed']
   for key in ['rawByteMatches','rawMismatchOrMissing','ordinaryCompatibleCalls','diagnosticRawMatches','internalBoundaryRawMatches']:assert rec[key]==local[key]
   total.update(local);children.append({'cohort':cohort,'key':job['key'],'pid':terminal['pid'],'exitCode':0,'terminalSlots':0,'requests':len(requests)})
  for key in ['apiCalls','rawByteMatches','rawMismatchOrMissing','ordinaryCompatibleCalls','diagnosticRawMatches','internalBoundaryRawMatches']:assert saved[key]==total[key]
  assert saved['unsettledOrUnexecutedApiCalls']==0 and saved['acquisitionIntegrityPassed']and not saved['fullJavaEventCounterGatePassed'];summary[cohort]={'counts':dict(total),'requestKinds':dict(request_kinds),'processes':len(planned),'acquisitionIntegrityPassed':True,'fullJavaEventCounterGatePassed':False}
 assert len(children)==212 and report['scopeLedger']=={'originalJavaApiCalls':212,'nativeProvidedAndPublicProfiles':2,'additionalJavaApiCalls':944,'additionalOrdinary':836,'additionalIntentNotReachedDiagnostic':100,'additionalInternalBoundary':8,'neverSumRepeatedProfilesAsNewFeatures':True}
 write('recomputed-cohorts.json',summary);write('remaining-mismatches.json',mismatches);write('children.json',children);write('original-inputs-before.json',CAT)
 changes=[p for p,row in CAT.items()if hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=row['sha256']];assert not changes;write('original-inputs-after.json',CAT)
 write('report.json',{'scope':'Independent native02 raw/classification/request/token/completion/actual diagnostic-event/source/artifact readback only; no evaluator or build reruns.','producerReportSha256':REPORT_SHA,'terminalReceiptSha256':sha(a.terminal),'buildSha256':BUILD_SHA,'artifactSha256':ARTIFACT_SHA,'sourceCount':227,'reviewedFocusedSourceMapFiles':220,'declaredProducerInputs':len(pre['inputsBefore']),'readOriginalFiles':len(CAT),'originalChanges':changes,'cohorts':summary,'processes':212,'profileApiCalls':1368,'uniqueOriginalJavaApiCalls':1156,'duplicateProvidedPublic212NotNewFeatures':True,'rawMatchesDistinctFromAcquisition':True,'fullJavaEventsCountersPassed':False,'limits':['Native actual request/diagnostic stream is retained and internally joined, not equal to complete Java2248/10124 events/counters.','Extended eight internal-boundary raw failures and100 intent-not-reached diagnostic calls remain separate from ordinary836.','All227 immutable source copies rehashed, three adapter pins unchanged and focused220 reviewed sources match. This is not complete Git checkout/performance proof.','B may append producer seal metadata outside audited raw/immutable report; no producer directory or cache traversal is used except flat explicitly fresh raw/session-0 file-set check.','No final full M2/native fullCLI/platform/wholeRSS performance completion claim.']});print(json.dumps({'processes':212,'cohorts':summary,'originalFiles':len(CAT),'originalChanges':changes}))
if __name__=='__main__':main()
