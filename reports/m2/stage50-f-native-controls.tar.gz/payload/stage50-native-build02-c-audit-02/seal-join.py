import json,pathlib,hashlib
R=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage50');P=R/'target/m2/stage50-native-controls-build02-01';O=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return p.read_bytes()
def load(p):return json.loads(read(p))
assert sha(read(P/'handoff.json'))=='0dd7cb4e7a0aa1ceade1ccdff33342b96551ad28a9aa3b8c20976a3c30e3a8c5'and sha(read(P/'closure.json'))=='0c0b5137ea2db95b864231513e20a1978355223777bbe4304730665bd07e50f9'
c=load(P/'closure.json');assert c['sealed']and c['liveHandles']==[];assert sha(read(P/'inventory.json'))==c['inventorySha256'];inventory=load(P/'inventory.json')['files'];original=load(O/'original-inputs-before.json');extras={};joined=0
for rel,row in inventory.items():
 path=P/rel;assert not pathlib.Path(rel).is_absolute()and'..'not in pathlib.Path(rel).parts
 if str(path)in original:assert original[str(path)]==row;joined+=1
 else:
  data=read(path);assert sha(data)==row['sha256']and len(data)==row['bytes'];extras[str(path)]=row
report=load(P/'report.json')
for cohort in report['cohorts'].values():
 for case in cohort['records']:
  rawpath=pathlib.Path(case['process']['command'][5]);launch=load(rawpath.parent/'launch.json');terminal=load(rawpath.parent/'terminal.json');assert all(terminal[k]==v for k,v in launch.items())
for rel,row in inventory.items():
 if rel.startswith('original-producer-tools/'):
  origin=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2')/rel.removeprefix('original-producer-tools/');assert read(P/rel)==read(origin)
assert all(sha(read(pathlib.Path(p)))==v['sha256']for p,v in extras.items())
(O/'producer-seal-join.json').write_text(json.dumps({'producerHandoffSha256':c['handoffSha256'],'producerClosureSha256':'0c0b5137ea2db95b864231513e20a1978355223777bbe4304730665bd07e50f9','producerInventorySha256':c['inventorySha256'],'declaredProducerFiles':len(inventory),'alreadyIndependentlyRead':joined,'additionalReadFiles':len(extras),'additionalInputsBeforeAndAfter':extras,'allLaunchTerminalPrefixesJoined':212,'originalToolCopiesMatchAuthenticatedOriginals':True,'qualification':'Direct sealed inventory joins and direct extra metadata reads only, no producer root/cache tree walk. Primary API/request/counter audit remains separate.'},indent=2)+'\n');print(json.dumps({'producerFiles':len(inventory),'alreadyRead':joined,'extraRead':len(extras),'launches':212}))
