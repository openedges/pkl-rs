from pathlib import Path
from collections import Counter
import json,sys,shutil
sys.path.insert(0,'tools')
import evidence,m2_manifest as contract,oracle
root=contract.ROOT
out=root/'target/m2/stage8-exploration-evidence-01';out.mkdir(exist_ok=False)
directories=[f'stage8-exploration-{n:02d}' for n in range(1,7)]+['stage8-platform-java-01','stage8-platform-java-02','stage8-runtime-replay-01','stage8-runtime-replay-02','stage8-selection-baseline-01']
for name in directories:shutil.copytree(root/'target/m2'/name,out/name)
scripts=['stage8_explore.py','stage8_explore_followup.py','stage8_explore_orders.py','stage8_explore_hash_phase.py','stage8_explore_held_locals.py','stage8_explore_warm_initializer.py','stage8_platform_java.py','stage8_platform_phase_java.py','stage8_replay_explorations.py','stage8_promote.py','stage8_package_exploration.py']
(out/'scripts').mkdir()
for name in scripts:shutil.copy2(root/'target/m2'/name,out/'scripts'/name)
shutil.copy2(root/'target/m2/stage8-promotion.json',out/'promotion.json')
baseline=json.loads((out/'stage8-selection-baseline-01/cases.json').read_bytes())
current=json.loads((root/contract.SELECTION).read_bytes());assert len(baseline['cases'])==874 and len(current['cases'])==907 and current['cases'][:874]==baseline['cases']
for c in baseline['cases']:assert (root/c['input']).read_bytes()==(out/'stage8-selection-baseline-01/inputs'/c['input']).read_bytes()
original=[]
for name in directories[:6]:
 rows=json.loads((out/name/'observations.json').read_bytes())
 original.extend(dict(**r,exploration=name) for r in rows)
final=json.loads((out/'stage8-runtime-replay-02/results.json').read_bytes())
first=json.loads((out/'stage8-runtime-replay-01/results.json').read_bytes())
promotion=json.loads((out/'promotion.json').read_bytes())
selected={(Path(r['exploration']).name,r['exploratory_case_id']) for r in promotion['provenance']}
assert len(selected)==33 and all(r['status']=='pass' for r in final if (Path(r['baseline']).name,r['id']) in selected)
held=[]
for r in final:
 if r['status']=='pass':continue
 name=Path(r['baseline']).name;java=out/name/'cases'/r['id'];rust=out/'stage8-runtime-replay-02'/name/r['id']
 held.append(dict(id=r['id'],exploration=name,status=r['status'],java_process=json.loads((java/'java.process.json').read_bytes()),rust_process=r['rust'],java_stdout=(java/'java.stdout.bin').read_text(),java_stderr=(java/'java.stderr.bin').read_text(),java_outcome=(java/'java.outcome.bin').read_text(),rust_stdout=(rust/'rust.stdout.bin').read_text(),rust_stderr=(rust/'rust.stderr.bin').read_text(),selected=False))
platform=[]
for name in ['stage8-platform-java-01','stage8-platform-java-02']:
 report=json.loads((out/name/'report.json').read_bytes())
 platform.append(dict(directory=name,uri=report['uri'],captures=len(report['results']),helper_sha256=report['helper_sha256']))
summary=dict(scope='Bounded Stage 8 exploratory Java acquisition and frozen-candidate raw replay. This is not the formal build-bound selected report, full language compatibility, or performance evidence.',original_selection=dict(cases=874,definitions_unchanged=True,input_bytes_unchanged=True,frozen_probe_sha256=oracle.sha256(out/'stage8-selection-baseline-01/language_probe')),selection=dict(new_cases=33,total_cases=907,new_metamorphic_relations=6,promotion='promotion.json'),acquisition=dict(groups=6,java_rust_observation_rows=len(original),distinct_input_sha256=len({r['input_sha256'] for r in original}),initial_status_counts=dict(Counter(r['status'] for r in original)),java_captures=len(original),frozen_stage7_rust_captures=len(original)),replays=[dict(directory='stage8-runtime-replay-01',rows=len(first),status_counts=dict(Counter(r['status'] for r in first)),candidate_sha256=json.loads((out/'stage8-runtime-replay-01/candidate.json').read_bytes())['sha256']),dict(directory='stage8-runtime-replay-02',rows=len(final),status_counts=dict(Counter(r['status'] for r in final)),candidate_sha256=json.loads((out/'stage8-runtime-replay-02/candidate.json').read_bytes())['sha256'])],platform_captures=platform,held_mismatches=held,count_contract='Counts are process captures or observation rows. Repeated equivalent sources and candidate reruns are retained and are not distinct language requirements. Actual source URIs, raw channels, process commands and Java outcome sidecars are preserved. Platform captures use a separate exact URI and do not replace path-based captures.',known_unverified='Full Java hash integers/bucket and collision behavior, fifth cached-value insertion hash forcing, cyclic keys, local ObjectMember cache asymmetries, and general nested-let diagnostic frames remain outside this bounded closure.')
(out/'INDEX.json').write_bytes(contract.encoded(summary))
archive=root/'reports/m2/exploration-stage8-evidence.tar.gz';assert not archive.exists()
evidence.create(out,archive,[])
print(json.dumps(dict(archive=str(archive),archive_sha256=oracle.sha256(archive),observations=len(original),distinct_source_hashes=summary['acquisition']['distinct_input_sha256'],initial_status_counts=summary['acquisition']['initial_status_counts'],replay_rows=len(final),replay_status_counts=summary['replays'][-1]['status_counts'],held=len(held),platform_java_captures=sum(r['captures'] for r in platform),selected=33),indent=2))
