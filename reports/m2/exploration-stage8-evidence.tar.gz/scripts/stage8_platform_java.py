"""Capture exact Java diagnostics using the URI supplied by JS adapter scenarios."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
import oracle
import m2_language as runner
import m2_manifest as manifest

output = ROOT / "target/m2/stage8-platform-java-01"
output.mkdir(parents=True, exist_ok=False)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
(output / "oracle.json").write_bytes(manifest.encoded(metadata))
helper = output / "M2BoundaryProbe.java"
helper.write_text("""import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
import org.pkl.core.PklException;
public final class M2BoundaryProbe {
  public static void main(String[] args) throws Exception {
    try (var evaluator = EvaluatorBuilder.preconfigured().setModuleCacheDir(null)
        .setPowerAssertionsEnabled(Boolean.parseBoolean(args[2])).setColor(false)
        .setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      try {
        var module = ModuleSource.create(URI.create(args[1]), Files.readString(Path.of(args[0])));
        var result = evaluator.evaluateExpressionString(module, "result");
        Files.writeString(Path.of(args[3]), "success\\n", StandardCharsets.UTF_8);\n        System.out.write(result.getBytes(StandardCharsets.UTF_8));
      } catch (PklException error) {
        Files.writeString(Path.of(args[3]), "pkl-exception\\t" + error.getClass().getName() + "\\n", StandardCharsets.UTF_8);\n        System.err.write(error.getMessage().getBytes(StandardCharsets.UTF_8));
        System.exit(1);
      }
    }
  }
}
""")
classes = output / "classes"
classes.mkdir()
compiled = runner.capture([
    str(Path(metadata["java"]).with_name("javac")), "-encoding", "UTF-8",
    "-cp", metadata["artifact"], "-d", str(classes), str(helper)
], output, "javac", metadata["environment"])
assert compiled["exit_code"] == 0
cases = [('typed-default-equality', 'class C { default: Int = 1 }; result = new C {} == new C { default = 2 }\n', False), ('typed-default-keys', 'class C { default: Int }; result = new Mapping { [new C {default=1}]=10; [new C {default=2}]=20 }[new C {default=2}]\n', False), ('cache-order-warm-error', 'left = new Dynamic { a=0; b=new Mapping { [new Dynamic { key=throw("cached b first") }]=1 } }; right = new Dynamic { a=1; b=new Mapping { [new Dynamic { key=1 }]=1 } }; result = (left.b == left.b) && left == right\n', False), ('cache-order-cold', 'left = new Dynamic { a=0; b=new Mapping { [new Dynamic { key=throw("cached b first") }]=1 } }; right = new Dynamic { a=1; b=new Mapping { [new Dynamic { key=1 }]=1 } }; result = left == right\n', False), ('typed-class-order-control', 'class C { a: Int; b: Mapping }; left=new C {b=new Mapping {[new Dynamic {key=throw("skip reordered b")}]=1};a=0};right=new C {b=new Mapping {[new Dynamic {key=1}]=1};a=1};result=left==right\n', False), ('typed-default-force-error', 'class C { default: Int }; result = new C { default = throw("left default") } == new C { default = throw("right default") }\n', False)]

prefix = metadata["command"][:metadata["command"].index("-cp")]
rows = []
for name, source, power in cases:
    directory = output / name
    directory.mkdir()
    path = directory / "input.pkl"
    path.write_bytes(source.encode())
    command = [*prefix, "-cp", str(classes) + ":" + metadata["artifact"],
               "M2BoundaryProbe", str(path), "file:///m2-platform.pkl", str(power).lower(), str(directory / "java.outcome.bin")]
    capture = runner.capture(command, directory, "java", metadata["environment"])
    rows.append({
        "id": name, "source": source, "source_sha256": oracle.sha256(path),
        "power_assertions": power, "capture": capture,
        "outcome_sha256": oracle.sha256(directory / "java.outcome.bin"),
        "stdout": (directory / "java.stdout.bin").read_text(),
        "stderr": (directory / "java.stderr.bin").read_text(),
    })
    print(name, capture["exit_code"], flush=True)
(output / "report.json").write_bytes(manifest.encoded({
    "scope": "Pinned Java-only observations for exact JS adapter source URI; Rust platform verification separate.",
    "helper_sha256": oracle.sha256(helper), "uri": "file:///m2-platform.pkl", "results": rows
}))

paths=['target/m2/stage8_platform_java.py','references.lock','oracle.lock.json','tools/m2_language.py']
(output/'source-identities.json').write_bytes(manifest.encoded({p:oracle.sha256(ROOT/p) for p in paths}))
for p in paths:
 q=output/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((ROOT/p).read_bytes())
(output/'evidence-sha256.json').write_bytes(manifest.encoded({str(p.relative_to(output)):oracle.sha256(p) for p in sorted(output.rglob('*')) if p.is_file()}))
