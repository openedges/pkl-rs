from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import sys,json,shutil
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
candidate=Path('target/m2/stage8-selection-baseline-01/language_probe');shutil.copy2(candidate,art/'language_probe')
(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(candidate.resolve()),sha256=oracle.sha256(candidate),binding='Frozen original Stage7 final candidate; exploratory raw comparisons, not Stage8 final build evidence.')))
r=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert r['exit_code']==0
cases=[]
def add(id,source,family):cases.append(dict(id=id,source=source+'\n',family=family,expression='result'))
add('typed-ordinary-unequal','class C { value: Int = 1 }; result = new C {} == new C { value = 2 }','typed-default-relation')
add('typed-default-override-equal','class C { default: Int = 1 }; result = new C {default=2} == new C {default=2}','typed-default-relation')
add('typed-default-ordinary-order','class C { default: Int; other: Int }; result = new C {other=throw("other first");default=throw("default second")} == new C {default=0;other=0}','typed-force-order')
add('typed-default-own-before-parent','open class C { default: Int = throw("parent default") }; class D extends C { own: Int = throw("child own") }; result = new D {} == new D {}','typed-force-order')
for kind in ['Dynamic','Mapping','Listing']:
 if kind=='Dynamic':l='a=0; b=';r='a=1; b=';read='left.b';bodyend=''
 elif kind=='Mapping':l='["a"]=0; ["b"]=';r='["a"]=1; ["b"]=';read='left["b"]';bodyend=''
 else:l='0; ';r='1; ';read='left[1]';bodyend=''
 prefix='left=new '+kind+' { '+l+'new Mapping { [new Dynamic {key=throw("cached b first")}]=1 } }; right=new '+kind+' { '+r+'new Mapping { [new Dynamic {key=1}]=1 } }; '
 for mode,expression in [('warm','('+read+'=='+read+') && left==right'),('cold','left==right'),('warm-a','let(pre='+('left.a' if kind=='Dynamic' else 'left["a"]' if kind=='Mapping' else 'left[0]')+') left==right')]:
  add(kind.lower()+'-cache-'+mode+'-comparison-order',prefix+'result='+expression,'cache-comparison-order')
add('typed-cache-warm-class-order','class C { a: Int; b: Mapping }; left=new C {a=0;b=new Mapping {[new Dynamic {key=throw("skip cached b")}]=1}};right=new C {a=1;b=new Mapping {[new Dynamic {key=1}]=1}};result=(left.b==left.b)&&left==right','typed-order-control')
add('typed-cache-amendment-class-order','class C { a: Int; b: Mapping }; left=new C {b=new Mapping {[new Dynamic {key=throw("skip reordered b")}]=1};a=0};right=new C {b=new Mapping {[new Dynamic {key=1}]=1};a=1};result=left==right','typed-order-control')
add('typed-cache-child-class-order','open class C {a:Int};class D extends C {b:Mapping};left=new D {a=0;b=new Mapping {[new Dynamic {key=throw("child b first")}]=1}};right=new D {a=1;b=new Mapping {[new Dynamic {key=1}]=1}};result=left==right','typed-order-control')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','target/m2/stage8_explore_orders.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{k}.java' for k in ['Object','Dynamic','Listing','Mapping','Typed','List','Class']]
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 d=out/'cases'/c['id'];d.mkdir(parents=True);source=d/'input.pkl';source.write_bytes(c['source'].encode())
 java=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],d)
 rust=lang.capture([str(art/'language_probe'),*lang.expression_arguments(source,c['expression'])],d,'rust',meta['environment'])
 expected='success' if (d/'java.outcome.bin').read_bytes()==b'success\n' else 'error'
 status=lang.status(dict(expected_outcome=expected),java,rust,*[(d/f'{runtime}.{channel}.bin').read_bytes() for runtime in ['java','rust'] for channel in ['stdout','stderr']],(d/'java.outcome.bin').read_bytes())
 row=dict(id=c['id'],family=c['family'],source_uri=source.as_uri(),input_sha256=oracle.sha256(source),java=java,rust=rust,status=status,java_stdout=(d/'java.stdout.bin').read_text(),rust_stdout=(d/'rust.stdout.bin').read_text(),java_stderr=(d/'java.stderr.bin').read_text(),rust_stderr=(d/'rust.stderr.bin').read_text())
 print(c['id'],status,java['exit_code'],repr(row['java_stdout']),rust['exit_code'],repr(row['rust_stdout']),flush=True)
 return row
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
