from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,sys,shutil
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();candidate=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
frozen=out/'language_probe';shutil.copy2(candidate,frozen)
(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(candidate),sha256=oracle.sha256(frozen),binding='Provisional frozen exploration replay; formal recorded build evidence separate.')))
(out/'source-identities-before.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in lang.source_paths()}))
jobs=[]
for number in range(1,7):
 baseline=contract.ROOT/f'target/m2/stage8-exploration-{number:02d}'
 for case in json.loads((baseline/'matrix.json').read_bytes()):jobs.append((baseline,case))
def run(job):
 baseline,c=job;b=baseline/'cases'/c['id'];folder=out/baseline.name/c['id'];folder.mkdir(parents=True)
 meta=json.loads((baseline/'oracle.json').read_bytes());j=json.loads((b/'java.process.json').read_bytes());source=b/'input.pkl'
 assert source.read_bytes()==c['source'].encode()
 r=lang.capture([str(frozen),*lang.expression_arguments(source,c['expression'])],folder,'rust',meta['environment'])
 status=lang.status(dict(expected_outcome='success' if j['exit_code']==0 else 'failure'),j,r,*[(b/f'java.{ch}.bin').read_bytes() for ch in ['stdout','stderr']],*[(folder/f'rust.{ch}.bin').read_bytes() for ch in ['stdout','stderr']],(b/'java.outcome.bin').read_bytes())
 return dict(id=c['id'],baseline=str(baseline),status=status,rust=r)
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,jobs))
(out/'results.json').write_bytes(contract.encoded(results))
(out/'source-identities-after.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in lang.source_paths()}))
from collections import Counter
print(dict(Counter(r['status'] for r in results)))
for r in results:
 if r['status']!='pass':print(Path(r['baseline']).name,r['id'],r['status'])
