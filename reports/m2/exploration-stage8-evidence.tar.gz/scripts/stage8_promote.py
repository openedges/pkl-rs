from pathlib import Path
import json,sys
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
selection=contract.ROOT/contract.SELECTION;current=json.loads(selection.read_bytes())
baseline=Path('target/m2/stage8-selection-baseline-01');original=json.loads((baseline/'cases.json').read_bytes())
assert current==original and len(current['cases'])==874
for c in original['cases']:assert (contract.ROOT/c['input']).read_bytes()==(baseline/'inputs'/c['input']).read_bytes()
replay=json.loads((Path(sys.argv[1])/'results.json').read_bytes())
passes={(Path(r['baseline']).name,r['id']) for r in replay if r['status']=='pass'}
promoted=[];unselected=[]
for number in range(1,7):
 directory=Path(f'target/m2/stage8-exploration-{number:02d}')
 for c in json.loads((directory/'matrix.json').read_bytes()):
  choose=(number==1 and (c['id'].startswith('typed-') or c['family']=='default-controls')) or (number==2 and c['family']=='default-controls') or (number==3 and c['id']!='typed-default-own-before-parent') or (number==4 and c['id']!='dynamic-hash-warm-b-cache-order') or number==6
  if not choose:
   reason='Outside bounded Stage 8: cached fifth insertion and Java hash bucket/cache-order identity gaps remain failed; control observations retained.' if number==1 else 'Outside bounded Java hash bucket/cache-order identity closure; original outcomes retained.' if c['family']=='listing-cache-order' else 'Equivalent selected ordering reproduction captured in exploration 03.' if number==2 else 'Empty-body identity skips force; redundant identity observation retained.' if number==3 else 'Preexisting generic nested-let diagnostic frame gap remains failed; initializer-based warmed hash probe separately observed and selected.' if number==4 else 'Listing/Mapping local ObjectMember cache asymmetry remains failed and unimplemented; Dynamic control retained.'
   unselected.append(dict(id=c['id'],exploration=str(directory),reason=reason));continue
  assert (directory.name,c['id']) in passes,(directory,c['id'])
  identifier='equality-stage8-'+c['id'];file=Path('tests/fixtures/m2')/(identifier+'.pkl');assert not file.exists()
  folder=directory/'cases'/c['id'];process=json.loads((folder/'java.process.json').read_bytes());outcome=(folder/'java.outcome.bin').read_bytes();assert not process['timed_out']
  expected='success' if process['exit_code']==0 else 'failure';assert outcome==b'success\n' if expected=='success' else process['exit_code']==1 and lang.valid_exception_outcome(outcome)
  requirements=['semantic:operators','semantic:objects','semantic:collections','semantic:lazy-evaluation','semantic:diagnostics']
  if c['id'].startswith('typed-'):requirements.extend(['semantic:classes','semantic:types'])
  if 'inherited' in c['id'] or 'parent' in c['id'] or 'amendment' in c['id']:requirements.append('semantic:amendment')
  row=dict(id=identifier,input=str(file),expression=c['expression'],requirements=requirements,expected_outcome=expected)
  file.write_bytes(c['source'].encode());current['cases'].append(row)
  promoted.append(dict(id=identifier,exploration=str(directory),exploratory_case_id=c['id'],input_sha256=oracle.sha256(file)))
assert len(promoted)==33,len(promoted)
groups=[(['typed-default-unequal','typed-ordinary-unequal','typed-default-inherited'],'Renaming a regular typed Int property to default and inheriting its declaration preserve unequal explicit override comparison.'),(['typed-default-equal','typed-default-override-equal'],'Comparing matching regular typed default values remains equal under an identical explicit override.'),(['typed-cache-warm-class-order','typed-cache-amendment-class-order'],'Typed class declaration order selects the unequal Int before a nested Mapping key comparison despite successful member prewarming or reordered assignments.')]
for kind in ['dynamic','mapping','listing']:groups.append(([kind+'-cache-cold-comparison-order',kind+'-cache-warm-a-comparison-order'],'Successfully reading the first declared scalar '+kind+' member preserves the same unequal result and cache comparison order.'))
byid={c['id']:c for c in current['cases']}
for ids,domain in groups:
 ids=['equality-stage8-'+x for x in ids];relation=dict(kind='equal-stdout',case_ids=ids,domain=domain)
 for identifier in ids:
  byid[identifier]['metamorphic_relation']=relation;byid[identifier]['requirements'].append('semantic:generated-verification')
selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
assert current['cases'][:874]==original['cases']
for c in original['cases']:assert (contract.ROOT/c['input']).read_bytes()==(baseline/'inputs'/c['input']).read_bytes()
Path('target/m2/stage8-promotion.json').write_bytes(contract.encoded(dict(selected_count=len(promoted),total_selected=len(current['cases']),provenance=promoted,unselected=unselected,metamorphic_relations=len(groups),original_874_definitions_and_bytes_preserved=True,replay=str(Path(sys.argv[1]).resolve()))))
print('Promoted',len(promoted),'total',len(current['cases']),'relations',len(groups))
