"""Compare every retained trace payload with the closed Stage38 checkpoint."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'pkl-rs/target/m2/stage38-trace-final-02'
NEW = ROOT / 'target/m2/stage39-trace-final-01'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def payloads(path):
    return {p.relative_to(path).as_posix(): p for p in path.rglob('*.bin') if p.is_file()}

old = json.loads((OLD / 'report.json').read_bytes())
new = json.loads((NEW / 'report.json').read_bytes())
old_rows = {(row['id'], row['repeat']): row for row in old['results']}
new_rows = {(row['id'], row['repeat']): row for row in new['results']}
assert list(old_rows) == list(new_rows)
assert old['cases'] == new['cases'] and old['manifest_sha256'] == new['manifest_sha256']
differences = []
unchanged_files = {'java': 0, 'rust': 0}
for identifier, repeat in old_rows:
    before = old_rows[identifier, repeat]
    after = new_rows[identifier, repeat]
    if before['status'] != after['status']:
        differences.append(dict(id=identifier, repeat=repeat, channel='comparison-status',
                                before=before['status'], after=after['status']))
    for runtime in ['java', 'rust']:
        relative = Path('cases') / identifier / str(repeat) / runtime
        left, right = payloads(OLD / relative), payloads(NEW / relative)
        assert set(left) == set(right), (identifier, repeat, runtime)
        for name in sorted(left):
            if left[name].read_bytes() == right[name].read_bytes():
                unchanged_files[runtime] += 1
            else:
                differences.append(dict(id=identifier, repeat=repeat, runtime=runtime,
                                        channel=name, before_sha256=digest(left[name]), after_sha256=digest(right[name])))
report = dict(scope='Full original42 trace cases, two repetitions: raw payload/process .bin regression comparison. No candidate/oracle execution.',
              old_report=dict(path=str(OLD / 'report.json'), sha256=digest(OLD / 'report.json')),
              new_report=dict(path=str(NEW / 'report.json'), sha256=digest(NEW / 'report.json')),
              cases=len(new['cases']), executions=len(new_rows),
              old_status_counts=old['status_counts'], new_status_counts=new['status_counts'],
              exact_case_contracts_preserved=True, exact_payload_file_sets_preserved=True,
              unchanged_files=unchanged_files, differences=differences,
              no_candidate_raw_regressions=not any(row.get('runtime') == 'rust' or row.get('channel') == 'comparison-status' for row in differences),
              known_oracle_errors_remain_failures=True,
              helper_sha256=digest(Path(__file__)))
(OUT / 'trace-report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'differences'}, sort_keys=True))
print('raw differences:', len(differences))
raise SystemExit(0 if report['no_candidate_raw_regressions'] else 1)
