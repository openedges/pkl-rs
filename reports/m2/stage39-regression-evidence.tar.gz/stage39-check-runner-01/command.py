"""Retain complete wrapper stdout/stderr and actual terminal status."""
from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[3]
label, *command = sys.argv[1:]
assert label and '/' not in label and command
output = root / 'target/m2/stage39-command-captures-01' / label
output.mkdir(parents=True, exist_ok=False)
started = time.time()
with (output / 'stdout.bin').open('wb') as stdout, (output / 'stderr.bin').open('wb') as stderr:
    result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr)
record = dict(command=command, cwd=str(root), host=platform.platform(),
              started_epoch=started, elapsed_seconds=time.time() - started,
              exit_code=result.returncode,
              helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              channels={name: dict(bytes=(output / (name + '.bin')).stat().st_size,
                                   sha256=hashlib.sha256((output / (name + '.bin')).read_bytes()).hexdigest())
                        for name in ['stdout', 'stderr']})
(output / 'process.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps(record, sort_keys=True), flush=True)
raise SystemExit(result.returncode)
