"""Record required local checks against one unchanged source snapshot."""
from pathlib import Path
import hashlib
import json
import os
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import m2_language

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

output = Path(sys.argv[1]).absolute()
assert output.is_relative_to(ROOT / 'target/m2')
output.mkdir(parents=True, exist_ok=False)
paths = set(m2_language.source_paths(ROOT))
excluded = {ROOT / 'tools/platform/node_modules', ROOT / 'target', ROOT / '.cache'}
for folder in ['tools', 'tests/fixtures', 'compatibility']:
    for directory, children, names in os.walk(ROOT / folder, topdown=True):
        children[:] = sorted(name for name in children
                             if Path(directory) / name not in excluded and name != '__pycache__')
        for name in names:
            path = Path(directory) / name
            if path.is_file() and path.suffix in {'.py', '.java', '.json', '.mjs', '.pkl', '.toml'}:
                paths.add(path.relative_to(ROOT).as_posix())
manifest = json.loads((ROOT / 'compatibility/m2-language.json').read_bytes())
paths.update(row['input'] for row in manifest['cases'] if row.get('adapter') == 'language-module-eval')
hashes = {}
for name in sorted(paths):
    data = (ROOT / name).read_bytes()
    hashes[name] = sha(data)
    target = output / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

checks = [
    ('rust-version', ['rustc', '-Vv']),
    ('references', ['cargo', 'xtask', 'verify']),
    ('format', ['cargo', 'fmt', '--all', '--', '--check']),
    ('clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('rust-tests', ['cargo', 'test', '--workspace', '--locked']),
    ('wasm-check', ['cargo', 'check', '-p', 'pkl-runtime', '--target', 'wasm32-unknown-unknown', '--locked']),
    ('python-tests', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-v']),
    ('manifest', [sys.executable, 'tools/m2_manifest.py', '--check']),
    ('portable-driver-tests', ['node', '--test', 'tools/platform/compare-language-cases.test.mjs',
                              'tools/platform/module-eval-session.test.mjs']),
]
report = dict(schema=1, scope='Stage39 required local checks; no full-language compatibility claim.',
              host=platform.platform(), python=sys.version, cwd=str(ROOT),
              runner_sha256=sha(Path(__file__).read_bytes()),
              source_sha256=hashes, checks=[])
(output / 'run.py').write_bytes(Path(__file__).read_bytes())
for name, command in checks:
    started = time.time()
    with (output / (name + '.stdout.bin')).open('wb') as stdout, (output / (name + '.stderr.bin')).open('wb') as stderr:
        try:
            child = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=1800)
            code, timeout = child.returncode, False
        except subprocess.TimeoutExpired:
            code, timeout = None, True
    row = dict(name=name, command=command, exit_code=code, timed_out=timeout,
               started_epoch=started, elapsed_seconds=time.time() - started,
               stdout_sha256=sha((output / (name + '.stdout.bin')).read_bytes()),
               stderr_sha256=sha((output / (name + '.stderr.bin')).read_bytes()))
    report['checks'].append(row)
    write(output / 'partial-report.json', report)
    print(json.dumps(row, sort_keys=True), flush=True)
report['source_changes'] = [name for name, digest in hashes.items()
                            if not (ROOT / name).is_file() or sha((ROOT / name).read_bytes()) != digest]
report['source_stability'] = not report['source_changes']
report['passed'] = report['source_stability'] and all(row['exit_code'] == 0 and not row['timed_out'] for row in report['checks'])
write(output / 'report.json', report)
raise SystemExit(0 if report['passed'] else 1)
