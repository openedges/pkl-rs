# Stage2 frontend and modifier review

This review used the frozen stage2 candidate copied at `target/m2/language-stage2-final/artifacts/language_probe` and pinned Java 0.32.0. `provenance.json` records the exact candidate hash, oracle identity/environment, and reviewed source hashes. Candidate identity remained stable across these probes. Each case uses the identical input path for Java and Rust; raw stdout, stderr, exit status, sidecar outcome, and commands are retained under `cases/`. No corpus or source files were changed during acquisition. Later corrections authorized by the root agent are separate from these original observations.

Eight probes produced one raw equality, three false successes, two additional diagnostic differences, and two explicit unsupported-feature differences. This is a focused review, not a complete language verdict.

| Priority | Probe | Java | Frozen Rust | Finding |
| --- | --- | --- | --- | --- |
| High | `abstract-nullable-force` | Abstract-property error | Success: `null` | An abstract property must not receive its nullable type default. |
| High | `abstract-literal-force` | Abstract-property error | Success: `default` | An abstract property must not receive its string-literal type default. |
| High | `duplicate-const-capture` | Non-const property-reference error | Success: `42` | Repeated modifiers use additive flags, not token presence or bitwise OR. |
| Medium | `abstract-method-force` | Abstract-method error | Undefined-property error | Missing abstract methods need a distinct lazy failure with authored qualified identity. |
| Medium | `named-class-type-error` | Expected `example.named#C` | Expected `C` | Member frames preserve module identity, but the type descriptor's display name loses it. |
| Explicit gap | `fixed-override` | Missing `fixed` override error | `fixed modifiers are not implemented` | Compiler already rejects the unsupported flag; it does not silently accept the override. |
| Explicit gap | `hidden-direct-read` | Success: `42` | `hidden modifiers are not implemented` | Compiler already reports this feature as unsupported, even though direct member access is valid Java behavior. |
| Control | `unused-abstract-members` | Success: `42` | Success: `42` | Declaring unused abstract members is valid; a fix must retain laziness. |

## Evidence and implementation implications

`AstBuilder.visitClassProperty` selects `CannotInvokeAbstractPropertyNode` before ordinary absent-value default handling. `visitClassMethod` similarly selects `CannotInvokeAbstractFunctionNode`. The frozen compiler accepts all `Abstract` tokens in `validate_modifiers`, but `default_property` delegates directly to `default_type`, and an uninitialized method reaches the generic undefined instruction. Prefer lazy abstract property/method instructions to rejecting every abstract declaration: the control proves that unused declarations must continue to work.

`AstBuilder.doVisitModifiers` uses `result += modifier`; `VmModifier` defines `ABSTRACT=1`, `OPEN=2`, `LOCAL=4`, `HIDDEN=8`, `EXTERNAL=16`, `FIXED=32`, and `CONST=64`. Consequently, repeated `const` produces `128`, without the const bit; repeated `open` produces the local bit; repeated `abstract` produces the open bit. A shared wrapping-add flag helper should drive runtime class open/abstract/local metadata and member const/local metadata, together with resolver const barriers and modifier-combination checks. An isolated repeated-const special case would preserve other false results.

There is an important static/runtime locality distinction: `registerClassScopeNames` uses raw `hasLocalModifier` to register property/method lexical names, while actual member locality comes from computed flags. Preserve that distinction instead of changing every `Member.local` meaning. Some repeated modifiers provoke upstream internal errors; retain those oracle outcomes rather than converting them into successful compatibility cases. Derived diagnostics that request an absent original modifier token must never panic Rust.

`hidden` and `fixed` are accepted syntactically but explicitly rejected by compiler `validate_modifiers`. Keeping those failures explicit is appropriate until visibility/rendering and fixed-override/amendment semantics are implemented. They remain required feature gaps, not successful compatibility cases. Abstract member handling cannot receive the same blanket support claim until forcing produces the correct lazy error.

Class type descriptors currently use the short declaration name. Their human-readable type identity must include the effective module name from a declaration or the supplied module context; class identity used for matching should remain separate from that display label. The named-module probe isolates this difference: all frames and source spans match except the expected type label.

## Recommended regression coverage

Add the four high-impact/new-identity cases to fresh pinned Java/Rust differential evidence. Add a lazy abstract-method failure and keep the unused-abstract control. Exercise repeated `open` with extension, repeated `abstract` with instantiation, repeated `local` without allowing a Rust panic, and repeated `const` inside class captures. Keep `hidden`/`fixed` cases in the explicit unimplemented inventory until supported; do not weaken or remove their failures to make a completion gate green.

The root agent authorized corrections after this acquisition. Those changes do not overwrite these original raw results, and require a fresh candidate and fresh evidence directory.

## Follow-up probes after source-freeze release

Three additional pinned Java observations are preserved under `followup/`. Repeated `abstract` on a class produces the open bit and permits instantiation (`42`); repeated `open` produces the local bit, so extending that class fails as a non-open class. These confirm additive carry behavior beyond `const`.

The last probe found another false-success risk: `function value(): Int` followed by unrelated `result = 42` fails eagerly in Java with `Method value is missing a body`, an authored `#value` header frame, and no REPL frame. A non-abstract missing method body must be rejected during AST validation even if unused. This also applies when repeated abstract tokens carry into a non-abstract flag. The root agent authorized a focused resolver correction and a fresh selected regression; the original Java bytes remain under `followup/missing-unused-method-body/`.
