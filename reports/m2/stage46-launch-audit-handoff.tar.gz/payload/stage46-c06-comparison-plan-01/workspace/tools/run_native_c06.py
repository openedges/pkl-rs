"""Run unchanged Java-derived native comparison groups on the explicitly pinned C06 release."""
from pathlib import Path
import argparse,concurrent.futures,hashlib,json,os,subprocess,time
BASE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46/target/m2')
FILE_TOOL=BASE/'stage46-file-triple-consumer-02/workspace/tools/m2_file_triple_compare.py'
RESOURCE_TOOL=BASE/'stage46-resource-native-consumer-04/workspace/tools/m2_resource_compare.py'
TOOL_PINS={str(FILE_TOOL):'9d425bbaec4778de6af1b6d6278e153895b85f1c6aa53a08d1e362c49a0311f5',str(RESOURCE_TOOL):'073bdd53c503f43bdcaf9ef5c4dfc18742701a7271c695953b244b21dd32846a'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,value):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--release-sha256',required=True);parser.add_argument('--file-release-sha256',required=True);args=parser.parse_args();candidate=BASE/'stage46-implementation-01/resource-candidate-build-06';release_path=candidate/'release.json';file_path=candidate/'file-probe-release.json'
 # Both release identities must be supplied by the producer after immutable release.
 if sha(release_path)!=args.release_sha256 or sha(file_path)!=args.file_release_sha256:raise ValueError('C06 release identity differs')
 release=json.loads(release_path.read_bytes());file_release=json.loads(file_path.read_bytes())
 for tool,pin in TOOL_PINS.items():
  if sha(Path(tool))!=pin:raise ValueError('comparison tooling differs')
 for metadata in [release,file_release]:
  if Path(metadata['source_map']).resolve()!=candidate/'source-after.json'or Path(metadata['source_snapshot']).resolve()!=candidate/'sources':raise ValueError('candidate source binding is not C06')
  if sha(Path(metadata['source_map']))!=metadata['source_map_sha256']:raise ValueError('C06 source map digest differs')
  if Path(metadata['artifact']).resolve().parent!=candidate/'artifacts'or sha(Path(metadata['artifact']))!=metadata['artifact_sha256']:raise ValueError('artifact is not the released C06 binary')
 if release['source_map_sha256']!=file_release['source_map_sha256']:raise ValueError('release source bindings differ')
 if Path(release['artifact']).name!='stage46_resource_probe'or Path(file_release['artifact']).name!='stage46_file_probe':raise ValueError('wrong probe selected')
 for name in ['module_eval_probe','stage46_resource_probe','stage46_file_probe']:
  item=release['artifacts'][name];path=Path(item['path'])
  if path.resolve()!=candidate/'artifacts'/name or sha(path)!=item['sha256']:raise ValueError('released probe identity differs: '+name)
 launch=BASE/'stage46-c06-native-launch-01';jobs=[]
 for group in ['triple-dot','triple-order','static-error','generator-owner','header-producer','supertype-producer','module-capability','logical-binding']:
  fixture=BASE/('stage46-file-triple-consumer-02/fixtures/logical-binding-02'if group=='logical-binding'else'stage46-file-triple-consumer-01/fixtures/'+group);output=BASE/('stage46-c06-file-'+group+'-native-01');jobs.append(('file-'+group,['python3','-B',str(FILE_TOOL),'compare','--fixture',str(fixture),'--release',str(file_path),'--output',str(output)],output))
 for group,oracle in [('resource','stage46-resource-oracle-01'),('authority','stage46-uri-authority-oracle-01'),('base64','stage46-base64-oracle-01'),('extra','stage46-resource-extra-oracle-01')]:
  output=BASE/('stage46-c06-'+group+'-native-01');jobs.append((group,['python3','-B',str(RESOURCE_TOOL),'--oracle',str(BASE/oracle),'--release',str(release_path),'--output',str(output)],output))
 if launch.exists()or any(output.exists()for _,_,output in jobs):raise ValueError('fresh C06 output root already exists; do not restart or overwrite')
 launch.mkdir();put(launch/'exclusions.json',{'beforeWalk':True,'exactPrunePaths':[],'scope':'Twelve explicit fixture/oracle groups and C06 frozenrelease only; no originalacquisition,oldcandidateexecution,source/cachewalk or productionwrites'})
 put(launch/'release-binding.json',{'release':str(release_path),'releaseSha256':sha(release_path),'fileRelease':str(file_path),'fileReleaseSha256':sha(file_path),'sourceMapSha256':release['source_map_sha256'],'artifacts':release['artifacts'],'toolPins':TOOL_PINS})
 def run(job):
  name,command,output=job;started=time.time_ns()
  with(launch/(name+'.stdout.bin')).open('wb')as stdout,(launch/(name+'.stderr.bin')).open('wb')as stderr:
   process=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'));put(launch/(name+'.launch.json'),{'pid':process.pid,'launchStartedUnixNs':started,'launchRecordedUnixNs':time.time_ns(),'command':command,'cwd':str(Path.cwd())});code=process.wait()
  row={'name':name,'pid':process.pid,'exitCode':code,'finishedUnixNs':time.time_ns(),'output':str(output),'reportSha256':sha(output/'report.json')if(output/'report.json').exists()else None};put(launch/(name+'.terminal.json'),row);print(json.dumps(row),flush=True);return row
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:records=list(pool.map(run,jobs))
 put(launch/'report.json',{'records':records,'scope':'Raw comparison outcomes remain in per-group reports; constructor16 and capabilitySPIprojection boundaries must be separately accounted; no blanket full-pass claim'})
 if sha(release_path)!=args.release_sha256 or sha(file_path)!=args.file_release_sha256:raise ValueError('released C06 metadata changed')
 return 0 if all(row['reportSha256']is not None and row['exitCode']in [0,1]for row in records)else 1
if __name__=='__main__':raise SystemExit(main())
