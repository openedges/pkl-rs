"""Freeze the next shared candidate and record actual build outputs."""
from pathlib import Path
import datetime, hashlib, json, os, platform, re, shutil, subprocess

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n')
def snapshot():
    paths = {p for p in (ROOT/'crates').rglob('*') if p.is_file() and p.suffix in ('.rs','.pkl','.toml')}
    paths.update(p for p in (ROOT/'xtask').rglob('*') if p.is_file() and p.suffix in ('.rs','.toml'))
    paths.update(ROOT/p for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','crates/pkl-runtime/src/stdlib/modules.txt'])
    paths.update(p for p in (ROOT/'.cargo').rglob('*') if p.is_file())
    # Literal compile-time fixture dependencies are inputs too, including the
    # independently acquired Java diagnostic bytes used by runtime regressions.
    for source in tuple(paths):
        if source.suffix == '.rs':
            for relative in re.findall(r'include_(?:str|bytes)!\s*\(\s*"([^"]+)"', source.read_text()):
                dependency = (source.parent/relative).resolve()
                assert dependency.is_relative_to(ROOT) and dependency.is_file(), str(dependency)
                paths.add(dependency)
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
assert not (OUT/'report.json').exists()
core_freeze = ROOT/'target/m2/stage51-collection-core-diagnostic-freeze-04/sources.json'
assert sha(core_freeze) == 'f9b5caae9a978104624c78340446bf698943af1404911dcf6c453b39df39f6f2'
core_deltas = []
for source in json.loads(core_freeze.read_bytes()):
    assert sha(ROOT/source['path']) == source['sha256'], source['path']
assert sha(ROOT/'crates/pkl-runtime/examples/stage51_collection_probe.rs') == 'ffa2bd0ab740f701abc58d948f98518ea2fba7679d28a4b5e638de5e40836316'
before = snapshot(); save('sources-before.json', before)
for name, digest in before.items():
    destination = OUT/'sources'/name; destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(ROOT/name,destination); assert sha(destination)==digest
node = Path(shutil.which('node')).resolve()
bindgen = (ROOT/'.cache/m1-tools/bin/wasm-bindgen').resolve()
report = {'schema':1,'scope':'Frozen Stage51 native/N-API/Wasm build; required checks, Java comparisons and actual platform execution are separate.',
          'startedUtc':now(),'cwd':str(ROOT),'host':platform.platform(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'runnerSha256':sha(Path(__file__)),'coreFreezeSha256':sha(core_freeze),'authorizedCoreFreezeDeltas':core_deltas,'node':{'path':str(node),'sha256':sha(node)},
          'bindgen':{'path':str(bindgen),'sha256':sha(bindgen)},'environment':{k:os.environ.get(k) for k in ['RUSTUP_TOOLCHAIN','CARGO_TARGET_DIR','JAVA_HOME','PKL_ORACLE_JAVA']},
          'commands':[],'complete':False}
save('report.json',report)
def execute(name,argv):
    row={'name':name,'argv':list(map(str,argv)),'startedUtc':now()}
    with (OUT/(name+'.stdout.bin')).open('wb') as stdout,(OUT/(name+'.stderr.bin')).open('wb') as stderr:
        child=subprocess.Popen(row['argv'],cwd=ROOT,stdout=stdout,stderr=stderr);row['pid']=child.pid
        save('active.json',row); print('START',name,child.pid,flush=True);row['exitCode']=child.wait()
    row.update(finishedUtc=now(),stdoutSha256=sha(OUT/(name+'.stdout.bin')),stderrSha256=sha(OUT/(name+'.stderr.bin')))
    report['commands'].append(row);save('report.json',report);print('DONE',name,row['exitCode'],flush=True)
    if row['exitCode']:raise RuntimeError(name+' failed')
try:
    execute('rust-version',['rustc','-Vv'])
    execute('node-version',[node,'--version'])
    execute('bindgen-version',[bindgen,'--version'])
    assert (OUT/'bindgen-version.stdout.bin').read_bytes()==b'wasm-bindgen 0.2.108\n'
    execute('native-build',['cargo','build','-p','pkl-runtime','--example','stage51_collection_probe','--example','language_probe','--locked'])
    execute('napi-build',['cargo','build','-p','pkl-napi','--release','--locked'])
    execute('wasm-build',['cargo','build','-p','pkl-wasm','--target','wasm32-unknown-unknown','--release','--locked'])
    execute('wasm-bindgen',[bindgen,'--target','web','--out-dir',OUT/'wasm',ROOT/'target/wasm32-unknown-unknown/release/pkl_wasm.wasm'])
    shutil.copy2(ROOT/'target/debug/examples/stage51_collection_probe',OUT/'stage51_collection_probe')
    shutil.copy2(ROOT/'target/debug/examples/language_probe',OUT/'language_probe')
    shutil.copy2(ROOT/'target/release/libpkl_napi.dylib',OUT/'pkl_napi.node')
    artifacts = {key:{'path':str(OUT/name),'sha256':sha(OUT/name)} for key,name in {
        'native':'stage51_collection_probe','napi':'pkl_napi.node','wasmJs':'wasm/pkl_wasm.js','wasm':'wasm/pkl_wasm_bg.wasm'}.items()}
    after=snapshot();save('sources-after.json',after);report['sourceStable']=before==after
    assert before==after
    assert sha(node)==report['node']['sha256'] and sha(bindgen)==report['bindgen']['sha256']
    proof={'schema':1,'status':'CLOSED','sourceStable':True,'artifacts':artifacts,'sources':before,'snapshotRoot':str(OUT/'sources')}
    save('build-proof.json',proof);report['buildProofSha256']=sha(OUT/'build-proof.json')
    report['languageProbe']={'path':str(OUT/'language_probe'),'sha256':sha(OUT/'language_probe')}
    report['complete']=True
except Exception as error:
    report['error']=repr(error)
finally:
    report['finishedUtc']=now();save('report.json',report);save('active.json',{'complete':True,'buildPassed':report['complete']})
    print(json.dumps(report),flush=True)
raise SystemExit(0 if report['complete'] else 1)
