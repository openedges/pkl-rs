"""Capture a target-only acquisition or replay process without changing its bytes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command
if command and command[0] == '--':
    command = command[1:]
if not command:
    parser.error('a command is required')
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
(output/'runner.py').write_bytes(Path(__file__).read_bytes())
started = time.monotonic_ns()
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
def pump(source, destination, visible):
    with destination.open('xb') as stream:
        while True:
            data = source.read1(65536)
            if not data:
                break
            stream.write(data)
            stream.flush()
            visible.write(data)
            visible.flush()
threads = [threading.Thread(target=pump, args=(process.stdout, output/'stdout.bin', sys.stdout.buffer)),
           threading.Thread(target=pump, args=(process.stderr, output/'stderr.bin', sys.stderr.buffer))]
for thread in threads:
    thread.start()
returncode = process.wait()
for thread in threads:
    thread.join()
row = {'command': command, 'cwd': str(Path.cwd()), 'exit_code': returncode, 'timed_out': False,
       'elapsed_ns': time.monotonic_ns() - started, 'python': sys.executable}
for channel in ['stdout', 'stderr']:
    data = (output/(channel+'.bin')).read_bytes()
    row[channel+'_sha256'] = hashlib.sha256(data).hexdigest()
    row[channel+'_bytes'] = len(data)
(output/'process.json').write_text(json.dumps(row, indent=2, sort_keys=True)+'\n')
sys.exit(returncode)
