"""Record root review of the frozen Stage23 implementation; not a test runner."""
from pathlib import Path
import hashlib,json
root=Path.cwd()
paths=['crates/pkl-runtime/src/'+name for name in ['diagnostic_values.rs','evaluation.rs','heap.rs','resolver.rs','stdlib_sources.rs','stdlib/base.pkl','strict_map.rs','vm.rs','vm/collections.rs','vm/equality.rs','vm/generics.rs','vm/reference.rs','vm/typecheck.rs']]
paths+=['crates/pkl-runtime/tests/m2_set_lifecycle.rs']
record=dict(status='pass',scope='Root source review of strict Set production changes, shared renderer integration and native lifecycle assertions. Root authored diagnostic_values.rs/evaluation.rs and the Set ToString dispatch branch in vm.rs, so those portions are self-review; the lifecycle and runtime reviewers independently reviewed them. Root also authored documentation and final verification orchestration.',source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},self_reviewed_sources=paths[:2]+['crates/pkl-runtime/src/vm.rs: Set ToString branch'],independently_reviewed_sources=paths[2:],findings=[
 'Set is a distinct collection kind using the existing slot-only Paguro trie. Both internal set_entries and insertion-order cached elements are traced by the owning heap object.',
 'Constructor evaluation proceeds argument by argument through separate PrepareSetElement and AddSetElement instructions. Empty lookup does not force a query hash, duplicates skip insertion, and new elements are prepared again before insertion.',
 'Lookup and insertion retain distinct trie hash guards and boxed equality. Rehashing stored leaves precedes trie mutation; pending builders, query values and equality candidates remain on VM roots through suspension and retry.',
 'Set equality checks table size and traverses the right table with left-table membership. Hashing adds signed 32-bit element hashes in trie order; canonical structural keys use the table rather than insertion order. Public iteration uses element order without an additional iterator hash.',
 'Set<T> schedules eager checks through the shared continuation and returns the original Set rather than replacing mutable hash keys with lazy collection wrappers. Empty defaults avoid constructing an element default, and Set amendments retain external-class diagnostics.',
 'Set ToString and its native toString method use multiline cache-only rendering with the Java signed-32-bit UTF-16 length bound. Nested objects inherit indentation; Map strings and bounded diagnostic snapshots retain single-line layout. The adapter still accepts only property paths and selected scalar/Reference/type-alias/Map/Set results.',
 'Set.contains arity diagnostics use the exact bundled pinned base source. Generic null diagnostics and uninitialized-property spans have independent fresh List/Map/Listing/primitive controls; prior selected cases remain unchanged.',
 'Strict collection spread validates the destination before iteration, including empty List/Set sources. The Mapping diagnostic retains complete source, value and hint bytes in differential evidence.',
 'Eight native tests cover pending constructor and membership/comparison roots, nested Host failure and retry, repeated cancellation, evaluator isolation, stale handles, retained declaration/cache plateaus and terminal cleanup. Deep Set has an explicit separate GC/event-budget contract while all historical small-stack tests keep their original conditions.'
],limits=[
 'Source review requires separate recorded Java comparisons, workspace tests and actual target execution for behavioral evidence.',
 'General compound output controls remain unselected failures; scalar observation replacements retain the original sources and raw failures and do not establish complete rendering support.',
 'Deep Set every-yield timeout and the lower event-cap failure remain failed experiments. The periodic-GC passing experiment does not establish the same conditions or Java execution-time/peak-RSS parity.',
 'No concrete Java Set internal-table versus element-order divergence witness was established; tracing both structures is implementation review, not a claim of tested hidden-entry retention.',
 'Higher-order Set and full Map APIs, JVM identity-dependent ordering, remaining type/Reference/module gaps, nested Map iterator rehash effects during stringification, recursive renderer resource limits, complete language/API/platform coverage and performance/memory parity remain open.'
])
out=root/'target/m2/stage23-root-review-final-01.json'
with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('Reviewed source files:',len(paths))
