from pathlib import Path
import json,hashlib,stat,collections
O=Path(__file__).resolve().parent;M=O.parents[2];T=O.parent/'stage48-c01-bootstrap-typed-c-audit-02';S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');h=lambda b:hashlib.sha256(b).hexdigest()
inputs=json.loads((O/'inputs-before.json').read_bytes());typedinputs=json.loads((T/'typed-bootstrap-inputs.json').read_bytes());final=json.loads((O/'report.json').read_bytes());tr=json.loads((T/'typed-bootstrap-report.json').read_bytes())
assert json.loads((O/'execution-01/report.json').read_bytes())['exitCode']==0
assert json.loads((T/'typed-execution-01/report.json').read_bytes())['exitCode']==0
for p,row in inputs.items():assert h(Path(row['readFrom']).read_bytes())==row['sha256']
for p,row in typedinputs.items():assert h(Path(p).read_bytes())==row['sha256']
unit=S/'target/m2/stage48-bootstrap-typed-provider-tests-01';receipt=(unit/'outer-terminal.json').read_bytes();receiptdata=json.loads(receipt)
assert receiptdata['exitCode']==0 and receiptdata['immediateTerminal'] and receiptdata['chunkId']=='d27a51'
(O/'late-unit-outer-terminal.json').write_bytes(receipt)
late={'original':str(unit/'outer-terminal.json'),'sha256':h(receipt),'scope':'Late source-provenance receipt added after independent missing-receipt finding. Preserve original failed audit and original report/stdout/stderr; do not represent receipt as present during earlier readback.','boundReportSha256':h((unit/'report.json').read_bytes())}
(O/'late-unit-receipt-binding.json').write_text(json.dumps(late,indent=2)+'\n')
raw=json.loads((O/'raw-module-requests.json').read_bytes());agg={}
for section in ['primaryThreeGroups','legacyAndBootstrap']:
 for row in raw[section]:
  key=(row['group'],row['target']);counter=agg.setdefault(key,collections.Counter());counter.update((r.get('module',r)).get('kind')for r in row['requests'])
requests=[{'group':k[0],'target':k[1],'counts':dict(v)}for k,v in sorted(agg.items())]
(O/'request-count-summary.json').write_text(json.dumps(requests,indent=2)+'\n')
cand=S/'target/m2/stage48-implementation-01/admission-candidate-build-01';links=json.loads((cand/'source-links.json').read_bytes());modechecks=[]
for n,row in links.items():
 p=cand/'sources'/n;assert p.is_symlink() and stat.S_IMODE(p.lstat().st_mode)==row['mode'];modechecks.append({'path':str(p),'mode':row['mode'],'target':row['target']})
(O/'literal-link-mode-checks.json').write_text(json.dumps(modechecks,indent=2)+'\n')
final.update({'typedBootstrapFollowup':{'reportPath':str(T/'typed-bootstrap-report.json'),'reportSha256':h((T/'typed-bootstrap-report.json').read_bytes()),'results':tr['results'],'actualExitCode':1,'fullStrictCompatibilityPassed':False,'lateTransportUnitReceipt':late},'recommendation':{'preserveOriginalStrictFailures':True,'proposedAdditiveReportFields':{'apiRawChannelsMatch':'Separately report all result/callback payload, UTF16 and available exit channels. Preserve legacy rawMatch aggregate and original statuses.','javaObservedModuleSpiCounts':{'observedKinds':['resolve','load-source'],'source':'Authenticated existing Java counters resolve/source, not policy SPI instrumentation.','projectionMatch':'Derived audit-only projection; currently true for all count-bound cases.'},'policyTraceComparison':{'state':'unobserved-in-original-fixture','actualCheckImportRequests':'Always retain full ordered raw requests; never add invented zero/exact expected counts.'}},'newToolContractScope':'A future schema may expose the observed SPI projection separately; it must not reclassify these original captures as strict pass or imply Java policy trace equivalence.'},'sourceBindingQualification':{'m1OwnCollectorMissingCargoConfig':True,'supplementalCandidateFullMapContainsCargoConfig':True,'candidateCargoConfigSha256':json.loads((cand/'source-after.json').read_bytes())['.cargo/config.toml'],'meaning':'M1 own sources.json does not directly capture .cargo/config.toml; C01 wrapper whole-map before/after plus frozen snapshot provide separate supplemental binding. Do not relabel as direct M1 capture.','laterConsumerChanges':'C01 original immutable source/read mapping is separate from typed helper/test delta.'},'rawRequestCounts':requests,'auditExecution':{'originalAudit':json.loads((O/'execution-01/report.json').read_bytes()),'typedAudit':json.loads((T/'typed-execution-01/report.json').read_bytes()),'earlierHarnessFailures':['stage48-c01-platform-c-audit-01 manifest-string schema TypeError exit1','stage48-c01-platform-c-audit-02/typed-execution-01 missing optional outer receipt exit1']},'originalChanges':[]})
(O/'final-report.json').write_text(json.dumps(final,indent=2)+'\n')
print(json.dumps({'finalReportSha256':h((O/'final-report.json').read_bytes()),'explicitOriginalRegularInputs':len(inputs),'typedInputs':len(typedinputs),'originalChanges':[]}))
