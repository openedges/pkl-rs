# Stage48 C01 실제 플랫폼 독립 감사

C01 release `04881b69…` / map `9f546b82…`에 연결된 기존 결과만 읽었다. 새 Java·Rust·Node·Chromium·fixture verifier·build 실행은 없고, 생산·원본·Git 변경도 없다. 감사기 actual38838와 typed 별도 감사 actual47739는 exit0이다. 원래 wrapper28335는 process/integrity exit0이며 개별 strict failure를 지우지 않는다.

## 원시 결과

| 그룹 | 대상별 실제 범위와 결과 |
|---|---|
| primitives | 6,078개 Rust/Node/browser 동일, Java와 각6,076 일치. 기존 두 regex 차이 유지 |
| renderer | Node/browser 각각860 API raw status·UTF16·JavaUTF8·read plan 일치 |
| Resource | 각각1,008 API와 reader trace 일치 |
| module preparation | 각각252 API와 선언된 Java observable projection 일치. capability/policy SPI 관찰 완료라는 의미 아님 |
| ModuleInfo | 각각156 ordinary API pass, 12 Java internal parser boundary 미지원 분리. 별도 native followup 56개 미실행 경계 유지 |
| security denial | 각각10 ordinary API와 실제 Java 원인/denial 수 일치. full Standard policy 구현 주장 없음 |
| guest catch | 대상별42 executions = full24/constructor10/terminal-partial8. 이를42 full API passes로 세지 않음 |
| module loader | 대상별44 executions =32pass/12mismatch. 실제116 result/callback API 채널은 전부 일치 |
| module inheritance | 대상별6 executions 모두mismatch. 실제20 result/callback API 채널은 전부 일치 |

loader/inheritance는 logs/resource scoped counts/architecture도 통과했고 실패는 `requestCountsMatch`에만 있다. 모든 ordered actual requests를 보존했다. Java fixture integrity 코드는 `module_loading_fixtures.py:205`, `module_inheritance_fixtures.py:164`에서 SPI의 `resolve`와 `source` 두 counter만 `{resolve,load-source}`로 묶는다. 새 `check-import` 요청에 대한 Java policy trace 기대값은 이 원본에 없다. 실제 두 SPI projection은 일치하지만, 기존 strict status/exit1은 그대로 실패로 남는다.

## 요청 수 비교 도구의 권장 후속 범위

기대 fixture를 바꾸거나 새 요청을 버리지 않는다. 후속 schema에서 다음 필드를 **추가**하면 관찰 범위를 명확히 할 수 있다.

- `apiRawChannelsMatch`: result/callback payload·UTF16 및 실제 있는 exit 채널만의 비교.
- `javaObservedModuleSpiCounts`: 관찰된 kinds가 `resolve`, `load-source`라는 사실과 그 두 counter projection 결과.
- `policyTraceComparison.state = "unobserved-in-original-fixture"`: 모든 CheckImport raw 요청을 그대로 보존하되, 없는 Java trace나 zero 기대값을 만들지 않는다.

이는 새 도구 계약의 제안이며 이번 원본을 strict pass로 재분류하는 근거가 아니다. 기존 `rawMatch`는 count 비교까지 합친 aggregate라 원본 false 상태를 유지한다. 새로운 Java policy fixture나 넓은 SPI/effect 순서 판정은 별도 의무다.

## Bootstrap 원본과 typed 후속

원본41297 exit1: 대상별600 API 완료, **274pass/144unsupported/182mismatch**. 이후43996 exit1은 같은 Java fixture와 C01 runtime artifacts에 helper 한 개의 declared consumer delta를 적용했다. `respondString` 대신 `completeReadText`로 성공 Resource cache를 사용하고 명시적 completion profile을 남긴 결과, 대상별 **402pass/144unsupported/54mismatch**다. 128건 mismatch→pass, 이전274pass는 전부 유지된다. 각600건의 전체 UTF16/JavaUTF8/status/read counters와 원시 파일을 독립 재계산했으며 두 기록을 보존했다. 남은 reflect/JVM-global lifetime 및 reader 경계를 일반화해 통과로 세지 않는다.

typed transport unit은 `node --test tools/platform/module-policy-session.test.mjs`의 실제6건/exit0 범위다. 처음에는 child report/raw만 있어 감사기가 outer receipt를 잘못 가정하고 실패했다. root가 뒤늦게 immediate-terminal chunk `d27a51` receipt를 추가했으며 `late-unit-receipt-binding.json`에 시점·해시를 별도로 남겼다. 원래 report/stdout/stderr와 감사 실패는 수정하지 않았다.

## Source/artifact/browser/HTTP

C01 snapshot의53,236개 regular source bytes/modes와11개 symlink target/mode를 명시 map으로 확인했다. baseline source subset, 기록된8개 build/tool/acquisition 명령, NAPI·native·Wasm 산출물 및 모든 driver input hash를 연결했다. M1 자체 `sources.json`에는 `.cargo/config.toml`이 없으므로 직접 capture라고 부르지 않는다. 이번 C01 full map의 config와 wrapper의 전체 map build 전후 점검이 별도의 보완 provenance다. 새 helper/test 소비자 delta는 frozen C01 source로 재귀속하지 않는다.

각 browser는 기록한 full Chrome executablePath를 실제 launch options로 사용했고 기록 SHA와 실제 파일을 재확인했다. Playwright/package-lock pin도 일치한다. renderer/Resource/module-preparation의 실제 missing-asset404/empty-body probe는 확인했다. 나머지 HTTP 서버는 read-before-200 및 headersSent guard의 고정 소스와 empty infrastructure/browser errors를 연결했다. loader HTTP의 `readFile`은 매 응답 payload digest를 기록하지 않으므로 네트워크 제공 바이트를 독립 계측했다고 주장하지 않는다. copied helper/source hash 및 before/after 파일 안정성과 구분한다.

원시 module requests와 이름 있는 default policy profile은 transport가 Rust 정책을 호출한 provenance다. Java가 관찰하지 않은 policy SPI 순서나 실제 브라우저 filesystem 정책 parity로 확대하지 않는다. GC/owned view 검사는 driver가 기록한 실제 값과 source에 한정하며 Java GC 동등성은 주장하지 않는다.

## 실패 이력과 남은 범위

첫 감사 `stage48-c01-platform-c-audit-01`은 manifest의 string-SHA schema를 object schema로 가정해 TypeError exit1이었다. 새 -02에서 두 schema를 명시 처리했다. -02의 첫 typed 감사는 optional receipt 부재로 exit1, 별도 `stage48-c01-bootstrap-typed-c-audit-02`에서 실제 부재를 기록하고 마쳤다. 모두 감사 harness 실패이며 evaluator 결과를 바꾸지 않았다.

이것은 C01 중간 구현의 기존 실행 감사다. factory/custom key/isCached, eager clause factory preflight, primary/repl, import*, full lifecycle/admission 및 M2 전체 완료를 닫지 않는다. Stage47의 실행 중 full regression도 이번 결과로 대체하지 않는다.
