from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
p=Path(__file__).resolve().parent;o=p/'typed-execution-01';o.mkdir(exist_ok=False);h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();cmd=[sys.executable,str(p/'typed-bootstrap-audit.py')]
r={'command':cmd,'scriptSha256':h(p/'typed-bootstrap-audit.py'),'startedUtc':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'Read-only existing raw typed bootstrap evidence comparison.'}
with(o/'stdout.bin').open('wb')as out,(o/'stderr.bin').open('wb')as err:
 c=subprocess.Popen(cmd,cwd=p,stdout=out,stderr=err,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});r['pid']=c.pid;(o/'launch.json').write_text(json.dumps(r,indent=2)+'\n');r['exitCode']=c.wait()
r.update(finishedUtc=datetime.datetime.now(datetime.UTC).isoformat(),stdoutSha256=h(o/'stdout.bin'),stderrSha256=h(o/'stderr.bin'));(o/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(r['exitCode'])
