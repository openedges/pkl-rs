from pathlib import Path
import hashlib,json,struct,difflib,stat,collections
O=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');B=S/'target/m2/stage48-c01-bootstrap-control-01';T=S/'target/m2/stage48-c01-bootstrap-typed-control-02';C=S/'target/m2/stage48-implementation-01/admission-candidate-build-01';P=S/'target/m2/stage48-c01-platform-control-01/primitives'
h=lambda b:hashlib.sha256(b).hexdigest();inputs={}
def read(p):
 p=Path(p);assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();row={'sha256':h(b),'bytes':len(b)};assert inputs.setdefault(str(p),row)==row;return b
def obj(p):return json.loads(read(p))
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
def units(u):assert all(type(n)==int and 0<=n<=65535 for n in u);return b''.join(struct.pack('>H',n)for n in u)
def utf8(u):return units(u).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
release=obj(C/'release.json');assert h(read(C/'release.json'))=='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0';mapping=obj(C/'source-after.json')
a=obj(B/'terminal.json');b=obj(T/'terminal.json');outer=obj(T/'outer-terminal.json');delta=obj(T/'consumer-source-delta.json');obj(T/'derivation.json');read(T/'run.py');read(T/'launch.json')
assert outer['sessionId']==43996 and outer['exitCode']==b['exitCode']==1 and b['inputHashesBefore']==b['inputHashesAfter']
assert a['releaseSha256']==b['releaseSha256']==delta['baseReleaseSha256']==h(read(C/'release.json'))
changes={p:(v,b['inputHashesBefore'][p])for p,v in a['inputHashesBefore'].items()if b['inputHashesBefore'].get(p)!=v};assert set(changes)=={str(S/'tools/platform/bootstrap-session.mjs')}
old_helper=read(B/'execution/bootstrap-session.mjs');new_helper=read(T/'execution/bootstrap-session.mjs');assert h(old_helper)==delta['sourceOnlyConsumerChanges']['tools/platform/bootstrap-session.mjs']['candidateSha256'] and h(new_helper)==delta['sourceOnlyConsumerChanges']['tools/platform/bootstrap-session.mjs']['currentSha256']
(O/'typed-bootstrap-helper.diff').write_text(''.join(difflib.unified_diff(old_helper.decode().splitlines(True),new_helper.decode().splitlines(True),fromfile='C01-original-consumer',tofile='C01-typed-consumer-followup')))
for path,expected in b['inputHashesBefore'].items():
 p=Path(path)
 try:n=str(p.relative_to(S))
 except ValueError:n=None
 if n=='tools/platform/bootstrap-session.mjs':data=new_helper
 elif n in mapping:data=read(C/'sources'/n)
 else:data=read(p)
 assert h(data)==expected,(path,'input SHA')
for side in ['stdout','stderr']:assert h(read(T/(side+'.bin')))==b[side+'Sha256']
er=obj(T/'execution/execution.json');old_er=obj(B/'execution/execution.json')
assert er['acquisitionPassed'] and not er['strictJavaCompatibilityPassed'] and not er['infrastructureErrors'] and not er['browserErrors'] and not er['changedInputs']
assert er['browserLaunchOptions']['executablePath']==er['browserExecutable'] and h(read(er['browserExecutable']))==er['browserExecutableSha256']
for path,expected in er['artifactAndInputHashes'].items():
 p=Path(path)
 try:n=str(p.relative_to(S))
 except ValueError:n=None
 data=new_helper if n=='tools/platform/bootstrap-session.mjs' else read(C/'sources'/n) if n in mapping else read(p)
 assert h(data)==expected,path
assert read(T/'execution/fixture-data.json')==read(B/'execution/fixture-data.json');fixtures=obj(T/'execution/fixture-data.json')
assert len(fixtures)==8
results=[];transitions=[];raw_requests=[]
for target in ['node','browser']:
 old_raw=obj(B/'execution'/(target+'.raw.json'));raw=obj(T/'execution'/(target+'.raw.json'));assert len(old_raw)==len(raw)==len(fixtures)
 counts=collections.Counter();transition_counts=collections.Counter();previouspassregressions=[];changed_raw=[]
 for f,a,b in zip(fixtures,old_raw,raw):
  assert b['id']==a['id']==f['id'] and b['repeat']==a['repeat']==f['repeat'];assert b['resourceCompletion']=='typed-resource-text-and-configured-default'
  for i,(previous,current) in enumerate(zip(a['sessions'],b['sessions'])):
   assert current['constructorError'] is None and current['acquisitionError'] is None and current['architecture']['terminalSlots']==0 and current['architecture']['ownedResultsStable'] and len(current['calls'])==len(previous['calls'])==25
   raw_requests.append({'target':target,'id':b['id'],'repeat':b['repeat'],'session':i,'modulePolicy':b['modulePolicy'],'resourceCompletion':b['resourceCompletion'],'requests':current['moduleRequests']})
   directory=T/'execution'/target/b['id']/str(b['repeat'])/('session-'+str(i));assert obj(directory/'actual.json')==current
   expected=[e for e in f['expected'] if e['session']==i]
   for e,prev,c in zip(expected,previous['calls'],current['calls']):
    check={'prefix':c['prefix']==e['prefix'],'status':c['kind']==e['kind'],'units':units(c['units']).hex()==e['utf16BEHex'],'javaUtf8':utf8(c['units']).hex()==e['utf8Hex'],'disposition':c['kind']!='error' or c['disposition']=='language-error'}
    if f['reader']=='counted':check.update(readsBefore=c['readsBefore']==e['readsBefore'],readsAfter=c['readsAfter']==e['readsAfter'])
    status='unsupported' if c['disposition']=='unsupported' else 'pass' if all(check.values()) else 'mismatch'
    comp=obj(directory/(c['prefix']+'.comparison.json'));assert comp['status']==status
    assert read(directory/(c['prefix']+'.actual.utf16be.bin'))==units(c['units']) and read(directory/(c['prefix']+'.actual.utf8.bin'))==utf8(c['units'])
    old_comp=obj(B/'execution'/target/a['id']/str(a['repeat'])/('session-'+str(i))/(c['prefix']+'.comparison.json'));old_status=old_comp['status']
    transition_counts[(old_status,status)]+=1
    if old_status=='pass' and status!='pass':previouspassregressions.append([b['id'],b['repeat'],i,c['prefix']])
    if prev!=c:changed_raw.append({'id':b['id'],'repeat':b['repeat'],'session':i,'prefix':c['prefix'],'before':prev,'after':c})
    transitions.append({'target':target,'id':b['id'],'repeat':b['repeat'],'session':i,'prefix':c['prefix'],'beforeStatus':old_status,'afterStatus':status,'failedChecks':[k for k,v in check.items()if not v]})
    counts[status]+=1
 assert sum(counts.values())==600 and dict(counts)==er['targets'][target]['counts'];assert not previouspassregressions
 results.append({'target':target,'calls':600,'counts':dict(counts),'transitions':[{'from':k[0],'to':k[1],'calls':v}for k,v in sorted(transition_counts.items())],'previousPassRegressions':previouspassregressions,'changedRawCalls':len(changed_raw)})
 save(target+'-typed-bootstrap-raw-changes.json',changed_raw)
test=S/'target/m2/stage48-bootstrap-typed-provider-tests-01';tr=obj(test/'report.json');assert tr['exitCode']==0 and tr['sourceBefore']==tr['sourceAfter'];unit_receipt_present=(test/'outer-terminal.json').exists()
if unit_receipt_present:read(test/'outer-terminal.json')
for path,expected in tr['sourceBefore'].items():
 data=new_helper if path=='tools/platform/bootstrap-session.mjs' else read(S/path);assert h(data)==expected
# This records existing transport unit scope; no test is re-executed.
for n in ['stdout.bin','stderr.bin']:
 if (test/n).exists():read(test/n)
for p,row in inputs.items():assert h(Path(p).read_bytes())==row['sha256']
save('typed-bootstrap-inputs.json',inputs);save('typed-bootstrap-raw-requests.json',raw_requests);save('typed-bootstrap-transitions.json',transitions)
save('typed-bootstrap-report.json',{'schema':1,'scope':'Read-only original-vs-typed consumer raw readback, no acquisition/runtime tests.','outerTerminal':outer,'sameCandidateRelease':h(read(C/'release.json')),'sameFixtureData':True,'runtimeArtifactsUnchanged':True,'consumerDelta':delta,'results':results,'transportUnitScope':tr['command'],'transportUnitOuterReceiptPresent':unit_receipt_present,'transportUnitQualification':'Captured child report exit0/sourceBefore==sourceAfter and raw6tests are retained; producer supplied no outer-terminal.json. Evaluator receipt43996 is separately present.','fullStrictCompatibilityPassed':False,'originalResultRetained':{'perTarget':old_er['targets']['node']['counts'],'exitCode':1},'originalChanges':[],'qualification':'One bootstrap helper completion/profile delta; test file is separate transport-only development change. All Java bytes and C01 runtime artifacts unchanged; remaining unsupported/mismatch stay failed.'})
print(json.dumps({'targets':results,'originalChanges':[]}))
