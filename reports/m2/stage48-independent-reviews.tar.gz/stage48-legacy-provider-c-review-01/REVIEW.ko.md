# Stage48 추가 legacy portable provider 검토

새 `module-policy-session.mjs`/test와 bootstrap·ModuleInfo·security-denial·guest-catch session 네 개, 해당 compare driver 네 개의 고정 10파일을 검토했다. 앞서 교정한 provider 여섯 파일은 exact SHA가 그대로다. 편집 중 core나 새 Java/browser 실행을 사용하지 않았다.

## 실제 비교 실행 전에 필요한 provenance 보완

1. `compare-bootstrap`, `compare-guest-catch`, `compare-security-denial`은 `chromium.executablePath()`의 해시를 기록하지만 `launch({headless:true})`만 사용한다. Playwright가 별도 headless executable을 선택할 수 있으므로 기록한 실행 파일을 실제 launch의 `executablePath`로 전달해야 한다. `compare-moduleinfo`에는 이미 explicit 경로가 있다. 과거 기록은 원래 provenance 제한 그대로 보존하고 새 실행 조건만 보완한다.
2. 네 driver 모두 helper/policy output copy와 HTTP asset body를 `readFile`로 다시 읽는다. 사전 hash 및 종료 후 rehash만으로는 실제 복사/제공한 바이트를 해당 hash에 직접 연결하지 못한다. 이미 선언한 tracked `read(path)`를 copy·HTTP response·browser executable hash에 사용하여 실제 소비 바이트를 같은 입력 ledger에 연결해야 한다. 현재 read-before-200 및 headersSent/404/destroy 분기는 올바르며 유지한다.

## 요청·callback 경로에서 확인한 사항

- 공통 helper는 token/id, CheckImport/Resolve kind, 네 URI 문자열, 허용 필드 및 nullable source/resolved 필드를 검사하고 실제 bool 반환만 받는다. trust/allowlist/URI 선택을 JS로 옮기지 않는다. false는 caller의 명시적인 unsupported 실패로 남고 binding throw는 잡아 NotFound로 바꾸지 않는다.
- bootstrap과 ModuleInfo는 새 module 요청을 raw 배열에 남긴다. guest 결과·Resource read·기존 원시 비교 통로를 바꾸지 않는다.
- security-denial은 CheckImport만 shared default에 보내고, 기존 Resolve 단계에서는 원래 denied URI·typed cause를 검사하여 explicit rejection을 먼저 실행한다. 새 edge 때문에 기존 denials counter가 증가하지 않는다.
- guest-catch의 next()는 새 CheckImport와 `catch:/child` 밖의 Resolve를 처리하고 실제 요청을 기록한다. `catch:/child` Resolve/Source는 기존 settle/callback 경로로 반환된다. projected counts/events를 새 default 요청으로 보충하지 않는다.
- terminal-partial 경로도 같은 next()를 사용하여 앞선 default 요청을 소비한다. 명시적 callback close/timeout 및 stale follow-up 로직은 유지된다. timeout 경계의 실제 새 core 실행은 아직 검증하지 않았다.
- 새 HTTP helper route와 helper-relative import 경로가 맞고 helper를 output에 복사한다. 위 consumed-byte/실행 파일 provenance 보완 이후 실제 HTTP/browser 결과로 확인해야 한다.

## 기록 범위

`all-unit-03`은 unit 138개와 driver syntax 네 명령이 각각 exit0이고 actual outer 16391/0이다. before/after mjs map이 동일하며 이 검토의 10파일 및 기존 여섯 파일과 연결된다. 이 결과는 mock/문법 검사이며 실제 Rust binding, HTTP serving, Chromium 실행, Java policy·callback 의미 일치나 M2 완료를 증명하지 않는다. 원본 raw/소스 map과 이 검토의 고정 source hashes를 함께 보존한다. root의 provenance 교정 후보는 새 addendum에서 검토한다.
