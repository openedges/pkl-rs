from pathlib import Path
import json,hashlib,re
OUT=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');P=S/'target/m2/stage48-portable-provider-all-unit-03';h=lambda b:hashlib.sha256(b).hexdigest();original=json.loads((OUT/'inputs.json').read_bytes());rows=[]
def cap(name):
 p=P/name;b=p.read_bytes();q=OUT/'unit03'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);rows.append({'path':str(p),'snapshot':'unit03/'+name,'sha256':h(b),'bytes':len(b)});return b
report=json.loads(cap('report.json'));terminal=json.loads(cap('outer-terminal.json'));before=cap('source-before.json');after=cap('source-after.json');assert before==after and report['sourceStable'];m=json.loads(before)
assert terminal['sessionId']==16391 and terminal['actualExitCode']==0 and len(report['records'])==5
for rec in report['records']:
 assert rec['exitCode']==0
 for side in ['stdout','stderr']:assert h(cap(rec['label']+'.'+side+'.bin'))==rec[side+'Sha256']
unit=(OUT/'unit03/unit.stdout.bin').read_text();assert re.search(r'ℹ tests 138\b',unit) and re.search(r'ℹ pass 138\b',unit) and re.search(r'ℹ fail 0\b',unit)
for r in original['files']:assert m[r['relativePath']]==r['sha256'] and h((OUT/r['snapshot']).read_bytes())==r['sha256']
for r in original['firstSixProviderHashesUnchanged']:assert m[str(Path(r['path']).relative_to(S))]==r['sha256']
for r in rows:assert h(Path(r['path']).read_bytes())==r['sha256']
(OUT/'check-inputs.json').write_text(json.dumps({'files':rows,'changes':[],'recursiveTraversal':False},indent=2)+'\n')
r={'schema':1,'scope':'Exactly10frozen additional JS files plus prior6hash continuity; no mutableRust snapshot or runtime/oracle/browser reruns.','sourceFiles':original['files'],'firstSixUnchanged':True,'openPublicationExecutionFindings':[{'id':'EXPLICIT-CHROMIUM-PATH','drivers':['compare-bootstrap.mjs','compare-guest-catch.mjs','compare-security-denial.mjs'],'detail':'Recorded executable hash not bound to actual defaultheadless launch; moduleinfo already explicit.'},{'id':'TRACK-CONSUMED-ASSET-BYTES','drivers':['compare-bootstrap.mjs','compare-moduleinfo.mjs','compare-security-denial.mjs','compare-guest-catch.mjs'],'detail':'Copy/HTTPbody/browserexe rawreadFile bypass trackedread; route actual consumed bytes through hashledger.'}],'preserved':['Strict transport fields andboolean result','All policy delegatedtoRust','ExplicitResolve denial beforefallback','Catch child callbacks/terminal path precedence','Newrawrequests separate fromprojectedJava events/counters','Readbefore200 and404headersSentguard'],'recordedChecks':{'reportSha256':h((P/'report.json').read_bytes()),'sourceMapSha256':h(before),'unitTests':138,'syntaxChecks':4,'allExit0':True,'actualOuterSession':16391,'actualOuterExit':0},'actualBrowserJavaBindingPassClaimed':False,'followup':'Root corrected10file candidate requires separate source/check addendum; originalreview/source staysimmutable.'}
(OUT/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'sourceFiles':10,'unitTests':138,'syntaxChecks':4,'findings':2}))
