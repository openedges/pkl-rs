from pathlib import Path
import json,hashlib,stat
OUT=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');P=S/'target/m2/stage48-portable-driver-syntax-02';h=lambda b:hashlib.sha256(b).hexdigest()
orig=json.loads((OUT/'inputs.json').read_bytes());correct=json.loads((OUT/'corrective-inputs.json').read_bytes());rows=[]
def cap(n):
 p=P/n;b=p.read_bytes();dest=OUT/'syntax02'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);rows.append({'path':str(p),'snapshot':'syntax02/'+n,'bytes':len(b),'sha256':h(b)});return b
report=json.loads(cap('report.json'));terminal=json.loads(cap('outer-terminal.json'));assert report['sourceBefore']==report['sourceAfter'] and report['stable'];assert terminal['sessionId']==21440 and terminal['actualExitCode']==0 and len(report['records'])==4
assert sum(r['changed'] for r in correct['files'])==4
for r in correct['files']:
 b=(S/r['relativePath']).read_bytes();assert h(b)==r['sha256'] and b==(OUT/r['snapshot']).read_bytes()
 if r['changed']:assert report['sourceBefore'][r['relativePath']]==r['sha256']
 else:assert next(x for x in orig['files'] if x['relativePath']==r['relativePath'])['sha256']==r['sha256']
for rec in report['records']:
 assert rec['exitCode']==0 and rec['argv'][:2]==['node','--check'];name=Path(rec['argv'][2]).stem
 for side in ['stdout','stderr']:cap(name+'.'+side+'.bin')
# Driver/source checks stay bounded to explicit source snapshots.
for r in correct['files']:
 if not r['changed']:continue
 text=(OUT/r['snapshot']).read_text()
 assert 'await read(helper)' in text and 'await read(policy)' in text
 assert 'await read(path)' in text and 'await readFile(path);res.writeHead' not in text and 'await readFile(path); res.writeHead' not in text
 assert 'browserLaunchOptions={headless:true,executablePath:' in text and 'chromium.launch(report.browserLaunchOptions)' in text
 assert 'hash(await read(report.browserExecutable))' in text or 'hash(await read(executable))' in text
for r in orig['firstSixProviderHashesUnchanged']:assert h(Path(r['path']).read_bytes())==r['sha256']
for r in rows:assert h(Path(r['path']).read_bytes())==r['sha256']
result={'schema':1,'scope':'Read-only corrective driver/source addendum and capturedsyntax readback only. No HTTP/browser/binding/Java execution.','priorReviewReportSha256':h((OUT/'report.json').read_bytes()),'priorClosureSha256':h((OUT/'closure.json').read_bytes()),'resolvedFindings':['EXPLICIT-CHROMIUM-PATH','TRACK-CONSUMED-ASSET-BYTES'],'correctiveSourceHashes':correct['files'],'changedSources':4,'unchangedNewHelperAndLegacySessionSources':6,'firstEarlierProviderSixUnchanged':True,'confirmed':['All4drivers use tracked read for helper/policycopies and HTTPassetpayload','All4browser executable bytes participate in trackedhash/postcheck','All4launches explicitly select recorded executablePath','Readbefore200+404headersSentguard retained','Callback/explicitdenial/rawprojection logic unchanged from prior reviewedhelper source'],'recordedSyntax':{'reportSha256':h((P/'report.json').read_bytes()),'outerTerminalSha256':h((P/'outer-terminal.json').read_bytes()),'actualSession':21440,'actualExitCode':0,'commands':4,'allExit0':True,'sourceBeforeAfterEqual':True,'rawHashFieldsInProducerReport':False,'syntaxRawFilesNewlyHashBoundHere':True},'newBlockingFindings':[],'qualification':'Existing138mockunit results apply to unchangedhelper/session sources. New4drivers have syntaxchecks only; realbrowser/HTTP/Java/corecomparisons remain unexecuted. Originalsource/findingreview remainsimmutable.','sourceAndRecordChanges':[],'productionOrGitWrites':False}
(OUT/'corrective-addendum.json').write_text(json.dumps(result,indent=2)+'\n');(OUT/'corrective-check-inputs.json').write_text(json.dumps({'files':rows,'changes':[],'recursiveTraversal':False},indent=2)+'\n')
names=['corrective-addendum.json','corrective-inputs.json','corrective-check-inputs.json','finalize_corrective.py']+[r['snapshot'] for r in correct['files']]+[r['snapshot'] for r in rows]
(OUT/'corrective-closure.json').write_text(json.dumps({'closed':True,'priorClosureSha256':h((OUT/'closure.json').read_bytes()),'files':[{'path':n,'sha256':h((OUT/n).read_bytes()),'bytes':(OUT/n).stat().st_size} for n in names],'ownLiveHandles':[]},indent=2)+'\n');print(json.dumps({'addendumSha256':h((OUT/'corrective-addendum.json').read_bytes()),'closureSha256':h((OUT/'corrective-closure.json').read_bytes()),'syntaxChecks':4,'blockers':[]}))
