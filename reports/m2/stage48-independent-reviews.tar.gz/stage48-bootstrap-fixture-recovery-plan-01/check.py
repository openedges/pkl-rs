from pathlib import Path,PurePosixPath
import tarfile,json,hashlib,stat,os
O=Path(__file__).resolve().parent;MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');ARCH=MAIN/'reports/m2/stage45-oracle-bootstrap-java.tar.gz';ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42/target/m2/stage45-bootstrap-oracle-02');DRIVER=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/tools/platform/compare-bootstrap.mjs');sha=lambda b:hashlib.sha256(b).hexdigest()
archive_pin='2661f1e6d28c9384bae7fe106cd5391375757fe02a81986feaa50a60fe7960b0';report_pin='1bc3b8d085ec266196e92f6957b06b153b1aa70d0e53543878fc6c5fa74221c5'
assert sha(ARCH.read_bytes())==archive_pin
index=json.loads((MAIN/'reports/m2/stage45-oracle-captures.json').read_bytes());group=next(r for r in index['archives'] if r['logicalGroup']=='bootstrap-java');assert group['sha256']==archive_pin
with tarfile.open(ARCH,'r:gz') as t:
 members=t.getmembers();byname={m.name:m for m in members};assert len(byname)==len(members)
 assert all(m.isfile() for m in members)
 for name in byname:
  p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
 evidence=json.loads(t.extractfile('EVIDENCE.json').read());expected={r['path']:r for r in evidence['files']};assert set(expected)==set(byname)-{'EVIDENCE.json'}
 verified=[]
 for n,row in expected.items():
  b=t.extractfile(n).read();assert len(b)==row['bytes'] and sha(b)==row['sha256'],n
  verified.append({'path':n,'bytes':len(b),'sha256':sha(b)})
 assert len(verified)==14044
 pub=json.loads(t.extractfile('PUBLICATION-SOURCE.json').read());assert sha(t.extractfile('PUBLICATION-SOURCE.json').read())==group['publicationSourceManifestSha256']
 pmap={r['path']:r for r in pub['files']};assert len(pmap)==14043
 for n,row in pmap.items():assert expected[n]['sha256']==row['sha256'] and expected[n]['bytes']==row['bytes']
 prefix='stage45-bootstrap-oracle-02/'
 meta={n:t.extractfile(prefix+n).read() for n in ['closure.json','report.json','inventory.json','cases.json']}
 assert sha(meta['report.json'])==report_pin
 closure=json.loads(meta['closure.json']);inventory=json.loads(meta['inventory.json']);report=json.loads(meta['report.json']);cases=json.loads(meta['cases.json'])
 assert closure['closed'] and not closure['liveHandles'];assert closure['reportSha256']==report_pin and closure['inventorySha256']==sha(meta['inventory.json']) and len(inventory['files'])==closure['files']==6796
 assert report['outerCallCount']==600 and not report['inputChanges'] and len(cases)==4 and not any(r['allRawPaths'] for r in report['repeatDifferences'])
 # Verify original exact paths; never recurse or restore/overwrite anything.
 originals=[];missing=[];conflicts=[]
 for n,b in meta.items():
  f=ROOT/n
  if not os.path.lexists(f):missing.append(str(f));continue
  s=f.lstat()
  if not stat.S_ISREG(s.st_mode) or f.read_bytes()!=b:conflicts.append(str(f))
  d=O/'metadata'/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 for row in inventory['files']:
  n=row['path'];relative=PurePosixPath(n);assert not relative.is_absolute() and '..' not in relative.parts
  assert expected[prefix+n]['sha256']==row['sha256'] and expected[prefix+n]['bytes']==row['bytes']
  assert pmap[prefix+n]['source']==str(ROOT/n)
  f=ROOT/n
  if not os.path.lexists(f):missing.append(str(f));continue
  st=f.lstat()
  if not stat.S_ISREG(st.st_mode):conflicts.append(str(f));continue
  b=f.read_bytes();h=sha(b)
  if h!=row['sha256'] or len(b)!=row['bytes']:conflicts.append(str(f))
  originals.append({'path':str(f),'archiveMember':prefix+n,'sha256':h,'bytes':len(b),'mode':stat.S_IMODE(st.st_mode)})
 workspace=[]
 for c in cases:
  f=Path(c['workspace'])/'main.pkl';b=f.read_bytes();assert sha(b)==c['sourceSha256'];assert c['workspace']==str(ROOT/'workspace')
  workspace.append({'case':c['id'],'path':str(f),'archiveMember':prefix+'workspace/main.pkl','sha256':sha(b),'bytes':len(b)})
 for row in originals:assert sha(Path(row['path']).read_bytes())==row['sha256']
 (O/'original-file-checks.json').write_text(json.dumps({'files':originals,'missing':missing,'conflicts':conflicts,'changes':[]},indent=2)+'\n')
 (O/'archive-member-checks.json').write_text(json.dumps({'members':verified,'sourceMapEntries':len(pmap),'recursiveFilesystemTraversal':False},indent=2)+'\n')
 (O/'workspace-map.json').write_text(json.dumps(workspace,indent=2)+'\n')
 driver=DRIVER.read_bytes();(O/'compare-bootstrap.mjs').write_bytes(driver)
 result={'schema':1,'scope':'Read-only authenticated bootstrap fixture path recovery plan. No extraction/restoration, source/Git edits or evaluator/build/runtime execution.','driver':{'path':str(DRIVER),'sha256':sha(driver)},'archive':{'path':str(ARCH),'sha256':archive_pin,'bytes':ARCH.stat().st_size,'verifiedPayloads':len(verified),'totalMembers':len(members),'allRegularAndSafeRelative':True},'pinnedOracle':{'root':str(ROOT),'reportSha256':report_pin,'inventorySha256':sha(meta['inventory.json']),'closureSha256':sha(meta['closure.json']),'filesVerified':len(originals),'caseRows':len(cases),'outerCalls':600,'missing':missing,'conflicts':conflicts,'originalChanges':[]},'recommendation':'Use existing ROOT directly as CLOSED_BOOTSTRAP_ORACLE; no extraction or frozen driver changes necessary.' if not missing and not conflicts else 'Do not overwrite conflicts; restore only missing exact archive members after parent validation.','originalRootRestorationMap':{'oracleArgument':str(ROOT),'allFourCaseWorkspace':str(ROOT/'workspace'),'mainSource':str(ROOT/'workspace/main.pkl'),'mainSourceSha256':cases[0]['sourceSha256']},'fallbackPlan':{'freshExtraction':'A fresh target copy of prefix stage45-bootstrap-oracle-02/ is sufficient for oracleRoot metadata/payload reads, but cases.json still requires original absolute workspace/main.pkl. Keep cases/report bytes unchanged.','minimalMissingPathRestoration':'Only if missing, restore original workspace/main.pkl from authenticated prefix workspace/main.pkl with exclusive-create and parent kind checks. Never overwrite any existing mismatched path.','noDriverPatchRequired':'Driver can take fresh oracle root while preserving original cases workspace, or use existing validated original ROOT directly.'},'qualifications':['Stage48 frozen driver and its exact SHA are bound, distinct from older MAIN driver.','Archive verification does not reacquire Java or create a new original result.','600 is original controlled bootstrap API denominator per target, not a compatibility pass or full stdlib/API scope.','New Node/browser outcome remains pending; provider policy requests and prior known gaps stay separately accounted.'],'sourceChanges':[],'recursiveFilesystemTraversal':False}
 (O/'report.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'archivePayloadsVerified':len(verified),'originalPayloadsVerified':len(originals),'missing':missing,'conflicts':conflicts,'restoredFiles':0,'oracleArgument':str(ROOT)}))
