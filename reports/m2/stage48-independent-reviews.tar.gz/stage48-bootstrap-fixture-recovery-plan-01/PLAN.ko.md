# Stage48 bootstrap fixture 경로 확인과 복구 계획

## 권장 경로

복구가 필요하지 않다. frozen Stage48 `compare-bootstrap.mjs`의 `CLOSED_BOOTSTRAP_ORACLE` 인수에 다음 기존 경로를 그대로 전달한다.

```text
/Users/cody.ij.hwang/Projects/pkl-rs.stage42/target/m2/stage45-bootstrap-oracle-02
```

driver가 고정한 report SHA는 `1bc3b8d085ec266196e92f6957b06b153b1aa70d0e53543878fc6c5fa74221c5`다. 네 cases 행은 모두 같은 원래 `workspace/main.pkl`을 가리키고 그 파일도 존재한다. Stage45 worktree의 target 목록과 원래 Stage42 evidence 경로를 구분해야 한다.

## 인증한 자료

- 원본 archive: MAIN `reports/m2/stage45-oracle-bootstrap-java.tar.gz`, SHA `2661f1e6d28c9384bae7fe106cd5391375757fe02a81986feaa50a60fe7960b0`.
- archive 내부 `stage45-bootstrap-oracle-02/report.json`은 driver pin과 일치하고 closure는 closed/liveHandles=[]다.
- inventory SHA `049dcb668d3a9e9a0840757bf3bb2f962ab1d148d77a4ef5a7a006281362b67e`, 명시 payload 6,796개를 현재 원래 위치 및 archive member와 전수 비교했다. 누락·충돌 0, 원본 전후 SHA 변경 0이다.
- 네 case workspace: 위 oracle root의 `workspace`; source `main.pkl` SHA `4690c40055ca7e230259da01711d131a3b3bf3380d1c499c1e6530e2b9270b47`.
- archive 전체 선언 payload 14,044개도 `EVIDENCE.json` 및 publication source map에 대해 전수 확인했다. duplicate/absolute/parent-traversal/nonregular member가 없다. archive members 총 14,045개에는 `EVIDENCE.json` 자체가 포함된다.

`original-file-checks.json`, `archive-member-checks.json`, `workspace-map.json`에 정확한 경로·길이·SHA를 남겼다. 일반 filesystem tree 탐색은 하지 않았고 inventory와 archive map만 사용했다. 검증 script actual tool session 37014는 exit0이었다. 파일 추출·복원·oracle/Node/browser/evaluator/build 실행은 없었다.

## 원래 경로가 추후 없어졌을 때만

archive의 `stage45-bootstrap-oracle-02/` prefix를 새 target 디렉터리에 복원하고 그 새 경로를 oracle 인수로 줄 수 있다. 단, 바이트가 고정된 `cases.json`의 workspace는 원래 절대 경로다. driver/report/cases를 재작성하지 말고, 그 원래 workspace/main.pkl이 없는 경우에 한하여 인증된 해당 archive member를 exclusive-create로 복원한다. root와 부모 디렉터리를 lstat로 확인하고 symlink/non-directory 또는 기존 불일치 파일이면 중단한다. 존재하는 파일을 덮어쓰지 않는다. 현재는 이 절차가 필요하지 않다.

## 판정 범위

이는 기존 Java 자료의 위치·무결성 확인이다. 새 취득이나 호환성 통과가 아니다. 원래 bootstrap 분모 600 API/target과 알려진 stdlib/cache/security/API 한계를 유지한다. Stage48의 실제 Node/Chromium 결과, artifact/source binding과 policy request 관찰은 root의 새 실행에서 별도로 판단해야 한다. 오래된 MAIN driver와 달리 이번 계획은 Stage48의 frozen driver SHA를 report에 직접 기록했다.
