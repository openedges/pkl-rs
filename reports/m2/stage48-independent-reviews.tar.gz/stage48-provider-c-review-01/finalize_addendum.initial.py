from pathlib import Path
import json,hashlib,re,stat
OUT=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');sha=lambda b:hashlib.sha256(b).hexdigest()
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
correct=json.loads((OUT/'corrective-inputs.json').read_bytes());original=json.loads((OUT/'inputs.json').read_bytes());rows=[]
for r in correct['files']:
 p=S/r['relativePath'];b=p.read_bytes();assert sha(b)==r['sha256'] and b==(OUT/r['snapshot']).read_bytes();assert stat.S_IMODE(p.lstat().st_mode)==420
records=[]
for name in ['stage48-portable-provider-unit-01','stage48-portable-provider-unit-02','stage48-portable-provider-all-unit-01','stage48-portable-provider-all-unit-02']:
 root=S/'target/m2'/name;captured={}
 for n in ['report.json','source-before.json','source-after.json','stdout.bin','stderr.bin','outer-terminal.json']:
  p=root/n;b=p.read_bytes();dest=OUT/'unit-records'/name/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);row={'path':str(p),'snapshot':str(dest.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)};rows.append(row);captured[n]=b
 report=json.loads(captured['report.json']);terminal=json.loads(captured['outer-terminal.json']);assert sha(captured['stdout.bin'])==report['stdoutSha256'] and sha(captured['stderr.bin'])==report['stderrSha256'];assert captured['source-before.json']==captured['source-after.json'] and report['sourceStable']
 assert terminal['actualExitCode']==report['exitCode']
 counts={label:int(re.search(r'ℹ '+label+r' (\d+)\b',captured['stdout.bin'].decode()).group(1)) for label in ['tests','pass','fail']}
 records.append({'root':str(root),'reportSha256':sha(captured['report.json']),'sourceMapSha256':sha(captured['source-before.json']),'outerTerminalSha256':sha(captured['outer-terminal.json']),'exitCode':report['exitCode'],'counts':counts,'scope':report['scope']})
 if name.endswith('all-unit-02'):
  m=json.loads(captured['source-before.json']);assert all(m[r['relativePath']]==r['sha256'] for r in correct['files']);assert counts=={'tests':133,'pass':133,'fail':0} and report['exitCode']==0 and len([x for x in report['command'] if x.endswith('.test.mjs')])==16
for r in rows:assert sha(Path(r['path']).read_bytes())==r['sha256']
report={'schema':1,'scope':'Addendum reviewing final6providerJSfiles and recordedmock/toolingchecks only. No runtime/binding/Java/platform reevaluation or mutablecore snapshot.','supersedesOpenFindingIn':'report.json','resolvedFindings':['RESOURCE-MODULE-CONTEXT','LOADER-DEFAULT-BOOL'],'sourceCorrectiveScope':['Resource records raw request before validation; validates CheckImport/Resolve kind,4URI strings, allowed fields and null/absent resolved/source URI before helper.','Loader strict boolean guard; malformed undefined/null/0/string preserved by mock and never converted to NotFound.'],'sourceHashes':correct['files'],'checks':records,'finalRecordedTestsPassed':133,'finalActualSession':78998,'finalActualExitCode':0,'newBlockingFindings':[],'originalReviewAndFailurePreserved':True,'qualifications':['Tests use mock sessions; no actual core default-policy/token/timeout behavior is validated by these JS units.','Raw moduleRequests and existing Java observable projection remain separate; no new default Java events invented, no fullSPI order claim.','Default consumer does not establish policy84/close28/fullidentity/fullM2 compatibility.','No C evaluation/production/fixture/Git mutation.'],'sourceOrRecordChanges':[]}
save('corrective-addendum.json',report);save('corrective-record-inputs.json',{'files':rows,'changes':[],'recursiveTraversal':False})
files=['corrective-addendum.json','corrective-inputs.json','corrective-record-inputs.json','finalize_addendum.py']+[r['snapshot'] for r in correct['files']]+[r['snapshot'] for r in rows]
save('corrective-closure.json',{'closed':True,'files':[{'path':n,'bytes':(OUT/n).stat().st_size,'sha256':sha((OUT/n).read_bytes())} for n in files],'priorClosureSha256':sha((OUT/'closure.json').read_bytes()),'ownLiveHandles':[]})
print(json.dumps({'addendumSha256':sha((OUT/'corrective-addendum.json').read_bytes()),'closureSha256':sha((OUT/'corrective-closure.json').read_bytes()),'records':len(records),'finalTests':133,'blockers':[]}))
