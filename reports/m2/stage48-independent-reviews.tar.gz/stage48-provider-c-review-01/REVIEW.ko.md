# Stage48 portable provider 여섯 파일 검토

이 검토는 `sources/`의 여섯 JS 파일과 Stage48 계획에서 합의한 Host 계약만 대상으로 한다. 편집 중인 Rust core를 동결본으로 읽거나 새 Node/Chromium·Rust·Java 실행을 하지 않았다. 따라서 `completeDefaultModule` 자체의 false/token/timeout 의미를 검증한 결과가 아니다.

## 필요한 보완

**Resource transport의 module request context 검증이 빠져 있다.** 고정 `resource-session.mjs:68–75`는 token/id만 검사하고, kind 및 `originalUri`, `importUri`, `importerOriginalUri`, `importerResolvedUri`는 검사하지 않는다. 실제 default binding은 token으로 VM의 pending request를 찾으므로 공개 event metadata에서 필드가 누락되거나 kind가 잘못돼도 내부 요청을 처리하고 동일한 결과를 반환할 수 있다. `compareResourceCase`는 moduleRequests의 context를 Java 기대와 비교하지 않으므로 출력이 맞으면 이 transport 결함을 놓칠 수 있다.

CheckImport/Resolve 두 default-supported kind와 필요한 context의 문자열 타입을 helper 호출 전에 검사하고, 잘못된 context일 때 helper를 호출하지 않는 stub-spy 회귀가 필요하다. 다른 module kind는 명시적인 unsupported/acquisition failure로 남긴다. JS에서 URI trust를 판정하라는 뜻은 아니다.

## 이미 교정된 fallback

초기 diff의 module-loader missing-Resolve 경로는 `completeDefaultModule(...) !== true`를 모두 NotFound로 바꾸므로 malformed `undefined/null/0/string` 반환도 정상 false로 취급할 수 있었다. 검토·root의 병행 지적 후 현재 캡처 `module-loader-session.mjs:156–158`은 실제 boolean인지 확인한 뒤 false에만 기존 NotFound를 사용한다. 코드상 이 문제는 해결됐다.

다만 현재 unit mock의 `options.defaultModule?.(...args) ?? false`는 의도적으로 반환한 undefined/null을 false로 바꾼다. 추가된 malformed regression은 string을 실제 검사하지만 undefined/null을 검사하려면 mock을 'callback이 없을 때만 false'로 바꾸고 invalid return 벡터를 추가해야 한다. 이것은 실제 core의 boolean 반환을 새로 검증했다는 의미가 아니다.

## 소스에서 유지된 계약

- module-preparation은 exact request identity로 provider를 먼저 찾는다. 명시적 CheckImport acceptance/typed denial은 새 complete/reject API로 보내고, 해당 provider가 있을 때 default helper를 호출하지 않는다.
- CheckImport의 NotFound/Io provider 입력은 실행 전 거절한다. nullable/empty/비정상 surrogate cause는 기존 UTF-16 문자열 통로를 그대로 통과한다.
- exact provider가 없는 CheckImport/Resolve만 shared default에 위임한다. capabilities/has-element/load-source의 미구성 요청은 계속 실패한다. boolean false나 실제 helper throw가 Java 이벤트로 바뀌지 않는다.
- 새 default 요청은 moduleRequests에 보존하며 default provider profile을 명시한다. default 요청으로 Java observable event를 합성하지 않는다.
- loader의 explicit resolution denial/설정은 default missing-Resolve fallback보다 먼저 적용된다. 실제 helper throw는 기존 per-call thrown 결과 경계를 거치고, NotFound fallback으로 바뀌지 않는다.
- Resource/renderer의 원시 UTF-16·Java UTF-8, reader-plan 순서/횟수, caller payload 변조, free 이후 output ownership 및 terminal heap 검사 경로는 유지된다.

## projection의 계속되는 제한

기존 `m2-module-portable/fixtures.json`의 resolve-provider observableEvents에는 policy-import·policy-resolve-module·secure-path가 함께 들어 있다. 새 raw CheckImport는 별도로 기록되지만 기존 ordered observable projection이 실제 새 SPI 호출의 전체 순서·횟수를 직접 증명하는 것은 아니다. provider input facts와 Java observable projection, 새 실제 moduleRequests를 계속 별개로 표시해야 한다. fixture를 바꾸지 않고 default 요청에서 이벤트를 추가하지 않은 현재 방향은 이 제한을 보존한다.

기존 test 결과의 실행 사실/소스 hash와 후속 교정 후보 결과는 root의 각 원본 기록에 귀속한다. 이 read-only 검토는 실제 새 binding/platform 통과나 policy84/close28/full M2 완료를 주장하지 않는다. Resource context 교정과 최신 frozen 여섯 파일/실제 검사 기록은 별도 addendum으로 검토한다.
