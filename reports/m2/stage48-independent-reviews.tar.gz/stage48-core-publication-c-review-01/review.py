from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,stat,base64,collections,os
O=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');P=S/'target/m2/stage48-core-publication-proposal-01';C=S/'target/m2/stage48-implementation-01/admission-candidate-build-01';sha=lambda b:hashlib.sha256(b).hexdigest();inputs={}
def read(p):
 p=Path(p);b=p.read_bytes();assert stat.S_ISREG(p.lstat().st_mode);row={'sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(p.lstat().st_mode)};assert inputs.setdefault(str(p),row)==row;return b
def obj(p):return json.loads(read(p))
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
handoff=obj(P/'handoff.json');assert sha(read(P/'handoff.json'))=='7d54ff40f1d38641a679ff096e165cc33d71232789a1d3ebc2986cd4006c0924'
for r in handoff['publication_files']:b=read(r['path']);assert len(b)==r['bytes'] and sha(b)==r['sha256']
idx=obj(P/'archive-index.json');summary=obj(P/'summary.json');receipt=obj(P/'publication-receipt.json');assert sha(read(P/'archive-index.json'))==receipt['archive_index_sha256'] and sha(read(P/'summary.json'))==receipt['summary_sha256']
assert receipt['packaging']['exit_code']==receipt['outer_terminal']['actual_exit_code']==0 and receipt['outer_terminal']['tool_session_id']==65460
for side in ['stdout','stderr']:assert base64.b64decode(receipt[side]['base64'])==read(P/('package.'+side+'.bin')) and sha(read(P/('package.'+side+'.bin')))==receipt[side]['sha256']
archiveinputs=obj(P/'archive-inputs.json');assert sha(read(P/'archive-inputs.json'))==idx['archive_inputs_sha256']
archive_hashes={};archive_bytes={};archives=[]
for a in idx['archives']:
 path=Path(a['path']);assert path.stat().st_size==a['bytes']<100*1024*1024 and sha(read(path))==a['sha256']
 assert a['create']['exit_code']==a['separate_verify']['exit_code']==0
 for c in [a['create'],a['separate_verify']]:
  for side in ['stdout','stderr']:assert sha(base64.b64decode(c[side+'_base64']))==c[side+'_sha256']
 with tarfile.open(path,'r:gz') as t:
  members=t.getmembers();names=[m.name for m in members];assert len(names)==len(set(names));byname={m.name:m for m in members};assert all(m.isfile() and m.mode==0o644 for m in members)
  for n in names:p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts
  ev=json.loads(t.extractfile('EVIDENCE.json').read());expected={r['path']:r for r in ev['files']};assert set(expected)==set(names)-{'EVIDENCE.json'}
  for n,r in expected.items():
   b=t.extractfile(n).read();assert len(b)==r['bytes'] and sha(b)==r['sha256'];archive_hashes[(a['name'],n)]={'sha256':sha(b),'bytes':len(b)}
   if a['name']==idx['source_binding_archive'] and (n.startswith('source-blobs/') or n.endswith('.json')or n=='README.md'):archive_bytes[n]=b
  assert len(expected)==a['files']
  archives.append({'name':a['name'],'sha256':a['sha256'],'compressedBytes':a['bytes'],'payloadFiles':len(expected),'rawBytes':sum(r['bytes']for r in expected.values())})
assert sum(a['compressedBytes'] for a in archives)==idx['total_bytes']
for group,rows in archiveinputs.items():
 archive='stage48-core-'+group+'.tar.gz'
 for r in rows:assert archive_hashes[(archive,r['path'])]=={'sha256':r['sha256'],'bytes':r['bytes']}
selected=obj(P/'selected-files.json')
for r in selected:
 b=read(r['original']);assert len(b)==r['bytes'] and sha(b)==r['sha256'] and stat.S_IMODE(Path(r['original']).lstat().st_mode)==r['mode']
 assert archive_hashes[('stage48-core-'+r['group']+'.tar.gz',r['path'])]=={'sha256':r['sha256'],'bytes':r['bytes']}
bindings=json.loads(archive_bytes['source-bindings.json']);assert sha(archive_bytes['source-bindings.json'])==idx['source_binding_sha256']==sha(read(P/'source-bindings.json'))
byversion={(r['path'],r['sha256']):r for r in bindings};assert len(byversion)==len(bindings)==summary['source_versions']
release=obj(C/'release.json');mapping=obj(C/'source-after.json');modes=obj(C/'source-modes.json');links=obj(C/'source-links.json')
assert sha(read(C/'release.json'))==handoff['candidate_release_sha256']==summary['candidate_release_sha256']=='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0'
assert len(mapping)==handoff['complete_C01_files']==53236 and len(links)==11 and set(modes)==set(mapping)
for n,h in mapping.items():
 r=byversion[(n,h)];assert r['kind']!='historical-hash-only';p=C/'sources'/n;b=read(p);assert sha(b)==h and len(b)==r['bytes'] and stat.S_IMODE(p.lstat().st_mode)==modes[n]
 if r['kind']=='pinned-git-blob':assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==r['object'] and int(r['git_mode'],8)&0o777==modes[n]
 else:assert archive_bytes[r['blob']]==b
rawmap=json.loads(archive_bytes['raw/implementation/admission-candidate-build-01/source-after.json']);assert rawmap==mapping
assert json.loads(archive_bytes['raw/implementation/admission-candidate-build-01/source-modes.json'])==modes
assert json.loads(archive_bytes['raw/implementation/admission-candidate-build-01/source-links.json'])==links
for n,r in links.items():p=C/'sources'/n;assert p.is_symlink() and os.readlink(p)==r['target'] and stat.S_IMODE(p.lstat().st_mode)==r['mode']
artm=json.loads(archive_bytes['artifact-modes.json'])
for n,r in artm.items():
 actual=release['artifacts'][n];assert actual['sha256']==r['sha256'];assert archive_hashes[('stage48-core-artifacts.tar.gz',n)]=={'sha256':r['sha256'],'bytes':r['bytes']} and stat.S_IMODE(Path(actual['path']).lstat().st_mode)==r['mode']
hashonly=[r for r in bindings if r['kind']=='historical-hash-only'];assert len(hashonly)==summary['historical_hash_only'].__len__()==idx['historical_source_gaps']==4
assert {(r['path'],r['sha256'])for r in hashonly}=={(r['path'],r['sha256'])for r in summary['historical_hash_only']}
for r in bindings:
 if r['kind']=='archived-source-blob':assert sha(archive_bytes[r['blob']])==r['sha256'] and len(archive_bytes[r['blob']])==r['bytes']
checkouts=json.loads(archive_bytes['checkout-byte-boundaries.json']);assert len(checkouts['records'])==2
for r in checkouts['records']:assert archive_bytes[r['blob']]==read(r['canonical_capture'])
outcomes=obj(P/'check-outcomes.json');assert dict(collections.Counter(str(r['exit_code'])for r in outcomes))==summary['check_exit_counts']=={'0':13,'101':15}
for r in outcomes:assert any(row['sha256']==r['report_sha256'] for row in selected)
gitreuse=obj(P/'git-hash-reuse.json');assert sha(read(gitreuse['prior_archive']))==gitreuse['prior_archive_sha256']
with tarfile.open(gitreuse['prior_archive'],'r:gz')as t:
 b=t.extractfile('git-objects.json').read();assert sha(b)==gitreuse['sha256']
prior_git=json.loads(b);current_git=obj(P/'git-objects.json');prior_by={(r['repository'],r['object']):r for r in prior_git}
for r in current_git:
 if r['hash_source']=='prior-archived-table':p=prior_by[(r['repository'],r['object'])];assert p['bytes']==r['bytes'] and p['sha256']==r['sha256']
bp=S/'target/m2/stage48-policy-native-c01-audit-01/handoff.json';br=S/'target/m2/stage48-policy-native-c01-01/report.json';assert sha(read(bp))=='56d37854a0e3ecd8888534945c1589a16df456988afaf0040ff1156f8eddf45b';assert sha(read(br))=='e5c093e9e450a949d32a87c0c2a37a15c67f4c857d8840f3f4d4424d69e92f14'
for p,r in inputs.items():assert sha(Path(p).read_bytes())==r['sha256']
save('inputs.json',inputs);save('archive-member-hashes.json',[{'archive':k[0],'member':k[1],**r}for k,r in archive_hashes.items()])
save('report.json',{'schema':1,'scope':'Read-only core publication integrity and claim review; no build/runtime/oracle/Git execution.','handoffSha256':sha(read(P/'handoff.json')),'archives':archives,'publicationFiles':len(handoff['publication_files']),'allArchivesBelow100MiB':True,'currentCandidate':{'sourceFiles':len(mapping),'literalLinks':len(links),'modeAndContentBindingsVerified':True,'rawGitSha1AndArchivedBlobSha256Verified':True,'historicalHashOnlyInCurrentMap':0},'historicalHashOnly':hashonly,'originalSelectedFilesVerified':len(selected),'checkExitCounts':summary['check_exit_counts'],'gitHashReuseArchiveVerified':gitreuse,'externalBClaimBinding':{'handoffPath':str(bp),'sha256':sha(read(bp)),'reportPath':str(br),'reportSha256':sha(read(br)),'scope':'Metadata binding only; B owns fullraw review.'},'claimAssessment':'No material publication issue found. Narrow earlier check scope, C01 whole-tree binding, four historical gaps, raw failures, heap source-only attribution, cycle-label limit and external B/root ownership are explicit.','originalChanges':[],'recursiveFilesystemTraversal':False})
print(json.dumps({'archives':len(archives),'archivePayloads':len(archive_hashes),'selectedRawFiles':len(selected),'C01files':len(mapping),'links':len(links),'historicalHashOnly':len(hashonly),'originalChanges':[]}))
