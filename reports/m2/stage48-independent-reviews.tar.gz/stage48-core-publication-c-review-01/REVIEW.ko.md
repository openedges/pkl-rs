# Stage48 core 게시 독립 검토

고정 handoff7d54ff40…의8파일 SHA와4archive를 대조했다. 전체1,053payload의 경로·길이·SHA,825개선택원본의 바이트·mode 및 create/별도verify0 기록이 일치했다. archive합31,101,353bytes,최대21,144,614bytes로각100MiB미만이다.

C01의53,236regular source와11symlink target/mode를 archived source metadata에 연결하고 실제 snapshot을 대조했다. currentmap의hash-only는0이며 과거4개버전은 복원불가능하다는 한계를 유지한다. Git binding은 실제source에서blob SHA1을 재계산하고 이전게시Git table/archive SHA를 연결했다. 기록된commit/tree membership은 producer의readonlyGit수집 provenance이며 새Git명령은 실행하지 않았다. source/artifact 실제mode는0644tar header와 별도metadata라는 점도 유지한다.

13성공/15실패check기록, 초기실패, 좁은이전capture와완전C01map구분, heap4개source-derived근거≠objectdump, cycleclass label≠ObjectId, 두CRLFcheckout차이, B/root/C별도소유권이명시돼있다. B440claim은 별도봉인handoff56d37854…/report e5c093e9…에 metadata로연결했고 raw재감사를대체하지않는다. legacybootstrap274/144/182와typed후속의분리도적절하다.

구체적인새게시결함은발견하지못했다. actual10734exit0이며명시map을사용해원본변경0을확인했다. 새평가/빌드/Java/테스트/Git/source수정없음. 전체M2와미완료factory/key/isCached/primary/repl/import*의완료주장은없다.
