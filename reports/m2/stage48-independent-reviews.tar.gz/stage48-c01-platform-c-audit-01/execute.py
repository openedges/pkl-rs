from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
p=Path(__file__).resolve().parent;o=p/'execution-01';o.mkdir(exist_ok=False)
h=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();command=[sys.executable,str(p/'audit.py')]
r={'command':command,'cwd':str(p),'scriptSha256':h(p/'audit.py'),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.UTC).isoformat(),'scope':'Read-only existing evidence audit, no evaluator runtime execution.'}
with(o/'stdout.bin').open('wb') as out,(o/'stderr.bin').open('wb') as err:
 c=subprocess.Popen(command,cwd=p,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);r['pid']=c.pid;(o/'launch.json').write_text(json.dumps(r,indent=2)+'\n');r['exitCode']=c.wait()
r.update(finishedUtc=datetime.datetime.now(datetime.UTC).isoformat(),stdoutSha256=h(o/'stdout.bin'),stderrSha256=h(o/'stderr.bin'))
(o/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(r['exitCode'])
