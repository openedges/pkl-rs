from pathlib import Path
import collections,hashlib,json,os,stat,struct
OUT=Path(__file__).resolve().parent
STAGE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');WORK=STAGE
CAND=STAGE/'target/m2/stage48-implementation-01/admission-candidate-build-01'
RUN=STAGE/'target/m2/stage48-c01-platform-control-01'
BOOT=STAGE/'target/m2/stage48-c01-bootstrap-control-01'
PIN='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0'
inputs={};links={};substitutions={};sources={};request_rows=[]
def digest(b):return hashlib.sha256(b).hexdigest()
def read(p):
 p=Path(p);actual=p
 try:relative=str(p.relative_to(STAGE))
 except ValueError:relative=None
 if relative in sources:
  actual=CAND/'sources'/relative;substitutions[str(p)]=str(actual)
 s=actual.lstat();assert stat.S_ISREG(s.st_mode),str(actual)
 b=actual.read_bytes();row={'sha256':digest(b),'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'readFrom':str(actual)}
 assert inputs.setdefault(str(p),row)==row,(str(p),'input changed')
 if relative in sources:assert row['sha256']==sources[relative]
 return b
def obj(p):return json.loads(read(p))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
def link(p):
 assert stat.S_ISLNK(p.lstat().st_mode);b=os.fsencode(os.readlink(p));links[str(p)]={'targetHex':b.hex(),'sha256':digest(b),'bytes':len(b)};return b
def known_runtime(p):
 p=Path(p)
 if p.is_symlink():link(p)
 return read(p.resolve(strict=True))
release=obj(CAND/'release.json');assert digest(read(CAND/'release.json'))==PIN
sources=obj(CAND/'source-after.json');assert digest(read(CAND/'source-after.json'))==release['source_map_sha256'] and len(sources)==53236
modes=obj(CAND/'source-modes.json');assert digest(read(CAND/'source-modes.json'))==release['source_modes_sha256'] and set(modes)==set(sources)
source_rows=[]
for name,h in sources.items():
 p=Path(name);assert not p.is_absolute() and '..' not in p.parts
 b=read(CAND/'sources'/name);assert digest(b)==h and (CAND/'sources'/name).lstat().st_mode&0o777==modes[name]
 source_rows.append({'path':name,'sha256':h,'mode':modes[name]})
sl=obj(CAND/'source-links.json');assert digest(read(CAND/'source-links.json'))==release['source_links_sha256'] and len(sl)==11
for n,row in sl.items():
 assert link(CAND/'sources'/n)==os.fsencode(row['target'])
for n,row in release['artifacts'].items():assert digest(read(row['path']))==row['sha256']
assert digest(read(release['build_report']))==release['build_report_sha256']
assert digest(read(release['environment']))==release['environment_sha256']
save('candidate-source-binding.json',{'releaseSha256':PIN,'mapSha256':release['source_map_sha256'],'paths':source_rows,'links':sl,'sourceScope':'All immutable C01 snapshot bytes/modes + literal links rehashed. Current live source may contain declared consumer-only follow-up and is not relabeled as original build input.'})
save('traversal-policy.json',{'recursiveTraversal':False,'selection':'Declared candidate/source maps, fixture manifests, driver indexes and explicit producer metadata only.','exactNotTraversed':[str(STAGE/'target/debug'),str(STAGE/'target/release'),str(STAGE/'target/wasm32-unknown-unknown'),str(STAGE/'target/stage48-cargo'),str(STAGE/'tools/platform/node_modules'),str(STAGE/'.cache')],'exceptions':'Explicit pinned browser/runtime package files and binaries; no recursive cache descent or generic build exclusion.'})
print('candidate snapshot verified',flush=True)
top=obj(RUN/'report.json');outer=obj(RUN/'outer-terminal.json');assert outer['sessionId']==28335 and outer['exitCode']==0
assert top['complete'] and not top['infrastructureErrors'] and not top['sourceChanges'] and top['platformArtifactsStable'] and not top['liveHandles']
assert top['candidateReleaseSha256']==PIN and top['sourceMapSha256']==release['source_map_sha256']
read(RUN/'run.py')
assert [r['label'] for r in top['commands']]==['primitives','renderer','resource','module-preparation','moduleinfo','security-denial','guest-catch','module-loader','module-inheritance']
assert [r['exitCode'] for r in top['commands']]==[0,0,0,0,0,0,0,1,1]
for c in top['commands']:
 assert obj(RUN/(c['label']+'.terminal.json'))==c
 for side in ['stdout','stderr']:assert digest(read(RUN/(c['label']+'.'+side+'.bin')))==c[side+'Sha256']
for n,h in top['platformArtifactHashes'].items():assert digest(read(RUN/'primitives'/n))==h
print('wrapper terminal/artifacts verified',flush=True)
base=RUN/'primitives';br=obj(base/'report.json');bm=obj(base/'sources.json')
assert bm==br['source_hashes']
for name,expected in bm.items():
    assert sources[name]==expected
    assert digest(read(base/'sources'/name))==expected
for command in obj(base/'commands.json'):
    assert command['exit_code'] in ([0,1] if command['name']=='oracle-native' else [0])
    read(base/(command['name']+'.stdout.bin'));read(base/(command['name']+'.stderr.bin'))
for name,expected in br['artifacts'].items():assert digest(read(base/name))==expected
native=obj(base/'oracle-native/report.json');cases=obj(base/'oracle-native/cases.json')['cases']
assert obj(WORK/'tests/fixtures/m1/semantics/cases.json')['cases']==cases
captures={}
for target,relative in [('java','oracle-native/java.stdout.bin'),('rust','oracle-native/rust.stdout.bin'),('node','execution/node.stdout.bin'),('browser','execution/browser.stdout.bin')]:
    data=read(base/relative);assert data.endswith(b'\n')
    lines=data[:-1].split(b'\n');assert len(lines)==len(cases)
    assert all(len(line)%2==0 and all(c in b'0123456789abcdef' for c in line) for line in lines)
    captures[target]=[bytes.fromhex(line.decode()) for line in lines]
for target,record in native['records'].items():
    for ch in ['stdout','stderr']:assert digest(read(base/'oracle-native'/(target+'.'+ch+'.bin')))==record[ch+'_sha256']
    assert record['exit_code']==0
baseline_rows=[];baseline_gaps={t:[] for t in ['rust','node','browser']}
for index,case in enumerate(cases):
    values={t:rows[index] for t,rows in captures.items()}
    row=br['comparisons'][index];assert row['id']==case['id']
    assert values['rust']==values['node']==values['browser']
    for target in values:assert digest(values[target])==row['sha256'][target]
    for target in baseline_gaps:
        match=values[target]==values['java'];assert match==row['oracle_matches'][target]
        if not match:baseline_gaps[target].append(case['id'])
    if any(values[t]!=values['java'] for t in baseline_gaps):
        assert row['mismatched_bytes_hex']=={t:v.hex() for t,v in values.items()}
        baseline_rows.append(row)
assert all(set(rows)==set(br['known_gaps']) for rows in baseline_gaps.values())
be=obj(base/'execution/execution.json');assert be==br['execution']
for n in ['node-checks.json','browser-checks.json','browser-launch.json','node-legacy-utf8-observations.json','browser-legacy-utf8-observations.json']:read(base/'execution'/n)
for ch in ['node','browser']:assert obj(base/'execution'/(ch+'-checks.json'))==be[ch+'Checks']
assert be['browserLaunchOptions']['executablePath']==be['browserExecutable']
assert digest(known_runtime(be['browserExecutable']))==be['browserExecutableSha256']
save('baseline-raw-audit.json',{'total':len(cases),'sharedEqual':len(cases),
 'oracleMatches':{t:len(cases)-len(g) for t,g in baseline_gaps.items()},'rawKnownGaps':baseline_rows,
 'capturedCommands':obj(base/'commands.json'),
 'qualification':'Decode complete canonical hex transport only; compare raw payload bytes without trimming or normalization. Historical Java-UTF8-only groups retain separate JS-unit observations.'})


print('baseline full raw verified',flush=True)
def unit_bytes(units):
    assert all(isinstance(n,int) and 0<=n<=65535 for n in units)
    return b''.join(struct.pack('>H',n) for n in units)
def java_utf8(units):return unit_bytes(units).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
def counter(raw):return dict(line.split('=',1) for line in raw.decode().splitlines())
supplements=[];all_calls=[]
for name,fixture_name in [('renderer','m2-renderer-portable'),('resource','m2-resource-portable'),('module-preparation','m2-module-portable')]:
    root=RUN/name;fixture_root=WORK/'tests/fixtures'/fixture_name
    er=obj(root/'execution.json');bundle=obj(root/'fixtures.json');assert bundle==obj(fixture_root/'fixtures.json')
    assert er['preflight']==obj(root/'preflight.process.json') and er['preflight']['exitCode']==0
    read(root/'preflight.stdout.bin');read(root/'preflight.stderr.bin')
    assert not er['infrastructureErrors'] and not er['browserErrors'] and not er['changedInputs']
    assert er['serverMissingAssetProbe']['status']==404 and er['serverMissingAssetProbe']['bodyHex']==''
    assert er['browserLaunchOptions']['executablePath']==er['browserExecutable']
    assert digest(known_runtime(er['browserExecutable']))==er['browserExecutableSha256']
    for path,expected in er['artifactAndInputHashes'].items():assert digest(read(Path(path)))==expected,path
    manifest=obj(fixture_root/'manifest.json')
    for relative,record in manifest['files'].items():
        data=read(fixture_root/relative);assert digest(data)==record['sha256'] and len(data)==record['bytes']
    provenance=obj(fixture_root/'provenance.json') if fixture_name!='m2-renderer-portable' else None
    reader_total={};counts={};events={}
    for target in ['node','browser']:
        raw=obj(root/(target+'.raw.json'));assert len(raw)==len(bundle['fixtures'])
        count=collections.Counter();reader_total[target]=0;events[target]=0
        for session_index,(f,a) in enumerate(zip(bundle['fixtures'],raw)):
            assert (f['id'],f['repeat'],f['session'])==(a['id'],a['repeat'],a['session'])
            assert a['constructorError'] is None and a['acquisitionError'] is None
            assert len(a['calls'])==len(f['expected'])==len(f['expressions'])
            assert a['readerUris']==[p['uri'] for p in f['readerPlan']]
            request_rows.append({'group':name,'target':target,'sessionIndex':session_index,'profile':a.get('modulePolicy'),'requests':a.get('moduleRequests',[])})
            reader_total[target]+=len(a['readerUris'])
            architecture=a['architecture'];assert architecture['terminalSlots']==0 and architecture['ownedResultsStable'] and architecture['consumedReaderPlan']
            directory=root/target/str(session_index)
            assert obj(directory/'actual.json')==a and obj(directory/'expected.json')==f['expected']
            obj(directory/'comparison.json')
            if name=='module-preparation':assert len(a['observableEventsByCall'])==len(a['calls'])
            for index,(expected,call) in enumerate(zip(f['expected'],a['calls'])):
                assert call['index']==index and call['expression']==f['expressions'][index]
                for field in ['status','stdoutUnits','stderrUnits','readsBefore','readsAfter']:assert call[field]==expected[field],(name,target,session_index,index,field)
                assert call['status'] in ['success','error']
                if call['status']=='error':assert call['disposition']=='language-error'
                if name=='module-preparation':
                    assert call['observableEvents']==expected['observableEvents']==a['observableEventsByCall'][index]
                    events[target]+=len(call['observableEvents'])
                # Link each expected channel/status/count back to captured Java
                # bytes, separately from trusting the comparison booleans.
                if name=='renderer':
                    group,case=f['id'].split('/',1)
                    prefix=fixture_root/'provenance'/group/'cases'/case/str(f['repeat'])/'calls'/('session-'+str(f['session']))/('outer-'+str(index))
                    java_read=lambda suffix:read(Path(str(prefix)+'.'+suffix+'.bin'))
                elif name=='resource':
                    sessions=[s for s in provenance['sessions'] if (s['id'],s['repeat'],s['session'])==(f['id'],f['repeat'],f['session'])]
                    assert len(sessions)==1
                    prefix=fixture_root/sessions[0]['selectedRawJava'][index]['rawLocalPrefix']
                    java_read=lambda suffix:read(Path(str(prefix)+'.'+suffix+'.bin'))
                else:
                    group,case=f['id'].split('/',1)
                    original=Path(provenance['pins']['groups'][group]['root'])/'cases'/case/str(f['repeat'])/'calls'/('session-'+str(f['session']))/('outer-'+str(index))
                    def java_read(suffix):
                        record=provenance['originalPaths'][str(original)+'.'+suffix+'.bin']
                        data=read(fixture_root/record['path']);assert digest(data)==record['sha256'];return data
                assert java_read('status')==(expected['status']+'\n').encode()
                assert java_read('expression')==f['expressions'][index].encode()
                for side in ['before','after']:
                    cnt=int(counter(java_read('counters-'+side))['read'])
                    assert java_read('reads-'+side)==str(cnt).encode() and cnt==expected['reads'+side.title()]
                channel_hashes={}
                for channel in ['stdout','stderr']:
                    units=unit_bytes(call[channel+'Units']);utf8=java_utf8(call[channel+'Units'])
                    assert units==java_read(channel+'.code-units') and utf8==java_read(channel)
                    assert utf8.hex()==expected[channel+'Hex']
                    assert read(directory/f'{index}.{channel}.utf16be.bin')==units
                    assert read(directory/f'{index}.{channel}.java-utf8.bin')==utf8
                    channel_hashes[channel]={'utf16be':digest(units),'javaUtf8':digest(utf8)}
                count[call['status']]+=1
                all_calls.append({'group':name,'target':target,'sessionIndex':session_index,'callIndex':index,'status':call['status'],'channels':channel_hashes})
        counts[target]=dict(count)
    assert er['selectedApiCallsPerTarget']==sum(len(f['expressions']) for f in bundle['fixtures'])
    supplements.append({'group':name,'executionSha256':digest(read(root/'execution.json')),
        'sessionsPerTarget':len(bundle['fixtures']),'callsPerTarget':er['selectedApiCallsPerTarget'],
        'counts':counts,'readerRequests':reader_total,'observableProjectionEvents':events,
        'terminalSlotsAllZero':True,'missingAsset404EmptyBody':True,
        'unselectedOrOtherBoundaries':bundle['unexecutedApiBoundaries']})


save('supplemental-raw-audit.json',{'groups':supplements,'calls':all_calls,'requestRows':request_rows})
print('primary supplements full raw verified',flush=True)

# Existing result bytes only: no verifier, Node, browser or evaluator is executed.
legacy=[];strict_spi=[];http=[];all_requests=[]
for name in ['renderer','resource','module-preparation','moduleinfo','security-denial','guest-catch','module-loader','module-inheritance']:
 root=RUN/name;er=obj(root/'execution.json')
 assert not er['infrastructureErrors'] and not er['browserErrors'] and not er['changedInputs']
 assert er['browserLaunchOptions']['executablePath']==er['browserExecutable']
 assert digest(known_runtime(er['browserExecutable']))==er['browserExecutableSha256']
 for path,h in er['artifactAndInputHashes'].items():assert digest(read(path))==h,(name,path)
 http.append({'group':name,'explicitBrowserPath':er['browserExecutable'],'browserSha256':er['browserExecutableSha256'],'missingAssetProbe':er.get('serverMissingAssetProbe'),'httpScope':'Driver source served paths are source-bound; only recorded missingAssetProbe is actual404 evidence. Older loader server readFile has no per-response payload digest.'})
 if name in ['renderer','resource','module-preparation']:continue
 fixture_root=STAGE/'tests/fixtures'/({'moduleinfo':'m2-moduleinfo','security-denial':'m2-security-denial','guest-catch':'m2-guest-catch','module-loader':'m2-module-loading','module-inheritance':'m2-module-inheritance-platform'}[name])
 manifest=obj(fixture_root/'manifest.json')
 for n,row in manifest['files'].items():
  b=read(fixture_root/n);assert digest(b)==row['sha256'] and len(b)==row['bytes']
 fixtures=obj(root/('fixtures.json' if name.startswith('module-') else 'fixture-data.json'))
 for target in ['node','browser']:
  raws=obj(root/(target+'.raw.json'));counts=collections.Counter();rows_checked=0;calls_checked=0
  if name in ['module-loader','module-inheritance']:
   assert len(raws)==len(fixtures)*2
   expected_pairs=[(f,r) for f in fixtures for r in [0,1]]
   for row,(f,repeat),claimed in zip(raws,expected_pairs,er['targets'][target]['results']):
    assert row['id']==f['id'] and row['repeat']==repeat and not row['acquisitionError']
    assert row['architecture']['terminalSlots']==0 and row['architecture']['ownedResultsStable']
    directory=root/target/row['id']/str(repeat);assert obj(directory/'actual.json')==row and obj(directory/'expected.json')==f['expected'];assert obj(directory/'result.json')==claimed
    for group,expected,actual in [('results',f['expected']['results'],row['results']),('callbacks',f['expected'].get('callbacks',[]),[dict(c['result'],path=c['path']) for c in row['callbacks']])]:
     assert len(actual)==len(expected)
     for i,(e,a) in enumerate(zip(expected,actual)):
      assert a['kind']==e['kind']
      if e['kind']=='bytes':b=bytes(a['bytes']);assert b.hex()==e['bytesHex']
      else:
       units=a['valueUnits'] if a['kind']=='value' else a.get('errorUnits')
       b=bytes(a['errorBytes']) if a.get('errorBytes') is not None else java_utf8(units)
       assert b.hex()==e['javaUtf8Hex']
       expunits=e.get('javaValueUnits' if e['kind']=='value' else 'javaErrorUnits')
       if expunits is not None:assert units==expunits and read(directory/f'{group}-{i}.actual.utf16be.bin')==unit_bytes(units) and read(directory/f'{group}-{i}.java.utf16be.bin')==unit_bytes(expunits)
      assert read(directory/f'{group}-{i}.actual.bin')==b and read(directory/f'{group}-{i}.java.bin')==b
      if e.get('javaExitCode') is not None:assert a['exitCode']==e['javaExitCode']
      assert a.get('actionIndex' if group=='results' else 'path')==e.get('actionIndex' if group=='results' else 'path')
      calls_checked+=1
    if f['expected'].get('logs') is not None:assert [{k:v for k,v in log.items() if k!='token'} for log in row['logs']]==f['expected']['logs']
    actual_counts=dict(collections.Counter(q['kind'] for q in row['requests']));assert actual_counts==claimed['requestCounts']
    exp=f['expected'].get('requestCounts');projection=None
    if exp is not None:
     assert set(exp)=={'resolve','load-source'}
     projection=all(actual_counts.get(k,0)==v for k,v in exp.items())
     assert projection
     extras={k:v for k,v in actual_counts.items() if k not in exp};assert set(extras)<= {'check-import'}
     full=projection and all(exp.get(k,0)==v for k,v in actual_counts.items());assert full==claimed['requestCountsMatch']
     # Expected counts link to actual Java's two SPI counters, not an import policy trace.
     if name=='module-loader':pre=fixture_root/'origins'/f['provenance']['origin']/'cases'/f['provenance']['id']/'0/calls/counters.bin'
     else:
      bindings=manifest['files'];candidates=[n for n in bindings if n.endswith('/'+f['id']+'/0/calls/counters.bin')]
      if not candidates:candidates=[n for n in bindings if n.endswith('/0/calls/counters.bin') and f['id'] in n]
      assert len(candidates)==1,(f['id'],candidates);pre=fixture_root/candidates[0]
     j=counter(read(pre));assert exp=={'resolve':int(j['resolve']),'load-source':int(j['source'])}
     strict_spi.append({'group':name,'target':target,'id':f['id'],'repeat':repeat,'expectedTwoSpiCounts':exp,'allActualRequestCounts':actual_counts,'observedSpiProjectionMatches':projection,'unobservedPolicyRequests':extras,'originalStrictRequestCountsMatch':full,'originalStatus':claimed['status']})
    assert all(c['rawMatch'] and c['indexMatches'] for c in claimed['comparisons'])
    assert claimed['logsMatch'] is not False and claimed['resourceReadCountsMatch'] is not False and claimed['architectureMatch']
    assert (claimed['status']=='mismatch')==(claimed['requestCountsMatch'] is False)
    all_requests.append({'group':name,'target':target,'id':row['id'],'repeat':repeat,'profile':'default helper delegated by module-loader-session; raw requests retained','requests':row['requests']})
    counts[claimed['status']]+=1;rows_checked+=1
   assert dict(counts)==er['targets'][target]['statusCounts']
  else:
   assert len(raws)==len(fixtures)
   oracle=obj(fixture_root/'oracle/report.json') if name!='guest-catch' else None
   for f,a in zip(fixtures,raws):
    assert a['id']==f['id'] and a['repeat']==f['repeat'] and a['acquisitionError'] is None
    all_requests.append({'group':name,'target':target,'id':a['id'],'repeat':a['repeat'],'profile':a.get('modulePolicy'),'requests':a.get('moduleRequests',[])})
    if name=='guest-catch':
     directory=root/target/a['group']/a['id']/str(a['repeat']);assert obj(directory/'actual.json')==a
     if f['comparisonScope']=='frontend-constructor-only':
      assert a['constructorError']['messageUnits']==f['expected']['calls'][0]['units'] and not a['calls'];counts['constructor-boundary-pass']+=1;continue
     assert a['constructorError'] is None and a['architecture']['terminalSlots']==0 and a['architecture']['ownedResultsStable']
     if f['comparisonScope']=='full-ordered-api':assert a['counts']==f['expected']['counters'] and a['events']==f['expected']['events'] and a['logs']==f['expected']['logs']
     for i,(c,e) in enumerate(zip(a['calls'],f['expected']['calls'])):
      assert c['prefix']==e['prefix'] and c['kind']==e['kind'] and c['units']==e['units'] and java_utf8(c['units'])==bytes(e['utf8'])
      calls_checked+=1
     if f['comparisonScope']=='full-ordered-api':assert len(a['calls'])==len(f['expected']['calls']);counts['pass']+=1
     else:counts['terminal-partial-pass']+=1
    else:
     directory=root/target/a['id']/str(a['repeat']);assert obj(directory/'actual.json')==a
     assert a['constructorError'] is None and a['architecture']['terminalSlots']==0 and a['architecture']['ownedResultsStable']
     obs=next(o for o in oracle['observations'] if o['repeat']==f['repeat'])
     java_calls=[c for c in obs['calls'] if (name!='moduleinfo' or c['case']==f['id']) and c['prefix'].startswith('outer-')]
     assert len(a['calls'])==len(f['expected'])==len(java_calls)
     for c,e,j in zip(a['calls'],f['expected'],java_calls):
      assert c['prefix']==e['prefix']==j['prefix']
      assert e['unitHex']==j['utf16BEHex'] and e['utf8Hex']==j['utf8Hex']
      if f.get('comparisonScope')=='java-internal-parser-boundary':assert c['disposition']=='unsupported';counts['java-internal-unsupported-boundary']+=1
      else:
       assert c['kind']==e['kind'] and unit_bytes(c['units']).hex()==e['unitHex'] and java_utf8(c['units']).hex()==e['utf8Hex']
       if c['kind']=='error':assert c['disposition']=='language-error'
       if name=='security-denial':assert c['denialsAfter']==e['denialsAfter']==int(counter(j['countersAfter'].encode())['denied'])
       counts['pass']+=1
      calls_checked+=1
    rows_checked+=1
   assert dict(counts)==er['targets'][target].get('counts',er['targets'][target].get('statusCounts'))
  legacy.append({'group':name,'target':target,'rowsChecked':rows_checked,'callsChecked':calls_checked,'counts':dict(counts)})
 print('legacy raw verified '+name,flush=True)
save('legacy-raw-audit.json',{'groups':legacy,'allRawRequests':all_requests,'spiScope':strict_spi,'noRequestsDropped':True,'qualification':'Original strict mismatch preserved; projection computed only in audit against actual Java resolve/source counters, not new oracle data or reblessed fixtures. ModuleInfo internal boundary and guest constructor/terminal partial scopes retained.'})
save('http-browser-binding.json',http)

bt=obj(BOOT/'terminal.json');bo=obj(BOOT/'outer-terminal.json');assert bo['sessionId']==41297 and bo['exitCode']==bt['exitCode']==1
assert bt['releaseSha256']==PIN and bt['inputHashesBefore']==bt['inputHashesAfter'] and not bt['liveHandles']
for path,h in bt['inputHashesBefore'].items():assert digest(read(path))==h
for side in ['stdout','stderr']:assert digest(read(BOOT/(side+'.bin')))==bt[side+'Sha256']
read(BOOT/'run.py');read(BOOT/'launch.json');root=BOOT/'execution';er=obj(root/'execution.json')
assert not er['infrastructureErrors'] and not er['browserErrors'] and not er['changedInputs'] and er['acquisitionPassed'] and not er['strictJavaCompatibilityPassed']
assert er['browserLaunchOptions']['executablePath']==er['browserExecutable'] and digest(known_runtime(er['browserExecutable']))==er['browserExecutableSha256']
for path,h in er['artifactAndInputHashes'].items():assert digest(read(path))==h
assert read(root/'bootstrap-session.mjs')==read(STAGE/'tools/platform/bootstrap-session.mjs')
assert read(root/'module-policy-session.mjs')==read(STAGE/'tools/platform/module-policy-session.mjs')
fixtures=obj(root/'fixture-data.json');assert len(fixtures)==8
bootstrap=[]
for target in ['node','browser']:
 rows=obj(root/(target+'.raw.json'));assert len(rows)==8;counts=collections.Counter();mismatches=[]
 for f,a in zip(fixtures,rows):
  assert a['id']==f['id'] and a['repeat']==f['repeat'] and len(a['sessions'])==3
  for i,s in enumerate(a['sessions']):
   assert s['constructorError'] is None and s['acquisitionError'] is None and s['architecture']['terminalSlots']==0 and s['architecture']['ownedResultsStable'] and len(s['calls'])==25
   d=root/target/a['id']/str(a['repeat'])/('session-'+str(i));assert obj(d/'actual.json')==s
   all_requests.append({'group':'bootstrap','target':target,'id':a['id'],'repeat':a['repeat'],'session':i,'profile':a['modulePolicy'],'requests':s['moduleRequests']})
   expected=[c for c in f['expected'] if c['session']==i]
   for c,e in zip(s['calls'],expected):
    checks={'prefix':c['prefix']==e['prefix'],'status':c['kind']==e['kind'],'units':unit_bytes(c['units']).hex()==e['utf16BEHex'],'javaUtf8':java_utf8(c['units']).hex()==e['utf8Hex'],'disposition':c['kind']!='error' or c['disposition']=='language-error'}
    if f['reader']=='counted':checks.update(readsBefore=c['readsBefore']==e['readsBefore'],readsAfter=c['readsAfter']==e['readsAfter'])
    status='unsupported' if c['disposition']=='unsupported' else 'pass' if all(checks.values()) else 'mismatch'
    comparison=obj(d/(c['prefix']+'.comparison.json'));assert comparison['status']==status
    assert read(d/(c['prefix']+'.actual.utf16be.bin'))==unit_bytes(c['units']) and read(d/(c['prefix']+'.actual.utf8.bin'))==java_utf8(c['units'])
    if status!='pass':mismatches.append({'id':a['id'],'repeat':a['repeat'],'session':i,'prefix':c['prefix'],'status':status,'failedChecks':[k for k,v in checks.items() if not v],'expression':comparison['expression']})
    counts[status]+=1
 assert sum(counts.values())==600 and dict(counts)==er['targets'][target]['counts']
 bootstrap.append({'target':target,'counts':dict(counts),'calls':600,'nonpass':mismatches})
assert bootstrap[0]['counts']==bootstrap[1]['counts']
save('bootstrap-raw-audit.json',{'actualExitCode':1,'acquisitionPassed':True,'strictJavaCompatibilityPassed':False,'targets':bootstrap,'newConsumerFollowup':'Original legacy respondString nonabsent completion remains source-bound C01. Typed-resource follow-up, when available, is a separate consumer-only profile using same artifacts/Java; not retroactively promoted.'})
print('bootstrap full raw verified',flush=True)
save('raw-module-requests.json',{'primaryThreeGroups':request_rows,'legacyAndBootstrap':all_requests,'qualification':'All observed raw typed requests preserved; named default profile is transport delegation, not an observed Java policy trace.'})
package=obj(STAGE/'tools/platform/package.json');lock=obj(STAGE/'tools/platform/package-lock.json');pin=package['devDependencies']['playwright']
for n in ['playwright','playwright-core']:
 assert obj(STAGE/'tools/platform/node_modules'/n/'package.json')['version']==pin and lock['packages']['node_modules/'+n]['version']==pin
save('inputs-before.json',inputs);save('literal-links-before.json',links);save('frozen-source-read-mapping.json',substitutions)
changes=[]
for logical,before in inputs.items():
 p=Path(before['readFrom']);s=p.lstat();b=p.read_bytes();after={'sha256':digest(b),'bytes':len(b),'mode':stat.S_IMODE(s.st_mode),'readFrom':str(p)}
 if after!=before:changes.append({'logicalPath':logical,'before':before,'after':after})
for path,before in links.items():
 p=Path(path);assert p.is_symlink();b=os.fsencode(os.readlink(p));assert {'targetHex':b.hex(),'sha256':digest(b),'bytes':len(b)}==before
assert not changes,changes
save('source-stability.json',{'readInputs':len(inputs),'literalLinks':len(links),'sourcePaths':len(sources),'originalChanges':changes,'liveSourceQualification':'Source-root paths in the C01 map were authenticated against the immutable C01 snapshot. This does not claim the declared later live bootstrap helper has original C01 bytes.'})
save('report.json',{'schema':1,'scope':'Independent existing raw/source/artifact readback; no runtime/oracle/browser/test/Git/acquisition execution.','candidateReleaseSha256':PIN,'candidateSourceMapSha256':release['source_map_sha256'],'sourcePaths':len(sources),'literalLinks':len(sl),'wrapperTerminal':outer,'commandExits':{c['label']:c['exitCode'] for c in top['commands']},'baseline':{'total':len(cases),'sharedEqual':len(cases),'knownGaps':baseline_gaps},'primarySupplementCounts':supplements,'legacyCounts':legacy,'bootstrap':{'actualExitCode':1,'countsPerTarget':bootstrap[0]['counts'],'acquisitionPassed':True,'strictJavaCompatibilityPassed':False},'requestComparisonQualification':'Loader/inheritance strict failures retained. All API payload/code-unit/exit channels, logs and observed two-SPI counts matched; new CheckImport raw requests have no policy trace expectation in those original fixtures.','newPolicyTracePassClaimed':False,'originalChanges':changes,'runtimeGaps':'Known baseline regex gaps, bootstrap runtime and legacy consumer counter boundaries, guest partial/constructor, ModuleInfo Java internal and full Stage48 admission obligations remain scoped/open.','sourceFollowup':'Original C01 source bound by immutable snapshot + acquisition copied helper. Later bootstrap typed completion source is separate.'})
print(json.dumps({'sources':len(sources),'inputCount':len(inputs),'baseline':len(cases),'primaryFullCalls':len(all_calls),'legacyGroups':len(legacy),'bootstrap':bootstrap[0]['counts'],'originalChanges':changes}),flush=True)
