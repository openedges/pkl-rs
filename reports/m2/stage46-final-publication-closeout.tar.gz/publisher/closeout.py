"""Archive publication execution metadata after its actual terminal receipt."""
from pathlib import Path
import hashlib
import json
import os
import stat
import subprocess
import sys
import tarfile

MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
OUT = Path(__file__).parent
REPORTS = MAIN / 'reports/m2'
DEST = REPORTS / 'stage46-final-publication-closeout.tar.gz'
GATHER = OUT / 'closeout-gathered'
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda p: json.loads(p.read_bytes())
save = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
assert not DEST.exists() and not GATHER.exists()
receipt = load(OUT / 'execution/outer-terminal.json')
execution = load(OUT / 'execution/report.json')
assert receipt['exit_code'] == 0 and execution['terminal'] and execution['exitCode'] == 0
assert receipt['process_report_sha256'] == sha((OUT / 'execution/report.json').read_bytes())
publication = load(OUT / 'report.json')
assert publication['publication_completed'] and not publication['originalChanges']
sources = [
    ('publisher', OUT, ['publish.py', 'run.py', 'closeout.py', 'closeout-run.py', 'report.json', 'commands.json', 'archive-readbacks.json', 'originals-after.json', 'partition-plan.json']),
    ('execution', OUT / 'execution', ['report.json', 'active.json', 'outer-terminal.json', 'stdout.bin', 'stderr.bin']),
    ('reviewed-publication', REPORTS, ['stage46-final-summary.json', 'stage46-final-regression-captures.json']),
]
rows = []
GATHER.mkdir()
for label, root, names in sources:
    for name in names:
        source = root / name
        assert stat.S_ISREG(source.lstat().st_mode)
        data = source.read_bytes()
        relative = label + '/' + name
        target = GATHER / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        rows.append({'path': relative, 'source': str(source), 'bytes': len(data), 'sha256': sha(data)})
for command in publication['commands']:
    root = OUT / 'commands' / command['label']
    for name in ['result.json', 'stdout.bin', 'stderr.bin']:
        source = root / name
        data = source.read_bytes()
        relative = 'commands/' + command['label'] + '/' + name
        target = GATHER / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        rows.append({'path': relative, 'source': str(source), 'bytes': len(data), 'sha256': sha(data)})
save(GATHER / 'CLOSEOUT-SOURCE.json', {'scope': 'Publication metadata after actual first-phase terminal. Pre-pointer summary remains immutable in this archive.', 'files': rows})
commands = []
for action in ['create', 'verify']:
    argv = [sys.executable, str(MAIN / 'tools/evidence.py'), action, *([str(GATHER), str(DEST)] if action == 'create' else [str(DEST)])]
    root = OUT / ('closeout-' + action)
    root.mkdir()
    with (root / 'stdout.bin').open('wb') as stdout, (root / 'stderr.bin').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=MAIN, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=stdout, stderr=stderr)
        code = process.wait()
    record = {'argv': argv, 'pid': process.pid, 'exitCode': code, 'stdoutSha256': sha((root / 'stdout.bin').read_bytes()), 'stderrSha256': sha((root / 'stderr.bin').read_bytes())}
    save(root / 'result.json', record)
    commands.append(record)
    assert code == 0
    print('closeout', action, 'exit', code, flush=True)
by_path = {row['path']: row for row in rows}
by_path['CLOSEOUT-SOURCE.json'] = {'bytes': (GATHER / 'CLOSEOUT-SOURCE.json').stat().st_size, 'sha256': sha((GATHER / 'CLOSEOUT-SOURCE.json').read_bytes())}
with tarfile.open(DEST, 'r:gz') as archive:
    members = {member.name: member for member in archive.getmembers()}
    assert set(members) == set(by_path) | {'EVIDENCE.json'}
    inventory = json.load(archive.extractfile(members['EVIDENCE.json']))
    assert {row['path']: {'bytes': row['bytes'], 'sha256': row['sha256']} for row in inventory['files']} == {name: {'bytes': row['bytes'], 'sha256': row['sha256']} for name, row in by_path.items()}
    for name, row in by_path.items():
        data = archive.extractfile(members[name]).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        assert data == (GATHER / name).read_bytes()
        if 'source' in row:
            assert data == Path(row['source']).read_bytes()
save(OUT / 'closeout-report.json', {'scope': 'Publication closeout capture; no compatibility acquisition.', 'archive': str(DEST), 'archiveSha256': sha(DEST.read_bytes()),
                                   'payloadFiles': len(by_path), 'payloadBytes': sum(row['bytes'] for row in by_path.values()), 'compressedBytes': DEST.stat().st_size,
                                   'commands': commands, 'independentMemberAndOriginalBytesEqual': True,
                                   'prePointerSummarySha256': sha((REPORTS / 'stage46-final-summary.json').read_bytes())})
print('CLOSEOUT COMPLETE', flush=True)
