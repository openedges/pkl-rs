//! Node experiment; no separate evaluator or Java fallback.
use napi::{
    Env, Error, Result,
    bindgen_prelude::{BigInt, JsObjectValue, Uint8Array, Utf16String},
};
use napi_derive::napi;
use pkl_runtime::{
    probe,
    source::SourceText,
    value::{PklString, Value},
};

fn error(e: impl ToString) -> Error {
    Error::from_reason(e.to_string())
}
// Throw the exact native object without Error::from(Unknown): that conversion
// coerces it to a string and reads `cause`, allowing unexpected JS callbacks.
// PendingException tells napi codegen to preserve the already-thrown object.
fn text_error(env: &Env, text: PklString) -> Error {
    let create = || -> Result<Error> {
        let mut object = env.create_error(Error::from_reason(""))?;
        object.set_named_property(
            "message",
            env.create_string_utf16(text.encode_utf16().collect::<Vec<_>>())?,
        )?;
        env.throw(object)?;
        Ok(Error::from_status(napi::Status::PendingException))
    };
    match create() {
        Ok(error) | Err(error) => error,
    }
}
fn unsigned(value: f64) -> Result<u32> {
    probe::unsigned_argument(value).map_err(error)
}
fn string(value: &Utf16String) -> Result<String> {
    String::from_utf16(value).map_err(|_| error("unpaired UTF-16 surrogate is unsupported"))
}
fn pkl_text(value: &Utf16String) -> PklString {
    PklString::from_utf16(value.to_vec())
}
fn source_text(value: &Utf16String) -> SourceText {
    SourceText::from(pkl_text(value))
}
fn js_text<'env>(env: &'env Env, text: &PklString) -> Result<napi::JsString<'env>> {
    env.create_string_utf16(text.encode_utf16().collect::<Vec<_>>())
}
fn integer(value: BigInt) -> Result<i64> {
    if value.words.len() > 1 {
        return Err(error("BigInt is outside signed 64-bit range"));
    }
    let magnitude = value.words.first().copied().unwrap_or(0);
    if value.sign_bit && magnitude == (1u64 << 63) {
        return Ok(i64::MIN);
    }
    let magnitude =
        i64::try_from(magnitude).map_err(|_| error("BigInt is outside signed 64-bit range"))?;
    Ok(if value.sign_bit {
        -magnitude
    } else {
        magnitude
    })
}

#[napi]
pub fn primitive(family: Utf16String, input: Utf16String) -> Result<String> {
    probe::primitive(&string(&family)?, &string(&input)?).map_err(error)
}
#[napi]
pub fn evaluate(env: Env, source: Utf16String, member: Utf16String) -> Result<String> {
    probe::evaluate_member_text(source_text(&source), pkl_text(&member))
        .map(probe::encode_value)
        .map_err(|text| text_error(&env, text))
}
/// Development-only scalar boundary with shared Pkl diagnostic rendering.
#[napi]
pub fn evaluate_language<'env>(
    env: &'env Env,
    source: Utf16String,
    uri: Utf16String,
    module_name: Utf16String,
    expression: Utf16String,
    power_assertions: Option<bool>,
) -> Result<napi::JsString<'env>> {
    pkl_runtime::evaluation::scalar_expression_text_with_options(
        source_text(&source),
        pkl_text(&uri),
        pkl_text(&module_name),
        source_text(&expression),
        pkl_runtime::evaluation::EvaluationOptions {
            power_assertions: power_assertions.unwrap_or(false),
        },
    )
    .map_err(|text| text_error(env, text))
    .and_then(|text| env.create_string_utf16(text.encode_utf16().collect::<Vec<_>>()))
}
/// Portable frontend bytes; this does not execute a native process or render output.
#[napi(object)]
pub struct ModuleFrontendOutcome {
    pub phase: String,
    pub disposition: String,
    pub reason: Option<String>,
    pub stdout: Uint8Array,
    pub stderr: Uint8Array,
    pub exit_code: i32,
}

#[napi]
pub fn evaluate_module_frontend(
    source: Utf16String,
    uri: Utf16String,
    module_name: Utf16String,
    arguments: Vec<Utf16String>,
) -> Result<ModuleFrontendOutcome> {
    use pkl_runtime::evaluation::frontend::{
        LosslessModuleSourceInput, arguments::parse_module_eval_args,
    };
    let arguments = arguments.iter().map(string).collect::<Result<Vec<_>>>()?;
    let invocation = parse_module_eval_args(&arguments).map_err(error)?;
    let source = source_text(&source);
    let uri = pkl_text(&uri);
    let module_name = pkl_text(&module_name);
    let result = pkl_runtime::evaluation::frontend::evaluate_module_frontend(
        LosslessModuleSourceInput {
            text: source,
            uri,
            inferred_name: module_name,
        },
        &invocation.options,
    );
    Ok(ModuleFrontendOutcome {
        phase: result.phase.as_str().to_owned(),
        disposition: result.disposition.as_str().to_owned(),
        reason: result.reason.map(str::to_owned),
        stdout: Uint8Array::new(result.stdout),
        stderr: Uint8Array::new(result.stderr),
        exit_code: result.exit_code,
    })
}

/// Actual shared module-output bytes. The legacy frontend-only export remains
/// separate; platform code neither walks objects nor renders their values.
#[napi(object)]
pub struct ModuleOutputOutcome {
    pub phase: String,
    pub disposition: Option<String>,
    pub reason: Option<String>,
    pub stdout: Uint8Array,
    pub stderr: Uint8Array,
    pub exit_code: i32,
}

#[napi]
pub fn evaluate_module_output(
    source: Utf16String,
    uri: Utf16String,
    module_name: Utf16String,
    arguments: Vec<Utf16String>,
) -> Result<ModuleOutputOutcome> {
    use pkl_runtime::evaluation::frontend::{
        LosslessModuleSourceInput, arguments::parse_module_eval_args,
    };
    let arguments = arguments.iter().map(string).collect::<Result<Vec<_>>>()?;
    let invocation = parse_module_eval_args(&arguments).map_err(error)?;
    let source = source_text(&source);
    let uri = pkl_text(&uri);
    let module_name = pkl_text(&module_name);
    let result = pkl_runtime::evaluation::frontend::evaluate_module_output(
        LosslessModuleSourceInput {
            text: source,
            uri,
            inferred_name: module_name,
        },
        &invocation.options,
    );
    Ok(ModuleOutputOutcome {
        phase: result.phase.as_str().to_owned(),
        disposition: result.disposition.map(|value| value.as_str().to_owned()),
        reason: result.reason.map(str::to_owned),
        stdout: Uint8Array::new(result.stdout),
        stderr: Uint8Array::new(result.stderr),
        exit_code: result.exit_code,
    })
}

/// Development-only ordered calls on one evaluator, retaining failures as data.
#[napi]
pub fn evaluate_language_sequence<'env>(
    env: &'env Env,
    source: Utf16String,
    uri: Utf16String,
    module_name: Utf16String,
    expressions: Vec<Utf16String>,
    power_assertions: Option<bool>,
) -> Result<Vec<napi::JsString<'env>>> {
    let expressions = expressions.iter().map(source_text).collect::<Vec<_>>();
    pkl_runtime::evaluation::scalar_expressions_source_with_options(
        source_text(&source),
        pkl_text(&uri),
        pkl_text(&module_name),
        &expressions,
        pkl_runtime::evaluation::EvaluationOptions {
            power_assertions: power_assertions.unwrap_or(false),
        },
    )
    .map_err(|text| text_error(env, text))?
    .into_iter()
    .map(|result| {
        let (prefix, text) = match result {
            Ok(value) => ("value\t", value),
            Err(error) => ("error\t", error),
        };
        env.create_string_utf16(
            prefix
                .encode_utf16()
                .chain(text.encode_utf16())
                .collect::<Vec<_>>(),
        )
    })
    .collect()
}
#[napi]
pub fn roundtrip_string<'env>(env: &'env Env, input: Utf16String) -> Result<napi::JsString<'env>> {
    match probe::identity(Value::String(pkl_text(&input))).map_err(error)? {
        Value::String(value) => js_text(env, &value),
        _ => Err(error("invalid engine result")),
    }
}
#[napi]
pub fn roundtrip_integer(input: BigInt) -> Result<BigInt> {
    match probe::identity(Value::Int(integer(input)?.into())).map_err(error)? {
        Value::Int(value) => Ok(BigInt::from(value.get())),
        _ => Err(error("invalid engine result")),
    }
}
#[napi]
pub fn roundtrip_bytes(input: Uint8Array) -> Result<Uint8Array> {
    match probe::identity(Value::Bytes(input.to_vec().into())).map_err(error)? {
        Value::Bytes(value) => Ok(Uint8Array::new(value.to_vec())),
        _ => Err(error("invalid engine result")),
    }
}

#[napi]
pub struct HostProbe {
    inner: probe::HostProbe,
}
#[napi]
impl HostProbe {
    #[napi(constructor)]
    pub fn new(mode: Utf16String) -> Result<Self> {
        Ok(Self {
            inner: probe::HostProbe::new(&string(&mode)?).map_err(error)?,
        })
    }
    #[napi]
    pub fn start(&mut self, now: f64, timeout: f64) -> Result<()> {
        self.inner
            .start(unsigned(now)?, unsigned(timeout)?)
            .map_err(error)
    }
    #[napi]
    pub fn poll(&mut self, now: f64, budget: f64) -> Result<String> {
        Ok(self.inner.poll(unsigned(now)?, unsigned(budget)?))
    }
    #[napi]
    pub fn reenter(&mut self, token: Utf16String, now: f64, timeout: f64) -> Result<()> {
        self.inner
            .reenter(&string(&token)?, unsigned(now)?, unsigned(timeout)?)
            .map_err(error)
    }
    #[napi]
    pub fn drain_cancelled_reads(&mut self) -> Vec<String> {
        self.inner.drain_cancelled_reads()
    }
    #[napi]
    pub fn respond_integer(&mut self, token: Utf16String, value: BigInt, now: f64) -> Result<()> {
        self.inner
            .respond(
                &string(&token)?,
                Value::Int(integer(value)?.into()),
                unsigned(now)?,
            )
            .map_err(error)
    }
    #[napi]
    pub fn respond_bytes(&mut self, token: Utf16String, value: Uint8Array, now: f64) -> Result<()> {
        self.inner
            .respond(
                &string(&token)?,
                Value::Bytes(value.to_vec().into()),
                unsigned(now)?,
            )
            .map_err(error)
    }
    #[napi]
    pub fn reject(&mut self, token: Utf16String, message: Utf16String, now: f64) -> Result<()> {
        self.inner
            .reject(&string(&token)?, &string(&message)?, unsigned(now)?)
            .map_err(error)
    }
    #[napi]
    pub fn cancel(&mut self) {
        self.inner.cancel();
    }
    #[napi]
    pub fn close(&mut self) {
        self.inner.close();
    }
}

/// Lossless logger transport; all textual fields contain UTF-16 code units.
#[napi(object, use_nullable = true)]
pub struct SourceLog {
    pub level: String,
    pub message: napi::bindgen_prelude::Uint16Array,
    pub module_uri: napi::bindgen_prelude::Uint16Array,
    pub member_name: Option<napi::bindgen_prelude::Uint16Array>,
    pub source_lines: Vec<napi::bindgen_prelude::Uint16Array>,
    pub start_line: u32,
    pub start_column: u32,
    pub end_line: u32,
    pub end_column: u32,
}
/// Full transformer input/output; text remains owned UTF-16, including surrogates.
#[napi(object, use_nullable = true)]
pub struct SourceFrame {
    pub module_uri: napi::bindgen_prelude::Uint16Array,
    pub member_name: Option<napi::bindgen_prelude::Uint16Array>,
    pub source_lines: Vec<napi::bindgen_prelude::Uint16Array>,
    pub start_line: f64,
    pub start_column: f64,
    pub end_line: f64,
    pub end_column: f64,
}
impl From<probe::SourceFrame> for SourceFrame {
    fn from(frame: probe::SourceFrame) -> Self {
        use napi::bindgen_prelude::Uint16Array;
        Self {
            module_uri: Uint16Array::new(frame.module_uri),
            member_name: frame.member_name.map(Uint16Array::new),
            source_lines: frame
                .source_lines
                .into_iter()
                .map(Uint16Array::new)
                .collect(),
            start_line: frame.start_line.into(),
            start_column: frame.start_column.into(),
            end_line: frame.end_line.into(),
            end_column: frame.end_column.into(),
        }
    }
}
impl TryFrom<SourceFrame> for probe::SourceFrame {
    type Error = Error;
    fn try_from(frame: SourceFrame) -> Result<Self> {
        Ok(Self {
            module_uri: frame.module_uri.to_vec(),
            member_name: frame.member_name.map(|s| s.to_vec()),
            source_lines: frame.source_lines.into_iter().map(|s| s.to_vec()).collect(),
            start_line: unsigned(frame.start_line)?,
            start_column: unsigned(frame.start_column)?,
            end_line: unsigned(frame.end_line)?,
            end_column: unsigned(frame.end_column)?,
        })
    }
}
/// Apply the existing shared frame policy without creating an evaluator session.
#[napi(js_name = "transformFrameForPolicy")]
pub fn transform_frame_for_policy(
    env: Env,
    frame: SourceFrame,
    policy: Utf16String,
) -> Result<SourceFrame> {
    use pkl_runtime::logging::FrameTransformer;
    let policy = match string(&policy)?.as_str() {
        "default" => FrameTransformer::Default,
        "identity" => FrameTransformer::Identity,
        _ => return Err(error("expected default or identity frame policy")),
    };
    let frame: probe::SourceFrame = frame.try_into()?;
    let transformed = policy.transform(frame.into());
    probe::SourceFrame::try_from(&transformed)
        .map(SourceFrame::from)
        .map_err(|failure| text_error(&env, failure.message))
}

#[napi(object)]
pub struct SourceModuleRequest<'env> {
    pub id: String,
    pub kind: String,
    pub importer_original_uri: Option<napi::JsString<'env>>,
    pub importer_resolved_uri: Option<napi::JsString<'env>>,
    pub import_uri: Option<napi::JsString<'env>>,
    pub original_uri: napi::JsString<'env>,
    pub resolved_uri: Option<napi::JsString<'env>>,
    pub source_uri: Option<napi::JsString<'env>>,
    pub key_id: Option<String>,
    pub key_kind: Option<String>,
    pub key_handle: Option<napi::JsString<'env>>,
    pub resolved_key_id: Option<String>,
    pub resolved_key_handle: Option<napi::JsString<'env>>,
    pub selection_phase: Option<String>,
    pub resolution_phase: Option<String>,
}
impl<'env> SourceModuleRequest<'env> {
    fn from_runtime(env: &'env Env, request: probe::SourceTextModuleRequest) -> Result<Self> {
        Ok(Self {
            id: request.id,
            kind: request.kind.into(),
            importer_original_uri: request
                .importer_original_uri
                .map(|s| js_text(env, &s))
                .transpose()?,
            importer_resolved_uri: request
                .importer_resolved_uri
                .map(|s| js_text(env, &s))
                .transpose()?,
            import_uri: request.import_uri.map(|s| js_text(env, &s)).transpose()?,
            original_uri: js_text(env, &request.original_uri)?,
            resolved_uri: request.resolved_uri.map(|s| js_text(env, &s)).transpose()?,
            source_uri: request.source_uri.map(|s| js_text(env, &s)).transpose()?,
            key_id: request.key_id,
            key_kind: request.key_kind.map(Into::into),
            key_handle: request.key_handle.map(|s| js_text(env, &s)).transpose()?,
            resolved_key_id: request.resolved_key_id,
            resolved_key_handle: request
                .resolved_key_handle
                .map(|s| js_text(env, &s))
                .transpose()?,
            selection_phase: request.selection_phase.map(Into::into),
            resolution_phase: request.resolution_phase.map(Into::into),
        })
    }
}
#[napi(object)]
pub struct SourcePathElement {
    pub name: napi::bindgen_prelude::Uint16Array,
    pub is_directory: bool,
}
fn glob_elements(elements: Vec<SourcePathElement>) -> Vec<pkl_runtime::glob::PathElement> {
    elements
        .into_iter()
        .map(|element| pkl_runtime::glob::PathElement {
            name: PklString::from_utf16(element.name.to_vec()),
            is_directory: element.is_directory,
        })
        .collect()
}
/// Codec-only control through the same decoder and event encoder as completions.
#[napi]
pub fn glob_transport_codec<'env>(
    env: &'env Env,
    elements: Vec<SourcePathElement>,
) -> Result<Vec<SourceEvent<'env>>> {
    probe::glob_transport_records(glob_elements(elements))
        .into_iter()
        .map(|event| SourceEvent::from_runtime(env, event))
        .collect()
}

#[napi(object)]
pub struct SourceGlobRequest<'env> {
    pub id: String,
    pub kind: String,
    pub uri: Option<napi::JsString<'env>>,
    pub reader_kind: String,
    pub reader_id: String,
    pub reader_uri: Option<napi::JsString<'env>>,
    pub reader_scheme: Option<napi::JsString<'env>>,
    pub reader_handle: Option<napi::JsString<'env>>,
    pub key_kind: Option<String>,
}
impl<'env> SourceGlobRequest<'env> {
    fn from_runtime(env: &'env Env, request: probe::SourceGlobRequest) -> Result<Self> {
        Ok(Self {
            id: request.id,
            kind: request.kind.into(),
            uri: request.uri.map(|s| js_text(env, &s)).transpose()?,
            reader_kind: request.reader_kind.into(),
            reader_id: request.reader_id,
            reader_uri: request.reader_uri.map(|s| js_text(env, &s)).transpose()?,
            reader_scheme: request
                .reader_scheme
                .map(|s| js_text(env, &s))
                .transpose()?,
            reader_handle: request
                .reader_handle
                .map(|s| js_text(env, &s))
                .transpose()?,
            key_kind: request.key_kind.map(Into::into),
        })
    }
}
#[napi(object)]
pub struct SourceEvent<'env> {
    pub kind: String,
    pub token: Option<String>,
    pub uri: Option<napi::JsString<'env>>,
    pub value: Option<napi::bindgen_prelude::Uint16Array>,
    pub bytes: Option<Uint8Array>,
    pub error: Option<napi::bindgen_prelude::Uint16Array>,
    pub error_bytes: Option<Uint8Array>,
    pub log: Option<SourceLog>,
    pub frame: Option<SourceFrame>,
    pub module: Option<SourceModuleRequest<'env>>,
    pub glob: Option<SourceGlobRequest<'env>>,
    pub exit_code: Option<i32>,
    pub phase: Option<String>,
    pub disposition: Option<String>,
    pub reason: Option<String>,
    pub callback_origin: Option<String>,
}
impl<'env> SourceEvent<'env> {
    fn from_runtime(env: &'env Env, event: probe::SourceTextEvent) -> Result<Self> {
        use napi::bindgen_prelude::Uint16Array;
        Ok(Self {
            kind: event.kind.into(),
            token: event.token,
            uri: event.uri.map(|s| js_text(env, &s)).transpose()?,
            value: event.value.map(Uint16Array::new),
            bytes: event.bytes.map(Uint8Array::new),
            error: event.error.map(Uint16Array::new),
            error_bytes: event.error_bytes.map(Uint8Array::new),
            module: event
                .module
                .map(|r| SourceModuleRequest::from_runtime(env, r))
                .transpose()?,
            glob: event
                .glob
                .map(|r| SourceGlobRequest::from_runtime(env, r))
                .transpose()?,
            frame: event.frame.map(Into::into),
            exit_code: event.exit_code,
            phase: event.phase.map(Into::into),
            disposition: event.disposition.map(Into::into),
            reason: event.reason.map(Into::into),
            callback_origin: event.callback_origin.map(Into::into),
            log: event.log.map(|log| SourceLog {
                level: log.level.into(),
                message: Uint16Array::new(log.message),
                module_uri: Uint16Array::new(log.module_uri),
                member_name: log.member_name.map(Uint16Array::new),
                source_lines: log.source_lines.into_iter().map(Uint16Array::new).collect(),
                start_line: log.start_line,
                start_column: log.start_column,
                end_line: log.end_line,
                end_column: log.end_column,
            }),
        })
    }
}

/// Development-only parsed-source session; JS callbacks execute after poll has
/// released its Rust borrow and explicitly acknowledge the pending log token.
#[napi]
pub struct SourceSession {
    inner: probe::SourceProbe,
}
#[napi]
impl SourceSession {
    /// Output API identity profile; the separate synchronous CLI-style export
    /// accepts original CLI arguments and reports complete byte channels.
    #[napi(factory)]
    #[allow(clippy::too_many_arguments)]
    pub fn for_output(
        env: Env,
        source: Utf16String,
        uri: Utf16String,
        module_name: Utf16String,
        paths: Vec<Utf16String>,
        arguments: Vec<Utf16String>,
        trace_mode: Option<Utf16String>,
        host_logger: Option<bool>,
        host_frame_transformer: Option<bool>,
        power_assertions: Option<bool>,
    ) -> Result<Self> {
        use pkl_runtime::evaluation::frontend::{
            DiagnosticProfile, LosslessModuleSourceInput, arguments::parse_module_eval_args,
        };
        let arguments = arguments.iter().map(string).collect::<Result<Vec<_>>>()?;
        let mut invocation = parse_module_eval_args(&arguments).map_err(error)?;
        invocation.options.diagnostic_profile = DiagnosticProfile::ApiIdentity;
        let paths = paths.iter().map(string).collect::<Result<Vec<_>>>()?;
        let mode = trace_mode
            .as_ref()
            .map(string)
            .transpose()?
            .unwrap_or_else(|| "compact".into());
        let options = probe::SourceProbe::options(
            &mode,
            host_logger.unwrap_or(false),
            host_frame_transformer.unwrap_or(false),
            power_assertions.unwrap_or(false),
        )
        .map_err(error)?;
        let source = source_text(&source);
        let uri = pkl_text(&uri);
        let name = pkl_text(&module_name);
        Ok(Self {
            inner: probe::SourceProbe::new_output_text(
                LosslessModuleSourceInput {
                    text: source,
                    uri,
                    inferred_name: name,
                },
                &paths,
                &invocation.options,
                options,
            )
            .map_err(|failure| text_error(&env, failure.text))?,
        })
    }
    #[napi(factory)]
    pub fn module_evaluator(
        env: Env,
        trace_mode: Option<Utf16String>,
        host_logger: Option<bool>,
        host_frame_transformer: Option<bool>,
        power_assertions: Option<bool>,
    ) -> Result<Self> {
        let mode = trace_mode
            .as_ref()
            .map(string)
            .transpose()?
            .unwrap_or_else(|| "compact".into());
        Ok(Self {
            inner: probe::SourceProbe::new_module_evaluator(
                &mode,
                host_logger.unwrap_or(false),
                host_frame_transformer.unwrap_or(false),
                power_assertions.unwrap_or(false),
            )
            .map_err(|text| text_error(&env, text))?,
        })
    }
    #[allow(clippy::too_many_arguments)]
    #[napi]
    pub fn evaluate_module_source(
        &mut self,
        env: Env,
        uri: Utf16String,
        contents: Option<Utf16String>,
        expression: Utf16String,
        now: f64,
        timeout: Option<f64>,
    ) -> Result<()> {
        let contents = contents.as_ref().map(source_text);
        self.inner
            .evaluate_module_source_text(
                pkl_text(&uri),
                contents,
                source_text(&expression),
                unsigned(now)?,
                timeout.map(unsigned).transpose()?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi(factory)]
    #[allow(clippy::too_many_arguments)]
    pub fn for_expressions(
        env: Env,
        source: Utf16String,
        uri: Utf16String,
        module_name: Utf16String,
        paths: Vec<Utf16String>,
        trace_mode: Option<Utf16String>,
        host_logger: Option<bool>,
        host_frame_transformer: Option<bool>,
        power_assertions: Option<bool>,
    ) -> Result<Self> {
        let paths = paths.iter().map(source_text).collect::<Vec<_>>();
        let mode = trace_mode
            .as_ref()
            .map(string)
            .transpose()?
            .unwrap_or_else(|| "compact".into());
        Ok(Self {
            inner: probe::SourceProbe::new_expressions_source(
                source_text(&source),
                pkl_text(&uri),
                pkl_text(&module_name),
                &paths,
                &mode,
                host_logger.unwrap_or(false),
                host_frame_transformer.unwrap_or(false),
                power_assertions.unwrap_or(false),
            )
            .map_err(|text| text_error(&env, text))?,
        })
    }
    #[napi(constructor)]
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        env: Env,
        source: Utf16String,
        uri: Utf16String,
        module_name: Utf16String,
        paths: Vec<Utf16String>,
        trace_mode: Option<Utf16String>,
        host_logger: Option<bool>,
        host_frame_transformer: Option<bool>,
        power_assertions: Option<bool>,
    ) -> Result<Self> {
        let paths = paths.iter().map(string).collect::<Result<Vec<_>>>()?;
        let mode = trace_mode
            .as_ref()
            .map(string)
            .transpose()?
            .unwrap_or_else(|| "compact".into());
        Ok(Self {
            inner: probe::SourceProbe::new_text(
                source_text(&source),
                pkl_text(&uri),
                pkl_text(&module_name),
                &paths,
                &mode,
                host_logger.unwrap_or(false),
                host_frame_transformer.unwrap_or(false),
                power_assertions.unwrap_or(false),
            )
            .map_err(|text| text_error(&env, text))?,
        })
    }
    #[napi]
    pub fn set_glob_test_mode(&mut self, env: Env, enabled: bool) -> Result<()> {
        self.inner
            .set_glob_test_mode(enabled)
            .map_err(|e| text_error(&env, e.message))
    }
    #[napi]
    pub fn complete_glob_reader(
        &mut self,
        env: Env,
        token: Utf16String,
        reader_id: Utf16String,
        scheme: Utf16String,
        handle: Utf16String,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_glob_reader(
                &string(&token)?,
                &string(&reader_id)?,
                pkl_text(&scheme),
                pkl_text(&handle),
                unsigned(now)?,
            )
            .map_err(|e| text_error(&env, e.message))
    }
    #[napi]
    pub fn complete_glob_boolean(
        &mut self,
        env: Env,
        token: Utf16String,
        kind: Utf16String,
        value: bool,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_glob_boolean(&string(&token)?, &string(&kind)?, value, unsigned(now)?)
            .map_err(|e| text_error(&env, e.message))
    }
    #[napi]
    pub fn complete_glob_elements(
        &mut self,
        env: Env,
        token: Utf16String,
        elements: Vec<SourcePathElement>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_glob_elements(&string(&token)?, glob_elements(elements), unsigned(now)?)
            .map_err(|e| text_error(&env, e.message))
    }
    #[napi]
    pub fn reject_glob(
        &mut self,
        env: Env,
        token: Utf16String,
        kind: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_glob(
                &string(&token)?,
                &string(&kind)?,
                message.as_ref().map(pkl_text),
                unsigned(now)?,
            )
            .map_err(|e| text_error(&env, e.message))
    }
    #[napi]
    pub fn complete_default_glob(
        &mut self,
        env: Env,
        token: Utf16String,
        now: f64,
    ) -> Result<bool> {
        self.inner
            .complete_default_glob(&string(&token)?, unsigned(now)?)
            .map_err(|e| text_error(&env, e.message))
    }
    #[napi]
    pub fn drain_cancelled_globs(&mut self) -> Vec<String> {
        self.inner.drain_cancelled_globs()
    }
    #[napi]
    pub fn resolve_glob_host_uri<'env>(
        &self,
        env: &'env Env,
        base: Utf16String,
        relative: Utf16String,
        fragment_paths: bool,
    ) -> Result<napi::JsString<'env>> {
        let uri = probe::SourceProbe::resolve_glob_host_uri(
            &pkl_text(&base),
            &pkl_text(&relative),
            fragment_paths,
        )
        .map_err(|e| text_error(env, e.message))?;
        js_text(env, &uri)
    }
    #[napi]
    pub fn normalize_glob_host_uri<'env>(
        &self,
        env: &'env Env,
        uri: Utf16String,
    ) -> Result<napi::JsString<'env>> {
        let uri = probe::SourceProbe::normalize_glob_host_uri(&pkl_text(&uri))
            .map_err(|e| text_error(env, e.message))?;
        js_text(env, &uri)
    }
    #[napi]
    pub fn reject_import_uri(
        &mut self,
        env: Env,
        token: Utf16String,
        key_id: Utf16String,
        kind: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_import_uri(
                &string(&token)?,
                &string(&key_id)?,
                &string(&kind)?,
                message.as_ref().map(pkl_text),
                unsigned(now)?,
            )
            .map_err(|e| text_error(&env, e.message))
    }
    #[napi]
    pub fn start_module(&mut self, env: Env, now: f64, timeout: Option<f64>) -> Result<()> {
        self.inner
            .start_module(unsigned(now)?, timeout.map(unsigned).transpose()?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn start_output_bytes(&mut self, env: Env, now: f64, timeout: Option<f64>) -> Result<()> {
        self.inner
            .start_output_bytes(unsigned(now)?, timeout.map(unsigned).transpose()?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn reenter_output_bytes(
        &mut self,
        env: Env,
        token: Utf16String,
        now: f64,
        timeout: Option<f64>,
    ) -> Result<()> {
        self.inner
            .reenter_output_bytes(
                &string(&token)?,
                unsigned(now)?,
                timeout.map(unsigned).transpose()?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_module_import_check(
        &mut self,
        env: Env,
        token: Utf16String,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_import_check(&string(&token)?, unsigned(now)?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn reject_module_import_check(
        &mut self,
        env: Env,
        token: Utf16String,
        kind: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_module_import_check(
                &string(&token)?,
                &string(&kind)?,
                message.map(|message| PklString::from_utf16(message.to_vec())),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_default_module(
        &mut self,
        env: Env,
        token: Utf16String,
        now: f64,
    ) -> Result<bool> {
        self.inner
            .complete_default_module(&string(&token)?, unsigned(now)?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[allow(clippy::too_many_arguments)]
    #[napi]
    pub fn complete_module_key(
        &mut self,
        env: Env,
        token: Utf16String,
        key_id: Utf16String,
        uri: Utf16String,
        kind: Utf16String,
        handle: Utf16String,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_key(
                &string(&token)?,
                &string(&key_id)?,
                pkl_text(&uri),
                &string(&kind)?,
                pkl_text(&handle),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[allow(clippy::too_many_arguments)]
    #[napi]
    pub fn complete_module_cache_policy(
        &mut self,
        env: Env,
        token: Utf16String,
        key_id: Utf16String,
        cached: bool,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_cache_policy(
                &string(&token)?,
                &string(&key_id)?,
                cached,
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_import_uri(
        &mut self,
        env: Env,
        token: Utf16String,
        key_id: Utf16String,
        uri: Utf16String,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_import_uri(
                &string(&token)?,
                &string(&key_id)?,
                pkl_text(&uri),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[allow(clippy::too_many_arguments)]
    #[napi]
    pub fn reenter_module_source(
        &mut self,
        env: Env,
        token: Utf16String,
        uri: Utf16String,
        contents: Option<Utf16String>,
        expression: Utf16String,
        now: f64,
        timeout: Option<f64>,
    ) -> Result<()> {
        let contents = contents.as_ref().map(source_text);
        self.inner
            .reenter_module_source_text(
                &string(&token)?,
                pkl_text(&uri),
                contents,
                source_text(&expression),
                unsigned(now)?,
                timeout.map(unsigned).transpose()?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[allow(clippy::too_many_arguments)]
    #[napi]
    pub fn complete_module_fragment_paths(
        &mut self,
        env: Env,
        token: Utf16String,
        key_id: Utf16String,
        fragment_paths: bool,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_fragment_paths(
                &string(&token)?,
                &string(&key_id)?,
                fragment_paths,
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[allow(clippy::too_many_arguments)]
    #[napi]
    pub fn complete_module_resolved_key(
        &mut self,
        env: Env,
        token: Utf16String,
        key_id: Utf16String,
        resolved_key_id: Utf16String,
        handle: Utf16String,
        original_uri: Utf16String,
        resolved_uri: Utf16String,
        source_uri: Utf16String,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_resolved_key(
                &string(&token)?,
                &string(&key_id)?,
                &string(&resolved_key_id)?,
                pkl_text(&handle),
                pkl_text(&original_uri),
                pkl_text(&resolved_uri),
                pkl_text(&source_uri),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[allow(clippy::too_many_arguments)]
    #[napi]
    pub fn reject_module_key(
        &mut self,
        env: Env,
        token: Utf16String,
        cache_policy: bool,
        kind: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_module_key(
                &string(&token)?,
                cache_policy,
                &string(&kind)?,
                message.map(|value| PklString::from_utf16(value.to_vec())),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_module_capabilities(
        &mut self,
        env: Env,
        token: Utf16String,
        local: bool,
        hierarchical: bool,
        fragment_paths: bool,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_capabilities(
                &string(&token)?,
                local,
                hierarchical,
                fragment_paths,
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_module_has_element(
        &mut self,
        env: Env,
        token: Utf16String,
        exists: bool,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_has_element(&string(&token)?, exists, unsigned(now)?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_module_resolution(
        &mut self,
        env: Env,
        token: Utf16String,
        original_uri: Utf16String,
        resolved_uri: Utf16String,
        source_uri: Utf16String,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_resolution(
                &string(&token)?,
                pkl_text(&original_uri),
                pkl_text(&resolved_uri),
                pkl_text(&source_uri),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_module_source(
        &mut self,
        env: Env,
        token: Utf16String,
        text: Utf16String,
        inferred_name: Utf16String,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_module_source(
                &string(&token)?,
                source_text(&text),
                pkl_text(&inferred_name),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn reject_module_resolution(
        &mut self,
        env: Env,
        token: Utf16String,
        kind: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_module_text(
                &string(&token)?,
                false,
                &string(&kind)?,
                message.map(|message| PklString::from_utf16(message.to_vec())),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn reject_module_source(
        &mut self,
        env: Env,
        token: Utf16String,
        kind: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_module_text(
                &string(&token)?,
                true,
                &string(&kind)?,
                message.map(|message| PklString::from_utf16(message.to_vec())),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn reject_module_preparation(
        &mut self,
        env: Env,
        token: Utf16String,
        has_element: bool,
        kind: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_module_preparation_text(
                &string(&token)?,
                has_element,
                &string(&kind)?,
                message.map(|message| PklString::from_utf16(message.to_vec())),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn resolved_read_uri<'env>(
        &self,
        env: &'env Env,
        token: Utf16String,
    ) -> Result<napi::JsString<'env>> {
        let uri = self
            .inner
            .resolved_read_uri_text(&string(&token)?)
            .map_err(|failure| text_error(env, failure.message))?;
        js_text(env, &uri)
    }
    #[napi]
    pub fn complete_read_missing(&mut self, env: Env, token: Utf16String, now: f64) -> Result<()> {
        self.inner
            .complete_read_missing(&string(&token)?, unsigned(now)?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_read_text(
        &mut self,
        env: Env,
        token: Utf16String,
        units: napi::bindgen_prelude::Uint16Array,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_read_text(
                &string(&token)?,
                PklString::from_utf16(units.to_vec()),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_read_resource(
        &mut self,
        env: Env,
        token: Utf16String,
        uri: Utf16String,
        bytes: Uint8Array,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_read_resource(
                &string(&token)?,
                PklString::from_utf16(uri.to_vec()),
                bytes.to_vec(),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn reject_read_security_manager(
        &mut self,
        env: Env,
        token: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_read_security_manager(
                &string(&token)?,
                message.map(|message| PklString::from_utf16(message.to_vec())),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn respond_configured(&mut self, env: Env, token: Utf16String, now: f64) -> Result<()> {
        self.inner
            .respond_configured(&string(&token)?, unsigned(now)?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn start_path(
        &mut self,
        env: Env,
        index: f64,
        now: f64,
        timeout: Option<f64>,
    ) -> Result<()> {
        self.inner
            .start_path(
                unsigned(index)?,
                unsigned(now)?,
                timeout.map(unsigned).transpose()?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn setup_failed(&self) -> bool {
        self.inner.setup_failed()
    }
    #[napi]
    pub fn reenter_path(
        &mut self,
        env: Env,
        token: Utf16String,
        index: f64,
        now: f64,
        timeout: Option<f64>,
    ) -> Result<()> {
        self.inner
            .reenter_path(
                &string(&token)?,
                unsigned(index)?,
                unsigned(now)?,
                timeout.map(unsigned).transpose()?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn poll<'env>(
        &mut self,
        env: &'env Env,
        now: f64,
        budget: f64,
    ) -> Result<SourceEvent<'env>> {
        let event = self
            .inner
            .poll_text(unsigned(now)?, unsigned(budget)?)
            .map_err(|failure| text_error(env, failure.message))?;
        SourceEvent::from_runtime(env, event)
    }
    #[napi]
    pub fn set_frame_transformer(&mut self, env: Env, mode: Utf16String) -> Result<()> {
        self.inner
            .set_frame_transformer(&string(&mode)?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn complete_frame_transform(
        &mut self,
        env: Env,
        token: Utf16String,
        frame: Option<SourceFrame>,
        failure: Option<napi::bindgen_prelude::Uint16Array>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .complete_frame_transform(
                &string(&token)?,
                frame.map(TryInto::try_into).transpose()?,
                failure.map(|units| units.to_vec()),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn acknowledge_log(
        &mut self,
        env: Env,
        token: Utf16String,
        failure: Option<napi::bindgen_prelude::Uint16Array>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .acknowledge_log(
                &string(&token)?,
                failure.map(|units| units.to_vec()),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn respond_string(
        &mut self,
        env: Env,
        token: Utf16String,
        value: napi::bindgen_prelude::Uint16Array,
        now: f64,
    ) -> Result<()> {
        self.inner
            .respond(
                &string(&token)?,
                Value::String(pkl_runtime::value::PklString::from_utf16(value.to_vec())),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn respond_integer(
        &mut self,
        env: Env,
        token: Utf16String,
        value: BigInt,
        now: f64,
    ) -> Result<()> {
        self.inner
            .respond(
                &string(&token)?,
                Value::Int(integer(value)?.into()),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn respond_bytes(
        &mut self,
        env: Env,
        token: Utf16String,
        value: Uint8Array,
        now: f64,
    ) -> Result<()> {
        self.inner
            .respond(
                &string(&token)?,
                Value::Bytes(value.to_vec().into()),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn reject(
        &mut self,
        env: Env,
        token: Utf16String,
        message: Utf16String,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_text(
                &string(&token)?,
                PklString::from_utf16(message.to_vec()),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn reject_read_io(
        &mut self,
        env: Env,
        token: Utf16String,
        message: Option<Utf16String>,
        now: f64,
    ) -> Result<()> {
        self.inner
            .reject_read_io(
                &string(&token)?,
                message.map(|message| PklString::from_utf16(message.to_vec())),
                unsigned(now)?,
            )
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn close_from_callback(&mut self, env: Env, token: Utf16String) -> Result<()> {
        self.inner
            .close_from_callback(&string(&token)?)
            .map_err(|failure| text_error(&env, failure.message))
    }
    #[napi]
    pub fn drain_cancelled_modules(&mut self) -> Vec<String> {
        self.inner.drain_cancelled_modules()
    }
    #[napi]
    pub fn drain_cancelled_reads(&mut self) -> Vec<String> {
        self.inner.drain_cancelled_reads()
    }
    #[napi]
    pub fn collect(&mut self) -> Result<u32> {
        u32::try_from(self.inner.collect().slots).map_err(error)
    }
    #[napi]
    pub fn heap_slots(&self) -> Result<u32> {
        u32::try_from(self.inner.heap_slots()).map_err(error)
    }
    #[napi]
    pub fn context_depth(&self) -> u32 {
        self.inner.context_depth() as u32
    }
    #[napi]
    pub fn cancel(&mut self) {
        self.inner.cancel();
    }
    #[napi]
    pub fn close(&mut self) {
        self.inner.close();
    }
}
