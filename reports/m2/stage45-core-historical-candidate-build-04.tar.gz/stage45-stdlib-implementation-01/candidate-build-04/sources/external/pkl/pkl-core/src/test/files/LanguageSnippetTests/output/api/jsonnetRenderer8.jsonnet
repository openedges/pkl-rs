{
  FOO: 'a',
  bar: 'b', // bar,
  baz: {
    qux: 'c', // qux,
    quux: 'c',
  },
}
