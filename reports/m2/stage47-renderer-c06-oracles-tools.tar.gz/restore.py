"""Restore captured regular files from checked content objects and explicit external references."""
from pathlib import Path
import argparse, hashlib, json, os, stat, tarfile
sha=lambda b:hashlib.sha256(b).hexdigest()
def safe(text):
 p=Path(text)
 if p.is_absolute() or '..' in p.parts or str(p)!=text:raise ValueError('unsafe restored path')
 return p
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def restore(index, object_roots, output, git_fixture, external_map):
 if output.exists():raise ValueError('fresh restored output required')
 output.mkdir()
 objects=index['objects'];external=index['canonicalReferences'];git=index['gitFixture'];cache={}
 def value(storage):
  kind=storage['kind'];key=storage['sha256']
  if key in cache:return cache[key]
  if kind=='object':
   item=objects[key];data=(object_roots/item['group']/safe(item['path'])).read_bytes()
  elif kind=='git':
   item=git['files'][storage['relative']];data=(git_fixture/safe(storage['relative'])).read_bytes()
   if blob(data)!=item['gitBlobSha1']:raise ValueError('Git blob content identity differs')
  elif kind=='canonical':data=Path(external_map[key]).read_bytes()
  else:raise ValueError('unknown storage kind')
  if sha(data)!=key:raise ValueError('restored object hash differs')
  cache[key]=data
  return data
 def put(label,relative,row,storage):
  label=safe(label);relative=safe(relative)
  if len(label.parts)!=1:raise ValueError('unsafe root label')
  data=value(storage)
  if len(data)!=row['bytes']:raise ValueError('restored byte count differs')
  path=output/'roots'/label/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);path.chmod(row['mode'])
 for row in index['records']:put(row['rootLabel'],row['relative'],row,row['storage'])
 for relative,row in git['files'].items():put(git['rootLabel'],relative,row,{'kind':'git','sha256':row['sha256'],'relative':relative})
 return {'capturedFiles':len(index['records']),'gitFixtureFiles':len(git['files']),'contentObjectsRead':len(cache)}
def main():
 p=argparse.ArgumentParser();p.add_argument('--index',type=Path,required=True);p.add_argument('--objects',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--git-fixture',type=Path,required=True);p.add_argument('--external-map',type=Path,required=True);a=p.parse_args()
 print(json.dumps(restore(json.loads(a.index.read_bytes()),a.objects,a.output,a.git_fixture,json.loads(a.external_map.read_bytes())),indent=2))
if __name__=='__main__':main()
