"""Offline raw-result verification: no evaluator, Java, Node, browser, network or Git execution."""
from pathlib import Path
import argparse, collections, importlib.util, json

def units(values):return b''.join(v.to_bytes(2,'big')for v in values)
def java_utf8(values):return units(values).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
def verify(base):
 root=base/'roots';tools=root/'stage47-renderer-c06-native-proposal-01';native=root/'stage47-renderer-native-c06-01';portable=root/'stage47-renderer-supplementary-portable-c06-01';cohorts=json.loads((tools/'cohorts.json').read_bytes())['cohorts'];counts=collections.Counter();sessions=0
 for spec in cohorts:
  golden=root/Path(spec['fixtures']).name;module_spec=importlib.util.spec_from_file_location('offline_'+spec['name'],tools/spec['verifier']);tool=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(tool);v=tool.verify(golden)
  if v['manifestSha256']!=spec['manifestSha256']:raise ValueError('offline pinned fixture differs')
  fixtures=json.loads((golden/'fixtures.json').read_bytes())['fixtures']
  for fixture in fixtures:
   group,case=fixture['id'].split('/');directory=native/spec['name']/'cases'/group/case/str(fixture['repeat'])/'calls'/f"session-{fixture['session']}"
   if (directory/'terminal-slots.bin').read_bytes()!=b'0':raise ValueError('native slots')
   for index,expected in enumerate(fixture['expected']):
    fields={'status.bin':(expected['status']+'\n').encode(),'stdout.bin':bytes.fromhex(expected['stdoutHex']),'stderr.bin':bytes.fromhex(expected['stderrHex']),'stdout.code-units.bin':units(expected['stdoutUnits']),'stderr.code-units.bin':units(expected['stderrUnits']),'reads-before.bin':str(expected['readsBefore']).encode(),'reads-after.bin':str(expected['readsAfter']).encode()}
    for suffix,data in fields.items():
     if (directory/f'outer-{index}.{suffix}').read_bytes()!=data:raise ValueError('offline native raw mismatch')
    counts['native']+=1
   if (directory/'reads.bin').read_bytes()!=str(len(fixture['readerPlan'])).encode():raise ValueError('offline final reader count')
   attempts=collections.Counter()
   for ri,entry in enumerate(fixture['readerPlan']):
    result=entry['result'];attempts[entry['uri']]+=1;fields={'uri.bin':entry['uri'].encode(),'kind.bin':result['kind'].encode(),'attempt.bin':str(attempts[entry['uri']]).encode()}
    if result['kind']=='text':fields.update({'value.code-units.bin':units(result['units']),'value.bin':java_utf8(result['units'])})
    elif result['kind']=='io':fields['message.bin']=result['message'].encode()
    elif result['kind']=='resource':fields.update({'resource-uri.bin':result['resourceUri'].encode(),'bytes.bin':bytes(result['bytes'])})
    for suffix,data in fields.items():
     if (directory/f'read-{ri}.{suffix}').read_bytes()!=data:raise ValueError('offline native complete reader plan')
  if spec['name']=='original860':continue
  name={'supplement424':'supplementary424','oracle10_436':'java10_436','oracle11_120':'java11_120'}[spec['name']]
  for target in ['node','browser']:
   rows=json.loads((portable/name/(target+'.raw.json')).read_bytes())
   if len(rows)!=len(fixtures):raise ValueError('offline portable session count')
   for fi,(fixture,actual)in enumerate(zip(fixtures,rows)):
    if [actual[k]for k in ['id','repeat','session']]!=[fixture[k]for k in ['id','repeat','session']]:raise ValueError('offline portable identity/order')
    if actual['readerUris']!=[e['uri']for e in fixture['readerPlan']]:raise ValueError('offline reader URI order')
    if actual['constructorError']is not None or actual['acquisitionError']is not None or actual['architecture']['terminalSlots']!=0 or not actual['architecture']['ownedResultsStable']or not actual['architecture']['consumedReaderPlan']:raise ValueError('offline portable architecture')
    if len(actual['calls'])!=len(fixture['expected']):raise ValueError('offline portable API count')
    for i,(call,expected)in enumerate(zip(actual['calls'],fixture['expected'])):
     if call['index']!=i or call['expression']!=fixture['expressions'][i]:raise ValueError('offline call index/expression')
     for field in ['status','stdoutUnits','stderrUnits','readsBefore','readsAfter']:
      if call[field]!=expected[field]:raise ValueError('offline portable raw field')
     for channel in ['stdout','stderr']:
      if java_utf8(call[channel+'Units']).hex()!=expected[channel+'Hex']:raise ValueError('offline Java UTF8')
      d=portable/name/target/str(fi)
      if (d/f'{i}.{channel}.utf16be.bin').read_bytes()!=units(call[channel+'Units'])or(d/f'{i}.{channel}.java-utf8.bin').read_bytes()!=bytes.fromhex(expected[channel+'Hex']):raise ValueError('offline portable saved binary')
     counts[target]+=1
    sessions+=1
 if dict(counts)!={'native':1840,'node':980,'browser':980}:raise ValueError('offline complete raw accounting')
 return {'counts':dict(counts),'portableSessions':sessions,'evaluations':0,'rawMismatchCount':0,'scope':'Default configurations only; wrongmethod16,sharedbacking,GC,instrumentation,policy84/close28 and broadergates remain as captured.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--restored',type=Path,required=True);a=p.parse_args();print(json.dumps(verify(a.restored),indent=2))
