from pathlib import Path
import collections,datetime,hashlib,json,os,shutil,stat,subprocess,sys,tarfile,time
O=Path(__file__).parent.resolve();B=O.parent;M=Path('/Users/cody.ij.hwang/Projects/pkl-rs');CLEAN=O/'clean-source';ARCH=O/'archives'
sha=lambda data:hashlib.sha256(data).hexdigest()
file_sha=lambda p:sha(p.read_bytes())
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
records=[];roots=[];objects={};canonical={};git_files={};git_hashes={};commands=[];before={}
def regular(path):
 if not stat.S_ISREG(path.lstat().st_mode):raise ValueError('nonregular selected file: '+str(path))
 return path.read_bytes()
def safe(text):
 p=Path(text)
 if p.is_absolute()or'..'in p.parts or str(p)!=text:raise ValueError('unsafe source path')
 return p
for group in ['native','portable','oracles-tools']:(CLEAN/group/'objects').mkdir(parents=True,exist_ok=False)
ARCH.mkdir()
# Explicit pruning precedes any source traversal. Source selection uses exact inventories/manifests only.
write(O/'prewalk-exclusions.json',{'declaredBeforeTraversal':True,'exactNeverWalkedCachePaths':[str(B.parent/'stage47-cargo')],'exactExcludedTemporaryPaths':[str(B/'stage47-renderer-identity-regression-export-01/test-clone'),str(B/'stage47-renderer-supplementary-portable-proposal-02/test-clones')],'exactGeneratedOutputPaths':[str(CLEAN),str(O/'restored')],'selectionMethod':'Read sealed inventories and golden manifests directly; no original source/build/cache directory walking. evidence.py walks only freshly generated clean content objects.','genericNameExclusions':[]})
# Original860 fixture dependency: explicit commit/path/blob/SHA references, no Git command by this publisher.
G=B/'stage47-renderer-portable-fixtures-02';GP=M/'tests/fixtures/m2-renderer-portable';gm=json.loads(regular(G/'manifest.json'))
assert file_sha(G/'manifest.json')=='90f6694ff7637cfbe86e0a1a99f1a2351baba9537018022ffa8e3ff17c52cd77'
for rel in sorted(set(gm['files'])|{'manifest.json'}):
 data=regular(G/safe(rel));assert regular(GP/rel)==data
 digest=sha(data);row={'sha256':digest,'bytes':len(data),'mode':stat.S_IMODE((G/rel).stat().st_mode),'gitBlobSha1':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'repositoryPath':'tests/fixtures/m2-renderer-portable/'+rel}
 git_files[rel]=row;git_hashes.setdefault((digest,len(data)),rel);before[str(G/rel)]={'sha256':digest,'bytes':len(data),'mode':row['mode']};before[str(GP/rel)]={'sha256':digest,'bytes':len(data),'mode':stat.S_IMODE((GP/rel).stat().st_mode)}
git_fixture={'rootLabel':G.name,'commit':'674d3cabdd0e9c421a2cb9b820a22f2456755629','manifestSha256':file_sha(G/'manifest.json'),'files':git_files,'authority':'Root-provided committed fixture checkpoint; B confirms exact current original/installed bytes and computes Git blob IDs without invoking Git. Root staged-source binding/capture report is published separately.','localFixtureRoot':str(GP)}
# Canonical native/core and primary platform captures are owned by A/C; do not duplicate them.
release_root=B/'stage47-implementation-01/renderer-candidate-build-06';release=json.loads(regular(release_root/'release.json'));platform=json.loads(regular(B/'stage47-renderer-supplementary-portable-proposal-02/platform-pins.json'));platform_root=Path(platform['root'])
canonical_paths=[('A-core',release_root/'release.json','59543feca57c4994116708f9950fdabec97c3d7f3cbc261feafc2d8f074899c9')]
for key,digest in [('source_map','source_map_sha256'),('source_modes','source_modes_sha256'),('build_report','build_report_sha256'),('environment','environment_sha256')]:canonical_paths.append(('A-core',Path(release[key]),release[digest]))
for item in release['artifacts'].values():canonical_paths.append(('A-core',Path(item['path']),item['sha256']))
for rel,digest in platform['files'].items():canonical_paths.append(('C-primary-platform',platform_root/rel,digest))
for owner,path,digest in canonical_paths:
 assert file_sha(path)==digest
 row={'owner':owner,'canonicalPath':str(path),'sha256':digest,'bytes':path.stat().st_size,'mode':stat.S_IMODE(path.stat().st_mode),'scope':'Externally packaged canonical capture/artifact. Exact hash+length required; no B artifact/source-snapshot copy.'}
 canonical.setdefault(digest,row)
 before[str(path)]={'sha256':digest,'bytes':row['bytes'],'mode':row['mode']}

def add(root,rel,group,expected=None):
 rel=str(safe(rel));p=root/rel;data=regular(p);digest=sha(data);mode=stat.S_IMODE(p.stat().st_mode)
 if expected and (digest!=expected['sha256']or len(data)!=expected['bytes']):raise ValueError('producer indexed payload differs: '+str(p))
 key=(digest,len(data))
 if digest in canonical and len(data)==canonical[digest]['bytes']:
  if regular(Path(canonical[digest]['canonicalPath']))!=data:raise ValueError('canonical collision')
  storage={'kind':'canonical','sha256':digest}
 elif key in git_hashes:
  relative=git_hashes[key]
  if regular(GP/relative)!=data:raise ValueError('Git byte equality differs')
  storage={'kind':'git','sha256':digest,'relative':relative}
 else:
  if digest not in objects:
   target=CLEAN/group/'objects'/digest;target.write_bytes(data);objects[digest]={'group':group,'path':'objects/'+digest,'sha256':digest,'bytes':len(data),'firstOriginal':str(p)}
  else:
   item=objects[digest]
   if regular(CLEAN/item['group']/item['path'])!=data:raise ValueError('content collision')
  storage={'kind':'object','sha256':digest}
 row={'rootLabel':root.name,'relative':rel,'originalPath':str(p),'group':group,'kind':'regular','sha256':digest,'bytes':len(data),'mode':mode,'storage':storage}
 records.append(row);before[str(p)]={'sha256':digest,'bytes':len(data),'mode':mode}

def sealed(root,group,selected=None):
 inventory=json.loads(regular(root/'inventory.json'));closure=json.loads(regular(root/'closure.json'))
 assert closure['closed']and closure['allPayloadHashesVerified']and closure['liveHandles']==[]and file_sha(root/'inventory.json')==closure['inventorySha256']
 rows={r['path']:r for r in inventory['files']};assert len(rows)==closure['files']
 paths=set(rows)|{'inventory.json','closure.json'}
 if selected is not None:paths=set(selected)&paths
 for rel in sorted(paths):add(root,rel,group,rows.get(rel))
 roots.append({'root':str(root),'label':root.name,'group':group,'kind':'sealed-complete'if selected is None else'sealed-selected-history','closureSha256':file_sha(root/'closure.json'),'inventorySha256':file_sha(root/'inventory.json'),'producerPayloadFiles':len(rows),'selectedFiles':len(paths),'rawOriginalRetained':True})

def golden(root,pin):
 assert file_sha(root/'manifest.json')==pin
 m=json.loads(regular(root/'manifest.json'))
 for rel in sorted(set(m['files'])|{'manifest.json'}):add(root,rel,'oracles-tools',m['files'].get(rel))
 roots.append({'root':str(root),'label':root.name,'group':'oracles-tools','kind':'exact-golden-manifest-no-producer-closure','manifestSha256':pin,'selectedFiles':len(m['files'])+1,'rawOriginalRetained':True})
for name in ['stage47-renderer-native-c06-01','stage47-renderer-native-c06-control-01','stage47-renderer-native-c06-audit-01']:sealed(B/name,'native')
for name in ['stage47-renderer-supplementary-portable-c06-01','stage47-renderer-supplementary-portable-c06-control-01','stage47-renderer-supplementary-portable-c06-audit-01']:sealed(B/name,'portable')
for name in ['stage47-renderer-c06-native-proposal-01','stage47-renderer-supplementary-portable-proposal-02','stage47-renderer-supplementary-portable-preflight-03','stage47-renderer-identity-regression-export-01']:sealed(B/name,'oracles-tools')
for name,pin in [('stage47-renderer-supplementary-fixtures-01','7fb9e2e94d48dd753b099b8d2264c896e4286040273765d1465997ee8e1b782f'),('stage47-renderer-oracle10-fixtures-01','7b236def8416e42abdc76bddf6f17d236b17f6df5a9eeb3c517f304ae285eb91'),('stage47-renderer-oracle11-fixtures-01','8d20029f47feedc6df4105c80d2e7a261a02399330e6b3f55a566868cb048c5f'),('stage47-renderer-identity-regression-fixtures-02','d7027df9ed28462aa04f32b8c97d453d602e8142ab22f75d2e907629f0b1dc5f')]:golden(B/name,pin)
# Preserve failed compact metadata export and historical native mismatches without repackaging entire old captures.
for rel in ['manifest.json','fixtures.json']:add(B/'stage47-renderer-identity-regression-fixtures-01',rel,'oracles-tools')
history=[]
for name in ['stage47-renderer-native-c03-01','stage47-renderer-supplementary-native-c04-01','stage47-renderer-c04-audit-01','stage47-renderer-c05-audit-01','stage47-renderer-oracle11-c05-audit-01','stage47-renderer-supplementary-portable-c05-audit-01']:
 root=B/name;inv=json.loads(regular(root/'inventory.json'));available={r['path']for r in inv['files']}|{'inventory.json','closure.json'};chosen={p for p in available if'/'not in p and (p.endswith('.json')or p.endswith('.bin'))}
 data=json.loads(regular(root/'report.json'))
 for observation in data.get('observations',[]):
  if observation['outcome']!='pass':chosen.update(p for p in available if p.startswith(observation['rawPrefix']+'.'))
 sealed(root,'oracles-tools',chosen);history.append({'root':str(root),'reportSha256':file_sha(root/'report.json'),'inventorySha256':file_sha(root/'inventory.json'),'closureSha256':file_sha(root/'closure.json'),'selectedFiles':len(chosen),'completeOldRawArchived':False,'scope':'Oldrawcaptures preservedat originalroot andanchoredinventory; selectedmetadata plusall72C03and4C04mismatchingprefix rawfiles archived. C05 remains intermediate, not relabelled C06.'})
# Already-published failed acquisition/tools and installed fixture evidence are exact Git/archive references.
prior=[]
for relative,digest in [('reports/m2/renderer-tooling-originals.tar.gz','4b2f00a3d51cd14d19adc8f20393bc1200ff1660cbecfd1c5f52695e467c4721'),('reports/m2/renderer-portable-fixture-captures.tar.gz','01c8989733378cacf526dec4e268991b24dab31aea75dd3ff6464a6abc940b92')]:
 assert file_sha(M/relative)==digest
 prior.append({'commit':git_fixture['commit'],'repositoryPath':relative,'sha256':digest,'bytes':(M/relative).stat().st_size,'scope':'Already published initialjavac/toolfailures,sourceversions,actualchecks andstagedfixturebinding; referencednotduplicated.'})
index={'schema':1,'scope':'CurrentC06native1840+suppportable980 and pinnedtools/goldens/provenance. Actualsource records preserved bypath/hash/mode; content objects deduplicate byte-equal payloads.','records':records,'roots':roots,'objects':objects,'canonicalReferences':canonical,'gitFixture':git_fixture,'historicalReferences':history,'priorPublishedArchives':prior,'limitations':{'wrongMethod16':'Rawcomparisons preserved; excluded intendedidentity.','policy84':'separateunexecutednative/portabledefaultscope','close28':'separateunexecuted ordinaryadapter; originalrawretainedinclosedJava07/08roots','sharedBacking':'Portablecopiedcompletions notJava/native samebackingbranch','instrumentation':'OneactualJava powertrue; defaultconsumeronly, twoRustmodes separatelyownedA','gc':'Requests/collectionschedule distinction','broader':'No fullidentity/renderer/M2/platformrelease/performance claim'},'externalIdentityQualification':'Gitcommit suppliedbyroot and prior publishedfixturecheckpoint. B invokes no Git; blobIDs computedfromliteralbytes, source/installed exactbyteequality checked. Canonicalnative/platform artifacts/sourcecaptures are separatelypackaged byA/C.'}
write(O/'selection.json',index);write(O/'source-before.json',before);write(O/'external-live-map.json',{digest:row['canonicalPath']for digest,row in canonical.items()})
shutil.copy2(M/'tools/evidence.py',O/'evidence.py')
# Source/index/restore tools live in only the tools archive; all payload references resolve across the three groups.
for name in ['selection.json','restore.py','verify_raw.py','publish.py','evidence.py','prewalk-exclusions.json']:shutil.copy2(O/name,CLEAN/'oracles-tools'/name)
for group in ['native','portable','oracles-tools']:
 write(CLEAN/group/'CAPTURE_SELECTION.json',{'schema':1,'group':group,'selectedOriginalFiles':sum(r['group']==group for r in records),'storedContentObjects':[{'path':v['path'],'sha256':digest,'bytes':v['bytes']}for digest,v in objects.items()if v['group']==group],'globalIndexArchive':'renderer-c06-oracles-tools.tar.gz/selection.json','originalModes':'Storedinselection.json; evidence.tar normalizesheaders0644/mtime0, restore reappliesoriginalmodes.','externalPayloads':'Original860 Git/hash references andA/Ccanonicalproducerhashrefs, no compiledartifact/snapshot duplication.'})
write(O/'selection-summary.json',{'originalSelectedFiles':len(records),'originalSelectedBytes':sum(r['bytes']for r in records),'roots':len(roots),'storageCounts':dict(collections.Counter(r['storage']['kind']for r in records)),'contentObjects':len(objects),'contentObjectBytes':sum(o['bytes']for o in objects.values()),'gitFixtureFiles':len(git_files),'canonicalExternalObjects':len(canonical),'sourceTraversal':'No original directory walk; exactinventories/manifests and metadata-listed mismatchprefixes only.','archiveGroups':['native','portable','oracles-tools']})
print(json.dumps(json.loads((O/'selection-summary.json').read_bytes())),flush=True)

def command(name,argv):
 record={'name':name,'command':argv,'cwd':str(O),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentPid':os.getpid()}
 with(O/(name+'.stdout.bin')).open('wb')as out,(O/(name+'.stderr.bin')).open('wb')as err:
  proc=subprocess.Popen(argv,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);record['pid']=proc.pid;write(O/(name+'.launch.json'),record);record['exitCode']=proc.wait()
 record['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['stdoutSha256']=file_sha(O/(name+'.stdout.bin'));record['stderrSha256']=file_sha(O/(name+'.stderr.bin'));write(O/(name+'.terminal.json'),record);commands.append(record)
 if record['exitCode']!=0:raise RuntimeError(name+' failed')
 return record
archives=[];readbacks=[]
for group in ['native','portable','oracles-tools']:
 archive=ARCH/('renderer-c06-'+group+'.tar.gz');command(group+'-create',[sys.executable,str(O/'evidence.py'),'create',str(CLEAN/group),str(archive)]);command(group+'-verify',[sys.executable,str(O/'evidence.py'),'verify',str(archive)])
 # Independent complete member readback to gathered originals, with source object identity join.
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();names=[m.name for m in members];assert len(names)==len(set(names));by_name={m.name:m for m in members};evidence=json.load(tar.extractfile(by_name['EVIDENCE.json']));assert set(names)=={r['path']for r in evidence['files']}|{'EVIDENCE.json'}
  count=0
  for row in evidence['files']:
   member=by_name[row['path']];assert member.isfile()and member.mode==0o644 and member.mtime==0
   data=tar.extractfile(member).read();assert len(data)==row['bytes']and sha(data)==row['sha256']and data==regular(CLEAN/group/safe(row['path']))
   if row['path'].startswith('objects/'):
    digest=row['path'].split('/')[1];assert digest in objects and objects[digest]['group']==group and data==regular(Path(objects[digest]['firstOriginal']))
   count+=1
 readbacks.append({'archive':archive.name,'payloadMembersRead':count,'allRawMemberBytesEqualGatheredAndObjectOriginal':True,'unsafeMembers':0})
 archives.append({'group':group,'path':str(archive),'sha256':file_sha(archive),'bytes':archive.stat().st_size,'payloadFiles':count,'membersIncludingEvidence':count+1})
# Restore from the exact clean object set and external identities, then independently verify all raw channels offline.
command('restore',[sys.executable,str(O/'restore.py'),'--index',str(O/'selection.json'),'--objects',str(CLEAN),'--output',str(O/'restored'),'--git-fixture',str(GP),'--external-map',str(O/'external-live-map.json')])
command('offline-raw-verify',[sys.executable,str(O/'verify_raw.py'),'--restored',str(O/'restored')])
changes=[]
for path,row in before.items():
 p=Path(path)
 if not stat.S_ISREG(p.lstat().st_mode)or file_sha(p)!=row['sha256']or p.stat().st_size!=row['bytes']or stat.S_IMODE(p.stat().st_mode)!=row['mode']:changes.append(path)
assert not changes
write(O/'archive-index.json',{'schema':1,'archives':archives,'globalSelectionSha256':file_sha(O/'selection.json'),'readbacks':readbacks,'crossArchiveContentObjectsUnique':len(objects)==len(set(objects)),'gitFixtureCommit':git_fixture['commit'],'canonicalArtifactCopies':0})
report={'schema':1,'scope':'FreshC06native1840+portable980 actualoriginalraw/tool/golden publication; no new evaluator/build/Java/Node/browser acquisition.','archives':archives,'selectionSummary':json.loads((O/'selection-summary.json').read_bytes()),'archiveIndexSha256':file_sha(O/'archive-index.json'),'globalSelectionSha256':file_sha(O/'selection.json'),'commands':commands,'readbacks':readbacks,'offlineRawVerification':json.loads((O/'offline-raw-verify.stdout.bin').read_bytes()),'originalSourceChanges':changes,'sourceModesPreservedInIndex':True,'gitFixtureCopies':0,'canonicalArtifactCopies':0,'C05AndFailedAttempts':'Exacthistoricalreferences andselectedmetadata/mismatchraw; initialjavac/tool failures additionally viaexisting committedarchives. No oldcandidate rerun orrewrite.','limitations':index['limitations'],'mainReportsGitWrites':0,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'liveHandles':[]}
write(O/'report.json',report);print(json.dumps({'archives':archives,'reportSha256':file_sha(O/'report.json'),'originalChanges':len(changes),'offline':report['offlineRawVerification']},indent=2),flush=True)
