"""Execute an immutable per-attempt copy of the Stage18 packaging helper."""
from pathlib import Path
import sys,subprocess,json,hashlib,datetime,platform
root=Path.cwd();out=(root/sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=False)
helper=root/'target/m2/package_stage18_final.py';frozen=out/'package_stage18_final.py';frozen.write_bytes(helper.read_bytes())
digest=lambda raw:hashlib.sha256(raw).hexdigest()
command=[sys.executable,str(frozen),*sys.argv[2:]]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
process=subprocess.run(command,cwd=root,capture_output=True)
row=dict(command=command,exit_code=process.returncode,host=platform.platform(),utc_start=start,
 utc_end=datetime.datetime.now(datetime.timezone.utc).isoformat(),executed_helper_sha256=digest(frozen.read_bytes()),
 helper_source_sha256_after=digest(helper.read_bytes()),captured_binaries_executed=False)
for channel in ['stdout','stderr']:
 raw=getattr(process,channel);(out/(channel+'.bin')).write_bytes(raw);row[channel+'_sha256']=digest(raw)
(out/'process.json').write_text(json.dumps(row,indent=2)+'\n')
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
(out/'evidence-sha256.json').write_text(json.dumps({str(p.relative_to(out)):digest(p.read_bytes()) for p in sorted(out.rglob('*')) if p.is_file()},indent=2)+'\n')
print(process.stdout.decode(errors='replace')+process.stderr.decode(errors='replace'),end='')
raise SystemExit(process.returncode)
