"""Stop a superseded candidate acquisition after a reproduced parser regression."""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import time

out = Path(__file__).parent
pid = 47053
observed = subprocess.check_output(['ps', '-p', str(pid), '-o', 'pid=,ppid=,command='])
assert b'tools/m2_language.py --output target/m2/stage39-language-final-01 --workers 4 --record-only' in observed
(out / 'process-before.txt').write_bytes(observed)
record = dict(schema=1, pid=pid, signal='SIGTERM', requested_epoch=time.time(),
              reason='Independent pinned-Java/frozen-Rust reproduction confirmed the newly introduced keyword-head lambda first-error regression. Preserve partial acquisition; it is not a complete comparison or candidate result.',
              reproduction='target/m2/stage39-lambda-keyword-review-01/cases/true-comma',
              acquisition='target/m2/stage39-language-final-01',
              wrapper='target/m2/stage39-command-captures-01/language-final-01',
              helper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(out / 'termination-request.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
os.kill(pid, signal.SIGTERM)
print(json.dumps(record), flush=True)
