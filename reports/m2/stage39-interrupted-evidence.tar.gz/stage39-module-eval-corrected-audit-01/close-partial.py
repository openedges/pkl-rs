from pathlib import Path
import sys,json,hashlib,collections,subprocess
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools'))
import compat,m2_module_eval
OUT=Path(__file__).parent
R=ROOT/'target/m2/stage39-module-eval-corrected-01'
CMD=ROOT/'target/m2/stage39-module-eval-corrected-command-01'
C=ROOT/'target/m2/stage39-original72-java-01'
def read(p): return json.loads(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p): return {'path':str(p),'sha256':sha(p)}
assert not (R/'report.json').exists()
terminal=read(CMD/'report.json')
assert terminal['exit_code']==-2
for channel in ['stdout','stderr']:
 assert sha(CMD/(channel+'.bin'))==terminal[channel+'_sha256']
assert subprocess.run(['ps','-p','43641','-o','command='],capture_output=True).returncode==1
manifest=read(R/'sources/compatibility/m2-language.json')
selected=[r for r in manifest['cases'] if r.get('adapter')==m2_module_eval.ADAPTER]
assert [r['id'] for r in selected]==read(R/'selection.json')['case_ids']
assert len(selected)==72
source_map={str(p.relative_to(R/'sources')):sha(p) for p in sorted((R/'sources').rglob('*')) if p.is_file()}
B=ROOT/'target/m2/stage39-adapter-final-checks-01/source-freeze.json'
A=ROOT/'target/m2/stage39-core-validation-03/freeze.json'
B_not_captured=[]
for name,digest in read(B)['sources'].items():
 if name in source_map: assert source_map[name]==digest,name
 else:
  assert sha(ROOT/name)==digest,name
  B_not_captured.append(name)
assert sha(A)==read(B)['A_freeze_sha256']
Amap=A.parent/read(A)['all_runtime_sources']
assert sha(Amap)==read(A)['all_runtime_sources_sha256']
for name,digest in read(Amap).items(): assert source_map[name]==digest,name
artifact=R/'artifacts/module_eval_probe'
assert read(R/'build.process.json')['exit_code']==0
baseline=read(R/'module-workspace.json')
workspace=ROOT/'target/m2/stage39-original72-workspace-01/workspace'
workspace_restored=compat.snapshot(workspace)==baseline
assert workspace_restored
records=collections.defaultdict(list)
for row in read(C/'report.json')['records']: records[row['id']].append(row)
rows=[]
for case in selected:
 folder=R/'cases'/compat.case_directory(case['id'])
 if not folder.exists(): continue
 row={'id':case['id'],'folder':folder.name,'capture_state':{}}
 for runtime in ['java','rust']:
  capture=folder/runtime
  complete=all((capture/name).is_file() for name in ['process.json','result.json','stdout.bin','stderr.bin'])
  row['capture_state'][runtime]='complete' if complete else ('incomplete' if capture.exists() else 'not-persisted')
  if not complete: continue
  proc=read(capture/'process.json'); actual=compat.load_capture(capture)
  assert proc['watchdog_seconds']==60
  assert not actual['workspace_changes']
  diffs=[]
  for old in records[case['id']]:
   expected=compat.load_capture(C/'cases'/folder.name/str(old['repeat']))
   assert proc['source_uri']==old['moduleUri'] and proc['cwd']==old['cwd']
   assert proc['environment']==old['environment']
   assert (proc['command']==old['command']) if runtime=='java' else (proc['command'][1:]==old['originalArguments'])
   assert sha(folder/'input.pkl')==old['sourceSha256']
   diffs.append({'repeat':old['repeat'],'differences':compat.differences(expected,actual)})
  row[runtime+'_vs_original_java']=diffs
 if all(v=='complete' for v in row['capture_state'].values()):
  j=read(folder/'java/process.json'); n=read(folder/'rust/process.json')
  row['status']=m2_module_eval.status(j,n,compat.load_capture(folder/'java'),compat.load_capture(folder/'rust'))
 else: row['status']='uncompleted-acquisition'
 rows.append(row)
progress=(CMD/'stdout.bin').read_text().splitlines()
assert len([r for r in rows if r['status']!='uncompleted-acquisition'])==len(progress)==25
assert len(rows)==26
assert all(r['status']=='pass' for r in rows[:-1])
assert rows[-1]['capture_state']=={'java':'complete','rust':'not-persisted'}
for row in rows:
 for runtime in ['java','rust']:
  assert all(not r['differences'] for r in row.get(runtime+'_vs_original_java',[]))
# Acquisition and command trees have no build/cache subtree. Audit only exact roots.
inventory={}
for label,root in [('acquisition',R),('command',CMD)]:
 inventory[label]={str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
(OUT/'closed-input-inventory.json').write_bytes(compat.encoded(inventory))
(OUT/'captured-source-map.json').write_bytes(compat.encoded(source_map))
result={'status':'intentionally-interrupted-and-closed','scope':'Partial original72 module-eval acquisition; never completed72/final candidate/fullM2. Original captures retained unchanged.',
 'reason':read(CMD/'termination-request.json')['reason'],'driver_terminal':terminal,'outer_tool_exit_code':254,
 'native_process_interruption':'Traceback reaches native capture postprocess workspace restoration check. Native26 was invoked but raw result was not persisted; do not count it as unexecuted or pass.',
 'requested_cases':72,'completed_pairs':25,'completed_pair_status_counts':{'pass':25},'fresh_java_complete_captures':26,'native_complete_captures':25,
 'uncompleted_started_case':rows[-1]['id'],'not_started_cases':46,'completed_metarelation_checks':0,
 'full_report_present':False,'offline_gate_status':'Not run: acquisition has no complete report. No integrity/subset/development/full gate claimed.',
 'workspace_restored_to_baseline':workspace_restored,'workspace_released':True,'no_live_B_acquisition_handles':True,
 'candidate':identity(artifact),'build':identity(R/'build.process.json'),'A_freeze':identity(A),'B_freeze':identity(B),
 'B_test_sources_not_in_acquisition_snapshot_currently_match_freeze':B_not_captured,'captured_source_count':len(source_map),'all_runtime_source_identities_bound':len(read(Amap)),
 'original_java':identity(C/'report.json'),'closed_input_inventory':identity(OUT/'closed-input-inventory.json'),
 'comparison_boundary':'Exact stdout/stderr/exit/files/timed_out/workspace_changes and actual original argv/cwd/env/physical URI; no normalization. Completedcaptures compared separately to both closed Java repeats.',
 'cache_policy':'Only exact acquisition/command/source subtrees and managed resource workspace inspected. No Cargo/cache traversal.',
 'planned_full_audit_script':'audit.py retained unexecuted because acquisition intentionally stopped; close-partial.py is actual terminal audit.', 'rows':rows}
(OUT/'report.json').write_bytes(compat.encoded(result))
print(json.dumps({k:v for k,v in result.items() if k not in ('rows','driver_terminal')},indent=2))
