from pathlib import Path
import sys,json,hashlib,collections
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'tools'))
import compat
OUT=Path(__file__).parent
R=ROOT/'target/m2/stage39-module-eval-corrected-01'
C=ROOT/'target/m2/stage39-original72-java-01'
def read(p): return json.loads(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p): return {'path':str(p),'sha256':sha(p)}
report=read(R/'report.json')
closed=read(C/'report.json')
registry=read(ROOT/'compatibility/m2-module-eval.json')
ids=[x['id'] for x in registry['cases']]
assert [x['id'] for x in report['results']]==ids
assert report['selected_count']==len(ids)==72
assert report['selection']==read(R/'selection.json')
assert report['selection']['case_ids']==ids
assert report['selection']['adapters']==['language-module-eval']
assert report['source_stability'] and report['artifact_stability']
assert report['candidate'] is None and report['metamorphic_results']==[]
assert report['module_eval']['watchdog_seconds']==60
assert report['module_candidate']['source_binding']=='recorded-build'
assert report['module_candidate']['build']['exit_code']==0
artifact=R/'artifacts/module_eval_probe'
assert sha(artifact)==report['module_candidate']['sha256']
assert sha(Path(report['module_candidate']['path']))==sha(artifact)
for name,digest in report['source_sha256'].items():
 assert sha(ROOT/name)==sha(R/'sources'/name)==digest,name
B=ROOT/'target/m2/stage39-adapter-final-checks-01/source-freeze.json'
A=ROOT/'target/m2/stage39-core-validation-03/freeze.json'
for name,digest in read(B)['sources'].items(): assert sha(ROOT/name)==digest,name
assert sha(A)==read(B)['A_freeze_sha256']
Amap=A.parent/read(A)['all_runtime_sources']
assert sha(Amap)==read(A)['all_runtime_sources_sha256']
for name,digest in read(Amap).items(): assert sha(ROOT/name)==digest,name
records=collections.defaultdict(list)
for row in closed['records']: records[row['id']].append(row)
comparisons=[]
for row in report['results']:
 folder=R/'cases'/row['directory']
 native=compat.load_capture(folder/'rust')
 fresh=compat.load_capture(folder/'java')
 assert row['java']['watchdog_seconds']==row['rust']['watchdog_seconds']==60
 assert not native['workspace_changes'] and not fresh['workspace_changes']
 assert len(records[row['id']])==2
 channels=[]
 for old in records[row['id']]:
  capture=C/'cases'/compat.case_directory(row['id'])/str(old['repeat'])
  original=compat.load_capture(capture)
  assert old['moduleUri']==row['java']['source_uri']==row['rust']['source_uri']
  assert old['cwd']==row['java']['cwd']==row['rust']['cwd']
  assert old['command']==row['java']['command']
  assert old['environment']==row['java']['environment']==row['rust']['environment']
  assert row['rust']['command'][1:]==old['originalArguments']
  assert sha(folder/'input.pkl')==old['sourceSha256']
  channels.append({'repeat':old['repeat'],'fresh_java_vs_original':compat.differences(original,fresh),
                   'native_vs_original':compat.differences(original,native),
                   'original_stderr_sha256':sha(capture/'stderr.bin'),
                   'native_stderr_sha256':sha(folder/'rust/stderr.bin')})
 comparisons.append({'id':row['id'],'status':row['status'],'comparisons':channels})
raw_match=all(not c['fresh_java_vs_original'] and not c['native_vs_original'] for r in comparisons for c in r['comparisons'])
result={'scope':'Independent offline full raw channels/source/profile/recorded-build review of selected original72 module contract. Not full M2 or module output support.',
 'report':identity(R/'report.json'),'original_java':identity(C/'report.json'),
 'A_freeze':identity(A),'B_freeze':identity(B),'artifact':identity(artifact),
 'raw_match_to_both_original_repeats':raw_match,'selected':len(ids),'status_counts':dict(collections.Counter(x['status'] for x in report['results'])),
 'compared_original_processes':sum(len(r['comparisons']) for r in comparisons),
 'fresh_java_processes':len(ids),'native_processes':len(ids),
 'source_count':len(report['source_sha256']),'all_runtime_freeze_sources':len(read(Amap)),
 'metamorphic_relations_selected':0,'full_gate_failure_count':len(report['full_gate_failures']),
 'comparisons':comparisons,'cache_policy':'No cache traversal. Exact source map paths and capture directories only.'}
(OUT/'report.json').write_bytes(compat.encoded(result))
print(json.dumps({k:v for k,v in result.items() if k!='comparisons'},indent=2))

if not raw_match: raise SystemExit(1)
