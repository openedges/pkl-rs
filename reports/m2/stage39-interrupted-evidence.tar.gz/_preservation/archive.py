"""Preserve explicitly listed, closed evidence without altering original captures."""
from pathlib import Path
import hashlib
import io
import json
import os
import stat
import sys
import tarfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()

plan_path = Path(sys.argv[1]).absolute()
plan = json.loads(plan_path.read_bytes())
base = Path(plan['base'])
archive = Path(plan['archive'])
report = Path(plan['report'])
assert not archive.exists() and not report.exists()
excluded = {base / name for name in plan.get('excluded_cargo_paths', [])}
sources = {}
for name in plan['roots']:
    origin = base / name
    assert origin.is_dir(), origin
    for directory, children, names in os.walk(origin, topdown=True, followlinks=False):
        children[:] = sorted(child for child in children if Path(directory) / child not in excluded)
        assert all(not (Path(directory) / child).is_symlink() for child in children)
        for filename in sorted(names):
            path = Path(directory) / filename
            assert path.is_file() and not path.is_symlink(), path
            key = path.relative_to(base).as_posix()
            assert key not in sources, key
            sources[key] = path
sources['_preservation/archive.py'] = Path(__file__)
sources['_preservation/plan.json'] = plan_path
inventory = {}
for name, path in sorted(sources.items()):
    data = path.read_bytes()
    inventory[name] = dict(bytes=len(data), sha256=sha(data), mode=stat.S_IMODE(path.stat().st_mode))
payload = encoded(dict(schema=1, scope=plan['scope'], files=inventory,
                       exclusions=plan.get('excluded_cargo_paths', []),
                       excluded_cache_contents_enumerated=False))
with tarfile.open(archive, 'w:gz') as target:
    for name, path in sorted(sources.items()):
        data = path.read_bytes()
        assert sha(data) == inventory[name]['sha256']
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(data), inventory[name]['mode']
        target.addfile(info, io.BytesIO(data))
    info = tarfile.TarInfo('archive-inventory.json')
    info.size = len(payload)
    target.addfile(info, io.BytesIO(payload))
with tarfile.open(archive, 'r:gz') as target:
    entries = target.getmembers()
    assert len(entries) == len(inventory) + 1
    assert {entry.name for entry in entries} == set(inventory) | {'archive-inventory.json'}
    for entry in entries:
        assert entry.isfile()
        data = target.extractfile(entry).read()
        if entry.name == 'archive-inventory.json':
            assert data == payload
        else:
            expected = inventory[entry.name]
            assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
            assert entry.mode == expected['mode']
assert all(sha(path.read_bytes()) == inventory[name]['sha256'] for name, path in sources.items())
result = dict(schema=1, scope=plan['scope'], archive=str(archive),
              archive_sha256=sha(archive.read_bytes()), archive_bytes=archive.stat().st_size,
              original_files=len(inventory), original_bytes=sum(row['bytes'] for row in inventory.values()),
              inventory_sha256=sha(payload), originals_stable=True, extracted_members_verified=True,
              plan_sha256=sha(plan_path.read_bytes()), helper_sha256=sha(Path(__file__).read_bytes()))
report.write_bytes(encoded(result))
print(json.dumps(result), flush=True)
