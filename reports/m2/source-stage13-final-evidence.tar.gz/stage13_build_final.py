from pathlib import Path
import json,sys,os
sys.path.insert(0,'tools')
import oracle,m2_language as l,m2_manifest as c
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False);paths=[Path(p)for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','oracle.lock.json','tools/oracle.py','tools/m2_language.py','target/m2/stage13_build_final.py']];paths.extend(p for p in Path('crates').rglob('*')if p.is_file());before={str(p):oracle.sha256(p)for p in paths}
for p in paths:
 dst=out/'sources'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(p.read_bytes())
compiler=l.capture(['rustc','-vV'],out,'rustc');cargo=l.capture(['cargo','--version'],out,'cargo-version');command=['cargo','build','-p','pkl-runtime','--example','language_probe','--locked','--release','--message-format=json'];build=l.capture(command,out,'build',dict(os.environ),timeout=300);assert build['exit_code']==0
messages=[json.loads(line)for line in (out/'build.stdout.bin').read_bytes().splitlines()];executables=[Path(r['executable'])for r in messages if r.get('reason')=='compiler-artifact'and r.get('executable')and r.get('target',{}).get('name')=='language_probe'];assert len(executables)==1
src=executables[0];frozen=out/'artifacts/language_probe';frozen.parent.mkdir();frozen.write_bytes(src.read_bytes());frozen.chmod(0o755);after={str(p):oracle.sha256(p)for p in paths};metadata=dict(source_binding='recorded-build',source_stability=before==after,source_sha256_before=before,source_sha256_after=after,candidate_path=str(src),candidate_sha256=oracle.sha256(src),frozen_path=str(frozen),frozen_sha256=oracle.sha256(frozen),build=build,rustc=compiler,cargo=cargo);(out/'candidate.json').write_bytes(c.encoded(metadata));(out/'evidence-sha256.json').write_bytes(c.encoded({str(p.relative_to(out)):oracle.sha256(p)for p in out.rglob('*')if p.is_file()}));print(json.dumps(dict(frozen=str(frozen),sha256=oracle.sha256(frozen),source_stability=before==after)))
