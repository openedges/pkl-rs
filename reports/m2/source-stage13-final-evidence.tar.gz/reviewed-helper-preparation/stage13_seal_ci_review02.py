"""Package verified stage13 CI evidence, then retain an independent sealed replay."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

root = Path.cwd()
base = root / 'target/m2'
helpers = base / 'ci-stage13-review-02'
final = base / 'ci-stage13-final-evidence'
package = final / 'package'
acquired = base / 'ci-stage13-acquired'

def load(path):
    return json.loads(path.read_bytes())

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def capture(name, command):
    directory = base / ('ci-stage13-' + name + '-process')
    subprocess.run([sys.executable, str(helpers / 'capture_process.py'), '--output', str(directory), '--', *map(str, command)], check=True)
    return directory

def inventory(directory):
    return {str(p.relative_to(directory)): dict(bytes=p.stat().st_size, sha256=sha(p))
            for p in sorted(directory.rglob('*')) if p.is_file()}

def compare(original, replay, package_stable, replay_path):
    fields = sorted(set(original) - {'frozen_verifiers'})
    assert {key: original[key] for key in fields} == {key: replay[key] for key in fields}
    assert {key: row['sha256'] for key,row in original['frozen_verifiers'].items()} == {
        key: row['sha256'] for key,row in replay['frozen_verifiers'].items()}
    return dict(status='pass', commit=original['commit'], run_id=original['run_id'],
                compared_result_fields=fields, complete_result_fields_equal=True,
                frozen_verifier_hashes_equal=True, package_unchanged=package_stable,
                original_package=str(package), unpacked_replay=str(replay_path),
                verification_sha256=sha(replay_path/'verification/verification.json'),
                source_snapshot_copies=replay['exact_source_snapshot_copies'],
                unique_source_files=replay['unique_source_files'])

original = load(acquired/'verification/verification.json')
terminal = load(base/'ci-stage13-terminal-status/status-summary.json')
assert terminal['all_six_jobs_succeeded'] and terminal['commit'] == original['commit']
assert terminal['run_id'] == original['run_id']
assert len(terminal['jobs']) == 6 and all(row['conclusion']=='success' for row in terminal['jobs'])
assert original['commit'] == sys.argv[1]
final.mkdir(exist_ok=False)
print('Packaging original verified ZIPs and exact commit evidence.', flush=True)
package_process = capture('package', [sys.executable, helpers/'package.py', '--acquired', acquired, '--output', package])
before_initial = inventory(package)
write(base/'ci-stage13-pre-offline-inventory.json', before_initial)
initial_path = base/'ci-stage13-offline-initial'
initial_process = capture('offline-initial', [sys.executable, package/'verification/unpack_and_verify.py', '--repository-root', root, '--output', initial_path])
assert inventory(package) == before_initial
initial = compare(original, load(initial_path/'verification/verification.json'), True, initial_path)
write(package/'verification/portable-recheck.json', initial)
captures = package/'verification/captured-processes'
captures.mkdir()
for name, directory in [('discovery',base/'ci-stage13-discovery-process'), ('acquire',base/'ci-stage13-acquire-process'), ('package',package_process),
                        ('terminal-status',base/'ci-stage13-terminal-process'), ('offline-initial',initial_process)]:
    shutil.copytree(directory,captures/name)
shutil.copytree(base/'ci-stage13-terminal-status',package/'metadata/terminal-status')
preparation = package/'verification/helper-preparation'
preparation.mkdir()
shutil.copyfile(helpers/'preparation.json',preparation/'preparation.json')
for name in ['self-test.stdout.bin','self-test.stderr.bin']:
    shutil.copyfile(helpers/name,preparation/name)
local_helpers = {}
for source in [base/'stage13_terminal_from_acquired.py', Path(__file__)]:
    shutil.copyfile(source,preparation/source.name)
    local_helpers[source.name] = sha(source)
write(preparation/'local-helper-sha256.json',local_helpers)
manifest = load(package/'package-manifest.json')
files = inventory(package)
del files['package-manifest.json']
manifest.update(files=files,file_count=len(files)+1,hashed_file_count=len(files))
write(package/'package-manifest.json',manifest)
sealed = inventory(package)
write(base/'ci-stage13-sealed-inventory.json',sealed)
print('Package sealed; replaying without executing captured binaries.', flush=True)
sealed_path = base/'ci-stage13-offline-sealed'
sealed_process = capture('offline-sealed', [sys.executable, package/'verification/unpack_and_verify.py', '--repository-root', root, '--output', sealed_path])
assert inventory(package) == sealed
portable = compare(original,load(sealed_path/'verification/verification.json'),True,sealed_path)
portable.update(offline_exit_code=0,package_manifest_sha256=sha(package/'package-manifest.json'),
                package_files=len(sealed),packaged_initial_offline_capture='verification/captured-processes/offline-initial',
                packaged_initial_offline_result='verification/portable-recheck.json',
                capture_rounds='Initial replay capture was integrated, then the final sealed package was replayed without further package mutation.')
proof = base/'ci-stage13-offline-proof'
shutil.copytree(sealed_process,proof)
shutil.copyfile(sealed_path/'verification/verification.json',proof/'verification.json')
write(proof/'result.json',portable)
shutil.copytree(proof,final/'offline-proof')
(final/'README.md').write_text('''# Stage 13 exact-commit CI evidence

`package/` preserves the original GitHub ZIP artifacts, exact commit identities,
all six terminal job outcomes, independent raw verification, helper preparation,
and the initial portable replay. `offline-proof/` records a second replay of the
sealed package. The package stayed byte-identical during that final replay.

M2 selected and M1 architecture contracts retain known failures. These artifacts
do not establish complete language/API compatibility or performance targets.
''')
archives={}
for name, directory, filename in [('main',final,'ci-stage13-evidence.tar.gz'),
                                  ('offline',proof,'ci-stage13-offline-evidence.tar.gz')]:
    archive=base/filename
    capture('archive-'+name,[sys.executable,root/'tools/evidence.py','create',directory,archive])
    with tarfile.open(archive,'r:gz') as stream:
        count=len(stream.getmembers())
    archives[name]=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),
                        inventory_verified=True,files_including_inventory=count)
summary=dict(original)
summary.update(package=str(package),artifact_payloads=load(package/'package-summary.json')['artifact_payloads'],
               all_six_jobs_succeeded=True,evidence_archives=archives,portable_recheck=portable,
               portable_recheck_process=load(sealed_process/'process.json'),
               captured_processes={name:load(directory/'process.json') for name,directory in [
                   ('acquire',base/'ci-stage13-acquire-process'),('package',package_process),
                   ('terminal-status',base/'ci-stage13-terminal-process'),
                   ('offline-initial',initial_process),('offline-sealed',sealed_process)]})
write(base/'ci-stage13-summary.json',summary)
print(json.dumps(dict(summary=str(base/'ci-stage13-summary.json'),archives=archives,
                      m2=summary['m2'],m1_platform=summary['m1']['platform']),sort_keys=True),flush=True)

# Publish only the three report files authorized for this exact implementation.
reports = root/'reports/m2'
for name,row in archives.items():
    original_archive=Path(row['path'])
    report_archive=reports/original_archive.name
    if report_archive.exists():
        raise ValueError('Refusing to replace prior CI evidence: '+str(report_archive))
    shutil.copyfile(original_archive,report_archive)
    assert sha(report_archive)==row['sha256']
    row['report_path']=str(report_archive.relative_to(root))
    row['report_digest_verified']=True
summary['evidence_archives']=archives
summary['source_count_contract']='exact_source_snapshot_copies counts each checked path in each captured source snapshot; unique_source_files counts distinct repository source paths across those snapshots.'
write(base/'ci-stage13-summary.json',summary)
report_summary=reports/'ci-stage13-summary.json'
if report_summary.exists():
    raise ValueError('Refusing to replace prior CI summary')
shutil.copyfile(base/'ci-stage13-summary.json',report_summary)
print(json.dumps({'report_summary':str(report_summary),'archives':archives,'exact_source_snapshot_copies':summary['exact_source_snapshot_copies'],'unique_source_files':summary['unique_source_files']},sort_keys=True),flush=True)
