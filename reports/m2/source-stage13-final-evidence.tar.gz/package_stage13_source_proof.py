"""Package exact-commit Stage 13 source proof after final captures are packaged.

This target-only helper never executes captured evaluation binaries or modifies
raw suites/archives. It refuses existing proof outputs and enriches only the
final summary that still explicitly marks its commit binding as pending.
"""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
COMMIT = 'f90d7b09124bb5a7d73dd5b2bfcddf2a90d2761f'
PRIOR_COMMIT = '9e67c9be1d10ff4c746c7bf18c9aecb993cf6bf7'


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def relative(name):
    path = Path(name)
    require(not path.is_absolute() and '..' not in path.parts,
            'Unsafe relative evidence path: ' + str(name))
    return path


def process(directory, filename='process.json', expected_exit=0):
    row = load(directory / filename)
    require(row['exit_code'] == expected_exit and row['timed_out'] is False,
            'Command did not complete successfully: ' + str(directory / filename))
    prefix = filename.removesuffix('process.json')
    for channel in ['stdout', 'stderr']:
        capture = directory / (prefix + channel + '.bin')
        require(sha(capture) == row[channel + '_sha256'],
                'Command capture digest differs: ' + str(capture))
        if channel + '_bytes' in row:
            require(capture.stat().st_size == row[channel + '_bytes'],
                    'Command capture size differs: ' + str(capture))
    return row


def git(*arguments):
    return subprocess.run(['git', *arguments], cwd=ROOT, check=True,
                          capture_output=True, timeout=60).stdout


@lru_cache(maxsize=None)
def committed(name):
    relative(name)
    for prefix in ['external/pkl/', 'external/pkl-pantry/']:
        if name.startswith(prefix):
            repository = prefix.removesuffix('/')
            revision = git('rev-parse', COMMIT + ':' + repository).decode().strip()
            return subprocess.run(['git', '-C', str(ROOT / repository), 'show',
                revision + ':' + name.removeprefix(prefix)], check=True,
                capture_output=True, timeout=60).stdout
    return git('show', COMMIT + ':' + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-process', default='source-stage13-final-process')
    parser.add_argument('--package-process', default='package-stage13-final-process-02')
    args = parser.parse_args()
    proof = BASE / 'source-stage13-final-evidence'
    archive = ROOT / 'reports/m2/source-stage13-final-evidence.tar.gz'
    summary_path = ROOT / 'reports/m2/stage13-final-summary.json'
    summary_temporary = summary_path.with_suffix('.source-proof.tmp')
    require(not any(p.exists() for p in [proof, archive, summary_temporary]),
            'Refusing to replace an existing source proof output')
    summary_original = summary_path.read_bytes()
    summary = json.loads(summary_original)
    require(summary['source_to_commit_binding'].startswith('Pending'),
            'Final summary is already bound; refusing to replace binding')
    require(git('rev-parse', '--verify', COMMIT + '^{commit}').decode().strip() == COMMIT,
            'Implementation commit does not resolve exactly')
    binding_path = BASE / 'source-verification-stage13-final.json'
    binding = load(binding_path)
    require(binding['implementation_commit'] == COMMIT, 'Wrong implementation binding')
    require(binding['verifier_sha256'] == sha(BASE / 'verify_stage13_implementation_sources.py'),
            'Source verifier differs from executed verifier')
    for name, digest in binding['source_reports'].items():
        require(sha(ROOT / relative(name)) == digest, 'Source report changed: ' + name)

    commands = [
        (args.source_process, 'source-binding-command'),
        (args.package_process, 'final-package-command'),
        ('language-stage13-command-final', 'language-command'),
        ('platforms-stage13-command-final', 'platforms-command'),
        ('validation-stage13-command-final', 'validation-command'),
        ('frontend-stage13-command-final', 'frontend-command'),
        ('runtime-stage13-command-final', 'runtime-command'),
        ('lifecycle-stage13-command-final', 'lifecycle-command'),
        ('prior-selection-stage13-command-final', 'prior-selection-command'),
    ]
    records = {destination: process(BASE / relative(name)) for name, destination in commands}
    source_command = records['source-binding-command']['command']
    require(COMMIT in source_command and '--output' in source_command
            and any(Path(arg).name == 'verify_stage13_implementation_sources.py'
                    for arg in source_command), 'Captured source-binding command differs')
    require(Path(source_command[source_command.index('--output') + 1]).resolve() == binding_path,
            'Captured source-binding command wrote another output')
    failed_package_dir = BASE / 'package-stage13-final-process'
    failed_package = process(failed_package_dir, expected_exit=1)
    require(any(Path(arg).name == 'package_stage13_final.py' for arg in failed_package['command']),
            'Failed package capture is not the original final package command')
    package_command = records['final-package-command']['command']
    require('--check-ready' not in package_command
            and any(Path(arg).name == 'package_stage13_final.py' for arg in package_command),
            'Captured packaging command is not final packaging')
    class_commands = BASE / 'class-lifecycle-stage13-command-final'
    for name in ['tests', 'integrity', 'contract']:
        process(class_commands, name + '.process.json')
    for name, digest in load(class_commands / 'evidence-sha256.json').items():
        require(sha(class_commands / relative(name)) == digest, 'Class command inventory differs')

    # Claims audit already belongs to the sealed regression package.
    claims_path = BASE / 'regressions-stage13-final/raw-claims-audit.json'
    claims = load(claims_path)
    require(claims['status'] == 'pass' and claims['captured_binaries_executed'] is False,
            'Final raw claims audit did not pass')
    regression_archive = summary['archives']['regressions']
    regression_path = ROOT / relative(regression_archive['path'])
    require(sha(regression_path) == regression_archive['sha256'], 'Regression archive changed')
    with tarfile.open(regression_path, 'r:gz') as stream:
        matches = [entry for entry in stream.getmembers()
                   if entry.isfile() and (entry.name.endswith('/raw-claims-audit.json')
                                          or entry.name == 'raw-claims-audit.json')]
        require(len(matches) == 1, 'Regression archive lacks one unique claims audit')
        require(stream.extractfile(matches[0]).read() == claims_path.read_bytes(),
                'Claims audit differs from sealed regression archive')

    reviewed = load(BASE / 'stage13-final-helpers-syntax-review02.json')
    reviewed_checks = {Path(row['path']).name: row for row in reviewed['checks']}
    binder_name = 'verify_stage13_implementation_sources.py'
    require(reviewed_checks[binder_name]['syntax'] == 'pass'
            and reviewed_checks[binder_name]['sha256'] == sha(BASE / binder_name),
            'Source binder differs from reviewed preparation')
    correction_path = BASE / 'package-stage13-final-review03.json'
    correction = load(correction_path)
    original_packager = ROOT / relative(correction['original_helper']['path'])
    current_packager = ROOT / relative(correction['current_helper']['path'])
    require(correction['syntax'] == 'pass' and correction['reason'],
            'Package correction lacks review rationale or syntax validation')
    require(sha(original_packager) == correction['original_helper']['sha256']
            == reviewed_checks['package_stage13_final.py']['sha256'],
            'Original packager differs from preserved review02 helper')
    require(current_packager == BASE / 'package_stage13_final.py'
            and sha(current_packager) == correction['current_helper']['sha256'],
            'Executed packager differs from explicitly reviewed correction')
    preparation_dir = BASE / 'ci-stage13-review-02'
    preparation = load(preparation_dir / 'preparation.json')
    for field in ['helper_sha256', 'self_test_sha256']:
        for name, digest in preparation[field].items():
            require(sha(preparation_dir / relative(name)) == digest,
                    'Retained review preparation differs: ' + name)
    require(preparation['self_test']['exit_code'] == 0, 'Review helper self-tests failed')
    preparation_revision = load(preparation_dir / 'preparation-local-helper-retention-03.json')
    require(preparation_revision['previous_preparation']['sha256']
            == sha(preparation_dir / 'preparation.json'), 'Preparation revision base differs')
    for name, row in preparation_revision['current_local_helpers'].items():
        require(row['syntax'] == 'pass' and sha(ROOT / relative(name)) == row['sha256'],
                'Revised helper differs: ' + name)
    checkpoint_path = BASE / 'stage13-checkpoint-review.json'
    checkpoint = load(checkpoint_path)
    checkpoint_draft = ROOT / relative(checkpoint['draft'])
    require(checkpoint_draft.is_file(), 'Checkpoint draft is not retained')
    self_preparation = BASE / 'package-stage13-source-proof-preparation-02.json'
    require(load(self_preparation)['helper_sha256'] == sha(Path(__file__)),
            'Source proof helper differs from its syntax-reviewed preparation')
    prior_dir = BASE / 'ci-stage13-prior-terminal-status'
    prior_status = load(prior_dir / 'status-summary.json')
    require(prior_status['commit'] == PRIOR_COMMIT
            and prior_status['all_six_jobs_succeeded'] is True,
            'Prior CI metadata identity/status differs')
    process(BASE / 'ci-stage13-prior-terminal-process')

    snapshots = binding['source_checks']
    require(len(snapshots) == binding['verified_source_snapshot_copies'] and snapshots,
            'Source copy count differs')
    unique = {}
    for row in snapshots:
        source = str(relative(row['source']))
        snapshot = ROOT / relative(row['snapshot'])
        data = snapshot.read_bytes()
        require(hashlib.sha256(data).hexdigest() == row['sha256']
                and data == committed(source), 'Snapshot differs from exact commit: ' + str(snapshot))
        if source in unique:
            require(unique[source].read_bytes() == data, 'Duplicated source copies differ')
        unique[source] = snapshot
    require(len(unique) == binding['unique_source_files'], 'Unique source count differs')

    proof.mkdir()
    for name in ['source-verification-stage13-final.json', 'verify_stage13_implementation_sources.py',
                 'package_stage13_final.py', 'package_stage13_source_proof.py',
                 'run_stage13_validation.py', 'stage13_build_final.py',
                 'package-stage13-source-proof-preparation.json',
                 'package-stage13-source-proof-preparation-02.json']:
        shutil.copyfile(BASE / name, proof / name)
    for source, destination in commands:
        shutil.copytree(BASE / source, proof / destination)
    shutil.copytree(failed_package_dir, proof / 'packaging-first-failed-command')
    shutil.copytree(BASE / 'source-proof-stage13-preparation-01', proof / 'source-proof-helper-history/preparation01')
    correction_target = proof / 'packaging-reviewed-correction'
    correction_target.mkdir()
    shutil.copyfile(correction_path, correction_target / correction_path.name)
    shutil.copyfile(original_packager, correction_target / 'original-package_stage13_final.py')
    shutil.copyfile(current_packager, correction_target / 'corrected-package_stage13_final.py')
    shutil.copytree(class_commands, proof / 'declaration-verification-commands')
    shutil.copyfile(claims_path, proof / 'raw-claims-audit.json')
    preparation_target = proof / 'reviewed-helper-preparation'
    shutil.copytree(preparation_dir, preparation_target / 'ci-review02')
    for name in ['stage13-final-helpers-syntax.json', 'stage13-final-helpers-syntax-review02.json',
                 'stage13-final-command-plan-review02.json']:
        shutil.copyfile(BASE / name, preparation_target / name)
    for name in preparation_revision['current_local_helpers']:
        shutil.copyfile(ROOT / name, preparation_target / Path(name).name)
    shutil.copyfile(checkpoint_path, preparation_target / checkpoint_path.name)
    shutil.copyfile(checkpoint_draft, preparation_target / checkpoint_draft.name)
    shutil.copytree(prior_dir, proof / 'prior-ci-terminal-status')
    shutil.copytree(BASE / 'ci-stage13-prior-terminal-process', proof / 'prior-ci-terminal-command')
    for source, snapshot in unique.items():
        destination = proof / 'implementation-sources' / source
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(snapshot, destination)
    write_new(proof / 'source-copy-index.json', {
        'implementation_commit': COMMIT,
        'source_snapshot_copies': binding['verified_source_snapshot_copies'],
        'unique_source_files': len(unique),
        'copies': [{ 'source': name, 'snapshot': 'implementation-sources/' + name,
                    'sha256': sha(path)} for name, path in sorted(unique.items())],
    })
    write_new(proof / 'scope.json', {
        'implementation_commit': COMMIT,
        'captured_binaries_executed': False,
        'source_snapshot_copies': binding['verified_source_snapshot_copies'],
        'unique_source_files': len(unique),
        'scope': 'Each captured source copy and deduplicated proof copy equals exact Git implementation bytes, including pinned submodule blobs. Original raw comparison suites remain in separate unchanged archives. No new compatibility or performance case is introduced.',
        'claims_audit': {'path': 'raw-claims-audit.json', 'sha256': sha(claims_path),
                         'original_archive': regression_archive},
        'review_preparation': 'Original syntax/self-test/preparation records are historical helper evidence; the source binder remains byte-identical to review02 and the final packager is bound to explicit review03 correction, with the failed first command and original helper retained. Prior CI preparation is not implementation compatibility evidence.',
        'packaging_correction': {'review': 'packaging-reviewed-correction/' + correction_path.name,
            'sha256': sha(correction_path), 'reason': correction['reason'],
            'first_exit_code': failed_package['exit_code'],
            'scope': 'Original first packaging failure is preserved. Reviewed correction changes the expected relation ordering to the existing checker contract, without changing or normalizing raw comparison bytes.'},
        'preservation_checkpoint': {'review': 'reviewed-helper-preparation/' + checkpoint_path.name,
            'sha256': sha(checkpoint_path), 'new_compatibility_test_count': 0,
            'scope': 'Additional read-only review of original selected definitions, input bytes, relation and class sequence preservation. Draft placeholders remain historical and are not final outcome claims.'},
        'prior_ci': {'commit': PRIOR_COMMIT, 'run_id': prior_status['run_id'],
                     'scope': 'Separate prior reporting commit terminal status. Original metadata wording is preserved; this is not Stage 13 implementation CI or compatibility evidence.'},
    })
    subprocess.run([sys.executable, 'tools/evidence.py', 'create', str(proof), str(archive)], check=True)
    subprocess.run([sys.executable, 'tools/evidence.py', 'verify', str(archive)], check=True)
    with tarfile.open(archive, 'r:gz') as stream:
        archive_files = len(stream.getmembers())
    archive_identity = dict(path=str(archive.relative_to(ROOT)), sha256=sha(archive),
        bytes=archive.stat().st_size, files_including_inventory=archive_files, inventory_verified=True)
    require(summary_path.read_bytes() == summary_original,
            'Final summary changed concurrently; archive retained and summary not replaced')
    summary['implementation_commit'] = COMMIT
    summary['source_to_commit_binding'] = 'All final captured source copies match exact Git implementation bytes; retained raw suites and recorded-build identities remain separate evidence.'
    summary['implementation_source_verification'] = dict(
        source_snapshot_copies=binding['verified_source_snapshot_copies'],
        unique_source_files=len(unique), matched_exact_git_commit=True,
        report_sha256=sha(binding_path), evidence=archive_identity,
        method='Each captured full source byte string matches git show at the exact implementation commit, resolving external sources through that commit\'s pinned gitlinks. The proof also retains deduplicated exact source copies.')
    summary['final_claims_audit'].update(report_sha256=sha(claims_path),
        source_evidence_path='raw-claims-audit.json', new_compatibility_test_count=0,
        original_evidence=regression_archive)
    write_new(summary_temporary, summary)
    summary_temporary.replace(summary_path)
    print(json.dumps(dict(archive=archive_identity, implementation_commit=COMMIT,
        source_copies=binding['verified_source_snapshot_copies'], unique_source_files=len(unique)), sort_keys=True))


if __name__ == '__main__':
    main()
