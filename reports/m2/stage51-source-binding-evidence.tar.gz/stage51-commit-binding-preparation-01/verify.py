#!/usr/bin/env python3
"""Join authenticated candidate04 staged blobs to one explicit real implementation commit.

This reads commit/tree metadata only. Blob bytes were verified in the prior
closed staged-binding evidence and are not reread by this verifier.
"""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
FIXTURE = 'tests/fixtures/m2-collection-transforms'
PINS = {
    'handoff.json': '62a3cb3c2ef90f12dd99f154ba2ab07aa582aa7fba4450ea0e646466eb0577bf',
    'closure.json': '84c6667206bb2111d2f1cb0a8b3cc911e3e85b35f65b1a2bc307164fb7b4ac58',
    'report.json': '794927f693f6dba099c943d0e941a8ad24484fcc77a983f528f1cc872f4e7fa3',
    'post-guard-report.json': '08e0216e243c077bd56a830fd12fee01b19bc93eff3967e5ea68c329fc806ba4',
    'file-bindings.json': '31d58542974ae796d1a519fdbe3ceb00aec59a2f7475862885545d5bde22e817',
    'git-objects.json': '84508e8678a5d55de522692a1916aeed213610137b259d068a7df9132ae2cd39',
    'candidate04-build-proof.json': '3f483d613b334b453b96866e6b036c2afd1b1fbca83632d6959142330cde5286',
}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2) + '\n')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def parse_tree(data):
    result = {}
    for record in data.split(b'\0'):
        if not record:
            continue
        header, raw_path = record.split(b'\t', 1)
        mode, kind, oid = header.decode('ascii').split()
        path = raw_path.decode('utf-8')
        need(path not in result, 'duplicate tree path: ' + path)
        need(not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts,
             'unsafe tree path')
        result[path] = {'mode': mode, 'kind': kind, 'oid': oid}
    return result


def compare_tree(expected, actual):
    failures = []
    for path in sorted(set(expected) | set(actual)):
        if path not in expected:
            failures.append({'path': path, 'reason': 'unexpected tree path', 'actual': actual[path]})
        elif path not in actual:
            failures.append({'path': path, 'reason': 'missing tree path', 'expected': expected[path]})
        elif expected[path] != actual[path]:
            failures.append({'path': path, 'reason': 'mode/type/OID mismatch',
                             'expected': expected[path], 'actual': actual[path]})
    return failures


def load_authority(root):
    inputs = {}
    loaded = {}
    for name, expected in PINS.items():
        path = root / name
        need(path.is_file() and not path.is_symlink(), 'regular canonical input required')
        data = path.read_bytes()
        need(hashlib.sha256(data).hexdigest() == expected, 'canonical authority differs: ' + name)
        inputs[str(path)] = {'sha256': expected, 'bytes': len(data)}
        loaded[name] = json.loads(data)
    closure = loaded['closure.json']
    inventory_path = root / 'inventory.json'
    need(digest(inventory_path) == closure['inventorySha256'], 'canonical inventory differs')
    inputs[str(inventory_path)] = {'sha256': digest(inventory_path), 'bytes': inventory_path.stat().st_size}
    need(closure['sealed'] is True and closure['handoffSha256'] == PINS['handoff.json'],
         'canonical closure link differs')
    report, post, proof = loaded['report.json'], loaded['post-guard-report.json'], loaded['candidate04-build-proof.json']
    bindings = loaded['file-bindings.json']
    need(post['bindingReportSha256'] == PINS['report.json']
         and post['fileBindingsSha256'] == PINS['file-bindings.json']
         and post['buildProofSha256'] == PINS['candidate04-build-proof.json']
         and post['all437ProofShaEqualStagedBlobAndActualAndFrozenSnapshot'] is True,
         'authenticated proof post-guard link differs')
    need(proof['status'] == 'CLOSED' and proof['sourceStable'] is True and len(proof['sources']) == 437,
         'candidate04 proof differs')
    need(len(bindings) == 76302, 'canonical unique file count differs')
    need(sum('candidate04-declared-source' in row['categories'] for row in bindings.values()) == 437,
         'canonical source count differs')
    need(sum(any(c.startswith('fixture-') for c in row['categories']) for row in bindings.values()) == 75863,
         'canonical fixture count differs')
    for rel, expected in proof['sources'].items():
        row = bindings[rel]
        need(row['gitBlobSha256'] == row['filesystemSha256'] == expected
             and row['candidate04SnapshotBytesEqualStagedBlob'] is True,
             'source proof/staged blob SHA differs: ' + rel)
    return bindings, report, proof, inputs


def expected_trees(bindings, staged_report):
    main, external = {}, {}
    for path, row in bindings.items():
        need(row['stage'] == 0 and row['filesystemBytesEqualStagedBlob'] is True
             and row['gitBlobObjectHashVerified'] is True, 'unverified staged row')
        expected = {'mode': row['gitMode'], 'kind': 'blob', 'oid': row['gitBlob']}
        if row['repository'] == '.':
            main[path] = expected
        else:
            need(row['repository'] == 'external/pkl' and path.startswith('external/pkl/'),
                 'unexpected foreign repository')
            external[row['repositoryRelative']] = expected
    for path, row in staged_report['gitlinks'].items():
        main[path] = {'mode': row['mode'], 'kind': 'commit', 'oid': row['oid']}
    need(len(external) == 21, 'external source count differs')
    return main, external


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('commit', help='Actual full 40-hex implementation commit; no default or guessed commit')
    parser.add_argument('--output', type=Path, required=True, help='Fresh directory under REPO/target/m2')
    parser.add_argument('--repo', type=Path, default=ROOT)
    parser.add_argument('--binding-root', type=Path,
                        default=ROOT / 'target/m2/stage51-candidate04-staged-binding-01')
    args = parser.parse_args(argv)
    need(re.fullmatch(r'[0-9a-f]{40}', args.commit) is not None, 'full literal commit OID required')
    repo, evidence, out = args.repo.resolve(), args.binding_root.resolve(), args.output.resolve()
    need(out.is_relative_to(repo / 'target/m2') and not out.is_relative_to(evidence),
         'output must be a separate fresh target/m2 directory')
    out.mkdir(parents=True, exist_ok=False)
    git = Path(shutil.which('git')).resolve()
    environment = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}
    report = {'schema': 1, 'status': 'RUNNING-real-commit-tree-binding', 'requestedCommit': args.commit,
              'repo': str(repo), 'bindingRoot': str(evidence), 'startedUtc': now(), 'commands': [],
              'blobBytesRereadByThisVerification': False, 'priorBlobByteVerificationAuthenticated': False,
              'gitIndexWrites': False, 'engineExecutions': 0, 'complete': False}
    inputs = {}

    def execute(label, arguments, cwd=repo):
        command = [str(git), '-c', 'gc.auto=0', *arguments]
        row = {'argv': command, 'cwd': str(cwd), 'parentPid': os.getpid(), 'startedUtc': now(),
               'environmentOverrides': {'GIT_OPTIONAL_LOCKS': '0'}}
        with (out / (label + '.stdout.bin')).open('wb') as stdout, \
                (out / (label + '.stderr.bin')).open('wb') as stderr:
            child = subprocess.Popen(command, cwd=cwd, env=environment, stdout=stdout, stderr=stderr)
            row['pid'] = child.pid
            save(out / (label + '.launch.json'), row)
            row['exitCode'] = child.wait()
        row.update(finishedUtc=now(), stdoutSha256=digest(out / (label + '.stdout.bin')),
                   stderrSha256=digest(out / (label + '.stderr.bin')))
        save(out / (label + '.terminal.json'), row)
        report['commands'].append(row)
        need(row['exitCode'] == 0, 'Git metadata read failed: ' + label)
        return (out / (label + '.stdout.bin')).read_bytes()

    try:
        bindings, staged, proof, inputs = load_authority(evidence)
        for path in [Path(__file__).resolve(), git, Path(sys.executable).resolve()]:
            inputs[str(path)] = {'sha256': digest(path), 'bytes': path.stat().st_size}
        save(out / 'inputs-before.json', inputs)
        report.update(gitExecutable=str(git), gitExecutableSha256=digest(git), python=sys.version,
                      pythonExecutable=str(Path(sys.executable).resolve()), host=platform.platform(),
                      priorBlobByteVerificationAuthenticated=True,
                      stagedBindingTableSha256=PINS['file-bindings.json'],
                      proofPostGuardSha256=PINS['post-guard-report.json'],
                      candidate04ProofSha256=PINS['candidate04-build-proof.json'])
        report['gitVersion'] = execute('git-version', ['version', '--build-options']).decode('utf-8')
        resolved = execute('resolve-actual-commit', ['rev-parse', '--verify', args.commit + '^{commit}']).decode().strip()
        need(resolved == args.commit, 'argument must name the actual commit object, not a tag/ref')
        need(execute('actual-commit-type', ['cat-file', '-t', args.commit]) == b'commit\n',
             'requested object is not a commit')
        main_expected, external_expected = expected_trees(bindings, staged)
        pathspecs = sorted(p for p in main_expected if not p.startswith(FIXTURE + '/')) + [FIXTURE]
        main_actual = parse_tree(execute('main-commit-tree', ['ls-tree', '-r', '-z', args.commit, '--', *pathspecs]))
        failures = compare_tree(main_expected, main_actual)
        link = main_actual.get('external/pkl')
        expected_link = main_expected['external/pkl']
        if link == expected_link:
            foreign = parse_tree(execute('pkl-pinned-tree', ['ls-tree', '-r', '-z', link['oid'], '--',
                                                          *sorted(external_expected)], repo / 'external/pkl'))
            failures.extend({'repository': 'external/pkl', **f}
                            for f in compare_tree(external_expected, foreign))
        else:
            failures.append({'path': 'external/pkl', 'reason': 'submodule source tree not joined: gitlink mismatch'})
        report.update(actualCommit=args.commit, filesCompared=len(bindings), mainFilePaths=76281,
                      externalFilePaths=21, candidate04SourcePaths=437, fixtureFiles=75863,
                      fixturePayloads=75862, fixtureManifestFiles=1, executedToolPaths=5,
                      transitiveHelperPaths=2, dependencyManifestPaths=2, relatedTestPaths=4,
                      stagedGitlinks=staged['gitlinks'], commitTreeMismatches=failures,
                      exactPathModeOidMatched=not failures, complete=True,
                      qualification='This joins authenticated staged OIDs/modes/paths to the supplied actual commit. '
                                    'Earlier evidence verified blob bytes; this run reads only commit/tree metadata. '
                                    'Historical candidates and PLAN/docs are outside scope. No compatibility or evaluator claim.')
    except Exception as error:
        report['infrastructureError'] = repr(error)
        report['exactPathModeOidMatched'] = False
    finally:
        changes = [name for name, row in inputs.items()
                   if not Path(name).is_file() or digest(Path(name)) != row['sha256']
                   or Path(name).stat().st_size != row['bytes']]
        report.update(inputChanges=changes, finishedUtc=now())
        report['passed'] = report.get('complete', False) and report.get('exactPathModeOidMatched', False) and not changes
        report['status'] = 'CLOSED-actual-commit-binding-pass' if report['passed'] else 'CLOSED-actual-commit-binding-failed'
        save(out / 'inputs-after.json', {name: {'sha256': digest(Path(name)), 'bytes': Path(name).stat().st_size}
                                         for name in inputs if Path(name).is_file()})
        save(out / 'report.json', report)
    print(json.dumps({k: report.get(k) for k in ['status', 'actualCommit', 'filesCompared', 'candidate04SourcePaths',
                                               'fixtureFiles', 'exactPathModeOidMatched', 'inputChanges']}))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
