"""Protocol-only metadata join tests; no Git/evaluator/guessed commit execution."""
import importlib.util
from pathlib import Path
import unittest
P=Path(__file__).with_name('verify.py');spec=importlib.util.spec_from_file_location('commit_binding',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class TreeJoinTests(unittest.TestCase):
 def test_nul_tree_paths_keep_unicode_and_newline(self):
  raw=('100644 blob '+'a'*40+'\tname\n日本語.bin\0').encode();self.assertEqual(m.parse_tree(raw)['name\n日本語.bin']['oid'],'a'*40)
 def test_duplicate_path_rejected(self):
  raw=('100644 blob '+'a'*40+'\tx\0').encode()
  with self.assertRaisesRegex(ValueError,'duplicate'):m.parse_tree(raw+raw)
 def test_exact_mode_kind_oid_and_coverage(self):
  expected={'x':{'mode':'100644','kind':'blob','oid':'a'*40}}
  self.assertEqual(m.compare_tree(expected,expected),[])
  actual={'x':{'mode':'100755','kind':'blob','oid':'b'*40},'extra':{'mode':'100644','kind':'blob','oid':'c'*40}}
  self.assertEqual({x['reason']for x in m.compare_tree(expected,actual)},{'mode/type/OID mismatch','unexpected tree path'})
  self.assertEqual(m.compare_tree(expected,{})[0]['reason'],'missing tree path')
 def test_submodule_staged_tree_is_not_main_blob(self):
  bindings={'x':{'stage':0,'filesystemBytesEqualStagedBlob':True,'gitBlobObjectHashVerified':True,'gitMode':'100644','gitBlob':'a'*40,'repository':'.'}}
  for i in range(21):bindings[f'external/pkl/{i}']={'stage':0,'filesystemBytesEqualStagedBlob':True,'gitBlobObjectHashVerified':True,'gitMode':'100644','gitBlob':'b'*40,'repository':'external/pkl','repositoryRelative':str(i)}
  main,sub=m.expected_trees(bindings,{'gitlinks':{'external/pkl':{'mode':'160000','oid':'c'*40}}})
  self.assertEqual(main['external/pkl']['kind'],'commit');self.assertEqual(len(sub),21);self.assertNotIn('external/pkl/0',main)
if __name__=='__main__':unittest.main(verbosity=2)
