# 실제 implementation commit 후행 연결 도구

verify.py는 실제40자리 implementation commit 인자를 필수로 받는다. 추정commit/HEAD를 기본값으로 실행하지 않는다. 이번 준비에서는 실제commit에 대해 실행하지 않았다.4개 protocol metadata 테스트 및 --help만 실행했고 Git/평가를 실행하지 않았다.

기존 봉인 staged binding table/hash와 authenticated postguard/proof를 literal SHA로 인증한다. 전체76,302개 파일의 경로/mode/OID를 commit ls-tree와 대조한다. 외부pkl21개는 해당commit의 변하지 않은 gitlink 및 pinned submodule tree를 통해 연결한다. fixture prefix와 그밖의 선택된 exact paths만 조회하며 repo전체 tree를 요청하지 않는다.

기존 evidence가 blob원시bytes/객체hash를 검증했다. 후행 도구는 이를 인증해재사용하고 blob bytes를 Git에서 다시읽지 않는다. commit/tree metadata만 읽는다. 현재파일76k를 다시읽거나 생산평가를 재실행하지 않는다. staged상태나HEAD내용을새commit이라고주장하지않는다. historysource 및 PLAN/docs는 범위밖이다.

Root 실행 예시(실제commit 생성뒤 인자대체):

python3 -B target/m2/stage51-commit-binding-preparation-01/verify.py ACTUAL_IMPLEMENTATION_COMMIT --output target/m2/stage51-commit-binding-actual-01

필요하면 --repo 및 --binding-root를 명시한다. 후자는 같은 literal인증을 통과해야한다. output은 새 REPO/target/m2 디렉터리만 허용한다. Git/index/source 쓰기나 network는 없으며 원시git응답/명령/PID/runtime/종료기록과 compact report를 출력한다. Input proof/table bytes의 후행hash도 검사한다. Root가 실제commit 실행결과를 별도게시한다.
