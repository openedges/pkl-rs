import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys

root = Path.cwd()
out = root / 'target/m2/stage51-publication-closeout-01'
gather = out / 'payload'
gather.mkdir()
selected = []
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, d):
    p.write_text(json.dumps(d, indent=2) + '\n')
def copy(p, dest):
    assert stat.S_ISREG(p.lstat().st_mode), p
    before = sha(p)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(p, dest)
    assert sha(dest) == before == sha(p)
    selected.append({'source': str(p), 'member': str(dest.relative_to(gather)), 'bytes': p.stat().st_size,
                     'sha256': before, 'mode': stat.S_IMODE(p.stat().st_mode)})

receipt = {'implementationCommit': 'f5d1f7a51a61e3a6922962fe51b930f49423a09d',
           'commit': {'session': 34181, 'exitCode': 0, 'chunk': '94fffd'},
           'commitBinding': {'session': 2144, 'exitCode': 0, 'chunk': 'eb3ad7'},
           'push': {'session': 70363, 'exitCode': 0, 'chunk': 'bb4f7c'},
           'qualification': 'Root observations recorded after actual tool termination; receipt creation time is not process exit time.'}
save(gather / 'actual-root-terminals.json', receipt)
for name in ['stage51-commit-binding-preparation-01', 'stage51-commit-binding-actual-01',
             'stage51-published-index-c-review-01', 'stage51-publication-git-01']:
    directory = root / 'target/m2' / name
    for p in sorted(directory.rglob('*')):
        if p.is_dir():
            continue
        copy(p, gather / name / p.relative_to(directory))
# Only direct publication worker records; its metadata payload is already archived.
directory = root / 'target/m2/stage51-publication-02'
for p in sorted(directory.iterdir()):
    if p.is_file():
        copy(p, gather / directory.name / p.name)
copy(root / 'target/m2/stage51-publication-draft-02/mapping-verification.json', gather / 'producer-record-mapping.json')
copy(Path(__file__), gather / 'publication-closeout.py')
copy(root / 'tools/evidence.py', gather / 'evidence.py')
save(gather / 'selection.json', selected)
archive = root / 'reports/m2/stage51-source-binding-evidence.tar.gz'
assert not archive.exists()
for action, source in [('create', [str(gather), str(archive)]), ('verify', [str(archive)])]:
    argv = [sys.executable, '-B', str(root / 'tools/evidence.py'), action, *source]
    with (out / (action + '.stdout.bin')).open('wb') as so, (out / (action + '.stderr.bin')).open('wb') as se:
        result = subprocess.run(argv, stdout=so, stderr=se)
    save(out / (action + '.json'), {'argv': argv, 'exitCode': result.returncode})
    assert result.returncode == 0

actual = json.loads((root / 'target/m2/stage51-commit-binding-actual-01/report.json').read_text())
assert actual['passed'] and actual['exactPathModeOidMatched'] and not actual['inputChanges']
assert actual['actualCommit'] == receipt['implementationCommit']
assert json.loads((root / 'target/m2/stage51-publication-git-01/push.json').read_text())['exitCode'] == 0
report = {k: v for k, v in actual.items() if k != 'commands'}
report.update(scope='Postcommit source binding for the Stage51 candidate04 implementation and fixture authority. No new evaluator or compatibility result.',
              evidenceArchive={'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                               'actualBindingReportMember': 'stage51-commit-binding-actual-01/report.json',
                               'createExitCode': 0, 'separateVerifyExitCode': 0},
              originalCaptureIndex={'path': 'stage51-implementation-captures.json',
                                    'sha256': sha(root / 'reports/m2/stage51-implementation-captures.json')},
              originalCheckpoint='stage51-implementation-checkpoint.json',
              originalCheckpointQualification='The original checkpoint and capture index retain their precommit observations unchanged. This later record completes the actual commit join.',
              actualRootTerminals=receipt, implementationPushedToOriginMain=True,
              fullM2Complete=False, hostedCiClaimed=False, performanceTargetClaimed=False)
save(root / 'reports/m2/stage51-implementation-source-binding.json', report)
p = root / 'reports/m2/README.md'
s = p.read_text()
old = 'This is precommit evidence: the observed base HEAD is not the implementation identity, and binding to the future implementation commit remains pending.'
new = ('That archive preserves the original precommit evidence. The subsequent '
       '[commit binding](stage51-implementation-source-binding.json) joins all 76,302 paths, modes and object IDs '
       'to implementation commit `f5d1f7a`, which was pushed to `origin/main`. The original checkpoint retains '
       'its precommit observations; the later binding completes that provenance step.')
assert old in s
p.write_text(s.replace(old, new, 1))
p = root / 'PLAN.md'
s = p.read_text()
old = '대조한 기록도 유지하며, 실제 구현 커밋과의 연결은 커밋 후 별도로 확인합니다.'
new = ('대조한 기록도 유지합니다. [실제 커밋 대조](reports/m2/stage51-implementation-source-binding.json)에서 '
       '모든 경로·mode·OID가 구현 커밋 `f5d1f7a`와 일치했고 `origin/main`에 푸시했습니다. '
       '원래 검증 기록의 커밋 전 관찰은 그대로 보존합니다.')
assert old in s
p.write_text(s.replace(old, new, 1))
save(out / 'report.json', {'complete': True, 'sourceBindingReportSha256': sha(root / 'reports/m2/stage51-implementation-source-binding.json'),
                          'archiveSha256': sha(archive), 'archiveBytes': archive.stat().st_size,
                          'originalSelectedFilesUnchanged': all(sha(Path(x['source'])) == x['sha256'] for x in selected)})
print(json.dumps({'sourceCommit': actual['actualCommit'], 'sourceFiles': actual['filesCompared'],
                  'archiveBytes': archive.stat().st_size, 'complete': True}))
