from pathlib import Path
import hashlib,json,stat,datetime
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51')
OUT=Path(__file__).parent
inputs={}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def read(p):
 inputs[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
 return json.loads(p.read_text())
def nodes(x):
 yield x
 if isinstance(x,dict):
  for v in x.values():yield from nodes(v)
 elif isinstance(x,list):
  for v in x:yield from nodes(v)
c=read(ROOT/'reports/m2/stage51-implementation-captures.json')
k=read(ROOT/'reports/m2/stage51-implementation-checkpoint.json')
pub=read(ROOT/'target/m2/stage51-publication-02/report.json')
t=read(ROOT/'target/m2/stage51-publication-02/actual-terminal.json')
assert t['actualExitCode']==0 and t['actualChunk']=='a999d5'
assert pub['complete'] and pub['sourceIndexFilesUnchanged']
assert inputs[str(ROOT/'reports/m2/stage51-implementation-captures.json')]['sha256']==pub['captureManifestSha256']
assert len(c['archives'])==c['archiveCount']==27
rows=[]; indices={}
for a in c['archives']:
 f=ROOT/a['path']; actual={'sha256':sha(f),'bytes':f.stat().st_size}
 assert actual=={v:a[v] for v in ['sha256','bytes']},a['path']
 assert actual['bytes']<100_000_000
 if 'originalPath' in a:
  original=Path(a['originalPath']);assert sha(original)==a['sha256'] and original.stat().st_size==a['bytes']
  assert stat.S_IMODE(original.stat().st_mode)==a['originalMode']
  indexPath=ROOT/'target/m2'/a['preparationIndex']
  if str(indexPath) not in indices:indices[str(indexPath)]=read(indexPath)
  record=a['originalPreparationRecord']
  assert record in list(nodes(indices[str(indexPath)])),a['preparationIndex']
  assert record['path']==a['originalPath'] and record['sha256']==a['sha256']
  assert record.get('compressedBytes',record.get('bytes'))==a['bytes']
 rows.append({'path':a['path'],**actual,'originalIndexJoined':'originalPath' in a})
assert sum(x['bytes'] for x in rows)==c['compressedBytes']==pub['compressedBytes']==127409783
b=read(ROOT/'target/m2/stage51-candidate04-staged-binding-publication-01/index.json')
table=ROOT/'target/m2/stage51-candidate04-staged-binding-01/file-bindings.json'
assert sha(table)==b['sourceBindingTableSha256']==c['sourceBinding']['fileBindingsSha256']=='31d58542974ae796d1a519fdbe3ceb00aec59a2f7475862885545d5bde22e817'
inputs[str(table)]={'sha256':sha(table),'bytes':table.stat().st_size}
assert b['originalChanges']==[]
assert c['sourceBinding']['files']==76302 and c['sourceBinding']['candidate04Sources']==437
assert c['fixtureAuthority']['filesIncludingManifest']==75863
assert c['fixtureAuthority']['manifestSha256']==k['java_fixture_authority']['manifest_sha256']=='a90cc8d0c409b03c783192f39cf265052e3efa48e0d9bc5f7d64818e57a2558d'
for target,row in k['candidate04_results']['per_target'].items():
 assert row['calls']==2108 and row['rawMatches']==2096 and row['ordinaryCompatible']==row['ordinaryRawMatches']==row['ordinary']==2000
 assert row['intent-not-reachedRawMatches']==96 and row['public-api-boundary']==12 and row['public-api-boundaryRawMatches']==0
 assert k['candidate04_results']['policy_per_target'][target]=={'requests':76,'denied':4,'readerSideEffectOnDenied':0}
assert k['candidate04_results']['strict_selected_contract_passed']==c['candidate04Results']['strictSelectedContractPassed']==False
assert not c['fullM2Complete'] and not k['full_m2_complete'] and not k['performance_target_claimed']
assert c['m1KnownRegexMismatchesEachTarget']==2
assert k['source_and_artifact_binding']['snapshot_source_files']==437
assert k['source_and_artifact_binding']['staged_binding']['file_bindings_sha256']==c['sourceBinding']['fileBindingsSha256']
originalChanges=[]
for p,r in inputs.items():
 if sha(Path(p))!=r['sha256']:originalChanges.append(p)
assert not originalChanges
report={'schema':1,'status':'CLOSED-bounded-published-index-review','scope':'Archive byte hashes/lengths and original preparation index joins, claim consistency and unchanged binding table. Prior sealed full member/raw/source audits reused; no tar or evaluator reruns.','archives':len(rows),'compressedBytes':sum(x['bytes'] for x in rows),'maximumArchiveBytes':max(x['bytes'] for x in rows),'originalArchivePreparationJoins':sum(x['originalIndexJoined'] for x in rows),'publicationMetadataArchive':'27th archive joined to actual publication report/capture manifest; no separate pre-existing preparation index','archiveRows':rows,'sourceBindingTableSha256':sha(table),'sourceBindingRows':76302,'candidateSources':437,'fixtureFiles':75863,'knownFailuresPreserved':{'postCloseEachTarget':12,'regexEachTarget':2,'intentNotReachedEachTarget':96},'currentImplementationCommitFromParentNotice':'f5d1f7a51a61e3a6922962fe51b930f49423a09d','commitQualification':'Published precommit checkpoint intentionally remains pending; parent separately reports actual closed commit binding. This bounded review does not re-run Git blob verification.','originalChanges':originalChanges,'blockers':[],'limitations':['No repeated tar/member/raw-object verification; prior closed audits remain authority.','Full M2, full selected regression, full Java administrative lifecycle and performance remain unproven.'],'inputRecords':inputs}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'archives':len(rows),'compressedBytes':report['compressedBytes'],'blockers':[]}))
