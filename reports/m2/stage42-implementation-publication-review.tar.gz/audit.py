from pathlib import Path
import hashlib,json,os,tarfile,datetime
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42');OUT=Path(__file__).resolve().parent;PUB=ROOT/'target/m2/stage42-implementation-publication-01'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(n,x):(OUT/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
index=read(ROOT/'reports/m2/stage42-implementation-captures.json');selection=read(PUB/'selection.json');pre=read(OUT/'preflight.json')
assert sha(PUB/'selection.json')==pre['publisherSelectionSha256'] and sha(PUB/'publish.py')==pre['publisherScriptSha256']
assert len(selection['source_roots'])==16 and len(selection['direct_original_files'])==8
excluded={ROOT/p for p in selection['exact_cache_exclusions_before_traversal']}
assert ROOT/'target/m2/stage42-owner-corrected-candidate-01/cargo-target' in excluded and ROOT/'target/m2/stage42-owner-corrected-candidate-01/workspace/target' in excluded
expected={};rootCounts=[];visited=[]
for name in selection['source_roots']:
 base=ROOT/name;assert base not in excluded and not base.is_symlink();count=0
 for current,dirs,files in os.walk(base,followlinks=False):
  current=Path(current);assert not any(current==e or e in current.parents for e in excluded);visited.append(str(current.relative_to(ROOT)))
  dirs[:]=[d for d in dirs if current/d not in excluded]
  assert not any((current/d).is_symlink() for d in dirs)
  for n in files:
   p=current/n
   if p in excluded:continue
   assert p.is_file() and not p.is_symlink(),p
   expected[str(p.relative_to(ROOT))]={'bytes':p.stat().st_size,'sha256':sha(p)};count+=1
 rootCounts.append({'path':name,'currentRegularFiles':count})
for name in selection['direct_original_files']:
 p=ROOT/name;assert p.is_file() and not p.is_symlink();expected[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
assert rootCounts==pre['sourceRoots'] and len(expected)==pre['totalRegularFilesObserved']
before=read(PUB/'inputs.before.json');after=read(PUB/'inputs.after.json');assert expected==before==after
archived={};archives=[];duplicates=[];nested=0
for row in index['archives']:
 p=ROOT/row['path'];assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'];payload={};evidence=None
 with tarfile.open(p,'r|gz') as tar:
  for member in tar:
   assert member.isfile() and member.mode==0o644
   data=tar.extractfile(member).read()
   if member.name=='EVIDENCE.json':assert evidence is None;evidence=json.loads(data);continue
   name=member.name;assert name not in payload
   v={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()};assert expected.get(name)==v,(name,'original mismatch')
   payload[name]=v
   if name in archived:duplicates.append(name)
   archived[name]=v
   if Path(name).name in ('closure.json','inventory.json'):nested+=1
 inv={x['path']:{'bytes':x['bytes'],'sha256':x['sha256']} for x in evidence['files']};assert len(inv)==len(evidence['files']) and inv==payload
 assert len(payload)==row['payload_files'] and sum(x['bytes'] for x in payload.values())==row['uncompressed_payload_bytes'] and row['verification']['exit_code']==0
 archives.append({'path':row['path'],'sha256':row['sha256'],'compressedBytes':row['bytes'],'payloadFiles':len(payload),'payloadBytes':sum(x['bytes'] for x in payload.values())})
assert not duplicates and archived==expected
assert index['source_roots']==selection['source_roots'] and index['direct_original_files']==selection['direct_original_files'] and index['source_changes_during_publication']==[] and index['full_m2_complete'] is False
assert not any(n.startswith('target/m2/stage43-') for n in archived)
# Supplemental original wrapper closure postdates A's24-file audit; all original and supplemental paths included.
wrapper='target/m2/stage42-full-regression-01/'
assert wrapper+'closure.json' in archived and wrapper+'inventory.json' in archived
report={'status':'PASS_EXACT_UNION','reviewedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':selection['scope'],'index':{'path':'reports/m2/stage42-implementation-captures.json','sha256':sha(ROOT/'reports/m2/stage42-implementation-captures.json')},'archives':archives,'archiveCount':len(archives),'summedPayloadFiles':sum(x['payloadFiles'] for x in archives),'uniquePayloadFiles':len(archived),'duplicatePaths':duplicates,'totalPayloadBytes':sum(x['bytes'] for x in archived.values()),'compressedBytes':sum(x['compressedBytes'] for x in archives),'allSelectedRootsAndDirectFilesCovered':True,'roots':rootCounts,'directFiles':selection['direct_original_files'],'actualNestedInventoryOrClosureFilesIncluded':nested,'allCurrentOriginalsEqualPublicationBeforeAndAfterMaps':True,'preflightSelectionAndScriptUnchanged':True,'exactExclusionsBeforeTraversal':selection['exact_cache_exclusions_before_traversal'],'omittedLiveOrManagedRoots':selection['omitted_live_or_managed_roots'],'historicalScope':selection['historical_inventory_scope'],'canonicalModes':'All tar payloads0644, bytes/hash/membership preserved; executable modes not claimed.','recordedVerifyCommands':'Every archived evidence.py verify recorded exit0; independently decoded all tar members and internal inventories here without rerunning tool/runtime suites.','claimsNotMade':['Corrected fullselected rerun','OldheldReference regression erased','Stage43 results','M2 completion','Wholeconfiguration equivalence for copy missing CIworkflow','New evaluation/test execution by this review'],'runtimeBuildJavaReruns':0}
write('union-inventory.json',archived);write('report.json',report)
print(json.dumps({'status':'PASS','archives':len(archives),'payloadFiles':len(archived),'payloadBytes':report['totalPayloadBytes'],'reportSha256':sha(OUT/'report.json')}))
