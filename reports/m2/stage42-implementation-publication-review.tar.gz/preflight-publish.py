"""Publish completed Stage42 captures without traversing Cargo caches."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BASE = ROOT / 'target/m2'
SELECTION = OUT / 'selection.json'


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def enumerate_root(path, excluded):
    result = []
    for current, dirs, files in os.walk(path):
        current = Path(current)
        dirs[:] = sorted(d for d in dirs if (current / d) not in excluded)
        if any((current / d).is_symlink() for d in dirs):
            raise ValueError(f'Unexpected directory symlink in {current}')
        for name in sorted(files):
            item = current / name
            if item in excluded:
                continue
            if item.is_symlink() or not item.is_file():
                raise ValueError(f'Non-regular evidence: {item}')
            result.append(item)
    return result


selection = json.loads(SELECTION.read_bytes())
excluded = {ROOT / name for name in selection['exact_cache_exclusions_before_traversal']}
groups = []
for name in selection['source_roots']:
    path = ROOT / name
    if path in excluded:
        raise ValueError('Cache cannot be selected')
    files = enumerate_root(path, excluded)
    groups.append((name, files))
for name in selection['direct_original_files']:
    path = ROOT / name
    if not path.is_file() or path.is_symlink():
        raise ValueError(f'Missing regular direct input: {path}')
    groups.append((name, [path]))

paths = sorted({p for _, files in groups for p in files})
before = {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths}
(OUT / 'inputs.before.json').write_bytes(encoded(before))

shards = []
current = []
size = 0
for name, files in groups:
    amount = sum(before[str(p.relative_to(ROOT))]['bytes'] for p in files)
    if current and size + amount > 150_000_000:
        shards.append(current)
        current, size = [], 0
    current.extend(files)
    size += amount
if current:
    shards.append(current)

archives = []
for index, files in enumerate(shards, 1):
    files = sorted(set(files))
    destination = ROOT / f'reports/m2/stage42-implementation-captures-{index:02}.tar.gz'
    if destination.exists():
        raise ValueError(f'Refusing evidence overwrite: {destination}')
    rows = [dict(path=str(p.relative_to(ROOT)), **before[str(p.relative_to(ROOT))]) for p in files]
    inventory = encoded({'schema_version': 1, 'excluded_patterns': [], 'files': rows})
    with destination.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as archive:
            for path in files:
                name = str(path.relative_to(ROOT))
                data = path.read_bytes()
                if hashlib.sha256(data).hexdigest() != before[name]['sha256']:
                    raise ValueError(f'Input changed during publication: {name}')
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(data), 0o644, 0
                archive.addfile(member, io.BytesIO(data))
            member = tarfile.TarInfo('EVIDENCE.json')
            member.size, member.mode, member.mtime = len(inventory), 0o644, 0
            archive.addfile(member, io.BytesIO(inventory))
    command = [sys.executable, 'tools/evidence.py', 'verify', str(destination.relative_to(ROOT))]
    result = subprocess.run(command, cwd=ROOT, capture_output=True)
    (OUT / f'verify-{index:02}.stdout.bin').write_bytes(result.stdout)
    (OUT / f'verify-{index:02}.stderr.bin').write_bytes(result.stderr)
    if result.returncode:
        raise ValueError(f'Archive integrity failed: {destination}')
    archives.append(dict(path=str(destination.relative_to(ROOT)), bytes=destination.stat().st_size,
                         sha256=sha(destination), payload_files=len(rows),
                         uncompressed_payload_bytes=sum(r['bytes'] for r in rows),
                         verification=dict(command=command, exit_code=result.returncode,
                                           stdout_hex=result.stdout.hex(), stderr_hex=result.stderr.hex())))
    print(f'{destination.name}: {len(rows)} files, {destination.stat().st_size} bytes', flush=True)

after = {str(p.relative_to(ROOT)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in paths}
(OUT / 'inputs.after.json').write_bytes(encoded(after))
changes = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
if changes:
    raise ValueError(f'Publication input changes: {changes}')
report = dict(schema=1, scope=selection['scope'], full_m2_complete=False, archives=archives,
              archive_integrity_exit=0, source_roots=selection['source_roots'],
              direct_original_files=selection['direct_original_files'],
              exact_cache_exclusions_before_traversal=selection['exact_cache_exclusions_before_traversal'],
              omitted_live_or_managed_roots=selection['omitted_live_or_managed_roots'],
              source_changes_during_publication=changes,
              historical_inventory_scope=selection['historical_inventory_scope'])
destination = ROOT / 'reports/m2/stage42-implementation-captures.json'
if destination.exists():
    raise ValueError('Refusing index overwrite')
destination.write_bytes(encoded(report))
(OUT / 'report.json').write_bytes(encoded(report))
print('Publication complete; full M2 remains incomplete.', flush=True)
