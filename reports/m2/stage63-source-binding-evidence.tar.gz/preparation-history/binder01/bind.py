"""Bind recorded Stage63 sources to an explicit future implementation B commit.

No build, evaluator, comparison, publication or Git mutation is performed.
Historical platform01 and failed comparison01 remain historical evidence.
Real original publication/assembly process logs are included in the C archive.
Run only after B and the root-approved six-archive layout guard exist.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

if not __debug__:
    raise RuntimeError('Run this integrity audit without Python -O; assertions are required')

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'target/m2/stage63-source-binding-01'
PUBLIC = OUT / 'stage63-source-binding.json'
ARCHIVE = OUT / 'stage63-source-binding-evidence.tar.gz'
BASE = 'b3664d84ce0f3b5a45daf46981c5c9f30acf5e3e'
HISTORICAL_BASE_DOCS = {'PLAN.md', 'TESTING.md', 'docs/m2-language.md'}
PIN = {'external/pkl': 'e51fb2f91774265666f94980ec630db794a4db2d',
       'external/pkl-pantry': '904a68184e54da378b0a0e8a911a3fab3956f693'}
RUST = 'target/m2/stage63-rust-validation-01'
BUILD = 'target/m2/stage63-native-build-01'
COHORT = 'target/m2/stage63-native-acquisition-01'
M1 = 'target/m2/stage63-m1-platform-contract-02'
PLATFORM = 'target/m2/stage63-platform-validation-02'
HISTORY_M1 = 'target/m2/stage63-m1-platform-contract-01'
HISTORY_PLATFORM = 'target/m2/stage63-platform-validation-01'
HISTORY_COMPARE = 'target/m2/stage63-comparison-validation-01'
ORIGINAL = 'target/m2/stage63-original-addition-01'
COMPARE = 'target/m2/stage63-comparison-validation-02'
TOOL = 'target/m2/stage63-tool-development-02'
DATA_SIZE = 'target/m2/stage63-data-size-native-regression-01'
CAPTURE_PREPARATION = 'target/m2/stage63-capture-preparation-01'
CAPTURE_PREPARATION_SHA = '6f7d656d05d606f9f9a82805c52ea8885634cd429494ee8255f0c77dbea83946'
FREEZE = 'target/m2/stage63-core-freeze-01'
PUBLISHER = 'target/m2/stage63-publication-01'
PUBLISHER_LAYOUT_SHA = '24fd8a950e926678a10f7ccb6131c2704d91a5a4029d1477698dd69f5694d5e5'
PUBLICATION_EXECUTION = 'target/m2/stage63-publication-execution-01'
PUBLICATION_REVIEW = 'target/m2/stage63-publication-review-01'
PROFILE_ROWS = {'collection-conversions': 236, 'collection-conversion-controls': 58,
                'collection-lookups': 133, 'collection-default-contracts': 22,
                'collection-dynamic-render': 10, 'collection-property-names': 26,
                'collection-addition': 125, 'set-endpoints': 70}
NATIVE_CAPTURES = {
    **{name: (f'target/m2/stage63-{name}-native-comparison-01',
              f'tests/fixtures/m2-{name}', rows) for name, rows in PROFILE_ROWS.items()},
    'intseq': ('target/m2/stage63-intseq-native-comparison-01', 'tests/fixtures/m2-int-seq-values', 237),
    'bytes': ('target/m2/stage63-bytes-native-regression-01', 'tests/fixtures/m2-bytes-values', 300),
    'duration': ('target/m2/stage63-duration-native-regression-01', 'tests/fixtures/m2-duration-values', 274),
}
PORTABLE_CAPTURES = {
    **{name: (f'target/m2/stage63-{name}-portable-capture-02', rows)
       for name, rows in PROFILE_ROWS.items()},
    **{name: (f'target/m2/stage63-{name}-portable-capture-02', rows)
       for name, rows in [('int-seq-values', 237), ('bytes-values', 300),
                          ('duration-values', 274), ('any-if-non-null', 86), ('data-size', 255)]},
}
# These exact four capture-specific B proofs remain explicit even though the
# Stage63 wrapper now includes all four in its complete declared source closure.
PORTABLE_CAPTURE_SPECIFIC_SOURCES = {
    'any-if-non-null': {'tools/java/AnyIfNonNullOracle.java',
                       'tools/tests/test_any_if_non_null_fixtures.py',
                       'tools/tests/test_any_if_non_null_portable_compare.py'},
    'data-size': {'tools/java/DataSizeSplitOracle.java'},
}
MANIFESTS = {'rust_validation': RUST + '/sources.json', 'native_build': BUILD + '/source-before.json',
             'native_cohort': COHORT + '/cohort-before.json', 'm1_platforms': M1 + '/sources.json',
             'platform_wrapper': PLATFORM + '/source-before.json',
             'original_addition': ORIGINAL + '/sources.json',
             'comparison_wrapper': COMPARE + '/source-before.json',
             'tool_validation': TOOL + '/report.json',
             'data_size_regression': DATA_SIZE + '/source-before.json',
             'historical_m1_platforms': HISTORY_M1 + '/sources.json',
             'historical_platform_wrapper': HISTORY_PLATFORM + '/source-before.json',
             'failed_comparison_snapshot': HISTORY_COMPARE + '/source-before.json'}
SOURCE_COPIES = {category: folder + '/sources' for category, folder in [
    ('native_build', BUILD), ('native_cohort', COHORT), ('m1_platforms', M1),
    ('platform_wrapper', PLATFORM), ('original_addition', ORIGINAL),
    ('comparison_wrapper', COMPARE), ('tool_validation', TOOL), ('data_size_regression', DATA_SIZE),
    ('historical_m1_platforms', HISTORY_M1), ('historical_platform_wrapper', HISTORY_PLATFORM),
    ('failed_comparison_snapshot', HISTORY_COMPARE)]}
MANIFEST_FIELDS = {'tool_validation': 'source_before'}
FIXTURE_MANIFESTS = {}
ARCHIVED_COPIES = {
    'rust_validation': ('validation', RUST + '/sources/', 'captured-only'),
    **{category: (group, SOURCE_COPIES[category] + '/', 'all') for category, group in [
        ('native_build', 'native-regressions'), ('native_cohort', 'native-regressions'),
        ('m1_platforms', 'platform'), ('platform_wrapper', 'platform'),
        ('original_addition', 'closeout'), ('comparison_wrapper', 'closeout'),
        ('tool_validation', 'validation'), ('data_size_regression', 'native-regressions'),
        ('historical_m1_platforms', 'platform-history'),
        ('historical_platform_wrapper', 'platform-history'), ('failed_comparison_snapshot', 'closeout')]},
}
for capture_name, (folder, fixture, _) in NATIVE_CAPTURES.items():
    for part in ('build', 'tools', 'fixture'):
        category = 'native_' + capture_name.replace('-', '_') + '_' + part
        if part == 'build':
            MANIFESTS[category] = folder + '/build/source-before.json'
            SOURCE_COPIES[category] = folder + '/build/sources'
            mode = 'all'
        elif part == 'tools':
            MANIFESTS[category] = folder + '/report.json'
            MANIFEST_FIELDS[category] = 'tools_before'
            SOURCE_COPIES[category] = folder + '/tools'
            mode = 'flat'
        else:
            MANIFESTS[category] = folder + '/inventory.json'
            FIXTURE_MANIFESTS[category] = fixture
            SOURCE_COPIES[category] = folder + '/fixture'
            mode = 'strip:' + fixture + '/'
        group = 'native-collections' if capture_name in PROFILE_ROWS else 'native-regressions'
        ARCHIVED_COPIES[category] = (group, SOURCE_COPIES[category] + '/', mode)
GROUPS = ('validation', 'native-collections', 'native-regressions', 'platform-history', 'platform', 'closeout')
PUBLIC_ARCHIVES = {group: f'reports/m2/stage63-{group}-evidence.tar.gz' for group in GROUPS}
PUBLICATIONS = {group: f'reports/m2/stage63-{group}-publication.json' for group in GROUPS}
# Closed list of ignored execution inputs. A B source mismatch can never select
# one of these proofs; they apply only when that exact path is absent from B.
EXECUTION_INPUTS = {}
for group, folder, names in [
    ('validation', RUST, ('run.py', 'preparation.json')),
    ('validation', CAPTURE_PREPARATION, ('prepare.py', 'common.py', 'preparation.json', 'source-contracts.json')),
    ('validation', FREEZE, ('freeze.json', 'source-snapshot.json')),
    ('validation', TOOL, ('run.py', 'sitecustomize.py')),
    ('native-regressions', BUILD, ('run.py',)),
    ('native-regressions', COHORT, ('run.py',)),
    ('native-regressions', DATA_SIZE, ('run.py',)),
    ('native-regressions', 'target/m2/stage63-bytes-native-regression-launch-01', ('run.py',)),
    ('native-regressions', 'target/m2/stage63-duration-native-regression-launch-01', ('run.py',)),
    ('platform-history', HISTORY_PLATFORM, ('run.py',)),
    ('platform', PLATFORM, ('run.py', 'prepare.py', 'preparation.json')),
    ('closeout', HISTORY_COMPARE, ('run.py', 'prepare.py', 'preparation.json')),
    ('closeout', COMPARE, ('run.py', 'prepare.py', 'preparation.json')),
    ('closeout', 'target/m2/stage63-original-addition-prep-01', ('run.py',)),
    ('closeout', 'target/m2/stage63-original-addition-launch-01', ('run.py',)),
    ('closeout', 'target/m2/stage63-checkpoint-01', ('prepare.py',)),
    ('validation', PUBLISHER, ('publish.py', 'adapt.py', 'refine.py', 'layout.json', 'preparation.json')),
]:
    for name in names:
        relative = folder + '/' + name
        assert relative not in EXECUTION_INPUTS
        EXECUTION_INPUTS[relative] = (group, relative)
EXECUTION_PROOFS = []
ARCHIVE_CONTROL_MEMBERS = {
    'validation': [RUST + '/report.json', TOOL + '/report.json', FREEZE + '/freeze.json',
                   FREEZE + '/source-snapshot.json', CAPTURE_PREPARATION + '/preparation.json'],
    'native-collections': [],
    'native-regressions': [BUILD + '/build.json', BUILD + '/string_session_probe', BUILD + '/data_size_fixture_probe',
                           COHORT + '/report.json', COHORT + '/cohort-before.json', COHORT + '/cohort-after.json',
                           DATA_SIZE + '/report.json', DATA_SIZE + '/inventory.json',
                           *[f'target/m2/stage63-{name}-native-regression-launch-01/report.json' for name in ('bytes', 'duration')]],
    'platform': [M1 + '/report.json', PLATFORM + '/report.json',
                 *[folder + '/report.json' for folder, _ in PORTABLE_CAPTURES.values()]],
    'platform-history': [HISTORY_M1 + '/report.json', HISTORY_PLATFORM + '/report.json',
                         *[folder.replace('-capture-02', '-capture-01') + '/report.json'
                           for folder, _ in PORTABLE_CAPTURES.values()]],
    'closeout': [ORIGINAL + '/report.json', ORIGINAL + '/selection.json', COMPARE + '/report.json',
                 HISTORY_COMPARE + '/report.json', HISTORY_COMPARE + '/attempt.json',
                 'target/m2/stage63-original-addition-launch-01/report.json'],
}
for name, (folder, _, _) in NATIVE_CAPTURES.items():
    group = 'native-collections' if name in PROFILE_ROWS else 'native-regressions'
    ARCHIVE_CONTROL_MEMBERS[group].extend(folder + '/' + item for item in
        ('report.json', 'inventory.json', 'build/build.json', 'build/string_session_probe', 'build/data_size_fixture_probe'))
CHECKPOINT = 'reports/m2/stage63-implementation-checkpoint.json'


def raw_json(data):
    return (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()


def digest(path):
    h = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
            size += len(chunk)
    return {'sha256': h.hexdigest(), 'bytes': size}


def execute(*argv):
    proc = subprocess.run(argv, cwd=ROOT, capture_output=True)
    assert proc.returncode == 0, (argv, proc.returncode, proc.stderr[-1000:])
    return proc.stdout


def git_tree(repo, commit):
    result = {}
    for record in execute('git', '-C', str(repo), 'ls-tree', '-rz', '--full-tree', commit).split(b'\0'):
        if not record:
            continue
        head, path = record.split(b'\t', 1)
        mode, kind, oid = head.split(b' ')
        name = path.decode('utf-8', 'surrogateescape')
        assert name not in result
        result[name] = (mode.decode(), kind.decode(), oid.decode())
    return result


def logical(name):
    for repo in ('external/pkl-pantry', 'external/pkl'):
        if name.startswith(repo + '/'):
            return repo, name[len(repo) + 1:]
    return '.', name


def git_blobs(repo, oids):
    """Read each unique Git object once and validate its SHA-1 framing."""
    proc = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    result = {}
    try:
        for oid in sorted(oids):
            proc.stdin.write((oid + '\n').encode())
            proc.stdin.flush()
            header = proc.stdout.readline().strip().split(b' ')
            assert len(header) == 3 and header[0].decode() == oid and header[1] == b'blob', (oid, header)
            size = int(header[2])
            remaining = size
            git_hash = hashlib.sha1(b'blob ' + str(size).encode() + b'\0')
            content_hash = hashlib.sha256()
            while remaining:
                chunk = proc.stdout.read(min(1 << 20, remaining))
                assert chunk, (oid, remaining)
                git_hash.update(chunk)
                content_hash.update(chunk)
                remaining -= len(chunk)
            assert proc.stdout.read(1) == b'\n' and git_hash.hexdigest() == oid
            result[oid] = {'sha256': content_hash.hexdigest(), 'bytes': size}
        proc.stdin.close()
        assert proc.wait() == 0, proc.stderr.read()[-1000:]
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()
    return result


def blob_bytes(repo, oid, expected):
    raw = execute('git', '-C', str(repo), 'cat-file', 'blob', oid)
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid
    assert {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} == expected
    return raw


def expected_identity(value):
    if isinstance(value, str):
        return value, None
    assert isinstance(value, dict)
    return value['sha256'], value.get('bytes')


def archive_member_audit(archive_bytes, category, prefix, source_manifest, captured_only=False):
    seen = 0
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as stream:
        members = stream.getmembers()
        names = [member.name for member in members]
        assert len(names) == len(set(names)), 'duplicate evidence archive member'
        for name, value in source_manifest.items():
            if captured_only and value['origin']['kind'] != 'captured-file':
                continue
            entry = stream.getmember(prefix + copied_suffix(category, name))
            assert entry.isfile() and not entry.issym() and not entry.islnk(), entry.name
            raw = stream.extractfile(entry).read()
            sha, size = expected_identity(value)
            assert hashlib.sha256(raw).hexdigest() == sha and (size is None or len(raw) == size), entry.name
            seen += 1
    return seen


READ_IDENTITIES = {}


def read_json(relative):
    raw = (ROOT / relative).read_bytes()
    identity = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    if relative in READ_IDENTITIES:
        assert READ_IDENTITIES[relative] == identity, ('changed JSON evidence', relative)
    READ_IDENTITIES[relative] = identity
    return json.loads(raw)


def copied_suffix(category, name):
    mode = ARCHIVED_COPIES[category][2]
    if mode == 'flat':
        return PurePosixPath(name).name
    if mode.startswith('strip:'):
        prefix = mode.removeprefix('strip:')
        assert name.startswith(prefix), (category, name)
        return name.removeprefix(prefix)
    return name


def load_manifest(category, relative):
    values = read_json(relative)
    if category in MANIFEST_FIELDS:
        values = values[MANIFEST_FIELDS[category]]
    elif category in FIXTURE_MANIFESTS:
        prefix = FIXTURE_MANIFESTS[category] + '/'
        values = {prefix + name.removeprefix('fixture/'): item
                  for name, item in values.items() if name.startswith('fixture/')}
    assert isinstance(values, dict) and values, (category, relative)
    return values


def validate_final_records(manifests):
    """Cross-bind recorded build/capture inputs without running evaluators or verifiers."""
    rust = read_json(RUST + '/report.json')
    assert rust['complete'] is True and rust['changed_sources'] == []
    assert rust['base_commit'] == BASE and len(rust['commands']) == 5
    assert all(row['exit_code'] == 0 for row in rust['commands'])
    assert manifests['rust_validation'] == read_json(RUST + '/sources-after.json')
    assert len(manifests['rust_validation']) == rust['source_count'] == 165362
    assert rust['copied_source_files'] == 13
    for category, after in [('native_build', BUILD + '/source-after.json'),
                            ('native_cohort', COHORT + '/cohort-after.json'),
                            ('platform_wrapper', PLATFORM + '/source-after.json'),
                            ('comparison_wrapper', COMPARE + '/source-after.json'),
                            ('data_size_regression', DATA_SIZE + '/source-after.json')]:
        assert manifests[category] == read_json(after), category
    for relative in (BUILD + '/build.json', PLATFORM + '/report.json',
                     ORIGINAL + '/report.json', COMPARE + '/report.json', TOOL + '/report.json',
                     DATA_SIZE + '/report.json'):
        data = read_json(relative)
        assert data['complete'] is True, relative
        assert data.get('source_stable', data.get('source_stability')) is True, relative
    build = read_json(BUILD + '/build.json')
    assert build['exit_code'] == 0 and build['base_commit'] == BASE
    for name, item in build['artifacts'].items():
        assert digest(ROOT / BUILD / name) == item, name
    cohort = read_json(COHORT + '/report.json')
    assert cohort['complete'] is True and cohort['stable'] is True
    assert len(cohort['commands']) == len(NATIVE_CAPTURES) + 1
    assert all(row['exit_code'] == 0 for row in cohort['commands'])
    assert cohort['artifacts_before'] == cohort['artifacts_after'] == {
        name: digest(ROOT / name) for name in cohort['artifacts_before']}
    assert cohort['wrapper_before'] == cohort['wrapper_after'] == digest(ROOT / COHORT / 'run.py')
    native_controls = {}
    for name, (folder, fixture, rows) in NATIVE_CAPTURES.items():
        report = read_json(folder + '/report.json')
        assert report['complete'] is True and len(report['processes']) == 2, name
        assert report['comparison']['counts'] == {'pass': rows * 2}, name
        assert report['comparison']['strict_string_passed'] is True, name
        assert report['source_after'] == manifests['native_build'], name
        assert read_json(folder + '/build/source-before.json') == manifests['native_build']
        assert read_json(folder + '/build/source-after.json') == manifests['native_build']
        assert digest(ROOT / folder / 'build/build.json') == digest(ROOT / BUILD / 'build.json')
        for artifact, item in build['artifacts'].items():
            assert digest(ROOT / folder / 'build' / artifact) == item, (name, artifact)
        assert report['tools_before'] == report['tools_after']
        if name in PROFILE_ROWS:
            assert report['profile_uri'] == read_json(fixture + '/cases.json')['module_uri']
            assert all(manifests['native_cohort'].get(path) == item
                       for path, item in report['tools_before'].items()), name
        for process in report['processes']:
            assert process['exit_code'] == 0 and process['timed_out'] is False and process['launch_error'] is None
        native_controls[name] = {'path': folder + '/report.json', **digest(ROOT / folder / 'report.json'),
                                 'rows': rows, 'repetitions': 2,
                                 'counts': report['comparison']['counts']}
    for row in cohort['commands']:
        relative = str(Path(row['output']).relative_to(ROOT)) + '/report.json'
        assert row['output_report'] == digest(ROOT / relative), row['name']
    for name in ('bytes', 'duration'):
        relative = f'target/m2/stage63-{name}-native-regression-launch-01/report.json'
        launch = read_json(relative)
        assert launch['exit_code'] == 0 and launch['source_stable'] is True
        assert launch['source_before'] == launch['source_after']
        assert launch['output_report'] == digest(ROOT / NATIVE_CAPTURES[name][0] / 'report.json')
    data = read_json(DATA_SIZE + '/report.json')
    assert data['artifact_before'] == data['artifact_after'] == build['artifacts']['data_size_fixture_probe']
    assert data['build_report'] == digest(ROOT / BUILD / 'build.json')
    assert data['passed'] == 510 and data['mismatches'] == 0 and data['strict_string_passed'] is True
    assert data['fixture_before'] == data['fixture_after']
    m1 = read_json(M1 + '/report.json')
    assert manifests['m1_platforms'] == m1['source_hashes']
    assert m1['source_stability'] is True and m1['experiment_contract_status'] == 'pass'
    assert m1['total'] == m1['shared_engine_passed'] == 6078
    assert m1['oracle_passed'] == {'rust': 6076, 'node': 6076, 'browser': 6076}
    assert m1['compatibility_status'] == 'fail'
    wrapper = read_json(PLATFORM + '/report.json')
    command, = [item for item in wrapper['commands'] if item['name'] == 'm1-contract']
    assert command['exit_code'] == 0 and command['finished_epoch'] >= command['started_epoch']
    assert command['argv'] == ['python3', 'tools/m1_platforms.py', '--output', str(ROOT / M1), '--verify-contract']
    assert len(wrapper['commands']) == len(PORTABLE_CAPTURES) + 1
    assert all(row['exit_code'] == 0 for row in wrapper['commands'])
    portable_controls = {}
    capture_specific_observed = {}
    for name, (folder, rows) in PORTABLE_CAPTURES.items():
        report = read_json(folder + '/report.json')
        assert report['complete'] is True and report['orderedRows'] == rows and report['repetitions'] == 2
        assert report['inputsBefore'] == report['inputsAfter'] and report['fileSetsBefore'] == report['fileSetsAfter']
        assert report['infrastructureErrors'] == []
        assert set(report['targets']) == {'napi', 'chromium'}
        for folder_files in report['fileSetsBefore'].values():
            assert len(folder_files) == len(set(folder_files))
            assert all(path in report['inputsBefore'] for path in folder_files)
        binding = {'source_inputs': {}, 'capture_specific_source_inputs': {},
                   'built_artifacts': {}, 'recorded_external_runtime_inputs': {}}
        for absolute, sha in report['inputsBefore'].items():
            path = Path(absolute)
            assert path.is_absolute()
            if path.is_relative_to(ROOT):
                relative = path.relative_to(ROOT).as_posix()
                if relative.startswith(M1 + '/'):
                    assert digest(path)['sha256'] == sha
                    ARCHIVE_CONTROL_MEMBERS['platform'].append(relative)
                    binding['built_artifacts'][relative] = sha
                else:
                    assert relative in manifests['platform_wrapper'], (name, relative)
                    assert expected_identity(manifests['platform_wrapper'][relative])[0] == sha
                    binding['source_inputs'][relative] = sha
                    if relative in PORTABLE_CAPTURE_SPECIFIC_SOURCES.get(name, set()):
                        assert relative in manifests['comparison_wrapper'], (name, relative)
                        assert expected_identity(manifests['comparison_wrapper'][relative])[0] == sha
                        binding['capture_specific_source_inputs'][relative] = sha
                        capture_specific_observed.setdefault(name, set()).add(relative)
            else:
                # Recorded Node/Python/browser payloads are execution identities,
                # not implementation sources or newly checked installed runtimes.
                binding['recorded_external_runtime_inputs'][absolute] = sha
        portable_controls[name] = {'path': folder + '/report.json', **digest(ROOT / folder / 'report.json'),
                                   'rows': rows, 'binding': binding}
    assert capture_specific_observed == PORTABLE_CAPTURE_SPECIFIC_SOURCES
    comparison = read_json(COMPARE + '/report.json')
    assert comparison['source_snapshot_stable'] is True
    assert comparison['full_api_complete'] is False and comparison['full_m2_complete'] is False
    commands = comparison['commands']
    assert len(commands) == 25 and len({row['name'] for row in commands}) == 25
    for row in commands:
        assert row['exit_code'] == row['expected_exit_code'] == (1 if row['name'] == 'any-portable' else 0)
    expected_counts = {}
    for name, rows in {**PROFILE_ROWS, 'intseq': 237, 'bytes': 300, 'duration': 274, 'data-size': 255}.items():
        expected_counts[name + '-native'] = {'pass': rows * 2}
        expected_counts[name + '-portable'] = {target: {'pass': rows * 2} for target in ('napi', 'chromium')}
    expected_counts['any-portable'] = {target: {'pass': 170, 'mismatch': 2} for target in ('napi', 'chromium')}
    assert comparison['counts'] == expected_counts
    input_reports = {'m1': M1 + '/report.json', 'native_build': BUILD + '/build.json',
                     'platform_wrapper': PLATFORM + '/report.json', 'data_size_native': DATA_SIZE + '/report.json',
                     'native_acquisition': COHORT + '/report.json',
                     **{name + ('-native' if name in PROFILE_ROWS else '_native'): folder + '/report.json'
                        for name, (folder, _, _) in NATIVE_CAPTURES.items()},
                     **{name: folder + '/report.json' for name, (folder, _) in PORTABLE_CAPTURES.items()}}
    assert comparison['preflight']['input_reports'] == {name: digest(ROOT / path) for name, path in input_reports.items()}
    tool = read_json(TOOL + '/report.json')
    assert len(tool['checks']) == 7 and all(row['exit_code'] == 0 for row in tool['checks'])
    assert manifests['tool_validation'] == tool['source_after'] and tool['source_copies_match'] is True
    assert tool['actual_python_read_missing_from_snapshot'] == []
    assert len(manifests['tool_validation']) == tool['source_counts']['declared_and_copied'] == 6499
    original = read_json(ORIGINAL + '/report.json')
    selection = read_json(ORIGINAL + '/selection.json')
    assert len(original['results']) == len(selection['case_ids']) == len(set(selection['case_ids'])) == 91
    assert original['integrity_status'] == 'passed'
    assert all(original[key] is True for key in ('source_snapshot_stability', 'freeze_authority_stability', 'runner_stability'))
    assert original['freeze_authority']['sha256'] == digest(ROOT / MANIFESTS['rust_validation'])['sha256']
    launch = read_json('target/m2/stage63-original-addition-launch-01/report.json')
    assert launch['complete'] is True and launch['source_stable'] is True
    assert launch['exit_code'] == (0 if original['selected_status'] == 'passed' else 1)
    assert launch['inputs_before'] == launch['inputs_after'] == {
        name: digest(ROOT / name) for name in launch['inputs_before']}
    assert launch['result_report'] == digest(ROOT / ORIGINAL / 'report.json')
    frozen = read_json(FREEZE + '/source-snapshot.json')
    assert len(frozen) == 268 and all(manifests['native_build'].get(p) == v for p, v in frozen.items())
    assert digest(ROOT / CAPTURE_PREPARATION / 'preparation.json')['sha256'] == CAPTURE_PREPARATION_SHA
    assert comparison['capture_preparation_sha256'] == CAPTURE_PREPARATION_SHA
    assert comparison['catalog_rows'] == 680 and comparison['catalog_observations_per_target'] == 1360
    for folder in (PLATFORM, COMPARE):
        prepared = read_json(folder + '/preparation.json')
        assert prepared['prepared_files']['run.py'] == digest(ROOT / folder / 'run.py')
        assert prepared['runtime_unchanged'] is True and prepared['frozen_runtime_entries'] == 268
        assert prepared['original_preparation_sha256'] == CAPTURE_PREPARATION_SHA
    history = read_json(HISTORY_PLATFORM + '/report.json')
    assert history['complete'] is True and history['source_stable'] is True
    assert manifests['historical_platform_wrapper'] == read_json(HISTORY_PLATFORM + '/source-after.json')
    assert len(history['commands']) == 14 and all(c['exit_code'] == 0 for c in history['commands'])
    assert history['commands'][0]['argv'][0] != 'python3'
    assert history['commands'][0]['argv'][1:] == ['tools/m1_platforms.py', '--output', str(ROOT / HISTORY_M1), '--verify-contract']
    history_m1 = read_json(HISTORY_M1 + '/report.json')
    assert manifests['historical_m1_platforms'] == history_m1['source_hashes']
    assert history_m1['source_stability'] is True and history_m1['experiment_contract_status'] == 'pass'
    failed = read_json(HISTORY_COMPARE + '/report.json')
    attempt = read_json(HISTORY_COMPARE + '/attempt.json')
    assert failed['complete'] is False and failed['commands'] == []
    assert attempt['observed_terminal_exit_code'] == 1 and attempt['guest_comparisons_executed'] == 0
    assert attempt['report_identity'] == digest(ROOT / HISTORY_COMPARE / 'report.json')
    assert attempt['script_identity'] == digest(ROOT / HISTORY_COMPARE / 'run.py')
    assert not (ROOT / HISTORY_COMPARE / 'source-after.json').exists()
    for group in ARCHIVE_CONTROL_MEMBERS:
        ARCHIVE_CONTROL_MEMBERS[group] = sorted(set(ARCHIVE_CONTROL_MEMBERS[group]))
    return original, {'native': native_controls, 'portable': portable_controls,
                      'data_size': {'path': DATA_SIZE + '/report.json', **digest(ROOT / DATA_SIZE / 'report.json')},
                      'native_cohort': {'path': COHORT + '/report.json', **digest(ROOT / COHORT / 'report.json')},
                      'comparison': {'path': COMPARE + '/report.json', **digest(ROOT / COMPARE / 'report.json'),
                                     'counts': comparison['counts'], 'known_regex_failures_preserved': True}}


def publication_execution(commit, checkpoint_id):
    """Bind real original publication/assembly process captures, never reconstruct logs."""
    folder = ROOT / PUBLICATION_EXECUTION
    paths = sorted(folder.rglob('*'))
    assert all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in paths)
    files = {str(path.relative_to(folder)): path for path in paths if path.is_file()}
    assert 'run.py' in files and all(not path.is_symlink() for path in files.values())
    before = {name: digest(path) for name, path in files.items()}
    processes = {}
    for name, path in files.items():
        if not name.endswith('/process.json'):
            continue
        row = json.loads(path.read_bytes())
        label = name.removesuffix('/process.json')
        assert row['complete'] is True and row['source_stable'] is True, label
        assert row['cwd'] == str(ROOT) and row['base_commit'] == BASE, label
        assert row['pid'] > 0 and row['finished_epoch'] >= row['started_epoch'], label
        assert row['source_before'] == row['source_after'], label
        assert row['source_before'] == {n: digest(ROOT / n) for n in row['source_before']}, label
        for channel in ('stdout', 'stderr'):
            assert row[channel] == before[label + '/' + channel + '.bin'], label
        processes[label] = row
    required = {group + '-publication' for group in GROUPS} | {'checkpoint-assembly'}
    assert required <= set(processes), ('missing original process captures', required - set(processes))
    for group in GROUPS:
        row = processes[group + '-publication']
        assert row['exit_code'] == 0
        assert row['argv'] == ['python3', '-B', PUBLISHER + '/publish.py', group]
        assert files[group + '-publication/stderr.bin'].read_bytes() == b''
    assembly = processes['checkpoint-assembly']
    assert assembly['exit_code'] == 0
    assert assembly['argv'] == ['python3', '-B', 'target/m2/stage63-checkpoint-01/prepare.py']
    assert files['checkpoint-assembly/stderr.bin'].read_bytes() == b''
    result = json.loads(files['checkpoint-assembly/stdout.bin'].read_bytes())
    assert result['checkpoint'] == {'path': CHECKPOINT, **checkpoint_id}
    # Other preflight/failure attempts retain their actual status. They are
    # process history, never counted as successful assembly/publication runs.
    return files, before, {'path': PUBLICATION_EXECUTION, 'files': before,
        'processes': {label: {'argv': row['argv'], 'exit_code': row['exit_code'],
                              'complete': row['complete'], 'source_stable': row['source_stable'],
                              'base_commit': row['base_commit'], 'stdout': row['stdout'], 'stderr': row['stderr']}
                      for label, row in processes.items()},
        'original_checkpoint_assembly_raw_available': True,
        'later_verification_substitute': False, 'checkpoint_identity': {'path': CHECKPOINT, **checkpoint_id}}


def publication_review(checkpoint_id):
    """Preserve the independent review recorded after the six B archives sealed."""
    folder = ROOT / PUBLICATION_REVIEW
    paths = sorted(folder.rglob('*'))
    assert all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in paths)
    files = {str(path.relative_to(folder)): path for path in paths if path.is_file()}
    assert 'report.json' in files
    before = {name: digest(path) for name, path in files.items()}
    review = json.loads(files['report.json'].read_bytes())
    assert review['schema'] == 1 and review['kind'] == 'stage63-independent-B-publication-and-doc-review'
    assert review['complete'] is True and review['source_stable'] is True and review['approved'] is True
    assert review['candidate_compatibility_passes_claimed'] == 0
    assert set(review['publication_groups']) == set(GROUPS)
    assert expected_identity(review['checkpoint']) == (checkpoint_id['sha256'], checkpoint_id['bytes'])
    assert set(review['docs']) == HISTORICAL_BASE_DOCS | {'reports/m2/README.md'}
    for name, value in review['inputs'].items():
        item = digest(ROOT / name)
        assert expected_identity(value) == (item['sha256'], item['bytes']), name
    for name, value in review['docs'].items():
        item = digest(ROOT / name)
        assert expected_identity(value) == (item['sha256'], item['bytes']), name
    return files, before, review


def main(commit, layout_file):
    assert ROOT == Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
    assert re.fullmatch('[0-9a-f]{40}', commit), 'explicit implementation B commit required'
    assert not PUBLIC.exists() and not ARCHIVE.exists() and not (OUT / 'report.json').exists()
    assert commit != BASE, 'implementation B must differ from the Java authority base'
    assert execute('git', 'rev-parse', 'HEAD').decode().strip() == commit, 'actual HEAD must be supplied B'
    assert execute('git', 'cat-file', '-t', commit).strip() == b'commit'
    execute('git', 'merge-base', '--is-ancestor', BASE, commit)
    assert layout_file.resolve() == OUT / 'layout-verified.json'
    layout_id = digest(layout_file)
    layout = json.loads(layout_file.read_bytes())
    assert layout['schema'] == 1 and layout['approved'] is True
    assert layout['implementation_commit'] == commit
    assert set(layout['publications']) == set(PUBLICATIONS)
    preparation_id = digest(OUT / 'preparation.json')
    binder_id = digest(Path(__file__))
    preparation = json.loads((OUT / 'preparation.json').read_bytes())
    assert preparation['prepared_binder'] == binder_id
    assert preparation['source'] == {name: digest(ROOT / name) for name in preparation['source']}
    repositories = {'.': ROOT, **{name: ROOT / name for name in PIN}}
    trees = {'.': git_tree(ROOT, commit),
             **{name: git_tree(ROOT / name, pin) for name, pin in PIN.items()}}
    base_tree = git_tree(ROOT, BASE)
    for name, pin in PIN.items():
        assert trees['.'].get(name) == ('160000', 'commit', pin), (name, trees['.'].get(name))

    manifests = {}
    manifest_ids = {}
    for category, relative in MANIFESTS.items():
        path = ROOT / relative
        manifest_ids[relative] = digest(path)
        values = load_manifest(category, relative)
        manifests[category] = values
    assert digest(ROOT / PUBLISHER / 'layout.json')['sha256'] == PUBLISHER_LAYOUT_SHA
    publisher_layout = json.loads((ROOT / PUBLISHER / 'layout.json').read_bytes())
    assert set(publisher_layout['groups']) == set(GROUPS)
    for category, values in manifests.items():
        for name in values:
            if name.startswith('target/'):
                assert name in EXECUTION_INPUTS, ('unapproved ignored source', category, name)
                group, member = EXECUTION_INPUTS[name]
                EXECUTION_PROOFS.append((category, group, name, member))
    represented = {row[2] for row in EXECUTION_PROOFS}
    for name, (group, member) in EXECUTION_INPUTS.items():
        if name not in represented:
            EXECUTION_PROOFS.append(('standalone_execution_input', group, name, member))
    original_report, capture_controls = validate_final_records(manifests)
    for category, relative in MANIFESTS.items():
        ARCHIVE_CONTROL_MEMBERS[ARCHIVED_COPIES[category][0]].append(relative)
    for relative in READ_IDENTITIES:
        if not relative.startswith('target/m2/'):
            assert any(relative in rows for rows in manifests.values()), relative
            continue
        groups = [group for group, directories in publisher_layout['groups'].items()
                  if any(relative.startswith('target/m2/' + directory + '/') for directory in directories)]
        assert len(groups) == 1, ('JSON evidence has no unique archive group', relative, groups)
        ARCHIVE_CONTROL_MEMBERS[groups[0]].append(relative)
    for group in ARCHIVE_CONTROL_MEMBERS:
        ARCHIVE_CONTROL_MEMBERS[group] = sorted(set(ARCHIVE_CONTROL_MEMBERS[group]))

    copied_ids = {}
    rust = manifests['rust_validation']
    origin_counts = Counter()
    required_oids = {name: set() for name in repositories}
    rows = []
    for name, value in rust.items():
        origin = value['origin']
        repo, relative = logical(name)
        if origin['kind'] == 'git-blob':
            assert origin['repository'] == repo and origin['path'] == relative
            expected_commit = BASE if repo == '.' else PIN[repo]
            assert origin['commit'] == expected_commit
            previous = base_tree if repo == '.' else trees[repo]
            assert previous.get(relative) == (origin['mode'], 'blob', origin['oid']), (name, origin)
            required_oids[repo].add(origin['oid'])
            assert value['input_mode'] == origin['mode']
            origin_counts['base_git' if repo == '.' else 'pinned_submodule_git'] += 1
        else:
            assert origin['kind'] == 'captured-file' and repo == '.'
            path = ROOT / RUST / origin['path']
            assert path.is_file() and not path.is_symlink(), path
            copied_ids[str(path.relative_to(ROOT))] = digest(path)
            assert copied_ids[str(path.relative_to(ROOT))] == {
                'sha256': value['sha256'], 'bytes': value['bytes']}
            origin_counts['captured_file'] += 1
        rows.append(('rust_validation', name, value))
    assert sum(origin_counts.values()) == len(rust)
    assert origin_counts['captured_file'] == json.loads(
        (ROOT / RUST / 'report.json').read_bytes())['copied_source_files']
    for category, folder in SOURCE_COPIES.items():
        for name, value in manifests[category].items():
            path = ROOT / folder / copied_suffix(category, name)
            assert path.is_file() and not path.is_symlink(), path
            expected_sha, expected_size = expected_identity(value)
            identity = digest(path)
            assert identity['sha256'] == expected_sha and (expected_size is None or identity['bytes'] == expected_size), (category, name)
            copied_ids[str(path.relative_to(ROOT))] = identity
    for category, data in manifests.items():
        if category == 'rust_validation':
            continue
        rows.extend((category, name, value) for name, value in data.items())

    archive_ids = {}
    for category, relative in PUBLIC_ARCHIVES.items():
        path = ROOT / relative
        archive_ids[category] = {'path': relative, **digest(path)}
        entry = trees['.'].get(relative)
        assert entry and entry[:2] == ('100644', 'blob'), (relative, entry)
        required_oids['.'].add(entry[2])
    publication_ids = {}
    for category, relative in PUBLICATIONS.items():
        publication_ids[category] = {'path': relative, **digest(ROOT / relative)}
        entry = trees['.'].get(relative)
        assert entry and entry[:2] == ('100644', 'blob'), (relative, entry)
        required_oids['.'].add(entry[2])
    checkpoint_id = digest(ROOT / CHECKPOINT)
    checkpoint_entry = trees['.'].get(CHECKPOINT)
    assert checkpoint_entry and checkpoint_entry[:2] == ('100644', 'blob')
    required_oids['.'].add(checkpoint_entry[2])
    execution_files, execution_ids, execution_summary = publication_execution(commit, checkpoint_id)
    review_files, review_ids, independent_review = publication_review(checkpoint_id)
    for name in independent_review['docs']:
        entry = trees['.'].get(name)
        assert entry and entry[:2] == ('100644', 'blob'), ('reviewed document absent from B', name)
        required_oids['.'].add(entry[2])
    for category, name, value in rows:
        repo, relative = logical(name)
        entry = trees[repo].get(relative)
        if entry and entry[1] == 'blob':
            required_oids[repo].add(entry[2])
    for capture in capture_controls['portable'].values():
        for name in capture['binding']['capture_specific_source_inputs']:
            entry = trees['.'].get(name)
            assert entry and entry[:2] == ('100644', 'blob'), ('capture-specific B source', name, entry)
            required_oids['.'].add(entry[2])
    blobs = {name: git_blobs(repo, required_oids[name]) for name, repo in repositories.items()}
    reviewed_document_B_proofs = {}
    for name, value in independent_review['docs'].items():
        mode, kind, oid = trees['.'][name]
        assert expected_identity(value) == (blobs['.'][oid]['sha256'], blobs['.'][oid]['bytes'])
        reviewed_document_B_proofs[name] = {'B_mode': mode, 'B_oid': oid, **blobs['.'][oid]}
    portable_specific_B_proofs = []
    for capture_name, capture in capture_controls['portable'].items():
        for name, sha in capture['binding']['capture_specific_source_inputs'].items():
            mode, kind, oid = trees['.'][name]
            actual = blobs['.'][oid]
            recorded = manifests['comparison_wrapper'][name]
            assert actual == {'sha256': sha, 'bytes': recorded['bytes']}, (capture_name, name)
            portable_specific_B_proofs.append({
                'capture': capture_name, 'capture_report': capture['path'], 'path': name,
                'recorded_capture_sha256': sha, 'B_mode': mode, 'B_type': kind,
                'B_oid': oid, 'B_bytes': actual['bytes'], 'B_sha256': actual['sha256'],
                'status': 'capture_specific_source_matches_B',
                'independent_copied_source_category': 'comparison_wrapper'})
    assert len(portable_specific_B_proofs) == 4
    assert blobs['.'][checkpoint_entry[2]] == checkpoint_id
    for name, value in rust.items():
        origin = value['origin']
        if origin['kind'] == 'git-blob':
            repo, _ = logical(name)
            assert blobs[repo][origin['oid']] == {'sha256': value['sha256'], 'bytes': value['bytes']}, name
    symlinks = [name for name, value in rust.items() if value['input_mode'] == '120000']
    assert all(rust[name]['origin']['kind'] == 'git-blob' and
               rust[name]['origin']['mode'] == '120000' for name in symlinks)

    archive_bytes = {}
    for category, identity in archive_ids.items():
        entry = trees['.'][identity['path']]
        assert blobs['.'][entry[2]] == {'sha256': identity['sha256'], 'bytes': identity['bytes']}
        archive_bytes[category] = blob_bytes(ROOT, entry[2], {
            'sha256': identity['sha256'], 'bytes': identity['bytes']})
        identity['B_oid'] = entry[2]
    full_archive_counts = {}
    for category, identity in publication_ids.items():
        entry = trees['.'][identity['path']]
        expected = {key: identity[key] for key in ('sha256', 'bytes')}
        assert blobs['.'][entry[2]] == expected
        publication = json.loads(blob_bytes(ROOT, entry[2], expected))
        identity['B_oid'] = entry[2]
        approved = layout['publications'][category]
        assert all(approved[key] == identity[key] for key in ('path', 'sha256', 'bytes'))
        assert approved['selected_directories'] == publication['selected_directories']
        assert publication['selected_directories'] == ['target/m2/' + n for n in publisher_layout['groups'][category]]
        archive = publication['archive']
        assert all(approved['archive'][key] == archive[key]
                   for key in ('path', 'sha256', 'bytes', 'members'))
        assert all(archive[key] == archive_ids[category][key]
                   for key in ('path', 'sha256', 'bytes'))
        assert publication['source_before_after']['stable'] is True
        assert archive['full_member_readback_verified'] is True
        observed = {}
        with tarfile.open(fileobj=io.BytesIO(archive_bytes[category]), mode='r:gz') as stream:
            for member in stream:
                assert member.isfile() and not member.issym() and not member.islnk()
                assert member.name not in observed and not member.name.startswith('/')
                assert '..' not in PurePosixPath(member.name).parts
                raw = stream.extractfile(member).read()
                observed[member.name] = {
                    'sha256': hashlib.sha256(raw).hexdigest(),
                    'bytes': len(raw), 'mode': member.mode}
        assert observed == publication['member_inventory'], category
        assert len(observed) == archive['members']
        full_archive_counts[category] = len(observed)
    archived_counts = {}
    for category, (archive_name, prefix, mode) in ARCHIVED_COPIES.items():
        archived_counts[category] = archive_member_audit(
            archive_bytes[archive_name], category, prefix, manifests[category],
            captured_only=(mode == 'captured-only'))
        assert archived_counts[category] == (origin_counts['captured_file'] if mode == 'captured-only'
                                             else len(manifests[category]))
    for archive_name, controls in ARCHIVE_CONTROL_MEMBERS.items():
        with tarfile.open(fileobj=io.BytesIO(archive_bytes[archive_name]), mode='r:gz') as stream:
            for relative in controls:
                member = stream.getmember(relative)
                assert member.isfile() and not member.issym() and not member.islnk(), relative
                raw = stream.extractfile(member).read()
                assert {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} == digest(ROOT / relative), relative

    control_ids = {relative: digest(ROOT / relative)
                   for controls in ARCHIVE_CONTROL_MEMBERS.values() for relative in controls}
    wrapper_rows = []
    wrapper_ids = {}
    for category, archive_name, source, archived_member in EXECUTION_PROOFS:
        assert source not in trees['.'], ('wrapper unexpectedly became a B source', source)
        path = ROOT / source
        assert path.is_file() and not path.is_symlink(), source
        identity = digest(path)
        wrapper_ids[source] = identity
        with tarfile.open(fileobj=io.BytesIO(archive_bytes[archive_name]), mode='r:gz') as stream:
            member = stream.getmember(archived_member)
            assert member.isfile() and not member.issym() and not member.islnk()
            raw = stream.extractfile(member).read()
        assert {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} == identity
        wrapper_rows.append({
            'category': category, 'source_path': source,
            'status': 'archived_execution_tool_not_B',
            'archive': PUBLIC_ARCHIVES[archive_name], 'archive_member': archived_member,
            'B_archive_oid': archive_ids[archive_name]['B_oid'], **identity})

    statuses = defaultdict(Counter)
    deviations = defaultdict(list)
    output_rows = OUT / 'rows.jsonl.gz'
    with output_rows.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
            for category, name, value in rows:
                expected_sha, expected_size = expected_identity(value)
                repo, relative = logical(name)
                entry = trees[repo].get(relative)
                row = {'category': category, 'path': name, 'repository': repo,
                       'expected_sha256': expected_sha, 'expected_bytes': expected_size}
                if category == 'rust_validation':
                    row['origin'] = value['origin']
                    row['expected_mode'] = value['input_mode']
                if entry is None:
                    proof = next((proof for proof in wrapper_rows
                                  if proof['category'] == category and proof['source_path'] == name), None)
                    if proof is not None:
                        assert proof['sha256'] == expected_sha
                        assert expected_size is None or proof['bytes'] == expected_size
                        status = 'archived_execution_tool_not_B'
                        row.update(archive=proof['archive'], archive_member=proof['archive_member'],
                                   B_archive_oid=proof['B_archive_oid'])
                    else:
                        status = 'missing_in_B'
                elif entry[1] != 'blob':
                    status = 'nonblob_in_B'
                    row.update(B_mode=entry[0], B_type=entry[1], B_oid=entry[2])
                else:
                    mode, _, oid = entry
                    current = blobs[repo][oid]
                    row.update(B_mode=mode, B_oid=oid, B_sha256=current['sha256'],
                               B_bytes=current['bytes'])
                    equal = current['sha256'] == expected_sha and (
                        expected_size is None or current['bytes'] == expected_size) and (
                        category != 'rust_validation' or mode == value['input_mode'])
                    status = 'matches_B' if equal else 'differs_from_B'
                    if not equal and category == 'rust_validation' and value['origin']['kind'] == 'git-blob' and repo == '.' and name in HISTORICAL_BASE_DOCS:
                        # The exact older bytes and Git mode were checked against BASE above.
                        status = 'historical_document_from_base'
                row['status'] = status
                statuses[category][status] += 1
                if status != 'matches_B':
                    deviations[category].append({'path': name, 'status': status,
                                                 'expected_sha256': expected_sha,
                                                 'B_sha256': row.get('B_sha256')})
                zipped.write((json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n').encode())
    assert sum(sum(counts.values()) for counts in statuses.values()) == sum(map(len, manifests.values()))
    for category, counts in statuses.items():
        unauthorized = set(counts) - {'matches_B', 'historical_document_from_base',
                                      'archived_execution_tool_not_B'}
        assert not unauthorized, (category, dict(counts), deviations[category][:10])
        expected_wrapper_paths = {proof['source_path'] for proof in wrapper_rows
                                  if proof['category'] == category and proof['source_path'] in manifests[category]}
        assert counts['archived_execution_tool_not_B'] == len(expected_wrapper_paths), category
    assert statuses['rust_validation']['matches_B'] >= origin_counts['captured_file']
    for category, values in manifests.items():
        if category != 'rust_validation':
            assert sum(statuses[category].values()) == len(values)
    assert {relative: digest(ROOT / relative) for relative in manifest_ids} == manifest_ids
    assert {relative: digest(ROOT / relative) for relative in copied_ids} == copied_ids
    assert all(digest(ROOT / identity['path']) == {k: identity[k] for k in ('sha256', 'bytes')}
               for identity in archive_ids.values())
    assert all(digest(ROOT / identity['path']) == {k: identity[k] for k in ('sha256', 'bytes')}
               for identity in publication_ids.values())
    assert {relative: digest(ROOT / relative) for relative in wrapper_ids} == wrapper_ids
    assert execution_ids == {name: digest(path) for name, path in execution_files.items()}
    assert review_ids == {name: digest(path) for name, path in review_files.items()}
    assert preparation['source'] == {name: digest(ROOT / name) for name in preparation['source']}
    assert digest(ROOT / CHECKPOINT) == checkpoint_id
    assert digest(layout_file) == layout_id and digest(OUT / 'preparation.json') == preparation_id
    assert digest(Path(__file__)) == binder_id
    assert {name: digest(ROOT / name) for name in control_ids} == control_ids
    assert {name: digest(ROOT / name) for name in READ_IDENTITIES} == READ_IDENTITIES

    report = {
        'schema': 1, 'kind': 'actual-Git-object-source-binding-for-Stage63-B',
        'original_case_count': len(original_report['results']),
        'original_selected_status': original_report['selected_status'],
        'B_commit': commit, 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'recorded_base_commit': BASE, 'gitlinks': PIN,
        'method': 'Actual base, pinned submodule and B tree OIDs/modes; SHA-1-framed Git blob reads and raw SHA-256/size; copied source bytes, required report controls and B archive members reread.',
        'manifests': {category: {'path': relative, **manifest_ids[relative],
                                 'rows': len(manifests[category])}
                      for category, relative in MANIFESTS.items()},
        'category_statuses': {category: dict(counts) for category, counts in statuses.items()},
        'deviations': dict(deviations), 'origin_counts': dict(origin_counts),
        'verified_symlink_sources': symlinks, 'archived_source_member_counts': archived_counts,
        'archived_control_members': {name: list(paths) for name, paths in ARCHIVE_CONTROL_MEMBERS.items()},
        'B_archive_blobs': archive_ids, 'unique_blob_objects_read': {name: len(value) for name, value in blobs.items()},
        'B_publication_blobs': publication_ids, 'full_archive_member_counts': full_archive_counts,
        'archived_execution_wrappers': wrapper_rows,
        'copied_source_files_stable': len(copied_ids),
        'B_implementation_checkpoint': {'path': CHECKPOINT, 'B_oid': checkpoint_entry[2], **checkpoint_id},
        'publication_execution': execution_summary,
        'independent_publication_review': {'path': PUBLICATION_REVIEW, 'files': review_ids,
                                           'approved': True, 'reviewed_document_B_proofs': reviewed_document_B_proofs},
        'original_checkpoint_assembly_raw_available': True,
        'row_details': {'path': str(output_rows.relative_to(ROOT)), **digest(output_rows)},
        'capture_controls': capture_controls,
        'portable_capture_specific_B_source_proofs': portable_specific_B_proofs,
        'layout_guard': {'path': str(layout_file.relative_to(ROOT)), **layout_id},
        'binder': {'path': str(Path(__file__).relative_to(ROOT)), **binder_id},
        'original_comparison': {'selected_status': original_report['selected_status'],
                                'status_counts': original_report['status_counts'],
                                'selected_cases': len(original_report['results'])},
        'limits': ['Only the three named base document rows may retain verified base Git bytes when they differ from B; actual rows are counted and are not B-current source claims.',
                   'Named generated execution wrappers are separately proved by exact bytes in committed B evidence archives; they are absent from B source paths and are never counted as B-current sources.',
                   'Earlier failed compiler, build, and tooling attempts remain historical evidence. Platform01 and comparison01 source snapshots are bound as historical observations without changing their acquisition or failure status.',
                   'The four Any/DataSize capture-specific source proofs are retained explicitly and now also belong to the complete platform-wrapper snapshot. Each requires actual B mode/OID/framed-blob SHA/size equality; no source drift is allowed.',
                   'Original publication and checkpoint assembly process stdout/stderr, exit codes and source bookends are preserved in this C evidence archive. Any earlier failed preflight retains its actual status.',
                   'Source binding does not rerun evaluators, builds or tests and does not establish full API, whole M2 or performance compatibility.'],
    }
    (OUT / 'report.json').write_bytes(raw_json(report))
    payloads = {'report.json': OUT / 'report.json', 'rows.jsonl.gz': output_rows,
                'binder.py': Path(__file__)}
    payloads.update({'publication-execution/' + name: path for name, path in execution_files.items()})
    payloads.update({'independent-publication-review/' + name: path for name, path in review_files.items()})
    payloads.update({'preparation/draft-01/' + path.name: path for path in (OUT / 'draft-01').iterdir() if path.is_file()})
    for name in ('adapt.py', 'config.py.txt', 'execution.py.txt'):
        payloads['preparation/' + name] = OUT / name
    payloads['preparation.json'] = OUT / 'preparation.json'
    payloads['layout-verified.json'] = OUT / 'layout-verified.json'
    inventory = {name: {'mode': stat.S_IMODE(path.stat().st_mode), **digest(path)}
                 for name, path in payloads.items()}
    manifest_raw = raw_json({'schema': 1, 'files': inventory})
    with ARCHIVE.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as stream:
                for name, path in [('manifest.json', None), *sorted(payloads.items())]:
                    raw = manifest_raw if path is None else path.read_bytes()
                    entry = tarfile.TarInfo(name)
                    entry.size = len(raw)
                    entry.mode = 0o644 if path is None else inventory[name]['mode']
                    entry.mtime = 0
                    stream.addfile(entry, io.BytesIO(raw))
    assert digest(ARCHIVE)['bytes'] < 95 * 1024 * 1024
    seen = {}
    with tarfile.open(ARCHIVE, 'r:gz') as stream:
        for entry in stream:
            assert entry.isfile() and entry.name not in seen and not entry.name.startswith('/') and '..' not in PurePosixPath(entry.name).parts
            raw = stream.extractfile(entry).read()
            seen[entry.name] = {'sha256': hashlib.sha256(raw).hexdigest(),
                                'bytes': len(raw), 'mode': entry.mode}
    assert seen.pop('manifest.json') == {'sha256': hashlib.sha256(manifest_raw).hexdigest(),
                                         'bytes': len(manifest_raw), 'mode': 0o644}
    assert seen == inventory
    publication = {
        'schema': 1, 'binding_report': report,
        'evidence_archive': {'path': 'reports/m2/stage63-source-binding-evidence.tar.gz',
                             'local_artifact_path': str(ARCHIVE.relative_to(ROOT)), **digest(ARCHIVE),
                             'members': len(seen) + 1},
        'full_archive_reread_verified': True, 'original_sources_stable_before_after': True,
        'whole_M2_complete': False, 'full_public_api_comparison_passed': False,
        'performance_targets_achieved': False,
    }
    PUBLIC.write_bytes(raw_json(publication))
    print(json.dumps({'B_commit': commit, 'category_statuses': report['category_statuses'],
                      'evidence_archive': publication['evidence_archive'],
                      'report': digest(PUBLIC)}, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--commit', required=True,
                        help='Actual root-supplied 40-hex implementation B commit')
    parser.add_argument('--layout', type=Path, required=True,
                        help='Root-approved final archive guard at this directory/layout-verified.json')
    args = parser.parse_args()
    main(args.commit, args.layout)
