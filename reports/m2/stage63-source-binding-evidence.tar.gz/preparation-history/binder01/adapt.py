"""Prepare Stage63's future-commit binder from the reviewed Stage62 implementation.

This adapter writes only the fresh target binder and its preparation record.
It syntax-checks generated Python; it never calls the binder or Git mutation.
"""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'target/m2/stage62-source-binding-03/bind.py'


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def main():
    assert not (OUT / 'bind.py').exists() and not (OUT / 'preparation.json').exists()
    source = SOURCE.read_text()
    source = source[source.index('from __future__ import annotations'):]
    source = '"""Bind recorded Stage63 sources to an explicit future implementation B commit.\n\n' \
             'No build, evaluator, comparison, publication or Git mutation is performed.\n' \
             'Historical platform01 and failed comparison01 remain historical evidence.\n' \
             'Real original publication/assembly process logs are included in the C archive.\n' \
             'Run only after B and the root-approved six-archive layout guard exist.\n"""\n' + source
    start = source.index('ROOT = Path(')
    end = source.index('def raw_json(', start)
    source = source[:start] + (OUT / 'config.py.txt').read_text() + source[end:]
    source = source.replace('Stage62', 'Stage63').replace('Stage 62', 'Stage 63').replace('stage62-', 'stage63-')

    def replace(old, new, count=1):
        nonlocal source
        assert source.count(old) == count, (old[:100], source.count(old), count)
        source = source.replace(old, new)

    replace("    assert commit == IMPLEMENTATION_COMMIT, 'explicit reviewed Stage63 implementation B required'\n", '')
    replace("    assert commit != BASE, 'implementation B must differ from the Java authority base'",
            "    assert commit != BASE, 'implementation B must differ from the Java authority base'\n"
            "    assert execute('git', 'rev-parse', 'HEAD').decode().strip() == commit, 'actual HEAD must be supplied B'")
    replace("    binder_id = digest(Path(__file__))",
            "    binder_id = digest(Path(__file__))\n"
            "    preparation = json.loads((OUT / 'preparation.json').read_bytes())\n"
            "    assert preparation['prepared_binder'] == binder_id\n"
            "    assert preparation['source'] == {name: digest(ROOT / name) for name in preparation['source']}")
    replace('== 165344', '== 165362')
    replace("rust['copied_source_files'] == 22", "rust['copied_source_files'] == 13")
    replace("                            ('tool_validation', TOOL + '/source-after.json'),\n", '')
    replace("len(commands) == 19 and len({row['name'] for row in commands}) == 19",
            "len(commands) == 25 and len({row['name'] for row in commands}) == 25")
    replace("    assert len(tool['commands']) == 4 and all(row['exit_code'] == 0 for row in tool['commands'])",
            "    assert len(tool['checks']) == 7 and all(row['exit_code'] == 0 for row in tool['checks'])\n"
            "    assert manifests['tool_validation'] == tool['source_after'] and tool['source_copies_match'] is True\n"
            "    assert tool['actual_python_read_missing_from_snapshot'] == []\n"
            "    assert len(manifests['tool_validation']) == tool['source_counts']['declared_and_copied'] == 6499")
    replace("len(set(selection['case_ids'])) == 90", "len(set(selection['case_ids'])) == 91")
    replace('stage63-original-conversions-launch-01', 'stage63-original-addition-launch-01', 1)
    replace("'platform_wrapper': PLATFORM + '/report.json', 'data_size_native': DATA_SIZE + '/report.json',",
            "'platform_wrapper': PLATFORM + '/report.json', 'data_size_native': DATA_SIZE + '/report.json',\n"
            "                     'native_acquisition': COHORT + '/report.json',")
    replace("    assert command['argv'][-1] == '--verify-contract' and command['argv'][-2] == str(ROOT / M1)",
            "    assert command['argv'] == ['python3', 'tools/m1_platforms.py', '--output', str(ROOT / M1), '--verify-contract']")

    old = """                elif relative in manifests['platform_wrapper']:
                    assert expected_identity(manifests['platform_wrapper'][relative])[0] == sha
                    binding['source_inputs'][relative] = sha
                else:
                    assert relative in PORTABLE_CAPTURE_SPECIFIC_SOURCES.get(name, set()), (name, relative)
                    # Comparison independently copied these bytes. Its unchanged
                    # source row must also match B; this does not relabel that
                    # copy as a platform-wrapper source or permit source drift.
                    assert relative in manifests['comparison_wrapper'], (name, relative)
                    assert expected_identity(manifests['comparison_wrapper'][relative])[0] == sha
                    binding['capture_specific_source_inputs'][relative] = sha
                    capture_specific_observed.setdefault(name, set()).add(relative)
"""
    new = """                else:
                    assert relative in manifests['platform_wrapper'], (name, relative)
                    assert expected_identity(manifests['platform_wrapper'][relative])[0] == sha
                    binding['source_inputs'][relative] = sha
                    if relative in PORTABLE_CAPTURE_SPECIFIC_SOURCES.get(name, set()):
                        assert relative in manifests['comparison_wrapper'], (name, relative)
                        assert expected_identity(manifests['comparison_wrapper'][relative])[0] == sha
                        binding['capture_specific_source_inputs'][relative] = sha
                        capture_specific_observed.setdefault(name, set()).add(relative)
"""
    replace(old, new)
    extra_validation = """    frozen = read_json(FREEZE + '/source-snapshot.json')
    assert len(frozen) == 268 and all(manifests['native_build'].get(p) == v for p, v in frozen.items())
    assert digest(ROOT / CAPTURE_PREPARATION / 'preparation.json')['sha256'] == CAPTURE_PREPARATION_SHA
    assert comparison['capture_preparation_sha256'] == CAPTURE_PREPARATION_SHA
    assert comparison['catalog_rows'] == 680 and comparison['catalog_observations_per_target'] == 1360
    for folder in (PLATFORM, COMPARE):
        prepared = read_json(folder + '/preparation.json')
        assert prepared['prepared_files']['run.py'] == digest(ROOT / folder / 'run.py')
        assert prepared['runtime_unchanged'] is True and prepared['frozen_runtime_entries'] == 268
        assert prepared['original_preparation_sha256'] == CAPTURE_PREPARATION_SHA
    history = read_json(HISTORY_PLATFORM + '/report.json')
    assert history['complete'] is True and history['source_stable'] is True
    assert manifests['historical_platform_wrapper'] == read_json(HISTORY_PLATFORM + '/source-after.json')
    assert len(history['commands']) == 14 and all(c['exit_code'] == 0 for c in history['commands'])
    assert history['commands'][0]['argv'][0] != 'python3'
    assert history['commands'][0]['argv'][1:] == ['tools/m1_platforms.py', '--output', str(ROOT / HISTORY_M1), '--verify-contract']
    history_m1 = read_json(HISTORY_M1 + '/report.json')
    assert manifests['historical_m1_platforms'] == history_m1['source_hashes']
    assert history_m1['source_stability'] is True and history_m1['experiment_contract_status'] == 'pass'
    failed = read_json(HISTORY_COMPARE + '/report.json')
    attempt = read_json(HISTORY_COMPARE + '/attempt.json')
    assert failed['complete'] is False and failed['commands'] == []
    assert attempt['observed_terminal_exit_code'] == 1 and attempt['guest_comparisons_executed'] == 0
    assert attempt['report_identity'] == digest(ROOT / HISTORY_COMPARE / 'report.json')
    assert attempt['script_identity'] == digest(ROOT / HISTORY_COMPARE / 'run.py')
    assert not (ROOT / HISTORY_COMPARE / 'source-after.json').exists()
"""
    replace("    for group in ARCHIVE_CONTROL_MEMBERS:\n        ARCHIVE_CONTROL_MEMBERS[group] = sorted(set(ARCHIVE_CONTROL_MEMBERS[group]))\n    return original,",
            extra_validation + "    for group in ARCHIVE_CONTROL_MEMBERS:\n        ARCHIVE_CONTROL_MEMBERS[group] = sorted(set(ARCHIVE_CONTROL_MEMBERS[group]))\n    return original,")

    # Resolve source rows only through this closed explicit execution-input list.
    insert = """    assert digest(ROOT / PUBLISHER / 'layout.json')['sha256'] == PUBLISHER_LAYOUT_SHA
    publisher_layout = json.loads((ROOT / PUBLISHER / 'layout.json').read_bytes())
    assert set(publisher_layout['groups']) == set(GROUPS)
    for category, values in manifests.items():
        for name in values:
            if name.startswith('target/'):
                assert name in EXECUTION_INPUTS, ('unapproved ignored source', category, name)
                group, member = EXECUTION_INPUTS[name]
                EXECUTION_PROOFS.append((category, group, name, member))
    represented = {row[2] for row in EXECUTION_PROOFS}
    for name, (group, member) in EXECUTION_INPUTS.items():
        if name not in represented:
            EXECUTION_PROOFS.append(('standalone_execution_input', group, name, member))
"""
    replace("    original_report, capture_controls = validate_final_records(manifests)",
            insert + "    original_report, capture_controls = validate_final_records(manifests)")
    begin = source.index('        groups = [group for group, paths in ARCHIVE_CONTROL_MEMBERS.items()')
    end = source.index('    for group in ARCHIVE_CONTROL_MEMBERS:', begin)
    source = source[:begin] + """        groups = [group for group, directories in publisher_layout['groups'].items()
                  if any(relative.startswith('target/m2/' + directory + '/') for directory in directories)]
        assert len(groups) == 1, ('JSON evidence has no unique archive group', relative, groups)
        ARCHIVE_CONTROL_MEMBERS[groups[0]].append(relative)
""" + source[end:]

    begin = source.index('    checkpoint_verification_files = {')
    end = source.index('    for category, name, value in rows:', begin)
    source = source[:begin] + """    execution_files, execution_ids, execution_summary = publication_execution(commit, checkpoint_id)
    review_files, review_ids, independent_review = publication_review(checkpoint_id)
    for name in independent_review['docs']:
        entry = trees['.'].get(name)
        assert entry and entry[:2] == ('100644', 'blob'), ('reviewed document absent from B', name)
        required_oids['.'].add(entry[2])
""" + source[end:]
    replace("    portable_specific_B_proofs = []",
            "    reviewed_document_B_proofs = {}\n"
            "    for name, value in independent_review['docs'].items():\n"
            "        mode, kind, oid = trees['.'][name]\n"
            "        assert expected_identity(value) == (blobs['.'][oid]['sha256'], blobs['.'][oid]['bytes'])\n"
            "        reviewed_document_B_proofs[name] = {'B_mode': mode, 'B_oid': oid, **blobs['.'][oid]}\n"
            "    portable_specific_B_proofs = []")
    replace("        assert verification_summary['groups'][category]['members'] == len(observed)\n", '')
    replace("    assert verification_summary['member_readback_total'] == sum(full_archive_counts.values())\n", '')
    replace("        assert approved['selected_directories'] == publication['selected_directories']",
            "        assert approved['selected_directories'] == publication['selected_directories']\n"
            "        assert publication['selected_directories'] == ['target/m2/' + n for n in publisher_layout['groups'][category]]")
    replace("    assert checkpoint_verification_ids == {name: digest(path) for name, path in checkpoint_verification_files.items()}\n"
            "    assert verification_inputs == {name: digest(ROOT / name) for name in verification_inputs}\n",
            "    assert execution_ids == {name: digest(path) for name, path in execution_files.items()}\n"
            "    assert review_ids == {name: digest(path) for name, path in review_files.items()}\n"
            "    assert preparation['source'] == {name: digest(ROOT / name) for name in preparation['source']}\n")
    begin = source.index("        'checkpoint_verification': {")
    end = source.index("        'row_details':", begin)
    source = source[:begin] + """        'publication_execution': execution_summary,
        'independent_publication_review': {'path': PUBLICATION_REVIEW, 'files': review_ids,
                                           'approved': True, 'reviewed_document_B_proofs': reviewed_document_B_proofs},
        'original_checkpoint_assembly_raw_available': True,
""" + source[end:]
    replace('Only the four named base document rows', 'Only the three named base document rows')
    replace("Earlier failed compiler, build, and tooling attempts remain historical evidence; only the declared final source snapshots are compared with B-current bytes.",
            "Earlier failed compiler, build, and tooling attempts remain historical evidence. Platform01 and comparison01 source snapshots are bound as historical observations without changing their acquisition or failure status.")
    replace("Four recorded portable-capture-specific sources lie outside the platform-wrapper snapshot; each receives a separate actual B mode/OID/framed-blob SHA/size proof, and the original 36 source manifests remain unchanged.",
            "The four Any/DataSize capture-specific source proofs are retained explicitly and now also belong to the complete platform-wrapper snapshot. Each requires actual B mode/OID/framed-blob SHA/size equality; no source drift is allowed.")
    replace("Original checkpoint assembly stdout/stderr were not saved. The separately captured later read-only verification checks existing checkpoint/publication bytes; it is not a capture or reconstruction of the original assembly execution.",
            "Original publication and checkpoint assembly process stdout/stderr, exit codes and source bookends are preserved in this C evidence archive. Any earlier failed preflight retains its actual status.")
    begin = source.index("    payloads.update({'checkpoint-verification/'")
    end = source.index("    payloads['preparation.json']", begin)
    source = source[:begin] + """    payloads.update({'publication-execution/' + name: path for name, path in execution_files.items()})
    payloads.update({'independent-publication-review/' + name: path for name, path in review_files.items()})
    payloads.update({'preparation/draft-01/' + path.name: path for path in (OUT / 'draft-01').iterdir() if path.is_file()})
    for name in ('adapt.py', 'config.py.txt', 'execution.py.txt'):
        payloads['preparation/' + name] = OUT / name
""" + source[end:]
    replace("    assert digest(ARCHIVE)['bytes'] < 90 * 1024 * 1024", "    assert digest(ARCHIVE)['bytes'] < 95 * 1024 * 1024")
    source = source.replace('def main(commit, layout_file):', (OUT / 'execution.py.txt').read_text() + 'def main(commit, layout_file):')
    assert 'CHECKPOINT_VERIFICATION' not in source and 'verification_summary' not in source
    assert 'IMPLEMENTATION_COMMIT' not in source and 'stage62-' not in source
    assert 'stage63-original-conversions' not in source
    ast.parse(source)
    compile(source, str(OUT / 'bind.py'), 'exec')
    (OUT / 'bind.py').write_text(source)
    inputs = [SOURCE, Path(__file__), OUT / 'config.py.txt', OUT / 'execution.py.txt',
              ROOT / 'target/m2/stage63-publication-01/layout.json',
              ROOT / 'target/m2/stage63-publication-execution-01/run.py',
              ROOT / 'target/m2/stage63-core-freeze-01/source-snapshot.json']
    record = {'scope': 'Prepared before implementation B; syntax checked only. Binder not executed.',
              'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'source': {str(p.relative_to(ROOT)): identity(p) for p in inputs},
              'prepared_binder': identity(OUT / 'bind.py'), 'syntax_checked': True,
              'binder_executed': False, 'explicit_future_commit_required': True,
              'layout_guard_required': 'target/m2/stage63-source-binding-01/layout-verified.json',
              'public_archive_path': 'reports/m2/stage63-source-binding-evidence.tar.gz',
              'historical_document_allowlist': ['PLAN.md', 'TESTING.md', 'docs/m2-language.md'],
              'expected_source_categories': 45, 'archive_groups': 6,
              'pending_terminal_inputs': ['comparison02', 'original91', 'six publications', 'checkpoint assembly'],
              'execution_contract': 'Real publication-execution-01 process records and raw channels, including checkpoint-assembly; no reconstructed or later-verification substitute.'}
    (OUT / 'preparation.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'binder': identity(OUT / 'bind.py'), 'preparation': identity(OUT / 'preparation.json')}))


if __name__ == '__main__':
    main()
