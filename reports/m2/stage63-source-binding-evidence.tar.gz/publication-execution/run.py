"""Record one real publication/checkpoint process; never reconstruct old logs."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent


def identity(path):
    path = Path(path)
    with path.open('rb') as handle:
        digest = hashlib.file_digest(handle, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('label')
    parser.add_argument('argv', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not args.label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in args.label):
        raise ValueError('A simple unique process label is required')
    argv = args.argv[1:] if args.argv[:1] == ['--'] else args.argv
    if not argv:
        raise ValueError('Actual child argv is required')
    output = HERE / args.label
    output.mkdir()
    names = [Path(__file__).resolve(),
             ROOT / 'target/m2/stage63-publication-01/publish.py',
             ROOT / 'target/m2/stage63-publication-01/layout.json',
             ROOT / 'target/m2/stage63-publication-01/preparation.json']
    names += [ROOT / item for item in argv if item.endswith('.py') and (ROOT / item).is_file()]
    before = {str(p.relative_to(ROOT)): identity(p) for p in sorted(set(names))}
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
    record = {'schema': 1, 'argv': argv, 'cwd': str(ROOT), 'host': platform.uname()._asdict(),
              'python': {'executable': sys.executable, 'version': sys.version,
                         'identity': identity(Path(sys.executable).resolve())},
              'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'source_before': before, 'started_utc': now(), 'started_epoch': time.time(),
              'environment': {k: env.get(k) for k in ('PATH', 'LANG', 'LC_ALL', 'TZ', 'PYTHONDONTWRITEBYTECODE')},
              'complete': False}
    def save():
        (output / 'process.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    save()
    with (output / 'stdout.bin').open('xb') as stdout, (output / 'stderr.bin').open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        record['pid'] = child.pid
        save()
        code = child.wait()
    after = {str(p.relative_to(ROOT)): identity(p) for p in sorted(set(names))}
    record.update(complete=True, exit_code=code, finished_utc=now(), finished_epoch=time.time(),
                  source_after=after, source_stable=before == after,
                  stdout=identity(output / 'stdout.bin'), stderr=identity(output / 'stderr.bin'))
    save()
    print(json.dumps({'label': args.label, 'exit_code': code, 'source_stable': before == after,
                      'process': str((output / 'process.json').relative_to(ROOT))}, sort_keys=True), flush=True)
    raise SystemExit(code if before == after else 2)


if __name__ == '__main__':
    main()
