"""Recorded combined Stage46/classpath acquisition, preserving strict failures."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

root=Path.cwd()
out=root/'target/m2/stage46-full-regression-01'
language=root/'target/m2/stage46-language-final-01'
lifecycle=root/'target/m2/stage46-class-lifecycle-final-01'
assert not (out/'process-report.json').exists()
assert not language.exists() and not lifecycle.exists()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
report={'scope':'Complete selected language and persistent regression of shared Stage46 Resource/module preparation implementation and the existing explicit JVM profile. Strict failures remain failures. No CI or performance claim.','cwd':str(root),'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'startedUtc':utc(),'python':sys.executable,'pythonVersion':sys.version,'platform':platform.platform(),'commands':[],'complete':False,'infrastructureFailures':[],'relevantEnvironment':{name:os.environ.get(name)for name in ['PKL_ORACLE_JAVA','JAVA_HOME','CARGO_TARGET_DIR','RUSTUP_TOOLCHAIN']},'runnerSha256':sha(Path(__file__))}
def save():(out/'process-report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
commands=[
 ('language-acquire',[sys.executable,'tools/m2_language.py','--output',str(language),'--record-only','--workers','2'],True),
 ('language-verify-report',[sys.executable,'tools/m2_language.py','--verify-report',str(language)],True),
 ('language-verify-development',[sys.executable,'tools/m2_language.py','--verify-development',str(language)],False),
 ('language-verify-subset',[sys.executable,'tools/m2_language.py','--verify-subset',str(language)],False),
 ('language-verify-full',[sys.executable,'tools/m2_language.py','--verify-full',str(language)],False),
 ('lifecycle-acquire',[sys.executable,'tools/m2_class_lifecycle.py','--output',str(lifecycle),'--record-only'],True),
 ('lifecycle-verify-report',[sys.executable,'tools/m2_class_lifecycle.py','--verify-report',str(lifecycle)],True),
 ('lifecycle-verify-contract',[sys.executable,'tools/m2_class_lifecycle.py','--verify-contract',str(lifecycle)],False),
]
for label,argv,require_zero in commands:
    row={'label':label,'argv':argv,'startedUtc':utc(),'requiresZeroForIntegrity':require_zero}
    start=time.monotonic()
    print('START',label,flush=True)
    stdout=out/(label+'.stdout.bin');stderr=out/(label+'.stderr.bin')
    with stdout.open('wb')as output,stderr.open('wb')as error:
        child=subprocess.Popen(argv,cwd=root,stdout=output,stderr=error)
        row['pid']=child.pid
        (out/'active.json').write_text(json.dumps(row,indent=2)+'\n')
        row['returncode']=child.wait()
    row.update(finishedUtc=utc(),seconds=time.monotonic()-start,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr))
    report['commands'].append(row)
    infrastructure_failure = (row['returncode'] != 0) if require_zero else (row['returncode'] not in (0, 1))
    if infrastructure_failure:report['infrastructureFailures'].append(label)
    save()
    print('FINISH',label,row['returncode'],flush=True)
    if infrastructure_failure:
        raise SystemExit('Acquisition/integrity failure preserved; inspect before continuing')
report.update(complete=True,finishedUtc=utc(),returncodeSemantics='Wrapper zero means every scheduled command finished with no acquisition/integrity failures; strict contract exit codes retain their own meanings.')
save()
print('COMPLETE',flush=True)
