from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
OUT=Path(__file__).parent
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
EXEC=OUT/'execution';EXEC.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
argv=[sys.executable,str(OUT/'publish.py')]
r={'schema':1,'scope':'Stage46 terminal regression publication only; no reacquisition/build/evaluator/test execution.','startedUtc':now(),'parentPid':os.getpid(),'argv':argv,'cwd':str(MAIN),'python':sys.executable,'pythonSha256':sha(Path(sys.executable)),'publisherSha256':sha(OUT/'publish.py'),'terminal':False}
(EXEC/'report.json').write_text(json.dumps(r,indent=2)+'\n')
with(EXEC/'stdout.bin').open('wb')as stdout,(EXEC/'stderr.bin').open('wb')as stderr:
 p=subprocess.Popen(argv,cwd=MAIN,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
 (EXEC/'active.json').write_text(json.dumps({'pid':p.pid,'argv':argv},indent=2)+'\n')
 code=p.wait()
r.update(exitCode=code,terminal=True,finishedUtc=now(),stdoutSha256=sha(EXEC/'stdout.bin'),stderrSha256=sha(EXEC/'stderr.bin'),sourceUnchanged=sha(OUT/'publish.py')==r['publisherSha256'])
(EXEC/'report.json').write_text(json.dumps(r,indent=2)+'\n')
print('PUBLICATION TERMINAL',code,flush=True)
raise SystemExit(code)
