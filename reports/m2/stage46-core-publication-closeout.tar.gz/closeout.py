"""Package the terminal publication and independent readback records."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
MAIN = OUT.parents[2]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
save = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
assert load(OUT / 'execution.json')['actualExitCode'] == 0
assert load(OUT / 'verification-execution.json')['actualExitCode'] == 0
index = load(OUT / 'archive-index.json')
assert load(OUT / 'independent-verification.json')['archiveIndexSha256'] == sha(OUT / 'archive-index.json')
names = ['publish.py', 'verify_archives.py', 'closeout.py', 'archive-index.json', 'commands.json',
         'originals-before.json', 'originals-after.json', 'stdout.bin', 'stderr.bin', 'execution.json',
         'verification.stdout.bin', 'verification.stderr.bin', 'independent-verification.json', 'verification-execution.json']
for row in load(OUT / 'commands.json'):
    names.extend([row['name'] + '.stdout.bin', row['name'] + '.stderr.bin'])
assert len(names) == len(set(names))
gathered = OUT / 'gathered/publication-closeout'
gathered.mkdir()
mapping = []
for name in names:
    source = OUT / name; shutil.copyfile(source, gathered / name)
    assert sha(source) == sha(gathered / name)
    mapping.append({'source': str(source), 'path': name, 'bytes': source.stat().st_size, 'sha256': sha(source)})
shutil.copyfile(MAIN / 'tools/evidence.py', gathered / 'evidence.py')
save(gathered / 'PUBLICATION-SOURCES.json', {'scope': 'Terminal packaging records and independent readback, distinct from original producer seals. This current closeout create/verify output and final handoff index are necessarily external to avoid a circular digest.', 'files': mapping})
destination = OUT / 'stage46-core-publication-closeout.tar.gz'
commands = []
for action, args in [('create', [str(gathered), str(destination)]), ('verify', [str(destination)])]:
    argv = [sys.executable, str(MAIN / 'tools/evidence.py'), action, *args]
    out, err = OUT / f'closeout-{action}.stdout.bin', OUT / f'closeout-{action}.stderr.bin'
    with out.open('wb') as stdout, err.open('wb') as stderr:
        result = subprocess.run(argv, cwd=MAIN, stdout=stdout, stderr=stderr)
    commands.append({'argv': argv, 'exitCode': result.returncode, 'stdoutSha256': sha(out), 'stderrSha256': sha(err)})
    assert result.returncode == 0
with tarfile.open(destination, 'r:gz') as archive:
    members = archive.getmembers(); lookup = {m.name: m for m in members}
    assert len(lookup) == len(members)
    inventory = json.load(archive.extractfile(lookup['EVIDENCE.json']))
    assert {r['path'] for r in inventory['files']} == set(lookup) - {'EVIDENCE.json'}
    for row in inventory['files']:
        data = archive.extractfile(lookup[row['path']]).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    for row in mapping:
        assert sha(Path(row['source'])) == row['sha256']
closeout = {'group': 'publication-closeout', 'path': str(destination), 'sha256': sha(destination),
            'compressedBytes': destination.stat().st_size, 'payloadFiles': len(inventory['files']), 'commands': commands}
assert closeout['compressedBytes'] < 100_000_000
handoff = {'scope': index['scope'], 'coreArchiveIndexSha256': sha(OUT / 'archive-index.json'),
           'independentVerificationSha256': sha(OUT / 'independent-verification.json'),
           'publicationActualExitCode': 0, 'publicationToolSessionId': load(OUT / 'execution.json')['toolSessionId'],
           'independentReadbackActualExitCode': 0, 'independentReadbackToolSessionId': load(OUT / 'verification-execution.json')['toolSessionId'],
           'archives': index['archives'] + [closeout], 'archiveCount': len(index['archives']) + 1,
           'totalCompressedBytes': index['totalCompressedBytes'] + closeout['compressedBytes'],
           'producerOriginalFiles': index['producerOriginalFiles'], 'producerOriginalBytes': index['producerOriginalBytes'],
           'rawOriginals': index['rawPayloadFiles'], 'gitMappedOriginals': index['gitMappedFiles'],
           'originalChanges': [], 'selectionRoots': 57, 'bRootsDisjoint': 83,
           'producerSeals': 'Historical original closure-null and browser provenance qualifications remain unchanged. These archives are current publication seals, not retrospective acquisition seals.',
           'fullSelectedRegressionExcluded': True, 'hostedCiClaimed': False, 'fullM2Complete': False,
           'publicGitOrReportsMutations': []}
save(OUT / 'handoff.json', handoff)
print(json.dumps({'handoffSha256': sha(OUT / 'handoff.json'), 'archiveCount': handoff['archiveCount'], 'compressedBytes': handoff['totalCompressedBytes'], 'closeoutSha256': sha(destination)}))
