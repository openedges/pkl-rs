"""Independent archive/path/raw-byte and source-restoration-map readback."""
from pathlib import Path
import hashlib
import json
import os
import stat
import tarfile
import time

OUT = Path(__file__).resolve().parent
MAIN = OUT.parents[2]
SELECT = MAIN / 'target/m2/stage46-core-publication-selection-01'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
started = time.time()
index = load(OUT / 'archive-index.json')
terminal = load(OUT / 'execution.json')
assert terminal['actualExitCode'] == 0 and terminal['archiveIndexSha256'] == sha(OUT / 'archive-index.json')
expected = {}
for name in ['original-files.jsonl', 'closeout-files.jsonl']:
    for line in (SELECT / name).open():
        row = json.loads(line); assert row['absolutePath'] not in expected
        expected[row['absolutePath']] = row
assert len(expected) == 176228
bindings_path = MAIN.parent / 'pkl-rs.stage46/target/m2/stage46-index-binding-03/file-bindings.json'
bindings = load(bindings_path)
assert sha(bindings_path) == load(SELECT / 'git-source-binding.json')['producerFileBindingsSha256']
seen, archives = set(), []
payload_files = payload_bytes = raw_originals = git_originals = 0
for entry in index['archives']:
    path = Path(entry['path'])
    assert sha(path) == entry['sha256'] and path.stat().st_size == entry['compressedBytes'] < 100_000_000
    with path.open('rb') as stream:
        header = stream.read(10)
    assert header[:3] == b'\x1f\x8b\x08' and header[4:8] == b'\0\0\0\0'
    with tarfile.open(path, 'r:gz') as archive:
        members = archive.getmembers(); names = [m.name for m in members]
        assert len(names) == len(set(names)) and 'EVIDENCE.json' in names
        assert all(m.isfile() and m.mode == 0o644 and m.mtime == 0 and m.uid == m.gid == 0
                   and not m.uname and not m.gname and not Path(m.name).is_absolute()
                   and '..' not in Path(m.name).parts for m in members)
        lookup = {m.name: m for m in members}
        manifest = json.load(archive.extractfile(lookup['EVIDENCE.json']))
        declared = manifest['files']
        assert {r['path'] for r in declared} == set(names) - {'EVIDENCE.json'}
        assert len(declared) == len({r['path'] for r in declared})
        for row in declared:
            member = lookup[row['path']]
            data = archive.extractfile(member).read()
            assert len(data) == row['bytes'] == member.size
            assert hashlib.sha256(data).hexdigest() == row['sha256']
            payload_files += 1; payload_bytes += len(data)
        if entry['group'] != 'selection-metadata':
            source_rows = [json.loads(line) for line in archive.extractfile(lookup['ORIGINAL-SOURCES.jsonl'])]
            raw_members = set()
            assert len(source_rows) == entry['originalFiles']
            for row in source_rows:
                original = expected[row['absolutePath']]
                assert row['absolutePath'] not in seen
                seen.add(row['absolutePath'])
                assert all(row[k] == v for k, v in original.items())
                if row['storage'] == 'raw-payload':
                    raw_originals += 1
                    member = row['archiveMember']; assert member.startswith('payload/')
                    assert member not in raw_members; raw_members.add(member)
                    content = archive.extractfile(lookup[member]).read()
                    assert len(content) == row['bytes'] and hashlib.sha256(content).hexdigest() == row['sha256']
                else:
                    git_originals += 1
                    bound = bindings[row['repositoryPath']]
                    assert row['gitBlob'] == bound['gitBlob'] and row['repository'] == bound['repository']
                    assert row['gitMode'] == bound['gitMode'] and row['sha256'] == bound['gitBlobSha256']
                    assert row['bytes'] == bound['blobSize']
                    assert row['commitOrPin'] == (bound['pin'] if bound['repository'] != '.' else 'a3eb3634558cef6f36189320498fe7e013296c48')
            assert raw_members == {n for n in names if n.startswith('payload/')}
        else:
            for name, digest in load(SELECT / 'final-selection-closure.json').items():
                assert hashlib.sha256(archive.extractfile(lookup[name]).read()).hexdigest() == digest
            for name in ['original-files.jsonl', 'closeout-files.jsonl', 'final-selection-closure.json']:
                assert hashlib.sha256(archive.extractfile(lookup[name]).read()).hexdigest() == sha(SELECT / name)
        archives.append({'group': entry['group'], 'payloadFiles': len(declared), 'payloadBytes': sum(r['bytes'] for r in declared)})
    print('Independent readback', entry['group'], flush=True)
assert seen == set(expected)
assert raw_originals == index['rawPayloadFiles'] and git_originals == index['gitMappedFiles']
# Independently rehash every original, not just the staged/gathered copies.
cache = {}
for path, row in expected.items():
    p = Path(path); info = p.lstat()
    assert stat.S_IMODE(info.st_mode) == row['mode']
    if row['kind'] == 'symlink':
        assert p.is_symlink()
        content = os.fsencode(os.readlink(p))
        assert len(content) == row['bytes'] and hashlib.sha256(content).hexdigest() == row['sha256']
    else:
        assert stat.S_ISREG(info.st_mode) and info.st_size == row['bytes']
        key = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)
        if key not in cache:
            cache[key] = sha(p)
        assert cache[key] == row['sha256'], path
assert load(OUT / 'originals-before.json') == load(OUT / 'originals-after.json')
assert all(c['exitCode'] == 0 for c in load(OUT / 'commands.json'))
report = {'scope': 'Independent readback only; no evaluator, test, Java, build, platform or Git mutation.',
          'archiveIndexSha256': sha(OUT / 'archive-index.json'), 'archiveCount': len(archives),
          'declaredArchivePayloadsVerified': payload_files, 'declaredArchivePayloadBytes': payload_bytes,
          'archiveEvidenceInventoriesVerified': len(archives), 'allHeaderMetadataDeterministic': True,
          'originalsRehashed': len(expected), 'rawOriginalsVerified': raw_originals,
          'gitSourceMappingsVerified': git_originals, 'allOriginalsCoveredExactlyOnce': True,
          'originalHashModeKindChanges': [], 'beforeAfterOriginalPathSetsEqual': True,
          'compressedBytes': index['totalCompressedBytes'],
          'maxArchiveBytes': max(r['compressedBytes'] for r in index['archives']),
          'findings': [], 'archives': archives, 'seconds': time.time() - started,
          'qualification': 'Original producer closure-null/internal failure/publication01 size-boundary records remain preserved, not relabeled. Core/full selected regression and M2 completion are separate scopes. No final publication/Git commitment is claimed.'}
(OUT / 'independent-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'reportSha256': sha(OUT / 'independent-verification.json'), **{k: report[k] for k in ['archiveCount', 'declaredArchivePayloadsVerified', 'originalsRehashed', 'maxArchiveBytes']}}), flush=True)
