"""Gather explicit selected payloads and package them with existing evidence.py."""
from pathlib import Path
import collections
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
MAIN = OUT.parents[2]
ROOT = MAIN.parent / 'pkl-rs.stage46'
SELECT = MAIN / 'target/m2/stage46-core-publication-selection-01'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
save = lambda p, d: p.write_text(json.dumps(d, indent=2) + '\n')
assert not (OUT / 'archive-index.json').exists(), 'Preserve prior publication.'
started = time.time()
rows = []
for name in ['original-files.jsonl', 'closeout-files.jsonl']:
    with (SELECT / name).open() as stream:
        rows.extend(json.loads(line) for line in stream)
assert len(rows) == load(SELECT / 'final-selection-report.json')['totalOriginalFiles'] == 176228
assert len({r['absolutePath'] for r in rows}) == len(rows)
selection_hashes = {p.name: sha(p) for p in SELECT.iterdir() if p.is_file()}
groups = collections.defaultdict(list)
for row in rows:
    groups[row['group']].append(row)
assert sum(r['bytes'] for r in rows) == 22213858964
# Split the large historical check group at producer-directory boundaries.
# The failed publication01 is preserved, including its valid oversized archive.
history = groups.pop('implementation-checks-proposals')
units = collections.defaultdict(list)
for row in history:
    units[Path(row['path']).parts[0]].append(row)
parts, current, size = [], [], 0
for _, unit in sorted(units.items()):
    unit_size = sum(r['bytes'] for r in unit if r['storage'] == 'raw-payload')
    assert unit_size < 32 * 1024 * 1024
    if current and size + unit_size > 32 * 1024 * 1024:
        parts.append(current); current, size = [], 0
    current.extend(unit); size += unit_size
if current:
    parts.append(current)
for i, part in enumerate(parts, 1):
    groups[f'implementation-checks-proposals-{i:02d}'] = part


def recheck_originals():
    # Exact original path lists only, with inode-keyed repeated hardlink reads.
    cache = {}
    for row in rows:
        p = Path(row['absolutePath']); s = p.lstat()
        assert stat.S_IMODE(s.st_mode) == row['mode']
        if row['kind'] == 'symlink':
            assert stat.S_ISLNK(s.st_mode)
            data = os.fsencode(os.readlink(p)); assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        else:
            assert stat.S_ISREG(s.st_mode) and s.st_size == row['bytes']
            key = (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
            if key not in cache:
                cache[key] = sha(p)
            assert cache[key] == row['sha256'], str(p)
    # Non-snapshot selected pathsets are rechecked; exact-map source directories
    # remain pruned and are reconstructed from the authoritative producer maps.
    prune = load(SELECT / 'prewalk-prunes.json')
    excluded = set(prune['cacheDirectories']) | set(prune['explicitMapSourceDirectories'])
    expected = {r['absolutePath'] for r in rows}
    for root_name in load(SELECT / 'selected-roots.json')['roots']:
        root = Path(root_name); actual = set()
        def walk(directory):
            with os.scandir(directory) as entries:
                for entry in entries:
                    p = directory / entry.name
                    if str(p) in excluded:
                        continue
                    if entry.is_dir(follow_symlinks=False) and not entry.is_symlink():
                        walk(p)
                    else:
                        actual.add(str(p))
        walk(root)
        for snapshot, map_path in prune['explicitMapSourceDirectories'].items():
            snap = Path(snapshot)
            if root in snap.parents:
                actual.update(str(snap / name) for name in load(Path(map_path)))
        assert actual == {p for p in expected if p.startswith(str(root) + '/')}, str(root)
    assert all(sha(SELECT / n) == h for n, h in selection_hashes.items())
    return {'originalFilesRehashed': len(rows), 'originalBytes': sum(r['bytes'] for r in rows),
            'originalPathSetsRechecked': True, 'hashModeKindChanges': [], 'selectionMetadataChanges': []}


print('Rechecking exact originals before gathering', flush=True)
before = recheck_originals()
save(OUT / 'originals-before.json', before)
commands = []


def command(name, argv):
    stdout, stderr = OUT / (name + '.stdout.bin'), OUT / (name + '.stderr.bin')
    t = time.time()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        result = subprocess.run(argv, cwd=MAIN, stdout=out, stderr=err)
    row = {'name': name, 'argv': argv, 'exitCode': result.returncode, 'seconds': time.time() - t,
           'stdoutSha256': sha(stdout), 'stderrSha256': sha(stderr)}
    commands.append(row); save(OUT / 'commands.json', commands)
    assert result.returncode == 0, name


def label(row):
    root = Path(row['root'])
    return ('main--' if root == MAIN or MAIN in root.parents else 'stage46--') + (root.name if root != MAIN else 'repository-draft')


archives = []
for group, entries in sorted(groups.items()):
    gathered = OUT / 'gathered' / group
    gathered.mkdir(parents=True)
    mapped = []
    for original in sorted(entries, key=lambda r: r['absolutePath']):
        row = dict(original)
        if row['storage'] == 'raw-payload':
            relative = Path(row['path'])
            assert not relative.is_absolute() and '..' not in relative.parts
            name = 'payload/' + label(row) + '/' + relative.as_posix()
            if row['kind'] == 'symlink':
                name += '.link-target.bin'
            target = gathered / name
            target.parent.mkdir(parents=True, exist_ok=True)
            if row['kind'] == 'symlink':
                target.write_bytes(bytes.fromhex(row['linkTargetHex']))
            else:
                shutil.copyfile(row['absolutePath'], target)
            assert sha(target) == row['sha256'] and target.stat().st_size == row['bytes']
            row['archiveMember'] = name
        else:
            assert row['storage'] == 'git-source-map'
            row['restoration'] = 'Read exact gitBlob from repository at commitOrPin, verify length/SHA256, restore original mode/path. No checkout transformations.'
        mapped.append(row)
    (gathered / 'ORIGINAL-SOURCES.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in mapped))
    save(gathered / 'PUBLICATION.json', {
        'scope': 'This group preserves original raw payloads and exact byte-verified Git source restoration maps. Original producer seals/terminal gaps retain their own scope; this archive does not retroactively seal them.',
        'group': group, 'originalFiles': len(entries), 'originalBytes': sum(r['bytes'] for r in entries),
        'rawPayloadFiles': sum(r['storage'] == 'raw-payload' for r in entries),
        'gitMappedFiles': sum(r['storage'] == 'git-source-map' for r in entries),
        'commit': 'a3eb3634558cef6f36189320498fe7e013296c48',
        'sourceBinding': load(SELECT / 'git-source-binding.json'),
        'originalModes': 'The deterministic archive uses regular-file mode0644. ORIGINAL-SOURCES.jsonl retains exact original kind/mode, including executable artifact modes; restore these when reconstructing originals.',
        'historicalBoundaries': load(SELECT / 'selection-report.json')['preservedBoundaries'],
    })
    destination = OUT / f'stage46-core-{group}.tar.gz'
    command(group + '-create', [sys.executable, str(MAIN / 'tools/evidence.py'), 'create', str(gathered), str(destination)])
    command(group + '-verify', [sys.executable, str(MAIN / 'tools/evidence.py'), 'verify', str(destination)])
    assert destination.stat().st_size < 48 * 1024 * 1024, 'Keep all groups below48MiB; split a larger logical group into new named partitions before publishing.'
    archives.append({'group': group, 'path': str(destination), 'sha256': sha(destination),
                     'compressedBytes': destination.stat().st_size,
                     'originalFiles': len(entries), 'rawPayloadFiles': sum(r['storage'] == 'raw-payload' for r in entries),
                     'gitMappedFiles': sum(r['storage'] == 'git-source-map' for r in entries)})
    print('Packaged', group, destination.stat().st_size, flush=True)

# Capture the full selection/closure/methodology separately from producer groups.
group = 'selection-metadata'; gathered = OUT / 'gathered' / group; gathered.mkdir(parents=True)
for name, digest in selection_hashes.items():
    shutil.copyfile(SELECT / name, gathered / name)
    assert sha(gathered / name) == digest
shutil.copyfile(MAIN / 'tools/evidence.py', gathered / 'evidence.py')
shutil.copyfile(Path(__file__), gathered / 'publish.py')
failed = MAIN / 'target/m2/stage46-core-publication-01'
failure_files = ['publish.py', 'stdout.bin', 'stderr.bin', 'commands.json', 'originals-before.json', 'execution.json']
for row in load(failed / 'commands.json'):
    failure_files.extend([row['name'] + '.stdout.bin', row['name'] + '.stderr.bin'])
for name in failure_files:
    target = gathered / 'failed-publication-01' / name
    target.parent.mkdir(exist_ok=True)
    shutil.copyfile(failed / name, target)
save(gathered / 'failed-publication-01/archive-disposition.json', {
    'scope': 'Initial valid archives remain preserved at their original target paths. They are not duplicated inside a compressed archive because the final logical partitions reproduce all of their selected originals and retain the size-limit failure raw logs.',
    'originalArchives': load(failed / 'execution.json')['preservedArchives'],
})
destination = OUT / f'stage46-core-{group}.tar.gz'
command(group + '-create', [sys.executable, str(MAIN / 'tools/evidence.py'), 'create', str(gathered), str(destination)])
command(group + '-verify', [sys.executable, str(MAIN / 'tools/evidence.py'), 'verify', str(destination)])
assert destination.stat().st_size < 48 * 1024 * 1024
archives.append({'group': group, 'path': str(destination), 'sha256': sha(destination), 'compressedBytes': destination.stat().st_size})
print('Rechecking exact originals after packaging', flush=True)
after = recheck_originals()
save(OUT / 'originals-after.json', after)
assert before == after
index = {'scope': 'Stage46 core/platform evidence archives; full language/persistent regression is excluded and remains separate. No hosted CI, whole M2/platform/performance completion claim.',
         'archives': archives, 'producerOriginalFiles': len(rows), 'producerOriginalBytes': sum(r['bytes'] for r in rows),
         'rawPayloadFiles': sum(r['storage'] == 'raw-payload' for r in rows),
         'gitMappedFiles': sum(r['storage'] == 'git-source-map' for r in rows),
         'totalCompressedBytes': sum(r['compressedBytes'] for r in archives),
         'allArchivesUnder48MiB': True, 'originalChanges': [], 'originalPathsetsUnchanged': True,
         'selectionClosureSha256': sha(SELECT / 'final-selection-closure.json'),
         'commandsSha256': sha(OUT / 'commands.json'), 'commandsAllZero': True, 'seconds': time.time() - started}
save(OUT / 'archive-index.json', index)
print(json.dumps({'archives': len(archives), 'totalCompressedBytes': index['totalCompressedBytes'], 'indexSha256': sha(OUT / 'archive-index.json')}), flush=True)
