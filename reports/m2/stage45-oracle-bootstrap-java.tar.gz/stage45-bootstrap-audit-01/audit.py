from pathlib import Path
import json,hashlib,collections
A=Path(__file__).resolve().parent;B=A.parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();roots={};verified=0
for suffix in ['01','02']:
 root=B/('stage45-bootstrap-oracle-'+suffix);cl=json.loads((root/'closure.json').read_text());assert cl['closed']and not cl['liveHandles'];assert sha(root/'report.json')==cl['reportSha256']and sha(root/'inventory.json')==cl['inventorySha256'];inventory=json.loads((root/'inventory.json').read_text())
 for row in inventory['files']:
  p=root/row['path'];assert p.stat().st_size==row['bytes']and sha(p)==row['sha256'];verified+=1
 report=json.loads((root/'report.json').read_text());assert not report['inputChanges'];assert not any(r['allRawPaths']for r in report['repeatDifferences']);assert all(p['result']['exit_code']==0 and not p['result']['timed_out']for p in report['records']);assert report['outerCallCount']==600
 for observation in report['observations']:
  for call in observation['calls']:
   channel='stdout'if call['status']=='success\n'else'stderr';opposite='stderr'if channel=='stdout'else'stdout';raw=root/(call['rawPrefix']+'.'+channel+'.bin');units=root/(call['rawPrefix']+'.'+channel+'.code-units.bin');assert sha(raw)==call['utf8Sha256']and sha(units)==call['utf16BESha256'];assert raw.read_bytes().hex()==call['utf8Hex']and units.read_bytes().hex()==call['utf16BEHex'];assert not(root/(call['rawPrefix']+'.'+opposite+'.bin')).read_bytes()and not(root/(call['rawPrefix']+'.'+opposite+'.code-units.bin')).read_bytes()
 roots[suffix]=(root,report)
root,r=roots['02'];comparisons=0
for reader_case in ['json','invalid-bootstrap-format']:
 for repeat in range(2):
  x=next(o for o in r['observations']if o['case']=='builtin-'+reader_case and o['repeat']==repeat);y=next(o for o in r['observations']if o['case']=='counted-'+reader_case and o['repeat']==repeat);assert len(x['calls'])==len(y['calls'])==75
  for l,q in zip(x['calls'],y['calls']):
   assert l['session']==q['session']and l['format']==q['format']and l['expression']==q['expression']
   for suffix in ['expression.bin','status.bin','stdout.bin','stderr.bin','stdout.code-units.bin','stderr.code-units.bin','error-class.bin','message-null.bin']:
    assert(root/(l['rawPrefix']+'.'+suffix)).read_bytes()==(root/(q['rawPrefix']+'.'+suffix)).read_bytes();comparisons+=1
observed={}
for expression in ['b.output.renderer.getClass()','b.output.text','b.ModuleInfo == ModuleInfo','new base.ModuleInfo { minPklVersion = "0.32.0" }.getClass() == ModuleInfo','r.Module(b).annotations.length','r.Module(t).annotations.length','r.Module(b).annotations[0].minPklVersion','r.Module(t).annotations[0].minPklVersion']:
 calls=[c for o in r['observations']for c in o['calls']if c['expression']==expression];observed[expression]={'calls':len(calls),'rawResults':list(dict.fromkeys((c['status'],c['utf8Hex'],c['utf16BEHex'])for c in calls))}
result={'passed':True,'verifiedPayloadFiles':verified,'verifiedRawApiCalls':1200,'builtInVsCountedApiChannelPairs':comparisons,'sameReaderAndOrderProfilesPreserveAllApiBytes':True,'originalLexicalAliasBoundaryPreserved':True,'observedInvariantPayloads':observed,'oracle02ReportSha256':sha(root/'report.json'),'scope':'Java evidence integrity and control equivalence only; not Rust compatibility. Caller callback counts/events are deliberately separate instrumented Host observations, not normalized API bytes.'};(A/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='observedInvariantPayloads'},indent=2))
