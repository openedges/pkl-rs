"""Publish already recorded additive Java authority and offline validation."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'reports/m2/stage56-metadata-validation-evidence.tar.gz'
CHECKPOINT = ROOT / 'reports/m2/stage56-metadata-oracle-checkpoint.json'
SEAL = ROOT / 'target/m2/stage56-class-metadata-publication-01/source-seal.json'
VALIDATION = ROOT / 'target/m2/stage56-class-metadata-verification-01/report.json'


def identity(data):
    return dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()


seal = json.loads(SEAL.read_bytes())
validation = json.loads(VALIDATION.read_bytes())
assert not ARCHIVE.exists() and not CHECKPOINT.exists()
assert len(seal['files']) == 10
for name, expected in seal['files'].items():
    assert identity((ROOT / name).read_bytes()) == expected, name
for check in validation['checks'].values():
    process = check['process']
    assert process['exit_code'] == 0
    for channel in ['stdout', 'stderr']:
        entry = process[channel]
        assert identity((ROOT / entry['path']).read_bytes()) == {
            key: entry[key] for key in ['sha256', 'bytes']
        }

paths = {}
for folder in ['stage56-class-metadata-verification-01',
               'stage56-class-metadata-publication-01']:
    for path in sorted((ROOT / 'target/m2' / folder).rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            paths['evidence/' + path.relative_to(ROOT).as_posix()] = path
canonical_name = 'tests/fixtures/m2-class-metadata-completion/oracle-evidence.tar.gz'
for name in seal['files']:
    if name != canonical_name:
        paths['owned-sources/' + name] = ROOT / name
paths['publish.py'] = Path(__file__)
payloads = {name: identity(path.read_bytes()) for name, path in paths.items()}
manifest = dict(schema=1, files=payloads, canonical_authority=dict(
    path=canonical_name, **seal['files'][canonical_name]),
    scope='Local Java-only authority and original offline validation. No guest, test, candidate, Cargo or performance reruns during publication.',
    original_outputs_modified=False, candidate_compatibility_claimed=False)
(OUT / 'manifest.json').write_bytes(encode(manifest))
ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
with ARCHIVE.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as stream:
            for name in ['manifest.json', *sorted(payloads)]:
                data = (OUT / 'manifest.json').read_bytes() if name == 'manifest.json' else paths[name].read_bytes()
                if name != 'manifest.json':
                    assert identity(data) == payloads[name]
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                stream.addfile(info, io.BytesIO(data))

seen = set()
with tarfile.open(ARCHIVE, 'r:gz') as stream:
    for member in stream:
        assert member.isreg() and member.name not in seen
        assert not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        seen.add(member.name)
        data = stream.extractfile(member).read()
        if member.name == 'manifest.json':
            assert data == encode(manifest)
        else:
            assert identity(data) == payloads[member.name]
assert seen == {'manifest.json', *payloads}
for name, path in paths.items():
    assert identity(path.read_bytes()) == payloads[name]
for name, expected in seal['files'].items():
    assert identity((ROOT / name).read_bytes()) == expected

checkpoint = dict(schema=1, stage=56,
    kind='Additive Java base-class metadata authority checkpoint',
    recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope=validation['scope'], baseline='Pkl 0.32.0',
    reference_revision='e51fb2f91774265666f94980ec630db794a4db2d',
    original_authority_commit='31eef43ad2473e8977d7844c4fa5af087392072c',
    fixture='tests/fixtures/m2-class-metadata-completion',
    original_fixture_preserved=seal['original_fixture_preserved'],
    canonical_authority=manifest['canonical_authority'],
    canonical_raw_member_count=seal['published_member_count'],
    observed_main=validation['main_java'],
    preserved_initial=validation['preserved_initial_java'],
    validation=validation, owned_payloads=seal['files'],
    source_seal=dict(path=SEAL.relative_to(ROOT).as_posix(), **identity(SEAL.read_bytes())),
    publication=dict(archive=ARCHIVE.relative_to(ROOT).as_posix(),
        **identity(ARCHIVE.read_bytes()), payload_count=len(payloads),
        all_members_reread_verified=True, all_original_outputs_unchanged=True,
        canonical_raw_archive_not_duplicated=True),
    source_binding='Pending actual authorized Java supplement commit; publish a separate post-commit binding without rewriting this record.',
    provider_api_parity='not-executed-required',
    public_exports='not-acquired-required',
    whole_m2_complete=False, candidate_compatibility_claimed=False,
    performance_claimed=False, hosted_CI_claimed=False)
CHECKPOINT.write_bytes(encode(checkpoint))
(OUT / 'report.json').write_bytes(encode(dict(
    checkpoint=dict(path=CHECKPOINT.relative_to(ROOT).as_posix(), **identity(CHECKPOINT.read_bytes())),
    archive=checkpoint['publication'])))
print((OUT / 'report.json').read_text())
