"""Seal closed concurrent-acquisition evidence from the isolated worktree and main."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
WORKTREE = ROOT.with_name('pkl-rs.stage36')
check = ROOT / 'target/m2/stage36-tooling-checkpoint-01'
assert json.loads((check / 'report.json').read_bytes())['passed']
origins = [('main', check)] + [('worktree', WORKTREE / 'target/m2' / name) for name in [
    'stage36-concurrent-acquisition-01', 'stage36-concurrent-acquisition-02',
    'stage36-concurrent-tool-freeze-01', 'stage36-concurrent-tool-validation-01']]
staging = ROOT / 'target/m2-evidence-stage36-tooling-01'
staging.mkdir(exist_ok=False)
files = []
for prefix, origin in origins:
    # These explicit closed capture roots contain no Cargo or dependency caches.
    for folder, dirs, names in os.walk(origin):
        assert not any((Path(folder) / name).is_symlink() for name in dirs)
        for name in names:
            source = Path(folder) / name
            assert source.is_file() and not source.is_symlink()
            relative = Path(prefix) / origin.name / source.relative_to(origin)
            destination = staging / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            os.link(source, destination)
            files.append(dict(source=str(source), archived=str(relative),
                              sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
(staging / 'seal.py').write_bytes(Path(__file__).read_bytes())
(staging / 'ORIGINS.json').write_text(json.dumps(files, indent=2) + '\n')
archive = ROOT / 'reports/m2/stage36-tooling-evidence.tar.gz'
assert not archive.exists()
subprocess.run([sys.executable, 'tools/evidence.py', 'create', str(staging), str(archive)], cwd=ROOT, check=True)
assert all(hashlib.sha256(Path(row['source']).read_bytes()).hexdigest() == row['sha256'] for row in files)
with tarfile.open(archive) as stream:
    inventory = json.load(stream.extractfile('EVIDENCE.json'))
    hashes = {row['path']: row['sha256'] for row in inventory['files']}
    assert all(hashes[row['archived']] == row['sha256'] for row in files)
verification = json.loads((check / 'report.json').read_bytes())
comparison = json.loads((WORKTREE / 'target/m2/stage36-concurrent-acquisition-02/report.json').read_bytes())
assert comparison['all_raw_pairs_equal'] and comparison['status_order_equal'] and comparison['source_stability']
comparison_root = WORKTREE / 'target/m2/stage36-concurrent-acquisition-02'
for identifier in comparison['selected_ids']:
    serial = comparison_root / 'serial/cases' / identifier
    parallel = comparison_root / 'parallel/cases' / identifier
    captures = {path.relative_to(serial) for path in serial.rglob('*.bin')}
    assert captures == {path.relative_to(parallel) for path in parallel.rglob('*.bin')}
    assert all((serial / path).read_bytes() == (parallel / path).read_bytes() for path in captures)
verification['python_tests'] = int(re.search(r'Ran (\d+) tests', (check / 'python.stderr.bin').read_text()).group(1))
report = dict(scope='Optional concurrent M2 language acquisition; shared runtime unchanged.',
    default_workers=1, maximum_workers=32,
    guarantees=['Fresh Java and Rust process per case with unchanged pinned options.',
                'Independent capture directories and manifest-order reporting.',
                'Raw mismatch, timeout, oracle-error and repeated remainder capture retained.',
                'Existing two-argument execute API and older report verification retained.'],
    verification=verification,
    fresh_serial_parallel=dict(cases=comparison['selected_ids'], statuses=comparison['statuses'],
                               all_raw_pairs_equal=True, execution_settings=comparison['execution_settings'],
                               candidate=comparison['baseline']),
    preserved_failures=['First integration driver used an invalid existing case ID; its assertion failure is retained.',
                       'Worktree full Python run retained three stale-manifest errors while runtime integration was ongoing; main verification used its current unchanged language manifest.',
                       'Original integration report inventories run.log before its closing summary. The closed supplemental inventory records that sole changed file; original report remains unchanged.'],
    archive=dict(path=str(archive.relative_to(ROOT)), bytes=archive.stat().st_size,
                 sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                 original_files=len(files), inventory_files=len(inventory['files']), source_stability=True),
    compatibility_complete=False, runtime_performance_claimed=False)
(ROOT / 'reports/m2/stage36-tooling-checkpoint.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(archive=report['archive'], checks_passed=verification['passed'])))
