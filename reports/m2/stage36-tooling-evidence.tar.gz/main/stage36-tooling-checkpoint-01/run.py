"""Capture the independent concurrent-acquisition tooling checks."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
names = ['tools/m2_language.py', 'tools/tests/test_m2_language.py',
         'tools/m2_manifest.py', 'compatibility/m2-language.json',
         'docs/m2-language.md', 'oracle.lock.json', 'references.lock']
sources = {}
for name in names:
    data = (ROOT / name).read_bytes()
    path = OUT / 'sources' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    sources[name] = hashlib.sha256(data).hexdigest()
checks = []
for name, command in [
    ('python', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-v']),
    ('manifest', [sys.executable, 'tools/m2_manifest.py', '--check']),
    ('diff', ['git', 'diff', '--check']),
]:
    process = subprocess.run(command, cwd=ROOT, capture_output=True)
    (OUT / (name + '.stdout.bin')).write_bytes(process.stdout)
    (OUT / (name + '.stderr.bin')).write_bytes(process.stderr)
    row = dict(name=name, command=command, exit_code=process.returncode,
               stdout_sha256=hashlib.sha256(process.stdout).hexdigest(),
               stderr_sha256=hashlib.sha256(process.stderr).hexdigest())
    checks.append(row)
    (OUT / (name + '.process.json')).write_text(json.dumps(row, indent=2) + '\n')
    print(name, process.returncode, flush=True)
stable = all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
             for name, digest in sources.items())
report = dict(scope='Concurrent acquisition tooling checks; no runtime performance claim.',
              host=platform.platform(), python=sys.version, sources=sources,
              checks=checks, source_stability=stable,
              passed=stable and all(row['exit_code'] == 0 for row in checks))
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
sys.exit(0 if report['passed'] else 1)
