"""Capture the actual later read-only checkpoint verification process boundary."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
VERIFY = OUT / 'verify.py'
GROUPS = ('validation', 'native', 'platform', 'closeout')
INPUTS = [
    'target/m2/stage62-checkpoint-verification-01/run.py',
    'target/m2/stage62-checkpoint-verification-01/verify.py',
    'target/m2/stage62-checkpoint-01/prepare.py',
    'target/m2/stage62-publication-review-01/report.json',
    'reports/m2/stage62-implementation-checkpoint.json',
    *[f'reports/m2/stage62-{group}-{suffix}' for group in GROUPS
      for suffix in ('publication.json', 'evidence.tar.gz')],
]


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def snapshot():
    return {name: identity(ROOT / name) for name in INPUTS}


def main():
    for name in ('report.json', 'source-before.json', 'source-after.json',
                 'stdout.bin', 'stderr.bin'):
        if (OUT / name).exists():
            raise ValueError('fresh verification evidence directory required: ' + name)
    argv = [sys.executable, '-B', str(VERIFY)]
    env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
    before = snapshot()
    save('source-before.json', before)
    current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    report = {'schema': 1, 'kind': 'stage62-later-checkpoint-verification-process',
              'scope': 'Read-only verification of existing Stage62 checkpoint/publication bytes after implementation B; not original assembly execution',
              'verification_is_later': True, 'original_assembly_raw_available': False,
              'read_only': True, 'command': argv, 'cwd': str(ROOT),
              'current_head': current_head, 'host': platform.uname()._asdict(),
              'python': {'version': sys.version, 'executable': sys.executable,
                         'identity': identity(Path(sys.executable))},
              'environment': {key: env.get(key) for key in
                              ('PATH', 'HOME', 'TMPDIR', 'LANG', 'LC_ALL', 'TZ',
                               'PYTHONHASHSEED', 'PYTHONDONTWRITEBYTECODE')},
              'started_epoch': time.time(), 'complete': False,
              'source_before': before}
    save('report.json', report)
    with (OUT / 'stdout.bin').open('xb') as stdout, (OUT / 'stderr.bin').open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        report['pid'] = child.pid
        save('report.json', report)
        report['exit_code'] = child.wait()
    after = snapshot()
    save('source-after.json', after)
    summary = None
    if report['exit_code'] == 0:
        summary = json.loads((OUT / 'stdout.bin').read_bytes())
    report.update(complete=True, finished_epoch=time.time(),
                  source_after=after, source_stable=before == after,
                  stdout=identity(OUT / 'stdout.bin'),
                  stderr=identity(OUT / 'stderr.bin'),
                  checkpoint_identity=before['reports/m2/stage62-implementation-checkpoint.json'],
                  verification_summary=summary)
    save('report.json', report)
    print(json.dumps({'exit_code': report['exit_code'],
                      'source_stable': report['source_stable'],
                      'checkpoint_identity': report['checkpoint_identity'],
                      'original_assembly_raw_available': False,
                      'verification_is_later': True}, sort_keys=True))
    raise SystemExit(report['exit_code'] or int(not report['source_stable']))


if __name__ == '__main__':
    main()
