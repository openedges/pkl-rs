"""Later read-only verification of the published Stage 62 checkpoint bytes."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
CHECKPOINT = ROOT / 'reports/m2/stage62-implementation-checkpoint.json'
GROUPS = ('validation', 'native', 'platform', 'closeout')
ASSEMBLY_BASE = 'b262208ccc537af2845d2107226bb4dac0ba7ecf'
CURRENT_B = 'aac28e5b8d7a2182bc3e385410ff12228f246fb0'
CHECKPOINT_SHA = '601be8c596fcb4d77511bdc5726ab19a621ca2915d19670f5674eb3be2cfb220'


def need(condition, message):
    if not condition:
        raise ValueError(message)


def identity(path):
    path = Path(path)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


def local_path(name):
    need(isinstance(name, str), 'non-string identity path')
    rel = PurePosixPath(name)
    need(not rel.is_absolute() and '..' not in rel.parts and str(rel) == name,
         'unsafe identity path: ' + name)
    path = ROOT / name
    need(path.is_file() and not path.is_symlink(), 'missing identity file: ' + name)
    return path


def declared_identities(value):
    items = []
    def walk(node):
        if isinstance(node, dict):
            if {'path', 'bytes', 'sha256'} <= node.keys():
                items.append(node)
            for child in node.values():
                walk(child)
        elif isinstance(node, list):
            for child in node:
                walk(child)
    walk(value)
    return items


def verify_group(group, checkpoint):
    report_name = f'reports/m2/stage62-{group}-publication.json'
    archive_name = f'reports/m2/stage62-{group}-evidence.tar.gz'
    report_path, archive_path = local_path(report_name), local_path(archive_name)
    report = json.loads(report_path.read_bytes())
    report_identity = {'path': report_name, **identity(report_path)}
    archive_identity = {'path': archive_name, **identity(archive_path)}
    declared = checkpoint['evidence'][group]
    need(report_identity == declared['publication']
         and archive_identity == declared['archive']
         and report['archive']['sha256'] == archive_identity['sha256']
         and report['archive']['bytes'] == archive_identity['bytes']
         and report['archive']['members'] == declared['members']
         and declared['full_member_readback_verified'] is True,
         'publication/checkpoint identity differs: ' + group)
    inventory = report['member_inventory']
    observed = {}
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive:
            name = member.name
            rel = PurePosixPath(name)
            need(member.isfile() and name not in observed and not rel.is_absolute()
                 and '..' not in rel.parts and str(rel) == name,
                 'unsafe or duplicate archive member: ' + name)
            handle = archive.extractfile(member)
            need(handle is not None, 'unreadable archive member: ' + name)
            digest = hashlib.sha256()
            size = 0
            with handle:
                while chunk := handle.read(1024 * 1024):
                    digest.update(chunk)
                    size += len(chunk)
            observed[name] = {'bytes': size, 'mode': member.mode,
                              'sha256': digest.hexdigest()}
    need(observed == inventory and len(observed) == declared['members'],
         'full member hash readback differs: ' + group)
    return {'archive': archive_identity, 'publication': report_identity,
            'members': len(observed), 'full_member_hash_readback': True}


def main():
    current = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    need(current == CURRENT_B, 'verification HEAD is not implementation B')
    ancestor = subprocess.run(['git', 'merge-base', '--is-ancestor', ASSEMBLY_BASE, current],
                              cwd=ROOT, capture_output=True, check=False)
    need(ancestor.returncode == 0 and ancestor.stdout == ancestor.stderr == b'',
         'recorded assembly base is not ancestor of current B')
    checkpoint_identity = {'path': CHECKPOINT.relative_to(ROOT).as_posix(),
                           **identity(CHECKPOINT)}
    need(checkpoint_identity['sha256'] == CHECKPOINT_SHA
         and checkpoint_identity['bytes'] == 50057,
         'published checkpoint bytes differ')
    checkpoint = json.loads(CHECKPOINT.read_bytes())
    need(checkpoint['source_binding']['base_commit'] == ASSEMBLY_BASE
         and checkpoint['rust_validation']['base_commit'] == ASSEMBLY_BASE
         and set(checkpoint['evidence']) == set(GROUPS)
         and checkpoint['full_m2_complete'] is False
         and checkpoint['full_public_api_comparison_passed'] is False
         and checkpoint['performance_targets_achieved'] is False,
         'checkpoint base or scope differs')
    identities = declared_identities(checkpoint)
    need(len(identities) == 87, 'checkpoint identity count differs')
    for item in identities:
        observed = identity(local_path(item['path']))
        need(observed == {key: item[key] for key in ('bytes', 'sha256')},
             'checkpoint declared identity differs: ' + item['path'])
    groups = {group: verify_group(group, checkpoint) for group in GROUPS}
    review_name = 'target/m2/stage62-publication-review-01/report.json'
    review = json.loads(local_path(review_name).read_bytes())
    need(review['source_stable'] is True and review['findings'] == []
         and review['checkpoint'] == checkpoint_identity
         and review['checkpoint_referenced_identities_verified'] == 87
         and review['checkpoint_target_references_in_published_members'] == 60
         and review['archive_member_counts'] ==
         {group: groups[group]['members'] for group in GROUPS},
         'independent publication review binding differs')
    print(json.dumps({'schema': 1, 'kind': 'stage62-later-checkpoint-verification',
                      'verification_is_later': True,
                      'original_assembly_raw_available': False, 'read_only': True,
                      'current_head': current, 'recorded_assembly_base': ASSEMBLY_BASE,
                      'base_is_ancestor': True, 'checkpoint_identity': checkpoint_identity,
                      'checkpoint_declared_identities_checked': len(identities),
                      'groups': groups, 'member_readback_total': sum(
                          row['members'] for row in groups.values()),
                      'independent_review': {'path': review_name,
                                             **identity(ROOT / review_name)},
                      'limitation': 'This is a later read-only verification of existing bytes. Original checkpoint assembly stdout/stderr were not saved as local files.'},
                     sort_keys=True))


if __name__ == '__main__':
    main()
