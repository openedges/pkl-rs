"""Prepare binder03 from preserved binder02; do not execute the binder."""
from pathlib import Path
out = Path(__file__).resolve().parent
old = out.parent / 'stage62-source-binding-02'
s = (old / 'bind.py').read_text()
s = s.replace("OUT = ROOT / 'target/m2/stage62-source-binding-02'", "OUT = ROOT / 'target/m2/stage62-source-binding-03'")
s = s.replace('Root owns execution.', 'Root owns execution. Binder02 and its failed run01 are preserved.')
s = s.replace('MANIFESTS = {', '''# Exact additional source closure declared by the recorded portable captures.
# These remain outside the unchanged platform-wrapper snapshot and require
# separate actual B mode/OID/framed-blob checks; no differing bytes are allowed.
PORTABLE_CAPTURE_SPECIFIC_SOURCES = {
    'any-if-non-null': {
        'tools/java/AnyIfNonNullOracle.java',
        'tools/tests/test_any_if_non_null_fixtures.py',
        'tools/tests/test_any_if_non_null_portable_compare.py',
    },
    'data-size': {'tools/java/DataSizeSplitOracle.java'},
}
MANIFESTS = {''', 1)
s = s.replace('    portable_controls = {}', '    portable_controls = {}\n    capture_specific_observed = {}')
s = s.replace("        binding = {'source_inputs': {}, 'built_artifacts': {}, 'recorded_external_runtime_inputs': {}}", "        binding = {'source_inputs': {}, 'capture_specific_source_inputs': {},\n                   'built_artifacts': {}, 'recorded_external_runtime_inputs': {}}")
s = s.replace("""                else:
                    assert relative in manifests['platform_wrapper'], (name, relative)
                    assert expected_identity(manifests['platform_wrapper'][relative])[0] == sha
                    binding['source_inputs'][relative] = sha""", """                elif relative in manifests['platform_wrapper']:
                    assert expected_identity(manifests['platform_wrapper'][relative])[0] == sha
                    binding['source_inputs'][relative] = sha
                else:
                    assert relative in PORTABLE_CAPTURE_SPECIFIC_SOURCES.get(name, set()), (name, relative)
                    # Comparison independently copied these bytes. Its unchanged
                    # source row must also match B; this does not relabel that
                    # copy as a platform-wrapper source or permit source drift.
                    assert relative in manifests['comparison_wrapper'], (name, relative)
                    assert expected_identity(manifests['comparison_wrapper'][relative])[0] == sha
                    binding['capture_specific_source_inputs'][relative] = sha
                    capture_specific_observed.setdefault(name, set()).add(relative)""")
s = s.replace("    comparison = read_json(COMPARE + '/report.json')", "    assert capture_specific_observed == PORTABLE_CAPTURE_SPECIFIC_SOURCES\n    comparison = read_json(COMPARE + '/report.json')")
s = s.replace("    blobs = {name: git_blobs(repo, required_oids[name]) for name, repo in repositories.items()}", """    for capture in capture_controls['portable'].values():
        for name in capture['binding']['capture_specific_source_inputs']:
            entry = trees['.'].get(name)
            assert entry and entry[:2] == ('100644', 'blob'), ('capture-specific B source', name, entry)
            required_oids['.'].add(entry[2])
    blobs = {name: git_blobs(repo, required_oids[name]) for name, repo in repositories.items()}
    portable_specific_B_proofs = []
    for capture_name, capture in capture_controls['portable'].items():
        for name, sha in capture['binding']['capture_specific_source_inputs'].items():
            mode, kind, oid = trees['.'][name]
            actual = blobs['.'][oid]
            recorded = manifests['comparison_wrapper'][name]
            assert actual == {'sha256': sha, 'bytes': recorded['bytes']}, (capture_name, name)
            portable_specific_B_proofs.append({
                'capture': capture_name, 'capture_report': capture['path'], 'path': name,
                'recorded_capture_sha256': sha, 'B_mode': mode, 'B_type': kind,
                'B_oid': oid, 'B_bytes': actual['bytes'], 'B_sha256': actual['sha256'],
                'status': 'capture_specific_source_matches_B',
                'independent_copied_source_category': 'comparison_wrapper'})
    assert len(portable_specific_B_proofs) == 4""")
s = s.replace("        'capture_controls': capture_controls,", "        'capture_controls': capture_controls,\n        'portable_capture_specific_B_source_proofs': portable_specific_B_proofs,")
s = s.replace("                   'Original checkpoint assembly stdout/stderr were not saved.", "                   'Four recorded portable-capture-specific sources lie outside the platform-wrapper snapshot; each receives a separate actual B mode/OID/framed-blob SHA/size proof, and the original 36 source manifests remain unchanged.',\n                   'Original checkpoint assembly stdout/stderr were not saved.")
s = s.replace("    payloads['adapter.py'] = OUT / 'adapt.py'", """    payloads['adapter.py'] = OUT / 'adapt.py'
    for name in ('bind.py', 'preparation.json', 'layout-verified.json', 'adapt.py', 'record-preparation.py'):
        payloads['preparation-history/binder02/' + name] = ROOT / 'target/m2/stage62-source-binding-02' / name
    for name in ('run.py', 'report.json', 'source-before.json', 'source-after.json', 'stdout.bin', 'stderr.bin'):
        payloads['failed-binding-run01/' + name] = ROOT / 'target/m2/stage62-source-binding-run-01' / name""")
assert 'assert relative in manifests[\'platform_wrapper\']' not in s
(out / 'bind.py').write_text(s)
(out / 'layout-verified.json').write_bytes((old / 'layout-verified.json').read_bytes())
compile(s, str(out / 'bind.py'), 'exec')
print('binder03 syntax checked, binder not executed; exact approved layout copied unchanged')
