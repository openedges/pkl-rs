"""Bind frozen Stage 62 source evidence to an explicitly supplied implementation B commit.

Prepared after B from the preserved, unexecuted binder01. Root owns execution.
Original checkpoint assembly raw output was not saved; this audit binds the
separate later read-only checkpoint verification without recreating that run.
This reads Git objects and recorded evidence; it does not run builds or tests.
Earlier failed captures remain historical evidence; only the declared final
manifests below are compared with B-current source bytes. All newly generated
outputs stay beneath this target directory; publication is a separate root action.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

if not __debug__:
    raise RuntimeError('Run this integrity audit without Python -O; assertions are required')

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'target/m2/stage62-source-binding-02'
PUBLIC = OUT / 'stage62-source-binding.json'
ARCHIVE = OUT / 'stage62-source-binding-evidence.tar.gz'
BASE = 'b262208ccc537af2845d2107226bb4dac0ba7ecf'
IMPLEMENTATION_COMMIT = 'aac28e5b8d7a2182bc3e385410ff12228f246fb0'
HISTORICAL_BASE_DOCS = {'PLAN.md', 'README.md', 'TESTING.md', 'docs/m2-language.md'}
PIN = {'external/pkl': 'e51fb2f91774265666f94980ec630db794a4db2d',
       'external/pkl-pantry': '904a68184e54da378b0a0e8a911a3fab3956f693'}
RUST = 'target/m2/stage62-rust-validation-02'
BUILD = 'target/m2/stage62-native-build-01'
COHORT = 'target/m2/stage62-native-acquisition-01'
M1 = 'target/m2/stage62-m1-platform-contract-01'
PLATFORM = 'target/m2/stage62-platform-validation-01'
ORIGINAL = 'target/m2/stage62-original-conversions-01'
COMPARE = 'target/m2/stage62-comparison-validation-01'
TOOL = 'target/m2/stage62-tool-development-05'
DATA_SIZE = 'target/m2/stage62-data-size-native-regression-01'
PROFILE_ROWS = {'collection-conversions': 236, 'collection-conversion-controls': 58,
                'collection-lookups': 133, 'collection-default-contracts': 22,
                'collection-dynamic-render': 10, 'collection-property-names': 26}
NATIVE_CAPTURES = {
    **{name: (f'target/m2/stage62-{name}-native-comparison-01',
              f'tests/fixtures/m2-{name}', rows) for name, rows in PROFILE_ROWS.items()},
    'intseq': ('target/m2/stage62-intseq-native-comparison-01', 'tests/fixtures/m2-int-seq-values', 237),
    'bytes': ('target/m2/stage62-bytes-native-regression-01', 'tests/fixtures/m2-bytes-values', 300),
    'duration': ('target/m2/stage62-duration-native-regression-01', 'tests/fixtures/m2-duration-values', 274),
}
PORTABLE_CAPTURES = {
    **{name: (f'target/m2/stage62-{name}-portable-capture-01', rows)
       for name, rows in PROFILE_ROWS.items()},
    **{name: (f'target/m2/stage62-{name}-portable-capture-01', rows)
       for name, rows in [('int-seq-values', 237), ('bytes-values', 300),
                          ('duration-values', 274), ('any-if-non-null', 86), ('data-size', 255)]},
}
MANIFESTS = {'rust_validation': RUST + '/sources.json', 'native_build': BUILD + '/source-before.json',
             'native_cohort': COHORT + '/cohort-before.json', 'm1_platforms': M1 + '/sources.json',
             'platform_wrapper': PLATFORM + '/source-before.json',
             'original_conversions': ORIGINAL + '/sources.json',
             'comparison_wrapper': COMPARE + '/source-before.json',
             'tool_validation': TOOL + '/source-before.json',
             'data_size_regression': DATA_SIZE + '/source-before.json'}
SOURCE_COPIES = {category: folder + '/sources' for category, folder in [
    ('native_build', BUILD), ('native_cohort', COHORT), ('m1_platforms', M1),
    ('platform_wrapper', PLATFORM), ('original_conversions', ORIGINAL),
    ('comparison_wrapper', COMPARE), ('tool_validation', TOOL), ('data_size_regression', DATA_SIZE)]}
MANIFEST_FIELDS = {}
FIXTURE_MANIFESTS = {}
ARCHIVED_COPIES = {
    'rust_validation': ('validation', RUST + '/sources/', 'captured-only'),
    **{category: (group, SOURCE_COPIES[category] + '/', 'all') for category, group in [
        ('native_build', 'native'), ('native_cohort', 'native'), ('m1_platforms', 'platform'),
        ('platform_wrapper', 'platform'), ('original_conversions', 'closeout'),
        ('comparison_wrapper', 'closeout'), ('tool_validation', 'validation'),
        ('data_size_regression', 'native')]},
}
for capture_name, (folder, fixture, _) in NATIVE_CAPTURES.items():
    for part in ('build', 'tools', 'fixture'):
        category = 'native_' + capture_name.replace('-', '_') + '_' + part
        if part == 'build':
            MANIFESTS[category] = folder + '/build/source-before.json'
            SOURCE_COPIES[category] = folder + '/build/sources'
            mode = 'all'
        elif part == 'tools':
            MANIFESTS[category] = folder + '/report.json'
            MANIFEST_FIELDS[category] = 'tools_before'
            SOURCE_COPIES[category] = folder + '/tools'
            mode = 'flat'
        else:
            MANIFESTS[category] = folder + '/inventory.json'
            FIXTURE_MANIFESTS[category] = fixture
            SOURCE_COPIES[category] = folder + '/fixture'
            mode = 'strip:' + fixture + '/'
        ARCHIVED_COPIES[category] = ('native', SOURCE_COPIES[category] + '/', mode)
PUBLIC_ARCHIVES = {group: f'reports/m2/stage62-{group}-evidence.tar.gz'
                   for group in ('validation', 'native', 'platform', 'closeout')}
PUBLICATIONS = {group: f'reports/m2/stage62-{group}-publication.json' for group in PUBLIC_ARCHIVES}
# Generated ignored inputs must match these exact members of B's committed archives.
# These proofs do not turn execution scripts into implementation source matches.
EXECUTION_PROOFS = [
    ('rust_validation', 'validation', RUST + '/run.py', RUST + '/run.py'),
    ('native_build', 'native', BUILD + '/run.py', BUILD + '/run.py'),
    ('native_cohort', 'native', COHORT + '/run.py', COHORT + '/run.py'),
    ('platform_wrapper', 'platform', PLATFORM + '/run.py', PLATFORM + '/run.py'),
    ('platform_wrapper', 'platform', PLATFORM + '/preparation-02.json', PLATFORM + '/preparation-02.json'),
    ('comparison_wrapper', 'closeout', COMPARE + '/run.py', COMPARE + '/run.py'),
    ('comparison_wrapper', 'platform', PLATFORM + '/run.py', PLATFORM + '/run.py'),
    ('comparison_wrapper', 'platform', PLATFORM + '/preparation-02.json', PLATFORM + '/preparation-02.json'),
    ('original_conversions', 'closeout', 'target/m2/stage62-original-conversions-prep-01/run.py', ORIGINAL + '/runner.py'),
    ('original_launch', 'closeout', 'target/m2/stage62-original-conversions-launch-01/run.py', 'target/m2/stage62-original-conversions-launch-01/run.py'),
    ('tool_validation', 'validation', TOOL + '/run.py', TOOL + '/run.py'),
    ('data_size_regression', 'native', DATA_SIZE + '/run.py', DATA_SIZE + '/run.py'),
    *[(name + '_launch', 'native', f'target/m2/stage62-{name}-native-regression-launch-01/run.py',
       f'target/m2/stage62-{name}-native-regression-launch-01/run.py') for name in ('bytes', 'duration')],
]
ARCHIVE_CONTROL_MEMBERS = {
    'validation': [RUST + '/report.json', TOOL + '/report.json'],
    'native': [BUILD + '/build.json', BUILD + '/string_session_probe', BUILD + '/data_size_fixture_probe',
               COHORT + '/report.json', COHORT + '/cohort-before.json', COHORT + '/cohort-after.json',
               DATA_SIZE + '/report.json', DATA_SIZE + '/inventory.json',
               *[folder + '/' + name for folder, _, _ in NATIVE_CAPTURES.values()
                 for name in ('report.json', 'inventory.json', 'build/build.json', 'build/string_session_probe',
                              'build/data_size_fixture_probe')],
               *[f'target/m2/stage62-{name}-native-regression-launch-01/report.json' for name in ('bytes', 'duration')]],
    'platform': [M1 + '/report.json', PLATFORM + '/report.json',
                 *[folder + '/report.json' for folder, _ in PORTABLE_CAPTURES.values()]],
    'closeout': [ORIGINAL + '/report.json', ORIGINAL + '/selection.json', COMPARE + '/report.json',
                 'target/m2/stage62-original-conversions-launch-01/report.json'],
}
CHECKPOINT = 'reports/m2/stage62-implementation-checkpoint.json'
CHECKPOINT_VERIFICATION = 'target/m2/stage62-checkpoint-verification-01'


def raw_json(data):
    return (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()


def digest(path):
    h = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
            size += len(chunk)
    return {'sha256': h.hexdigest(), 'bytes': size}


def execute(*argv):
    proc = subprocess.run(argv, cwd=ROOT, capture_output=True)
    assert proc.returncode == 0, (argv, proc.returncode, proc.stderr[-1000:])
    return proc.stdout


def git_tree(repo, commit):
    result = {}
    for record in execute('git', '-C', str(repo), 'ls-tree', '-rz', '--full-tree', commit).split(b'\0'):
        if not record:
            continue
        head, path = record.split(b'\t', 1)
        mode, kind, oid = head.split(b' ')
        name = path.decode('utf-8', 'surrogateescape')
        assert name not in result
        result[name] = (mode.decode(), kind.decode(), oid.decode())
    return result


def logical(name):
    for repo in ('external/pkl-pantry', 'external/pkl'):
        if name.startswith(repo + '/'):
            return repo, name[len(repo) + 1:]
    return '.', name


def git_blobs(repo, oids):
    """Read each unique Git object once and validate its SHA-1 framing."""
    proc = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    result = {}
    try:
        for oid in sorted(oids):
            proc.stdin.write((oid + '\n').encode())
            proc.stdin.flush()
            header = proc.stdout.readline().strip().split(b' ')
            assert len(header) == 3 and header[0].decode() == oid and header[1] == b'blob', (oid, header)
            size = int(header[2])
            remaining = size
            git_hash = hashlib.sha1(b'blob ' + str(size).encode() + b'\0')
            content_hash = hashlib.sha256()
            while remaining:
                chunk = proc.stdout.read(min(1 << 20, remaining))
                assert chunk, (oid, remaining)
                git_hash.update(chunk)
                content_hash.update(chunk)
                remaining -= len(chunk)
            assert proc.stdout.read(1) == b'\n' and git_hash.hexdigest() == oid
            result[oid] = {'sha256': content_hash.hexdigest(), 'bytes': size}
        proc.stdin.close()
        assert proc.wait() == 0, proc.stderr.read()[-1000:]
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()
    return result


def blob_bytes(repo, oid, expected):
    raw = execute('git', '-C', str(repo), 'cat-file', 'blob', oid)
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid
    assert {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} == expected
    return raw


def expected_identity(value):
    if isinstance(value, str):
        return value, None
    assert isinstance(value, dict)
    return value['sha256'], value.get('bytes')


def archive_member_audit(archive_bytes, category, prefix, source_manifest, captured_only=False):
    seen = 0
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as stream:
        members = stream.getmembers()
        names = [member.name for member in members]
        assert len(names) == len(set(names)), 'duplicate evidence archive member'
        for name, value in source_manifest.items():
            if captured_only and value['origin']['kind'] != 'captured-file':
                continue
            entry = stream.getmember(prefix + copied_suffix(category, name))
            assert entry.isfile() and not entry.issym() and not entry.islnk(), entry.name
            raw = stream.extractfile(entry).read()
            sha, size = expected_identity(value)
            assert hashlib.sha256(raw).hexdigest() == sha and (size is None or len(raw) == size), entry.name
            seen += 1
    return seen


READ_IDENTITIES = {}


def read_json(relative):
    raw = (ROOT / relative).read_bytes()
    identity = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    if relative in READ_IDENTITIES:
        assert READ_IDENTITIES[relative] == identity, ('changed JSON evidence', relative)
    READ_IDENTITIES[relative] = identity
    return json.loads(raw)


def copied_suffix(category, name):
    mode = ARCHIVED_COPIES[category][2]
    if mode == 'flat':
        return PurePosixPath(name).name
    if mode.startswith('strip:'):
        prefix = mode.removeprefix('strip:')
        assert name.startswith(prefix), (category, name)
        return name.removeprefix(prefix)
    return name


def load_manifest(category, relative):
    values = read_json(relative)
    if category in MANIFEST_FIELDS:
        values = values[MANIFEST_FIELDS[category]]
    elif category in FIXTURE_MANIFESTS:
        prefix = FIXTURE_MANIFESTS[category] + '/'
        values = {prefix + name.removeprefix('fixture/'): item
                  for name, item in values.items() if name.startswith('fixture/')}
    assert isinstance(values, dict) and values, (category, relative)
    return values


def validate_final_records(manifests):
    """Cross-bind recorded build/capture inputs without running evaluators or verifiers."""
    rust = read_json(RUST + '/report.json')
    assert rust['complete'] is True and rust['changed_sources'] == []
    assert rust['base_commit'] == BASE and len(rust['commands']) == 5
    assert all(row['exit_code'] == 0 for row in rust['commands'])
    assert manifests['rust_validation'] == read_json(RUST + '/sources-after.json')
    assert len(manifests['rust_validation']) == rust['source_count'] == 165344
    assert rust['copied_source_files'] == 22
    for category, after in [('native_build', BUILD + '/source-after.json'),
                            ('native_cohort', COHORT + '/cohort-after.json'),
                            ('platform_wrapper', PLATFORM + '/source-after.json'),
                            ('comparison_wrapper', COMPARE + '/source-after.json'),
                            ('tool_validation', TOOL + '/source-after.json'),
                            ('data_size_regression', DATA_SIZE + '/source-after.json')]:
        assert manifests[category] == read_json(after), category
    for relative in (BUILD + '/build.json', PLATFORM + '/report.json',
                     ORIGINAL + '/report.json', COMPARE + '/report.json', TOOL + '/report.json',
                     DATA_SIZE + '/report.json'):
        data = read_json(relative)
        assert data['complete'] is True, relative
        assert data.get('source_stable', data.get('source_stability')) is True, relative
    build = read_json(BUILD + '/build.json')
    assert build['exit_code'] == 0 and build['base_commit'] == BASE
    for name, item in build['artifacts'].items():
        assert digest(ROOT / BUILD / name) == item, name
    cohort = read_json(COHORT + '/report.json')
    assert cohort['complete'] is True and cohort['stable'] is True
    assert len(cohort['commands']) == len(NATIVE_CAPTURES) + 1
    assert all(row['exit_code'] == 0 for row in cohort['commands'])
    assert cohort['artifacts_before'] == cohort['artifacts_after'] == {
        name: digest(ROOT / name) for name in cohort['artifacts_before']}
    assert cohort['wrapper_before'] == cohort['wrapper_after'] == digest(ROOT / COHORT / 'run.py')
    native_controls = {}
    for name, (folder, fixture, rows) in NATIVE_CAPTURES.items():
        report = read_json(folder + '/report.json')
        assert report['complete'] is True and len(report['processes']) == 2, name
        assert report['comparison']['counts'] == {'pass': rows * 2}, name
        assert report['comparison']['strict_string_passed'] is True, name
        assert report['source_after'] == manifests['native_build'], name
        assert read_json(folder + '/build/source-before.json') == manifests['native_build']
        assert read_json(folder + '/build/source-after.json') == manifests['native_build']
        assert digest(ROOT / folder / 'build/build.json') == digest(ROOT / BUILD / 'build.json')
        for artifact, item in build['artifacts'].items():
            assert digest(ROOT / folder / 'build' / artifact) == item, (name, artifact)
        assert report['tools_before'] == report['tools_after']
        if name in PROFILE_ROWS:
            assert report['profile_uri'] == read_json(fixture + '/cases.json')['module_uri']
            assert all(manifests['native_cohort'].get(path) == item
                       for path, item in report['tools_before'].items()), name
        for process in report['processes']:
            assert process['exit_code'] == 0 and process['timed_out'] is False and process['launch_error'] is None
        native_controls[name] = {'path': folder + '/report.json', **digest(ROOT / folder / 'report.json'),
                                 'rows': rows, 'repetitions': 2,
                                 'counts': report['comparison']['counts']}
    for row in cohort['commands']:
        relative = str(Path(row['output']).relative_to(ROOT)) + '/report.json'
        assert row['output_report'] == digest(ROOT / relative), row['name']
    for name in ('bytes', 'duration'):
        relative = f'target/m2/stage62-{name}-native-regression-launch-01/report.json'
        launch = read_json(relative)
        assert launch['exit_code'] == 0 and launch['source_stable'] is True
        assert launch['source_before'] == launch['source_after']
        assert launch['output_report'] == digest(ROOT / NATIVE_CAPTURES[name][0] / 'report.json')
    data = read_json(DATA_SIZE + '/report.json')
    assert data['artifact_before'] == data['artifact_after'] == build['artifacts']['data_size_fixture_probe']
    assert data['build_report'] == digest(ROOT / BUILD / 'build.json')
    assert data['passed'] == 510 and data['mismatches'] == 0 and data['strict_string_passed'] is True
    assert data['fixture_before'] == data['fixture_after']
    m1 = read_json(M1 + '/report.json')
    assert manifests['m1_platforms'] == m1['source_hashes']
    assert m1['source_stability'] is True and m1['experiment_contract_status'] == 'pass'
    assert m1['total'] == m1['shared_engine_passed'] == 6078
    assert m1['oracle_passed'] == {'rust': 6076, 'node': 6076, 'browser': 6076}
    assert m1['compatibility_status'] == 'fail'
    wrapper = read_json(PLATFORM + '/report.json')
    command, = [item for item in wrapper['commands'] if item['name'] == 'm1-contract']
    assert command['exit_code'] == 0 and command['finished_epoch'] >= command['started_epoch']
    assert command['argv'][-1] == '--verify-contract' and command['argv'][-2] == str(ROOT / M1)
    assert len(wrapper['commands']) == len(PORTABLE_CAPTURES) + 1
    assert all(row['exit_code'] == 0 for row in wrapper['commands'])
    portable_controls = {}
    for name, (folder, rows) in PORTABLE_CAPTURES.items():
        report = read_json(folder + '/report.json')
        assert report['complete'] is True and report['orderedRows'] == rows and report['repetitions'] == 2
        assert report['inputsBefore'] == report['inputsAfter'] and report['fileSetsBefore'] == report['fileSetsAfter']
        assert report['infrastructureErrors'] == []
        assert set(report['targets']) == {'napi', 'chromium'}
        for folder_files in report['fileSetsBefore'].values():
            assert len(folder_files) == len(set(folder_files))
            assert all(path in report['inputsBefore'] for path in folder_files)
        binding = {'source_inputs': {}, 'built_artifacts': {}, 'recorded_external_runtime_inputs': {}}
        for absolute, sha in report['inputsBefore'].items():
            path = Path(absolute)
            assert path.is_absolute()
            if path.is_relative_to(ROOT):
                relative = path.relative_to(ROOT).as_posix()
                if relative.startswith(M1 + '/'):
                    assert digest(path)['sha256'] == sha
                    ARCHIVE_CONTROL_MEMBERS['platform'].append(relative)
                    binding['built_artifacts'][relative] = sha
                else:
                    assert relative in manifests['platform_wrapper'], (name, relative)
                    assert expected_identity(manifests['platform_wrapper'][relative])[0] == sha
                    binding['source_inputs'][relative] = sha
            else:
                # Recorded Node/Python/browser payloads are execution identities,
                # not implementation sources or newly checked installed runtimes.
                binding['recorded_external_runtime_inputs'][absolute] = sha
        portable_controls[name] = {'path': folder + '/report.json', **digest(ROOT / folder / 'report.json'),
                                   'rows': rows, 'binding': binding}
    comparison = read_json(COMPARE + '/report.json')
    assert comparison['source_snapshot_stable'] is True
    assert comparison['full_api_complete'] is False and comparison['full_m2_complete'] is False
    commands = comparison['commands']
    assert len(commands) == 19 and len({row['name'] for row in commands}) == 19
    for row in commands:
        assert row['exit_code'] == row['expected_exit_code'] == (1 if row['name'] == 'any-portable' else 0)
    expected_counts = {}
    for name, rows in {**PROFILE_ROWS, 'intseq': 237, 'bytes': 300, 'duration': 274, 'data-size': 255}.items():
        expected_counts[name + '-native'] = {'pass': rows * 2}
        expected_counts[name + '-portable'] = {target: {'pass': rows * 2} for target in ('napi', 'chromium')}
    expected_counts['any-portable'] = {target: {'pass': 170, 'mismatch': 2} for target in ('napi', 'chromium')}
    assert comparison['counts'] == expected_counts
    input_reports = {'m1': M1 + '/report.json', 'native_build': BUILD + '/build.json',
                     'platform_wrapper': PLATFORM + '/report.json', 'data_size_native': DATA_SIZE + '/report.json',
                     **{name + ('-native' if name in PROFILE_ROWS else '_native'): folder + '/report.json'
                        for name, (folder, _, _) in NATIVE_CAPTURES.items()},
                     **{name: folder + '/report.json' for name, (folder, _) in PORTABLE_CAPTURES.items()}}
    assert comparison['preflight']['input_reports'] == {name: digest(ROOT / path) for name, path in input_reports.items()}
    tool = read_json(TOOL + '/report.json')
    assert len(tool['commands']) == 4 and all(row['exit_code'] == 0 for row in tool['commands'])
    original = read_json(ORIGINAL + '/report.json')
    selection = read_json(ORIGINAL + '/selection.json')
    assert len(original['results']) == len(selection['case_ids']) == len(set(selection['case_ids'])) == 90
    assert original['integrity_status'] == 'passed'
    assert all(original[key] is True for key in ('source_snapshot_stability', 'freeze_authority_stability', 'runner_stability'))
    assert original['freeze_authority']['sha256'] == digest(ROOT / MANIFESTS['rust_validation'])['sha256']
    launch = read_json('target/m2/stage62-original-conversions-launch-01/report.json')
    assert launch['complete'] is True and launch['source_stable'] is True
    assert launch['exit_code'] == (0 if original['selected_status'] == 'passed' else 1)
    assert launch['inputs_before'] == launch['inputs_after'] == {
        name: digest(ROOT / name) for name in launch['inputs_before']}
    assert launch['result_report'] == digest(ROOT / ORIGINAL / 'report.json')
    for group in ARCHIVE_CONTROL_MEMBERS:
        ARCHIVE_CONTROL_MEMBERS[group] = sorted(set(ARCHIVE_CONTROL_MEMBERS[group]))
    return original, {'native': native_controls, 'portable': portable_controls,
                      'data_size': {'path': DATA_SIZE + '/report.json', **digest(ROOT / DATA_SIZE / 'report.json')},
                      'native_cohort': {'path': COHORT + '/report.json', **digest(ROOT / COHORT / 'report.json')},
                      'comparison': {'path': COMPARE + '/report.json', **digest(ROOT / COMPARE / 'report.json'),
                                     'counts': comparison['counts'], 'known_regex_failures_preserved': True}}


def main(commit, layout_file):
    assert ROOT == Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
    assert re.fullmatch('[0-9a-f]{40}', commit), 'explicit implementation B commit required'
    assert not PUBLIC.exists() and not ARCHIVE.exists() and not (OUT / 'report.json').exists()
    assert commit == IMPLEMENTATION_COMMIT, 'explicit reviewed Stage62 implementation B required'
    assert commit != BASE, 'implementation B must differ from the Java authority base'
    assert execute('git', 'cat-file', '-t', commit).strip() == b'commit'
    execute('git', 'merge-base', '--is-ancestor', BASE, commit)
    assert layout_file.resolve() == OUT / 'layout-verified.json'
    layout_id = digest(layout_file)
    layout = json.loads(layout_file.read_bytes())
    assert layout['schema'] == 1 and layout['approved'] is True
    assert layout['implementation_commit'] == commit
    assert set(layout['publications']) == set(PUBLICATIONS)
    preparation_id = digest(OUT / 'preparation.json')
    binder_id = digest(Path(__file__))
    repositories = {'.': ROOT, **{name: ROOT / name for name in PIN}}
    trees = {'.': git_tree(ROOT, commit),
             **{name: git_tree(ROOT / name, pin) for name, pin in PIN.items()}}
    base_tree = git_tree(ROOT, BASE)
    for name, pin in PIN.items():
        assert trees['.'].get(name) == ('160000', 'commit', pin), (name, trees['.'].get(name))

    manifests = {}
    manifest_ids = {}
    for category, relative in MANIFESTS.items():
        path = ROOT / relative
        manifest_ids[relative] = digest(path)
        values = load_manifest(category, relative)
        manifests[category] = values
    original_report, capture_controls = validate_final_records(manifests)
    for category, relative in MANIFESTS.items():
        ARCHIVE_CONTROL_MEMBERS[ARCHIVED_COPIES[category][0]].append(relative)
    for relative in READ_IDENTITIES:
        if not relative.startswith('target/m2/'):
            assert any(relative in rows for rows in manifests.values()), relative
            continue
        groups = [group for group, paths in ARCHIVE_CONTROL_MEMBERS.items()
                  if relative in paths]
        if not groups:
            matches = [(len(prefix), ARCHIVED_COPIES[category][0])
                       for category, prefix in SOURCE_COPIES.items()
                       if relative.startswith(prefix.removesuffix('/sources') + '/')]
            if relative.startswith(RUST + '/'):
                matches.append((len(RUST), 'validation'))
            assert matches, ('JSON evidence has no archive group', relative)
            ARCHIVE_CONTROL_MEMBERS[max(matches)[1]].append(relative)
    for group in ARCHIVE_CONTROL_MEMBERS:
        ARCHIVE_CONTROL_MEMBERS[group] = sorted(set(ARCHIVE_CONTROL_MEMBERS[group]))

    copied_ids = {}
    rust = manifests['rust_validation']
    origin_counts = Counter()
    required_oids = {name: set() for name in repositories}
    rows = []
    for name, value in rust.items():
        origin = value['origin']
        repo, relative = logical(name)
        if origin['kind'] == 'git-blob':
            assert origin['repository'] == repo and origin['path'] == relative
            expected_commit = BASE if repo == '.' else PIN[repo]
            assert origin['commit'] == expected_commit
            previous = base_tree if repo == '.' else trees[repo]
            assert previous.get(relative) == (origin['mode'], 'blob', origin['oid']), (name, origin)
            required_oids[repo].add(origin['oid'])
            assert value['input_mode'] == origin['mode']
            origin_counts['base_git' if repo == '.' else 'pinned_submodule_git'] += 1
        else:
            assert origin['kind'] == 'captured-file' and repo == '.'
            path = ROOT / RUST / origin['path']
            assert path.is_file() and not path.is_symlink(), path
            copied_ids[str(path.relative_to(ROOT))] = digest(path)
            assert copied_ids[str(path.relative_to(ROOT))] == {
                'sha256': value['sha256'], 'bytes': value['bytes']}
            origin_counts['captured_file'] += 1
        rows.append(('rust_validation', name, value))
    assert sum(origin_counts.values()) == len(rust)
    assert origin_counts['captured_file'] == json.loads(
        (ROOT / RUST / 'report.json').read_bytes())['copied_source_files']
    for category, folder in SOURCE_COPIES.items():
        for name, value in manifests[category].items():
            path = ROOT / folder / copied_suffix(category, name)
            assert path.is_file() and not path.is_symlink(), path
            expected_sha, expected_size = expected_identity(value)
            identity = digest(path)
            assert identity['sha256'] == expected_sha and (expected_size is None or identity['bytes'] == expected_size), (category, name)
            copied_ids[str(path.relative_to(ROOT))] = identity
    for category, data in manifests.items():
        if category == 'rust_validation':
            continue
        rows.extend((category, name, value) for name, value in data.items())

    archive_ids = {}
    for category, relative in PUBLIC_ARCHIVES.items():
        path = ROOT / relative
        archive_ids[category] = {'path': relative, **digest(path)}
        entry = trees['.'].get(relative)
        assert entry and entry[:2] == ('100644', 'blob'), (relative, entry)
        required_oids['.'].add(entry[2])
    publication_ids = {}
    for category, relative in PUBLICATIONS.items():
        publication_ids[category] = {'path': relative, **digest(ROOT / relative)}
        entry = trees['.'].get(relative)
        assert entry and entry[:2] == ('100644', 'blob'), (relative, entry)
        required_oids['.'].add(entry[2])
    checkpoint_id = digest(ROOT / CHECKPOINT)
    checkpoint_entry = trees['.'].get(CHECKPOINT)
    assert checkpoint_entry and checkpoint_entry[:2] == ('100644', 'blob')
    required_oids['.'].add(checkpoint_entry[2])
    checkpoint_verification_files = {
        name: ROOT / CHECKPOINT_VERIFICATION / name
        for name in ('verify.py', 'run.py', 'report.json', 'source-before.json',
                     'source-after.json', 'stdout.bin', 'stderr.bin')}
    checkpoint_verification_ids = {name: digest(path) for name, path in checkpoint_verification_files.items()}
    verification = json.loads(checkpoint_verification_files['report.json'].read_bytes())
    assert verification['exit_code'] == 0 and verification['complete'] is True
    assert verification['source_stable'] is True and verification['current_head'] == commit
    assert verification['verification_is_later'] is True
    assert verification['original_assembly_raw_available'] is False and verification['read_only'] is True
    assert verification['cwd'] == str(ROOT)
    assert verification['command'] == [verification['python']['executable'], '-B',
                                       str(ROOT / CHECKPOINT_VERIFICATION / 'verify.py')]
    verification_inputs = json.loads(checkpoint_verification_files['source-before.json'].read_bytes())
    assert verification_inputs == json.loads(checkpoint_verification_files['source-after.json'].read_bytes())
    assert verification['source_before'] == verification['source_after'] == verification_inputs
    expected_verification_inputs = {CHECKPOINT_VERIFICATION + '/' + name for name in ('run.py', 'verify.py')}
    expected_verification_inputs |= {'target/m2/stage62-checkpoint-01/prepare.py',
                                    'target/m2/stage62-publication-review-01/report.json', CHECKPOINT}
    expected_verification_inputs |= set(PUBLIC_ARCHIVES.values()) | set(PUBLICATIONS.values())
    assert set(verification_inputs) == expected_verification_inputs
    assert verification_inputs == {name: digest(ROOT / name) for name in verification_inputs}
    assert verification['checkpoint_identity'] == checkpoint_id
    for channel in ('stdout', 'stderr'):
        assert verification[channel] == checkpoint_verification_ids[channel + '.bin']
    assert checkpoint_verification_files['stderr.bin'].read_bytes() == b''
    verification_summary = json.loads(checkpoint_verification_files['stdout.bin'].read_bytes())
    assert verification['verification_summary'] == verification_summary
    assert verification_summary['current_head'] == commit and verification_summary['recorded_assembly_base'] == BASE
    assert verification_summary['base_is_ancestor'] is True
    assert verification_summary['verification_is_later'] is True
    assert verification_summary['original_assembly_raw_available'] is False and verification_summary['read_only'] is True
    assert verification_summary['checkpoint_identity'] == {'path': CHECKPOINT, **checkpoint_id}
    assert verification_summary['checkpoint_declared_identities_checked'] == 87
    assert set(verification_summary['groups']) == set(PUBLIC_ARCHIVES)
    for group, item in verification_summary['groups'].items():
        assert item['full_member_hash_readback'] is True
        assert item['archive'] == archive_ids[group] and item['publication'] == publication_ids[group]
    review_path = 'target/m2/stage62-publication-review-01/report.json'
    assert verification_summary['independent_review'] == {'path': review_path, **verification_inputs[review_path]}
    for category, name, value in rows:
        repo, relative = logical(name)
        entry = trees[repo].get(relative)
        if entry and entry[1] == 'blob':
            required_oids[repo].add(entry[2])
    blobs = {name: git_blobs(repo, required_oids[name]) for name, repo in repositories.items()}
    assert blobs['.'][checkpoint_entry[2]] == checkpoint_id
    for name, value in rust.items():
        origin = value['origin']
        if origin['kind'] == 'git-blob':
            repo, _ = logical(name)
            assert blobs[repo][origin['oid']] == {'sha256': value['sha256'], 'bytes': value['bytes']}, name
    symlinks = [name for name, value in rust.items() if value['input_mode'] == '120000']
    assert all(rust[name]['origin']['kind'] == 'git-blob' and
               rust[name]['origin']['mode'] == '120000' for name in symlinks)

    archive_bytes = {}
    for category, identity in archive_ids.items():
        entry = trees['.'][identity['path']]
        assert blobs['.'][entry[2]] == {'sha256': identity['sha256'], 'bytes': identity['bytes']}
        archive_bytes[category] = blob_bytes(ROOT, entry[2], {
            'sha256': identity['sha256'], 'bytes': identity['bytes']})
        identity['B_oid'] = entry[2]
    full_archive_counts = {}
    for category, identity in publication_ids.items():
        entry = trees['.'][identity['path']]
        expected = {key: identity[key] for key in ('sha256', 'bytes')}
        assert blobs['.'][entry[2]] == expected
        publication = json.loads(blob_bytes(ROOT, entry[2], expected))
        identity['B_oid'] = entry[2]
        approved = layout['publications'][category]
        assert all(approved[key] == identity[key] for key in ('path', 'sha256', 'bytes'))
        assert approved['selected_directories'] == publication['selected_directories']
        archive = publication['archive']
        assert all(approved['archive'][key] == archive[key]
                   for key in ('path', 'sha256', 'bytes', 'members'))
        assert all(archive[key] == archive_ids[category][key]
                   for key in ('path', 'sha256', 'bytes'))
        assert publication['source_before_after']['stable'] is True
        assert archive['full_member_readback_verified'] is True
        observed = {}
        with tarfile.open(fileobj=io.BytesIO(archive_bytes[category]), mode='r:gz') as stream:
            for member in stream:
                assert member.isfile() and not member.issym() and not member.islnk()
                assert member.name not in observed and not member.name.startswith('/')
                assert '..' not in PurePosixPath(member.name).parts
                raw = stream.extractfile(member).read()
                observed[member.name] = {
                    'sha256': hashlib.sha256(raw).hexdigest(),
                    'bytes': len(raw), 'mode': member.mode}
        assert observed == publication['member_inventory'], category
        assert len(observed) == archive['members']
        full_archive_counts[category] = len(observed)
        assert verification_summary['groups'][category]['members'] == len(observed)
    assert verification_summary['member_readback_total'] == sum(full_archive_counts.values())
    archived_counts = {}
    for category, (archive_name, prefix, mode) in ARCHIVED_COPIES.items():
        archived_counts[category] = archive_member_audit(
            archive_bytes[archive_name], category, prefix, manifests[category],
            captured_only=(mode == 'captured-only'))
        assert archived_counts[category] == (origin_counts['captured_file'] if mode == 'captured-only'
                                             else len(manifests[category]))
    for archive_name, controls in ARCHIVE_CONTROL_MEMBERS.items():
        with tarfile.open(fileobj=io.BytesIO(archive_bytes[archive_name]), mode='r:gz') as stream:
            for relative in controls:
                member = stream.getmember(relative)
                assert member.isfile() and not member.issym() and not member.islnk(), relative
                raw = stream.extractfile(member).read()
                assert {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} == digest(ROOT / relative), relative

    control_ids = {relative: digest(ROOT / relative)
                   for controls in ARCHIVE_CONTROL_MEMBERS.values() for relative in controls}
    wrapper_rows = []
    wrapper_ids = {}
    for category, archive_name, source, archived_member in EXECUTION_PROOFS:
        assert source not in trees['.'], ('wrapper unexpectedly became a B source', source)
        path = ROOT / source
        assert path.is_file() and not path.is_symlink(), source
        identity = digest(path)
        wrapper_ids[source] = identity
        with tarfile.open(fileobj=io.BytesIO(archive_bytes[archive_name]), mode='r:gz') as stream:
            member = stream.getmember(archived_member)
            assert member.isfile() and not member.issym() and not member.islnk()
            raw = stream.extractfile(member).read()
        assert {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} == identity
        wrapper_rows.append({
            'category': category, 'source_path': source,
            'status': 'archived_execution_tool_not_B',
            'archive': PUBLIC_ARCHIVES[archive_name], 'archive_member': archived_member,
            'B_archive_oid': archive_ids[archive_name]['B_oid'], **identity})

    statuses = defaultdict(Counter)
    deviations = defaultdict(list)
    output_rows = OUT / 'rows.jsonl.gz'
    with output_rows.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
            for category, name, value in rows:
                expected_sha, expected_size = expected_identity(value)
                repo, relative = logical(name)
                entry = trees[repo].get(relative)
                row = {'category': category, 'path': name, 'repository': repo,
                       'expected_sha256': expected_sha, 'expected_bytes': expected_size}
                if category == 'rust_validation':
                    row['origin'] = value['origin']
                    row['expected_mode'] = value['input_mode']
                if entry is None:
                    proof = next((proof for proof in wrapper_rows
                                  if proof['category'] == category and proof['source_path'] == name), None)
                    if proof is not None:
                        assert proof['sha256'] == expected_sha
                        assert expected_size is None or proof['bytes'] == expected_size
                        status = 'archived_execution_tool_not_B'
                        row.update(archive=proof['archive'], archive_member=proof['archive_member'],
                                   B_archive_oid=proof['B_archive_oid'])
                    else:
                        status = 'missing_in_B'
                elif entry[1] != 'blob':
                    status = 'nonblob_in_B'
                    row.update(B_mode=entry[0], B_type=entry[1], B_oid=entry[2])
                else:
                    mode, _, oid = entry
                    current = blobs[repo][oid]
                    row.update(B_mode=mode, B_oid=oid, B_sha256=current['sha256'],
                               B_bytes=current['bytes'])
                    equal = current['sha256'] == expected_sha and (
                        expected_size is None or current['bytes'] == expected_size) and (
                        category != 'rust_validation' or mode == value['input_mode'])
                    status = 'matches_B' if equal else 'differs_from_B'
                    if not equal and category == 'rust_validation' and value['origin']['kind'] == 'git-blob' and repo == '.' and name in HISTORICAL_BASE_DOCS:
                        # The exact older bytes and Git mode were checked against BASE above.
                        status = 'historical_document_from_base'
                row['status'] = status
                statuses[category][status] += 1
                if status != 'matches_B':
                    deviations[category].append({'path': name, 'status': status,
                                                 'expected_sha256': expected_sha,
                                                 'B_sha256': row.get('B_sha256')})
                zipped.write((json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n').encode())
    assert sum(sum(counts.values()) for counts in statuses.values()) == sum(map(len, manifests.values()))
    for category, counts in statuses.items():
        unauthorized = set(counts) - {'matches_B', 'historical_document_from_base',
                                      'archived_execution_tool_not_B'}
        assert not unauthorized, (category, dict(counts), deviations[category][:10])
        expected_wrapper_paths = {proof['source_path'] for proof in wrapper_rows
                                  if proof['category'] == category and proof['source_path'] in manifests[category]}
        assert counts['archived_execution_tool_not_B'] == len(expected_wrapper_paths), category
    assert statuses['rust_validation']['matches_B'] >= origin_counts['captured_file']
    for category, values in manifests.items():
        if category != 'rust_validation':
            assert sum(statuses[category].values()) == len(values)
    assert {relative: digest(ROOT / relative) for relative in manifest_ids} == manifest_ids
    assert {relative: digest(ROOT / relative) for relative in copied_ids} == copied_ids
    assert all(digest(ROOT / identity['path']) == {k: identity[k] for k in ('sha256', 'bytes')}
               for identity in archive_ids.values())
    assert all(digest(ROOT / identity['path']) == {k: identity[k] for k in ('sha256', 'bytes')}
               for identity in publication_ids.values())
    assert {relative: digest(ROOT / relative) for relative in wrapper_ids} == wrapper_ids
    assert checkpoint_verification_ids == {name: digest(path) for name, path in checkpoint_verification_files.items()}
    assert verification_inputs == {name: digest(ROOT / name) for name in verification_inputs}
    assert digest(ROOT / CHECKPOINT) == checkpoint_id
    assert digest(layout_file) == layout_id and digest(OUT / 'preparation.json') == preparation_id
    assert digest(Path(__file__)) == binder_id
    assert {name: digest(ROOT / name) for name in control_ids} == control_ids
    assert {name: digest(ROOT / name) for name in READ_IDENTITIES} == READ_IDENTITIES

    report = {
        'schema': 1, 'kind': 'actual-Git-object-source-binding-for-Stage62-B',
        'original_case_count': len(original_report['results']),
        'original_selected_status': original_report['selected_status'],
        'B_commit': commit, 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'recorded_base_commit': BASE, 'gitlinks': PIN,
        'method': 'Actual base, pinned submodule and B tree OIDs/modes; SHA-1-framed Git blob reads and raw SHA-256/size; copied source bytes, required report controls and B archive members reread.',
        'manifests': {category: {'path': relative, **manifest_ids[relative],
                                 'rows': len(manifests[category])}
                      for category, relative in MANIFESTS.items()},
        'category_statuses': {category: dict(counts) for category, counts in statuses.items()},
        'deviations': dict(deviations), 'origin_counts': dict(origin_counts),
        'verified_symlink_sources': symlinks, 'archived_source_member_counts': archived_counts,
        'archived_control_members': {name: list(paths) for name, paths in ARCHIVE_CONTROL_MEMBERS.items()},
        'B_archive_blobs': archive_ids, 'unique_blob_objects_read': {name: len(value) for name, value in blobs.items()},
        'B_publication_blobs': publication_ids, 'full_archive_member_counts': full_archive_counts,
        'archived_execution_wrappers': wrapper_rows,
        'copied_source_files_stable': len(copied_ids),
        'B_implementation_checkpoint': {'path': CHECKPOINT, 'B_oid': checkpoint_entry[2], **checkpoint_id},
        'checkpoint_verification': {'path': CHECKPOINT_VERIFICATION, 'exit_code': 0,
                                    'files': checkpoint_verification_ids,
                                    'verification_is_later': True, 'original_assembly_raw_available': False,
                                    'read_only': True, 'summary': verification_summary},
        'original_checkpoint_assembly_raw_available': False,
        'row_details': {'path': str(output_rows.relative_to(ROOT)), **digest(output_rows)},
        'capture_controls': capture_controls,
        'layout_guard': {'path': str(layout_file.relative_to(ROOT)), **layout_id},
        'binder': {'path': str(Path(__file__).relative_to(ROOT)), **binder_id},
        'original_comparison': {'selected_status': original_report['selected_status'],
                                'status_counts': original_report['status_counts'],
                                'selected_cases': len(original_report['results'])},
        'limits': ['Only the four named base document rows may retain verified base Git bytes when they differ from B; actual rows are counted and are not B-current source claims.',
                   'Named generated execution wrappers are separately proved by exact bytes in committed B evidence archives; they are absent from B source paths and are never counted as B-current sources.',
                   'Earlier failed compiler, build, and tooling attempts remain historical evidence; only the declared final source snapshots are compared with B-current bytes.',
                   'Original checkpoint assembly stdout/stderr were not saved. The separately captured later read-only verification checks existing checkpoint/publication bytes; it is not a capture or reconstruction of the original assembly execution.',
                   'Source binding does not rerun evaluators, builds or tests and does not establish full API, whole M2 or performance compatibility.'],
    }
    (OUT / 'report.json').write_bytes(raw_json(report))
    payloads = {'report.json': OUT / 'report.json', 'rows.jsonl.gz': output_rows,
                'binder.py': Path(__file__)}
    payloads.update({'checkpoint-verification/' + name: path
                     for name, path in checkpoint_verification_files.items()})
    payloads['checkpoint-verification/independent-publication-review.json'] = ROOT / review_path
    payloads['preparation-history/binder01.py'] = ROOT / 'target/m2/stage62-source-binding-01/bind.py'
    payloads['preparation-history/preparation01.json'] = ROOT / 'target/m2/stage62-source-binding-01/preparation.json'
    payloads['adapter.py'] = OUT / 'adapt.py'
    payloads['preparation.json'] = OUT / 'preparation.json'
    payloads['layout-verified.json'] = OUT / 'layout-verified.json'
    inventory = {name: {'mode': stat.S_IMODE(path.stat().st_mode), **digest(path)}
                 for name, path in payloads.items()}
    manifest_raw = raw_json({'schema': 1, 'files': inventory})
    with ARCHIVE.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as stream:
                for name, path in [('manifest.json', None), *sorted(payloads.items())]:
                    raw = manifest_raw if path is None else path.read_bytes()
                    entry = tarfile.TarInfo(name)
                    entry.size = len(raw)
                    entry.mode = 0o644 if path is None else inventory[name]['mode']
                    entry.mtime = 0
                    stream.addfile(entry, io.BytesIO(raw))
    assert digest(ARCHIVE)['bytes'] < 90 * 1024 * 1024
    seen = {}
    with tarfile.open(ARCHIVE, 'r:gz') as stream:
        for entry in stream:
            assert entry.isfile() and entry.name not in seen and not entry.name.startswith('/') and '..' not in PurePosixPath(entry.name).parts
            raw = stream.extractfile(entry).read()
            seen[entry.name] = {'sha256': hashlib.sha256(raw).hexdigest(),
                                'bytes': len(raw), 'mode': entry.mode}
    assert seen.pop('manifest.json') == {'sha256': hashlib.sha256(manifest_raw).hexdigest(),
                                         'bytes': len(manifest_raw), 'mode': 0o644}
    assert seen == inventory
    publication = {
        'schema': 1, 'binding_report': report,
        'evidence_archive': {'path': 'reports/m2/stage62-source-binding-evidence.tar.gz',
                             'local_artifact_path': str(ARCHIVE.relative_to(ROOT)), **digest(ARCHIVE),
                             'members': len(seen) + 1},
        'full_archive_reread_verified': True, 'original_sources_stable_before_after': True,
        'whole_M2_complete': False, 'full_public_api_comparison_passed': False,
        'performance_targets_achieved': False,
    }
    PUBLIC.write_bytes(raw_json(publication))
    print(json.dumps({'B_commit': commit, 'category_statuses': report['category_statuses'],
                      'evidence_archive': publication['evidence_archive'],
                      'report': digest(PUBLIC)}, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--commit', required=True,
                        help='Actual root-supplied 40-hex implementation B commit')
    parser.add_argument('--layout', type=Path, required=True,
                        help='Root-approved final archive guard at this directory/layout-verified.json')
    args = parser.parse_args()
    main(args.commit, args.layout)
