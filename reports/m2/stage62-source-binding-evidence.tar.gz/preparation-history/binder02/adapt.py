"""Prepare binder02; never import or execute the binder."""
from pathlib import Path

out = Path(__file__).resolve().parent
source = out.parent / 'stage62-source-binding-01/bind.py'
s = source.read_text()
s = s.replace('Prepared before B. Execute only after the root agent supplies --commit and GO.',
              'Prepared after B from the preserved, unexecuted binder01. Root owns execution.\nOriginal checkpoint assembly raw output was not saved; this audit binds the\nseparate later read-only checkpoint verification without recreating that run.')
s = s.replace("OUT = ROOT / 'target/m2/stage62-source-binding-01'", "OUT = ROOT / 'target/m2/stage62-source-binding-02'")
s = s.replace("BASE = 'b262208ccc537af2845d2107226bb4dac0ba7ecf'", "BASE = 'b262208ccc537af2845d2107226bb4dac0ba7ecf'\nIMPLEMENTATION_COMMIT = 'aac28e5b8d7a2182bc3e385410ff12228f246fb0'")
s = s.replace("CHECKPOINT_EXECUTION = 'target/m2/stage62-checkpoint-execution-01'", "CHECKPOINT_VERIFICATION = 'target/m2/stage62-checkpoint-verification-01'")
s = s.replace("    assert commit != BASE, 'implementation B must differ from the Java authority base'", "    assert commit == IMPLEMENTATION_COMMIT, 'explicit reviewed Stage62 implementation B required'\n    assert commit != BASE, 'implementation B must differ from the Java authority base'")
a = s.index('    checkpoint_execution_files = {')
b = s.index('    for category, name, value in rows:', a)
s = s[:a] + '''    checkpoint_verification_files = {
        name: ROOT / CHECKPOINT_VERIFICATION / name
        for name in ('verify.py', 'run.py', 'report.json', 'source-before.json',
                     'source-after.json', 'stdout.bin', 'stderr.bin')}
    checkpoint_verification_ids = {name: digest(path) for name, path in checkpoint_verification_files.items()}
    verification = json.loads(checkpoint_verification_files['report.json'].read_bytes())
    assert verification['exit_code'] == 0 and verification['complete'] is True
    assert verification['source_stable'] is True and verification['current_head'] == commit
    assert verification['verification_is_later'] is True
    assert verification['original_assembly_raw_available'] is False and verification['read_only'] is True
    assert verification['cwd'] == str(ROOT)
    assert verification['command'] == [verification['python']['executable'], '-B',
                                       str(ROOT / CHECKPOINT_VERIFICATION / 'verify.py')]
    verification_inputs = json.loads(checkpoint_verification_files['source-before.json'].read_bytes())
    assert verification_inputs == json.loads(checkpoint_verification_files['source-after.json'].read_bytes())
    assert verification['source_before'] == verification['source_after'] == verification_inputs
    expected_verification_inputs = {CHECKPOINT_VERIFICATION + '/' + name for name in ('run.py', 'verify.py')}
    expected_verification_inputs |= {'target/m2/stage62-checkpoint-01/prepare.py',
                                    'target/m2/stage62-publication-review-01/report.json', CHECKPOINT}
    expected_verification_inputs |= set(PUBLIC_ARCHIVES.values()) | set(PUBLICATIONS.values())
    assert set(verification_inputs) == expected_verification_inputs
    assert verification_inputs == {name: digest(ROOT / name) for name in verification_inputs}
    assert verification['checkpoint_identity'] == checkpoint_id
    for channel in ('stdout', 'stderr'):
        assert verification[channel] == checkpoint_verification_ids[channel + '.bin']
    assert checkpoint_verification_files['stderr.bin'].read_bytes() == b''
    verification_summary = json.loads(checkpoint_verification_files['stdout.bin'].read_bytes())
    assert verification['verification_summary'] == verification_summary
    assert verification_summary['current_head'] == commit and verification_summary['recorded_assembly_base'] == BASE
    assert verification_summary['base_is_ancestor'] is True
    assert verification_summary['verification_is_later'] is True
    assert verification_summary['original_assembly_raw_available'] is False and verification_summary['read_only'] is True
    assert verification_summary['checkpoint_identity'] == {'path': CHECKPOINT, **checkpoint_id}
    assert verification_summary['checkpoint_declared_identities_checked'] == 87
    assert set(verification_summary['groups']) == set(PUBLIC_ARCHIVES)
    for group, item in verification_summary['groups'].items():
        assert item['full_member_hash_readback'] is True
        assert item['archive'] == archive_ids[group] and item['publication'] == publication_ids[group]
    review_path = 'target/m2/stage62-publication-review-01/report.json'
    assert verification_summary['independent_review'] == {'path': review_path, **verification_inputs[review_path]}
''' + s[b:]
s = s.replace('        full_archive_counts[category] = len(observed)', '''        full_archive_counts[category] = len(observed)
        assert verification_summary['groups'][category]['members'] == len(observed)
    assert verification_summary['member_readback_total'] == sum(full_archive_counts.values())''')
s = s.replace('    assert checkpoint_execution_ids == {name: digest(path) for name, path in checkpoint_execution_files.items()}', '''    assert checkpoint_verification_ids == {name: digest(path) for name, path in checkpoint_verification_files.items()}
    assert verification_inputs == {name: digest(ROOT / name) for name in verification_inputs}''')
s = s.replace("        'checkpoint_execution': {'path': CHECKPOINT_EXECUTION, 'exit_code': 0, 'files': checkpoint_execution_ids},", '''        'checkpoint_verification': {'path': CHECKPOINT_VERIFICATION, 'exit_code': 0,
                                    'files': checkpoint_verification_ids,
                                    'verification_is_later': True, 'original_assembly_raw_available': False,
                                    'read_only': True, 'summary': verification_summary},
        'original_checkpoint_assembly_raw_available': False,''')
s = s.replace("                   'Source binding does not rerun evaluators, builds or tests and does not establish full API, whole M2 or performance compatibility.'],", """                   'Original checkpoint assembly stdout/stderr were not saved. The separately captured later read-only verification checks existing checkpoint/publication bytes; it is not a capture or reconstruction of the original assembly execution.',
                   'Source binding does not rerun evaluators, builds or tests and does not establish full API, whole M2 or performance compatibility.'],""")
s = s.replace("    payloads.update({'checkpoint-execution/' + name: path\n                     for name, path in checkpoint_execution_files.items()})", """    payloads.update({'checkpoint-verification/' + name: path
                     for name, path in checkpoint_verification_files.items()})
    payloads['checkpoint-verification/independent-publication-review.json'] = ROOT / review_path
    payloads['preparation-history/binder01.py'] = ROOT / 'target/m2/stage62-source-binding-01/bind.py'
    payloads['preparation-history/preparation01.json'] = ROOT / 'target/m2/stage62-source-binding-01/preparation.json'
    payloads['adapter.py'] = OUT / 'adapt.py'""")
assert 'CHECKPOINT_EXECUTION' not in s and 'checkpoint_execution' not in s
assert 'checkpoint-execution-01' not in s
assert 'stage61' not in s and 'Stage61' not in s
(out / 'bind.py').write_text(s)
compile(s, str(out / 'bind.py'), 'exec')
print('binder02 prepared and syntax checked; not executed')
