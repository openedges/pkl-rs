"""Record binder02 preparation; syntax-check only, never execute its module."""
from pathlib import Path
import datetime
import hashlib
import json

out = Path(__file__).resolve().parent
root = out.parents[2]

def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

for name in ('bind.py', 'adapt.py', 'record-preparation.py'):
    path = out / name
    compile(path.read_bytes(), str(path), 'exec')
old = root / 'target/m2/stage62-source-binding-01'
assert identity(old / 'bind.py') == {'bytes': 47610, 'sha256': 'c785388a67ebf8662f5dc3262f0d11d835f79e04e7cd62280b73bc462a8b1b7c'}
assert identity(out / 'layout-verified.json') == {'bytes': 7263, 'sha256': 'b7cf857c5793588147b1093562bdfd782c1f6eaa027760396d038e94d6a61e50'}
verification_dir = root / 'target/m2/stage62-checkpoint-verification-01'
verification = json.loads((verification_dir / 'report.json').read_bytes())
assert verification['complete'] is True and verification['exit_code'] == 0 and verification['source_stable'] is True
assert verification['current_head'] == 'aac28e5b8d7a2182bc3e385410ff12228f246fb0'
assert verification['verification_is_later'] is True and verification['original_assembly_raw_available'] is False and verification['read_only'] is True
preparation = {
    'schema': 1, 'status': 'prepared-unexecuted',
    'prepared_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'binder_executed': False,
    'syntax_check': 'compile(source_bytes, path, exec) only; binder was not imported or executed',
    'implementation_commit': 'aac28e5b8d7a2182bc3e385410ff12228f246fb0',
    'source_base': 'b262208ccc537af2845d2107226bb4dac0ba7ecf',
    'preparation_files': {str((out / name).relative_to(root)): identity(out / name)
                          for name in ('bind.py', 'adapt.py', 'record-preparation.py', 'layout-verified.json')},
    'preserved_preparation': {str((old / name).relative_to(root)): identity(old / name)
                             for name in ('bind.py', 'preparation.json', 'assemble.py', 'config-fragment.py', 'checks-fragment.py', 'record-preparation.py')},
    'source_binding_schema': {
        'manifest_categories': 36,
        'copied_source_members_in_published_inventories': 10446,
        'named_archived_execution_proofs': 14,
        'ignored_source_manifest_rows': {'platform_wrapper': 2, 'comparison_wrapper': 3, 'tool_validation': 1, 'data_size_regression': 1},
        'allowed_statuses': ['matches_B', 'historical_document_from_base', 'archived_execution_tool_not_B'],
        'historical_base_documents': ['PLAN.md', 'README.md', 'TESTING.md', 'docs/m2-language.md'],
        'generic_historical_source_exception_option': False,
    },
    'checkpoint_verification': {
        'path': 'target/m2/stage62-checkpoint-verification-01',
        'files': {name: identity(verification_dir / name) for name in
                  ('verify.py', 'run.py', 'source-before.json', 'source-after.json', 'report.json', 'stdout.bin', 'stderr.bin')},
        'verification_is_later': True, 'original_assembly_raw_available': False, 'read_only': True,
        'actual_command': verification['command'],
        'checkpoint_identity': verification['checkpoint_identity'],
        'checkpoint_declared_identities_checked': 87,
        'archive_members_read_back': 160577,
        'note': 'This later process checked existing checkpoint/publication bytes under the real implementation B HEAD. It did not reconstruct or recapture the original checkpoint assembly execution.',
    },
    'changes_from_binder01': [
        'Output directory is source-binding-02, with implementation B explicitly pinned and root-provided layout guard preserved.',
        'Missing original checkpoint-execution files are replaced by the actual separately captured later checkpoint-verification files and their exact report schema.',
        'Original assembly raw output remains unavailable and is explicitly reported as such; no historical HEAD substitution or reconstruction is used.',
        'All substantive source, Git blob, copied-file, archive/member, scalar, platform, cohort and wrapper checks remain unchanged.',
        'Own binding evidence includes later verifier sources/raw channels/identity snapshots, its independent review, and preserved binder01 preparation bytes.',
    ],
    'execution_command': ['python3', 'target/m2/stage62-source-binding-02/bind.py', '--commit',
                          'aac28e5b8d7a2182bc3e385410ff12228f246fb0', '--layout',
                          'target/m2/stage62-source-binding-02/layout-verified.json'],
    'public_evidence_archive_path': 'reports/m2/stage62-source-binding-evidence.tar.gz',
    'limitations': [
        'Original checkpoint assembly stdout/stderr were not saved locally. Later verification is separate evidence and does not repair that missing execution record.',
        'Preparation does not execute the binder, perform a build/evaluator run, mutate Git/source/published evidence, or establish full M2, full public API, typed export, complete math functions, or performance targets.',
    ],
}
with (out / 'preparation.json').open('x') as stream:
    stream.write(json.dumps(preparation, indent=2, sort_keys=True) + '\n')
print(json.dumps({'binder': {'path': str((out/'bind.py').relative_to(root)), **identity(out/'bind.py')},
                  'preparation': identity(out/'preparation.json'), 'binder_executed': False,
                  'layout_preserved': True, 'binder01_preserved': True}, sort_keys=True))
