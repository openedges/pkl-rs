"""Record the actual post-commit source-binding process without rerunning guests."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BINDER = ROOT / "target/m2/stage62-source-binding-02"
COMMIT = "aac28e5b8d7a2182bc3e385410ff12228f246fb0"


def identity(path):
    with path.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    return {"bytes": path.stat().st_size, "sha256": digest}


def write(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def main():
    assert not (OUT / "report.json").exists()
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip() == COMMIT
    inputs = [Path(__file__).resolve(), *(BINDER / name for name in
              ("bind.py", "preparation.json", "layout-verified.json")),
              ROOT / "target/m2/stage62-checkpoint-verification-01/report.json"]
    before = {str(path.relative_to(ROOT)): identity(path) for path in inputs}
    write("source-before.json", before)
    command = [sys.executable, "-B", str(BINDER / "bind.py"), "--commit", COMMIT,
               "--layout", str(BINDER / "layout-verified.json")]
    start = time.time()
    with (OUT / "stdout.bin").open("xb") as stdout, (OUT / "stderr.bin").open("xb") as stderr:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
    after = {str(path.relative_to(ROOT)): identity(path) for path in inputs}
    write("source-after.json", after)
    report = {"schema": 1, "kind": "stage62-post-commit-source-binding-execution",
              "command": command, "cwd": str(ROOT), "implementation_commit": COMMIT,
              "started_epoch": start, "finished_epoch": time.time(),
              "exit_code": result.returncode, "complete": True,
              "host": platform.uname()._asdict(),
              "python": {"executable": sys.executable, "version": sys.version,
                         "identity": identity(Path(sys.executable))},
              "environment": {name: os.environ.get(name) for name in
                              ("LANG", "LC_ALL", "TZ", "PATH", "PYTHONHASHSEED")},
              "source_stable": before == after,
              "stdout": identity(OUT / "stdout.bin"), "stderr": identity(OUT / "stderr.bin"),
              "guest_execution": False}
    write("report.json", report)
    print(json.dumps({"exit_code": result.returncode, "source_stable": before == after,
                      "report": identity(OUT / "report.json")}, sort_keys=True))
    return result.returncode if result.returncode else (0 if before == after else 1)


if __name__ == "__main__":
    raise SystemExit(main())
