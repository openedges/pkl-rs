# M2 stage5 exact-commit CI evidence

This bundle preserves the original GitHub artifact ZIP bytes, exact-commit source verification, process captures, and an offline replay proof for implementation commit `3a70e033eb93f4cbb9526467e627313cc72e5784`, CI run `39411357487`.

The sealed portable package is under `package/`. Follow `package/README.md` to repeat verification using the exact Git commit and pinned Pkl submodule. `offline-proof/` records the final replay of that sealed package. No captured binary is executed by the offline verifier.

The outer `EVIDENCE.json` inventories this bundle. The inner `package/package-manifest.json` inventories the portable package. Recorded compatibility failures and incomplete M2/API/performance requirements remain open.
