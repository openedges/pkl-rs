"""Capture exact-commit CI status without downloading artifacts."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--commit', required=True)
parser.add_argument('--run', required=True, type=int)
parser.add_argument('--repo', required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
expected = {'M1 architecture experiments (known gaps recorded)', 'M2 language development (full gate incomplete)',
            'Compatibility tooling and Java replay', 'Workspace (windows-latest)', 'Workspace (macos-latest)', 'Workspace (ubuntu-latest)'}

def capture(pair):
    label, endpoint, iteration = pair
    command = ['gh', 'api', endpoint]
    started = time.monotonic_ns()
    process = subprocess.run(command, capture_output=True, timeout=45)
    prefix = args.output/f'poll-{iteration:03}-{label}'
    prefix.with_suffix('.json').write_bytes(process.stdout)
    prefix.with_suffix('.stderr.bin').write_bytes(process.stderr)
    metadata = {'command':command,'cwd':str(Path.cwd()),'exit_code':process.returncode,'timed_out':False,
                'elapsed_ns':time.monotonic_ns()-started,'stdout_sha256':hashlib.sha256(process.stdout).hexdigest(),
                'stderr_sha256':hashlib.sha256(process.stderr).hexdigest(),'stdout_bytes':len(process.stdout),'stderr_bytes':len(process.stderr)}
    prefix.with_suffix('.process.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n')
    if process.returncode:
        raise RuntimeError('GitHub status API failed: '+endpoint)
    return json.loads(process.stdout)

previous = None
iteration = 0
while True:
    endpoint=f'repos/{args.repo}/actions/runs/{args.run}'
    with ThreadPoolExecutor(max_workers=2) as pool:
        workflow,jobs=pool.map(capture,[('run',endpoint,iteration),('jobs',endpoint+'/jobs?per_page=100',iteration)])
    if workflow['id']!=args.run or workflow['head_sha']!=args.commit:
        raise RuntimeError('Exact requested CI commit/run identity differs')
    if len(jobs['jobs'])!=jobs['total_count']:
        raise RuntimeError('GitHub jobs metadata is incomplete')
    rows=[{k:job.get(k)for k in ['name','status','conclusion']}for job in jobs['jobs']]
    state={'status':workflow['status'],'conclusion':workflow['conclusion'],'jobs':rows}
    if state!=previous:
        print(json.dumps(state,sort_keys=True),flush=True)
        previous=state
    failed=[row for row in rows if row['conclusion']in {'failure','cancelled','timed_out','action_required'}]
    if failed:
        raise RuntimeError('CI job failed: '+', '.join(row['name']for row in failed))
    if workflow['status']=='completed':
        if workflow['conclusion']!='success' or {row['name']for row in rows}!=expected or any(row['status']!='completed'or row['conclusion']!='success'for row in rows):
            raise RuntimeError('CI did not complete all six required jobs successfully')
        summary={'commit':args.commit,'run_id':args.run,'repository':args.repo,'workflow_status':'completed','conclusion':'success','all_six_jobs_succeeded':True,'jobs':rows,'status_snapshots':iteration+1,'scope':'Requested stage5 commit CI terminal status; no artifact download, repackaging, or compatibility evidence acquisition.'}
        (args.output/'status-summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
        break
    iteration+=1
    time.sleep(30)
