from pathlib import Path
import hashlib,json,subprocess,time,platform,sys
out=Path(__file__).resolve().parent
config=json.loads((out/'config.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
before={p:sha(p) for p in config['inputs']}
for name in before:
 p=Path(name);(out/p.name).write_bytes(p.read_bytes())
report={**config,'host':platform.platform(),'runnerSha256':sha(__file__),'inputsBefore':before,'complete':False}
start=time.time()
with (out/'stdout.bin').open('wb') as stdout,(out/'stderr.bin').open('wb') as stderr:
 process=subprocess.Popen(config['command'],stdout=stdout,stderr=stderr)
 report['pid']=process.pid;(out/'process-report.json').write_text(json.dumps(report,indent=2)+'\n')
 code=process.wait()
after={p:sha(p) for p in before}
report.update(exitCode=code,elapsedSeconds=time.time()-start,inputsAfter=after,changedInputs=[p for p in before if before[p]!=after[p]],complete=True)
(out/'process-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['pid','exitCode','elapsedSeconds','changedInputs']}))
print((out/'stdout.bin').read_text());print((out/'stderr.bin').read_text());sys.exit(code)
