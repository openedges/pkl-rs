import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createRequire} from 'node:module';
import {runModuleKeyExtendedCase,compareModuleKeyExtendedCase} from './modulekey-extended-session.mjs';
const api=createRequire(import.meta.url)(process.argv[2]);
const {fixtures}=JSON.parse(await readFile(new URL('./fixtures.json',import.meta.url)));
const {profiles}=JSON.parse(await readFile(new URL('./host-metadata.json',import.meta.url)));
await mkdir(new URL('./cases/',import.meta.url));
const summary={qualification:'Diagnostic helper acquisition on immutable Stage49 build05, not Stage50 candidate verification or full Java event parity.',sessions:0,calls:0,rawMatches:0,intendedOrdinaryMatched:0,diagnosticOnlyMatched:0,internalBoundaryRawMatched:0,acquisitionFailures:[],ordinaryFailures:[],rawFailures:[]};
for(const f of fixtures){
 const actual=runModuleKeyExtendedCase(api,f,profiles.find(p=>p.id===f.providerProfileId));
 const comparison=compareModuleKeyExtendedCase(f,actual);
 const name=`${f.id.replaceAll('/','_')}-${f.repeat}-${f.session}`;
 await writeFile(new URL(`./cases/${name}.json`,import.meta.url),JSON.stringify({actual,comparison},null,2)+'\n');
 summary.sessions++; summary.calls+=actual.calls.length;
 summary.rawMatches+=comparison.cases.filter(c=>c.rawMatched).length;
 for(const key of ['intendedOrdinaryMatched','diagnosticOnlyMatched','internalBoundaryRawMatched'])summary[key]+=comparison[key];
 if(!comparison.acquisitionIntegrityPassed)summary.acquisitionFailures.push({name,error:actual.acquisitionError,constructor:actual.constructorError,architecture:actual.architecture,last:actual.requests.at(-1)});
 if(comparison.ordinaryFailures.length)summary.ordinaryFailures.push({name,failures:comparison.ordinaryFailures});
 if(comparison.rawFailures.length)summary.rawFailures.push({name,failures:comparison.rawFailures});
}
await writeFile(new URL('./summary.json',import.meta.url),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({...summary,acquisitionFailures:summary.acquisitionFailures.map(x=>({name:x.name,message:x.error?.message})),ordinaryFailures:summary.ordinaryFailures.length,rawFailures:summary.rawFailures.length},null,2));
