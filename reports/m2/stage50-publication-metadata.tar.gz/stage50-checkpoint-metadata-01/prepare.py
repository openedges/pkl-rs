"""Summarize original Stage50 reports without changing their outcomes."""
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/m2'
OUT = ROOT / 'reports/m2'


def read(relative):
    path = BASE / relative
    return json.loads(path.read_bytes())


def reference(relative):
    path = BASE / relative
    return {'originalPath': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def save(name, value):
    with (OUT / name).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


integration = read('stage50-platform-integration-01/report.json')
assert integration['complete'] and not any(integration[k] for k in ['infrastructureErrors','sourceChanges','artifactChanges','runtimeChanges'])
drivers = []
for command in integration['commands']:
    label = command['label']
    relative = f'stage50-platform-integration-01/{label}/execution.json'
    original = read(relative)
    row = {'label': label, 'exitCode': command['exitCode'], 'report': reference(relative),
           'gates': {k: v for k, v in original.items() if type(v) is bool}, 'targets': {}}
    for name, target in original['targets'].items():
        row['targets'][name] = {k: v for k, v in target.items()
                              if k not in {'results','cases','sessions'} or type(v) in {int,bool}}
    drivers.append(row)
publication = read('stage50-root-publication-01/report.json')
assert publication['complete']
platform = {'schema': 1, 'scope': 'Actual local macOS native/Node/Chromium controls for Stage50 candidate02; strict failures remain failures.',
            'host': integration['environment'],
            'm1Report': reference('stage50-platform-control-01/report.json'),
            'm1PrimitiveReport': reference('stage50-platform-control-01/primitives/report.json'),
            'artifactPins': reference('stage50-platform-control-01/artifact-pins.json'),
            'integration': reference('stage50-platform-integration-01/report.json'),
            'rootTerminalReceipt': reference('stage50-platform-integration-01/root-terminal-receipt.json'),
            'drivers': drivers, 'archives': publication['archives'],
            'archiveVerification': {'wrapperSession':73957,'actualExitCode':0,'terminalChunk':'521ba9','separateVerifyAndAllSelectedRawMemberReadback':True},
            'm1NodeProvenanceQualification': 'M1 launches bare node and records child version, not child execPath/hash. Parent observes the executable path/hash and unchanged environment; exact child executable identity is inferred. All eleven integration commands explicitly launch the recorded absolute Node path.',
            'remainingGates': ['Two Java regex mismatches', 'ModuleKey full Java event/counter parity', 'Eight extended Java internal boundaries', 'Loader/inheritance exact request counters', 'Declared ModuleInfo/constructor/terminal/unexecuted boundaries', 'Complete M2, release platforms, speed and peak RSS']}
save('stage50-platform-captures.json', platform)
required = read('stage50-required-rust-02/report.json')
native = read('stage50-native-controls-build02-01/report.json')
checkpoint = {'schema':1, 'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope':'Resident executable storage and extended ModuleKey comparisons on frozen Stage50 candidate02; not complete M2 or product/performance compatibility.',
              'baselineCommit':'d0450699f59174752d4759e4fb9b7e6eeef586fc',
              'candidate':native['candidate'],
              'implementation':['Fixed prepared prefix plus resident dynamic segments; committed logical addresses are not reused.', 'Reachability retires complete segments and independent public-operation entries, preserving escaped declarations/closures and suspended frames.', 'Transactional compile rollback restores replaced module units and metadata.', 'URI preparation mutates only blocks with actual URI changes, preserving unrelated snapshot owners.'],
              'storageValidation':{'focusedTests':190,'ordinaryAndReentrantEvaluationCounts':[20,200], 'measures':'Resident segment counts, slots, capacities, nested storage, source bytes and selected heap/declaration counts.', 'wholeProcessRssMeasured':False, 'javaPerformanceTargetClaimed':False,
                                   'report':reference('stage50-code-storage-focused-02/report.json'),'independentReview':reference('stage50-code-storage-c-review-02/report.json')},
              'requiredRust':{'sourceCount':required['sourceCount'],'sourceStable':required['sourceStable'],'checks':required['checks'],'report':reference('stage50-required-rust-02/report.json'),'wrapperSession':44569,'exitCode':0,'terminalChunk':'96b9ad'},
              'native':{'report':reference('stage50-native-controls-build02-01/report.json'),'independentAudit':reference('stage50-native-build02-c-audit-02/report.json'),'provided212':{'calls':212,'rawMatches':212,'ordinaryCompatible':212},'public212':{'calls':212,'rawMatches':212,'ordinaryCompatible':212},'extended944':{'calls':944,'rawMatches':936,'ordinaryCompatible':836,'intentNotReachedDiagnosticMatches':100,'internalBoundaryMismatches':8},'processes':212,'acquisitionIntegrityPassed':native['allAcquisitionIntegrityPassed'],'fullJavaEventsCountersPassed':native['fullJavaEventCounterGatePassed'],'repeatedProfilesAreNotDistinctFeatures':True},
              'platformCaptures':'stage50-platform-captures.json',
              'nativeToolingCaptures':'stage50-native-tooling-captures.json',
              'm1NodeProvenanceQualification':platform['m1NodeProvenanceQualification'],
              'inventory':{'rows':4527,'ready':3664,'unimplemented':823,'unmapped':40,'requirements':475,'countInterpretation':'Overlapping accounting rows, not distinct features or completion percentage. Only source hashes refreshed.'},
              'fullSelectedRegression':{'stage50Acquired':False,'stage48And49':'Separate fixed-commit acquisitions; never inherited as Stage50 results.','latestPublishedStage47':{'matches':3652,'selected':3664,'unsupported':2,'mismatches':9,'oracleErrors':1}},
              'historicalFailuresPreserved':['Fixture exporter and test expectations', 'Provider error-classification gap', 'Old Stage49-artifact GC observation comparison', 'Earlier audit assumptions', 'Candidate01 unnecessary copy-on-write and Clippy failures'],
              'fullM2Complete':False,'hostedCiClaimed':False,'releasePlatformCoverageComplete':False,'performanceTargetClaimed':False}
save('stage50-implementation-checkpoint.json',checkpoint)
print(json.dumps({'created':['stage50-platform-captures.json','stage50-implementation-checkpoint.json'],'drivers':len(drivers)}))
