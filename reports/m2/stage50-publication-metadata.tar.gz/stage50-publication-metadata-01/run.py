"""Publish explicit closed provenance roots; preserve their original bytes."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'target/m2'
sha = lambda data: hashlib.sha256(data).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
save = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
assert not (OUT/'report.json').exists()
selection = json.loads((OUT/'selection.json').read_bytes())
paths = []
for name in selection['closedTrees']:
    root = BASE/name
    assert root.is_dir() and not root.is_symlink()
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs.sort()
        for name in dirs:
            assert not (Path(directory)/name).is_symlink()
        paths.extend(Path(directory)/name for name in sorted(files))
for name in selection['directFilesOnly']:
    root = BASE/name
    paths.extend(p for p in sorted(root.iterdir()) if p.is_file() and not p.name.endswith('.tar.gz'))
paths += [BASE/name for name in selection['files']]
paths += [Path(__file__), OUT/'selection.json']
assert len(paths) == len(set(paths))
staging = OUT/'staging'
staging.mkdir()
originals = {}
for path in paths:
    mode = path.lstat().st_mode
    assert stat.S_ISREG(mode), path
    data = path.read_bytes()
    relative = path.relative_to(BASE).as_posix()
    dest = staging/relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    originals[relative] = {'path':str(path), 'bytes':len(data), 'sha256':sha(data), 'mode':stat.S_IMODE(mode)}
save(staging/'original-paths.json', originals)
archive = OUT/'stage50-publication-metadata.tar.gz'
report = {'scope':'Source-to-staged-Git binding, publication commands and original fixture whitespace qualification. No evaluator executions.', 'startedUtc':now(), 'commands':[], 'selectedFiles':len(originals)}
save(OUT/'report.json',report)
for action, argv in [('create',[sys.executable,str(ROOT/'tools/evidence.py'),'create',str(staging),str(archive)]),('verify',[sys.executable,str(ROOT/'tools/evidence.py'),'verify',str(archive)])]:
    row={'argv':argv,'startedUtc':now()}
    with (OUT/(action+'.stdout.bin')).open('wb') as stdout, (OUT/(action+'.stderr.bin')).open('wb') as stderr:
        process=subprocess.Popen(argv,cwd=ROOT,stdout=stdout,stderr=stderr)
        print('START',action,process.pid,flush=True)
        row.update(pid=process.pid,exitCode=process.wait(),finishedUtc=now())
    report['commands'].append(row)
    save(OUT/'report.json',report)
    assert row['exitCode']==0,row
seen=set()
with tarfile.open(archive,'r:gz') as packed:
    for member in packed:
        if member.name not in originals:
            assert member.name in {'EVIDENCE.json','original-paths.json'},member.name
            continue
        data=packed.extractfile(member).read()
        facts=originals[member.name]
        assert len(data)==facts['bytes'] and sha(data)==facts['sha256']
        seen.add(member.name)
assert seen==set(originals)
changes=[]
for name,before in originals.items():
    path=Path(before['path']);mode=path.lstat().st_mode;data=path.read_bytes()
    if not stat.S_ISREG(mode) or stat.S_IMODE(mode)!=before['mode'] or len(data)!=before['bytes'] or sha(data)!=before['sha256']:
        changes.append(name)
assert not changes,changes
facts={'repositoryPath':'reports/m2/'+archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size}
assert facts['bytes']<100_000_000
destination=ROOT/facts['repositoryPath']
with destination.open('xb') as output,archive.open('rb') as source:
    shutil.copyfileobj(source,output)
assert sha(destination.read_bytes())==facts['sha256']
report.update(complete=True,finishedUtc=now(),archive=facts,readbackFiles=len(seen),originalChanges=changes)
save(OUT/'report.json',report)
print(json.dumps({'complete':True,'files':len(seen),'archive':facts}),flush=True)
