"""Archive explicitly selected, closed Stage50 platform producers unchanged."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = ROOT / "target/m2"
sha = lambda data: hashlib.sha256(data).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def capture(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode), path
    data = path.read_bytes()
    return data, {"path": str(path), "kind": "regular", "mode": stat.S_IMODE(info.st_mode), "bytes": len(data), "sha256": sha(data)}


assert not (OUT / "report.json").exists(), "Preserve previous publication attempts."
groups = json.loads((OUT / "selection.json").read_bytes())
report = {"schema": 1, "scope": "Closed Stage50 actual platform evidence. Acquisition and archive integrity do not establish full compatibility, M2 completion, or performance targets.", "startedUtc": now(), "toolSha256": sha((ROOT / "tools/evidence.py").read_bytes()), "archives": []}
save(OUT / "report.json", report)
for group, names in groups.items():
    staging = OUT / "staging" / group
    staging.mkdir(parents=True)
    originals = {}
    for name in names:
        source = BASE / name
        assert source.is_dir() and not source.is_symlink(), source
        for directory, dirs, files in os.walk(source, followlinks=False):
            dirs.sort()
            for dirname in dirs:
                assert not (Path(directory) / dirname).is_symlink(), dirname
            for filename in sorted(files):
                path = Path(directory) / filename
                data, facts = capture(path)
                relative = path.relative_to(BASE).as_posix()
                target = staging / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
                originals[relative] = facts
    save(staging / "original-paths.json", originals)
    archive = OUT / ("stage50-" + group + ".tar.gz")
    row = {"group": group, "roots": names, "archive": str(archive), "repositoryPath": "reports/m2/" + archive.name, "originalFiles": len(originals), "originalBytes": sum(x["bytes"] for x in originals.values()), "commands": []}
    for action, argv in [("create", [sys.executable, str(ROOT / "tools/evidence.py"), "create", str(staging), str(archive)]), ("verify", [sys.executable, str(ROOT / "tools/evidence.py"), "verify", str(archive)])]:
        command = {"action": action, "argv": argv, "startedUtc": now()}
        with (OUT / (group + "-" + action + ".stdout.bin")).open("wb") as stdout, (OUT / (group + "-" + action + ".stderr.bin")).open("wb") as stderr:
            process = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
            print("START", group, action, process.pid, flush=True)
            command.update(pid=process.pid, exitCode=process.wait(), finishedUtc=now())
        row["commands"].append(command)
        save(OUT / (group + "-commands.json"), row["commands"])
        assert command["exitCode"] == 0, command
    readback = set()
    with tarfile.open(archive, "r:gz") as packed:
        for member in packed:
            if member.name not in originals:
                assert member.name in {"EVIDENCE.json", "original-paths.json"}, member.name
                continue
            assert member.isfile() and member.name not in readback, member.name
            data = packed.extractfile(member).read()
            facts = originals[member.name]
            assert len(data) == facts["bytes"] and sha(data) == facts["sha256"], member.name
            readback.add(member.name)
    assert readback == set(originals)
    changes = []
    for name, facts in originals.items():
        _, after = capture(Path(facts["path"]))
        if after != facts:
            changes.append({"member": name, "before": facts, "after": after})
    assert not changes, changes
    row.update(sha256=sha(archive.read_bytes()), bytes=archive.stat().st_size, rawReadbackFiles=len(readback), originalChanges=changes)
    assert row["bytes"] < 100_000_000, row
    destination = ROOT / row["repositoryPath"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as sink, archive.open("rb") as original:
        shutil.copyfileobj(original, sink)
    assert sha(destination.read_bytes()) == row["sha256"]
    report["archives"].append(row)
    save(OUT / "report.json", report)
    print("DONE", group, row["originalFiles"], row["bytes"], row["sha256"], flush=True)
report.update(complete=True, finishedUtc=now())
save(OUT / "report.json", report)
