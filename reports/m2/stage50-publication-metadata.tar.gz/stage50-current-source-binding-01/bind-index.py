"""Read actual staged blobs; never write the index, Git objects, or sources."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import threading
import time

BASELINE = 'd0450699f59174752d4759e4fb9b7e6eeef586fc'

def parse_index(data):
    rows = {}
    for record in data.split(b'\0'):
        if not record:
            continue
        header, path = record.split(b'\t', 1)
        mode, oid, stage = header.split()
        if stage != b'0' or path in rows:
            raise ValueError('unmerged or duplicate index path')
        rows[path] = (mode.decode(), oid.decode())
    return rows

def tree_id(rows, algorithm='sha1'):
    tree = {}
    for path, (mode, oid) in rows.items():
        node = tree
        parts = path.split(b'/')
        for part in parts[:-1]:
            node = node.setdefault(part, {})
            if not isinstance(node, dict):
                raise ValueError('file/directory collision')
        node[parts[-1]] = (mode, oid)
    def finish(node):
        entries = []
        for name, value in node.items():
            if isinstance(value, dict):
                mode, oid, sort = '40000', finish(value), name + b'/'
            else:
                mode, oid = value
                sort = name
            entries.append((sort, mode.encode() + b' ' + name + b'\0' + bytes.fromhex(oid)))
        body = b''.join(row for _, row in sorted(entries))
        return hashlib.new(algorithm, b'tree ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    return finish(tree)

def blob_hashes(root, object_ids):
    ids = sorted(set(object_ids))
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    failures = []
    def feed():
        try:
            for oid in ids:
                process.stdin.write(oid.encode() + b'\n')
            process.stdin.close()
        except Exception as error:
            failures.append(str(error))
    writer = threading.Thread(target=feed, daemon=True)
    writer.start()
    hashes = {}
    try:
        for expected in ids:
            header = process.stdout.readline().split()
            if len(header) != 3 or header[0].decode() != expected or header[1] != b'blob':
                raise ValueError(f'unexpected cat-file header {header!r}')
            size = int(header[2])
            remaining = size
            digest = hashlib.sha256()
            while remaining:
                chunk = process.stdout.read(min(remaining, 1024 * 1024))
                if not chunk:
                    raise ValueError('truncated Git blob')
                digest.update(chunk)
                remaining -= len(chunk)
            if process.stdout.read(1) != b'\n':
                raise ValueError('invalid cat-file blob terminator')
            hashes[expected] = {'sha256': digest.hexdigest(), 'bytes': size}
        writer.join()
        stderr = process.stderr.read()
        if process.wait() or failures or stderr:
            raise ValueError(f'cat-file failed: {failures!r} {stderr!r}')
    except BaseException:
        process.kill()
        process.wait()
        raise
    finally:
        process.stdout.close()
        process.stderr.close()
    return hashes

def compare(source, actual):
    return {key: {'expected': source[key], 'actual': actual.get(key)}
            for key in ('sha256', 'bytes') if source[key] != actual.get(key)}

def publication_only(path):
    return path.startswith(('reports/', 'docs/')) or (not '/' in path and path.endswith('.md'))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--map', type=Path, required=True)
    parser.add_argument('--map-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root, out = args.root.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    def command(*argv):
        return subprocess.check_output(['git', *argv], cwd=root)
    def save(name, value):
        (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    data = args.map.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != args.map_sha256:
        raise ValueError('source map pin mismatch')
    sources = json.loads(data)
    started = time.time()
    parent = command('rev-parse', 'HEAD').decode().strip()
    if parent != BASELINE:
        raise ValueError('baseline parent mismatch')
    before = command('ls-files', '--stage', '-z')
    index = parse_index(before)
    algorithm = command('rev-parse', '--show-object-format').decode().strip()
    # Validate the read-only tree serializer against an existing Git tree.
    head_rows = {}
    for row in command('ls-tree', '-r', '-z', 'HEAD').split(b'\0'):
        if row:
            header, path = row.split(b'\t', 1)
            mode, kind, oid = header.split()
            head_rows[path] = (mode.decode(), oid.decode())
    expected_head_tree = command('rev-parse', 'HEAD^{tree}').decode().strip()
    if tree_id(head_rows, algorithm) != expected_head_tree:
        raise ValueError('Git tree serializer validation failed')
    changed = {os.fsdecode(p) for p in command('diff', '--cached', '--name-only', '-z', BASELINE).split(b'\0') if p}
    extra = sorted(changed - sources.keys() - {'external/pkl', 'external/pkl-pantry'})
    differences = []
    for path in extra:
        if not publication_only(path):
            differences.append({'path': path, 'kind': 'staged-source-not-covered-by-producer-map'})
    wanted = {}
    for path in sorted(set(sources) | set(extra)):
        record = index.get(os.fsencode(path))
        if not record:
            differences.append({'path': path, 'kind': 'missing-staged-source'})
        elif record[0] not in ('100644', '100755'):
            differences.append({'path': path, 'kind': 'unexpected-source-mode', 'mode': record[0]})
        else:
            wanted[path] = record
    hashes = blob_hashes(root, [oid for _, oid in wanted.values()])
    bound, publication = {}, {}
    for path, (mode, oid) in wanted.items():
        row = {'mode': mode, 'gitBlob': oid, **hashes[oid]}
        if path in sources:
            mismatch = compare(sources[path], row)
            if mismatch:
                differences.append({'path': path, 'kind': 'staged-blob-mismatch', 'fields': mismatch})
            bound[path] = row
        else:
            publication[path] = {**row, 'disposition': 'publication-only; not execution-tested source evidence'}
    pins = {'external/pkl': 'e51fb2f91774265666f94980ec630db794a4db2d',
            'external/pkl-pantry': '904a68184e54da378b0a0e8a911a3fab3956f693'}
    for path, expected in pins.items():
        if index.get(path.encode()) != ('160000', expected):
            differences.append({'path': path, 'kind': 'reference-gitlink-mismatch'})
    after = command('ls-files', '--stage', '-z')
    final_index = parse_index(after)
    for path, before_record in wanted.items():
        if final_index.get(os.fsencode(path)) != before_record:
            differences.append({'path': path, 'kind': 'source-index-changed-during-binding'})
    if command('rev-parse', 'HEAD').decode().strip() != parent:
        differences.append({'kind': 'HEAD-changed-during-binding'})
    save('source-blobs.json', bound)
    save('publication-only-blobs.json', publication)
    report = {'schema': 1, 'scope': 'Actual staged Git blob bytes joined to current producer input map; no source/index/object writes or evaluator reruns.',
              'parent': parent, 'sourceMap': {'path': str(args.map), 'sha256': digest},
              'startedUnix': started, 'finishedUnix': time.time(),
              'sourcePaths': len(sources), 'gitBoundSourcePaths': len(bound),
              'uniqueBlobsRead': len(hashes), 'publicationOnlyPaths': len(publication),
              'indexTreeBefore': tree_id(index, algorithm), 'indexTreeAfter': tree_id(final_index, algorithm),
              'indexEntriesBeforeSha256': hashlib.sha256(before).hexdigest(),
              'indexEntriesAfterSha256': hashlib.sha256(after).hexdigest(),
              'headTreeSerializerVerified': expected_head_tree, 'referenceGitlinks': pins,
              'differences': differences, 'passed': not differences,
              'implementationCommitNotYetClaimed': True}
    save('report.json', report)
    print(json.dumps(report))
    raise SystemExit(bool(differences))

if __name__ == '__main__':
    main()
