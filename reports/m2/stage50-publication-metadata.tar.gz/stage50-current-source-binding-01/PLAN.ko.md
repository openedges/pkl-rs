# Stage50 후보02 현재 소스와 staged Git blob 연결

## 범위

기준 parent는 `d0450699f59174752d4759e4fb9b7e6eeef586fc`다. 후보02 build227, focused/review220, M1 parent325/direct190, integration parent106 및 실제 execution input maps, required86455, 도구/fixture metadata의 경로별 SHA를 합친다. 각 producer map 자체의 경로·해시를 보존하고 현재 파일 byte/size와 가능한 producer snapshot을 별도로 검증한다.

`collect.py`는 명시적으로 열거한 producer 문서와 그 문서가 지정한 파일만 읽는다. 전체 target/cache 재귀 탐색을 하지 않는다. 같은 현재 파일이나 snapshot은 하나의 절대 경로로 dedup하여 읽는다. required86455에는 원래 byte snapshot이 없으므로 snapshot 전체가 있었다고 쓰지 않는다. broad required collector에 포함되었다는 사실을 그 fixture가 실제 실행되었다는 주장으로 사용하지 않는다.

현재 repository 입력, reference checkout source/gitlink, generated/외부 runtime artifact, 역사적 producer source를 구분한다. 후보01·초기 helper의 다른 byte는 후보02의 현재 source로 바꾸지 않는다. 이번 Stage50 입력에는 ignored Python cache가 없었다. 향후 나타나면 `git check-ignore`와 별도 증거 copy로 처리하고 강제 staging하지 않는다.

## 실제 진행

1. 최초 collector actual33710 exit0: repository input 86,570개와 실제 존재하는 snapshot을 검증했다. 현재 source와 snapshot 차이는 0이었다.
2. Root의 actual38115 staging 완료 신호 후 `bind-index.py`를 실행했다. checker6 tests는 actualfc117b exit0이었다.
3. 최초 staged check actual86584 exit1은 mapped source 86,570개 모두의 blob 일치를 확인했지만, staged `compatibility/m2-language.json`이 최초 union에 없음을 거부했다. 실패 산출물 `staged-01`은 보존한다.
4. `stage50-manifest-freshness-02/after.json`과 현재 inventory가 byte-identical임을 확인하고 `current-source-map-02.json`에 한 경로를 추가했다. 이전 `before.json`과 최초 freshness 실패는 historical disposition으로 남겼다. 최초 map/report는 수정하지 않았다.
5. 후속 staged check actual37197 exit0: 현재 repository input 86,571개 모두 실제 staged blob SHA-256/size와 일치했다. 새로운 extended fixture 32,968개를 포함한다. 입력 hash나 staged index를 바꾸는 명령은 사용하지 않았다.

## checker 계약

- `git ls-files --stage -z`로 실제 stage0 mode/OID/path를 읽고 unmerged/duplicate path를 거부한다.
- `git cat-file --batch`로 10,498개 고유 blob의 **실제 본문**을 읽어 SHA-256과 size를 계산한다. Git OID만 비교하거나 working-tree bytes를 staged bytes로 대신하지 않는다.
- source map에 없는 staged source/tool/fixture 경로는 실패한다. 문서와 reports는 publication-only로 별도 기록하며 실행 검증된 source라고 주장하지 않는다.
- 두 external gitlink의 mode160000/revision을 검사한다. 기록된 Java reference source 두 파일은 pinned revision의 실제 blob과 현재/기록 hash가 같음을 별도로 검증한다.
- index tree는 stage0 entries를 Git tree 형식으로 직렬화하여 읽기 전용으로 계산한다. 기존 HEAD tree와 계산값을 대조하여 알고리즘을 검증한다. `git write-tree`를 실행하지 않아 index/cache-tree나 Git object를 쓰지 않는다.
- 시작/종료 index entries와 현재 source의 `(path, mode, blob)`를 비교한다. 이후 report-only staging으로 전체 tree가 바뀌어도 `staged-02/source-blobs.json`의 source subset은 독립적으로 비교할 수 있다.
- 아직 commit 생성이나 push를 주장하지 않는다. 최종 root publication에서 실제 commit의 source subset과 이 blob 목록을 연결해야 한다.

## 확정 결과와 제한

최종 map `current-source-map-02.json` SHA-256은 `cf363981d7ed598b5e253f4faa1f660048f8012f4c4623198beaaf40fb493468`이다. source 크기는 154,631,318 bytes다. 343개 경로에는 producer snapshot byte가 있으며, 나머지 86,228개는 producer hash 기록만 있었다. 후자의 actual staged bytes를 이번에 검증한 것은 과거 runtime snapshot을 소급 생성한 것이 아니다.

staged source와 별도 문서 5개를 읽은 시점 index tree는 `75d569179edab8d712de3933d8d9a309832d5a5d`이고, before/after index-entry SHA-256은 모두 `0cde88ccdb6dfbb9b6f2df2d7d4ba4f91c4becabae71462db8f7f549dccdd3be`다. source 차이는 0이다.

이 결과는 source/archive/Git 연결을 위한 증거다. C의 실제 platform/raw semantics 감사, B의 native/fixture 감사와 archive publication을 재실행하거나 대신하지 않는다. nonrepository runtime/binary hash는 producer metadata로 보존하고 이 source checker가 전체 binary/raw audit를 다시 했다고 주장하지 않는다. 전체 언어 호환성, full observer parity, RSS/performance, Stage48/49 장기 실행의 완료 여부도 이 연결로 바뀌지 않는다.
