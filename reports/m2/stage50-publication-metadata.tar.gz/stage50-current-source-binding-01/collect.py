from pathlib import Path
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage50')
OUT = Path(__file__).resolve().parent
BASELINE = 'd0450699f59174752d4759e4fb9b7e6eeef586fc'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def pin(path):
    path = Path(path)
    return {'path': str(path), 'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}

def source_path(name):
    path = Path(name)
    if path.is_absolute():
        return str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
    assert '..' not in path.parts
    return str(path)

def category(path):
    p = Path(path)
    if p.is_absolute():
        return 'external-runtime-or-historical-input'
    if p.parts[0] == 'external':
        return 'pinned-reference-source'
    if p.parts[0] in ('target', '.cache') or 'node_modules' in p.parts:
        return 'nonrepository-generated-or-artifact'
    if '__pycache__' in p.parts and p.suffix == '.pyc':
        return 'generated-python-cache'
    return 'repository-input'

def main():
    assert not (OUT / 'current-source-map.json').exists(), 'Preserve prior collection'
    started = time.time()
    assert git('rev-parse', 'HEAD').decode().strip() == BASELINE
    versions = defaultdict(lambda: defaultdict(lambda: {'producers': [], 'snapshotCandidates': []}))
    producers = []
    document_pins = {}
    problems = []

    def load(path):
        path = ROOT / path if not Path(path).is_absolute() else Path(path)
        record = pin(path)
        document_pins[str(path)] = record
        return json.loads(path.read_bytes())

    def add(label, rel, field=None, after=None, snapshots=None, historical=False, rows=None):
        data = load(rel)
        mapping = rows if rows is not None else data[field] if field else data
        if after:
            assert mapping == load(after), (label, 'before-after mismatch')
        record = {'id': label, 'map': document_pins[str(ROOT / rel)],
                  'field': field, 'count': len(mapping),
                  'disposition': 'historical-evidence-only' if historical else 'current-candidate-input',
                  'snapshotRoot': str(ROOT / snapshots) if snapshots else None,
                  'afterMap': document_pins[str(ROOT / after)] if after else None}
        producers.append(record)
        for name, expected in mapping.items():
            path = source_path(name)
            digest = expected if isinstance(expected, str) else expected['sha256']
            assert len(digest) == 64 and all(c in '0123456789abcdef' for c in digest), (label, name)
            row = versions[path][digest]
            row['producers'].append(label)
            if isinstance(expected, dict) and 'bytes' in expected:
                previous = row.setdefault('declaredBytes', expected['bytes'])
                assert previous == expected['bytes'], (path, digest, 'size conflict')
            if snapshots and not Path(path).is_absolute():
                candidate = ROOT / snapshots / path
                if candidate.is_file():
                    row['snapshotCandidates'].append(str(candidate))
            if not historical:
                row['currentRequired'] = True

    add('build02', 'target/m2/stage50-storage-build02/sources-before.json',
        after='target/m2/stage50-storage-build02/sources-after.json', snapshots='target/m2/stage50-storage-build02/sources')
    build = load('target/m2/stage50-storage-build02/build.json')
    assert build['status'] == 'CLOSED' and build['exitCode'] == 0 and build['sourceStable']
    add('focused02', 'target/m2/stage50-code-storage-focused-02/sources-before.json', after='target/m2/stage50-code-storage-focused-02/sources-after.json')
    add('review02', 'target/m2/stage50-code-storage-c-review-02/source-map.json',
        after='target/m2/stage50-code-storage-c-review-02/source-after.json', snapshots='target/m2/stage50-code-storage-c-review-02/sources')
    add('required02', 'target/m2/stage50-required-rust-02/inputs-before.json', after='target/m2/stage50-required-rust-02/inputs-after.json')
    required = load('target/m2/stage50-required-rust-02/report.json')
    assert required['status'] == 'PASS' and required['sourceStable']
    add('m1-parent', 'target/m2/stage50-platform-control-01/sources-before.json',
        after='target/m2/stage50-platform-control-01/sources-after.json', snapshots='target/m2/stage50-platform-control-01/sources')
    add('m1-direct', 'target/m2/stage50-platform-control-01/primitives/report.json', field='source_hashes', snapshots='target/m2/stage50-platform-control-01/primitives/sources')
    add('integration-parent', 'target/m2/stage50-platform-integration-01/sources-before.json',
        after='target/m2/stage50-platform-integration-01/sources-after.json', snapshots='target/m2/stage50-platform-integration-01/sources')
    integration = load('target/m2/stage50-platform-integration-01/report.json')
    for command in integration['commands']:
        label = command['label']
        add('integration-' + label, f'target/m2/stage50-platform-integration-01/{label}/execution.json', field='artifactAndInputHashes')
    add('tool-final02', 'target/m2/stage50-modulekey-extended-final-checks-02/source-before.json', after='target/m2/stage50-modulekey-extended-final-checks-02/source-after.json')
    add('tool-handoff02', 'target/m2/stage50-modulekey-extended-handoff-02/handoff.json', field='sources', snapshots='target/m2/stage50-modulekey-extended-handoff-02/sources')
    add('helper-unit04', 'target/m2/stage50-extended-helper-c-unit-04/sources-before.json',
        after='target/m2/stage50-extended-helper-c-unit-04/sources-after.json', snapshots='target/m2/stage50-extended-helper-c-unit-04/sources')
    add('pipeline-review02', 'target/m2/stage50-extended-pipeline-c-review-02/inputs-before.json',
        after='target/m2/stage50-extended-pipeline-c-review-02/inputs-after.json', snapshots='target/m2/stage50-extended-pipeline-c-review-02/sources')
    manifest_path = 'tests/fixtures/m2-modulekey-extended/manifest.json'
    fixture = load(manifest_path)
    fixture_rows = {'tests/fixtures/m2-modulekey-extended/' + p: row for p, row in fixture['files'].items()}
    fixture_rows[manifest_path] = document_pins[str(ROOT / manifest_path)]
    add('installed-fixture', manifest_path, rows=fixture_rows)

    historical = [
        ('build01', 'stage50-storage-build01', 'sources-before.json', 'sources'),
        ('focused01', 'stage50-code-storage-focused-01', 'sources-before.json', None),
        ('review01', 'stage50-code-storage-c-review-01', 'source-map.json', 'sources'),
        ('required01', 'stage50-required-rust-01', 'inputs-before.json', None),
        ('tool-final01', 'stage50-modulekey-extended-final-checks-01', 'source-before.json', None),
        *[(f'helper-unit{i:02}', f'stage50-extended-helper-c-unit-{i:02}', 'sources-before.json', 'sources') for i in range(1, 4)],
        ('pipeline-review01', 'stage50-extended-pipeline-c-review-01', 'inputs-before.json', 'sources'),
        ('platform05-control01', 'stage50-extended944-platform05-control-01', 'sources-before.json', 'sources'),
        ('platform05-control02', 'stage50-extended944-platform05-control-02', 'sources-before.json', 'sources'),
    ]
    for label, folder, name, copies in historical:
        path = f'target/m2/{folder}/{name}'
        if (ROOT / path).is_file():
            add(label, path, snapshots=f'target/m2/{folder}/{copies}' if copies else None, historical=True)

    # Enumerated producer paths only: never walk target, caches, or the workspace.
    candidates = {str(ROOT / p) for p in versions if category(p) in ('repository-input', 'generated-python-cache', 'pinned-reference-source')}
    candidates.update(s for variants in versions.values() for row in variants.values() for s in row['snapshotCandidates'])
    def read(path):
        p = Path(path)
        if not p.is_file():
            return path, {'missing': True}
        before = p.stat()
        data = p.read_bytes()
        after = p.stat()
        assert (before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), ('source changed while reading', path)
        return path, {'sha256': sha(data), 'bytes': len(data)}
    with ThreadPoolExecutor(max_workers=8) as pool:
        observed = dict(pool.map(read, sorted(candidates)))
    current, other, historical_rows = {}, {}, {}
    for path, variants in sorted(versions.items()):
        kind = category(path)
        now = observed.get(str(ROOT / path), {}) if not Path(path).is_absolute() else {}
        for digest, row in variants.items():
            row['snapshots'] = []
            for snapshot in sorted(set(row.pop('snapshotCandidates'))):
                actual = observed[snapshot]
                if actual.get('sha256') != digest:
                    problems.append({'path': snapshot, 'expected': digest, 'actual': actual, 'kind': 'snapshot-mismatch'})
                else:
                    row['snapshots'].append({'path': snapshot, **actual})
            if kind in ('repository-input', 'pinned-reference-source', 'generated-python-cache') and now.get('sha256') == digest:
                if 'declaredBytes' in row and row['declaredBytes'] != now['bytes']:
                    problems.append({'path': path, 'kind': 'declared-size-mismatch'})
            elif row.get('currentRequired') and kind in ('repository-input', 'pinned-reference-source'):
                problems.append({'path': path, 'expected': digest, 'actual': now, 'kind': 'current-source-mismatch'})
        if kind == 'repository-input' and any(r.get('currentRequired') for r in variants.values()):
            row = variants.get(now.get('sha256'))
            if row:
                current[path] = {**now, 'producers': sorted(row['producers']), 'snapshots': row['snapshots']}
        elif kind != 'repository-input':
            other[path] = {'category': kind, 'versions': variants, 'currentObservation': now or None,
                           'nonSourceArtifactHashRecomputed': False if not now else None}
        older = {digest: row for digest, row in variants.items() if not row.get('currentRequired')}
        if older:
            historical_rows[path] = {'category': kind, 'currentSha256': now.get('sha256'), 'versions': older,
                                     'disposition': 'historical-producer-input; not a candidate02 verification claim'}

    caches = [path for path, row in other.items() if row['category'] == 'generated-python-cache']
    ignored = set()
    if caches:
        result = subprocess.run(['git', 'check-ignore', '--stdin', '-z'], cwd=ROOT,
                                input=b''.join(os.fsencode(p) + b'\0' for p in caches), stdout=subprocess.PIPE, check=False)
        assert result.returncode in (0, 1)
        ignored = {os.fsdecode(p) for p in result.stdout.split(b'\0') if p}
    for path in caches:
        row = other[path]
        row['gitIgnored'] = path in ignored
        if path not in ignored:
            problems.append({'path': path, 'kind': 'generated-cache-not-ignored'})
        digest = (row['currentObservation'] or {}).get('sha256')
        if digest in row['versions']:
            dest = OUT / 'ignored-captured-artifacts' / path
            dest.parent.mkdir(parents=True, exist_ok=True)
            data = (ROOT / path).read_bytes()
            assert sha(data) == digest
            dest.write_bytes(data)
            row['capturedCurrentBytes'] = pin(dest)

    lock = dict(line.split('=', 1) for line in (ROOT / 'references.lock').read_text().splitlines() if line and not line.startswith('#'))
    references = []
    for name in ('pkl', 'pkl-pantry'):
        path, revision = lock[name + '.path'], lock[name + '.revision']
        checkout = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / path).decode().strip()
        record = git('ls-files', '--stage', path).decode().strip()
        assert checkout == revision and record.split()[0:2] == ['160000', revision]
        references.append({'path': path, 'revision': revision, 'checkoutHead': checkout, 'indexRecord': record})
    save('current-source-map.json', current)
    save('producer-maps.json', producers)
    save('producer-documents.json', document_pins)
    save('historical-source-dispositions.json', historical_rows)
    save('nonrepository-inputs.json', other)
    save('reference-git-pins.json', references)
    report = {'baseline': BASELINE, 'startedUnix': started, 'finishedUnix': time.time(),
              'uniqueRepositoryInputs': len(current), 'repositoryInputBytes': sum(r['bytes'] for r in current.values()),
              'repositoryInputsWithSnapshot': sum(bool(r['snapshots']) for r in current.values()),
              'repositoryHashOnlyInputs': sum(not r['snapshots'] for r in current.values()),
              'installedExtendedFixtureInputs': sum(p.startswith('tests/fixtures/m2-modulekey-extended/') for p in current),
              'producerCounts': {p['id']: p['count'] for p in producers},
              'nonrepositoryCategories': dict(Counter(r['category'] for r in other.values())),
              'historicalPaths': len(historical_rows), 'uniqueActualByteReads': len(observed),
              'problems': problems, 'stagedIndexBindingExecuted': False,
              'scope': 'Exact enumerated current repository inputs and available snapshot joins; no evaluator rerun, semantic raw audit or Git index mutation.'}
    save('report.json', report)
    print(json.dumps(report))
    raise SystemExit(bool(problems))

if __name__ == '__main__':
    main()
