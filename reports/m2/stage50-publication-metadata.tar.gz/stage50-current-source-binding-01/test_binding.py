import importlib.util
from pathlib import Path
import unittest

spec = importlib.util.spec_from_file_location('binding', Path(__file__).with_name('bind-index.py'))
binding = importlib.util.module_from_spec(spec)
spec.loader.exec_module(binding)

class BindingChecks(unittest.TestCase):
    def test_unmerged_index_cannot_be_bound(self):
        with self.assertRaisesRegex(ValueError, 'unmerged'):
            binding.parse_index(b'100644 ' + b'a' * 40 + b' 2\tfile\0')

    def test_duplicate_stage_zero_path_cannot_be_bound(self):
        row = b'100644 ' + b'a' * 40 + b' 0\tfile\0'
        with self.assertRaisesRegex(ValueError, 'duplicate'):
            binding.parse_index(row + row)

    def test_nul_records_preserve_unicode_spaces_and_tabs(self):
        path = '日本語 name\tpart'.encode()
        result = binding.parse_index(b'100644 ' + b'a' * 40 + b' 0\t' + path + b'\0')
        self.assertEqual(result[path], ('100644', 'a' * 40))

    def test_empty_tree_matches_known_git_object(self):
        self.assertEqual(binding.tree_id({}), '4b825dc642cb6eb9a060e54bf8d69288fbee4904')

    def test_blob_size_and_digest_are_independently_checked(self):
        expected = {'sha256': 'a' * 64, 'bytes': 42}
        self.assertEqual(set(binding.compare(expected, {'sha256': 'b' * 64, 'bytes': 42})), {'sha256'})
        self.assertEqual(set(binding.compare(expected, {'sha256': 'a' * 64, 'bytes': 43})), {'bytes'})
        self.assertEqual(binding.compare(expected, expected), {})

    def test_uncovered_tools_and_fixtures_are_not_documentation(self):
        for path in ['tools/new.py', 'crates/pkl-runtime/src/new.rs', 'tests/fixtures/new.bin']:
            self.assertFalse(binding.publication_only(path))
        for path in ['README.md', 'docs/architecture.md', 'reports/m2/evidence.tar.gz']:
            self.assertTrue(binding.publication_only(path))

if __name__ == '__main__':
    unittest.main()
