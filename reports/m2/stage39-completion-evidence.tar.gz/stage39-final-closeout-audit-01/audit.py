from pathlib import Path,PurePosixPath
import json,hashlib,stat,tarfile,os,tempfile
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-final-closeout-audit-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
def file_sha(p):return sha(p.read_bytes())
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
results=[]
for kind in ['language']:
 capture_path=ROOT/'reports/m2'/f'stage39-final-{kind}-captures.json';capture=load(capture_path);archive=Path(capture['archive']);assert archive.stat().st_size==capture['archive_bytes'] and file_sha(archive)==capture['archive_sha256'];archive_before=file_sha(archive)
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();names=[m.name for m in members];assert len(names)==len(set(names)) and all(m.isfile() for m in members)
  for name in names:
   path=PurePosixPath(name);assert not path.is_absolute() and '..' not in path.parts and '.' not in path.parts
  inv_bytes=tf.extractfile('archive-inventory.json').read();assert sha(inv_bytes)==capture['inventory_sha256'];inv=json.loads(inv_bytes);plan_bytes=tf.extractfile('_preservation/plan.json').read();plan=json.loads(plan_bytes);helper=tf.extractfile('_preservation/archive.py').read();assert sha(plan_bytes)==capture['plan_sha256'] and sha(helper)==capture['helper_sha256']
  assert plan['archive']==str(archive) and plan['report']==str(capture_path);base=Path(plan['base']);assert base==ROOT/'target/m2';excluded={base/x for x in plan['excluded_cargo_paths']};assert inv['exclusions']==plan['excluded_cargo_paths'] and not inv['excluded_cache_contents_enumerated']
  cargo_proof={}
  for p in excluded:
   assert (p/'CACHEDIR.TAG').is_file() and (p/'.rustc_info.json').is_file();cargo_proof[p.relative_to(base).as_posix()]={'CACHEDIR.TAG_exists':True,'rustc_info_exists':True,'contentsEnumerated':False}
  current={};visited=[]
  for name in plan['roots']:
   p=base/name;assert not p.is_symlink()
   if p.is_file():current[name]=p;continue
   assert p.is_dir()
   for directory,children,files in os.walk(p,topdown=True,followlinks=False):
    # Exact known Cargo trees are removed BEFORE recursion. Generic build log folders are retained.
    children[:]=sorted(n for n in children if Path(directory)/n not in excluded)
    assert not any((Path(directory)/n).is_symlink() for n in children)
    assert all(Path(directory)!=e and not Path(directory).is_relative_to(e) for e in excluded);visited.append(Path(directory).relative_to(base).as_posix())
    for name2 in sorted(files):
     q=Path(directory)/name2;assert q.is_file() and not q.is_symlink();key=q.relative_to(base).as_posix();assert key not in current;current[key]=q
  assert set(inv['files'])==set(current)|{'_preservation/archive.py','_preservation/plan.json'}
  assert set(names)==set(inv['files'])|{'archive-inventory.json'} and len(inv['files'])==capture['original_files']
  assert sum(r['bytes'] for r in inv['files'].values())==capture['original_bytes']
  checked={}
  # Real independent extraction with safe paths; scratch is owned by this audit and removed afterward.
  with tempfile.TemporaryDirectory(prefix='extracted-'+kind+'-',dir=OUT) as temporary:
   dest=Path(temporary)
   for member in members:
    data=tf.extractfile(member).read();q=dest/member.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);q.chmod(member.mode)
    assert q.stat().st_size==member.size and stat.S_IMODE(q.stat().st_mode)==member.mode and q.read_bytes()==data
    if member.name=='archive-inventory.json':assert data==inv_bytes;continue
    row=inv['files'][member.name];assert len(data)==row['bytes'] and sha(data)==row['sha256'] and member.mode==row['mode']
    if member.name in current:
     p=current[member.name];assert p.read_bytes()==data and stat.S_IMODE(p.stat().st_mode)==row['mode']
    checked[member.name]={'bytes':len(data),'mode':member.mode,'sha256':sha(data)}
  assert file_sha(archive)==archive_before
  write(OUT/(kind+'-verified-files.json'),{'files':checked,'exactCurrentOrigins':str(base),'excludedCargoProof':cargo_proof})
  results.append({'kind':kind,'archive':str(archive),'captureReport':str(capture_path),'captureReportSha256':file_sha(capture_path),'archiveSha256':archive_before,'inventorySha256':sha(inv_bytes),'regularMembers':len(members),'originalFiles':len(checked),'payloadBytes':sum(r['bytes'] for r in checked.values()),'declaredRoots':plan['roots'],'membersBytesModesCurrentOriginsExact':True,'independentExtractionVerified':True,'temporaryExtractionRemoved':True,'cachePruningBeforeWalk':cargo_proof})
import subprocess,collections,re,sys
sys.path.insert(0,str(ROOT/'tools'));import compat
summary_path=ROOT/'reports/m2/stage39-final-summary.json';summary=load(summary_path);binding_path=ROOT/'reports/m2/stage39-source-binding.json';binding=load(binding_path);reg_path=ROOT/'reports/m2/stage39-regression-comparison.json';reg=load(reg_path);commit='5526ec808b9ee9bfd743baa33bbc1a7d2364471b'
assert summary['implementation_commit']==binding['commit']==reg['implementation_commit']==commit
# Reuse prior independent archive audit identity rather than repeat old archive member walks.
prior=ROOT/'target/m2/stage39-final-archive-audit-01';prior_cl=load(prior/'closure.json');assert file_sha(prior/'report.json')==prior_cl['reportSha256'] and file_sha(prior/'inventory.json')==prior_cl['inventorySha256']
for row in load(prior/'inventory.json')['files']:assert file_sha(prior/row['path'])==row['sha256']
prior_report=load(prior/'report.json')
for row in prior_report['archives']:assert file_sha(Path(row['archive']))==row['archiveSha256'] and file_sha(Path(row['captureReport']))==row['captureReportSha256']
# Each declared source is bound to its exact committed Git-tree blob; batch object reads avoid thousands of subprocesses.
assert len(binding['sources'])==binding['source_files']==summary['source_files']==4289
assert sum(len(row['groups']) for row in binding['sources'].values())==binding['source_copies']==summary['source_copies']==8512
source_checks=[];source_group_counts=collections.Counter()
for repository in sorted({r['repository'] for r in binding['sources'].values()}):
 repo=ROOT if repository=='root' else ROOT/repository;revision=commit if repository=='root' else binding['submodules'][repository]
 if repository!='root':
  tree=subprocess.run(['git','ls-tree',commit,repository],cwd=ROOT,capture_output=True,check=True).stdout;assert tree.startswith(('160000 commit '+revision+'\t').encode())
 tree=subprocess.run(['git','ls-tree','-r','-z',revision],cwd=repo,capture_output=True,check=True).stdout;paths={}
 for row in tree.split(b'\0'):
  if not row:continue
  header,name=row.split(b'\t',1);mode,kind,blob=header.split();paths[name.decode()]=(kind.decode(),blob.decode())
 rows=[(p,r) for p,r in binding['sources'].items() if r['repository']==repository];objects=sorted({r['git_blob'] for _,r in rows});proc=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE);stdout,stderr=proc.communicate(('\n'.join(objects)+'\n').encode());assert proc.returncode==0 and not stderr;offset=0;hashes={}
 for expected in objects:
  end=stdout.index(b'\n',offset);head=stdout[offset:end].split();assert head[0].decode()==expected and head[1]==b'blob';size=int(head[2]);data=stdout[end+1:end+1+size];assert len(data)==size and stdout[end+1+size:end+2+size]==b'\n';offset=end+2+size;assert hashlib.sha1(b'blob '+str(size).encode()+b'\0'+data).hexdigest()==expected;hashes[expected]=sha(data)
 assert offset==len(stdout)
 for path,row in rows:
  local=path if repository=='root' else path.removeprefix(repository+'/');assert paths[local]==('blob',row['git_blob']) and hashes[row['git_blob']]==row['sha256']
  for group in row['groups']:
   copy=ROOT/'target/m2'/group/'sources'/path;assert copy.is_file() and file_sha(copy)==row['sha256'];source_group_counts[group]+=1
  source_checks.append({'path':path,'repository':repository,'revision':revision,'gitBlob':row['git_blob'],'sha256':row['sha256'],'copies':len(row['groups'])})
write(OUT/'verified-source-bindings.json',{'sources':source_checks,'groupCounts':dict(source_group_counts),'copies':8512,'unique':4289})
newroot=ROOT/'target/m2/stage39-language-final-02';new=load(newroot/'report.json');oldroot=Path(reg['previous_language']['path']).parent;old=load(oldroot/'report.json')
assert file_sha(oldroot/'report.json')==reg['previous_language']['sha256'] and file_sha(newroot/'report.json')==reg['current_language']['sha256']
assert len(old['results'])==3527 and len(new['results'])==new['selected_count']==summary['selected_native_cases']==3599 and new['source_stability'] and new['artifact_stability']
assert new['status_counts']==summary['selected_status_counts']=={'pass':3590,'mismatch':8,'oracle-error':1}
assert [r['id'] for r in old['results']]==[r['id'] for r in new['results'][:3527]] and new['selection']['case_ids']==[r['id'] for r in new['results']]
olddefs={r['id']:r for r in load(oldroot/'sources/compatibility/m2-language.json')['cases']};newdefs={r['id']:r for r in load(newroot/'sources/compatibility/m2-language.json')['cases']};raw_diffs={'java':[],'rust':[]}
for before,after in zip(old['results'],new['results'][:3527],strict=True):
 id=before['id'];assert before['status']==after['status'] and olddefs[id]==newdefs[id];definition=olddefs[id];input_path=definition['input'];assert file_sha(oldroot/'sources'/input_path)==file_sha(newroot/'sources'/input_path)==definition['input_sha256']
 for runtime in ['java','rust']:
  a=before[runtime];b=after[runtime];assert a['exit_code']==b['exit_code'] and a['timed_out']==b['timed_out'];changes=[]
  for channel in ['stdout','stderr']:
   p1=oldroot/'cases'/id/(runtime+'.'+channel+'.bin');p2=newroot/'cases'/id/(runtime+'.'+channel+'.bin');d1=p1.read_bytes();d2=p2.read_bytes();assert sha(d1)==a[channel+'_sha256'] and sha(d2)==b[channel+'_sha256']
   if d1!=d2:changes.append({'channel':channel,'before':{'path':str(p1),'sha256':sha(d1),'bytes':len(d1)},'after':{'path':str(p2),'sha256':sha(d2),'bytes':len(d2)}})
  if changes:raw_diffs[runtime].append({'id':id,'channels':changes})
assert raw_diffs==reg['cross_checkout_raw_changes'] and {k:len(v) for k,v in raw_diffs.items()}==summary['old_cross_checkout_raw_differences']=={'java':1664,'rust':1665}
write(OUT/'verified-raw-differences.json',raw_diffs)
# All reported evidence and original raw build logs are present, byte bound, and in the newly checked archive.
for path,h in new['evidence_sha256'].items():assert file_sha(newroot/path)==h
assert file_sha(newroot/'artifacts/language_probe')==new['candidate']['sha256'] and file_sha(newroot/'artifacts/module_eval_probe')==new['module_candidate']['sha256']
assert load(newroot/'build.process.json')==new['candidate']['build']==new['module_candidate']['build']
for channel in ['stdout','stderr']:assert file_sha(newroot/('build.'+channel+'.bin'))==new['candidate']['build'][channel+'_sha256']
archive_files=load(OUT/'language-verified-files.json')['files']
for p in ['build.process.json','build.stdout.bin','build.stderr.bin']:assert 'stage39-language-final-02/'+p in archive_files
modules=new['results'][3527:];assert len(modules)==72 and all(r['adapter']=='language-module-eval' and r['status']=='pass' for r in modules)
for row in modules:
 directory=newroot/'cases'/row['directory'];java=compat.load_capture(directory/'java');rust=compat.load_capture(directory/'rust');assert not compat.differences(java,rust) and java['exit_code']==rust['exit_code']==1 and not java['timed_out'] and not java['files'] and not java['workspace_changes']
 for runtime,cap in [('java',java),('rust',rust)]:
  record=load(directory/runtime/'process.json');assert record==row[runtime] and record['exit_code']==cap['exit_code'] and not record['workspace_changes'];assert record['source_uri']==(Path(record['cwd'])/record['command'][-1]).as_uri()
assert [{'id':r['id'],'status':r['status']} for r in new['results'] if r['status']!='pass']==summary['failures']==reg['failures'] and len(summary['failures'])==9
assert len(new['full_gate_failures'])==summary['full_gate_failure_reasons']==reg['full_gate_failure_reasons']==1887 and all(r['status']=='pass' for r in new['metamorphic_results']) and len(new['metamorphic_results'])==88
# Summary identity links and actual terminal gate channels/codes; no command is re-executed.
def link(record):
 p=Path(record['path']);p=p if p.is_absolute() else ROOT/p;assert p.stat().st_size==record['bytes'] and file_sha(p)==record['sha256'];return p
for key in ['corrected_focused_tooling_checks','existing_scalar_regression','final_archive_audit','final_platform_audit','required_checks','source_binding','unchanged_tooling_full_checks']:link(summary[key])
for record in summary['preservation_indices']:link(record)
for name,data in summary['gates'].items():
 p=link(data['record']);record=load(p);assert record['exit_code']==data['exit_code'] and record['command'][0]
 for channel in ['stdout','stderr']:
  raw=p.parent/(channel+'.bin');assert raw.stat().st_size==record['channels'][channel]['bytes'] and file_sha(raw)==record['channels'][channel]['sha256']
assert {n:v['exit_code'] for n,v in summary['gates'].items()}=={'language-development-final-02':1,'language-final-02':0,'language-full-final-02':1,'language-report-final-02':0,'language-subset-final-02':1,'persistent-contract-final-02':0,'trace-contract-final-02':1,'trace-report-final-02':0}
checks_path=link(summary['required_checks']);checks=load(checks_path);assert checks['passed'] and checks['source_stability'] and not checks['source_changes']
for check in checks['checks']:
 assert check['exit_code']==0 and not check['timed_out']
 for channel in ['stdout','stderr']:assert file_sha(checks_path.parent/(check['name']+'.'+channel+'.bin'))==check[channel+'_sha256']
test_stdout=(checks_path.parent/'rust-tests.stdout.bin').read_text();harness=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',test_stdout)];assert sum(p for p,f,i in harness)==summary['rust_harness_pass_invocations']==575 and sum(i for p,f,i in harness)==summary['rust_ignored_invocations']==1 and not any(f for p,f,i in harness)
platform=load(ROOT/'target/m2/stage39-platform-final-audit-03/report.json');assert summary['standard_platform']==platform['standard'] and summary['original_portable_calls_each_target']==summary['original_portable_matches_each_target']==144 and summary['original_distinct_internal_producer_phase_differences']==12
assert summary['accepted_output_boundary']=={'calls_each_target':8,'cases':4,'compatibility_complete':False,'status':'unsupported'} and summary['persistent_selected_matches']==summary['persistent_selected_calls']==2782 and summary['trace_status_counts']=={'pass':54,'oracle-error':30} and not summary['compatibility_complete'] and not summary['performance_target_claimed'] and not summary['hosted_ci_claimed']
write(OUT/'report.json',{'status':'pass','scope':'Independent final Stage39 language-archive/source/Git/raw regression/summary coherence audit. No runtime rerun/Git mutation; old platform/regression archive audit reused by identity.','languageArchive':results[0],'sourceBinding':{'commit':commit,'uniqueFiles':4289,'copies':8512,'groupCounts':dict(source_group_counts),'exactCommittedGitBlobAndCopiedBytes':True},'language':{'selected':3599,'statuses':new['status_counts'],'originalModuleRawPasses':72,'portableMatchesEach':144,'retainedFailures':summary['failures'],'fullGateFailureReasons':1887,'metamorphicPasses':88},'oldScalarRegression':{'cases':3527,'definitionsInputsOrderStatusesUnchanged':True,'rawDifferenceCounts':{'java':1664,'rust':1665},'rawChangesPreservedWithoutNormalization':True},'checks':{'allActualRequiredCheckCodesZero':True,'harnessPassInvocations':575,'ignoredInvocations':1,'distinctCountClaimed':False},'gates':{n:v['exit_code'] for n,v in summary['gates'].items()},'summarySha256':file_sha(summary_path),'sourceBindingSha256':file_sha(binding_path),'regressionComparisonSha256':file_sha(reg_path),'reusedPriorArchiveAudit':{'path':str(prior/'report.json'),'sha256':file_sha(prior/'report.json')},'noRuntimeCompatibilityExpansion':True,'noPerformanceOrM2CompletionClaim':True})
files=[{'path':p.relative_to(OUT).as_posix(),'size':p.stat().st_size,'sha256':file_sha(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and p.relative_to(OUT).as_posix() not in ('inventory.json','closure.json')];write(OUT/'inventory.json',{'files':files});write(OUT/'closure.json',{'status':'closed','reportSha256':file_sha(OUT/'report.json'),'inventorySha256':file_sha(OUT/'inventory.json'),'files':len(files)});print(json.dumps({'reportSha256':file_sha(OUT/'report.json'),'closureSha256':file_sha(OUT/'closure.json')},indent=2))
