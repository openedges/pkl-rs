"""Publish final acquisition references without rewriting historical checkpoints."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent


def load(path):
    return json.loads((ROOT / path).read_bytes())


def ref(path):
    data = (ROOT / path).read_bytes()
    return dict(path=path, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, value):
    target = ROOT / path
    assert not target.exists(), target
    target.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')


review = load('target/m2/stage39-final-review-01/report.json')
binding = load('target/m2/stage39-final-review-01/source-binding.json')
platform = load('target/m2/stage39-platform-final-audit-03/report.json')
assert review['status'] == 'pass'
for source, destination in [
    ('target/m2/stage39-final-review-01/source-binding.json', 'reports/m2/stage39-source-binding.json'),
    ('target/m2/stage39-final-review-01/report.json', 'reports/m2/stage39-regression-comparison.json'),
    ('target/m2/stage39-final-archive-audit-01/report.json', 'reports/m2/stage39-final-archive-audit.json'),
]:
    assert not (ROOT / destination).exists()
    (ROOT / destination).write_bytes((ROOT / source).read_bytes())
indices = ['stage39-oracle-captures.json', 'stage39-checkpoint-captures.json',
           'stage39-interrupted-captures.json', 'stage39-correction-captures.json',
           'stage39-final-platform-captures.json', 'stage39-final-regression-captures.json',
           'stage39-final-language-captures.json']
result = dict(
    schema=1, status='verified local frontend checkpoint',
    scope='Stage39 original72 frontend errors, shared diagnostic provenance and corrected parser commitment. Complete module output/loading and M2 remain unfinished.',
    implementation_commit=review['implementation_commit'],
    host='macOS-27.0-arm64-arm-64bit-Mach-O', hosted_ci_claimed=False,
    source_binding=ref('reports/m2/stage39-source-binding.json'),
    source_files=binding['source_files'], source_copies=binding['source_copies'],
    selected_native_cases=review['selected_count'], selected_status_counts=review['status_counts'],
    original_native_module_cases=72, original_native_module_matches=72,
    original_java_repetitions=2, original_java_cli_captures=144,
    original_portable_calls_each_target=144, original_portable_matches_each_target=144,
    portable_scope='Actual Node/Chromium API stdout/stderr byte vectors and API exitCode; native process and generated-file comparison is separate.',
    original_distinct_internal_producer_phase_differences=12,
    accepted_output_boundary=dict(cases=4, calls_each_target=8, status='unsupported', compatibility_complete=False),
    existing_scalar_regression=ref('reports/m2/stage39-regression-comparison.json'),
    existing_scalar_cases=3527, existing_definitions_inputs_order_statuses_unchanged=True,
    old_cross_checkout_raw_differences={key: len(rows) for key, rows in review['cross_checkout_raw_changes'].items()},
    raw_comparison_note=review['cross_checkout_raw_note'],
    metamorphic_relations=88, metamorphic_matches=88,
    persistent_sequences=334, persistent_selected_calls=2782, persistent_selected_matches=2782,
    persistent_unexecuted_groups=review['persistent']['unexecuted_groups'],
    trace_status_counts=review['trace'], standard_platform=platform['standard'],
    required_rust_checks_passed=True, rust_harness_pass_invocations=575, rust_ignored_invocations=1,
    distinct_rust_test_count_claimed=False,
    required_checks=ref('target/m2/stage39-checks-final-02/report.json'),
    unchanged_tooling_full_checks=ref('target/m2/stage39-checks-final-01/report.json'),
    corrected_focused_tooling_checks=ref('target/m2/stage39-adapter-final-checks-02/report.json'),
    final_platform_audit=ref('target/m2/stage39-platform-final-audit-03/report.json'),
    final_archive_audit=ref('reports/m2/stage39-final-archive-audit.json'),
    gates=review['gates'], full_gate_failure_reasons=review['full_gate_failure_reasons'],
    failures=review['failures'], inventory_counts=review['inventory_counts'],
    preservation_indices=[ref('reports/m2/' + name) for name in indices],
    historical_checkpoint_retained=True, initial_failures_and_interrupted_acquisitions_retained=True,
    compatibility_complete=False, performance_target_claimed=False,
    remaining=['Actual ModuleOutput and renderers', 'Original module loading, identity and initialization obligations',
               'Remaining type, collection, Reference, diagnostics and original corpus requirements',
               'Complete product APIs, release platforms, execution time and peak RSS goals'],
    publication='Implementation commit pushed and verified. Final closeout Git publication is recorded separately.',
)
save('reports/m2/stage39-final-summary.json', result)
save('target/m2/stage39-final-publication-01/prepare-report.json', dict(
    summary=ref('reports/m2/stage39-final-summary.json'), source_binding=ref('reports/m2/stage39-source-binding.json'),
    helper=ref('target/m2/stage39-final-publication-01/prepare.py')))
print(json.dumps(dict(status=result['status'], selected=result['selected_status_counts'],
                      source_files=result['source_files'], compatibility_complete=False)), flush=True)
