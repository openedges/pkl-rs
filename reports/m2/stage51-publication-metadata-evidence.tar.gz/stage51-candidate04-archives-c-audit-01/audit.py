from pathlib import Path
import hashlib,json,stat,os,tarfile,datetime,collections
b=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51');producer=b/'target/m2/stage51-candidate04-evidence-prep-01';out=Path(__file__).resolve().parent;load=lambda p:json.loads(Path(p).read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();selection=load(producer/'selection.json');after=load(producer/'selection-after.json');report=load(producer/'report.json');assert selection==after and selection['exclusions']==[];assert report['complete'] and report['originalsStable'] and report['toolStable'];assert len(report['archives'])==len(selection['roots'])==8
assert sha(producer/'run.py')==report['runnerSha256'] and sha(producer/'evidence.py')==report['evidenceToolSha256']
for command in report['commands']:
 assert command['exitCode']==0
 for channel in ['stdout','stderr']:assert sha(producer/(command['label']+'.'+channel+'.bin'))==command[channel+'Sha256']
assert len(report['commands'])==16
# All selected roots are fixed closed capture subtrees. Known exact dependency/cache
# locations are rejected before descent; no generic build-name exclusion is used.
prunes={b/'target/stage51-cargo',b/'target/debug',b/'target/release',b/'target/wasm32-unknown-unknown',b/'.cache',b/'tools/platform/node_modules'}
for name in selection['roots'].values():
 root=b/'target/m2'/name
 prunes.update(root/p for p in ['__pycache__','producer/__pycache__','helpers/__pycache__','sources/tools/__pycache__','sources/tools/tests/__pycache__'])
walked={};archiveRows=[];memberSets={};metadataBefore={str(producer/n):sha(producer/n) for n in ['selection.json','selection-after.json','report.json','run.py','evidence.py']};modeCounts=collections.Counter()
def inventory(root):
 files={};directories={};stack=[root]
 while stack:
  directory=stack.pop();assert directory not in prunes,str(directory);info=directory.lstat();assert stat.S_ISDIR(info.st_mode) and not directory.is_symlink();directories[str(directory.relative_to(root))]=stat.S_IMODE(info.st_mode)
  with os.scandir(directory) as entries:
   for entry in entries:
    p=Path(entry.path);assert p not in prunes,'Unexpected exact cache path rejected before descent: '+str(p);info=p.lstat()
    if stat.S_ISDIR(info.st_mode):stack.append(p)
    else:
     assert stat.S_ISREG(info.st_mode),str(p);files[str(p.relative_to(root))]={'sha256':sha(p),'bytes':info.st_size,'mode':stat.S_IMODE(info.st_mode)}
 return {'files':files,'directories':directories}
for unit,name in selection['roots'].items():
 root=b/'target/m2'/name;actual=inventory(root);assert actual==selection['inventories'][unit],unit;walked[unit]={'files':len(actual['files']),'directories':len(actual['directories'])};modeCounts.update(v['mode'] for v in actual['files'].values())
 archiveRow=next(row for row in report['archives'] if row['unit']==unit);archivePath=Path(archiveRow['path']);assert sha(archivePath)==archiveRow['sha256'] and archivePath.stat().st_size==archiveRow['bytes'];assert archivePath.stat().st_size<100_000_000
 with archivePath.open('rb') as stream:header=stream.read(10);assert header[:2]==b'\x1f\x8b' and header[4:8]==b'\0'*4 and not header[3]&8
 with tarfile.open(archivePath,'r:gz') as tar:
  members=tar.getmembers();names=[m.name for m in members];assert len(names)==len(set(names)) and 'EVIDENCE.json' in names
  index={m.name:m for m in members};assert set(index)==set(actual['files'])|{'EVIDENCE.json'}
  for member in members:
   assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
   assert member.mode==0o644 and member.mtime==0 and member.uid==member.gid==0
  evidence=json.load(tar.extractfile(index['EVIDENCE.json']));assert evidence['schema_version']==1 and evidence['excluded_patterns']==[];rows=evidence['files'];assert len(rows)==len({r['path'] for r in rows})==len(actual['files']);assert {r['path'] for r in rows}==set(actual['files'])
  for row in rows:
   claim=actual['files'][row['path']];assert row['bytes']==claim['bytes'] and row['sha256']==claim['sha256'];assert index[row['path']].size==claim['bytes'];digest=hashlib.sha256();size=0
   with tar.extractfile(index[row['path']]) as captured,(root/row['path']).open('rb') as original:
    while True:
     chunk=captured.read(1024*1024)
     if not chunk:assert original.read(1)==b'';break
     assert original.read(len(chunk))==chunk;size+=len(chunk);digest.update(chunk)
   assert size==claim['bytes'] and digest.hexdigest()==claim['sha256']
 memberSets[unit]=set(actual['files']);archiveRows.append({'unit':unit,'path':str(archivePath),'sha256':archiveRow['sha256'],'compressedBytes':archiveRow['bytes'],'payloadFiles':len(actual['files']),'rawBytes':sum(v['bytes'] for v in actual['files'].values()),'allMemberBytesEqualOriginal':True})
# Critical semantic/provenance payloads are present, not merely referenced.
proof=load(b/'target/m2/stage51-candidate04-build/build-proof.json');assert len(proof['sources'])==437 and 'build-proof.json' in memberSets['build']
assert all('sources/'+n in memberSets['build'] for n in proof['sources']);assert {'report.json','comparison.json','actual.json','fixtures.json','payloads.json'}<=memberSets['native'];assert {'execution.json','fixtures.json','node.raw.json','browser.raw.json','output-inventory.json'}<=memberSets['portable']
assert {'report.json','oracle-native/java.stdout.bin','oracle-native/rust.stdout.bin','execution/node.stdout.bin','execution/browser.stdout.bin'}<=memberSets['m1'];m1=load(b/'target/m2/stage51-m1-platforms-candidate04-01/report.json');assert m1['compatibility_status']=='fail' and m1['known_gaps']==['regex-unicode-15-vs-16','regex-zero-width-supplementary']
fixtures=load(b/'target/m2/stage51-native-candidate04-01/fixtures.json');actual=load(b/'target/m2/stage51-native-candidate04-01/actual.json');nativeReport=load(b/'target/m2/stage51-native-candidate04-01/report.json');folders={tuple(p['oracleCaseRepeat']):Path(p['argv'][-1]) for p in nativeReport['processes'] if p['name'].startswith('native-')};postClose=0
for position,(f,s) in enumerate(zip(fixtures,actual)):
 for expected,call in zip(f['expected'],s['calls']):
  if expected['scope']!='public-api-boundary':continue
  postClose+=1;assert call['status']=='api-error';folder=folders[(f['oracle'],f['caseId'],f['repeat'])]/('session-'+str(f['session']));prefix=str(folder.relative_to(b/'target/m2/stage51-native-candidate04-01'))+'/call-'+str(call['index']);assert prefix+'.status.bin' in memberSets['native'] and prefix+'.stderr.bin' in memberSets['native'] and prefix+'.api-error-kind.bin' in memberSets['native']
  for target in ['node','browser']:assert target+'/'+str(position)+'/'+str(call['index'])+'.stderr.utf16be.bin' in memberSets['portable'] and target+'/'+str(position)+'/'+str(call['index'])+'.status.bin' in memberSets['portable']
assert postClose==12
# Final path/mode/length/hash re-enumeration catches unlisted additions and mutation.
for unit,name in selection['roots'].items():assert inventory(b/'target/m2'/name)==selection['inventories'][unit]
assert metadataBefore=={p:sha(p) for p in metadataBefore}
(out/'archive-readback.json').write_text(json.dumps(archiveRows,indent=2)+'\n');(out/'source-scope.json').write_text(json.dumps({'roots':selection['roots'],'inventoriesSha256':sha(producer/'selection.json'),'exactPreDescentRejectedCachePaths':sorted(map(str,prunes)),'genericBuildNameExclusion':False,'exclusions':[],'allActualSourcePathsetsEqualSelection':True,'allFileAndDirectoryModesEqualSelection':True,'originalFileModeCounts':dict(modeCounts)},indent=2)+'\n')
result={'schema':1,'status':'CLOSED_INDEPENDENT_ARCHIVE_MEMBER_AUDIT','recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producerActual':{'session':46701,'exitCode':0,'chunk':'712c91'},'archives':len(archiveRows),'totalCompressedBytes':sum(v['compressedBytes'] for v in archiveRows),'largestCompressedBytes':max(v['compressedBytes'] for v in archiveRows),'originalFiles':sum(v['payloadFiles'] for v in archiveRows),'originalRawBytes':sum(v['rawBytes'] for v in archiveRows),'allOriginalSourcePathModeSizeHashesExact':True,'allTarPayloadBytesEqualOriginal':True,'missingOrUnexpectedPayloads':[],'sourceChanges':[],'criticalPresence':{'source437AndProof':True,'nativePortableActualReports':True,'postClose12RawFailureCalls':True,'regexTwoRawGaps':True,'actualLauncherAndRootReceipts':True},'modeContract':'evidence.py intentionally writes all tar headers0644/mtime0/uid0/gid0. Original file+directory modes are preserved separately in exact selection.json; executable-bit restoration requires that table. The eight archives alone do not encode original executable modes.','publicationScope':'Packaging worker run.py/selection/report/own actual closure are intentionally outside these eight closed producer-root archives; root plans a separate metadata archive. Exact selection.json must accompany publication to preserve original paths/modes.','newEvaluatorRuns':0,'fullM2Complete':False};(out/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
