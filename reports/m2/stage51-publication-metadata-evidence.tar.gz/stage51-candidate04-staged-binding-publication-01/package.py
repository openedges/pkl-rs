"""Package closed staged-binding evidence; never write the original audit or Git index."""
from pathlib import Path
import collections,datetime,hashlib,json,os,shutil,stat,subprocess,sys,tarfile
O=Path(__file__).resolve().parent;R=O.parents[2];S=O.parent/'stage51-candidate04-staged-binding-01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def need(x,s):
 if not x:raise ValueError(s)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
need(sha(S/'handoff.json')=='62a3cb3c2ef90f12dd99f154ba2ab07aa582aa7fba4450ea0e646466eb0577bf'and sha(S/'closure.json')=='84c6667206bb2111d2f1cb0a8b3cc911e3e85b35f65b1a2bc307164fb7b4ac58','binding authority differs');closure=json.loads((S/'closure.json').read_bytes());need(closure['sealed']and sha(S/'inventory.json')==closure['inventorySha256'],'inventory closure differs');inv=json.loads((S/'inventory.json').read_bytes())['files'];expected=set(inv)|{'inventory.json','closure.json','seal.stdout.bin','seal.stderr.bin'};need({p.name for p in S.iterdir()}==expected,'closed binding pathset differs');selection={}
for name in sorted(expected):
 p=S/name;need(p.is_file()and not p.is_symlink(),'nonregular original binding input');row={'sourcePath':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}
 if name in inv:need(row['sha256']==inv[name]['sha256']and row['bytes']==inv[name]['bytes'],'sealed original binding file changed')
 selection[name]=row
save(O/'selection.json',{'root':str(S),'files':selection,'originalExcludedFiles':[],'noRecursiveTargetWalk':True,'futureCommitNotYetBound':True});save(O/'inputs-before.json',{'package.py':sha(Path(__file__).resolve()),'pythonExecutable':str(Path(sys.executable).resolve()),'pythonExecutableSha256':sha(Path(sys.executable).resolve()),'selectionSha256':sha(O/'selection.json')})
# Reconstruct every staged object independently from its recorded raw stream offsets.
objects=json.loads((S/'git-objects.json').read_bytes());bindings=json.loads((S/'file-bindings.json').read_bytes());groups=collections.defaultdict(list)
for obj in objects:groups[obj['rawStream']].append(obj)
for stream,rows in groups.items():
 position=0
 with(S/stream).open('rb')as raw:
  for obj in rows:
   need(obj['rawHeaderOffset']==position,'raw object offset gap/overlap');raw.seek(position);header=raw.readline();need(header==f"{obj['oid']} blob {obj['bytes']}\n".encode(),'raw object header differs');need(raw.tell()==obj['rawPayloadOffset'],'payload offset differs');payload=raw.read(obj['bytes']);need(len(payload)==obj['bytes']and raw.read(1)==b'\n','raw object framing differs');need(hashlib.sha256(payload).hexdigest()==obj['sha256'],'raw blob SHA256 differs');need(hashlib.sha1(b'blob '+str(len(payload)).encode()+b'\0'+payload).hexdigest()==obj['oid'],'raw Git SHA1 differs');position=raw.tell()
  need(raw.read()==b'','unaccounted raw object bytes')
 stdin=stream.replace('.stdout.bin','.stdin.bin');need((S/stdin).read_bytes()==b''.join(x['oid'].encode()+b'\n'for x in rows),'raw request sequence differs')
object_map={(o['repository'],o['oid']):o for o in objects};counts=collections.Counter()
for rel,row in bindings.items():
 obj=object_map[(row['repository'],row['gitBlob'])];need(row['gitBlobSha256']==row['filesystemSha256']==obj['sha256']and row['gitBlobBytes']==row['filesystemBytes']==obj['bytes']and row['filesystemBytesEqualStagedBlob']is True,'binding row/object differs');counts[(row['repository'],row['gitBlob'])]+=1
for key,obj in object_map.items():need(counts[key]==obj['boundFiles'],'object referenced file count differs')
proof=json.loads((S/'candidate04-build-proof.json').read_bytes());need(len(proof['sources'])==437,'proof source count differs')
for rel,h in proof['sources'].items():need(bindings[rel]['gitBlobSha256']==h and bindings[rel]['candidate04SnapshotBytesEqualStagedBlob']is True,'proof source row differs')
readback={'status':'PASS-independent-raw-object-offsets-and-binding-table-readback','objects':len(objects),'files':len(bindings),'streams':{name:{'bytes':(S/name).stat().st_size,'sha256':sha(S/name),'objects':len(rows)}for name,rows in groups.items()},'allOffsetsAndRequestsAndSHA1AndSHA256Match':True,'allBindingRowsJoinObjects':True,'all437SourceRowsJoinProof':True,'notAReexecutionOfGitOrEvaluator':True};save(O/'raw-object-readback.json',readback)
G=O/'gather';G.mkdir();(G/'original').mkdir()
for name,row in selection.items():shutil.copyfile(S/name,G/'original'/name);need(sha(G/'original'/name)==row['sha256'],'gather copy differs')
shutil.copyfile(O/'selection.json',G/'CAPTURE_SELECTION.json');shutil.copyfile(O/'raw-object-readback.json',G/'INDEPENDENT_RAW_OBJECT_READBACK.json')
(G/'README.md').write_text('''# Candidate04 staged source and fixture binding

This archive preserves the closed read-only index binding evidence: original table, Git commands/runtime/PIDs, source scripts, proof post-guard, raw blob streams and exact offsets. It covers all 437 declared candidate04 source paths, 75,863 fixture files and execution tools/helpers/manifests/four tests, with 76,302 distinct paths and 3,053 unique blobs. External21 files are submodule staged blobs also verified at the main staged gitlink tree.

These are staged blob bytes. Observed HEAD460bfa5 is a base marker; no new commit or historical candidate equivalence is asserted. Root must join the same paths/modes/OIDs to the final commit. PLAN/docs are excluded from artifact binding. The original target-only trailing self-comparison is not relied on: its independent proof post-guard is preserved.

All original audit files remain unchanged. Packaging separately reconstructs every raw object header/offset/request/body, verifies SHA1 and SHA256, and joins every binding row and all437 proof rows. No Git or evaluator command is reexecuted during packaging. The archive receives separate evidence verification and complete raw-member readback. Its own packaging receipts are finalized outside itself to avoid recursive self inclusion.
''')
T=O/'tool-sources/tools/evidence.py';T.parent.mkdir(parents=True);shutil.copyfile(R/'tools/evidence.py',T);(G/'producer').mkdir();shutil.copyfile(Path(__file__).resolve(),G/'producer/package.py');shutil.copyfile(T,G/'producer/evidence.py')
archive=O/'stage51-candidate04-staged-source-binding.tar.gz';commands=[]
for action in ['create','verify']:
 argv=[sys.executable,'-B',str(T),action]+([str(G),str(archive)]if action=='create'else[str(archive)]);row={'argv':argv,'cwd':str(R),'parentPid':os.getpid(),'startedUtc':now()}
 with(O/(action+'.stdout.bin')).open('wb')as out,(O/(action+'.stderr.bin')).open('wb')as err:
  p=subprocess.Popen(argv,cwd=R,stdout=out,stderr=err);row['pid']=p.pid;save(O/(action+'.launch.json'),row);row['exitCode']=p.wait()
 row.update(finishedUtc=now(),stdoutSha256=sha(O/(action+'.stdout.bin')),stderrSha256=sha(O/(action+'.stderr.bin')));save(O/(action+'.terminal.json'),row);commands.append(row);need(row['exitCode']==0,'evidence command failed')
need(archive.stat().st_size<100000000,'archive over GitHub cap')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();need(len(members)==len({m.name for m in members})and all(m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts for m in members),'unsafe/duplicate members');actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in members};wanted={p.relative_to(G).as_posix():sha(p)for p in G.rglob('*')if p.is_file()};need(set(actual)==set(wanted)|{'EVIDENCE.json'}and all(actual[n]==h for n,h in wanted.items()),'independent raw member readback failed')
need({p.name for p in S.iterdir()}==expected,'original pathset changed after packaging');changes=[name for name,row in selection.items()if sha(S/name)!=row['sha256']or(S/name).stat().st_size!=row['bytes']or stat.S_IMODE((S/name).stat().st_mode)!=row['mode']];need(not changes,'original audit root changed')
report={'status':'CLOSED-read-only-staged-binding-evidence-package','archive':{'path':str(archive),'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'payloadFiles':len(wanted)},'commands':commands,'originalRoot':str(S),'originalFiles':len(selection),'originalBytes':sum(x['bytes']for x in selection.values()),'originalChanges':changes,'originalPathsetStable':True,'allModesAndHashesStable':True,'rawMemberReadbackPassed':True,'independentRawObjectReadbackSha256':sha(O/'raw-object-readback.json'),'sourceBindingHandoffSha256':sha(S/'handoff.json'),'sourceBindingTableSha256':sha(S/'file-bindings.json'),'selectionSha256':sha(O/'selection.json'),'futureCommitNotYetBound':True,'gitOrEvaluatorExecutionsDuringPackaging':0,'gitReportsSourceWrites':False,'finishedUtc':now()};save(O/'report.json',report);print(json.dumps(report),flush=True)
