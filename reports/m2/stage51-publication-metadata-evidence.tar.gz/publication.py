#!/usr/bin/env python3
"""Publish already verified, closed Stage51 evidence without evaluator reruns."""
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51')
OUT = ROOT / 'target/m2/stage51-publication-02'
REPORTS = ROOT / 'reports/m2'
SOURCES = [
    ('stage51-evidence-publication-prep-01', 'index.json', 'd6d72f35f39f4c8eeed329b382f8e69f539c3ed6280c234e5b0b2f3688b69702'),
    ('stage51-candidate03-evidence-prep-01', 'index.json', '08ebabf5d8a8e08f3cdb0ff75333d5d8833d8c932214e5d0b0e4210a9ed3712d'),
    ('stage51-early-history-evidence-prep-01', 'index.json', '38f4594c790e6acc5a880103d7f3c568e623e317ef7dc354e6a26113f46ac7b5'),
    ('stage51-candidate04-evidence-prep-01', 'report.json', None),
    ('stage51-review-metadata-evidence-prep-01', 'index.json', '1d96798afdf72cd57a255e14445939aaf3d5e52b61147a79483256e02ccca650'),
    ('stage51-review-metadata-packaging-02', 'index.json', '67c59178a32302b43fbfce522bef815e6fec449ebd56deaa9530cffbdc6f9033'),
    ('stage51-candidate04-staged-binding-publication-01', 'index.json', '6ccd054a5bf57a242825fdf16ab5360ad412cecd4178743ea9c534c95d1cc48c'),
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def copy_exact(source, destination):
    assert stat.S_ISREG(source.lstat().st_mode), source
    existed = destination.exists()
    if existed:
        assert destination.is_relative_to(REPORTS), destination
        assert destination.read_bytes() == source.read_bytes(), destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    before = digest(source)
    if not existed:
        shutil.copyfile(source, destination)
    assert digest(destination) == before == digest(source), source
    return {'originalPath': str(source), 'path': str(destination.relative_to(ROOT)),
            'bytes': destination.stat().st_size, 'sha256': before,
            'originalMode': stat.S_IMODE(source.stat().st_mode)}

def command(label, argv):
    with (OUT / (label + '.stdout.bin')).open('xb') as stdout, (OUT / (label + '.stderr.bin')).open('xb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    write(OUT / (label + '.json'), {'argv': argv, 'cwd': str(ROOT), 'exitCode': result.returncode})
    assert result.returncode == 0, label

def main():
    archives = []
    metadata = []
    payload = OUT / 'metadata'
    payload.mkdir()
    for directory, filename, expected in SOURCES:
        source = ROOT / 'target/m2' / directory / filename
        actual = digest(source)
        if expected:
            assert actual == expected, (source, actual)
        metadata.append(copy_exact(source, payload / directory / filename))
        data = json.loads(source.read_text())
        entries = data['archives'] if 'archives' in data else [data['archive']]
        for entry in entries:
            original = Path(entry['path'])
            assert digest(original) == entry['sha256'], original
            assert original.stat().st_size == entry.get('compressedBytes', entry.get('bytes')), original
            name = entry.get('proposedReportsFilename') or Path(entry.get('futureReportPath', original.name)).name
            copied = copy_exact(original, REPORTS / name)
            assert copied['bytes'] < 100_000_000, name
            copied['preparationIndex'] = str((payload / directory / filename).relative_to(payload))
            copied['originalPreparationRecord'] = entry
            copied['copyBytesVerified'] = True
            archives.append(copied)
    # These closed records were produced after the earlier metadata selection.
    for directory in ['stage51-candidate04-archives-c-audit-01', 'stage51-candidate04-staged-binding-publication-01']:
        root = ROOT / 'target/m2' / directory
        # gather duplicates the binding archive and is excluded before traversal.
        sources = [p for p in root.iterdir() if p.name not in {'gather', 'tool-sources'}]
        if (root / 'tool-sources').is_dir():
            sources.extend(p for p in (root / 'tool-sources').rglob('*') if p.is_file())
        for source in sorted(sources):
            if source.name.endswith('.tar.gz'):
                continue
            assert source.is_file() and not source.is_symlink(), source
            destination = payload / directory / source.relative_to(root)
            if destination.exists():
                assert destination.read_bytes() == source.read_bytes()
                continue
            metadata.append(copy_exact(source, destination))
    for name in ['publish.py', 'actual-terminal.json']:
        metadata.append(copy_exact(ROOT / 'target/m2/stage51-publication-01' / name, payload / 'publication-attempt01' / name))
    write(payload / 'publication-qualifications.json', {'earlierAttemptExit': 1, 'earlierReason': 'Strict selector rejected a duplicate gather directory.', 'preexistingReportArchives': 'Reused only after exact source SHA-256 and size comparison; no overwrite.', 'stagedBindingPackagingExcludedBeforeDescent': ['gather'], 'gatherAuthority': 'stage51-candidate04-staged-source-binding.tar.gz retains the full selected source binding payload.'})
    # Preserve the publication procedure and original modes in the same package.
    metadata.append(copy_exact(Path(__file__), payload / 'publication.py'))
    write(payload / 'selected-files.json', metadata)
    write(payload / 'archive-copies.json', archives)
    tool = ROOT / 'tools/evidence.py'
    assert digest(tool) == 'b3224aa21497c955c865e143faefb8ebdc9c70ea48983eb678b5972be17fe62e'
    copy_exact(tool, payload / 'evidence.py')
    final_archive = REPORTS / 'stage51-publication-metadata-evidence.tar.gz'
    assert not final_archive.exists()
    command('metadata-create', [sys.executable, '-B', str(tool), 'create', str(payload), str(final_archive)])
    command('metadata-verify', [sys.executable, '-B', str(tool), 'verify', str(final_archive)])
    archives.append({'path': str(final_archive.relative_to(ROOT)), 'bytes': final_archive.stat().st_size,
                     'sha256': digest(final_archive), 'scope': 'Closed preparation indices, final independent archive audit and staged-binding packaging provenance.',
                     'createExitCode': 0, 'separateVerifyExitCode': 0})
    manifest = {
        'schema': 1,
        'scope': 'Local Stage51 candidate04 implementation checkpoint, raw Java/Rust results, failed prior candidates and source provenance. Not full M2, CI or performance completion.',
        'archives': archives,
        'archiveCount': len(archives),
        'compressedBytes': sum(x['bytes'] for x in archives),
        'allArchivesBelow100000000': all(x['bytes'] < 100_000_000 for x in archives),
        'sourceBinding': {
            'status': 'Precommit staged blobs verified; actual implementation commit join is a separate publication record.',
            'archive': 'stage51-candidate04-staged-source-binding.tar.gz',
            'fileBindingsSha256': '31d58542974ae796d1a519fdbe3ceb00aec59a2f7475862885545d5bde22e817',
            'files': 76302, 'rawGitBlobsVerified': 3053, 'candidate04Sources': 437,
            'submoduleSourceFiles': 21,
            'externalPklGitlink': 'e51fb2f91774265666f94980ec630db794a4db2d',
            'historicalCandidateSourcesAreNotClaimedAsCurrentGitBlobs': True,
        },
        'fixtureAuthority': {
            'path': 'tests/fixtures/m2-collection-transforms',
            'manifestSha256': 'a90cc8d0c409b03c783192f39cf265052e3efa48e0d9bc5f7d64818e57a2558d',
            'filesIncludingManifest': 75863,
            'qualification': 'The Java06-08 authority package deduplicates 23397 files through exact repository fixture paths and SHA-256. The committed fixture tree and source binding are required to reconstruct that package. Original exclusions and mappings remain in the preparation metadata.',
        },
        'modeQualification': 'evidence.py normalizes archive headers to mode 0644 and mtime 0. Original paths/modes are preserved in selection tables; extractors must use those tables to restore executable modes.',
        'candidate04Results': {'eachTargetOrdinaryMatches': 2000, 'eachTargetOrdinaryCalls': 2000,
                               'eachTargetDiagnosticOnlyMatches': 96, 'eachTargetPostCloseMismatches': 12,
                               'rawApiPassed': False, 'fullJavaEventsCountersPassed': False,
                               'strictSelectedContractPassed': False},
        'm1KnownRegexMismatchesEachTarget': 2,
        'fullM2Complete': False, 'hostedCiClaimed': False, 'performanceTargetClaimed': False,
    }
    write(REPORTS / 'stage51-implementation-captures.json', manifest)
    write(OUT / 'report.json', {'complete': True, 'archiveCount': len(archives), 'compressedBytes': manifest['compressedBytes'],
                              'captureManifestSha256': digest(REPORTS / 'stage51-implementation-captures.json'),
                              'sourceIndexFilesUnchanged': all(digest(ROOT/'target/m2'/directory/filename) == digest(payload/directory/filename) for directory,filename,_ in SOURCES)})
    print(json.dumps({'archiveCount': len(archives), 'compressedBytes': manifest['compressedBytes'], 'copiedAllBytesVerified': True}))

if __name__ == '__main__':
    main()
