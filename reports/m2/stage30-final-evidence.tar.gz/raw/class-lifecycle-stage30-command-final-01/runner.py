"""Capture a Stage 30 acquisition or replay process without changing its bytes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

sys.dont_write_bytecode = True
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('command', nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command
if command and command[0] == '--':
    command = command[1:]
if not command:
    parser.error('a command is required')
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=False)
(output/'runner.py').write_bytes(Path(__file__).read_bytes())
entrypoints = {}
for index, argument in enumerate(command):
    path = Path(argument)
    if path.suffix == '.py' and path.is_file():
        raw = path.read_bytes()
        snapshot = 'entrypoints/' + str(index) + '-' + path.name
        (output/'entrypoints').mkdir(exist_ok=True)
        (output/snapshot).write_bytes(raw)
        entrypoints[str(path.resolve())] = dict(snapshot=snapshot, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
(output/'invocation.json').write_text(json.dumps(dict(command=command,cwd=str(Path.cwd()),
    python=sys.executable,python_sha256=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
    entrypoints=entrypoints),indent=2)+'\n')
started = time.monotonic_ns()
process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
pump_errors = []
def pump(source, destination, visible):
    try:
        with destination.open('xb') as stream:
            while True:
                data = source.read1(65536)
                if not data:
                    break
                stream.write(data)
                stream.flush()
                visible.write(data)
                visible.flush()
    except Exception as error:
        pump_errors.append(dict(channel=destination.name,error=repr(error)))
        process.terminate()
threads = [threading.Thread(target=pump, args=(process.stdout, output/'stdout.bin', sys.stdout.buffer)),
           threading.Thread(target=pump, args=(process.stderr, output/'stderr.bin', sys.stderr.buffer))]
for thread in threads:
    thread.start()
returncode = process.wait()
for thread in threads:
    thread.join()
row = {'command': command, 'cwd': str(Path.cwd()), 'exit_code': returncode, 'timed_out': False,
       'elapsed_ns': time.monotonic_ns() - started, 'python': sys.executable}
row['entrypoints'] = entrypoints
row['capture_errors'] = pump_errors
row['entrypoints_stable'] = all(Path(path).is_file() and hashlib.sha256(Path(path).read_bytes()).hexdigest()==record['sha256'] for path,record in entrypoints.items())
for channel in ['stdout', 'stderr']:
    data = (output/(channel+'.bin')).read_bytes()
    row[channel+'_sha256'] = hashlib.sha256(data).hexdigest()
    row[channel+'_bytes'] = len(data)
(output/'process.json').write_text(json.dumps(row, indent=2, sort_keys=True)+'\n')
sys.exit(returncode if row['entrypoints_stable'] and not pump_errors else 1)
