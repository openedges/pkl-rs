import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

root = Path.cwd()
out = Path(__file__).resolve().parent
sys.path.insert(0, str(root / 'tools'))
import m2_source_inputs

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

paths = set(m2_source_inputs.source_paths(root))
paths.update(str(p.relative_to(root)) for p in (root / 'tools').rglob('*.py') if '__pycache__' not in p.parts)
paths.update(['AGENTS.md', 'PLAN.md', 'TESTING.md', 'docs/m2-language.md', 'docs/m2-module-frontend.md'])
before = {p: sha(root / p) for p in sorted(paths)}
save(out / 'inputs-before.json', before)
for p in before:
    dest = out / 'sources' / p
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((root / p).read_bytes())
commands = [
    ('m2-unit-tests', [sys.executable, '-B', '-W', 'error::ResourceWarning', '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_*.py', '-v']),
    ('compat-unit-tests', [sys.executable, '-B', '-W', 'error::ResourceWarning', '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_compat.py', '-v']),
    ('module-registry-check', [sys.executable, '-B', 'tools/m2_module_eval.py', '--check']),
    ('m2-manifest-check', [sys.executable, '-B', 'tools/m2_manifest.py', '--check']),
    ('inventory-check', [sys.executable, '-B', 'tools/inventory.py', '--check']),
    ('corpus-check', [sys.executable, '-B', 'tools/discover.py', '--check']),
    ('regression-check', [sys.executable, '-B', 'tools/regression_manifest.py', '--check']),
    ('smoke-check', [sys.executable, '-B', 'tools/smoke_manifest.py', '--check']),
    ('reference-verification', ['cargo', 'xtask', 'verify']),
]
report = dict(scope='Stage52 Python acquisition/admission/profile tooling checks; no language compatibility claim.',
              host=platform.platform(), python=sys.version, pythonExecutable=sys.executable,
              commands=[], complete=False, inputCount=len(before))
save(out / 'report.json', report)
for label, argv in commands:
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print('START', label, flush=True)
    with (out / (label + '.stdout.bin')).open('wb') as stdout, (out / (label + '.stderr.bin')).open('wb') as stderr:
        child = subprocess.Popen(argv, cwd=root, stdout=stdout, stderr=stderr)
        save(out / 'active.json', dict(label=label, argv=argv, pid=child.pid, startedUtc=started))
        code = child.wait()
    row = dict(label=label, argv=argv, cwd=str(root), pid=child.pid, exitCode=code,
               startedUtc=started, finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               stdoutSha256=sha(out / (label + '.stdout.bin')), stderrSha256=sha(out / (label + '.stderr.bin')))
    report['commands'].append(row)
    save(out / 'report.json', report)
    print('FINISH', label, code, flush=True)
after = {p: sha(root / p) for p in before}
save(out / 'inputs-after.json', after)
report.update(complete=True, changedInputs=[p for p in before if before[p] != after[p]],
              allCommandsPassed=all(r['exitCode'] == 0 for r in report['commands']))
save(out / 'report.json', report)
print(json.dumps({k: report[k] for k in ['inputCount', 'complete', 'changedInputs', 'allCommandsPassed']}), flush=True)
raise SystemExit(0 if report['allCommandsPassed'] and not report['changedInputs'] else 1)
