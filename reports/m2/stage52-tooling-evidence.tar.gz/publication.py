import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys

root = Path.cwd()
out = Path(__file__).resolve().parent
payload = out / 'payload'
payload.mkdir()
reports = root / 'reports/m2'
reports.mkdir(parents=True, exist_ok=True)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, d):
    p.write_text(json.dumps(d, indent=2) + '\n')
validation = json.loads((root / 'target/m2/stage52-tooling-validation-01/report.json').read_text())
assert validation['complete'] and validation['allCommandsPassed'] and not validation['changedInputs']
assert subprocess.check_output(['git', 'diff', '--name-only', '--', 'crates']) == b''
roots = [root / 'target/m2' / name for name in [
    'stage52-tooling-validation-01', 'stage52-original-admission-audit-01',
    'stage52-upstream-workspace-audit-01', 'stage52-admission-delta-audit-01',
    'stage52-forbidden-control-scope-01', 'stage52-forbidden-control-scope-02']]
roots += [root.parent / 'pkl-rs.stage51/target/m2' / name for name in [
    'stage52-worktree-setup-01', 'stage52-worktree-setup-02']]
selection = []
for directory in roots:
    for path in sorted(directory.rglob('*')):
        if path.is_dir():
            continue
        assert stat.S_ISREG(path.lstat().st_mode), path
        dest = payload / directory.name / path.relative_to(directory)
        dest.parent.mkdir(parents=True, exist_ok=True)
        before = sha(path)
        shutil.copyfile(path, dest)
        assert sha(dest) == before == sha(path)
        selection.append(dict(source=str(path), member=str(dest.relative_to(payload)),
                              bytes=path.stat().st_size, sha256=before, mode=stat.S_IMODE(path.stat().st_mode)))
save(payload / 'selection.json', selection)
save(payload / 'review-feedback.json', {
    'scope': 'Reviewer feedback preserved as reported; not a new engine or oracle capture.',
    'initialSchema5Counterexample': 'Nine tests: eight passed; forged retained-resource inventory was accepted and its regression failed with ValueError not raised. Root added authoritative corpus digest validation; final nine tests pass in the recorded full suite.',
    'otherFixedGap': 'Unselected module workspace context/profile/schema was accepted; now rejected and covered by regression tests.',
    'staticInspectionFailure': 'The first forbidden-control scan normalized a symlink target via Path; the corrected scan uses literal os.readlink bytes. No source mutation or actual JVM crash was observed.',
    'newCompatibilityRuns': 0,
})
shutil.copyfile(Path(__file__), payload / 'publication.py')
shutil.copyfile(root / 'tools/evidence.py', payload / 'evidence.py')
archive = reports / 'stage52-tooling-evidence.tar.gz'
assert not archive.exists()
for action, arguments in [('create', [str(payload), str(archive)]), ('verify', [str(archive)])]:
    argv = [sys.executable, '-B', str(root / 'tools/evidence.py'), action, *arguments]
    with (out / (action + '.stdout.bin')).open('wb') as so, (out / (action + '.stderr.bin')).open('wb') as se:
        result = subprocess.run(argv, stdout=so, stderr=se)
    save(out / (action + '.json'), dict(argv=argv, exitCode=result.returncode))
    assert result.returncode == 0
inventory = json.loads((root / 'compatibility/m2-language.json').read_text())
checkpoint = dict(schema=1, scope='Stage52 original-corpus admission and capture tooling checkpoint; not runtime or language compatibility completion.',
    baseCommit='ea2cab56b171e865fb1b9cde30066c6d7eedd10c', rustImplementationChanged=False,
    admissions=dict(addedOriginalReadyCases=752, originalReadyModuleCases=888, registryEntries=889,
                    preservedExistingRegistryRecords=137, inventoryCases=4527, requirements=475,
                    originalCaseIdsAndOrderPreserved=True, originalContractsPreserved=True,
                    caseFieldsChanged=['adapter', 'execution']),
    inventoryCounts=inventory['counts'], remaining=dict(blockedOriginals=68, selectedHistoricalRegressions=3, unmappedRows=40),
    workspace=dict(default='legacy-full', explicitProfile='upstream-original-modules-v1', schemaVersion=5,
                   completePinnedReferenceResources=5584, declaredInputAndResourcePaths=1770,
                   omitted='Only the additional project-owned tests/fixtures copy.',
                   qualification='An explicit experimental filesystem condition. No equivalence with arbitrary surrounding trees, runtime speed or memory claim.'),
    captureFailureHandling='Restoration is attempted after exceptions; primary capture failures, cleanup failures and available raw bytes are retained separately. No failed acquisition is a passing language observation.',
    localValidation=dict(host=validation['host'], python=validation['python'], pythonExecutable=validation['pythonExecutable'],
                         inputFiles=validation['inputCount'], changedInputs=[], commands=validation['commands'],
                         pythonTests=dict(m2=165, compatibilityTooling=19, total=184, failed=0),
                         additionalRustChecks='cargo xtask verify only; no Rust implementation or binding changes. No new full Rust/platform compatibility claim.'),
    evidence=dict(archive=archive.name, sha256=sha(archive), bytes=archive.stat().st_size,
                  payloadFiles=len(selection)+4, createExitCode=0, separateVerifyExitCode=0,
                  originalModes='selection.json; tar headers use normalized mode0644 and mtime0'),
    finalValidationTerminal=dict(session=4769, exitCode=0, chunk='91676e'),
    newOriginalModuleCompatibilityResults=0, nextStep='Freeze this commit and acquire all 888 original-ready module cases under the explicit profile; preserve every pass, mismatch, unsupported, oracle error and timeout.',
    fullM2Complete=False, hostedCiClaimed=False, performanceTargetClaimed=False)
save(reports / 'stage52-tooling-checkpoint.json', checkpoint)
readme = reports / 'README.md'
if not readme.exists():
    readme.write_bytes(subprocess.check_output(['git', 'show', 'HEAD:reports/m2/README.md']))
s = readme.read_text()
prefix = '''The [Stage52 tooling checkpoint](stage52-tooling-checkpoint.json) admits all
752 previously unconnected original-ready snippets. The generated module registry
contains all 888 original-ready cases and the preserved blocked `import1b` record.
Every original case ID, order, argument, input, resource and expected outcome is
preserved. The whole inventory now has 4,416 ready rows, 71 unimplemented rows and
40 unmapped rows. Readiness is execution connectivity, not compatibility.

An explicit original-module workspace retains the complete pinned Pkl and Pantry
trees while omitting unrelated project fixture copies. Schema-5 reports bind this
filesystem boundary to the authoritative corpus digest. Capture exceptions retain
their raw evidence and attempt workspace restoration. The default workspace is
unchanged. Local validation passed 184 Python tests and all nine recorded commands
with 3,955 inputs unchanged. [Raw evidence](stage52-tooling-evidence.tar.gz) includes
the audits, source snapshots, failed setup/inspection records and actual checks.
Rust evaluator code is unchanged. The all-original Java/Rust acquisition follows
this tooling checkpoint; no new language passes, whole M2, platform or performance
completion are claimed here.

'''
assert s.startswith('# M2 language evidence\n\n')
readme.write_text('# M2 language evidence\n\n' + prefix + s[len('# M2 language evidence\n\n'):])
save(out / 'report.json', dict(complete=True, archiveSha256=sha(archive), archiveBytes=archive.stat().st_size,
                              checkpointSha256=sha(reports / 'stage52-tooling-checkpoint.json'),
                              originalFilesStable=all(sha(Path(x['source'])) == x['sha256'] for x in selection)))
print(json.dumps(dict(archiveBytes=archive.stat().st_size, originalFiles=len(selection), complete=True)))
