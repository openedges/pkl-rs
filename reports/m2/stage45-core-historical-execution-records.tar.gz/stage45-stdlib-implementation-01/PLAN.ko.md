# Stage45 표준 모듈과 guest 예외 처리

고정 Stage44 소스에서 별도 복사한 작업 공간만 수정한다. 원본 Stage42 전체 회귀와 Stage43·44 취득 자료를 보존한다. 정확한 cache 경로와 source map은 `exclusions.json`, `seed.json`에 기록한다.

우선 원본 `api/moduleOutput.pkl`, `basic/boolean.pkl`, `modules/equality.pkl`, `modules/supercalls3.pkl`, `modules/typedModuleMethods1.pkl`, `parser/newline.pkl` 여섯 계약을 실행한다. 원본 argv·환경·파일·Java 전체 채널을 그대로 비교한다. 이 여섯 개의 성공으로 전체 stdlib 또는 M2 완료를 주장하지 않는다.

공유 VM 안에 표준 모듈 singleton·선언별 원본 source·기존 builtin class의 동일한 heap handle을 연결한다. 알려진 미구현 binding은 실제 forcing 시 미지원 오류로 남긴다. test의 catch는 정상 Function0 argument 검사를 통과한 뒤에만 handler를 설치한다. 내부 호출은 같은 VM/Host/GC/clock을 사용한다. 실패 시 handler 아래 frame의 미완성 force/cache/module 상태만 되돌리고 성공한 callback publication은 보존한다. 정상 반환 뒤 expectedAnException을 던지기 전에 handler를 해제한다.

실제 Java의 catch 출력은 stack·hint·power assertion 없는 renderer와 UTF-16 Java lines/strip 의미를 사용한다. adapter에서 출력이나 기대값을 정규화하지 않는다. Unsupported·엔진 limit·잘못된 token·terminal cancellation을 일반 언어 오류 문자열로 위장하지 않는다. typed resource/module SPI 오류와 임의 Host 실패를 구분한다.

첫 구현의 base/test/ref 선언 graph·catch 경계는 컴파일과 두 architecture 검사를 통과했다. 원본 Java 차등 취득과 stdlib bootstrap annotation/output 문맥, 모든 필수 검사는 진행 중이다. `bootstrap-tests-01`의 잘못된 authored keyword 실패를 보존했다.

후속 전체 의무는 별도 마감한 `stage44-next-m2-scope-design-01/PLAN.ko.md`에 남는다: Resource·reader capability, eager triple-dot, read*/import* glob, pkl:reflect/JSON/RenderDirective와 기타 stdlib/제품/성능 범위.

재개 작업에서 캐시된 module source 예외의 프레임 수명을 수정했다. guest catch에서는 실제로 제거한 frame만 lazy trace에 누적하고, 일반 evaluator 경계를 처음 벗어난 뒤에만 trace를 고정한다. 원본 source 실패와 모든 cache alias는 같은 예외 기록을 갱신한다. callback close와 Boolean xor/implies의 앞선 구현도 최신 파일에서 확인했다. candidate03은 원본 여섯 입력×두 반복의 12회 전체 raw 비교가 일치했다.

pinned 표준 module annotation을 공통 compiler/initializer로 만들고, 같은 heap에서 eager bootstrap과 base output seed를 실행한다. private 초기화의 output-format read는 빈 property 문맥을 사용하며 caller Host에 전파하지 않는다. 실제 미구현 선언은 capability gap으로 보존하고 완전히 force한 module로 표시하지 않는다. 따라서 전체 base surface의 eager 초기화 완료를 주장하지 않는다. test hidden output의 JVM 전체 static cache와 evaluator 범위 identity의 차이는 계속 명시한다.

ModuleInfo의 minPklVersion은 공통 constraint/force 경로를 사용한다. 최초 ASCII 가정은 새 Java 관찰로 기각했고, pinned JDK의 전체 1,114,112 code point에 대한 Character/Pattern 차등 자료로 얻은 Unicode digit 표를 사용한다. module version 검사는 정상 초기화 이후 실행한다. Unicode version에서 실제 Java Version.parse가 내는 내부 오류는 명시적 Unsupported로 남긴다. source-backed native Regex 상수와 boolean 결과를 기존 power observation에 연결한다.

candidate04의 원본 여섯 비교와 새 bootstrap/ModuleInfo raw 비교는 별도 oracle 담당자가 수행 중이다. 필수 전체 workspace test와 Wasm check도 실행 중이며, 현재 완료한 집중 검사는 unit 92개와 integration 49개다. Clippy의 새 테스트 loop 경고를 테스트만 수정한 뒤 workspace/all-targets Clippy가 통과했고 fmt check도 통과했다. source 사본에는 Git/submodule metadata가 없으므로 이 위치에서 Git pin 검증을 했다고 주장하지 않는다. 실제 worktree의 Rust5·portable 실행·독립 검토·최종 증거 게시 전에는 이 단계를 마감하지 않는다.

## candidate05 검증 진행

- `candidate-build-05`에 두 native probe와 13052개 source snapshot을 고정했다. source map SHA-256은 `ee57595d734ebcca586ef1eb2bdea1cedcdd472cfc2d7a0a2d69b9429f10011f`이다.
- cached module 오류의 누적 frame 플래그가 일반 Host 오류에 붙지 않도록 범위를 수정했다. module annotation 진단의 `.` 소유자 구분과 직접 `ModuleInfo` class 식 해석을 수정했다. 수동 block 추가 뒤 stdlib compilation에서도 metadata arena 길이를 맞춘다.
- `pkl:ref`의 실제 `ModuleInfo`/`Since` annotation 두 객체, prototype 세 객체, constraint execution node 세 개가 보존된다. 임시 heap 추적으로 8개 증가를 확인하고 exact lifecycle 기준을 갱신했다. 실패 원본과 임시 계측 기록은 보존했고 production 계측은 제거했다. 종료 시 live/slot 0 기준은 그대로 통과한다.
- `cargo test --workspace --locked --no-fail-fast`, fmt, Clippy, wasm32 runtime check를 새 기록에서 통과했다. `cargo xtask verify`는 복사본의 `.gitmodules`/Git metadata 부재로 실패했으며 `xtask-verify-01`에 보존했다. 실제 worktree의 Rust5 검증이 남아 있다.
- Python bootstrap comparator 7개, guest fixture verifier 6개, portable transport 5개 개발 검증을 통과했다. 실제 Node/browser 실행은 아직 이 후보로 수행하지 않았다.
- oracle agent가 candidate05의 original6 및 824개 bootstrap/ModuleInfo raw comparison을 수행한다. 이전 candidate04의 모든 original6 두 반복은 통과했다. JSON/reflect 지원, resource read cache, JVM-static stdlib cache 범위 차이는 계속 별도 미완성 항목이다.
