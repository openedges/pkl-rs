from pathlib import Path
import hashlib,json,os,shutil
root=Path(__file__).resolve().parent
source=root.parent/'stage44-lossless-host-implementation-01/workspace'
work=root/'workspace'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
excluded={source/'target',root/'cargo-target',work/'target'}
write(root/'exclusions.json',{'declaredBeforeEnumeration':True,'exactPrunedDirectories':[str(p) for p in sorted(excluded)],'source':str(source),'destination':str(work),'noSharedWritableSourceSymlinks':True,'note':'No generic build basename exclusion.'})
work.mkdir()
files={}
for base,dirs,names in os.walk(source,topdown=True,followlinks=False):
 base=Path(base)
 dirs[:]=sorted(d for d in dirs if base/d not in excluded)
 for name in list(dirs):
  p=base/name
  if p.is_symlink():
   assert p.resolve().is_relative_to(source),p
   q=work/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True);q.symlink_to(os.readlink(p));files[str(p.relative_to(source))]=hashlib.sha256(os.readlink(p).encode()).hexdigest();dirs.remove(name)
 for name in sorted(names):
  p=base/name;q=work/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
  if p.is_symlink():
   assert p.resolve().is_relative_to(source),p
   q.symlink_to(os.readlink(p));files[str(p.relative_to(source))]=hashlib.sha256(os.readlink(p).encode()).hexdigest()
  else:
   shutil.copy2(p,q);assert sha(p)==sha(q);files[str(p.relative_to(source))]=sha(q)
final=json.loads((root.parent/'stage44-core-checkpoint-01/source-hashes.json').read_text())
assert all(files[p]==h for p,h in final.items())
write(root/'seed.json',{'source':str(source),'sourceCheckpointReportSha256':sha(root.parent/'stage44-core-checkpoint-01/report.json'),'finalStage44SourceMapSha256':sha(root.parent/'stage44-core-checkpoint-01/source-hashes.json'),'files':files})
shutil.copyfile(source.parent/'check.py',root/'check.py')
shutil.copyfile(source.parent/'test-reference-copy.json',root/'test-reference-copy.json')
print(json.dumps({'files':len(files),'seedSha256':sha(root/'seed.json'),'cache':str(root/'cargo-target')}))
