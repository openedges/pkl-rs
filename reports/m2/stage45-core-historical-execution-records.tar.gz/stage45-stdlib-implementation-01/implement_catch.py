from pathlib import Path
r=Path(__file__).parent/'workspace/crates/pkl-runtime/src'
p=r/'vm.rs';s=p.read_text();s=s.replace('    LoadRefModule,','    LoadRefModule,\n    /// Invoke a checked Function0 under a guest exception handler.\n    GuestCatch { or_null: bool },',1)
s=s.replace('struct Frame {','struct Frame {\n    guest_catch: Option<guest_exceptions::GuestCatch>,',1)
s=s.replace('mod modules;','mod modules;\nmod guest_exceptions;\nmod stdlib_modules;',1)
# Every existing frame starts outside a handler. Frame ownership follows suspension.
for f in [r/'vm.rs',*(r/'vm').glob('*.rs'),*(r/'vm').glob('*/*.rs')]:
 t=s if f==p else f.read_text()
 import re
 t=re.sub(r'(self\.frames\.push\(Frame \{\n)',r'\1            guest_catch: None,\n',t)
 if f==p:s=t
 elif t!=f.read_text():f.write_text(t)
s=s.replace('    fn step(&mut self) -> Result<(), RuntimeError> {','    fn step(&mut self) -> Result<(), RuntimeError> {\n        if self.frames.last().is_some_and(|frame| frame.guest_catch.is_some()) {\n            return self.finish_guest_catch();\n        }',1)
s=s.replace('            Instruction::LoadRefModule => {','            Instruction::GuestCatch { or_null } => {\n                self.begin_guest_catch(or_null)?;\n            }\n            Instruction::LoadRefModule => {',1)
s=s.replace('        self.reset_force_marks(0);\n        // Inferred properties','        let catch_boundary = self.guest_catch_boundary(&error);\n        let unwind_start = catch_boundary.map_or(0, |index| index + 1);\n        self.reset_force_marks(unwind_start);\n        // Inferred properties',1)
# Cleanup only frames leaving scope. Prefix protects an outer pending read as suspended frames already do.
a=s.index('        for frame in &self.frames {',s.index('    fn fail('));b=s.index('        self.frames.clear();',a)
t=s[a:b].replace('for frame in &self.frames {','for frame in &self.frames[unwind_start..] {').replace('.flat_map(|context| &context.frames)\n                    .any(','.flat_map(|context| &context.frames)\n                    .chain(self.frames[..unwind_start].iter())\n                    .any(')
s=s[:a]+t+s[b:]
s=s.replace('        self.frames.clear();\n        self.stack.clear();\n        self.inputs.clear();\n        self.state = State::Finished(Err(error));','        if let Some(index) = catch_boundary {\n            let value = self.render_caught_exception(&error);\n            let handler = self.frames[index].guest_catch.take().expect("catch boundary");\n            self.frames.truncate(index + 1);\n            self.stack.truncate(handler.stack);\n            self.stack.push(Value::String(value));\n            self.state = State::Running;\n        } else {\n            self.frames.clear();\n            self.stack.clear();\n            self.inputs.clear();\n            self.state = State::Finished(Err(error));\n        }',1)
p.write_text(s)
p=r/'diagnostic.rs';s=p.read_text().replace('self.render_indented(source, "")','self.render_indented(source, "", true)',1).replace('    fn render_indented(&self, source: &Source, indent: &str) -> (PklString, Option<PklString>) {','    pub(crate) fn render_without_power(&self, source: &Source) -> PklString {\n        self.render_indented(source, "", false).0\n    }\n\n    fn render_indented(&self, source: &Source, indent: &str, power: bool) -> (PklString, Option<PklString>) {',1).replace('if let Some(observations) = observations {','if power && let Some(observations) = observations {',1).replace('.render_indented(source, &format!("{indent}  "));','.render_indented(source, &format!("{indent}  "), power);',1);p.write_text(s)
p=r/'value.rs';s=p.read_text().replace('pub struct RuntimeErrorDetails {','pub struct RuntimeErrorDetails {\n    /// A typed Host SPI mapping produced an ordinary guest exception.\n    pub(crate) host_language_exception: bool,',1).replace('const EMPTY_ERROR_DETAILS: RuntimeErrorDetails = RuntimeErrorDetails {','const EMPTY_ERROR_DETAILS: RuntimeErrorDetails = RuntimeErrorDetails {\n    host_language_exception: false,',1);p.write_text(s)
p=r/'host/errors.rs';s=p.read_text().replace('        RuntimeError::new(ErrorKind::Host, message)','        let mut error = RuntimeError::new(ErrorKind::Host, message);\n        error.host_language_exception = true;\n        error',1);p.write_text(s)
