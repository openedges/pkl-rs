from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

root=Path(__file__).resolve().parent
work=root/'workspace'
out=root/sys.argv[1]
out.mkdir()
command=sys.argv[2:]
def snapshot():
    paths=[]
    for directory in ['crates','.cargo','xtask','tests']:
        for base,dirs,names in os.walk(work/directory,topdown=True):
            dirs[:]=sorted(d for d in dirs if Path(base)/d != root/'cargo-target')
            paths.extend(Path(base)/n for n in sorted(names))
    paths.extend(work/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml'])
    reference_record=root/'test-reference-copy.json'
    if reference_record.exists():
        paths.extend(work/'external/pkl'/p for p in json.loads(reference_record.read_text())['paths'])
    return {str(p.relative_to(work)):hashlib.sha256(os.readlink(p).encode() if p.is_symlink() else p.read_bytes()).hexdigest() for p in paths}
before=snapshot()
(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
start=time.time()
with (out/'stdout.bin').open('wb') as stdout,(out/'stderr.bin').open('wb') as stderr:
    result=subprocess.run(command,cwd=work,env={**os.environ,'CARGO_TARGET_DIR':str(root/'cargo-target')},stdout=stdout,stderr=stderr)
after=snapshot()
(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
record={'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'command':command,'cwd':str(work),'cargo_target_dir':str(root/'cargo-target'),'exit_code':result.returncode,'seconds':time.time()-start,'source_stable':before==after,'source_changes':[p for p in before.keys()|after.keys() if before.get(p)!=after.get(p)]}
(out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
raise SystemExit(result.returncode or int(before!=after))
