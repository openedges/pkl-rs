from pathlib import Path
import hashlib,json,os,subprocess,stat
root=Path(__file__).resolve().parent
work=root/'workspace'
repo=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
out=root/'promotion-manifest-03.json'
assert not out.exists()
excluded={work/'target',root/'cargo-target',work/'tools/__pycache__',work/'tools/tests/__pycache__'}
(root/'promotion-exclusions-03.json').write_text(json.dumps({'declared_before_enumeration':True,'exact_paths':sorted(map(str,excluded)),'scope':['crates','tests','tools','docs','seed.json file membership'],'no_generic_build_basename_exclusion':True},indent=2)+'\n')
def data(p):return os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
def sha(b):return hashlib.sha256(b).hexdigest()
seed=json.loads((root/'seed.json').read_text())['files']
names=set(seed)
for directory in ['crates','tests','tools','docs']:
 for base,dirs,files in os.walk(work/directory,topdown=True,followlinks=False):
  base=Path(base);dirs[:]=sorted(d for d in dirs if base/d not in excluded)
  for name in list(dirs):
   if (base/name).is_symlink():names.add(str((base/name).relative_to(work)));dirs.remove(name)
  for name in files:names.add(str((base/name).relative_to(work)))
# References remain immutable inputs and are not promotion candidates.
names={n for n in names if not n.startswith('external/') and not any((work/n).is_relative_to(e) for e in excluded)}
commit=subprocess.check_output(['git','rev-parse','c9b140a^{commit}'],cwd=repo).decode().strip()
tree={}
for line in subprocess.check_output(['git','ls-tree','-rz',commit],cwd=repo).split(b'\0'):
 if not line:continue
 meta,path=line.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[path.decode()]=(mode,kind,oid)
existing=[n for n in sorted(names) if n in tree]
process=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
blobs={}
for name in existing:
 mode,kind,oid=tree[name];assert kind=='blob',(name,kind)
 process.stdin.write((oid+'\n').encode());process.stdin.flush()
 header=process.stdout.readline().decode().split();size=int(header[2]);blobs[name]=process.stdout.read(size);assert process.stdout.read(1)==b'\n'
process.stdin.close();assert process.wait()==0
changes=[];current={};inherited_seed_differences=[]
for name in sorted(names):
 p=work/name;before=blobs.get(name)
 if not p.exists() and not p.is_symlink():
  if before is not None:changes.append({'path':name,'status':'deleted','baseline_sha256':sha(before),'baseline_git_blob':tree[name][2]})
  continue
 content=data(p);digest=sha(content);mode='120000' if p.is_symlink() else ('100755' if p.stat().st_mode & stat.S_IXUSR else '100644')
 current[name]=digest
 if before==content and tree[name][0]==mode:continue
 if seed.get(name)==digest:
  inherited_seed_differences.append({'path':name,'seed_sha256':digest,'baseline_sha256':None if before is None else sha(before),'disposition':'unchanged copied seed; excluded from authored promotion'})
  continue
 changes.append({'path':name,'status':'added' if before is None else 'modified','sha256':digest,'mode':mode,'bytes':len(content),'baseline_sha256':None if before is None else sha(before),'baseline_git_blob':None if before is None else tree[name][2]})
record={'baseline_commit':commit,'baseline_requested':'c9b140a','source_workspace':str(work),'immutable_native_candidate':'candidate-build-05','native_production_source_unchanged_after_candidate':True,'scope':'Exact current authored/source changes relative to baseline; absent unseeded repository files are not deletions. Excludes immutable reference copies and explicitly declared cache paths.','seed_sha256':sha((root/'seed.json').read_bytes()),'changes':changes,'inherited_seed_differences_excluded':inherited_seed_differences,'counts':{status:sum(c['status']==status for c in changes) for status in ['added','modified','deleted']},'promoted_path_manifest_sha256':sha(json.dumps({c['path']:c.get('sha256') for c in changes},sort_keys=True).encode())}
out.write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
(root/'promotion-current-source-map-03.json').write_text(json.dumps(current,indent=2,sort_keys=True)+'\n')
print(json.dumps({'manifest':str(out),'sha256':sha(out.read_bytes()),'counts':record['counts']}))
