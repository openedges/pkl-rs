"""Acquire actual platforms from an explicitly frozen Stage49 source checkpoint."""
from pathlib import Path
import datetime
import hashlib
import importlib.util
import json
import os
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
save = lambda p, value: p.write_text(json.dumps(value, indent=2) + '\n')
assert len(sys.argv) == 3, 'Explicit frozen build JSON and its SHA256 are required.'
build_path = Path(sys.argv[1]).resolve()
assert sha(build_path) == sys.argv[2]
build = load(build_path)
assert build['exitCode'] == 0 and build['sourceStable'] and build['status'] == 'CLOSED'
frozen_source = build_path.parent / 'sources-before.json'
frozen = load(frozen_source)
assert frozen == load(build_path.parent / 'sources-after.json')
assert all(sha(ROOT / p) == digest for p, digest in frozen.items()), 'Candidate source drift before platform build.'
assert sha(Path(build['artifact'])) == build['artifactSha256']
assert not os.environ.get('CARGO_TARGET_DIR'), 'The platform tool uses explicit default target paths.'
assert not (OUT / 'report.json').exists(), 'Preserve earlier acquisition.'

sys.path.insert(0, str(ROOT / 'tools'))
spec = importlib.util.spec_from_file_location('platform_acquisition', ROOT / 'tools/m1_platforms.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
paths = set(module.source_paths(ROOT)) | {ROOT / p for p in frozen}
paths |= {ROOT / p for p in ['.cargo/config.toml', 'references.lock', 'oracle.lock.json']}
before = {}
for path in sorted(paths):
    relative = path.relative_to(ROOT)
    data = path.read_bytes()
    destination = OUT / 'sources' / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    before[str(relative)] = hashlib.sha256(data).hexdigest()
save(OUT / 'sources-before.json', before)
environment_path = ROOT / 'target/m2/stage49-platform-environment-01/report.json'
environment = load(environment_path)
for name, digest in [('browser', 'browserSha256'), ('nodePath', 'nodeSha256'), ('bindgenPath', 'bindgenSha256')]:
    assert sha(Path(environment[name])) == environment[digest]
report = {
    'scope': 'Actual native/Node/Chromium shared primitive and architecture acquisition. Known Java regex mismatches remain failures; no complete M2 or performance claim.',
    'startedUtc': now(), 'cwd': str(ROOT), 'host': platform.platform(),
    'candidateBuild': str(build_path), 'candidateBuildSha256': sha(build_path),
    'candidateSourceMapSha256': sha(frozen_source), 'sourceCount': len(before),
    'environment': environment, 'python': sys.executable, 'pythonVersion': sys.version,
    'pythonSha256': sha(Path(sys.executable)), 'complete': False,
    'relevantEnvironment': {k: os.environ.get(k) for k in ['CARGO_TARGET_DIR', 'JAVA_HOME', 'PKL_ORACLE_JAVA', 'RUSTUP_TOOLCHAIN', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'LANG', 'LC_ALL', 'TZ']},
}
save(OUT / 'report.json', report)
output = OUT / 'primitives'
argv = [sys.executable, 'tools/m1_platforms.py', '--output', str(output),
        '--wasm-bindgen', environment['bindgenPath'], '--verify-contract']
with (OUT / 'primitives.stdout.bin').open('wb') as stdout, (OUT / 'primitives.stderr.bin').open('wb') as stderr:
    process = subprocess.Popen(argv, cwd=ROOT, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=stdout, stderr=stderr)
    save(OUT / 'active.json', {'argv': argv, 'pid': process.pid, 'startedUtc': now()})
    print('START actual primitive/platform acquisition', process.pid, flush=True)
    code = process.wait()
report['process'] = {'argv': argv, 'pid': process.pid, 'exitCode': code,
                     'stdoutSha256': sha(OUT / 'primitives.stdout.bin'),
                     'stderrSha256': sha(OUT / 'primitives.stderr.bin')}
after = {p: sha(ROOT / p) for p in before}
save(OUT / 'sources-after.json', after)
report['sourceChanges'] = [p for p, digest in before.items() if after[p] != digest]
report['runtimeChanges'] = [environment[k] for k, h in [('browser', 'browserSha256'), ('nodePath', 'nodeSha256'), ('bindgenPath', 'bindgenSha256')]
                            if sha(Path(environment[k])) != environment[h]]
if (output / 'report.json').is_file():
    primitive = load(output / 'report.json')
    report['primitiveReportSha256'] = sha(output / 'report.json')
    report['primitiveGate'] = {k: primitive[k] for k in ['total', 'oracle_passed', 'shared_engine_passed', 'compatibility_status', 'experiment_contract_status', 'known_gaps']}
    report['primitiveSourceStable'] = primitive['source_stability']
    report['primitiveSourcesBound'] = all(before.get(p) == digest for p, digest in primitive['source_hashes'].items())
    artifacts = {str((output / p).resolve()): digest for p, digest in primitive['artifacts'].items()}
    report['artifactsStable'] = all(sha(Path(p)) == digest for p, digest in artifacts.items())
    save(OUT / 'artifact-pins.json', {
        'schema': 1, 'files': artifacts,
        'sourceBindings': {str(build_path): sha(build_path), str(frozen_source): sha(frozen_source),
                           str((OUT / 'sources-before.json').resolve()): sha(OUT / 'sources-before.json'),
                           str((output / 'report.json').resolve()): sha(output / 'report.json')},
    })
report['complete'] = True
report['finishedUtc'] = now()
report['liveHandles'] = []
report['acquisitionAndArchitecturePassed'] = code == 0 and not report['sourceChanges'] and not report['runtimeChanges'] and report.get('primitiveSourceStable') and report.get('primitiveSourcesBound') and report.get('artifactsStable')
save(OUT / 'report.json', report)
save(OUT / 'active.json', {'complete': True, 'liveHandles': []})
print(json.dumps({k: report[k] for k in ['complete', 'sourceChanges', 'runtimeChanges', 'acquisitionAndArchitecturePassed']}), flush=True)
raise SystemExit(0 if report['acquisitionAndArchitecturePassed'] else 1)
