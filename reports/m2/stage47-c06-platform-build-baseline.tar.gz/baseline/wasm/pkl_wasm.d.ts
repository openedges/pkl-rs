/* tslint:disable */
/* eslint-disable */

export class HostProbe {
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    close(): void;
    drainCancelledReads(): string[];
    constructor(mode: string);
    poll(now: number, budget: number): string;
    reenter(token: string, now: number, timeout: number): void;
    reject(token: string, message: string, now: number): void;
    respondBytes(token: string, value: Uint8Array, now: number): void;
    respondInteger(token: string, value: any, now: number): void;
    start(now: number, timeout: number): void;
}

/**
 * Development-only parsed-source session. Logger callbacks run in the caller
 * after poll returns; this object owns no JavaScript callback or I/O semantics.
 */
export class SourceSession {
    free(): void;
    [Symbol.dispose](): void;
    acknowledgeLog(token: string, failure: Uint16Array | null | undefined, now: number): void;
    cancel(): void;
    close(): void;
    closeFromCallback(token: string): void;
    collect(): number;
    completeModuleCapabilities(token: string, local: boolean, hierarchical: boolean, fragment_paths: boolean, now: number): void;
    completeModuleHasElement(token: string, exists: boolean, now: number): void;
    completeModuleResolution(token: string, original_uri: string, resolved_uri: string, source_uri: string, now: number): void;
    completeModuleSource(token: string, text: string, inferred_name: string, now: number): void;
    completeReadMissing(token: string, now: number): void;
    completeReadResource(token: string, uri: string, bytes: Uint8Array, now: number): void;
    completeReadText(token: string, units: Uint16Array, now: number): void;
    contextDepth(): number;
    drainCancelledModules(): string[];
    drainCancelledReads(): string[];
    static forExpressions(source: string, uri: string, module_name: string, paths: Array<any>, trace_mode?: string | null, host_logger?: boolean | null, host_frame_transformer?: boolean | null, power_assertions?: boolean | null): SourceSession;
    static forOutput(source: string, uri: string, module_name: string, paths: Array<any>, _arguments: Array<any>, trace_mode?: string | null, host_logger?: boolean | null, host_frame_transformer?: boolean | null, power_assertions?: boolean | null): SourceSession;
    heapSlots(): number;
    constructor(source: string, uri: string, module_name: string, paths: Array<any>, trace_mode?: string | null, host_logger?: boolean | null, host_frame_transformer?: boolean | null, power_assertions?: boolean | null);
    poll(now: number, budget: number): any;
    reenterOutputBytes(token: string, now: number, timeout?: number | null): void;
    reenterPath(token: string, index: number, now: number, timeout?: number | null): void;
    reject(token: string, message: string, now: number): void;
    rejectModulePreparation(token: string, has_element: boolean, kind: string, message: string | null | undefined, now: number): void;
    rejectModuleResolution(token: string, kind: string, message: string | null | undefined, now: number): void;
    rejectModuleSource(token: string, kind: string, message: string | null | undefined, now: number): void;
    rejectReadIo(token: string, message: string | null | undefined, now: number): void;
    rejectReadSecurityManager(token: string, message: string | null | undefined, now: number): void;
    resolvedReadUri(token: string): string;
    respondBytes(token: string, value: Uint8Array, now: number): void;
    respondConfigured(token: string, now: number): void;
    respondInteger(token: string, value: any, now: number): void;
    respondString(token: string, value: Uint16Array, now: number): void;
    setupFailed(): boolean;
    startModule(now: number, timeout?: number | null): void;
    startOutputBytes(now: number, timeout?: number | null): void;
    startPath(index: number, now: number, timeout?: number | null): void;
}

export function evaluate(source: string, member: string): string;

/**
 * Development-only scalar boundary with shared Pkl diagnostic rendering.
 */
export function evaluateLanguage(source: string, uri: string, module_name: string, expression: string, power_assertions?: boolean | null): string;

/**
 * Development-only ordered calls on one evaluator, retaining failures as data.
 */
export function evaluateLanguageSequence(source: string, uri: string, module_name: string, expressions: Array<any>, power_assertions?: boolean | null): Array<any>;

/**
 * Portable frontend bytes; no native process exit or generated-files execution.
 */
export function evaluateModuleFrontend(source: string, uri: string, module_name: string, _arguments: Array<any>): object;

/**
 * Actual shared module-output bytes; PCF and encoding stay in pkl-runtime.
 */
export function evaluateModuleOutput(source: string, uri: string, module_name: string, _arguments: Array<any>): object;

export function primitive(family: string, input: string): string;

export function roundtripBytes(input: Uint8Array): Uint8Array;

export function roundtripInteger(input: any): bigint;

export function roundtripString(input: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_hostprobe_free: (a: number, b: number) => void;
    readonly __wbg_sourcesession_free: (a: number, b: number) => void;
    readonly evaluate: (a: any, b: any) => [number, number, number, number];
    readonly evaluateLanguage: (a: any, b: any, c: any, d: any, e: number) => [number, number, number];
    readonly evaluateLanguageSequence: (a: any, b: any, c: any, d: any, e: number) => [number, number, number];
    readonly evaluateModuleFrontend: (a: any, b: any, c: any, d: any) => [number, number, number];
    readonly evaluateModuleOutput: (a: any, b: any, c: any, d: any) => [number, number, number];
    readonly hostprobe_cancel: (a: number) => void;
    readonly hostprobe_close: (a: number) => void;
    readonly hostprobe_drainCancelledReads: (a: number) => [number, number];
    readonly hostprobe_new: (a: any) => [number, number, number];
    readonly hostprobe_poll: (a: number, b: number, c: number) => [number, number, number, number];
    readonly hostprobe_reenter: (a: number, b: any, c: number, d: number) => [number, number];
    readonly hostprobe_reject: (a: number, b: any, c: any, d: number) => [number, number];
    readonly hostprobe_respondBytes: (a: number, b: any, c: any, d: number) => [number, number];
    readonly hostprobe_respondInteger: (a: number, b: any, c: any, d: number) => [number, number];
    readonly hostprobe_start: (a: number, b: number, c: number) => [number, number];
    readonly primitive: (a: any, b: any) => [number, number, number, number];
    readonly roundtripBytes: (a: any) => [number, number, number];
    readonly roundtripInteger: (a: any) => [number, number, number];
    readonly roundtripString: (a: any) => [number, number, number, number];
    readonly sourcesession_acknowledgeLog: (a: number, b: any, c: number, d: number) => [number, number];
    readonly sourcesession_cancel: (a: number) => void;
    readonly sourcesession_close: (a: number) => void;
    readonly sourcesession_closeFromCallback: (a: number, b: any) => [number, number];
    readonly sourcesession_collect: (a: number) => [number, number, number];
    readonly sourcesession_completeModuleCapabilities: (a: number, b: any, c: number, d: number, e: number, f: number) => [number, number];
    readonly sourcesession_completeModuleHasElement: (a: number, b: any, c: number, d: number) => [number, number];
    readonly sourcesession_completeModuleResolution: (a: number, b: any, c: any, d: any, e: any, f: number) => [number, number];
    readonly sourcesession_completeModuleSource: (a: number, b: any, c: any, d: any, e: number) => [number, number];
    readonly sourcesession_completeReadMissing: (a: number, b: any, c: number) => [number, number];
    readonly sourcesession_completeReadResource: (a: number, b: any, c: any, d: any, e: number) => [number, number];
    readonly sourcesession_completeReadText: (a: number, b: any, c: any, d: number) => [number, number];
    readonly sourcesession_contextDepth: (a: number) => number;
    readonly sourcesession_drainCancelledModules: (a: number) => [number, number];
    readonly sourcesession_forExpressions: (a: any, b: any, c: any, d: any, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly sourcesession_forOutput: (a: any, b: any, c: any, d: any, e: any, f: number, g: number, h: number, i: number) => [number, number, number];
    readonly sourcesession_heapSlots: (a: number) => [number, number, number];
    readonly sourcesession_new: (a: any, b: any, c: any, d: any, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly sourcesession_poll: (a: number, b: number, c: number) => [number, number, number];
    readonly sourcesession_reenterOutputBytes: (a: number, b: any, c: number, d: number, e: number) => [number, number];
    readonly sourcesession_reenterPath: (a: number, b: any, c: number, d: number, e: number, f: number) => [number, number];
    readonly sourcesession_reject: (a: number, b: any, c: any, d: number) => [number, number];
    readonly sourcesession_rejectModulePreparation: (a: number, b: any, c: number, d: any, e: number, f: number) => [number, number];
    readonly sourcesession_rejectModuleResolution: (a: number, b: any, c: any, d: number, e: number) => [number, number];
    readonly sourcesession_rejectModuleSource: (a: number, b: any, c: any, d: number, e: number) => [number, number];
    readonly sourcesession_rejectReadIo: (a: number, b: any, c: number, d: number) => [number, number];
    readonly sourcesession_rejectReadSecurityManager: (a: number, b: any, c: number, d: number) => [number, number];
    readonly sourcesession_resolvedReadUri: (a: number, b: any) => [number, number, number, number];
    readonly sourcesession_respondBytes: (a: number, b: any, c: any, d: number) => [number, number];
    readonly sourcesession_respondConfigured: (a: number, b: any, c: number) => [number, number];
    readonly sourcesession_respondInteger: (a: number, b: any, c: any, d: number) => [number, number];
    readonly sourcesession_respondString: (a: number, b: any, c: any, d: number) => [number, number];
    readonly sourcesession_setupFailed: (a: number) => number;
    readonly sourcesession_startModule: (a: number, b: number, c: number, d: number) => [number, number];
    readonly sourcesession_startOutputBytes: (a: number, b: number, c: number, d: number) => [number, number];
    readonly sourcesession_startPath: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly sourcesession_drainCancelledReads: (a: number) => [number, number];
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
