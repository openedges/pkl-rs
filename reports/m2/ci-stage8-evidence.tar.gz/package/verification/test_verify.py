"""Target-only regression checks for archive and artifact corruption rejection."""
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('stage8_verifier',HERE/'verify.py')
verifier=importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)


class VerificationTests(unittest.TestCase):
    def test_archive_parent_absolute_drive_and_symlink_members_fail(self):
        for name in ['../escape','/absolute','C:/drive','a\\escape','link']:
            with self.subTest(name=name),tempfile.TemporaryDirectory()as temporary:
                base=Path(temporary)
                with zipfile.ZipFile(base/'artifact.zip','w')as archive:
                    info=zipfile.ZipInfo(name)
                    if name=='link':info.external_attr=(stat.S_IFLNK|0o777)<<16
                    archive.writestr(info,b'payload')
                with self.assertRaises(ValueError):verifier.safe_extract(base/'artifact.zip',base/'artifact')

    def test_exact_github_digest_commit_and_complete_jobs_are_required(self):
        with tempfile.TemporaryDirectory()as temporary:
            base=Path(temporary)
            commit='a'*40
            run=dict(id=1,head_sha=commit,status='completed',conclusion='success')
            jobs=dict(total_count=1,jobs=[dict(name='required',conclusion='success')])
            archive=base/'artifact.zip'
            archive.write_bytes(b'raw ZIP transport bytes')
            row=dict(name=verifier.NAMES['m2'],id=1,expired=False,workflow_run=dict(head_sha=commit,id=1),digest='sha256:'+hashlib.sha256(archive.read_bytes()).hexdigest())
            def save():
                for name,value in [('run',run),('jobs',jobs),('artifacts',dict(artifacts=[row]))]:
                    (base/(name+'.json')).write_text(json.dumps(value))
            save()
            verifier.metadata(base,'m2',commit,1)
            archive.write_bytes(b'corrupted')
            with self.assertRaises(ValueError):verifier.metadata(base,'m2',commit,1)
            archive.write_bytes(b'raw ZIP transport bytes')
            run['head_sha']='b'*40
            save()
            with self.assertRaises(ValueError):verifier.metadata(base,'m2',commit,1)
            run['head_sha']=commit
            jobs['total_count']=2
            save()
            with self.assertRaises(ValueError):verifier.metadata(base,'m2',commit,1)
            jobs['total_count']=1
            jobs['jobs'][0]['conclusion']='failure'
            save()
            with self.assertRaises(ValueError):verifier.metadata(base,'m2',commit,1)


if __name__=='__main__':unittest.main()
