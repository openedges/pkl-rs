"""Capture focused node lifecycle verification without overwriting old evidence."""
from pathlib import Path
import subprocess,json,hashlib,re,shutil,sys,platform,datetime
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
names=['m2_collection_types_lifecycle','m2_constraint_slots_lifecycle','m2_equality_lifecycle','m2_recursive_types_lifecycle','m2_references_lifecycle','m2_type_metadata_lifecycle','m2_type_node_lifecycle','m2_type_resolution_lifecycle']
command=['cargo','test','-p','pkl-runtime','--locked','--no-fail-fast']
for name in names:command+=['--test',name]
paths=sorted([*Path('crates/pkl-runtime/src').rglob('*.rs'),*Path('crates/pkl-runtime/tests').rglob('*.rs'),Path('Cargo.toml'),Path('Cargo.lock'),Path('rust-toolchain.toml'),Path(__file__).relative_to(Path.cwd()) if Path(__file__).is_absolute() else Path(__file__)])
before={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(p.read_bytes())
r=subprocess.run(command,capture_output=True);(out/'stdout.bin').write_bytes(r.stdout);(out/'stderr.bin').write_bytes(r.stderr)
after={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths}
artifacts=[]
for name in re.findall(r'\((target/debug/deps/[^)]+)\)',r.stderr.decode()):
 src=Path(name);dest=out/'artifacts'/src.name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(src,dest);artifacts.append(dict(path=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),bytes=dest.stat().st_size))
row=dict(command=command,cwd=str(Path.cwd()),exit_code=r.returncode,host=platform.platform(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_sha256_before=before,source_sha256_after=after,source_stability=before==after,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),artifacts=artifacts)
(out/'process.json').write_text(json.dumps(row,indent=2)+'\n')
(out/'evidence-sha256.json').write_text(json.dumps({str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(out.rglob('*'))if p.is_file()},indent=2)+'\n')
print(json.dumps(dict(exit_code=r.returncode,source_stability=before==after,artifacts=len(artifacts))))
raise SystemExit(r.returncode)
