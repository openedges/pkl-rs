"""Recompute every final exploratory verdict before sealing its archive."""
from pathlib import Path
from collections import Counter
import sys,json,hashlib
sys.dont_write_bytecode=True
sys.path[:0]=['target/m2','tools']
import package_stage17_final as p,stage17_package_common as c
ROOT=Path.cwd();BASE=ROOT/'target/m2';summary=c.load(BASE/'stage17-exploration-summary-final.json');bundle=BASE/'stage17-exploration-bundle-final';c.require(c.load(bundle/'SUMMARY.json')==summary,'bundle summary differs')
release=summary['release_build'];directory=ROOT/release['path'];c.verify_inventory(directory);c.identity(directory/'candidate.json',release['metadata_sha256']);build=c.load(directory/'candidate.json');c.require(build['source_binding']=='recorded-build'and build['source_stability']and build['source_sha256_before']==build['source_sha256_after']and build['build']['exit_code']==0 and not build['build']['timed_out'],'final recorded build invalid')
for artifact,row in build['artifacts'].items():c.identity(directory/'artifacts'/artifact,row['frozen_sha256']);c.require(row['candidate_sha256']==row['frozen_sha256'],'artifact copy differs')
single={}
for key in ['selected_release_replay','final_discovery_replay','root_discovery_replay','let_followup_replay']:
 row=summary[key];actual=p.audit_single_replay(ROOT/row['path'],build['artifacts']['language_probe']['frozen_sha256'])
 for field in ['count','status_counts','known_mismatches']:c.require(actual[field]==row[field],'single replay count/verdict differs '+key)
 single[key]=actual
old=c.load(BASE/'stage16-const-retry-gap.json');required={row['path']for row in old['evidence']};covered=set();counts=Counter();acquisitions=summary['persistent_exploration']['acquisitions'];c.require(len(acquisitions)==len({row['path']for row in acquisitions})and acquisitions,'duplicate/empty persistent acquisitions')
for row in acquisitions:
 actual=p.audit_persistent_replay(ROOT/row['path'],ROOT/row['baseline'],build['artifacts']['class_lifecycle_probe']['frozen_sha256']);c.require(actual['comparisons']==row['comparisons']and actual['status_counts']==row['status_counts'],'persistent verdict differs '+row['path']);counts.update(actual['status_counts'])
 if row['baseline']in required:c.require(actual['status_counts']=={'pass':actual['comparisons']},'original retry gap remains');covered.add(row['baseline'])
c.require(covered==required,'original gap replay omitted');c.require(sum(counts.values())==summary['persistent_exploration']['comparisons']and dict(counts)==summary['persistent_exploration']['status_counts'],'persistent totals differ')
for row in old['evidence']:
 directory=ROOT/row['path'];c.verify_inventory(directory);expected={row['path']+'/evidence-sha256.json':row['inventory_sha256']};expected.update({row['path']+'/'+name:digest for name,digest in c.load(directory/'evidence-sha256.json').items()})
 for name,digest in expected.items():c.identity(bundle/name,digest)
c.identity(bundle/'target/m2/stage16-const-retry-gap.json',c.sha(BASE/'stage16-const-retry-gap.json'))
selection=c.load(ROOT/'tests/fixtures/m2/cases.json')['cases'];baseline=c.load(BASE/'stage17-baseline-contract/sources/tests/fixtures/m2/cases.json')['cases'];c.require(len(selection)==summary['selected_count']and len(baseline)==summary['original_selected_preserved']and len(selection)-len(baseline)==summary['new_selected_count'],'selection count differs')
report=dict(status='pass',scope='Read-only preseal audit; original raw nonpasses and superseded/unbound history retained. Native persistent artifact has its own separately recorded build and exact source proof; its binary need not equal the exploratory build binary.',summary_sha256=c.sha(BASE/'stage17-exploration-summary-final.json'),independent=single,persistent=dict(acquisitions=len(acquisitions),calls=sum(counts.values()),status_counts=dict(counts),original_gap_acquisitions=len(covered),original_gap_raw_calls=sum(row['comparisons']for row in acquisitions if row['baseline']in required)),historical_gap_evidence_complete_in_bundle=True,selected=len(selection))
out=Path(sys.argv[1]);c.write_new(out,report);print(json.dumps(report,sort_keys=True))
