"""Seal Stage17 local evidence and bind every final source copy to Git.

Read-only report verification does not execute any retained evaluator binary.
No CI acquisition, prior CI status, or hosted artifact is required.
"""
import argparse
from collections import Counter
import hashlib
import importlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
import stage17_package_common as c

ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
REPORTS = ROOT / 'reports/m2'
BASELINE = BASE / 'stage17-baseline-contract'
KNOWN = {'error-cycle', 'error-remainder-zero'}


def old_archive(name, members):
    """Read identified original bytes; original archives are never rewritten."""
    summary = c.load(REPORTS / 'stage16-final-summary.json')
    record = summary['archives'][name]
    path = ROOT / record['path']
    c.identity(path, record['sha256'], record['bytes'])
    with tarfile.open(path) as stream:
        return {name: stream.extractfile(name).read() for name in members}


# The original baseline omitted generated metadata and later repaired lifecycle inputs.
# Read missing documents from its exact immutable Git revision; preserve command
# proof in the final regression/source evidence without rewriting that baseline.
BASELINE_GIT_READS = {}


def baseline_json(name):
    path = BASELINE / 'sources' / name
    if path.is_file():
        return c.load(path)
    if name not in BASELINE_GIT_READS:
        head = c.load(BASELINE / 'summary.json')['git_revision']
        command = ['git', 'show', head + ':' + name]
        result = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=60)
        c.require(result.returncode == 0, 'cannot read missing baseline metadata: ' + name)
        BASELINE_GIT_READS[name] = dict(command=command, stdout=result.stdout, stderr=result.stderr)
    return json.loads(BASELINE_GIT_READS[name]['stdout'])


def verify_baseline():
    """Verify the exact immutable pre-Stage17 Git fixture/contract snapshot."""
    c.verify_inventory(BASELINE)
    baseline = c.load(BASELINE / 'summary.json')
    c.require(baseline['git_revision'] == 'a415e0437353f358211157ea87e7068c8aeeaef8',
              'baseline is not the preserved pre-Stage17 revision')
    c.require(len(baseline['sources']) == baseline['source_count'], 'baseline source denominator differs')
    names = [row['path'] for row in baseline['sources']]
    c.require(len(names) == len(set(names)), 'duplicate baseline source identity')
    listing = (BASELINE / 'git-ls-tree.bin').read_bytes()
    tree_rows = {}
    for line in listing.splitlines():
        header, name = line.split(b'\t', 1)
        mode, kind, oid = header.split()
        tree_rows[name.decode()] = (mode.decode(), kind.decode(), oid.decode())
    for row in baseline['sources']:
        path = BASELINE / 'sources' / row['path']
        c.identity(path, row['sha256'], row['bytes'])
        payload = path.read_bytes()
        git_blob = hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()
        c.require(git_blob == row['git_blob'] == tree_rows[row['path']][2] and
                  tree_rows[row['path']][1] == 'blob', 'baseline Git blob differs: ' + row['path'])
    previous_language = json.loads(old_archive('language', ['report.json'])['report.json'])
    previous_classes = json.loads(old_archive('class-lifecycle', ['report.json'])['report.json'])
    original = c.load(BASELINE / 'sources/tests/fixtures/m2/cases.json')['cases']
    original_classes = c.load(BASELINE / 'sources/compatibility/m2-class-lifecycle/manifest.json')['sequences']
    c.exact_ids(previous_language['results'], [row['id'] for row in original], 'baseline language')
    computed = dict(selected_cases=len(original), relations=len(previous_language['metamorphic_results']),
                    sequence_executions=len(previous_classes['cases']),
                    sequence_call_comparisons=sum(len(row['observations']['comparisons']) for row in previous_classes['cases']))
    c.require(computed['selected_cases'] == baseline['selected_cases'] == 1597 and
              computed['relations'] == 54 and computed['sequence_executions'] == 72 and
              computed['sequence_call_comparisons'] == 502 and
              len(original_classes) * previous_classes['repetitions'] == computed['sequence_executions'],
              'preserved Stage16 baseline denominators differ')
    return dict(baseline, head=baseline['git_revision'], **computed)


def previous_class_repetitions():
    return json.loads(old_archive('class-lifecycle', ['report.json'])['report.json'])['repetitions']



def audit_single_replay(directory, expected_artifact):
    """Rederive exploratory verdicts from full processes/channels, preserving mismatches."""
    c.verify_inventory(directory)
    candidate = c.load(directory / 'candidate.json')
    c.require(candidate['source_stability'] and
              candidate['source_sha256_before'] == candidate['source_sha256_after'],
              'exploratory comparison sources were unstable')
    c.require(candidate['frozen_sha256'] == expected_artifact, 'exploratory artifact is not final build')
    c.identity(directory / 'artifacts/language_probe', expected_artifact)
    rows = c.load(directory / 'results.json')
    baselines = {}
    counts = Counter()
    mismatches = []
    for row in rows:
        baseline = Path(row['baseline'])
        if baseline not in baselines:
            c.verify_inventory(baseline)
            baselines[baseline] = {r['id']: r for r in c.load(baseline / 'results.json')}
        previous = baselines[baseline][row['id']]
        java_folder = baseline / 'cases' / row['id']
        rust_folder = directory / baseline.name / row['id']
        c.require(c.load(rust_folder / 'rust.process.json') == row['rust'], 'exploratory process metadata differs')
        captures = []
        for process, folder, engine in [(previous['java'], java_folder, 'java'),
                                         (row['rust'], rust_folder, 'rust')]:
            channels = []
            for channel in ['stdout', 'stderr']:
                path = folder / (engine + '.' + channel + '.bin')
                c.identity(path, process[channel + '_sha256'])
                channels.append(path.read_bytes())
            captures.append((process['exit_code'], process['timed_out'], *channels))
        from m2_language import valid_exception_outcome
        outcome = (java_folder / 'java.outcome.bin').read_bytes()
        c.identity(java_folder / 'java.outcome.bin', previous['java']['outcome_sha256'])
        java = captures[0]
        valid = not java[1] and ((java[0] == 0 and not java[3] and outcome == b'success\n') or
                                (java[0] == 1 and not java[2] and valid_exception_outcome(outcome)))
        verdict = 'pass' if captures[0] == captures[1] and valid else ('mismatch' if valid else 'oracle-error')
        c.require(verdict == row['status'] and valid == row['valid_java_outcome'],
                  'exploratory raw verdict differs: ' + row['id'])
        counts[verdict] += 1
        if verdict != 'pass':
            mismatches.append(dict(baseline=baseline.name, id=row['id']))
    return dict(count=len(rows), status_counts=dict(counts), known_mismatches=mismatches)


def audit_persistent_replay(directory, baseline, expected_artifact):
    c.verify_inventory(directory)
    c.verify_inventory(baseline)
    candidate = c.load(directory / 'candidate.json')
    c.require(candidate['source_stability'] and
              candidate['source_sha256_before'] == candidate['source_sha256_after'] and
              candidate['baseline_inventory_sha256'] == c.sha(baseline / 'evidence-sha256.json'),
              'persistent exploratory provenance differs')
    c.require(candidate['frozen_sha256'] == expected_artifact, 'persistent artifact is not final build')
    c.identity(directory / 'artifacts/class_lifecycle_probe', expected_artifact)
    original = {r['id']: r for r in c.load(baseline / 'results.json')}
    rows = c.load(directory / 'results.json')
    counts = Counter()
    for row in rows:
        spec = original[row['id']]
        c.require(len(row['comparisons']) == len(spec['expressions']), 'persistent call coverage differs')
        folder = directory / row['id']
        c.require(c.load(folder / 'process.process.json') == row['process'], 'persistent process metadata differs')
        for channel in ['stdout', 'stderr']:
            c.identity(folder / ('process.' + channel + '.bin'), row['process'][channel + '_sha256'])
        for index, (call, expression) in enumerate(zip(row['comparisons'], spec['expressions'])):
            java = baseline / row['id'] / 'java'
            rust = folder / 'rust'
            valid = (java / f'{index}.status.bin').read_bytes() != b'oracle-error\n'
            same = row['process']['exit_code'] == 0 and not row['process']['timed_out'] and all(
                (java / f'{index}.{name}.bin').read_bytes() == (rust / f'{index}.{name}.bin').read_bytes()
                for name in ['status', 'stdout', 'stderr'])
            verdict = 'pass' if valid and same else 'mismatch'
            c.require(call == dict(index=index, expression=expression, status=verdict),
                      'persistent raw verdict differs')
            counts[verdict] += 1
    return dict(comparisons=sum(counts.values()), status_counts=dict(counts))


def verify_exploration_archive_set(summary, main_path):
    """Verify disjoint main/support inventories conserve every original payload byte."""
    import contextlib
    import evidence
    def read_archive(path):
        with contextlib.redirect_stdout(io.StringIO()):
            evidence.verify(path)
        with tarfile.open(path) as stream:
            records = json.load(stream.extractfile('EVIDENCE.json'))['files']
            files = {row['path']: row for row in records}
            c.require(len(files) == len(records), 'duplicate archive inventory paths')
            extras = {}
            if path == main_path:
                for name in ['SUMMARY.json', summary['exploration_partition']['index_path']]:
                    extras[name] = stream.extractfile(name).read()
        return files, extras
    main, extra = read_archive(main_path)
    c.require(extra['SUMMARY.json'] == (BASE / 'stage17-exploration-summary-final.json').read_bytes(),
              'sealed main summary differs from external summary')
    metadata = summary['exploration_partition']
    index_bytes = extra[metadata['index_path']]
    c.require(hashlib.sha256(index_bytes).hexdigest() == metadata['index_sha256'],
              'partition index identity differs')
    index = json.loads(index_bytes)
    c.require(index['schema'] == 1 and
              index['metadata_relocations'] == {'SUMMARY.json': 'PRE-PARTITION-SUMMARY.json'},
              'partition schema/metadata relocation differs')
    original = index['original_files_sha256']
    sizes = index['original_files_bytes']
    c.require(set(sizes) == set(original) and original and
              len(original) == metadata['original_payload_files'] and
              sum(sizes.values()) == metadata['original_payload_bytes'],
              'original partition payload denominator differs')
    supports = summary['support_archives']
    c.require(supports and len({row['partition_key'] for row in supports}) == len(supports) and
              set(index['support_files_sha256']) == {row['partition_key'] for row in supports},
              'support archive index missing/duplicated')
    expected_main = index['main_files_sha256']
    c.require(set(main) == set(expected_main) | {'SUMMARY.json', metadata['index_path']},
              'main archive payload differs from exact partition')
    all_files = {}
    support_claims = []
    def merge(actual, expected, label):
        c.require(set(actual) == set(expected), 'archive partition path set differs: ' + label)
        for name, digest in expected.items():
            c.require(name not in all_files and name in original and
                      actual[name]['sha256'] == digest == original[name] and
                      actual[name]['bytes'] == sizes[name],
                      'partition overlap/hash/size differs: ' + name)
            all_files[name] = actual[name]
    merge({name: main[name] for name in expected_main}, expected_main, 'main')
    for row in supports:
        path = ROOT / row['path']
        c.identity(path, row['sha256'], row['bytes'])
        actual, unused = read_archive(path)
        c.require(not unused and len(actual) == row['files_count'],
                  'support payload denominator differs: ' + row['path'])
        merge(actual, index['support_files_sha256'][row['partition_key']], row['path'])
        support_claims.append(dict(row, inventory_verified=True))
    c.require({name: row['sha256'] for name, row in all_files.items()} == original,
              'original payload was lost/added during archive partition')
    c.require('PRE-PARTITION-SUMMARY.json' in original and 'SUMMARY.json' not in original,
              'original summary bytes were not retained separately')
    return all_files, dict(status='pass', index_sha256=metadata['index_sha256'],
        original_payload_files=len(original), original_payload_bytes=sum(sizes.values()),
        disjoint_paths=True, exact_path_hash_byte_conservation=True,
        support_archives=support_claims,
        offline_requirement='Acquire main and every indexed support archive. Their original payload paths are disjoint and can be extracted together before raw report audit.')


def verify_exploration_gap(data):
    """Retain original failures while checking the final bounded ownership controls."""
    historical_path = BASE / 'stage16-const-retry-gap.json'
    historical = c.load(historical_path)
    c.require(historical['status'] == 'known-unimplemented' and historical['release_requirement_remains_open'],
              'original Stage16 gap history was relabeled')
    for row in historical['java_sources'].values():
        c.identity(ROOT / row['path'], row['sha256'])
    for row in historical['evidence']:
        directory = ROOT / row['path']
        for name, key in [('evidence-sha256.json', 'inventory_sha256'),
                          ('matrix.json', 'matrix_sha256'), ('results.json', 'results_sha256')]:
            c.identity(directory / name, row[key])
        c.verify_inventory(directory)
    summary_path = BASE / 'stage17-exploration-summary-final.json'
    archive_path = REPORTS / 'exploration-stage17-evidence.tar.gz'
    c.require(summary_path.is_file() and archive_path.is_file(), 'final exploratory evidence is missing')
    summary = c.load(summary_path)
    archived, partition = verify_exploration_archive_set(summary, archive_path)
    c.require(str(historical_path.relative_to(ROOT)) in archived and
              archived[str(historical_path.relative_to(ROOT))]['sha256'] == c.sha(historical_path),
              'exploration archive omitted original Stage16 retry-gap record')
    for row in historical['evidence']:
        directory = ROOT / row['path']
        expected = {row['path'] + '/evidence-sha256.json': row['inventory_sha256']}
        expected.update({row['path'] + '/' + name: digest
                         for name, digest in c.load(directory / 'evidence-sha256.json').items()})
        for name, digest in expected.items():
            c.require(name in archived and archived[name]['sha256'] == digest,
                      'exploration archive omitted/changed historical retry evidence: ' + name)
    summary = c.load(summary_path)
    selection = data['selection_counts']
    c.require(summary['selected_count'] == selection['selected'] and
              summary['original_selected_preserved'] == selection['original_selected'] and
              summary['new_selected_count'] == selection['added_selected'] and
              summary['metamorphic_relations'] == selection['relations'],
              'exploration/official selection accounting differs')
    c.require(summary['class_lifecycle']['unique_sequences'] == data['class_counts']['unique_sequences'] and
              summary['class_lifecycle']['sequence_executions'] == data['class_counts']['sequence_executions'] and
              summary['class_lifecycle']['comparisons'] == data['class_counts']['call_comparisons'],
              'exploration/official sequence accounting differs')
    release = summary['release_build']
    build_directory = ROOT / release['path']
    c.verify_inventory(build_directory)
    c.identity(build_directory / 'candidate.json', release['metadata_sha256'])
    build = c.load(build_directory / 'candidate.json')
    c.require(build['source_binding'] == 'recorded-build' and build['source_stability'] and
              build['source_sha256_before'] == build['source_sha256_after'] and
              build['build']['exit_code'] == 0 and build['build']['timed_out'] is False,
              'exploratory final release build provenance differs')
    for artifact, row in build['artifacts'].items():
        c.require(row['candidate_sha256'] == row['frozen_sha256'], 'release artifact copy differs')
        c.identity(build_directory / 'artifacts' / artifact, row['frozen_sha256'])
    language_sha = build['artifacts']['language_probe']['frozen_sha256']
    sequence_sha = build['artifacts']['class_lifecycle_probe']['frozen_sha256']
    focused = audit_single_replay(ROOT / summary['selected_release_replay']['path'], language_sha)
    observed = audit_single_replay(ROOT / summary['final_discovery_replay']['path'], language_sha)
    c.require(focused['count'] == selection['added_selected'] and
              focused['status_counts'] == summary['selected_release_replay']['status_counts'] == {'pass': focused['count']},
              'selected final exploratory raw verdicts differ')
    for field in ['count', 'status_counts', 'known_mismatches']:
        c.require(observed[field] == summary['final_discovery_replay'][field], 'original discovery accounting differs')
    supplementary = {}
    for field in ['root_discovery_replay', 'let_followup_replay']:
        replay = summary[field]
        audit = audit_single_replay(ROOT / replay['path'], language_sha)
        for key in ['count', 'status_counts', 'known_mismatches']:
            c.require(audit[key] == replay[key], 'supplementary independent accounting differs: ' + field)
        supplementary[field] = audit
    persistent = Counter()
    total = 0
    originals = {row['path'] for row in historical['evidence']}
    audited_originals = set()
    acquisitions = summary['persistent_exploration']['acquisitions']
    c.require(acquisitions and len({row['path'] for row in acquisitions}) == len(acquisitions),
              'persistent acquisition list empty or duplicated')
    for row in acquisitions:
        directory, baseline = ROOT / row['path'], ROOT / row['baseline']
        audit = audit_persistent_replay(directory, baseline, sequence_sha)
        c.require(audit['comparisons'] == row['comparisons'] and audit['status_counts'] == row['status_counts'],
                  'persistent replay accounting differs: ' + row['path'])
        total += audit['comparisons']
        persistent.update(audit['status_counts'])
        if baseline.relative_to(ROOT).as_posix() in originals:
            c.require(audit['status_counts'] == {'pass': audit['comparisons']},
                      'preserved original non-generic retry sequence still differs')
            audited_originals.add(baseline.relative_to(ROOT).as_posix())
    c.require(audited_originals == originals, 'original persistent retry evidence omitted')
    c.require(total == summary['persistent_exploration']['comparisons'] and
              dict(persistent) == summary['persistent_exploration']['status_counts'],
              'persistent exploration totals differ')
    data['const_retry_gap'] = dict(status='bounded-non-generic-controls-resolved',
        historical_path=str(historical_path.relative_to(ROOT)), historical_sha256=c.sha(historical_path),
        historical_record_unchanged=True,
        accepted_scope='Evaluator-local local-property resolution ownership for selected non-generic inline, lambda, shared let-root, recursive depth, inherited declarations and lazy collection wrapper cases.',
        remaining_scope='Recursive generic instantiation, generic let-root type-variable behavior, invalid class-path and local typed-object diagnostic frames, const-let-body/outer lexical-scope observations, full runtime type-resolution/M2/API and release performance/platform requirements remain open.',
        all_original_persistent_controls_raw_match=True, full_language_requirement_remains_open=True)
    data['exploration'] = dict(summary_path=str(summary_path.relative_to(ROOT)),
        summary_sha256=c.sha(summary_path), summary=summary,
        archive=dict(path=str(archive_path.relative_to(ROOT)), sha256=c.sha(archive_path), bytes=archive_path.stat().st_size),
        archive_inventory_verified_by_sealer=True,
        archive_partition_verification=partition,
        support_archives=partition['support_archives'],
        supplementary_replays=supplementary,
        original_failed_sequences_and_all_acquisition_iterations_retained=True)


def retain_baseline_git_proof(destination):
    destination.mkdir()
    rows = []
    for name, record in BASELINE_GIT_READS.items():
        payload = record['stdout']
        path = destination / 'documents' / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(payload)
        folder = destination / 'commands' / str(len(rows))
        folder.mkdir(parents=True)
        (folder / 'stdout.bin').write_bytes(payload)
        (folder / 'stderr.bin').write_bytes(record['stderr'])
        row = dict(path=name, command=record['command'], cwd=str(ROOT), exit_code=0,
                   stdout_sha256=c.sha(folder / 'stdout.bin'), stderr_sha256=c.sha(folder / 'stderr.bin'))
        c.write_new(folder / 'process.json', row)
        rows.append(row)
    c.write_new(destination / 'report.json', dict(baseline_head=c.load(BASELINE / 'summary.json')['git_revision'],
        baseline_git_listing_sha256=c.sha(BASELINE / 'git-ls-tree.bin'),
        git_blob_identities_verified=True,
        scope='Missing baseline metadata read from exact original Git blobs. Original immutable baseline files remain unchanged; Stage17 baseline has no repair history.',
        documents=rows, captured_binaries_executed=False))


def source_rows(directories, data):
    # The capture helper is untracked task machinery with its own retained hash;
    # all Rust/Cargo snapshots below are bound to the exact implementation Git bytes.
    for name, digest in data['native_lifecycle']['source_sha256_before'].items():
        relative = Path(name).relative_to(ROOT) if Path(name).is_absolute() else Path(name)
        if relative.parts[0] != 'target':
            yield relative.as_posix(), BASE / 'stage17-retention-final-07/sources' / relative, digest
    for suite, field in [('language', 'source_sha256'), ('frontend', 'source_sha256'), ('platforms', 'source_hashes')]:
        if suite not in data:
            continue
        for name, digest in data[suite][field].items():
            yield name, directories[suite] / 'sources' / name, digest
    for suite in ['classes', 'lifecycle']:
        for row in data[suite]['sources']:
            yield row['path'], directories[suite] / row['snapshot'], row['sha256']
    for row in data['runtime']['identities']:
        if 'snapshot' in row:
            snapshot = Path(row['snapshot'])
            yield snapshot.relative_to(directories['runtime'] / 'sources').as_posix(), snapshot, row['sha256']
    directory = directories['platforms'] / 'oracle-native'
    for name, digest in c.load(directory / 'report.json')['sources'].items():
        yield name, directory / 'sources' / name, digest
    if 'prior' in data:
        for path in sorted((BASE / 'prior-selection-stage17-final-02/sources').rglob('*')):
            if path.is_file():
                yield path.relative_to(BASE / 'prior-selection-stage17-final-02/sources').as_posix(), path, c.sha(path)


def inspect(directories):
    sys.path.insert(0, str(ROOT / 'tools'))
    language_tool = importlib.import_module('m2_language')
    class_tool = importlib.import_module('m2_class_lifecycle')
    frontend_tool = importlib.import_module('m1_frontend')
    lifecycle_tool = importlib.import_module('m1_lifecycle')
    runtime_tool = importlib.import_module('m1_runtime')
    platform_tool = importlib.import_module('m1_platforms')
    data = dict(language=language_tool.check_report(directories['language']),
        classes=class_tool.check_report(directories['classes']),
        frontend=frontend_tool.check_report(directories['frontend']),
        lifecycle=lifecycle_tool.check_report(directories['lifecycle']),
        runtime=c.load(directories['runtime'] / 'report.json'),
        platforms=c.load(directories['platforms'] / 'report.json'),
        validation=c.validation_report(directories['validation']))
    native_directory = BASE / 'stage17-retention-final-07'
    c.verify_inventory(native_directory)
    native = c.load(native_directory / 'process.json')
    c.require(native['exit_code'] == 0 and native['source_stability'] and
              native['source_sha256_before'] == native['source_sha256_after'],
              'final focused native lifecycle source/execution failed')
    for channel in ['stdout', 'stderr']:
        c.identity(native_directory / (channel + '.bin'), native[channel + '_sha256'])
    for row in native['artifacts']:
        c.identity(ROOT / row['path'], row['sha256'], row['bytes'])
    import re
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                      (native_directory / 'stdout.bin').read_text())
    c.require(rows and all(int(row[1]) == 0 for row in rows), 'native lifecycle summaries missing/failed')
    data['native_lifecycle'] = native
    data['native_lifecycle_counts'] = dict(passed=sum(int(row[0]) for row in rows),
        ignored=sum(int(row[2]) for row in rows), binary_artifacts=len(native['artifacts']),
        source_stability=True, tracked_sources_bound_to_implementation=True,
        capture_helper_source_scope='Untracked capture helper retained with its own hash; excluded from Git-commit equality claim.',
        snapshot_binding_scope='All captured project Rust/Cargo/toolchain source snapshots equal the exact implementation commit; the executed test subset is reported separately.')
    language = data['language']
    c.require(language_tool.development_passes(language, directories['language']), 'selected development contract failed')
    c.require(not language_tool.subset_passes(language) and language['full_gate_failures'], 'known strict failures missing')
    c.require({r['id'] for r in language['results'] if r['status'] != 'pass'} == KNOWN, 'known selected failures changed')
    c.require(language['candidate']['source_binding'] == 'recorded-build', 'candidate lacks recorded build')
    c.require(all(r['status'] == 'pass' for r in language['metamorphic_results']), 'metamorphic failure')
    baseline = verify_baseline()
    original = c.load(BASELINE / 'sources/tests/fixtures/m2/cases.json')['cases']
    selected = c.load(directories['language'] / 'sources/tests/fixtures/m2/cases.json')['cases']
    c.require(len(original) == baseline['selected_cases'] and selected[:len(original)] == original,
              'original selected prefix definitions changed')
    c.exact_ids(language['results'], [r['id'] for r in selected], 'fresh language')
    mutable_metadata = {'tests/fixtures/m2/cases.json',
                        'compatibility/m2-class-lifecycle/manifest.json',
                        'compatibility/m2-language.json', 'compatibility/m2-mappings.json',
                        # Platform implementation changes add the selected slot scenarios.
                        # Their old source copies stay in the baseline; new copies are
                        # proven against the implementation commit, not old fixture bytes.
                        'tools/m1_platforms.py', 'tools/platform/run.mjs',
                        'tools/platform/scenarios.mjs',
                        # The broader Stage17 Git snapshot includes implementation
                        # and documentation bytes. These are intentionally mutable
                        # and must equal the final exact implementation commit.
                        'tools/m2_manifest.py', 'tools/m2_language.py',
                        'tools/m2_class_lifecycle.py', 'PLAN.md', 'TESTING.md',
                        'docs/m2-language.md'}
    for row in baseline['sources']:
        name = row['path']
        if name not in mutable_metadata:
            c.identity(ROOT / name, row['sha256'], row['bytes'])
    old_inventory = baseline_json('compatibility/m2-language.json')
    new_inventory = c.load(directories['language'] / 'sources/compatibility/m2-language.json')
    data['requirements_preservation'] = c.semantic_inventory_preservation(old_inventory, new_inventory)
    old_mappings = baseline_json('compatibility/m2-mappings.json')
    new_mappings = c.load(directories['language'] / 'sources/compatibility/m2-mappings.json')
    data['mapping_preservation'] = c.semantic_mapping_preservation(old_mappings, new_mappings)
    previous_language = json.loads(old_archive('language', ['report.json'])['report.json'])
    c.exact_ids(previous_language['results'], [r['id'] for r in original], 'original language')
    c.require(len(previous_language['metamorphic_results']) == baseline['relations'],
              'original relation denominator differs')
    old_relations = {tuple(row['case_ids']): row for row in previous_language['metamorphic_results']}
    fresh_relations = {tuple(row['case_ids']): row for row in language['metamorphic_results']}
    c.require(all(fresh_relations.get(key) == row for key, row in old_relations.items()),
              'original complete relation observations changed')
    original_rows = language['results'][:len(original)]
    c.require([(r['id'], r['status']) for r in original_rows] ==
              [(r['id'], r['status']) for r in previous_language['results']], 'original selected outcomes changed')
    # Every originally passing case retains the identical complete channels;
    # known Java failures stay nonpasses with their original archives retained.
    for row, previous in zip(original_rows, previous_language['results']):
        if previous['status'] == 'pass':
            for engine in ['java', 'rust']:
                for channel in ['stdout', 'stderr']:
                    c.require(row[engine][channel + '_sha256'] == previous[engine][channel + '_sha256'],
                              'original passing raw bytes changed: ' + row['id'])
    prior_dir = BASE / 'prior-selection-stage17-final-02'
    c.require((prior_dir / 'report.json').is_file(), 'required prior1597 replay missing')
    if (prior_dir / 'report.json').is_file():
        prior = c.load(prior_dir / 'report.json')
        c.verify_inventory(prior_dir)
        c.exact_ids(prior['results'], [r['id'] for r in original], 'prior replay')
        c.require(c.load(prior_dir / 'original-selection.json')['cases'] == original, 'prior replay definitions differ')
        candidate = c.load(prior_dir / 'candidate.json')
        c.identity(prior_dir / 'artifacts/language_probe', candidate['sha256'])
        build = candidate['build_provenance']
        artifact = build['artifacts']['language_probe']
        c.require(build['source_binding'] == 'recorded-build' and build['source_stability'] and
                  build['source_sha256_before'] == build['source_sha256_after'] and
                  build['build']['exit_code'] == 0 and build['build']['timed_out'] is False and
                  artifact['candidate_sha256'] == artifact['frozen_sha256'] == candidate['sha256'],
                  'prior candidate recorded-build provenance differs')
        baseline_metadata = c.load(prior_dir / 'baseline.json')
        c.require(baseline_metadata['report_sha256'] == hashlib.sha256(old_archive('language', ['report.json'])['report.json']).hexdigest(),
                  'prior replay Java baseline differs from sealed original')
        baseline_dir = Path(baseline_metadata['path'])
        for row, previous, case in zip(prior['results'], previous_language['results'], original):
            folder, baseline_folder = prior_dir / 'cases' / row['id'], baseline_dir / 'cases' / row['id']
            c.require(c.load(folder / 'rust.process.json') == row['rust'], 'prior process metadata differs')
            c.identity(folder / 'input.pkl', row['input_sha256'])
            c.identity(folder / 'input.pkl', previous_language['source_sha256'][case['input']])
            captures = []
            for engine, process, directory in [('java', previous['java'], baseline_folder), ('rust', row['rust'], folder)]:
                for channel in ['stdout', 'stderr']:
                    path = directory / (engine + '.' + channel + '.bin'); c.identity(path, process[channel + '_sha256']); captures.append(path.read_bytes())
            outcome_path = baseline_folder / 'java.outcome.bin'; c.identity(outcome_path, previous['java']['outcome_sha256'])
            status = language_tool.status(case, previous['java'], row['rust'], *captures, outcome_path.read_bytes())
            c.require(status == row['status'] == previous['status'], 'prior replay raw verdict changed')
        c.require(prior['status_counts'] == dict(Counter(r['status'] for r in prior['results'])), 'prior replay count differs')
        data['prior'] = prior
    classes = data['classes']
    c.require(class_tool.contract_passes(classes), 'class selected contract failed')
    manifest = c.load(directories['classes'] / 'sources/compatibility/m2-class-lifecycle/manifest.json')
    old_manifest = c.load(BASELINE / 'sources/compatibility/m2-class-lifecycle/manifest.json')
    c.require(len(old_manifest['sequences']) * previous_class_repetitions() == baseline['sequence_executions'] and
              manifest['sequences'][:len(old_manifest['sequences'])] == old_manifest['sequences'], 'original sequence prefix changed')
    c.require(classes['repetitions'] == previous_class_repetitions(), 'sequence repetitions changed')
    previous_classes = json.loads(old_archive('class-lifecycle', ['report.json'])['report.json'])
    prior_rows = classes['cases'][:len(previous_classes['cases'])]
    c.require([(r['id'], r['repetition']) for r in prior_rows] ==
              [(r['id'], r['repetition']) for r in previous_classes['cases']], 'original sequence row order changed')
    old_calls = 0
    for row, previous in zip(prior_rows, previous_classes['cases']):
        c.require(row['observations']['comparisons'] == previous['observations']['comparisons'], 'original class comparison changed')
        for engine in ['java', 'rust']:
            c.require(row['observations']['processes'][engine]['calls'] == previous['observations']['processes'][engine]['calls'],
                      'original class full raw capture identities changed')
        old_calls += len(row['observations']['comparisons'])
    c.require(old_calls == baseline['sequence_call_comparisons'], 'original class call accounting differs')
    calls = [r for row in classes['cases'] for r in row['observations']['comparisons']]
    data['class_counts'] = dict(unique_sequences=len(manifest['sequences']), sequence_executions=len(classes['cases']),
        original_sequences=len(old_manifest['sequences']), added_sequences=len(manifest['sequences']) - len(old_manifest['sequences']),
        original_call_comparisons=old_calls, added_call_comparisons=len(calls) - old_calls,
        call_comparisons=len(calls), passing_calls=sum(r['status'] == 'pass' for r in calls),
        original_definitions_order_and_raw_bytes_preserved=True)
    old_platforms = json.loads(old_archive('platforms', ['report.json'])['report.json'])
    for target in ['nodeChecks', 'browserChecks']:
        original_scenarios = old_platforms['execution'][target]
        current_scenarios = data['platforms']['execution'][target]
        c.require([name for name in current_scenarios if name in set(original_scenarios)] == original_scenarios,
                  'original platform scenarios/order were removed or changed')
    c.DIRECTORIES['platforms'] = directories['platforms']
    data['platform_audit'] = c.platform_claims(data['platforms'], platform_tool)
    c.require(data['platforms']['source_stability'] and platform_tool.contract_matches(data['platforms']['comparisons']), 'platform architecture/source-stability contract failed')
    c.require(data['platforms']['compatibility_status'] == 'fail' and data['platforms']['experiment_contract_status'] == 'pass',
              'platform known failures relabeled')
    for name, digest in data['platforms']['artifacts'].items():
        c.identity(directories['platforms'] / name, digest)
    runtime = data['runtime']
    for row in runtime['identities']:
        c.identity(Path(row.get('snapshot', row['path'])), row['sha256'], row.get('bytes'))
        if 'snapshot' in row:
            c.identity(Path(row['path']), row['sha256'], row.get('bytes'))
    c.require([r['id'] for r in runtime['cases']] == list(runtime_tool.SUCCESS_CASES + runtime_tool.ERROR_CASES), 'runtime coverage differs')
    runtime_counts = Counter()
    mismatch_ids = []
    for row in runtime['cases']:
        java, rust = c.raw_process(row['java']), c.raw_process(row['rust'])
        c.require(row['raw_equal'] == (java == rust), 'runtime equality differs from raw')
        expected = 'bounded-value-bytes-match' if row['id'] in runtime_tool.SUCCESS_CASES else (
            'diagnostic-bytes-match' if java == rust else 'diagnostic-byte-mismatch')
        c.require(row['status'] == expected, 'runtime status differs')
        if expected == 'bounded-value-bytes-match':
            c.require(java == rust and java[0] == 0 and not java[2], 'runtime value failed')
        else:
            c.require(java[0] == rust[0] == 1, 'runtime error outcomes differ')
            if java != rust:
                c.require(row['id'] == 'forcing-cycle', 'new runtime diagnostic mismatch')
                mismatch_ids.append(row['id'])
        runtime_counts[expected] += 1
    c.require(mismatch_ids == ['forcing-cycle'], 'runtime known diagnostic mismatch inventory changed')
    data['regression_counts'] = dict(frontend_raw_matches=sum(r['passed'] for r in data['frontend']['results']),
        runtime_value_matches=runtime_counts['bounded-value-bytes-match'],
        runtime_diagnostic_matches=runtime_counts['diagnostic-bytes-match'],
        runtime_diagnostic_mismatches=runtime_counts['diagnostic-byte-mismatch'],
        runtime_known_diagnostic_mismatch_ids=mismatch_ids,
        lifecycle_protocol_matches=sum(r['observations']['protocol_raw_equal'] for r in data['lifecycle']['cases']),
        lifecycle_full_diagnostic_mismatches=sum(not e['raw_equal'] for r in data['lifecycle']['cases'] for e in r['observations']['diagnostics']))
    for name, path, digest in source_rows(directories, data):
        c.identity(path, digest)
        c.identity(ROOT / name, digest)
    data['selection_counts'] = dict(selected=len(selected), original_selected=len(original), added_selected=len(selected) - len(original),
        relations=len(language['metamorphic_results']), original_definitions_preserved=True,
        original_input_bytes_preserved=True, original_passing_raw_bytes_preserved=True,
        original_known_failures_preserved_separately=True, exact_result_order=True,
        frozen_selection_sha256=c.sha(directories['language'] / 'sources/tests/fixtures/m2/cases.json'),
        baseline_metadata_sha256=c.sha(BASELINE / 'summary.json'))
    data['selection_counts']['original_inventory_rows_preserved'] = len(old_inventory['cases'])
    data['baseline_metadata'] = baseline
    verify_exploration_gap(data)
    return data


def bind_sources(commit, directories, data, destination):
    """Read exact Git blobs in batches, resolving pinned submodule gitlinks."""
    c.require(len(commit) == 40 and all(ch in '0123456789abcdef' for ch in commit), 'full implementation SHA required')
    destination.mkdir(exist_ok=False)
    git_commands = destination / 'git-commands'
    git_commands.mkdir()
    captures = []
    def run_git(arguments, repository, payload=None):
        directory = git_commands / str(len(captures))
        directory.mkdir()
        command = ['git', *arguments]
        result = subprocess.run(command, cwd=repository, input=payload, capture_output=True, timeout=60)
        row = dict(command=command, cwd=str(repository), exit_code=result.returncode)
        for channel in ['stdout', 'stderr']:
            path = directory / (channel + '.bin'); path.write_bytes(getattr(result, channel))
            row[channel + '_sha256'] = c.sha(path)
        if payload is not None:
            (directory / 'stdin.bin').write_bytes(payload)
            row['stdin_sha256'] = c.sha(directory / 'stdin.bin')
        c.write_new(directory / 'process.json', row)
        captures.append(row)
        c.require(result.returncode == 0, 'Git source proof command failed; raw captures retained')
        return result.stdout
    def git(*args, repository=ROOT):
        return run_git(args, repository)
    c.require(git('rev-parse', commit + '^{commit}').decode().strip() == commit, 'commit differs')
    c.require(c.load(BASE / 'stage17-final-source-review.json')['implementation_commit'] == commit,
              'independent source review is for another implementation commit')
    rows = list(source_rows(directories, data))
    unique = {name: path for name, path, _ in rows}
    groups = {}
    for name in unique:
        repo, spec = ROOT, commit + ':' + name
        for prefix in ['external/pkl/', 'external/pkl-pantry/']:
            if name.startswith(prefix):
                repo = ROOT / prefix.rstrip('/')
                revision = git('rev-parse', commit + ':' + prefix.rstrip('/')).decode().strip()
                spec = revision + ':' + name[len(prefix):]
        groups.setdefault(repo, []).append((name, spec))
    committed = {}
    for repo, group in groups.items():
        result = run_git(['cat-file', '--batch'], repo, ('\n'.join(spec for _, spec in group) + '\n').encode())
        position = 0
        for name, spec in group:
            end = result.index(b'\n', position)
            fields = result[position:end].split()
            c.require(len(fields) == 3 and fields[1] == b'blob', 'missing Git blob ' + spec)
            size = int(fields[2]); committed[name] = result[end + 1:end + 1 + size]
            position = end + size + 2
        c.require(position == len(result), 'unexpected Git batch payload')
    checks = []
    for name, path, digest in rows:
        payload = path.read_bytes()
        c.require(payload == committed[name] and hashlib.sha256(payload).hexdigest() == digest, 'source differs from exact commit: ' + name)
        checks.append(dict(source=name, snapshot=path.relative_to(ROOT).as_posix(), sha256=digest))
    for name, payload in committed.items():
        path = destination / 'implementation-sources' / name
        path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(payload)
    external_copies = sum(name.startswith('external/') for name, _, _ in rows)
    external_paths = sum(name.startswith('external/') for name in unique)
    result = dict(implementation_commit=commit, source_snapshot_copies=len(rows), unique_source_files=len(unique),
        matched_exact_git_commit=True, pinned_submodule_blobs=external_copies > 0,
        upstream_source_blobs_verified=external_copies > 0,
        external_source_snapshot_copies=external_copies, unique_external_source_files=external_paths,
        source_checks=checks,
        source_reports={name: dict(path=str(path / 'report.json'), sha256=c.sha(path / 'report.json')) for name, path in directories.items()},
        method='Every final source snapshot enumerated in source_checks equals exact implementation Git bytes. Any captured upstream bytes resolve through the implementation commit gitlinks. Upstream blob proof exists only when external_source_snapshot_copies is positive. Reference pin validation remains separate.',
        captured_binaries_executed=False, git_command_captures=len(captures),
        source_binding_scope='Final language, class sequences, M1 frontend/runtime/lifecycle, platforms, prior-selection replay, and focused native lifecycle Rust/Cargo source copies enumerated below. Historical exploratory and superseded focused native lifecycle source copies are outside this current-commit equality claim. Final focused native lifecycle project Rust/Cargo/toolchain source snapshots are included; its untracked capture helper has separate identity.',
        validation_source_binding='Validation archive preserves raw command captures only; it does not add acquisition-time source snapshots. Other final suites retain full source snapshots.')
    c.write_new(destination / 'source-verification.json', result)
    for name in ['package_stage17_final.py', 'stage17_package_common.py']:
        shutil.copyfile(BASE / name, destination / name)
    for name in ['stage16-const-retry-gap.json', 'stage17-node-ownership-review-07.json',
                 'stage17-final-source-review.json', 'stage17-runtime-final-review.json',
                 'stage17-type-node-design-draft.md',
                 'stage17_partial_readiness.py', 'stage17-partial-readiness.json',
                 'stage17_retention_run.py', 'stage17-platform-final-audit-02.json',
                 'stage17_review_fixture_delta.py', 'stage17-fixture-delta-review.json',
                 'stage17-drafts-and-review.json', 'stage17-readme-review.json']:
        if (BASE / name).is_file():
            shutil.copyfile(BASE / name, destination / name)
    command_dirs = ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle', 'class-lifecycle', 'prior-selection', 'stage17-partial-readiness']
    for name in command_dirs:
        source = BASE / (name + '-command-final-04' if name == 'stage17-partial-readiness' else name + '-stage17-command-final-02')
        if not source.is_dir():
            continue
        for process_path in source.glob('*process.json'):
            row = c.load(process_path)
            c.require(row['exit_code'] == 0 and row.get('timed_out') is False, 'final acquisition command failed')
            prefix = process_path.name.removesuffix('process.json')
            for channel in ['stdout', 'stderr']:
                c.identity(source / (prefix + channel + '.bin'), row[channel + '_sha256'])
        shutil.copytree(source, destination / 'commands' / name)
    retain_baseline_git_proof(destination / 'baseline-git-metadata')
    for name in ['stage17-source-partial-proof-01', 'stage17-source-partial-proof-command-final']:
        if (BASE / name).is_dir():
            shutil.copytree(BASE / name, destination / 'independent-preseal' / name)
    for source in sorted(BASE.glob('package-stage17-command-*')):
        if source.is_dir() and (source / 'process.json').is_file():
            shutil.copytree(source, destination / 'helper-history' / source.name)
    c.write_new(destination / 'requirements-preservation.json', data['requirements_preservation'])
    c.write_new(destination / 'mapping-preservation.json', data['mapping_preservation'])
    c.write_new(destination / 'packaging-invocation.json', dict(command=[sys.executable, *sys.argv], cwd=str(ROOT),
        implementation_commit=commit, helper_sha256={name:c.sha(BASE / name) for name in ['package_stage17_final.py','stage17_package_common.py']},
        scope='Current sealing invocation; wrapper stdout/stderr/process record is retained separately after this process exits.'))
    return result


def archive(source, name):
    path = REPORTS / (name + '-stage17-final-evidence.tar.gz')
    c.require(not path.exists(), 'refusing existing archive')
    sys.path.insert(0, str(ROOT / 'tools'))
    import evidence
    # create() verifies the completed archive once; no redundant verification.
    evidence.create(source, path, ['build/*', '__pycache__/*', '*/__pycache__/*'])
    with tarfile.open(path) as stream:
        count = len(stream.getmembers())
    return dict(path=path.relative_to(ROOT).as_posix(), sha256=c.sha(path), bytes=path.stat().st_size,
                files_including_inventory=count, inventory_verified=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-ready', action='store_true')
    parser.add_argument('--commit')
    for name in ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle', 'classes']:
        parser.add_argument('--' + name, type=Path, default=BASE / (('class-lifecycle' if name == 'classes' else name) + '-stage17-final-02'))
    args = parser.parse_args()
    directories = {name: getattr(args, name).resolve() for name in ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle', 'classes']}
    data = inspect(directories)
    claims = dict(status='pass', captured_binaries_executed=False,
        field_scope='Read-only packaging audit only; acquisition commands executed their retained evaluator artifacts.',
        selection=data['selection_counts'],
        class_sequences=data['class_counts'], platforms=data['platform_audit'], regressions=data['regression_counts'],
        requirements=data['requirements_preservation'], mappings=data['mapping_preservation'],
        const_retry_gap=data['const_retry_gap'])
    if args.check_ready:
        print(json.dumps(dict(claims, validation={k: data['validation'][k] for k in ['rust_passed','rust_intentionally_ignored','python_passed']}), sort_keys=True)); return
    c.require(args.commit, '--commit is required to seal exact implementation evidence')
    names = ['language', 'validation', 'platforms', 'gates', 'regressions', 'class-lifecycle', 'source']
    outputs = [REPORTS / (name + '-stage17-final-evidence.tar.gz') for name in names]
    outputs += [REPORTS / 'stage17-final-summary.json', REPORTS / 'validation-stage17-final.json']
    generated = {name: BASE / (name + '-stage17-final-evidence') for name in ['gates', 'regressions', 'source']}
    c.require(not any(p.exists() for p in [*outputs, *generated.values()]), 'refusing existing final output')
    binding = bind_sources(args.commit, directories, data, generated['source'])
    gates = []
    generated['gates'].mkdir()
    for name, expected in [('report', 0), ('development', 0), ('subset', 1), ('full', 1)]:
        command = [sys.executable, 'tools/m2_language.py', '--verify-' + name, str(directories['language'])]
        process = subprocess.run(command, cwd=ROOT, capture_output=True, timeout=120)
        row = dict(gate=name, command=command, exit_code=process.returncode, expected_exit_code=expected)
        for channel in ['stdout', 'stderr']:
            path = generated['gates'] / (name + '.' + channel + '.bin'); path.write_bytes(getattr(process, channel))
            row[channel + '_sha256'] = c.sha(path)
        gates.append(row); c.require(process.returncode == expected, 'unexpected raw gate status: ' + name)
    c.write_new(generated['gates'] / 'report.json', dict(scope='Integrity/development pass; strict selected/full failures preserved.', rows=gates))
    generated['regressions'].mkdir()
    for name in ['frontend', 'runtime', 'lifecycle']:
        shutil.copytree(directories[name], generated['regressions'] / name, ignore=shutil.ignore_patterns('build', '__pycache__'))
    if 'prior' in data:
        shutil.copytree(BASE / 'prior-selection-stage17-final-02', generated['regressions'] / 'prior', ignore=shutil.ignore_patterns('build', '__pycache__'))
    if (BASE / 'stage17-exploration-summary-final.json').is_file():
        shutil.copyfile(BASE / 'stage17-exploration-summary-final.json', generated['regressions'] / 'stage17-exploration-summary-final.json')
    for name in ['stage17_review_fixture_delta.py', 'stage17-fixture-delta-review.json']:
        if (BASE / name).is_file():
            shutil.copyfile(BASE / name, generated['regressions'] / name)
    shutil.copytree(BASELINE, generated['regressions'] / 'immutable-stage17-baseline')
    retain_baseline_git_proof(generated['regressions'] / 'baseline-git-metadata')
    for name in ['stage16-const-retry-gap.json', 'stage17-node-ownership-review-07.json',
                 'stage17-final-source-review.json', 'stage17-runtime-final-review.json']:
        if (BASE / name).is_file():
            shutil.copyfile(BASE / name, generated['regressions'] / name)
    if (BASE / 'stage17-retention-final-07').is_dir():
        shutil.copytree(BASE / 'stage17-retention-final-07',
                        generated['regressions'] / 'native-type-node-lifecycle-final')
    c.write_new(generated['regressions'] / 'requirements-preservation.json', data['requirements_preservation'])
    c.write_new(generated['regressions'] / 'mapping-preservation.json', data['mapping_preservation'])
    c.write_new(generated['regressions'] / 'raw-claims-audit.json', claims)
    sources = dict(language=directories['language'], validation=directories['validation'], platforms=directories['platforms'],
                   **{'class-lifecycle':directories['classes']}, **generated)
    archives = {name: archive(sources[name], name) for name in names}
    language, platforms = data['language'], data['platforms']
    summary = dict(schema_version=1, implementation_commit=args.commit,
        scope='Stage17 evaluator-local executable/type-use ownership and persistent non-generic local const-property retry caches, including recursive depth, inline/lambda separation, shared let roots, lazy collection casts, and inherited declarations; local macOS native/Wasm/Node/browser evidence. Recursive generic instantiation, full runtime type-resolution/M2/API, performance, and release platform requirements remain open.',
        full_m2_complete=False, remote_ci_required=False, captured_binaries_executed_by_packaging=False,
        field_scope='Packaging/read-only audit only. The retained acquisition commands executed their evaluator artifacts.',
        unavailable_platform_execution=['Linux', 'Windows'],
        source_to_commit_binding='Every core-suite final source copy enumerated in source-verification.json equals exact implementation Git bytes. Historical exploratory and superseded focused native lifecycle source copies retain separate provenance; final focused lifecycle Rust/Cargo snapshots are included in the exact-commit check. Build identities and retained raw outcomes remain separate evidence.',
        implementation_source_verification={k:v for k,v in binding.items() if k not in ['source_checks', 'source_reports']},
        language={k:language[k] for k in ['selected_count','status_counts','source_stability','artifact_stability','candidate','inventory_counts']},
        class_lifecycle=dict(data['class_counts'], compatibility_complete=False, unexecuted_groups=data['classes']['unexecuted_groups'], evidence=archives['class-lifecycle']),
        platforms={k:platforms[k] for k in ['total','oracle_passed','shared_engine_passed','compatibility_status','known_gaps','experiment_contract_status','source_stability']},
        regressions=data['regression_counts'], validation={k:data['validation'][k] for k in ['rust_passed','rust_intentionally_ignored','python_passed']},
        final_claims_audit=claims, gates=gates, archives=archives, source_report_identities=binding['source_reports'],
        reviewed_mappings=dict(count=len(c.load(ROOT / 'compatibility/m2-mappings.json')['requirements']), scope='Partial reviewed mappings; strict full failures retained.'),
        original_evidence_preserved=dict(stage16_summary='reports/m2/stage16-final-summary.json',
            source_provenance_scope='Original Stage16 archives and reports remain unchanged.',
            immutable_stage17_baseline_from_exact_git_blobs=True, no_original_archive_modified=True))
    summary['implementation_source_verification']['evidence'] = archives['source']
    summary['language'].update(data['selection_counts'], source_snapshot_count=len(language['source_sha256']),
        metamorphic_relations=len(language['metamorphic_results']), metamorphic_statuses=[r['status'] for r in language['metamorphic_results']],
        full_gate_failure_reasons=len(language['full_gate_failures']),
        known_failures=[dict(id=r['id'], status=r['status']) for r in language['results'] if r['status'] != 'pass'])
    summary['platforms'].update(node_scenarios=len(platforms['execution']['nodeChecks']), browser_scenarios=len(platforms['execution']['browserChecks']))
    if 'prior' in data:
        summary['prior_selection_replay'] = dict(count=len(data['prior']['results']), status_counts=data['prior']['status_counts'],
            exact_original_ids_order_input_bytes_and_raw_verdicts=True,
            scope='Postfreeze Stage17 recorded-build candidate against retained original1597 complete Stage16 Java bytes. Fresh full Java acquisition remains separate.')
    summary['native_type_node_lifecycle'] = data['native_lifecycle_counts']
    summary['exploration'] = data['exploration']
    summary['type_node_ownership_scope'] = data['const_retry_gap']
    summary['requirements_preservation'] = data['requirements_preservation']
    summary['mapping_preservation'] = data['mapping_preservation']
    summary['independent_source_review'] = dict(path='stage17-final-source-review.json',
        sha256=c.sha(BASE / 'stage17-final-source-review.json'), retained_in=['source', 'regressions'],
        scope='Independent final implementation source review; compatibility results remain separate raw evidence.')
    node_review = BASE / 'stage17-node-ownership-review-07.json'
    c.require(c.load(node_review)['implementation_commit'] == args.commit,
              'node ownership review is for another implementation')
    summary['node_ownership_review'] = dict(path=node_review.name, sha256=c.sha(node_review),
        retained_in=['source', 'regressions'],
        scope='Independent ownership/GC/Host review bound to the exact implementation; focused native execution and raw Java results remain separately identified.')
    if (BASE / 'stage17-runtime-final-review.json').is_file():
        summary['runtime_source_review'] = dict(path='stage17-runtime-final-review.json',
            sha256=c.sha(BASE / 'stage17-runtime-final-review.json'), retained_in=['source', 'regressions'])
    if (BASE / 'stage17-type-node-design-draft.md').is_file():
        summary['initial_design'] = dict(path='stage17-type-node-design-draft.md',
            sha256=c.sha(BASE / 'stage17-type-node-design-draft.md'), retained_in=['source'],
            scope='Preserved preimplementation planning proposal; later implementation and final execution evidence are separate. This draft is not a current-commit source equality claim.')
    summary['unselected_exploratory_mismatches'] = dict(
        single_observations=data['exploration']['summary']['final_discovery_replay'],
        persistent_observations=data['exploration']['summary']['persistent_exploration'],
        required_scope_remains_open=True)
    if (BASE / 'stage17-fixture-delta-review.json').is_file():
        summary['fixture_delta_review'] = dict(report='stage17-fixture-delta-review.json',
            sha256=c.sha(BASE / 'stage17-fixture-delta-review.json'),
            scope='Independent acquisition-owner review retained separately in final regression/source archives; original exploration archive unchanged.')
    c.write_new(REPORTS / 'validation-stage17-final.json', data['validation'])
    c.write_new(REPORTS / 'stage17-final-summary.json', summary)
    print(json.dumps(dict(summary='reports/m2/stage17-final-summary.json', language=language['status_counts'],
        validation=summary['validation'], class_counts=data['class_counts'], source_copies=binding['source_snapshot_copies'],
        source_paths=binding['unique_source_files'], archives=archives), sort_keys=True))


if __name__ == '__main__':
    main()
