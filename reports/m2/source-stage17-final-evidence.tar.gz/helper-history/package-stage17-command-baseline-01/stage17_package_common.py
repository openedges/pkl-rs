"""Read-only Stage17 packaging primitives, reused from retained Stage16 helper."""
import json, hashlib, re
from pathlib import Path
ROOT = Path.cwd()
DIRECTORIES = {}
KNOWN_REGEX = {"regex-unicode-15-vs-16", "regex-zero-width-supplementary"}

def load(path):
    return json.loads(path.read_bytes())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')

def identity(path, expected, size=None):
    if sha(path) != expected or (size is not None and path.stat().st_size != size):
        raise ValueError('Evidence identity differs: ' + str(path))

def source_map(directory, mapping):
    for name, digest in mapping.items():
        identity(directory / 'sources' / name, digest)
        identity(ROOT / name, digest)

def require(condition, message):
    if not condition:
        raise ValueError(message)

def exact_ids(rows, expected, label):
    actual = [row['id'] for row in rows]
    require(actual and len(actual) == len(set(actual)), label + ': empty or duplicate IDs')
    require(actual == expected, label + ': missing, unexpected, or reordered IDs')

def platform_claims(platforms, platform_tool):
    directory = DIRECTORIES['platforms']
    execution = load(directory / 'execution/execution.json')
    node = load(directory / 'execution/node-checks.json')
    browser = load(directory / 'execution/browser-checks.json')
    require(platforms['execution'] == execution, 'Platform execution differs from retained execution.json')
    require(execution['nodeChecks'] == node, 'Node checks differ from retained scenario list')
    require(execution['browserChecks'] == browser, 'Browser checks differ from retained scenario list')
    platform_tool.check_scenarios(execution)
    captures = {name: (directory / relative).read_bytes() for name, relative in [
        ('java', 'oracle-native/java.stdout.bin'), ('rust', 'oracle-native/rust.stdout.bin'),
        ('node', 'execution/node.stdout.bin'), ('browser', 'execution/browser.stdout.bin')]}
    rows = platform_tool.compare(platform_tool.generate_cases()['cases'], captures)
    require(rows == platforms['comparisons'], 'Platform comparisons disagree with raw captures')
    counts = dict(total=len(rows), shared_engine_passed=sum(row['shared_engine_match'] for row in rows),
                  oracle_passed={target: sum(row['oracle_matches'][target] for row in rows)
                                 for target in ['rust', 'node', 'browser']})
    for key, value in counts.items():
        require(platforms[key] == value, 'Platform exported raw count differs: ' + key)
    require(execution['total'] == counts['total'], 'Platform execution denominator differs')
    require(set(platforms['known_gaps']) == KNOWN_REGEX, 'Platform known regex gaps changed')
    return dict(counts, node_scenarios=len(node), browser_scenarios=len(browser),
                report_execution_equals_retained=True, scenario_lists_equal_retained=True,
                comparisons_recomputed_from_raw=True,
                oracle_mismatch_ids={target: [row['id'] for row in rows if not row['oracle_matches'][target]]
                                     for target in ['rust', 'node', 'browser']})

def raw_process(process):
    if process['status'] != 'executed':
        raise ValueError('Process was not executed: ' + repr(process['command']))
    values = []
    for name in ['stdout', 'stderr']:
        row = process[name]
        path = Path(row['path'])
        identity(path, row['sha256'], row['bytes'])
        values.append(path.read_bytes())
    return process['exit_code'], *values

def validation_report(directory):
    report = load(directory / 'report.json')
    required = [
        ['cargo', 'xtask', 'verify'], ['cargo', 'fmt', '--all', '--', '--check'],
        ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings'],
        ['cargo', 'test', '--workspace', '--locked'],
        ['cargo', 'check', '-p', 'pkl-runtime', '--target', 'wasm32-unknown-unknown', '--locked'],
    ]
    if [r['command'] for r in report['checks'][:5]] != required:
        raise ValueError('Required Rust verification command inventory differs')
    rust_output = python_output = None
    for index, row in enumerate(report['checks']):
        if row['exit_code'] != 0:
            raise ValueError('Required verification failed: ' + repr(row['command']))
        captures = {}
        for channel in ['stdout', 'stderr']:
            path = directory / f'{index}.{channel}.bin'
            identity(path, row[channel + '_sha256'])
            captures[channel] = path.read_bytes().decode()
        if row['command'] == required[3]:
            rust_output = captures['stdout'] + captures['stderr']
        if row['command'][1:] == ['-m', 'unittest', 'discover', '-s', 'tools/tests', '-v']:
            python_output = captures['stdout'] + captures['stderr']
    if len(report['checks']) != 7 or report['checks'][6]['command'][1:] != ['tools/m2_manifest.py', '--check']:
        raise ValueError('Python/inventory verification command inventory differs')
    rust_rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', rust_output or '')
    python_rows = re.findall(r'Ran (\d+) tests? in ', python_output or '')
    if not rust_rows or len(python_rows) != 1 or not re.search(r'\nOK\s*$', python_output or ''):
        raise ValueError('Missing successful raw Rust/Python test summaries')
    counts = dict(rust_passed=sum(int(row[0]) for row in rust_rows),
                  rust_intentionally_ignored=sum(int(row[2]) for row in rust_rows),
                  python_passed=int(python_rows[0]))
    if any(int(row[1]) for row in rust_rows) or not counts['rust_passed'] or not counts['python_passed']:
        raise ValueError('Failed or empty verification summaries')
    return dict(report, **counts, evidence_sha256={str(p.relative_to(directory)): sha(p)
                for p in sorted(directory.rglob('*')) if p.is_file()})


def verify_inventory(directory, name='evidence-sha256.json'):
    """Check exact closure, including nested inventories and retained history."""
    inventory_path = directory / name
    inventory = load(inventory_path)
    observed = {path.relative_to(directory).as_posix() for path in directory.rglob('*')
                if path.is_file() and path != inventory_path}
    require(set(inventory) == observed, 'evidence inventory closure differs: ' + str(directory))
    for relative, digest in inventory.items():
        path = Path(relative)
        require(not path.is_absolute() and '..' not in path.parts,
                'unsafe inventory path: ' + relative)
        require(not (directory / path).is_symlink(), 'inventory contains symlink: ' + relative)
        identity(directory / path, digest)
    return inventory



def remaining_preservation(original, current, requirement):
    """Retain open clauses; allow only the reviewed Stage17 compression closeout."""
    position = 0
    updates = []
    for text in original:
        if text in current[position:]:
            position = current.index(text, position) + 1
            continue
        require(requirement == 'semantic:diagnostics' and
                text.startswith('Recursive frame compression, '),
                'remaining scope removed: ' + requirement)
        clauses = ['general imported source stacks', 'first-error combinations',
                   'complete parser/resolver/runtime diagnostic corpus', 'remain open',
                   'Colored output', 'selected uncolored recursive compression is covered']
        matches = [(index, value) for index, value in enumerate(current[position:], position)
                   if all(clause in value for clause in clauses)]
        require(len(matches) == 1, 'diagnostic remaining scope was relaxed beyond selected compression')
        index, replacement = matches[0]
        position = index + 1
        updates.append(dict(requirement=requirement, original=text, current=replacement,
            resolved_scope='Selected uncolored recursive frame compression only; colored/general diagnostic requirements remain open.',
            evidence='Stage17 selected raw Java frame-compression witnesses and persistent sequence comparisons.'))
    return updates

def semantic_inventory_preservation(original, current):
    """Allow new links/source hashes while retaining actual required scope."""
    for field in ['schema_version', 'baseline', 'comparison_boundary', 'completion']:
        require(original[field] == current[field], 'inventory contract changed: ' + field)
    old_requirements, new_requirements = original['requirements'], current['requirements']
    require([r['id'] for r in old_requirements] == [r['id'] for r in new_requirements],
            'original requirement IDs/order changed')
    remaining_updates = []
    for old, new in zip(old_requirements, new_requirements):
        ignored = {'implementation', 'tests', 'reviewed_mapping'}
        if 'reviewed_mapping' not in old and 'reviewed_mapping' in new:
            # The generator replaces the explanatory reason when a partial
            # requirement gains its first reviewed source/test mapping.
            ignored.add('reason')
        require({k: v for k, v in old.items() if k not in ignored} ==
                {k: v for k, v in new.items() if k not in ignored},
                'original requirement definition changed: ' + old['id'])
        require(old['implementation']['state'] == new['implementation']['state'],
                'implementation state changed: ' + old['id'])
        old_links = {(r['path'], r['symbol']) for r in old['implementation']['links']}
        new_links = {(r['path'], r['symbol']) for r in new['implementation']['links']}
        require(old_links <= new_links, 'old implementation link removed: ' + old['id'])
        require(old['tests']['state'] == new['tests']['state'] and
                set(old['tests']['case_ids']) <= set(new['tests']['case_ids']),
                'old test links/state changed: ' + old['id'])
        if 'reviewed_mapping' in old:
            require(old['reviewed_mapping']['source'] == new['reviewed_mapping']['source'],
                    'reviewed mapping source changed: ' + old['id'])
            remaining_updates.extend(remaining_preservation(old['reviewed_mapping']['remaining'],
                new['reviewed_mapping']['remaining'], old['id']))
    old_ids = {r['id'] for r in original['cases']}
    require([r for r in current['cases'] if r['id'] in old_ids] == original['cases'],
            'old inventory case objects/order changed')
    return dict(original_requirements=len(old_requirements), original_inventory_cases=len(old_ids),
                ids_order_definitions_states_and_existing_links_preserved=True,
                open_scope_preserved_except_verified_recursive_compression=True,
                reviewed_remaining_updates=remaining_updates,
                allowed_updates='Regenerated source/implementation hashes and additive implementation/test links reflect new verified work.')


def semantic_mapping_preservation(original, current):
    old_rows, new_rows = original['requirements'], current['requirements']
    old_ids = {r['requirement'] for r in old_rows}
    preserved = [r for r in new_rows if r['requirement'] in old_ids]
    require(len(new_rows) == len({r['requirement'] for r in new_rows}) and
            [r['requirement'] for r in old_rows] == [r['requirement'] for r in preserved],
            'reviewed mapping original IDs/order changed')
    remaining_updates = []
    for old, new in zip(old_rows, preserved):
        require(old['implementation']['state'] == new['implementation']['state'] and
                old['tests']['state'] == new['tests']['state'],
                'partial mapping states changed: ' + old['requirement'])
        remaining_updates.extend(remaining_preservation(old['remaining'], new['remaining'], old['requirement']))
        require({(r['path'], r['symbol']) for r in old['implementation']['links']} <=
                {(r['path'], r['symbol']) for r in new['implementation']['links']},
                'old mapping implementation link removed')
        require(set(old['tests']['case_ids']) <= set(new['tests']['case_ids']),
                'old mapping test links removed')
    return dict(original_partial_mappings=len(old_rows), current_partial_mappings=len(new_rows),
                added_partial_mappings=len(new_rows) - len(old_rows),
                states_and_existing_links_preserved=True,
                open_scope_preserved_except_verified_recursive_compression=True,
                reviewed_remaining_updates=remaining_updates)
