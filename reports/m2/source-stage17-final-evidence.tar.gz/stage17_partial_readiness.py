"""Audit completed Stage17 final suites before the fresh full language run finishes."""
from pathlib import Path
from collections import Counter
import sys,json,hashlib,subprocess,re,datetime
sys.dont_write_bytecode=True
sys.path[:0]=['target/m2','tools']
import package_stage17_final as p,stage17_package_common as c
import m1_frontend,m1_lifecycle,m1_platforms,m1_runtime,m2_class_lifecycle,m2_language
ROOT=Path.cwd();BASE=ROOT/'target/m2';commit=sys.argv[1];out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
dirs={name:BASE/(({'classes':'class-lifecycle'}.get(name,name))+'-stage17-final-02')for name in ['validation','frontend','runtime','lifecycle','classes','platforms']}
for helper in ['package_stage17_final.py','stage17_package_common.py','stage17_partial_readiness.py']:
 (out/helper).write_bytes((BASE/helper).read_bytes())
baseline=p.verify_baseline();data=dict(frontend=m1_frontend.check_report(dirs['frontend']),lifecycle=m1_lifecycle.check_report(dirs['lifecycle']),classes=m2_class_lifecycle.check_report(dirs['classes']),platforms=c.load(dirs['platforms']/'report.json'),runtime=c.load(dirs['runtime']/'report.json'))
validation=c.validation_report(dirs['validation']);c.require(m2_class_lifecycle.contract_passes(data['classes']),'persistent contract failed')
original=c.load(p.BASELINE/'sources/tests/fixtures/m2/cases.json')['cases'];selected=c.load(ROOT/'tests/fixtures/m2/cases.json')['cases'];c.require(selected[:len(original)]==original,'original selection prefix changed')
requirements=c.semantic_inventory_preservation(c.load(p.BASELINE/'sources/compatibility/m2-language.json'),c.load(ROOT/'compatibility/m2-language.json'))
mappings=c.semantic_mapping_preservation(c.load(p.BASELINE/'sources/compatibility/m2-mappings.json'),c.load(ROOT/'compatibility/m2-mappings.json'))
native_dir=BASE/'stage17-retention-final-07';c.verify_inventory(native_dir);native=c.load(native_dir/'process.json');c.require(native['exit_code']==0 and native['source_stability']and native['source_sha256_before']==native['source_sha256_after'],'focused native lifecycle failed/unstable');data['native_lifecycle']=native
for channel in ['stdout','stderr']:c.identity(native_dir/(channel+'.bin'),native[channel+'_sha256'])
for row in native['artifacts']:c.identity(ROOT/row['path'],row['sha256'],row['bytes'])
c.DIRECTORIES['platforms']=dirs['platforms'];platform=c.platform_claims(data['platforms'],m1_platforms);c.require(data['platforms']['source_stability']and m1_platforms.contract_matches(data['platforms']['comparisons']),'platform contract failed')
for name,digest in data['platforms']['artifacts'].items():c.identity(dirs['platforms']/name,digest)
previous_platform=json.loads(p.old_archive('platforms',['report.json'])['report.json'])
for target in ['nodeChecks','browserChecks']:c.require([name for name in data['platforms']['execution'][target]if name in previous_platform['execution'][target]]==previous_platform['execution'][target],'original platform order changed')
previous_classes=json.loads(p.old_archive('class-lifecycle',['report.json'])['report.json']);classes=data['classes'];old_manifest=c.load(p.BASELINE/'sources/compatibility/m2-class-lifecycle/manifest.json');new_manifest=c.load(dirs['classes']/'sources/compatibility/m2-class-lifecycle/manifest.json');c.require(new_manifest['sequences'][:len(old_manifest['sequences'])]==old_manifest['sequences'],'old persistent definitions changed');c.require(classes['repetitions']==previous_classes['repetitions'],'persistent repetitions changed')
for old,new in zip(previous_classes['cases'],classes['cases']):
 c.require((old['id'],old['repetition'])==(new['id'],new['repetition'])and old['observations']['comparisons']==new['observations']['comparisons'],'old persistent observation changed')
 for engine in ['java','rust']:c.require(old['observations']['processes'][engine]['calls']==new['observations']['processes'][engine]['calls'],'old persistent raw bytes changed')
previous_language=json.loads(p.old_archive('language',['report.json'])['report.json']);prior_dir=BASE/'prior-selection-stage17-final-02';c.verify_inventory(prior_dir);prior=c.load(prior_dir/'report.json');data['prior']=prior;c.exact_ids(prior['results'],[row['id']for row in original],'prior result order');c.require(c.load(prior_dir/'original-selection.json')['cases']==original,'prior definitions changed');candidate=c.load(prior_dir/'candidate.json');c.identity(prior_dir/'artifacts/language_probe',candidate['sha256']);build=candidate['build_provenance'];c.require(build['source_binding']=='recorded-build'and build['source_stability']and build['source_sha256_before']==build['source_sha256_after']and build['build']['exit_code']==0 and not build['build']['timed_out'],'prior recorded build invalid');prior_baseline=c.load(prior_dir/'baseline.json');c.require(prior_baseline['report_sha256']==hashlib.sha256(p.old_archive('language',['report.json'])['report.json']).hexdigest(),'prior Java baseline changed');baseline_dir=Path(prior_baseline['path'])
for row,old,case in zip(prior['results'],previous_language['results'],original):
 folder=prior_dir/'cases'/row['id'];java_folder=baseline_dir/'cases'/row['id'];c.require(c.load(folder/'rust.process.json')==row['rust'],'prior process differs');c.identity(folder/'input.pkl',old['java'].get('input_sha256',previous_language['source_sha256'][case['input']]));channels=[]
 for engine,process,directory in [('java',old['java'],java_folder),('rust',row['rust'],folder)]:
  for channel in ['stdout','stderr']:
   path=directory/(engine+'.'+channel+'.bin');c.identity(path,process[channel+'_sha256']);channels.append(path.read_bytes())
 outcome=java_folder/'java.outcome.bin';c.identity(outcome,old['java']['outcome_sha256']);status=m2_language.status(case,old['java'],row['rust'],*channels,outcome.read_bytes());c.require(status==row['status']==old['status'],'prior raw verdict changed')
c.require(prior['status_counts']==dict(Counter(row['status']for row in prior['results'])),'prior exported counts differ')
runtime_counts=Counter()
for row in data['runtime']['identities']:c.identity(Path(row.get('snapshot',row['path'])),row['sha256'],row.get('bytes'))
c.require([r['id']for r in data['runtime']['cases']]==list(m1_runtime.SUCCESS_CASES+m1_runtime.ERROR_CASES),'M1 runtime coverage changed')
for row in data['runtime']['cases']:
 java,rust=c.raw_process(row['java']),c.raw_process(row['rust']);c.require(row['raw_equal']==(java==rust),'runtime raw equality differs');expected='bounded-value-bytes-match'if row['id']in m1_runtime.SUCCESS_CASES else('diagnostic-bytes-match'if java==rust else'diagnostic-byte-mismatch');c.require(row['status']==expected,'runtime status differs');c.require(expected!='diagnostic-byte-mismatch'or row['id']=='forcing-cycle','new runtime mismatch');runtime_counts[expected]+=1
rows=list(p.source_rows(dirs,data));names=sorted({name for name,_,_ in rows});c.require(not any(name.startswith('external/')for name in names),'partial proof needs explicit submodule handling');stdin=('\n'.join(commit+':'+name for name in names)+'\n').encode();command=['git','cat-file','--batch'];result=subprocess.run(command,input=stdin,capture_output=True);(out/'git.stdin.bin').write_bytes(stdin);(out/'git.stdout.bin').write_bytes(result.stdout);(out/'git.stderr.bin').write_bytes(result.stderr);c.require(result.returncode==0,'Git source proof failed');position=0;committed={}
for name in names:
 end=result.stdout.index(b'\n',position);fields=result.stdout[position:end].split();c.require(len(fields)==3 and fields[1]==b'blob','missing Git blob '+name);size=int(fields[2]);committed[name]=result.stdout[end+1:end+1+size];position=end+size+2
c.require(position==len(result.stdout),'unexpected Git payload')
for name,path,digest in rows:c.identity(path,digest);c.identity(ROOT/name,digest);c.require(path.read_bytes()==committed[name],'snapshot differs from exact commit: '+name)
report=dict(status='pass',implementation_commit=commit,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Completed final suites only. Fresh full-language Java acquisition is still running and is not marked passed by this partial audit.',baseline={k:baseline[k]for k in ['head','source_count','selected_cases','relations','sequence_executions','sequence_call_comparisons']},selection=dict(original=len(original),selected=len(selected)),validation={k:validation[k]for k in ['rust_passed','rust_intentionally_ignored','python_passed']},platforms=platform,persistent=dict(unique_sequences=len(new_manifest['sequences']),executions=len(classes['cases']),calls=sum(len(row['observations']['comparisons'])for row in classes['cases']),original_raw_calls=sum(len(row['observations']['comparisons'])for row in previous_classes['cases'])),native=dict(passed=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;', (native_dir/'stdout.bin').read_text()))),source_stability=True,artifacts=len(native['artifacts'])),prior=dict(count=len(prior['results']),status_counts=prior['status_counts']),runtime=dict(runtime_counts),source_proof=dict(copies=len(rows),unique_paths=len(names),matched_exact_commit=True,upstream_source_snapshot_copies=0,upstream_blob_proof_claimed=False),requirements=requirements,mappings=mappings)
c.write_new(out/'report.json',report);print(json.dumps(report,sort_keys=True))
