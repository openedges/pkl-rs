from pathlib import Path, PurePosixPath
import json,hashlib,tarfile,subprocess,datetime
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
def filehash(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def safe(n):
 p=PurePosixPath(n);return n and not p.is_absolute() and all(x not in {'','..','.'} for x in n.split('/')) and '\\' not in n and not n.startswith('~')
def archive_audit(kind,pub,manifestname):
 p=ROOT/f'reports/m2/stage54-{kind}-evidence.tar.gz';report=json.loads((ROOT/'target/m2'/pub/'report.json').read_bytes())
 actual={};manifest=None;manifestbytes=None
 with tarfile.open(p,'r|gz') as t:
  for m in t:
   assert safe(m.name),(p,m.name);assert m.isfile(),(p,m.name,m.type);assert m.name not in actual,(p,m.name)
   h=hashlib.sha256();size=0;content=[] if m.name==manifestname else None
   with t.extractfile(m) as f:
    for b in iter(lambda:f.read(1048576),b''):
     size+=len(b);h.update(b)
     if content is not None:content.append(b)
   assert size==m.size
   actual[m.name]={'sha256':h.hexdigest(),'bytes':size}
   if content is not None:manifestbytes=b''.join(content);manifest=json.loads(manifestbytes)
 assert manifest is not None
 files=manifest['files'];assert actual[manifestname]['sha256']==sha(manifestbytes)
 assert set(actual)==set(files)|{manifestname},(kind,'coverage',set(actual)-set(files)-{manifestname},set(files)-set(actual))
 assert {k:v for k,v in actual.items() if k!=manifestname}==files,(kind,'bytes')
 expected_archive=report.get('sha256',report.get('archive_sha256'));assert filehash(p)==expected_archive
 assert p.stat().st_size==report.get('bytes',report.get('archive_bytes'))
 assert sha(manifestbytes)==report['manifest_sha256']
 assert len(files)==report.get('payload_files',report.get('payload_members'))
 local_compared=0;unmapped=[];mismatch=[]
 for name,v in files.items():
  if kind=='java-history':
   local=ROOT/name.removeprefix('evidence/') if name.startswith('evidence/') else ROOT/'target/m2'/pub/name
  elif name.startswith('verification-tools/'):local=ROOT/'target/m2'/pub/name
  else:local=ROOT/'target/m2'/name
  if not local.is_file():unmapped.append(name);continue
  local_compared+=1
  if local.stat().st_size!=v['bytes'] or filehash(local)!=v['sha256']:mismatch.append(name)
 assert not mismatch,(kind,'local drift',mismatch)
 result={'archive':str(p.relative_to(ROOT)),'sha256':filehash(p),'bytes':p.stat().st_size,'manifest':manifestname,'manifest_sha256':sha(manifestbytes),'regular_unique_safe_members':len(actual),'payload_files':len(files),'payload_bytes':sum(v['bytes'] for v in files.values()),'full_filename_and_raw_byte_coverage':True,'publication_report_matched':True,'local_payload_files_compared':local_compared,'local_payload_unmapped':unmapped}
 if kind=='java-history':
  omitted=manifest['omitted_duplicate_authority'];fixture=ROOT/omitted['path'];assert filehash(fixture)==omitted['archive']['sha256']
  expected={c['archive_prefix']+'/'+n:v for c in omitted['cohorts'] for n,v in c['files'].items()}
  with tarfile.open(fixture) as t:
   seen={}
   for m in t:
    if m.name in expected:
     assert safe(m.name) and m.isfile() and m.name not in seen
     data=t.extractfile(m).read();seen[m.name]={'sha256':sha(data),'bytes':len(data)}
  assert seen==expected
  result['omitted_final_authority_files_verified']=len(seen);result['compatibility_passes_claimed']=manifest['compatibility_passes_claimed']
 if kind=='validation-review':
  policy=report['source_publication_policy'];assert not any(n.startswith(policy['omitted_prefix']) for n in actual)
  source=json.loads((ROOT/'target/m2/stage54-rust-validation-01/sources.json').read_bytes());assert len(source)==policy['omitted_files']
  assert filehash(ROOT/'target/m2/stage54-rust-validation-01/sources.json')==policy['source_manifest_sha256']
  result['omitted_duplicate_sources']=policy;result['post_commit_git_binding_verified']=False
 return result
results=[]
for args in [('candidate','stage54-candidate-publication-01','MANIFEST.json'),('java-history','stage54-java-history-publication-01','manifest.json'),('validation-review','stage54-validation-publication-01','MANIFEST.json')]:
 results.append(archive_audit(*args));print('archive verified',args[0],flush=True)
corepath=ROOT/'target/m2/stage54-core-checks-01/core-freeze.json';core=json.loads(corepath.read_bytes());corebad=[v['path'] for v in core['files'] if filehash(ROOT/v['path'])!=v['sha256']];assert not corebad
freeze=ROOT/'target/m2/stage54-adapter-recheck-01/sources.json';catalog=json.loads(freeze.read_bytes());changed=[];missing=[]
for n,h in catalog.items():
 p=ROOT/n
 if not p.is_file():missing.append(n)
 elif filehash(p)!=h:changed.append(n)
protected=['.gitmodules','references.lock','oracle.lock.json','Cargo.lock','Cargo.toml','rust-toolchain.toml','tools/platform/package.json','tools/platform/package-lock.json']
cmds=[['git','diff','--raw','HEAD'],['git','diff','--name-status','HEAD'],['git','status','--short','--untracked-files=normal'],['git','submodule','status'],['git','diff','HEAD','--',*protected,'external'],['git','diff','--check']]
gitrecords=[]
for i,c in enumerate(cmds):
 p=subprocess.run(c,cwd=ROOT,capture_output=True);(OUT/f'git-{i}.stdout.bin').write_bytes(p.stdout);(OUT/f'git-{i}.stderr.bin').write_bytes(p.stderr)
 gitrecords.append({'argv':c,'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr)})
 assert p.returncode==0,(c,p.stderr)
 if i==4:assert not p.stdout,'reference/dependency drift'
sub=[]
for n in ['external/pkl','external/pkl-pantry']:
 p=subprocess.run(['git','-C',n,'status','--short','--untracked-files=no'],cwd=ROOT,capture_output=True);assert p.returncode==0 and not p.stdout
 sub.append({'path':n,'tracked_status_clean':True})
record={'schema':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only archive streaming and source/Git review. No extraction of complete payload, staging, edits to frozen inputs, tests or guest executions.','archives':results,'core_freeze':{'sha256':filehash(corepath),'files':len(core['files']),'current_mismatches':corebad},'final_source_freeze':{'path':str(freeze.relative_to(ROOT)),'sha256':filehash(freeze),'files':len(catalog),'current_changed_paths':changed,'current_missing_paths':missing},'reference_dependency_diff_empty':True,'reference_worktrees':sub,'git_commands':gitrecords,'git_binding_scope':'162919 omitted Rust source payloads require actual implementation commit binding after commit B; not yet verified by this precommit review.'}
(OUT/'audit.json').write_text(json.dumps(record,indent=2)+'\n');print('done',json.dumps({'changed':changed,'missing':missing,'archives':[{'files':r['payload_files'],'unmapped':r['local_payload_unmapped']} for r in results]}),flush=True)
