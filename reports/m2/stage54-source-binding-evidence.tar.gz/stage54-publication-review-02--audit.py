from pathlib import Path,PurePosixPath
import json,tarfile,hashlib
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
pub=ROOT/'target/m2/stage54-validation-publication-02';report=json.loads((pub/'report.json').read_bytes());archive=ROOT/report['archive'];actual={};readme=None;manifestbytes=None
before=sha(archive.read_bytes());assert before==report['sha256'];assert archive.stat().st_size==report['bytes']
with tarfile.open(archive,'r|gz') as stream:
 for m in stream:
  assert m.isfile() and m.name not in actual and not PurePosixPath(m.name).is_absolute() and all(p not in {'','.','..'} for p in m.name.split('/')) and '\\' not in m.name
  data=stream.extractfile(m).read();assert len(data)==m.size;actual[m.name]={'sha256':sha(data),'bytes':len(data)}
  if m.name=='MANIFEST.json':manifestbytes=data
  if m.name=='verification-tools/README.md':readme=data
manifest=json.loads(manifestbytes);files=manifest['files'];assert set(actual)==set(files)|{'MANIFEST.json'};assert {k:v for k,v in actual.items() if k!='MANIFEST.json'}==files
assert sha(manifestbytes)==report['manifest_sha256'];assert len(files)==report['payload_files'];assert readme.startswith(b'# Offline verification dependency\n') and b'\\n' not in readme
old=json.loads((ROOT/'target/m2/stage54-validation-publication-01/manifest.json').read_bytes());assert set(files)==set(old['files'])
changed=[n for n in files if files[n]!=old['files'][n]];assert changed==['verification-tools/README.md'],changed
assert files['verification-tools/README.md']['sha256']==sha((pub/'verification-tools/README.md').read_bytes())
assert sha(archive.read_bytes())==before
record={'schema':1,'scope':'Read-only streaming verification of metadata-only publication02. No guest/test runs, extraction, Git staging or frozen source edits.','archive':report['archive'],'sha256':before,'bytes':archive.stat().st_size,'manifest_sha256':sha(manifestbytes),'safe_unique_regular_members':len(actual),'payload_files':len(files),'full_manifest_bytes_verified':True,'same_payload_path_set_as_original01':True,'changed_payload_paths':changed,'unchanged_other_payload_files':len(files)-1,'readable_markdown_readme':True,'source_execution_evidence_unchanged':True,'original_archive_preserved':(ROOT/'reports/m2/stage54-validation-review-evidence.tar.gz').is_file(),'post_commit_git_binding':'Still separate required evidence after implementation commit B.'}
assert sha((ROOT/'reports/m2/stage54-validation-review-evidence.tar.gz').read_bytes())=='8339afd998ffd1cdadcca1afaf5ce5d938bdc3b1666c43bc8dbc096c701e0bff'
(OUT/'audit.json').write_text(json.dumps(record,indent=2)+'\n');(OUT/'published-README.md').write_bytes(readme)
(OUT/'PLAN.ko.md').write_text('# Stage54 publication02 metadata 독립 재검토\n\n새 `stage54-validation-review-evidence-v2.tar.gz`의 안전한 경로·일반 파일·중복 없음·전체 manifest filename/bytes·report SHA/size를 streaming으로 확인했습니다. 원본01과 payload 집합이 같고 유일한 payload 변화는 읽기 가능한 `verification-tools/README.md`입니다. 나머지 9,323개 파일은 모두 원본 manifest의 전체 byte hash·size와 같습니다. 원본01 archive SHA도 변하지 않았습니다. execution/source evidence 변경은 없으며 actual commit B의 162,919개 omitted source Git 결합은 별도 후속 의무입니다.\n')
entries={str(p.relative_to(OUT)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in OUT.iterdir() if p.is_file() and p.name!='seal.json'}
(OUT/'seal.json').write_text(json.dumps({'schema':1,'files':entries},indent=2)+'\n');print(json.dumps(record));print('audit',sha((OUT/'audit.json').read_bytes()),'seal',sha((OUT/'seal.json').read_bytes()))
