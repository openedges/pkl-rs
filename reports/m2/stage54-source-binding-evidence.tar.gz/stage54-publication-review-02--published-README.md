# Offline verification dependency

The candidate archive contains the frozen comparator and captured project inputs. Its source catalog did not include the transitive `benchmark.py` import. This directory supplies the exact file from the independently pinned Java authority; PROVENANCE.json records that origin. It does not modify the original candidate packet.

Extract the candidate and validation archives into separate directories. Add this verification-tools directory to PYTHONPATH and invoke the candidate packet sources/tools/deprecation_compare.py with Python -B and --verify-report pointing to the extracted stage54-deprecation-final-02 directory. The integrity check succeeds; --verify-full retains the recorded nonpasses. The original project, Java, Node, browser, and guest execution are not required for this offline check.
