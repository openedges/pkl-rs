# Stage54 publication 마감 독립 검토

새 세 archive를 추출하지 않고 streaming으로 읽어 안전한 상대 경로·일반 파일·중복 없음·전체 filename 집합·각 SHA-256와 byte 수를 검사했습니다. `audit.py`와 `audit.json`은 실제 검사 명령·Git 상태와 전체 결과를 보존합니다. frozen 파일 수정·Git staging·guest 실행·검사 재실행은 하지 않았습니다.

- candidate: payload 59,522개, 전체 raw bytes와 `MANIFEST.json`, publication report SHA/size가 일치합니다. 초기 실패와 최종 비교를 원래대로 포함합니다.
- Java history: payload 13,779개, 전체 raw bytes와 `manifest.json`, publication report가 일치합니다. 별도 고정 fixture authority에서 중복 제외한 최종 Java 7,650개 파일도 각각 확인했습니다. 대소문자가 다른 manifest 이름은 각 실제 형식에 맞춰 검사했습니다. compatibility pass 주장은 0입니다.
- validation/review: payload 9,324개, 전체 raw bytes와 `MANIFEST.json`, publication report가 일치합니다. 별도 verification toolkit의 `benchmark.py`는 후보 source catalog에 없었다는 설명과 정확한 Java authority origin/hash를 유지합니다.
- archive payload 82,625개 모두 원래 local 파일의 전체 raw bytes와 같고, 원본 누락·byte 변화가 없습니다. archive 전체를 추출하거나 symlink/hardlink/device member를 허용하지 않았습니다.
- 공통 core freeze 18개 모두 현재 source와 일치하고 final source freeze 4,577개도 현재 source와 완전히 같습니다. freeze 이후 source 변경·누락은 없습니다.
- Git diff에 reference·gitlink·dependency·toolchain 변경이 없고 pinned 두 submodule의 tracked worktree가 깨끗합니다. 새 engine/helper/test 및 evidence 파일은 의도된 Stage54 범위입니다. `git diff --check`가 통과합니다.

Rust 검증의 중복 source payload 162,919개는 publication에서만 제외되어 있습니다. 전체 source manifest와 원시 검사 로그는 archive에 남아 있고 원본 local payload는 유지됩니다. 해당 source bytes의 실제 implementation commit B 결합은 root가 commit 후 수행할 별도 의무이며 이 사전 검토에서 완료했다고 하지 않습니다.

세 archive의 안전성·전체 manifest/byte 결합과 현재 freeze 일치에서 blocker를 찾지 못했습니다. full M2·Java 내부 오류 nonpass·same-JVM lifecycle·custom transformer/API parity·기존 regex gap은 본 archive 검토로 닫히지 않습니다.

## 원본 publication01 README 한계

root가 별도 확인한 validation publication01의 README 생성 결함도 원본 archive에서 직접 확인했습니다. `repr(multiline)` 결과의 literal quote·escaped newline이 남아 있어 Markdown 안내 가독성이 떨어집니다. 원시 README와 별도 metadata 기록을 보존했습니다. 이는 위 전체 byte/manifest 무결성 검사 통과와 별개이며, root의 새 publication02에서 README와 manifest만 고칠 예정입니다. 원본 archive 검토를 새 archive 검증으로 소급하지 않습니다.
