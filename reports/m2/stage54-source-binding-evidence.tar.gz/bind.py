from pathlib import Path
import datetime
import hashlib
import io
import json
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
OUT = ROOT / 'target/m2/stage54-source-binding-01'
COMMIT = sys.argv[1]

def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def tree(cwd, revision):
    result = {}
    for entry in git('ls-tree', '-rz', revision, cwd=cwd).split(b'\0'):
        if not entry:
            continue
        head, name = entry.split(b'\t', 1)
        mode, kind, oid = head.decode().split()
        result[name.decode()] = (mode, kind, oid)
    return result

assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
assert git('rev-parse', '--show-object-format').decode().strip() == 'sha1'
assert not (OUT / 'report.json').exists()
project = tree(ROOT, COMMIT)
reference_trees = {}
gitlinks = {}
for name in ('external/pkl', 'external/pkl-pantry'):
    mode, kind, oid = project[name]
    assert mode == '160000' and kind == 'commit'
    gitlinks[name] = oid
    reference_trees[name] = tree(ROOT / name, oid)

groups = [
    ('final-validation-inputs', 'stage54-adapter-recheck-01', False),
    ('required-rust-check-inputs', 'stage54-rust-validation-01', True),
]
results = []
failures = []
details_path = OUT / 'bindings.jsonl'
with details_path.open('x') as details:
    for label, directory, captured in groups:
        base = ROOT / 'target/m2' / directory
        manifest_bytes = (base / 'sources.json').read_bytes()
        manifest = json.loads(manifest_bytes)
        counts = {'project': 0, 'references': 0}
        for path, expected_sha in sorted(manifest.items()):
            relative = Path(path)
            assert not relative.is_absolute() and '..' not in relative.parts
            origin = base / 'sources' / path if captured else ROOT / path
            data = origin.read_bytes()
            observed_sha = digest(data)
            repository = '.'
            revision = COMMIT
            git_path = path
            entries = project
            for prefix, reference in reference_trees.items():
                if path.startswith(prefix + '/'):
                    repository = prefix
                    revision = gitlinks[prefix]
                    git_path = path[len(prefix) + 1:]
                    entries = reference
                    break
            entry = entries.get(git_path)
            blob_oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            match = observed_sha == expected_sha and entry is not None and entry[1] == 'blob' and entry[2] == blob_oid
            row = {'group': label, 'path': path, 'sha256': observed_sha, 'bytes': len(data), 'repository': repository, 'commit': revision, 'git_path': git_path, 'git_blob': blob_oid, 'matches_manifest_and_git_blob': match}
            details.write(json.dumps(row, separators=(',', ':')) + '\n')
            if not match:
                failures.append({'group': label, 'path': path, 'expected_sha256': expected_sha, 'actual_sha256': observed_sha, 'git_entry': entry, 'computed_blob': blob_oid})
            counts['project' if repository == '.' else 'references'] += 1
        results.append({'group': label, 'manifest': str((base / 'sources.json').relative_to(ROOT)), 'manifest_sha256': digest(manifest_bytes), 'files': len(manifest), 'counts': counts, 'payload_origin': 'original immutable validation snapshot' if captured else 'workspace bytes equal final frozen manifest'})
        print(label, len(manifest), 'checked', flush=True)

details_data = details_path.read_bytes()
assert sum(1 for _ in details_data.splitlines()) == sum(item['files'] for item in results)
assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
report = {'schema': 1, 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Post-commit source binding; no new candidate/oracle execution or compatibility pass is claimed.', 'implementation_commit': COMMIT, 'gitlinks': gitlinks, 'groups': results, 'binding_rows': sum(item['files'] for item in results), 'details_sha256': digest(details_data), 'failures': failures, 'all_match': not failures, 'method': 'Hash original source bytes with SHA-256 against each frozen catalog and Git SHA-1 blob framing against the actual committed tree object IDs. Reference files are resolved through the committed gitlinks.', 'reconstruction': 'The 162919 required Rust validation snapshot payloads omitted from the validation publication can be reconstructed from this implementation Git tree using the original sources.json manifest. Original local snapshots remain intact.'}
write_json(OUT / 'report.json', report)
if failures:
    print(json.dumps({'failed': len(failures), 'examples': failures[:5]}))
    raise SystemExit(1)
(OUT / 'README.md').write_text('# Stage 54 source binding\n\nThe report and JSONL bindings connect the final frozen validation inputs and every original required Rust-check snapshot to actual committed Git blobs. This records provenance, not additional compatibility execution. Check out the recorded implementation commit and pinned gitlinks, then verify each reconstructed file against its manifest SHA-256. Original validation snapshots remain unchanged.\n')
archive = ROOT / 'reports/m2/stage54-source-binding-evidence.tar.gz'
assert not archive.exists()
members = {}
for path in sorted(OUT.iterdir()):
    if path.is_file():
        data = path.read_bytes()
        members[path.name] = {'sha256': digest(data), 'bytes': len(data)}
manifest_bytes = (json.dumps({'schema': 1, 'files': members}, indent=2) + '\n').encode()
with tarfile.open(archive, 'x:gz') as stream:
    for name in members:
        stream.add(OUT / name, arcname=name, recursive=False)
    entry = tarfile.TarInfo('MANIFEST.json')
    entry.size = len(manifest_bytes)
    stream.addfile(entry, io.BytesIO(manifest_bytes))
seen = set()
with tarfile.open(archive, 'r:gz') as stream:
    for entry in stream:
        assert entry.isfile() and entry.name not in seen and '/' not in entry.name
        seen.add(entry.name)
        data = stream.extractfile(entry).read()
        if entry.name == 'MANIFEST.json':
            assert data == manifest_bytes
        else:
            assert digest(data) == members[entry.name]['sha256'] and len(data) == members[entry.name]['bytes']
assert seen == set(members) | {'MANIFEST.json'}
publication = dict(report)
publication['archive'] = {'path': str(archive.relative_to(ROOT)), 'sha256': digest(archive.read_bytes()), 'bytes': archive.stat().st_size, 're_read_verified': True}
write_json(ROOT / 'reports/m2/stage54-source-binding.json', publication)
print(json.dumps({'all_match': True, 'rows': report['binding_rows'], 'archive': publication['archive']}), flush=True)
