"""Package explicit publication metadata after the data publisher has terminated."""
from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, tarfile
O = Path(__file__).resolve().parent
R = O.parents[2]
B = O.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
write(O / 'finalize-start.json', {'pid': os.getpid(), 'parentPid': os.getppid(), 'command': [sys.executable, str(Path(__file__).resolve())], 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sourceSha256': sha(Path(__file__))})
def check(ok, message):
    if not ok: raise ValueError(message)

check(json.loads((O / 'package.terminal.json').read_bytes())['exitCode'] == 0, 'actual publisher terminal')
check(sha(R / 'tools/evidence.py') == json.loads((O / 'selection.json').read_bytes())['evidenceToolSha256'], 'unchanged evidence tool source')
check(sha(O / 'publish.py') == json.loads((O / 'package.launch.json').read_bytes())['publisherSha256'], 'unchanged publisher source')
report = json.loads((O / 'report.json').read_bytes())
check(report['originalChanges'] == [] and report['allCommandsZero'], 'closed original data checks')
source = O / 'gathered/closeout'
source.mkdir()
paths = [O / name for name in ['publish.py', 'launch.py', 'finalize.py', 'selection.json', 'selection-summary.json', 'references.json', 'published-fixture-raw-mapping.json', 'index.json', 'report.json', 'progress.json', 'select.launch.json', 'select.terminal.json', 'select.stdout.bin', 'select.stderr.bin', 'package.launch.json', 'package.terminal.json', 'package.stdout.bin', 'package.stderr.bin', 'correction.json', 'README.md', 'actual-tools.json', 'runtime-identity.json', 'tool-source/evidence.py', 'finalize-start.json']]
paths += sorted((O / 'fixture-reference').iterdir())
for d in sorted((O / 'commands').iterdir()):
    check(d.is_dir() and not d.is_symlink(), 'known command directory')
    paths += [d / name for name in ['launch.json', 'terminal.json', 'stdout.bin', 'stderr.bin']]
previous = B / 'stage49-oracle-publication-01'
paths += [previous / name for name in ['publish.py', 'selection-summary.json', 'selection.stdout.bin', 'selection.stderr.bin']]
failed = B / 'stage49-oracle-publication-02'
paths += [failed / name for name in ['publish.py', 'launch.py', 'selection-summary.json', 'select.launch.json', 'select.terminal.json', 'select.stdout.bin', 'select.stderr.bin', 'package.launch.json', 'package.terminal.json', 'package.stdout.bin', 'package.stderr.bin']]
paths += [failed / 'progress.json']
for group_name in ['driver-mock-tooling', 'java-audits-transport']:
    paths.append(failed / 'archives' / ('stage49-' + group_name + '.tar.gz'))
    for action in ['create', 'verify']:
        paths += [failed / 'commands' / (group_name + '-' + action) / name for name in ['launch.json', 'terminal.json', 'stdout.bin', 'stderr.bin']]
rows = []
for p in paths:
    check(p.is_file() and not p.is_symlink(), 'known regular metadata')
    rel = str(p.relative_to(O)) if p.is_relative_to(O) else ('failed-publication02/' + str(p.relative_to(failed)) if p.is_relative_to(failed) else 'draft49/' + p.name)
    dest = source / rel; dest.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(p, dest)
    rows.append({'source': str(p), 'archiveMember': rel, 'sha256': sha(p), 'bytes': p.stat().st_size})
write(source / 'CAPTURE_SELECTION.json', {'schema': 1, 'files': rows, 'scope': 'Publication producer, explicit selected raw paths, canonical published fixture reconstruction map, tool commands and actual terminal. Draft49 selection retained as metadata; final53 selection supersedes its scope. No recursive traversal of source/dependency caches.'})
archive = O / 'archives/stage49-oracle-publication-closeout.tar.gz'
commands = []
for action in ['create', 'verify']:
    target = O / ('closeout-' + action); target.mkdir()
    command = [sys.executable, str(R / 'tools/evidence.py'), action]
    command += [str(source), str(archive)] if action == 'create' else [str(archive)]
    rec = {'command': command, 'cwd': str(R), 'parentPid': os.getpid(), 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (target / 'stdout.bin').open('wb') as out, (target / 'stderr.bin').open('wb') as err:
        p = subprocess.Popen(command, cwd=R, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=out, stderr=err); rec['pid'] = p.pid; write(target / 'launch.json', rec); rec['exitCode'] = p.wait()
    rec.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), stdoutSha256=sha(target / 'stdout.bin'), stderrSha256=sha(target / 'stderr.bin')); write(target / 'terminal.json', rec); check(rec['exitCode'] == 0, 'closeout ' + action); commands.append(rec)
with tarfile.open(archive, 'r:gz') as tf:
    members = {m.name: m for m in tf.getmembers()}; inv = json.load(tf.extractfile(members['EVIDENCE.json']))
    for row in inv['files']:
        data = tf.extractfile(members[row['path']]).read(); check(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'] and data == (source / row['path']).read_bytes(), 'closeout every-member independent readback')
    for row in rows: check(sha(Path(row['source'])) == row['sha256'], 'original publication metadata unchanged')
check(archive.stat().st_size < 100_000_000, 'closeout below100MB')
index = json.loads((O / 'index.json').read_bytes())
index['archives'].append({'group': 'closeout', 'path': str(archive), 'fileName': archive.name, 'sha256': sha(archive), 'compressedBytes': archive.stat().st_size, 'sourceFiles': len(rows), 'payloadFiles': len(inv['files']), 'allRawMembersReadBack': True, 'below100MB': True})
write(O / 'final-index.json', index)
summary = {'schema': 1, 'scope': 'Selected Stage49 Java, native ModuleKey and mocked driver verification evidence only; full Java events/counters, invalid Host SPI internal errors and full M2 remain open.', 'extraJava': {'apiCalls': 944, 'success': 760, 'error': 184, 'intentNotReachedQueryAliasDiagnosticCalls': 100, 'invalidFragmentInternalApiBoundaries': 8, 'original01To07Preserved': True}, 'old212Native': {'originalOrderedJavaEvents': 2248, 'eventEncodingQualification': 'Original UTF8/ASCII provenance retained; derived units are not fresh independent Java encoding captures.', 'build02': {'providedRawMatches': 212, 'publicRawMatches': 212}, 'build05': {'providedRawMatches': 212, 'publicRawMatches': 212}, 'fullLifecyclePassSessionsPerProfile': 0, 'fullLifecycleFailedSessionsPerProfile': 36}, 'extendedNative944': {'build04': {'rawMatches': 904, 'ordinaryMismatches': 32, 'internalBoundaryMismatches': 8}, 'build05': {'rawMatches': 936, 'intendedOrdinaryMatches': 836, 'preservedInitialDiagnosticMatches': 100, 'ordinaryMismatches': 0, 'internalBoundaryMismatches': 8}, 'processesPerBuild': 140, 'allProcessesZeroAndSlotsZero': True, 'unchangedJavaExpectations': True}, 'driverProposal04': {'syntaxChecks': 2, 'unitTests': 9, 'realInstalledFixtureMockPreflight': True, 'engineExecutions': 0, 'browserLaunches': 0}, 'selection': {k: report[k] for k in ['selectedRoots', 'selectedPayloads', 'selectedRawBytes', 'originalChanges']}, 'archives': len(index['archives']), 'compressedBytes': sum(r['compressedBytes'] for r in index['archives']), 'allBelow100MB': True, 'allCreateAndSeparateVerifyCommandsZero': True, 'allRawMembersIndependentlyReadBack': True, 'fullJavaEventCounterParityPassed': False, 'preservedHistory': ['Initial native132 relativeSOURCE launch failure before guest execution', 'Wrong consumer config pin rejection', 'Initial nativeaudit custom/default key classification failure', 'Native944 audit01 metadata field-name KeyError before audit result', 'Original query-scope alias intent failures100', 'Java invalid-SPI internal errors8', 'Initial fixture test expectation failure', 'Initial sidecarV2 builder failure', 'Driver mocked-test aliasing expectation failure and metadata parser failure', 'Unsealed historical roots remain without invented producer closures', 'Draft publication02 was stopped for missing exact prewalk cache exclusions; failed publisher SIGTERM/241 retained'], 'noJavaOrNativeEvaluationDuringPackaging': True, 'mainReportsGitWrites': False, 'liveHandles': []}
write(O / 'summary.json', summary)
write(O / 'handoff.json', {'schema': 1, 'selectionSha256': sha(O / 'selection.json'), 'publisherReportSha256': sha(O / 'report.json'), 'publisherActualTerminalSha256': sha(O / 'package.terminal.json'), 'finalIndexSha256': sha(O / 'final-index.json'), 'summarySha256': sha(O / 'summary.json'), 'referencesSha256': sha(O / 'references.json'), 'closeoutCommands': commands, 'finalizerSourceSha256': sha(Path(__file__)), 'archives': index['archives'], 'scope': summary['scope'], 'originalChanges': [], 'liveHandles': []})
print(json.dumps({'handoffSha256': sha(O / 'handoff.json'), 'summarySha256': sha(O / 'summary.json'), 'finalIndexSha256': sha(O / 'final-index.json'), 'archives': summary['archives'], 'compressedBytes': summary['compressedBytes']}))
