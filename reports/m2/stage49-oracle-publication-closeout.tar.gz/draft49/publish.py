"""Read-only Stage49 B evidence selection, clean gathering and checked publication."""
from pathlib import Path
import collections, datetime, hashlib, json, os, shutil, stat, subprocess, sys, tarfile

O = Path(__file__).resolve().parent
R = O.parents[2]
B = O.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
def check(ok, message):
    if not ok:
        raise ValueError(message)

def group(name):
    if name in [f'stage49-oracle-modulekey-{i:02}' for i in [1, 2, 3]]: return 'java-controls01-03'
    if name in [f'stage49-oracle-modulekey-{i:02}' for i in [4, 5, 6, 7]]: return 'java-controls04-07'
    if name == 'stage49-oracle-native-extended944-build04-01': return 'native944-build04-failures'
    if name == 'stage49-oracle-native-extended944-build05-01': return 'native944-build05-correction'
    if name.startswith('stage49-modulekey-driver-') or name == 'stage49-modulekey-installed-review-01': return 'driver-mock-tooling'
    if name.startswith('stage49-oracle-modulekey-audit-') or name.startswith('stage49-oracle-extended-transport-'): return 'java-audits-transport'
    if name.startswith('stage49-oracle-native-extended-'): return 'native944-consumers-audits'
    if name in ['stage49-oracle-native-consumer-03', 'stage49-oracle-native-audit-03', 'stage49-native-public-observer-diagnostic-01'] or '212-build02' in name: return 'native212-build02'
    return 'spi-reuse-tooling-initial-history'

def roots():
    result = []
    for p in B.iterdir():
        if ((p.name.startswith('stage49-oracle-') and p.name not in ['stage49-oracle-publication-01', 'stage49-oracle-spi-fixtures-01'])
            or (p.name.startswith('stage49-modulekey-driver-') and p.name != 'stage49-modulekey-driver-tests-private')
            or p.name in ['stage49-native-public-observer-diagnostic-01', 'stage49-modulekey-installed-review-01']):
            result.append(p)
    return sorted(result)

def traversal_prunes(selected):
    prunes = {}
    for root in selected:
        if root.name.startswith('stage49-oracle-modulekey-') and root.name[-2:].isdigit():
            prunes[str(root / 'identity/.cache')] = 'Generated deterministic-environment cache; no producer inventory payload under this directory.'
            prunes[str(root / 'runtime-private')] = 'No recursive walk of private JVM HOME/TMP/cache. Exact sealed libtruffleattach payloads are read directly from producer inventory and retained.'
        if root.name in ['stage49-oracle-spi-tools-01', 'stage49-oracle-spi-tools-02']:
            prunes[str(root / 'tests-private')] = 'Producer temporary fixture clones, cleaned; excluded before descent.'
    return prunes

def file_row(p, root, declared):
    st = p.lstat(); rel = str(p.relative_to(root)); kind = 'symlink' if stat.S_ISLNK(st.st_mode) else 'regular'
    check(kind == 'symlink' or stat.S_ISREG(st.st_mode), 'unsupported filesystem payload ' + str(p))
    data = os.fsencode(os.readlink(p)) if kind == 'symlink' else p.read_bytes()
    row = {'source': str(p), 'root': str(root), 'relative': rel, 'group': group(root.name), 'kind': kind, 'mode': stat.S_IMODE(st.st_mode), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'producerInventoryListed': rel in declared}
    if kind == 'symlink': row['targetBytesHex'] = data.hex()
    if rel in declared:
        d = declared[rel]
        check(row['sha256'] == d['sha256'] and row['bytes'] == d['bytes'], 'sealed payload changed ' + str(p))
        if 'mode' in d: check(row['mode'] == d['mode'], 'sealed mode changed ' + str(p))
        if 'kind' in d: check(row['kind'] == d['kind'], 'sealed kind changed ' + str(p))
    return row

def scan(selected, prunes):
    rows = []; statuses = []; prune_stats = []
    for root in selected:
        inv = json.loads((root / 'inventory.json').read_bytes()) if (root / 'inventory.json').is_file() else None
        declared = inv.get('files', {}) if inv else {}
        closure = json.loads((root / 'closure.json').read_bytes()) if (root / 'closure.json').is_file() else None
        if closure and closure.get('inventorySha256'):
            check(sha(root / 'inventory.json') == closure['inventorySha256'], 'producer inventory authentication ' + root.name)
        for key, name in [('reportSha256', 'report.json'), ('handoffSha256', 'handoff.json'), ('outerTerminalSha256', 'outer-terminal.json')]:
            if closure and closure.get(key): check(sha(root / name) == closure[key], 'producer closure ' + name)
        check(not closure or not closure.get('liveHandles'), 'closed producer handles ' + root.name)
        paths = {root / rel for rel in declared}
        # Read authenticated paths directly; do not recurse into a private cache.
        for p in paths: check(p.is_file() or p.is_symlink(), 'missing declared payload ' + str(p))
        for base, dirs, files in os.walk(root, followlinks=False):
            base = Path(base)
            for name in list(dirs):
                p = base / name
                if str(p) in prunes:
                    dirs.remove(name); st = p.lstat(); prune_stats.append({'path': str(p), 'reason': prunes[str(p)], 'walked': False, 'mode': stat.S_IMODE(st.st_mode), 'kind': 'symlink' if p.is_symlink() else 'directory'})
                elif p.is_symlink(): dirs.remove(name); paths.add(p)
            paths.update(base / f for f in files)
        rows.extend(file_row(p, root, declared) for p in sorted(paths))
        terminal = {}
        for n in ['outer-terminal.json', 'actual-terminal.json', 'cli-terminal.json', 'tests-terminal.json']:
            if (root / n).is_file(): terminal[n] = {'sha256': sha(root / n), 'record': json.loads((root / n).read_bytes())}
        statuses.append({'root': str(root), 'group': group(root.name), 'producerClosureSha256': sha(root / 'closure.json') if closure else None, 'historicProducerSealed': bool(closure and closure.get('sealed')), 'producerInventorySha256': sha(root / 'inventory.json') if inv else None, 'declaredPayloads': len(declared), 'terminalRecords': terminal, 'qualification': 'Historic missing closure/terminal is retained as missing; publication does not invent a producer seal.' if not closure else 'Existing producer seal retained; extra non-inventory envelope files are listed separately.'})
    return rows, statuses, prune_stats

def references():
    refs = {'schema': 1, 'alreadyPublished': [], 'frozenNativeBuilds': [], 'permanentFixture': {}, 'ownership': 'A owns native build/source/binaries; root/C own platform, promotion and independent-review roots. These are references, not B archive duplicates.'}
    for name in ['stage48-java-admission-controls.tar.gz', 'stage48-admission-tooling-history.tar.gz', 'stage48-oracle-captures.json']:
        p = R / 'reports/m2' / name
        refs['alreadyPublished'].append({'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size})
    for n in [1, 2, 4, 5]:
        root = B / f'stage49-modulekey-build{n:02}'; r = json.loads((root / 'build.json').read_bytes()); binary = Path(r['artifact'])
        check(sha(binary) == r['artifactSha256'], 'frozen referenced native binary')
        refs['frozenNativeBuilds'].append({'root': str(root), 'buildSha256': sha(root / 'build.json'), 'artifact': str(binary), 'artifactSha256': sha(binary), 'sourceBeforeSha256': sha(root / 'sources-before.json'), 'sourceAfterSha256': sha(root / 'sources-after.json'), 'sourceCount': r['sourceCount'], 'scope': r['scope'], 'owner': 'A/root core archive; binary and source snapshot not duplicated here.'})
    fixture = R / 'tests/fixtures/m2-modulekey-spi'; target = B / 'stage49-oracle-spi-fixtures-01'
    check(sha(fixture / 'manifest.json') == 'ebd3591361efc0a03e98e38695b120e9c625d9c09d0438fc641de420114aab97' == sha(target / 'manifest.json'), 'unchanged permanent fixture manifest')
    manifest = json.loads((fixture / 'manifest.json').read_bytes()); mapping = []
    archive = R / 'reports/m2/stage48-java-admission-controls.tar.gz'
    with tarfile.open(archive, 'r:gz') as tf:
        members = {m.name: m for m in tf.getmembers()}
        for rel, row in manifest['files'].items():
            check(sha(fixture / rel) == row['sha256'] == sha(target / rel), 'fixture original/installed byte join ' + rel)
            if rel.startswith('original/') or rel.startswith('provenance/'):
                inner = 'payload/java01/' + rel.split('/', 1)[1]
                data = tf.extractfile(members[inner]).read()
                check(hashlib.sha256(data).hexdigest() == row['sha256'], 'published original archive raw join ' + rel)
                mapping.append({'fixturePath': rel, 'archiveMember': inner, **row})
    write(O / 'published-fixture-raw-mapping.json', {'archiveSha256': sha(archive), 'files': mapping})
    refs['permanentFixture'] = {'root': str(fixture), 'producerRoot': str(target), 'manifestSha256': sha(fixture / 'manifest.json'), 'totalFiles': len(manifest['files']) + 1, 'publishedRawFilesMapped': len(mapping), 'mappingSha256': sha(O / 'published-fixture-raw-mapping.json'), 'derivedFiles': {p: manifest['files'][p] for p in ['fixtures.json', 'provenance-map.json']}, 'qualification': 'Installed fixture bytes authenticated; permanent Git commit binding is root-owned. Old original/provenance raw is reconstructed from already-published Stage48 archive, not duplicated.'}
    meta = O / 'fixture-reference'; meta.mkdir()
    for rel in ['manifest.json', 'fixtures.json', 'provenance-map.json']: shutil.copyfile(fixture / rel, meta / rel)
    return refs

def select():
    check(not (O / 'selection.json').exists(), 'fresh selection')
    selected = roots(); check(len(selected) == 49, 'explicit expected B49 root boundary')
    prunes = traversal_prunes(selected); rows, statuses, ps = scan(selected, prunes)
    refs = references(); write(O / 'references.json', refs)
    selection = {'schema': 1, 'roots': [str(p) for p in selected], 'rootStatus': statuses, 'traversalPrune': ps, 'exactPrunePaths': prunes, 'files': rows, 'externalReferencesSha256': sha(O / 'references.json'), 'evidenceTool': str(R / 'tools/evidence.py'), 'evidenceToolSha256': sha(R / 'tools/evidence.py'), 'groups': {g: {'files': sum(r['group'] == g for r in rows), 'rawBytes': sum(r['bytes'] for r in rows if r['group'] == g)} for g in sorted({r['group'] for r in rows})}}
    write(O / 'selection.json', selection)
    summary = {'roots': len(selected), 'payloads': len(rows), 'rawBytes': sum(r['bytes'] for r in rows), 'regularFiles': sum(r['kind'] == 'regular' for r in rows), 'symlinks': sum(r['kind'] == 'symlink' for r in rows), 'historicSealedRoots': sum(x['historicProducerSealed'] for x in statuses), 'historicUnsealedRoots': sum(not x['historicProducerSealed'] for x in statuses), 'identityIssues': 0, 'groups': selection['groups'], 'selectionSha256': sha(O / 'selection.json')}
    write(O / 'selection-summary.json', summary); print(json.dumps(summary, indent=2))

def run_command(command, label):
    d = O / 'commands' / label; d.mkdir(parents=True)
    rec = {'command': command, 'cwd': str(R), 'parentPid': os.getpid(), 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (d / 'stdout.bin').open('wb') as out, (d / 'stderr.bin').open('wb') as err:
        p = subprocess.Popen(command, cwd=R, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=out, stderr=err); rec['pid'] = p.pid; write(d / 'launch.json', rec); rec['exitCode'] = p.wait()
    rec.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), stdoutSha256=sha(d / 'stdout.bin'), stderrSha256=sha(d / 'stderr.bin')); write(d / 'terminal.json', rec)
    check(rec['exitCode'] == 0, 'evidence command ' + label)
    return rec

def package():
    selection = json.loads((O / 'selection.json').read_bytes()); before, statuses, ps = scan([Path(p) for p in selection['roots']], selection['exactPrunePaths'])
    check(before == selection['files'] and statuses == selection['rootStatus'] and ps == selection['traversalPrune'], 'original selection unchanged before gather')
    records = []; archives = []
    for g in selection['groups']:
        gather = O / 'gathered' / g; gather.mkdir(parents=True); chosen = [r for r in before if r['group'] == g]; mapping = []
        for row in chosen:
            src = Path(row['source']); rel = 'payload/' + Path(row['root']).name + '/' + row['relative']; rel += '.symlink-target.bin' if row['kind'] == 'symlink' else ''
            dest = gather / rel; dest.parent.mkdir(parents=True, exist_ok=True); data = os.fsencode(os.readlink(src)) if row['kind'] == 'symlink' else src.read_bytes(); check(hashlib.sha256(data).hexdigest() == row['sha256'], 'source before clean copy'); dest.write_bytes(data); mapping.append({'archiveMember': rel, **row})
        write(gather / 'CAPTURE_SELECTION.json', {'schema': 1, 'selectionSha256': sha(O / 'selection.json'), 'files': mapping})
        shutil.copyfile(O / 'references.json', gather / 'EXTERNAL_REFERENCES.json')
        write(gather / 'GROUP_SCOPE.json', {'group': g, 'historicProducerSeals': [s for s in statuses if s['group'] == g], 'scope': 'Raw history preserved.100 initial alias-intent failures and8 invalid-SPI Java internal boundaries are distinct from ordinary compatibility. Full Java event/counter parity remains false. No new evaluation during packaging.'})
        archive = O / 'archives' / ('stage49-' + g + '.tar.gz')
        records.append(run_command([sys.executable, str(R / 'tools/evidence.py'), 'create', str(gather), str(archive)], g + '-create'))
        records.append(run_command([sys.executable, str(R / 'tools/evidence.py'), 'verify', str(archive)], g + '-verify'))
        count = 0
        with tarfile.open(archive, 'r:gz') as tf:
            members = {m.name: m for m in tf.getmembers()}; inv = json.load(tf.extractfile(members['EVIDENCE.json']))
            for row in inv['files']:
                data = tf.extractfile(members[row['path']]).read(); check(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], 'independent member readback'); check(data == (gather / row['path']).read_bytes(), 'exact clean gather readback'); count += 1
            for row in mapping:
                data = tf.extractfile(members[row['archiveMember']]).read(); check(hashlib.sha256(data).hexdigest() == row['sha256'], 'original source-to-member join')
        check(archive.stat().st_size < 100_000_000, 'archive below GitHub100MB')
        archives.append({'group': g, 'path': str(archive), 'fileName': archive.name, 'sha256': sha(archive), 'compressedBytes': archive.stat().st_size, 'sourceFiles': len(chosen), 'sourceRawBytes': sum(r['bytes'] for r in chosen), 'payloadFiles': count, 'allRawMembersReadBack': True, 'below100MB': True})
        write(O / 'progress.json', {'archivesComplete': archives})
    after, poststatus, postps = scan([Path(p) for p in selection['roots']], selection['exactPrunePaths'])
    check(after == before and poststatus == statuses and postps == ps, 'original pathset/kind/mode/bytes unchanged after archive')
    write(O / 'index.json', {'schema': 1, 'archives': archives})
    write(O / 'report.json', {'schema': 1, 'archives': len(archives), 'compressedBytes': sum(a['compressedBytes'] for a in archives), 'selectedRoots': len(selection['roots']), 'selectedPayloads': len(before), 'selectedRawBytes': sum(r['bytes'] for r in before), 'originalChanges': [], 'allCommandsZero': True, 'allArchiveMembersIndependentlyReadBack': True, 'commands': records, 'selectionSha256': sha(O / 'selection.json'), 'indexSha256': sha(O / 'index.json'), 'noEvaluationsDuringPackaging': True, 'historicUnsealedRootsRemainUnsealed': True, 'mainReportsGitWrites': False})
    print(json.dumps({'reportSha256': sha(O / 'report.json'), 'archives': len(archives), 'compressedBytes': sum(a['compressedBytes'] for a in archives)}))

if __name__ == '__main__':
    {'select': select, 'package': package}[sys.argv[1]]()
