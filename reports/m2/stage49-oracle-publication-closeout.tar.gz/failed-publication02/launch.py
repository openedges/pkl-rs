from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
O = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ['select', 'package']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
record = {'command': [sys.executable, str(O / 'publish.py'), mode], 'cwd': str(O), 'parentPid': os.getpid(), 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'publisherSha256': sha(O / 'publish.py')}
with (O / (mode + '.stdout.bin')).open('wb') as out, (O / (mode + '.stderr.bin')).open('wb') as err:
    process = subprocess.Popen(record['command'], cwd=O, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=out, stderr=err)
    record['pid'] = process.pid
    write(O / (mode + '.launch.json'), record)
    record['exitCode'] = process.wait()
record.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(), stdoutSha256=sha(O / (mode + '.stdout.bin')), stderrSha256=sha(O / (mode + '.stderr.bin')), liveHandles=[])
write(O / (mode + '.terminal.json'), record)
print(json.dumps(record))
raise SystemExit(record['exitCode'])
