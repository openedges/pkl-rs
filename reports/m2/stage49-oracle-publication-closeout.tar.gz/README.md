# Stage49 oracle and native evidence proposal

This target-only publication contains B-owned Java controls01–07, the original212 native profiles on builds02 and05, native944 comparisons on builds04 and05, independent raw audits, and fixture/Host/driver tooling history. It does not change source, fixtures, Git, or reports.

The Java944 observations include100 original query-local alias errors that did not reach their intended property/identity checks and8 invalid custom-SPI fragment cases that raised Java internal errors. Build05 matches all836 intended ordinary rows and the100 original diagnostic rows; the8 internal boundaries remain unmatched. Build04’s32 ordinary mismatches and the exact unchanged-input corrective transition are preserved.

The new Java01–07 helper independently captured Java event UTF-16 and UTF-8. The reused original212 event ledger retains its original UTF-8/ASCII provenance; derived units do not become independent Java encoding evidence.

Both original212 native profiles match every API channel on builds02 and05. Each profile still fails the complete original Java event/counter gate for all36 sessions. Selected typed-request or diagnostic projections do not replace that gate. The driver proposals are mocked-artifact preflight/unit evidence; actual Node/Chromium platform acquisitions belong to root/C.

Selection is driven by exact producer inventories when available, with additional historical files explicitly listed.18 roots have historic producer seals;35 do not. No historic closure or missing process terminal is invented. Cache directory traversal is pruned by exact absolute paths before descent. Authenticated libtruffleattach payloads already listed in Java inventories are retained through direct file reads without recursively walking private JVM cache trees.

Already-published Stage48 raw fixture bytes are referenced through7236 byte-verified archive-member mappings. The permanent7239-file fixture is verified against its installed and original copies; only its manifest and two derived files are carried in the publication metadata. A-owned native binaries/source snapshots and root/C platforms are exact-hash references rather than duplicate archives.

Draft publication02 omitted two generated Python bytecode cache directories from its initial traversal exclusions. Its publisher was stopped; its original producer, selection summary, command and terminal metadata remain in the closeout archive. Publication03 corrects those exact exclusions without deleting or modifying original files.

Use final-index.json for archive hashes and member counts, selection.json for original paths/kinds/modes/hashes, references.json for external authority boundaries, and summary.json for scoped outcomes. Every archive is created and separately verified with tools/evidence.py, followed by independent full member readback.
