"""Create independent small archives from clean gathered regular files only."""
from pathlib import Path
from collections import defaultdict
import hashlib
import importlib.util
import json
import os
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
CLEAN = OUT / "gathered"
UNITS = OUT / "archive-sources"
ARCHIVES = OUT / "archives"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + "\n")

def original(row):
    path = Path(row["source"])
    mode = path.lstat().st_mode
    if row["kind"] == "symbolic-link-as-exact-target-bytes":
        assert stat.S_ISLNK(mode)
        data = os.readlink(os.fsencode(path))
    else:
        assert stat.S_ISREG(mode)
        data = path.read_bytes()
    assert sha(data) == row["sha256"] and len(data) == row["bytes"], str(path)
    assert stat.S_IMODE(mode) == row["original_mode"]

selection_raw = (OUT / "selection.json").read_bytes()
selection = json.loads(selection_raw)
proposal = json.loads((OUT / "proposal.json").read_bytes())
assert sha(selection_raw) == proposal["selection_sha256"]
assert json.loads((OUT / "gather-report.json").read_bytes())["source_verified_before_and_after_copy"]
assert not UNITS.exists() and not ARCHIVES.exists(), "Never overwrite archive evidence."
units = defaultdict(list)
for row in selection["rows"]:
    name = row["group"]
    if name == "historical-implementation":
        parts = row["archive_path"].split("/")
        child = parts[2]
        if child in ["candidate-build-01", "candidate-build-02"]:
            name = "historical-candidates-01-02"
        elif child.startswith("candidate-build-"):
            name = "historical-" + child
        elif child == "workspace":
            name = "historical-workspace"
        else:
            name = "historical-execution-records"
    units[name].append(row)
plan = [{"unit": unit, "source_payloads": len(rows), "source_bytes": sum(row["bytes"] for row in rows)} for unit, rows in units.items()]
write(OUT / "archive-plan.json", {"schema": 1, "selection_sha256": sha(selection_raw), "units": plan,
                                    "original_selection_unchanged": True, "maximum_compressed_bytes": 48 * 1024 * 1024})
for unit, rows in units.items():
    for row in rows:
        source = CLEAN / row["archive_path"]
        assert source.is_file() and not source.is_symlink()
        assert sha(source.read_bytes()) == row["sha256"]
        destination = UNITS / unit / row["archive_path"].split("/", 1)[1]
        destination.parent.mkdir(parents=True, exist_ok=True)
        # Hardlink only our verified clean copies; never link to producer files.
        os.link(source, destination)
    write(UNITS / unit / "CAPTURE_SELECTION.json", {
        "schema": 1, "unit": unit, "selection_sha256": sha(selection_raw),
        "original_payloads": len(rows), "original_bytes": sum(row["bytes"] for row in rows),
        "symbolic_link_policy": "Payload contains exact raw link-target bytes; kind and original mode are retained per row. No links are followed.",
        "rows": rows,
    })
spec = importlib.util.spec_from_file_location("stage45_evidence", ROOT / "tools/evidence.py")
evidence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evidence)
ARCHIVES.mkdir()
archives = []
for unit, rows in units.items():
    destination = ARCHIVES / f"stage45-core-{unit}.tar.gz"
    evidence.create(UNITS / unit, destination, [])
    with tarfile.open(destination, "r:gz") as archive:
        members = {member.name: member for member in archive.getmembers()}
        expected = {row["archive_path"].split("/", 1)[1] for row in rows} | {"CAPTURE_SELECTION.json", "EVIDENCE.json"}
        assert set(members) == expected
        for row in rows:
            data = archive.extractfile(members[row["archive_path"].split("/", 1)[1]]).read()
            assert sha(data) == row["sha256"] and len(data) == row["bytes"]
    assert destination.stat().st_size <= 48 * 1024 * 1024, str(destination)
    archives.append({"unit": unit, "path": str(destination), "sha256": sha(destination.read_bytes()),
                     "compressed_bytes": destination.stat().st_size, "source_payloads": len(rows),
                     "source_bytes": sum(row["bytes"] for row in rows), "derived_selection_metadata_files": 1,
                     "archive_payloads_excluding_evidence_inventory": len(rows) + 1})
for row in selection["rows"]:
    original(row)
report = {
    "schema": 1, "scope": "Core capture archives only; separate oracle/portable publication and all historical failures remain distinct.",
    "selection_sha256": sha(selection_raw), "archives": archives,
    "source_payloads_verified": len(selection["rows"]), "source_bytes": sum(row["bytes"] for row in selection["rows"]),
    "source_verified_before_gather_after_gather_after_archiving": True,
    "archive_members_and_payload_hashes_independently_joined_to_selection": True,
    "each_archive_with_independent_evidence_inventory_and_selection": True,
    "all_compressed_files_below_48_mib": True,
    "compiled_artifacts_preserved": selection["compiled_artifact_policy"],
    "symbolic_link_payloads": sum(row["kind"] != "regular-file" for row in selection["rows"]),
    "original_evidence_changed": False, "git_writes": False,
}
write(OUT / "archive-report.json", report)
print(json.dumps({"archives": len(archives), "payloads": report["source_payloads_verified"],
                  "compressed_bytes": sum(row["compressed_bytes"] for row in archives),
                  "largest_compressed_bytes": max(row["compressed_bytes"] for row in archives),
                  "archive_report_sha256": sha((OUT / "archive-report.json").read_bytes())}))
