"""Declare and hash exact core evidence roots without entering dependency caches."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
COMMIT = "97b4da0526ea0a96e4efb71eb5616bc15d80c116"
EARLY_ROOT = Path("/Users/cody.ij.hwang/Projects/pkl-rs.stage42/target/m2/stage45-stdlib-implementation-01")
GROUPS = {
    "historical-implementation": [str(EARLY_ROOT)],
    "rust-checks": ["stage45-rust5-01", "stage45-rust5-02", "stage45-security-fixture-tests-01", "stage45-denial-fix-01"],
    "main-platform": ["stage45-platform-candidate-01", "stage45-platform-launch-01", "stage45-platform-env-01"],
    "final-native": ["stage45-native-final-01"],
    "final-classpath": ["stage45-classpath-candidate-01", "stage45-classpath-candidate-01-workspace", "stage45-classpath-launch-01", "stage45-classpath-verification-01"],
    "reviews": ["stage45-core-review-02", "stage45-core-review-03", "stage45-core-integration-review-01", "stage45-publication-review-01", "stage45-core-handoff-01"],
    "receipts-tooling": ["stage45-tooling-final-01", "stage45-portable-promotion-01", "stage45-promotion-01", "stage45-base-update-01", "stage45-base-update-02", "stage45-proposed-binding-01"],
}
PUBLICATION_FILES = ["README.md", "PLAN.md", "TESTING.md", "docs/architecture.md",
                     "docs/m2-moduleinfo-fixtures.md", "docs/m2-stdlib-bootstrap.md",
                     "reports/m2/README.md", "reports/m2/stage45-implementation-checkpoint.json",
                     "compatibility/m2-language.json"]
# These exact paths are declared before any walk. Generic basename exclusions
# (including "build") are prohibited: unrelated captured builds remain evidence.
EXCLUDED = {
    ROOT / "target/debug", ROOT / "target/release", ROOT / "target/wasm32-unknown-unknown",
    ROOT / ".cache", ROOT / "tools/platform/node_modules", ROOT / ".git",
    ROOT / "tools/__pycache__", ROOT / "tools/tests/__pycache__",
    ROOT / "target/m2/stage45-classpath-candidate-01/build",
    EARLY_ROOT / "cargo-target", EARLY_ROOT / "workspace/target",
    EARLY_ROOT / "workspace/tools/__pycache__", EARLY_ROOT / "workspace/tools/tests/__pycache__",
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")

def source_binding():
    snapshot = ROOT / "target/m2/stage45-native-final-01/source-after.json"
    captured = json.loads(snapshot.read_bytes())
    tree = {}
    for item in git("ls-tree", "-rz", COMMIT).split(b"\0"):
        if item:
            metadata, name = item.split(b"\t", 1)
            mode, kind, oid = metadata.decode().split()
            tree[name.decode()] = (mode, kind, oid)
    rows = {}
    for name, expected in captured.items():
        path = ROOT / name
        frozen_path = ROOT / "target/m2/stage45-native-final-01/sources" / name
        assert path.is_file() and not path.is_symlink(), name
        data = path.read_bytes()
        assert sha(data) == expected and frozen_path.read_bytes() == data, name
        oid = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        mode, kind, actual_oid = tree[name]
        assert kind == "blob" and oid == actual_oid, name
        rows[name] = {"sha256": expected, "bytes": len(data), "git_blob": oid, "mode": mode}
    assert len(rows) == 14216
    publication_rows = {}
    for name in PUBLICATION_FILES:
        data = (ROOT / name).read_bytes()
        oid = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert tree[name][1:] == ("blob", oid), name
        publication_rows[name] = {"sha256": sha(data), "bytes": len(data), "git_blob": oid, "mode": tree[name][0]}
    write("committed-publication-map.json", publication_rows)
    write("committed-source-map.json", rows)
    write("committed-source-binding.json", {
        "schema": 1, "commit": COMMIT,
        "commit_tree": git("rev-parse", COMMIT + "^{tree}").decode().strip(),
        "scope": "Exact 14,216 final Rust5/native captured source bytes match real committed Git blobs; not a claim that every historical capture used these bytes.",
        "captured_map_path": str(snapshot), "captured_map_sha256": sha(snapshot.read_bytes()),
        "source_map_sha256": sha((OUT / "committed-source-map.json").read_bytes()),
        "verified_paths": len(rows), "all_match": True,
        "publication_paths": len(publication_rows),
        "publication_map_sha256": sha((OUT / "committed-publication-map.json").read_bytes()),
        "gitlinks": {name: {"mode": tree[name][0], "git_commit": tree[name][2]} for name in ["external/pkl", "external/pkl-pantry"]},
        "m1_collector_qualification": "76 of 77 production inputs were captured directly; stdlib/modules.txt uses the complete earlier freeze and identical later native map, not a fabricated M1 capture.",
        "git_writes": False, "full_m2_complete": False,
    })

def entry(path, archive_path, group):
    metadata = path.lstat()
    if stat.S_ISLNK(metadata.st_mode):
        data = os.readlink(os.fsencode(path))
        kind = "symbolic-link-as-exact-target-bytes"
    else:
        assert stat.S_ISREG(metadata.st_mode), str(path)
        data = path.read_bytes()
        kind = "regular-file"
    return {"source": str(path), "archive_path": archive_path,
            "group": group, "kind": kind, "bytes": len(data),
            "sha256": sha(data), "original_mode": stat.S_IMODE(metadata.st_mode)}

def main():
    assert git("rev-parse", "HEAD").decode().strip() == COMMIT
    assert not any(path.is_symlink() for path in [ROOT, OUT])
    source_binding()
    excluded_rows = [{"path": str(path), "reason": "Dependency/Cargo cache, excluded before descent and not sized/hashed."} for path in sorted(EXCLUDED)]
    write("exclusions.json", {"declared_before_walk": True, "exact_absolute_paths": excluded_rows,
                              "generic_basename_exclusions": [], "aliases_followed": False,
                              "symlinks": "Never follow; store exact os.readlink bytes as a regular payload with kind and mode metadata."})
    rows = []
    encountered_exclusions = []
    for group, roots in GROUPS.items():
        for name in roots:
            source = Path(name) if Path(name).is_absolute() else ROOT / "target/m2" / name
            archive_root = source.name
            assert source.is_dir() and not source.is_symlink(), str(source)
            for directory, dirs, files in os.walk(source, topdown=True, followlinks=False):
                directory = Path(directory)
                assert directory not in EXCLUDED
                keep = []
                for basename in sorted(dirs):
                    child = directory / basename
                    if child in EXCLUDED:
                        encountered_exclusions.append(str(child))
                    elif child.is_symlink():
                        relative = child.relative_to(source).as_posix()
                        rows.append(entry(child, f"{group}/{archive_root}/{relative}", group))
                    else:
                        keep.append(basename)
                dirs[:] = keep
                for basename in sorted(files):
                    child = directory / basename
                    if child in EXCLUDED:
                        encountered_exclusions.append(str(child))
                        continue
                    relative = child.relative_to(source).as_posix()
                    rows.append(entry(child, f"{group}/{archive_root}/{relative}", group))
    for name in PUBLICATION_FILES:
        rows.append(entry(ROOT / name, "committed-documents/" + name, "committed-documents"))
    rows.sort(key=lambda row: row["archive_path"])
    assert len({row["archive_path"] for row in rows}) == len(rows)
    counts = {}
    for group in [*GROUPS, "committed-documents"]:
        selected = [row for row in rows if row["group"] == group]
        counts[group] = {"roots": len(GROUPS.get(group, PUBLICATION_FILES)), "payloads": len(selected),
                         "bytes": sum(row["bytes"] for row in selected),
                         "kinds": dict(Counter(row["kind"] for row in selected))}
    write("selection.json", {"schema": 1, "scope": "Pre-archive explicit original core-evidence selection; original bytes unchanged. Java/original6/bootstrap/portable oracle evidence is separately owned.",
                             "groups": GROUPS, "explicit_committed_files": PUBLICATION_FILES, "rows": rows,
                             "encountered_exact_exclusions": encountered_exclusions,
                             "compiled_artifact_policy": "Preserve immutable recorded native, Wasm, N-API, Java classes and provider artifacts inside chosen evidence roots. Omit only exact declared dependency/Cargo cache paths. Fixture-embedded captured runtime identities remain producer inputs, not generic caches."})
    write("proposal.json", {"schema": 1, "status": "Selection hashed; archive not yet generated.",
                            "implementation_commit": COMMIT, "group_counts": counts,
                            "total_payloads": len(rows), "total_bytes": sum(row["bytes"] for row in rows),
                            "selection_sha256": sha((OUT / "selection.json").read_bytes()),
                            "source_binding_sha256": sha((OUT / "committed-source-binding.json").read_bytes()),
                            "source_map_sha256": sha((OUT / "committed-source-map.json").read_bytes()),
                            "encountered_exact_exclusions": encountered_exclusions,
                            "archive_created": False, "git_writes": False})
    print(json.dumps(json.loads((OUT / "proposal.json").read_bytes())))

if __name__ == "__main__":
    main()
