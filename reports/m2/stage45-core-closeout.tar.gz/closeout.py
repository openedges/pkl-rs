"""Archive collector metadata separately and publish a target-only handoff."""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")

archive_report = json.loads((OUT / "archive-report.json").read_bytes())
process = json.loads((OUT / "archive-process.json").read_bytes())
assert process["exit_code"] == 0 and process["inputs_stable"]
assert archive_report["source_verified_before_gather_after_gather_after_archiving"]
oracle_root = ROOT / "target/m2/stage45-oracle-publication-01"
oracle_expected = {
    "archive-index.json": "b03412d2c11b571400686ee2b4e7783e0de289ded9f9e7e3fe47513a4ea17d5d",
    "report.json": "c47697976f5412ebff431ee88a19af169ebdeca08af91ccc09db3758630cd8f2",
    "closure.json": "5a47833d3128f332736d67620cb09e24989ce06d9964504686f2b9377010c06f",
}
for name, expected in oracle_expected.items():
    assert sha((oracle_root / name).read_bytes()) == expected
write(OUT / "oracle-boundary.json", {"schema": 1, "scope": "Separate producer's completed publication handoff; pointer bytes checked here, archive internals remain that producer's verification scope.",
                                     "files": [{"path": str(oracle_root / name), "sha256": value} for name, value in oracle_expected.items()],
                                     "canonical_full_build_snapshots_owned_by_core": True,
                                     "sealed_comparison_duplicate_artifacts_preserved_in_oracle_set": True})
metadata_names = ["collect.py", "package.py", "archive.py", "run_archive.py", "closeout.py",
                  "selection.json", "proposal.json", "exclusions.json", "committed-source-binding.json",
                  "committed-source-map.json", "committed-publication-map.json", "gather-report.json",
                  "archive-plan.json", "archive-report.json", "archive-process.json", "archive.stdout.bin", "archive.stderr.bin", "oracle-boundary.json"]
source = OUT / "closeout-source"
assert not source.exists()
source.mkdir()
rows = []
for name in metadata_names:
    data = (OUT / name).read_bytes()
    (source / name).write_bytes(data)
    rows.append({"path": name, "sha256": sha(data), "bytes": len(data)})
spec = importlib.util.spec_from_file_location("stage45_evidence", ROOT / "tools/evidence.py")
evidence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evidence)
destination = OUT / "archives/stage45-core-closeout.tar.gz"
assert not destination.exists()
evidence.create(source, destination, [])
assert destination.stat().st_size <= 48 * 1024 * 1024
for row in rows:
    assert sha((OUT / row["path"]).read_bytes()) == row["sha256"]
all_archives = [*archive_report["archives"], {"unit": "closeout", "path": str(destination),
                "sha256": sha(destination.read_bytes()), "compressed_bytes": destination.stat().st_size,
                "archive_payloads_excluding_evidence_inventory": len(rows), "metadata": rows}]
write(OUT / "handoff.json", {
    "schema": 1, "scope": "Core Stage45 evidence preparation only. Target-only files, no reports publication or Git changes.",
    "implementation_commit": "97b4da0526ea0a96e4efb71eb5616bc15d80c116",
    "source_binding": {"path": str(OUT / "committed-source-binding.json"), "sha256": sha((OUT / "committed-source-binding.json").read_bytes())},
    "source_map": {"path": str(OUT / "committed-source-map.json"), "sha256": sha((OUT / "committed-source-map.json").read_bytes())},
    "selection": {"path": str(OUT / "selection.json"), "sha256": archive_report["selection_sha256"]},
    "source_payloads": archive_report["source_payloads_verified"], "source_bytes": archive_report["source_bytes"],
    "archives": all_archives, "archive_count": len(all_archives),
    "total_compressed_bytes": sum(row["compressed_bytes"] for row in all_archives),
    "largest_compressed_bytes": max(row["compressed_bytes"] for row in all_archives),
    "original_sources_verified_before_and_after_gather_and_archiving": True,
    "symbolic_link_payloads_as_exact_raw_target_bytes": archive_report["symbolic_link_payloads"],
    "archive_integrity_and_exact_selection_join_passed": True,
    "independent_inventory_per_archive": True, "all_archives_below_48_mib": True,
    "historical_failures_preserved": ["denied-catch-tests-01 exit101", "guest-oracle-tests-01/02", "workspace-tests-01..04", "other original producer statuses as recorded"],
    "original_evidence_changed": False, "production_changed": False, "git_writes": False,
    "separate_oracle_boundary": "B owns 37 historical stage42 and12 final Stage45 oracle/original6/bootstrap/portable roots plus handoff, including preserved supplemental audit failures. Canonical main-platform and final-native full build snapshots are in this core set; sealed comparison duplicate binaries remain in B set.",
    "separate_oracle_handoff": {"path": str(OUT / "oracle-boundary.json"), "sha256": sha((OUT / "oracle-boundary.json").read_bytes())},
    "remaining": ["Root review and reports/Git publication", "Root integration of separately completed oracle/portable archives", "Combined selected and sequential evaluator regression", "M1 modules.txt collector omission qualification and later tooling fix", "All full M2, product/platform and performance obligations"],
    "full_m2_complete": False, "hosted_ci_claimed": False, "performance_target_claimed": False,
})
print(json.dumps({"archives": len(all_archives), "total_compressed_bytes": sum(row["compressed_bytes"] for row in all_archives),
                  "largest_compressed_bytes": max(row["compressed_bytes"] for row in all_archives),
                  "handoff_sha256": sha((OUT / "handoff.json").read_bytes())}))
