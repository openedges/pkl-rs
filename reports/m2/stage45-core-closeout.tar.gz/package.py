"""Materialize frozen selection and archive only the clean gathered copies."""
from pathlib import Path
from collections import defaultdict
import hashlib
import importlib.util
import json
import os
import stat
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
CLEAN = OUT / "gathered"
ARCHIVES = OUT / "archives"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

def json_bytes(value):
    return (json.dumps(value, indent=2) + "\n").encode()

def original(row):
    path = Path(row["source"])
    metadata = path.lstat()
    if row["kind"] == "symbolic-link-as-exact-target-bytes":
        assert stat.S_ISLNK(metadata.st_mode), str(path)
        raw = os.readlink(os.fsencode(path))
    else:
        assert stat.S_ISREG(metadata.st_mode), str(path)
        raw = path.read_bytes()
    assert stat.S_IMODE(metadata.st_mode) == row["original_mode"], str(path)
    assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], str(path)
    return raw

selection_raw = (OUT / "selection.json").read_bytes()
selection = json.loads(selection_raw)
proposal = json.loads((OUT / "proposal.json").read_bytes())
assert sha(selection_raw) == proposal["selection_sha256"]
groups = defaultdict(list)
for row in selection["rows"]:
    groups[row["group"]].append(row)

if sys.argv[1:] == ["gather"]:
    assert not CLEAN.exists(), "Never overwrite a gathered snapshot."
    for row in selection["rows"]:
        target = CLEAN / row["archive_path"]
        write(target, original(row))
    for group, rows in groups.items():
        write(CLEAN / group / "CAPTURE_SELECTION.json", json_bytes({
            "schema": 1, "selection_sha256": sha(selection_raw), "group": group,
            "scope": "Original capture bytes preserved; symbolic-link entries are regular payloads of exact link-target bytes, never followed. Mode/kind metadata is retained in these rows.",
            "original_payloads": len(rows), "original_bytes": sum(row["bytes"] for row in rows), "rows": rows,
        }))
    # A second read detects producer changes during copying without cache walks.
    for row in selection["rows"]:
        original(row)
        copy = CLEAN / row["archive_path"]
        assert copy.is_file() and not copy.is_symlink()
        assert copy.stat().st_size == row["bytes"] and sha(copy.read_bytes()) == row["sha256"]
    write(OUT / "gather-report.json", json_bytes({
        "schema": 1, "source_payloads": len(selection["rows"]),
        "source_bytes": sum(row["bytes"] for row in selection["rows"]),
        "selection_sha256": sha(selection_raw), "source_verified_before_and_after_copy": True,
        "gathered_payloads_verified": True, "derived_group_metadata_files": len(groups),
        "symbolic_links_materialized_as_exact_bytes": sum(row["kind"] != "regular-file" for row in selection["rows"]),
        "archives_created": False, "original_evidence_changed": False,
    }))
    print((OUT / "gather-report.json").read_text())
elif sys.argv[1:] == ["archive"]:
    assert CLEAN.is_dir() and not ARCHIVES.exists(), "Never overwrite archive evidence."
    spec = importlib.util.spec_from_file_location("stage45_evidence", ROOT / "tools/evidence.py")
    evidence = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(evidence)
    ARCHIVES.mkdir()
    archives = []
    for group, rows in groups.items():
        destination = ARCHIVES / f"stage45-core-{group}.tar.gz"
        evidence.create(CLEAN / group, destination, [])
        # Independently join each member to the frozen pre-archive selection.
        with tarfile.open(destination, "r:gz") as archive:
            members = {member.name: member for member in archive.getmembers()}
            expected = {row["archive_path"].split("/", 1)[1] for row in rows} | {"CAPTURE_SELECTION.json", "EVIDENCE.json"}
            assert set(members) == expected
            for row in rows:
                data = archive.extractfile(members[row["archive_path"].split("/", 1)[1]]).read()
                assert sha(data) == row["sha256"] and len(data) == row["bytes"]
        archives.append({"group": group, "path": str(destination), "sha256": sha(destination.read_bytes()),
                         "compressed_bytes": destination.stat().st_size, "source_payloads": len(rows),
                         "source_bytes": sum(row["bytes"] for row in rows),
                         "derived_group_metadata_files": 1,
                         "archive_payloads_excluding_evidence_inventory": len(rows) + 1})
    for row in selection["rows"]:
        original(row)
    write(OUT / "archive-report.json", json_bytes({
        "schema": 1, "scope": "Core evidence groups only; separate oracle/portable evidence handoff and original limitations remain distinct.",
        "selection_sha256": sha(selection_raw), "archives": archives,
        "source_payloads_verified": len(selection["rows"]),
        "source_verified_before_gather_after_gather_after_archiving": True,
        "archive_members_and_payload_hashes_independently_joined_to_selection": True,
        "compiled_artifacts_preserved": selection["compiled_artifact_policy"],
        "original_evidence_changed": False, "git_writes": False,
    }))
    print(json.dumps({"archives": len(archives), "payloads": len(selection["rows"]),
                      "compressed_bytes": sum(row["compressed_bytes"] for row in archives),
                      "archive_report_sha256": sha((OUT / "archive-report.json").read_bytes())}))
else:
    raise SystemExit("usage: package.py gather|archive")
