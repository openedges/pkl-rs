import json,sys,concurrent.futures,platform
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import oracle,m2_language as m,m2_manifest as c
root=Path.cwd();out=root/'target/m2/stage35-annotation-sequences-02';meta=oracle.ensure_oracle(root,fetch=False);(out/'oracle.json').write_bytes(c.encoded(meta));(out/'artifacts/java').mkdir(parents=True);(out/'sources').mkdir()
p=root/'tools/java/M2ClassLifecycleProbe.java';(out/'sources/M2ClassLifecycleProbe.java').write_bytes(p.read_bytes());javac=str(Path(meta['java']).with_name('javac'));r=m.capture([javac,'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(out/'artifacts/java'),str(p)],out,'javac',meta['environment']);assert r['exit_code']==0
seq={
'class-first-annotation-prefix':('import "pkl:reflect"\nclass Ann extends Annotation { x: Int }\n@Ann { x=1 }\n@Int\nclass C { y: Int=2 }\nannCount=reflect.Class(C).annotations.length.toString()\nannX=reflect.Class(C).annotations.first.x.toString()\nstable=23\n',['C.toString()','C.toString()','annCount','annX','new C {}.y.toString()','stable.toString()']),
'alias-first-annotation-prefix':('import "pkl:reflect"\nclass Ann extends Annotation { x: Int }\n@Ann { x=1 }\n@Int\ntypealias A = Int\nannCount=reflect.TypeAlias(A).annotations.length.toString()\nannX=reflect.TypeAlias(A).annotations.first.x.toString()\nstable=23\n',['A.toString()','A.toString()','annCount','annX','(1 is A).toString()','stable.toString()']),
'lazy-body-retry':('import "pkl:reflect"\nclass Ann extends Annotation { x: Int }\n@Ann { x=throw("lazy") }\nclass C {}\nannX=reflect.Class(C).annotations.first.x.toString()\nstable=23\n',['C.toString()','annX','C.toString()','annX','stable.toString()']),
}
(out/'sequences.json').write_bytes(c.encoded(seq))
def run(item):
 name,(source,expressions)=item;d=out/'sequences'/name;d.mkdir(parents=True);(d/'input.pkl').write_text(source);(d/'expressions.txt').write_text('\n'.join(expressions)+'\n');results=[]
 for evaluator in ['first-evaluator','fresh-evaluator']:
  dest=d/evaluator;dest.mkdir();cmd=list(meta['command'][:-1]);cmd[-1]+=':'+str(out/'artifacts/java');cmd.extend(['M2ClassLifecycleProbe',str(d/'input.pkl'),str(d/'expressions.txt'),str(dest)]);row=m.capture(cmd,dest,'java',meta['environment']);assert row['exit_code']==0
  calls=[dict(expression=e,status=(dest/f'{i}.status.bin').read_text(),stdout=(dest/f'{i}.stdout.bin').read_text(),stderr=(dest/f'{i}.stderr.bin').read_text(),exception=(dest/f'{i}.error-class.bin').read_text()) for i,e in enumerate(expressions)]
  results.append(dict(evaluator=evaluator,process=row,calls=calls))
 print(name,[(x['status'].strip(),x['stdout'],x['stderr'].split('\n')[1:2]) for x in results[0]['calls']],flush=True)
 return dict(id=name,input=str((d/'input.pkl').relative_to(root)),input_sha256=oracle.sha256(d/'input.pkl'),expressions=expressions,results=results)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,seq.items()))
(out/'report.json').write_bytes(c.encoded(dict(scope='Independent pinned Java persistent annotation publication/failure/retry sequences, repeated fresh evaluator; no Rust success claim.',host=platform.platform(),oracle=meta,results=results,files={str(p.relative_to(out)):oracle.sha256(p) for p in out.rglob('*') if p.is_file()})))
