import json, pathlib, subprocess, sys
root=pathlib.Path.cwd(); out=root/('target/m2/stage35-core-matrix-'+sys.argv[1]);out.mkdir()
rows=json.load(open('target/m2/stage35-selected-rows.json')); results=[]
for row in rows:
 d=out/row['id']; d.mkdir(); source=root/row['input']; r=subprocess.run([str(root/'target/m2/stage35-core-cargo/debug/examples/language_probe'),str(source),row['expression']],capture_output=True)
 (d/'rust.stdout.bin').write_bytes(r.stdout);(d/'rust.stderr.bin').write_bytes(r.stderr)
 oracle=root/'target/m2/stage35-selected-oracle-01/cases'/row['id']; j=json.loads((oracle/'java.process.json').read_text())
 ok=r.stdout==(oracle/'java.stdout.bin').read_bytes() and r.stderr==(oracle/'java.stderr.bin').read_bytes()
 results.append({'id':row['id'],'equal':ok,'rust_returncode':r.returncode})
 if not ok:
  print(row['id'])
  print('R:',r.stderr.decode()[:550].replace('\n',' | '))
  print('J:',(oracle/'java.stderr.bin').read_text()[:550].replace('\n',' | '))
(out/'results.json').write_text(json.dumps(results,indent=2));print('passed',sum(r['equal'] for r in results),'/',len(results))
