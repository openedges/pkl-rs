import java.net.URI;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;
import java.io.IOException;
import org.pkl.core.*;
import org.pkl.core.resource.ResourceReader;
public final class Stage35HostProbe {
 static Path out;
 static void capture(Evaluator eval,ModuleSource source,String expression,String prefix) throws Exception {
  String status="success\n",value="",error="",type="";
  try { value=eval.evaluateExpressionString(source,expression); }
  catch(PklException e){status="error\n";error=e.getMessage();type=e.getClass().getName()+"\n";}
  Files.writeString(out.resolve(prefix+".status.bin"),status,StandardCharsets.UTF_8);
  Files.writeString(out.resolve(prefix+".stdout.bin"),value,StandardCharsets.UTF_8);
  Files.writeString(out.resolve(prefix+".stderr.bin"),error,StandardCharsets.UTF_8);
  Files.writeString(out.resolve(prefix+".error-class.bin"),type,StandardCharsets.UTF_8);
 }
 static final class Reader implements ResourceReader {
  int calls; Evaluator evaluator;ModuleSource source;List<String> inner;boolean fail;
  public String getUriScheme(){return "life";}public boolean hasHierarchicalUris(){return false;}public boolean isGlobbable(){return false;}
  public Optional<Object> read(URI uri) throws IOException {
   calls++;System.out.println("host-read="+uri+" calls="+calls);
   for(int i=0;i<inner.size();i++){try{capture(evaluator,source,inner.get(i),"inner-"+calls+"-"+i);}catch(Exception e){throw new RuntimeException(e);}}
   if(fail&&calls==1) throw new IOException("stage35-read-failure");
   return Optional.of("resource");
  }
 }
 public static void main(String[]args)throws Exception {
  out=Path.of(args[0]);var reader=new Reader();reader.inner=Files.readAllLines(out.resolve("inner.expressions"));reader.fail=Boolean.parseBoolean(args[1]);
  try(var eval=EvaluatorBuilder.preconfigured().setColor(false).setModuleCacheDir(null).setPowerAssertionsEnabled(false).setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).setAllowedResources(List.of(Pattern.compile("life:.*"))).setResourceReaders(List.of(reader)).build()){
   var source=ModuleSource.create(URI.create("file:///m2-platform.pkl"),Files.readString(out.resolve("input.pkl")));reader.evaluator=eval;reader.source=source;
   var calls=Files.readAllLines(out.resolve("outer.expressions"));for(int i=0;i<calls.size();i++){capture(eval,source,calls.get(i),"outer-"+i);System.out.println("attempt="+i+" calls="+reader.calls);}
  }
 }
}
