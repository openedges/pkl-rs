import json,sys,shutil,concurrent.futures
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import oracle,m2_language as m,m2_manifest as c
root=Path.cwd();base=root/'target/m2/stage35-builtin-selected-oracle-01';out=base/sys.argv[1];candidate=Path(sys.argv[2]);out.mkdir();(out/'artifacts').mkdir();binary=out/'artifacts/language_probe';shutil.copy2(candidate,binary);acq=base/'recovered';report=json.loads((acq/'report.json').read_bytes());rows=json.loads((root/'target/m2/stage35-builtin-selected-rows.json').read_bytes());meta=report['oracle'];(out/'selection.json').write_bytes(c.encoded(rows));(out/'oracle.json').write_bytes(c.encoded(meta))
def run(row):
 name=row['id'];d=out/'cases'/name;d.mkdir(parents=True);source=root/row['input'];(d/'input.pkl').write_bytes(source.read_bytes());r=m.capture([str(binary),str(source),row['expression']],d,'rust',meta['environment']);old=acq/'cases'/name;old=old if old.exists() else base/'direct/cases'/name;j=json.loads((old/'java.process.json').read_bytes());status=m.status(row,j,r,*((p/f'{runner}.{ch}.bin').read_bytes() for p,runner in [(old,'java'),(d,'rust')] for ch in ['stdout','stderr']),(old/'java.outcome.bin').read_bytes());differences=[]
 for ch in ['stdout','stderr']:
  expected=(old/f'java.{ch}.bin').read_bytes();actual=(d/f'rust.{ch}.bin').read_bytes()
  if expected!=actual:
   at=next((i for i,(a,b) in enumerate(zip(expected,actual)) if a!=b),min(len(expected),len(actual)));differences.append(dict(channel=ch,first_difference=at,expected_context=expected[max(0,at-50):at+180].decode(errors='replace'),actual_context=actual[max(0,at-50):at+180].decode(errors='replace')))
 print(name,status,json.dumps(differences),flush=True);return dict(id=name,status=status,source_sha256=oracle.sha256(source),java_acquisition=str(old.relative_to(root)),rust=r,differences=differences)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,rows))
from collections import Counter
(out/'report.json').write_bytes(c.encoded(dict(scope='Independent candidate-only raw comparison against unchanged pinned Java actual-path captures.',oracle_report=str((acq/'report.json').relative_to(root)),oracle_report_sha256=oracle.sha256(acq/'report.json'),candidate=dict(path=str(candidate),sha256=oracle.sha256(binary),binding='Caller-supplied frozen core artifact; source/build binding supplied separately by core.'),results=results,status_counts=dict(Counter(r['status'] for r in results)),files={str(p.relative_to(out)):oracle.sha256(p) for p in out.rglob('*') if p.is_file()})))
