import json
from pathlib import Path
root=Path.cwd();p={
'annotation-abstract':'result=(new Annotation {}).getClass().toString()\n',
'deprecated-nullable-defaults':'empty=new Deprecated {}\nfull=new Deprecated { since="0.1"; message="Use x."; replaceWith="x" }\nresult=List(empty.since,empty.message,empty.replaceWith,full.since,full.message,full.replaceWith,(full is Annotation)).toString()\n',
'deprecated-since-wrong-type':'ann=new Deprecated { since=1 }\nresult=ann.since.toString()\n',
'deprecated-message-wrong-type':'ann=new Deprecated { message=1 }\nresult=ann.message.toString()\n',
'deprecated-replace-with-wrong-type':'ann=new Deprecated { replaceWith=1 }\nresult=ann.replaceWith.toString()\n',
'since-version-undefined':'ann=new Since {}\nresult=ann.version\n',
'since-version-value':'ann=new Since { version="0.32.0" }\nresult=ann.version+"|"+(ann is Annotation).toString()\n',
'unlisted-empty':'@Unlisted\nclass C {}\nann=new Unlisted {}\nresult=(ann is Annotation).toString()\n',
'unlisted-final':'class Child extends Unlisted {}\nresult=Child.toString()\n',
'also-known-as-default-and-lazy':'empty=new AlsoKnownAs {}\ninvalid=new AlsoKnownAs { names { 1 } }\nresult=List(empty.names.length,invalid.names.length,(invalid is Annotation)).toString()\n',
'also-known-as-invalid-element':'ann=new AlsoKnownAs { names { 1 } }\nresult=ann.names[0].toString()\n',
'doc-example-default-and-lazy':'empty=new DocExample {}\ninvalid=new DocExample { subjects { 1 } }\nresult=List(empty.subjects.length,invalid.subjects.length,(invalid is Annotation)).toString()\n',
'doc-example-invalid-element':'ann=new DocExample { subjects { 1 } }\nresult=ann.subjects[0].toString()\n',
'source-code-defaults':'ann=new SourceCode {}\nresult=List(ann.language,ann.prefix,ann.suffix,(ann is Annotation)).toString()\n',
'source-code-union-and-string':'result=List("Go","HTML","Java","JavaScript","Markdown","Pkl","PklExpr","Python","Ruby","SQL","Swift","Rust").map((s)->new SourceCode { language=s }.language).toString()\n',
'source-code-language-wrong-type':'ann=new SourceCode { language=1 }\nresult=ann.language.toString()\n',
'source-code-prefix-wrong-type':'ann=new SourceCode { prefix=1 }\nresult=ann.prefix.toString()\n',
'custom-annotation-hierarchy':'open class Custom extends Annotation\nclass Child extends Custom\n@Child\nclass C {}\nann=new Child {}\nresult=List((ann is Annotation),(ann is Custom),(ann is Child)).toString()\n',
}
rows=[]
for name,source in p.items():
 identifier='annotation-stage35-builtin-'+name;path=root/f'tests/fixtures/m2/{identifier}.pkl';assert not path.exists();path.write_text(source);failure=name in ['annotation-abstract','deprecated-since-wrong-type','deprecated-message-wrong-type','deprecated-replace-with-wrong-type','since-version-undefined','unlisted-final','also-known-as-invalid-element','doc-example-invalid-element','source-code-language-wrong-type','source-code-prefix-wrong-type'];rows.append(dict(id=identifier,input=str(path.relative_to(root)),expression='result',expected_outcome='failure' if failure else 'success',requirements=['semantic:annotations','semantic:objects','semantic:types','semantic:lazy-evaluation','semantic:diagnostics','semantic:shared-engine']))
(root/'target/m2/stage35-builtin-selected-rows.json').write_text(json.dumps(rows,indent=2)+'\n');print(len(rows))
