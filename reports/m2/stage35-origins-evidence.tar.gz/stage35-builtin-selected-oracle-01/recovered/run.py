import json,sys,shutil,concurrent.futures
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import oracle,m2_language as m,m2_manifest as c
root=Path.cwd(); out=root/'target/m2/stage35-builtin-selected-oracle-01/recovered'; meta=oracle.ensure_oracle(root,fetch=False)
(out/'oracle.json').write_bytes(c.encoded(meta));(out/'artifacts/java').mkdir(parents=True);(out/'sources').mkdir(exist_ok=True)
probe=root/'tools/java/M2LanguageProbe.java';(out/'sources/M2LanguageProbe.java').write_bytes(probe.read_bytes())
fixed=out/'sources/Stage35BuiltinFixedProbe.java'; fixed.write_text(probe.read_text().replace('public final class M2LanguageProbe','public final class Stage35BuiltinFixedProbe').replace('ModuleSource.path(Path.of(args[0]))','ModuleSource.create(java.net.URI.create("file:///m2-platform.pkl"), Files.readString(Path.of(args[0])))'))
frozen=out/'artifacts/language_probe'; shutil.copy2(root/'target/m2/language-stage34-final-02/artifacts/language_probe',frozen)
javac=str(Path(meta['java']).with_name('javac'));r=m.capture([javac,'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(out/'artifacts/java'),str(out/'sources/M2LanguageProbe.java'),str(fixed)],out,'javac',meta['environment']);assert r['exit_code']==0
rows=json.loads((root/'target/m2/stage35-builtin-selected-rows.json').read_bytes());(out/'selection.json').write_bytes(c.encoded(rows))
def run(row):
 name=row['id'];d=out/'cases'/name;d.mkdir(parents=True);source=root/row['input'];(d/'input.pkl').write_bytes(source.read_bytes())
 j=m.capture_java(meta,frozen,name,source,row['expression'],d); r=m.capture([str(frozen),str(source),row['expression']],d,'rust',meta['environment'])
 command=m.java_case_command(meta,frozen,name,source,row['expression']);command[1]='-Dpkl.m2.outcome='+str(d/'java-fixed.outcome.bin');command[command.index('M2LanguageProbe')]='Stage35BuiltinFixedProbe'
 f=m.capture(command,d,'java-fixed',meta['environment']);f['outcome_sha256']=oracle.sha256(d/'java-fixed.outcome.bin');(d/'java-fixed.process.json').write_bytes(c.encoded(f))
 outcome=m.status(row,j,r,*((d/f'{runner}.{ch}.bin').read_bytes() for runner in ['java','rust'] for ch in ['stdout','stderr']),(d/'java.outcome.bin').read_bytes())
 assert j['exit_code']==f['exit_code'];assert j['exit_code']==(0 if row['expected_outcome']=='success' else 1)
 stdout=(d/'java-fixed.stdout.bin').read_bytes();stderr=(d/'java-fixed.stderr.bin').read_bytes();payload=('value\t'+stdout.decode()) if f['exit_code']==0 else ('error\t'+stderr.decode())
 print(name,outcome,flush=True)
 return dict(id=name,input=row['input'],input_sha256=oracle.sha256(source),expression=row['expression'],status=outcome,java=j,rust=r,java_fixed=f,fixed_uri='file:///m2-platform.pkl',fixed_payload=payload)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,rows))
report=dict(scope='Fresh selected Java path and fixed-URI API-string captures against frozen Stage34 Rust; exploratory matrices remain separate preserved observations.',baseline_origin='target/m2/language-stage34-final-02/artifacts/language_probe',baseline_sha256=oracle.sha256(frozen),javac=dict(path=javac,sha256=oracle.sha256(Path(javac))),oracle=meta,results=results,files={str(p.relative_to(out)):oracle.sha256(p) for p in out.rglob('*') if p.is_file()})
(out/'report.json').write_bytes(c.encoded(report))
(out/'fixed-payloads.json').write_bytes(c.encoded([dict(id=r['id'],source=(root/r['input']).read_text(),sourceSha256=r['input_sha256'],expression=r['expression'],payload=r['fixed_payload']) for r in results]))
