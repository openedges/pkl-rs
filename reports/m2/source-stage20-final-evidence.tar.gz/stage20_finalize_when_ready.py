"""Seal the frozen Stage20 implementation after the complete Java process exits."""
from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd(); marker=root/'target/m2/language-stage20-command-final-02/process.json'
while not marker.is_file():time.sleep(1)
process=json.loads(marker.read_bytes());assert process['exit_code']==0,process
language=json.loads((root/'target/m2/language-stage20-final-02/report.json').read_bytes())
assert language['selected_count']==1860 and language['status_counts']=={'pass':1858,'oracle-error':1,'mismatch':1},language['status_counts']
assert all(r['status']=='pass' for r in language['metamorphic_results']) and len(language['metamorphic_results'])==69
command=[sys.executable,'target/m2/run_stage20_package.py','--output','target/m2/stage20-package-captured-final-02','--','--commit','c4e2a41e8391fe5ef031fc6fd5880cf46112c66e']
print('Full fresh Java acquisition completed; sealing final Stage20 evidence.',flush=True)
raise SystemExit(subprocess.run(command,cwd=root).returncode)
