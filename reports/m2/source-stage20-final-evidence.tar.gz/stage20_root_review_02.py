"""Record root independent review of the final Stage20 implementation and tests."""
from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd()
paths=subprocess.check_output(['git','diff','--name-only','8c8ec8d2d4c344c552658bfa0a10e2d11b9a4aba','--','crates/pkl-runtime/src'],text=True).splitlines()
paths+=['crates/pkl-runtime/tests/m2_nullable_defaults.rs','crates/pkl-runtime/tests/m2_generic_defaults_lifecycle.rs']
paths=[p for p in dict.fromkeys(paths) if (root/p).is_file()]
record=dict(status='pass',scope='Root independent source review of nullable runtime changes, crosscutting value consumers and the new focused/lifecycle assertions; root authored documentation and orchestration only.',source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},findings=['Pinned VmNull equality/hash/export and nullable creation checked against local Java0.32.0 sources.', 'Empty amendments return one default; nonempty amendments recursively unwrap; null-propagating member and call paths strip attachments.', 'Heap roots retain null payloads via heap_id, including active default results and captured environments; slot validation distinguishes internal null values from object handles.', 'Host-input/completion variant validation finding was corrected and has a dedicated regression.', 'Full workspace validation caught a 256KiB native-stack regression from recursive collection dispatch; the final implementation handles empty amendments without redispatch and preserves all original test conditions.'],limits=['Review does not establish full Java language compatibility or performance parity.', 'Parent null unwrapping and some metadata consumers still execute within a single VM instruction.', 'Direct new T, shared-let/Reference and remaining abstract-default diagnostics are separately retained gaps.'])
out=root/'target/m2/stage20-root-review-final-02.json'
with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('Recorded',len(paths),'reviewed source hashes.')
