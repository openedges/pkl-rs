"""Read-only Stage20 audit/sealing with explicit suite paths and exact Git sources.

Historical archives are immutable external dependencies, identified by hash/size.
Only new Stage20 directories are archived. --check-ready audits completed suites
without treating missing, running, or failed suites as passing.
"""
from pathlib import Path
from collections import Counter
import argparse, ast, datetime, hashlib, json, re, shutil, subprocess, sys, tarfile
sys.dont_write_bytecode = True
ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
REPORTS = ROOT / 'reports/m2'
sys.path[:0] = [str(ROOT / 'tools')]
BASELINE = '8c8ec8d2d4c344c552658bfa0a10e2d11b9a4aba'
SUITES = ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle', 'class-lifecycle', 'native-defaults']
KNOWN_LANGUAGE = {'error-cycle': 'oracle-error', 'error-remainder-zero': 'mismatch'}
GIT_CACHE = {}
SOURCE_PROOF = {}


def require(condition, message):
    if not condition: raise ValueError(message)


def load(path): return json.loads(Path(path).read_bytes())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def write(path, value):
    with path.open('xb') as stream: stream.write(encoded(value))
def identity(path, digest, size=None):
    require(sha(path) == digest and (size is None or path.stat().st_size == size), 'identity differs: ' + str(path))
def git_bytes(commit, path):
    if (commit,path) in GIT_CACHE:return GIT_CACHE[(commit,path)]
    result = subprocess.run(['git', 'show', commit + ':' + path], cwd=ROOT, capture_output=True)
    require(result.returncode == 0, 'missing immutable Git source: ' + commit + ':' + path)
    return result.stdout


def historical():
    path = REPORTS / 'stage19-final-summary.json'
    summary = load(path)
    records = dict(summary['archives'])
    exploration = summary.get('exploration', {})
    if exploration.get('archive'): records['exploration'] = exploration['archive']
    support = exploration.get('support_archives', exploration.get('archive_partition_verification', {}).get('support_archives', []))
    for index, row in enumerate(support):
        records['exploration-history-' + str(index + 1)] = row
    for row in records.values(): identity(ROOT / row['path'], row['sha256'], row['bytes'])
    return dict(summary_path=str(path.relative_to(ROOT)), summary_sha256=sha(path), archives=records,
                inherited_dependencies=summary.get('historical_dependencies', {}),
                scope='Immutable Stage19 archives and their recorded dependency chain remain external dependencies; no historical payload is rewritten or duplicated.')


def old_report(references, suite):
    with tarfile.open(ROOT / references['archives'][suite]['path']) as stream:
        return json.load(stream.extractfile('report.json'))



def remaining_scope(original,current,requirement):
    """Permit only the reviewed Stage20 historical-abort wording replacement."""
    old='General lazy generic declaration resolution, full alias-root substitution identity, imported generic declarations and original suite adapters remain open. Unbounded changing-argument recursion can overflow the host stack while cloning owned type metadata; the preserved abort is a known failure, while bounded yielding and cancellation have separate lifecycle checks.'
    new='General lazy generic declaration resolution, full alias-root substitution identity, imported generic declarations and original suite adapters remain open. The Stage 19 changing-argument native-stack abort remains preserved as historical failure evidence. Shared metadata now has bounded extended execution and cleanup checks; exact Java stack diagnostics, wall-time bounds, and metadata/output resource bounds remain unverified.'
    allowed={(name,old):new for name in ['semantic:type-aliases','semantic:types','semantic:generics','semantic:constraints']}
    position=0;updates=[]
    for text in original:
        target=text if text in current[position:] else allowed.get((requirement,text))
        require(target is not None and target in current[position:], 'open obligation removed: '+requirement+' '+text)
        position=current.index(target,position)+1
        if target!=text:updates.append(dict(requirement=requirement,original=text,current=target,scope='Historical abort retained; only bounded metadata execution and cleanup are covered. Exact Java stack diagnostics and wall-time/resource limits remain open.'))
    return updates



def prefetch_baseline():
    """Read immutable baseline blobs in one process instead of thousands."""
    listing=subprocess.check_output(['git','ls-tree','-r','--name-only',BASELINE,
        'tests/fixtures/m2','compatibility/m2-class-lifecycle','compatibility/m2-language.json',
        'compatibility/m2-mappings.json','tools/m1_platforms.py','crates/pkl-runtime/tests'],cwd=ROOT,text=True).splitlines()
    request=('\n'.join(BASELINE+':'+name for name in listing)+'\n').encode()
    result=subprocess.run(['git','cat-file','--batch'],input=request,cwd=ROOT,capture_output=True)
    require(result.returncode==0,'cannot batch read immutable baseline');position=0
    for name in listing:
        end=result.stdout.index(b'\n',position);fields=result.stdout[position:end].split()
        require(len(fields)==3 and fields[1]==b'blob','missing baseline blob '+name)
        size=int(fields[2]);GIT_CACHE[(BASELINE,name)]=result.stdout[end+1:end+1+size];position=end+size+2
    require(position==len(result.stdout),'extra baseline Git payload')


def baseline_contract():
    original = json.loads(git_bytes(BASELINE, 'tests/fixtures/m2/cases.json'))
    current = load(ROOT / 'tests/fixtures/m2/cases.json')
    require(current['cases'][:len(original['cases'])] == original['cases'], 'old selected case definitions/order changed')
    for name in dict.fromkeys(row['input'] for row in original['cases']):
        require((ROOT / name).read_bytes() == git_bytes(BASELINE, name), 'old selected input changed: ' + name)
    old = json.loads(git_bytes(BASELINE, 'compatibility/m2-class-lifecycle/manifest.json'))
    new = load(ROOT / 'compatibility/m2-class-lifecycle/manifest.json')
    require(new['sequences'][:len(old['sequences'])] == old['sequences'], 'old persistent definitions/order changed')
    for row in old['sequences']:
        for key in ['source', 'expressions']:
            name='compatibility/m2-class-lifecycle/'+row[key]
            require((ROOT/name).read_bytes()==git_bytes(BASELINE,name),'old persistent input changed: '+name)
    for field in ['schema','module_name','power_assertions','uri']:
        require(old[field]==new[field], 'persistent boundary changed: '+field)
    require(all(row in new['unexecuted_groups'] for row in old['unexecuted_groups']), 'old unexecuted persistent scope removed')
    def scenarios(raw):
        tree = ast.parse(raw)
        return next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == 'REQUIRED_SCENARIOS' for target in node.targets))
    before = scenarios(git_bytes(BASELINE, 'tools/m1_platforms.py'))
    after = scenarios((ROOT / 'tools/m1_platforms.py').read_bytes())
    require(before <= after, 'old platform scenario removed')
    inventories = {};remaining_updates=[];implementation_link_updates=[]
    for path, key in [('compatibility/m2-language.json', 'id'), ('compatibility/m2-mappings.json', 'requirement')]:
        a = json.loads(git_bytes(BASELINE, path)); b = load(ROOT / path)
        for field in ['schema_version','baseline','comparison_boundary','completion']:
            if field in a: require(a[field]==b[field], 'inventory completion/baseline boundary changed: '+field)
        oldrows = a['requirements']; newrows = b['requirements']; oldids = [r[key] for r in oldrows]
        require(len({r[key] for r in newrows}) == len(newrows), 'duplicate inventory requirement')
        preserved = [r for r in newrows if r[key] in set(oldids)]
        require([r[key] for r in preserved] == oldids, 'required inventory IDs/order changed')
        for first, last in zip(oldrows, preserved):
            for state in ['implementation', 'tests']:
                require(first[state]['state'] == last[state]['state'], 'original implementation/test state changed: ' + first[key])
            old_links={(r['path'],r['symbol']) for r in first['implementation']['links']}
            new_links={(r['path'],r['symbol']) for r in last['implementation']['links']}
            migration={('crates/pkl-runtime/src/vm/generics.rs','generic_default_value'):('crates/pkl-runtime/src/vm/generics.rs','step_generic_default')}
            for prior in sorted(old_links-new_links):
                replacement=migration.get(prior) if first[key] in ['semantic:lazy-evaluation','semantic:type-aliases','semantic:types','semantic:generics','semantic:constraints'] else None
                require(replacement in new_links,'old implementation link removed without exact reviewed migration: '+repr(prior))
                implementation_link_updates.append(dict(requirement=first[key],original=dict(path=prior[0],symbol=prior[1]),current=dict(path=replacement[0],symbol=replacement[1]),scope='Exact source-symbol migration to the resumable default constructor; requirement state, test IDs and remaining obligations are preserved.'))
            require(set(first['tests']['case_ids']) <= set(last['tests']['case_ids']), 'old test link removed')
            if 'remaining' in first:remaining_updates.extend(remaining_scope(first['remaining'],last['remaining'],first[key]))
            if 'reviewed_mapping' in first:
                before_mapping=first['reviewed_mapping'];after_mapping=last['reviewed_mapping']
                require(before_mapping['source']==after_mapping['source'],'reviewed mapping authority changed')
                prior_scope=before_mapping['scope'].replace('Recursive generic constraints remain open;', 'At Stage 15 recursive generic constraints remained open;')
                require(after_mapping['scope'].startswith(before_mapping['scope']) or after_mapping['scope'].startswith(prior_scope),'historical reviewed scope removed')
                remaining_updates.extend(remaining_scope(before_mapping['remaining'],after_mapping['remaining'],first[key]))
            if 'scope' in first:
                historical_scope=first['scope'].replace('Recursive generic constraints remain open;', 'At Stage 15 recursive generic constraints remained open;')
                require(last['scope'].startswith(first['scope']) or last['scope'].startswith(historical_scope), 'historical descriptive scope removed: '+first[key])
            ignored = {'implementation', 'tests', 'reviewed_mapping', 'remaining', 'scope'}
            if 'reviewed_mapping' not in first and 'reviewed_mapping' in last: ignored.add('reason')
            require({k:v for k,v in first.items() if k not in ignored} == {k:v for k,v in last.items() if k not in ignored},
                    'required definition changed: ' + first[key])
        if 'cases' in a:
            ids = {row['id'] for row in a['cases']}
            require([r for r in b['cases'] if r['id'] in ids] == a['cases'], 'old inventory case objects changed')
        inventories[path] = dict(original_requirements=len(oldrows), current_requirements=len(newrows),
                                original_ids_states_definitions_and_links_preserved=True)
    old_lifecycles = subprocess.check_output(['git','ls-tree','-r','--name-only',BASELINE,'crates/pkl-runtime/tests'],cwd=ROOT,text=True).splitlines()
    old_lifecycles = [name for name in old_lifecycles if 'lifecycle' in name]
    for name in old_lifecycles:
        require((ROOT/name).read_bytes()==git_bytes(BASELINE,name),'historical lifecycle assertion changed: '+name)
    return dict(historical_lifecycle_files_unchanged=len(old_lifecycles),commit=BASELINE, original_selected=len(original['cases']), current_selected=len(current['cases']),
                added_selected=len(current['cases'])-len(original['cases']),added_selected_outcomes=dict(Counter(row['expected_outcome'] for row in current['cases'][len(original['cases']):])),
                original_sequences=len(old['sequences']), current_sequences=len(new['sequences']),
                original_platform_scenarios=len(before), current_platform_scenarios=len(after), inventories=inventories,reviewed_remaining_updates=remaining_updates,reviewed_implementation_link_updates=implementation_link_updates)


def raw_process(process):
    require(process['status'] == 'executed', 'process did not execute')
    values = []
    for channel in ['stdout', 'stderr']:
        row = process[channel]; path = Path(row['path']); identity(path, row['sha256'], row['bytes']); values.append(path.read_bytes())
    return (process['exit_code'], *values)


def verify_validation(directory):
    report = load(directory / 'report.json')
    require(report['source_stability'] and report['source_sha256_before'] and report['source_sha256_before']==report['source_sha256_after'], 'required validation sources changed during acquisition')
    observed={p.relative_to(directory/'sources').as_posix() for p in (directory/'sources').rglob('*') if p.is_file()}
    require(observed==set(report['source_sha256_before']), 'validation source snapshot closure differs')
    for name,digest in report['source_sha256_before'].items():identity(directory/'sources'/name,digest)
    for label,row in report['identities'].items():
        require(row['exit_code']==0,'validation environment identification failed')
        for channel in ['stdout','stderr']:identity(directory/(label+'.'+channel+'.bin'),row[channel+'_sha256'])
    required = [['cargo','xtask','verify'],['cargo','fmt','--all','--','--check'],
        ['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],
        ['cargo','test','--workspace','--locked'],['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked']]
    require([r['command'] for r in report['checks'][:5]] == required and len(report['checks']) == 7, 'required checks changed')
    require(report['checks'][5]['command'][1:] == ['-m','unittest','discover','-s','tools/tests','-v'] and
            report['checks'][6]['command'][1:] == ['tools/m2_manifest.py','--check'], 'required Python/inventory checks changed')
    outputs = []
    for index, row in enumerate(report['checks']):
        require(row['exit_code'] == 0, 'required check failed: ' + repr(row['command']))
        text = ''
        for channel in ['stdout','stderr']:
            path = directory / f'{index}.{channel}.bin'; identity(path,row[channel+'_sha256']); text += path.read_text()
        outputs.append(text)
    rust = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', outputs[3])
    python = re.findall(r'Ran (\d+) tests? in ', outputs[5])
    require(rust and not any(int(r[1]) for r in rust) and len(python)==1 and re.search(r'\nOK\s*$',outputs[5]), 'missing successful test summaries')
    return dict(rust_passed=sum(int(r[0]) for r in rust), rust_intentionally_ignored=sum(int(r[2]) for r in rust),
                python_passed=int(python[0]), required_commands=7)


def verify_prior(directory, references):
    import m2_language
    report=load(directory/'report.json'); old=old_report(references,'language')
    original=json.loads(git_bytes(BASELINE,'tests/fixtures/m2/cases.json'))['cases']
    require([r['id'] for r in report['results']]==[r['id'] for r in original], 'prior replay case coverage changed')
    require(load(directory/'original-selection.json')['cases']==original,'prior selection snapshot changed')
    candidate=load(directory/'candidate.json'); identity(directory/'artifacts/language_probe',candidate['sha256'])
    build=candidate['build_provenance']
    require(build['source_binding']=='recorded-build' and build['source_stability'] and build['source_sha256_before']==build['source_sha256_after'] and build['build']['exit_code']==0 and not build['build']['timed_out'],'prior source/build binding failed')
    require(candidate['sha256']==build['artifacts']['language_probe']['frozen_sha256'], 'prior candidate differs from recorded build')
    baseline=load(directory/'baseline.json'); raw_path=ROOT/references['archives']['language']['path']
    with tarfile.open(raw_path) as stream:
        raw_report=stream.extractfile('report.json').read()
        require(hashlib.sha256(raw_report).hexdigest()==baseline['report_sha256'],'prior Java report dependency differs')
        for case,row,previous in zip(original,report['results'],old['results']):
            folder=directory/'cases'/row['id']; identity(folder/'input.pkl',old['source_sha256'][case['input']])
            channels=[]
            for channel in ['stdout','stderr']:
                raw=stream.extractfile('cases/'+row['id']+'/java.'+channel+'.bin').read()
                require(hashlib.sha256(raw).hexdigest()==previous['java'][channel+'_sha256'],'prior Java channel identity differs');channels.append(raw)
            for channel in ['stdout','stderr']:
                path=folder/('rust.'+channel+'.bin');identity(path,row['rust'][channel+'_sha256']);channels.append(path.read_bytes())
            require(load(folder/'rust.process.json')==row['rust'],'prior Rust process differs')
            outcome=stream.extractfile('cases/'+row['id']+'/java.outcome.bin').read()
            identity_outcome=hashlib.sha256(outcome).hexdigest();require(identity_outcome==previous['java']['outcome_sha256'],'prior Java outcome differs')
            verdict=m2_language.status(case,previous['java'],row['rust'],*channels,outcome)
            require(verdict==row['status']==previous['status'],'prior raw comparison changed: '+row['id'])
    require(report['status_counts']==dict(Counter(row['status'] for row in report['results'])),'prior status counts differ')
    return dict(count=len(report['results']),status_counts=report['status_counts'],java_dependency=references['archives']['language'])


def audit_suite(name,directory,references):
    import m1_frontend,m1_lifecycle,m1_platforms,m1_runtime,m2_class_lifecycle,m2_language
    if name=='language':
        report=m2_language.check_report(directory)
        require(m2_language.development_passes(report,directory),'language development gate failed')
        require(report['candidate']['source_binding']=='recorded-build','final language candidate lacks recorded build')
        failures={r['id']:r['status'] for r in report['results'] if r['status']!='pass'}
        require(set(failures)==set(KNOWN_LANGUAGE) and failures['error-remainder-zero']=='mismatch' and failures['error-cycle'] in ['oracle-error','mismatch'],'language known failure inventory changed')
        previous=old_report(references,'language')
        require(report['metamorphic_results'][:len(previous['metamorphic_results'])]==previous['metamorphic_results'], 'old metamorphic relations changed')
        return dict(selected_count=report['selected_count'],status_counts=report['status_counts'],inventory_counts=report['inventory_counts'],
                    metamorphic_relations=len(report['metamorphic_results']),metamorphic_passed=sum(r['status']=='pass' for r in report['metamorphic_results']),
                    full_gate_failure_count=len(report['full_gate_failures']),candidate=report['candidate'])
    if name=='validation': return verify_validation(directory)
    if name=='frontend':
        report=m1_frontend.check_report(directory)
        return dict(cases=len(report['results']),passed=sum(r['passed'] for r in report['results']))
    if name=='lifecycle':
        report=m1_lifecycle.check_report(directory)
        return dict(cases=len(report['cases']),compatibility_complete=report['compatibility_complete'],limitations=report['limitations'])
    if name=='class-lifecycle':
        report=m2_class_lifecycle.check_report(directory);require(m2_class_lifecycle.contract_passes(report),'persistent contract failed')
        old=old_report(references,'class-lifecycle');oldids={r['id'] for r in old['cases']};preserved=[r for r in report['cases'] if r['id'] in oldids]
        require(len(preserved)==len(old['cases']) and report['repetitions']==old['repetitions'],'old sequence coverage changed')
        for a,b in zip(old['cases'],preserved):
            require((a['id'],a['repetition'])==(b['id'],b['repetition']) and a['observations']['comparisons']==b['observations']['comparisons'],'old persistent observations changed')
            for engine in ['java','rust']:
                require(a['observations']['processes'][engine]['calls']==b['observations']['processes'][engine]['calls'],'old persistent raw channels changed')
        return dict(unique_sequences=len(report['cases'])//report['repetitions'],executions=len(report['cases']),
                    comparisons=sum(len(r['observations']['comparisons']) for r in report['cases']),unexecuted_groups=report['unexecuted_groups'])
    if name=='runtime':
        report=load(directory/'report.json');require([r['id'] for r in report['cases']]==list(m1_runtime.SUCCESS_CASES+m1_runtime.ERROR_CASES),'runtime coverage changed')
        counts=Counter()
        for row in report['cases']:
            java=raw_process(row['java']);rust=raw_process(row['rust']);require(row['raw_equal']==(java==rust),'runtime raw equality differs')
            expected='bounded-value-bytes-match' if row['id'] in m1_runtime.SUCCESS_CASES else ('diagnostic-bytes-match' if java==rust else 'diagnostic-byte-mismatch')
            require(row['status']==expected and (expected!='diagnostic-byte-mismatch' or row['id']=='forcing-cycle'),'new runtime mismatch');counts[expected]+=1
        return dict(status_counts=dict(counts),compatibility_complete=False)
    if name=='platforms':
        report=load(directory/'report.json');execution=load(directory/'execution/execution.json')
        require(report['execution']==execution,'platform execution metadata differs');m1_platforms.check_scenarios(execution)
        for target in ['node','browser']:require(execution[target+'Checks']==load(directory/('execution/'+target+'-checks.json')),'platform scenario capture differs')
        captures={key:(directory/path).read_bytes() for key,path in [('java','oracle-native/java.stdout.bin'),('rust','oracle-native/rust.stdout.bin'),('node','execution/node.stdout.bin'),('browser','execution/browser.stdout.bin')]}
        rows=m1_platforms.compare(m1_platforms.generate_cases()['cases'],captures)
        require(rows==report['comparisons'] and report['source_stability'] and m1_platforms.contract_matches(rows),'platform raw contract failed')
        for path,digest in report['artifacts'].items():identity(directory/path,digest)
        counts=dict(total=len(rows),shared_engine_passed=sum(r['shared_engine_match'] for r in rows),
                    oracle_passed={target:sum(r['oracle_matches'][target] for r in rows) for target in ['rust','node','browser']})
        for key,value in counts.items():require(report[key]==value,'platform exported count differs: '+key)
        require(set(report['known_gaps'])==m1_platforms.KNOWN_GAPS,'platform known gap inventory changed')
        for row in load(directory/'commands.json'):require(row['exit_code'] in ([0,1] if row['name']=='oracle-native' else [0]),'platform build/execution command failed')
        old=old_report(references,'platforms')
        for field in ['nodeChecks','browserChecks']:
            require([x for x in execution[field] if x in old['execution'][field]]==old['execution'][field],'old platform order changed')
        return dict(total=len(rows),shared_engine_passed=sum(r['shared_engine_match'] for r in rows),
                    oracle_passed={target:sum(r['oracle_matches'][target] for r in rows) for target in ['rust','node','browser']},
                    node_scenarios=len(execution['nodeChecks']),browser_scenarios=len(execution['browserChecks']),known_gaps=report['known_gaps'])
    if name=='prior-selection':return verify_prior(directory,references)
    if name=='release-build':
        report=load(directory/'candidate.json')
        require(report['source_binding']=='recorded-build' and report['source_stability'] and report['source_sha256_before']==report['source_sha256_after'], 'final release source/build binding failed')
        for label in ['build','rustc','cargo']:
            row=report[label];require(row['exit_code']==0 and not row['timed_out'], 'release build command failed')
            for channel in ['stdout','stderr']:identity(directory/(( 'cargo-version' if label=='cargo' else label)+'.'+channel+'.bin'),row[channel+'_sha256'])
        for label,row in report['artifacts'].items():identity(directory/'artifacts'/label,row['frozen_sha256'])
        return dict(artifacts=report['artifacts'],source_stability=True)
    if name=='native-defaults':
        report=load(directory/'report.json')
        require(report['source_stability'] and report['source_sha256_before']==report['source_sha256_after'],'focused lifecycle source drift')
        for source,digest in report['source_sha256_before'].items():identity(directory/'sources'/source,digest)
        for row in report['commands']:
            require(row['exit_code']==0 and not row['timed_out'],'focused native/tool command failed: '+row['name'])
            for channel in ['stdout','stderr']:identity(directory/(row['name']+'.'+channel+'.bin'),row[channel+'_sha256'])
        for row in report['artifacts']: identity(directory/row['path'],row['sha256'],row['bytes'])
        require(len(report['artifacts'])==1, 'focused lifecycle binary closure differs')
        executions=[row for row in report['commands'] if row['name']=='native-lifecycle']
        require(len(executions)==1 and executions[0]['command']==[
            str(directory/report['artifacts'][0]['path']),'--nocapture','--test-threads=1'],
            'focused native execution is filtered or does not use retained binary')
        raw=(directory/'native-lifecycle.stdout.bin').read_text();counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',raw)
        require(counts and not any(int(row[1]) for row in counts),'focused native lifecycle result missing')
        expected=(directory/'sources/crates/pkl-runtime/tests/m2_generic_defaults_lifecycle.rs').read_text().count('#[test]')
        require(int(counts[-1][0])==expected,'native lifecycle top-level count differs from recorded source')
        return dict(passed=expected,source_stability=True,conditions=report['conditions'])
    raise ValueError('unknown suite '+name)


def source_binding(commit,directories):
    require(re.fullmatch('[0-9a-f]{40}',commit) is not None,'full implementation commit required')
    kind=subprocess.check_output(['git','cat-file','-t',commit],cwd=ROOT)
    require(kind==b'commit\n','implementation identity is not a Git commit')
    copies=[];helpers=[]
    for suite,directory in directories.items():
        for source_root in [directory/'sources',directory/'oracle-native/sources']:
            if not source_root.is_dir():continue
            for path in sorted(source_root.rglob('*')):
                if not path.is_file():continue
                name=path.relative_to(source_root).as_posix()
                row=dict(suite=suite,path=name,snapshot=str(path.relative_to(ROOT)),sha256=sha(path),bytes=path.stat().st_size)
                if name.startswith('target/'):
                    helpers.append(row);continue
                require(not name.startswith('external/'),'upstream source copies need explicit gitlink proof')
                copies.append(row)
    names=sorted({r['path'] for r in copies});require(names,'no final source snapshots')
    request=('\n'.join(commit+':'+name for name in names)+'\n').encode()
    process=subprocess.run(['git','cat-file','--batch'],input=request,cwd=ROOT,capture_output=True)
    require(process.returncode==0,'Git source proof command failed')
    SOURCE_PROOF.update(command=['git','cat-file','--batch'],request=request,stdout=process.stdout,stderr=process.stderr,exit_code=process.returncode)
    position=0;blobs={};blob_ids={}
    for name in names:
        end=process.stdout.index(b'\n',position);fields=process.stdout[position:end].split()
        require(len(fields)==3 and fields[1]==b'blob','missing implementation source '+name)
        size=int(fields[2]);blobs[name]=process.stdout[end+1:end+1+size];blob_ids[name]=fields[0].decode();position=end+size+2
    require(position==len(process.stdout),'extra Git source proof bytes')
    for row in copies:
        row['git_blob']=blob_ids[row['path']]
        require((ROOT/row['snapshot']).read_bytes()==blobs[row['path']],'snapshot differs from exact commit: '+row['snapshot'])
        require((ROOT/row['path']).read_bytes()==blobs[row['path']],'working source differs from exact commit: '+row['path'])
    return dict(implementation_commit=commit,source_snapshot_copies=len(copies),unique_source_files=len(names),
                upstream_source_snapshot_copies=0,upstream_blob_proof_claimed=False,copies=copies,
                untracked_helpers_with_separate_hashes=helpers,git_request_sha256=hashlib.sha256(request).hexdigest(),
                git_response_sha256=hashlib.sha256(process.stdout).hexdigest(),scope='Only final project source copies enumerated here equal exact implementation Git bytes. Historical focused/exploratory sources retain separate provenance.')



def exploration_audit():
    import evidence
    index=load(BASE/'stage20-exploration-index.json')
    for row in [index['main'],*index.get('additional_archives',[])]:
        path=ROOT/row['path'];identity(path,row['sha256'],row['bytes']);evidence.verify(path)
    for row in index.get('history_dependencies',[]):identity(ROOT/row['path'],row['sha256'],row['bytes'])
    return dict(index_path='target/m2/stage20-exploration-index.json',
                index_sha256=sha(BASE/'stage20-exploration-index.json'),**index)


def archive(directory,name):
    import evidence
    path=REPORTS/(name+'-stage20-final-evidence.tar.gz');require(not path.exists(),'refusing existing archive '+str(path))
    evidence.create(directory,path,['build/*','__pycache__/*','*/__pycache__/*'])
    with tarfile.open(path) as stream:count=len(stream.getmembers())
    return dict(path=str(path.relative_to(ROOT)),sha256=sha(path),bytes=path.stat().st_size,files_including_inventory=count,inventory_verified=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--check-ready',action='store_true');parser.add_argument('--commit');parser.add_argument('--output',type=Path)
    for suite in SUITES:
        default=BASE/('stage20-release-probe-build-final-01' if suite=='release-build' else suite+'-stage20-final-02')
        parser.add_argument('--'+suite,type=Path,default=default)
    args=parser.parse_args();directories={name:getattr(args,name.replace('-','_')).resolve() for name in SUITES}
    references=historical();prefetch_baseline();preservation=baseline_contract();audits={};missing=[]
    for name,directory in directories.items():
        marker='candidate.json' if name=='release-build' else 'report.json'
        if not (directory/marker).is_file():missing.append(name);continue
        if name=='validation':
            provisional=load(directory/marker)
            if len(provisional.get('checks',[]))<7 and all(row['exit_code']==0 for row in provisional.get('checks',[])) and provisional.get('source_stability'):
                missing.append(name);continue
        audits[name]=audit_suite(name,directory,references)
    exploration=exploration_audit() if (BASE/'stage20-exploration-index.json').is_file() else None
    if exploration is None:missing.append('exploration')
    require(args.check_ready or not missing,'missing final suites: '+repr(missing))
    binding=source_binding(args.commit,{name:directories[name] for name in audits}) if args.commit and audits else None
    result=dict(schema=1,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='partial-readiness' if missing else 'ready',
                implementation_commit=args.commit,missing_or_running_suites=missing,completed_suites=audits,preservation=preservation,
                packaging_helper=dict(executed_path=str(Path(__file__).resolve().relative_to(ROOT)),sha256=sha(Path(__file__)),invocation=sys.argv),
                source_binding=binding,historical_dependencies=references,exploration=exploration,captured_binaries_executed_by_packaging=False,
                compatibility_complete=False,performance_targets_established=False,
                known_unverified_scope=[
                  'Nullable default values retain attached defaults in the evaluator-owned heap. Generic default/type identity gaps outside the selected cases, synchronous metadata latency, Java stack diagnostics, parser/compiler depth, and arbitrary resource growth remain unverified.',
                  'Whole-language, complete API, Linux/Windows release execution and every-workload performance/memory gates remain open.'
                ])
    if args.check_ready:
        if args.output:write(args.output,result)
        print(json.dumps({k:v for k,v in result.items() if k not in ['completed_suites','source_binding','historical_dependencies']},sort_keys=True));return
    require(args.commit,'--commit required for final sealing')
    review_names=['stage20-runtime-review-final-02.json','stage20-lifecycle-review-final-02.json','stage20-root-review-final-02.json']
    result['reviews']={}
    committed_hashes={r['path']:r['sha256'] for r in binding['copies']}
    for name in review_names:
        path=BASE/name;data=load(path)
        require(data['status']=='pass','review is not passing: '+name)
        for source,digest in data['source_sha256'].items():
            identity(ROOT/source,digest)
            require(committed_hashes.get(source)==digest,'review source differs from implementation: '+source)
        result['reviews'][name]=dict(path=str(path.relative_to(ROOT)),sha256=sha(path),
            source_count=len(data['source_sha256']),scope=data['scope'],implementation_commit=args.commit)
    evidence_review_path=BASE/'stage20-evidence-review-final-02.json'
    evidence_review=load(evidence_review_path)
    build_review=evidence_review['root_recorded_build']
    require(evidence_review['status']=='pass-for-focused-final-artifact-replays','focused evidence review incomplete')
    require(build_review['source_sha256']==load(directories['language']/'report.json')['source_sha256'],
            'focused evidence review source closure differs')
    identity(directories['language']/'artifacts/language_probe',build_review['candidate_sha256'])
    identity(directories['language']/'build.process.json',build_review['build_process_sha256'])
    for row in [*evidence_review['scalar_replays'],evidence_review['persistent']]:
        identity(ROOT/row['path']/'report.json',row['report_sha256'])
        require(row['status']=='pass','focused replay review did not pass')
    result['evidence_review']=dict(path=str(evidence_review_path.relative_to(ROOT)),sha256=sha(evidence_review_path),
        scope=evidence_review['scope'],binding_scope='Focused raw-comparison review and final artifact/source identities; not an independent production source review.')
    exploration_audit_path=BASE/'stage20-exploration-independent-audit.json'
    independent_exploration=load(exploration_audit_path)
    require(independent_exploration['status']=='pass' and not independent_exploration['captured_artifacts_executed'],
            'independent exploration audit incomplete')
    result['exploration_independent_audit']=dict(path=str(exploration_audit_path.relative_to(ROOT)),sha256=sha(exploration_audit_path),
        scope=independent_exploration['scope'],original_paths=independent_exploration['original_paths'],
        inventory_files=independent_exploration['inventory_files'],excluded_cache_files=independent_exploration['excluded_cache_files'])
    destination=BASE/'source-stage20-final-evidence';destination.mkdir(exist_ok=False)
    write(destination/'source-verification.json',binding);write(destination/'audit.json',result)
    proof=destination/'git-proof';proof.mkdir()
    for field in ['request','stdout','stderr']:(proof/(field+'.bin')).write_bytes(SOURCE_PROOF[field])
    write(proof/'process.json',dict(command=SOURCE_PROOF['command'],exit_code=SOURCE_PROOF['exit_code'],
        sha256={field:hashlib.sha256(SOURCE_PROOF[field]).hexdigest() for field in ['request','stdout','stderr']}))
    command=['git','cat-file','-p',args.commit];process=subprocess.run(command,cwd=ROOT,capture_output=True)
    require(process.returncode==0,'cannot capture implementation commit object')
    (proof/'commit.stdout.bin').write_bytes(process.stdout);(proof/'commit.stderr.bin').write_bytes(process.stderr)
    write(proof/'commit.process.json',dict(command=command,exit_code=process.returncode,stdout_sha256=hashlib.sha256(process.stdout).hexdigest(),stderr_sha256=hashlib.sha256(process.stderr).hexdigest()))
    for name in sorted({r['path'] for r in binding['copies']}):
        target=destination/'implementation-sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes())
    subprocess.run(['git','show','--no-patch','--format=fuller',args.commit],cwd=ROOT,check=True,stdout=(destination/'implementation-commit.txt').open('wb'))
    gates=destination/'gates';gates.mkdir();gate_rows=[]
    for gate,tool,mode,suite,expected in [
        ('report','m2_language.py','report','language',0),
        ('development','m2_language.py','development','language',0),
        ('subset','m2_language.py','subset','language',1),
        ('full','m2_language.py','full','language',1),
        ('class-report','m2_class_lifecycle.py','report','class-lifecycle',0),
        ('class-contract','m2_class_lifecycle.py','contract','class-lifecycle',0),
    ]:
        command=[sys.executable,'tools/'+tool,'--verify-'+mode,str(directories[suite])]
        process=subprocess.run(command,cwd=ROOT,capture_output=True)
        row=dict(gate=gate,command=command,exit_code=process.returncode,expected_exit_code=expected)
        for channel in ['stdout','stderr']:
            raw=getattr(process,channel);(gates/(gate+'.'+channel+'.bin')).write_bytes(raw);row[channel+'_sha256']=hashlib.sha256(raw).hexdigest()
        gate_rows.append(row);require(process.returncode==expected,'unexpected gate outcome '+gate)
    write(gates/'report.json',gate_rows)
    result['gates']=gate_rows
    shutil.copy2(Path(__file__),destination/'package_stage20_final.py')
    execution=Path(__file__).resolve().parent.parent
    if (execution/'invocation.json').is_file():
        helper_proof=destination/'packaging-execution-preflight';helper_proof.mkdir()
        for name in ['invocation.json','runner.py']:shutil.copy2(execution/name,helper_proof/name)
    for name in [*review_names,'stage20-exploration-independent-audit.json','stage20_exploration_independent_audit.py','stage20-evidence-review-final-02.json','stage20-final-01-superseded.json','stage20-exploration-index.json','stage20_root_review.py','stage20_root_review_02.py','stage20_finalize_when_ready.py','run_stage20_package.py']:
        source=BASE/name
        if source.is_file():shutil.copy2(source,destination/name)
    write(destination/'immutable-lifecycle-baseline.json',preservation)
    for history in sorted(BASE.glob('stage20-readiness-captured-*')):
        if history.is_dir() and (history/'process.json').is_file():
            shutil.copytree(history,destination/'helper-history'/history.name)
    for name in ['stage20-superseded-final-01.json','stage20-superseded-final-02.json']:
        if (BASE/name).is_file():shutil.copy2(BASE/name,destination/name)
    # Preserve only new focused sources/history that are not duplicated by a core suite.
    archives={name:archive(directory,name) for name,directory in directories.items()}
    archives['source']=archive(destination,'source')
    archives['exploration']=exploration['main']
    for i,row in enumerate(exploration.get('additional_archives',[])):archives['exploration-support-'+str(i+1)]=row
    result['archives']=archives
    result['source_binding']={k:v for k,v in binding.items() if k not in ['copies','untracked_helpers_with_separate_hashes']}
    result['source_binding']['helper_snapshot_copies']=len(binding['untracked_helpers_with_separate_hashes'])
    output=args.output or REPORTS/'stage20-final-summary.json';write(output,result)
    print(json.dumps(dict(status='sealed',implementation_commit=args.commit,archives=archives),sort_keys=True))


if __name__=='__main__':main()
