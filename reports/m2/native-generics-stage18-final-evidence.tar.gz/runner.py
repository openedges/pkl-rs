"""Capture focused lifecycle checks with exact pre/post sources and build provenance."""
from pathlib import Path
import sys, subprocess, hashlib, json, platform, datetime, re, shutil
root=Path.cwd(); out=root/sys.argv[1]; out.mkdir(parents=True,exist_ok=False)
paths=sorted(p for folder in ['crates/pkl-runtime/src','crates/pkl-runtime/tests'] for p in (root/folder).rglob('*') if p.is_file())
paths += [root/p for p in ['Cargo.lock','Cargo.toml','rust-toolchain.toml','crates/pkl-runtime/Cargo.toml']]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p.relative_to(root)):digest(p) for p in paths}
for p in paths:
 dest=out/'sources'/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
commands=[['git','rev-parse','HEAD'],['git','status','--porcelain=v1'],['rustc','-Vv'],['cargo','test','-p','pkl-runtime','--locked','--test','m2_generic_nodes_lifecycle','--','--nocapture']]
rows=[]
for i,command in enumerate(commands):
 result=subprocess.run(command,cwd=root,capture_output=True)
 for channel,raw in [('stdout',result.stdout),('stderr',result.stderr)]: (out/f'{i}.{channel}.bin').write_bytes(raw)
 rows.append(dict(command=command,exit_code=result.returncode,stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest()))
 print(result.stdout.decode(errors='replace')+result.stderr.decode(errors='replace'),flush=True)
artifacts=[]
for name in re.findall(r'\((target/debug/deps/[^)]+)\)', result.stderr.decode()):
 p=root/name
 if p.is_file():
  dest=out/'artifacts'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest)
  artifacts.append(dict(path=str(dest.relative_to(out)),sha256=digest(dest),bytes=dest.stat().st_size))
(out/'report.json').write_text(json.dumps(dict(artifacts=artifacts,host=platform.platform(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),commands=rows,source_sha256_before=before,source_sha256_after={str(p.relative_to(root)):digest(p) for p in paths}),indent=2)+'\n')
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
(out/'evidence-sha256.json').write_text(json.dumps({str(p.relative_to(out)):digest(p) for p in sorted(out.rglob('*')) if p.is_file()},indent=2)+'\n')
raise SystemExit(rows[-1]['exit_code'])
