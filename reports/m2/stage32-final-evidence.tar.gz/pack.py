"""Seal explicitly listed Stage 32 evidence roots without traversing build caches."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / "tools"))
import evidence


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    args = parser.parse_args()
    config_bytes = args.config.read_bytes()
    config = json.loads(config_bytes)
    commit = config["implementation_commit"]
    assert subprocess.check_output(["git", "rev-parse", "HEAD"]).decode().strip() == commit
    staging = ROOT / config["staging"]
    staging.mkdir(parents=True, exist_ok=False)
    (staging / "config.json").write_bytes(config_bytes)
    (staging / "pack.py").write_bytes(Path(__file__).read_bytes())
    omitted = {str((ROOT / name).absolute()) for name in config["omitted_build_caches"]}
    seen_omissions = set()
    source_map = {}
    original_rows = []
    copied_roots = []

    def copy_file(path, destination):
        assert not path.is_symlink() and path.is_file(), path
        data = path.read_bytes()
        destination.parent.mkdir(parents=True, exist_ok=True)
        assert not destination.exists(), destination
        destination.write_bytes(data)
        original_rows.append(dict(original=str(path.relative_to(ROOT)),
                                  archived=str(destination.relative_to(staging)),
                                  bytes=len(data), sha256=sha(data)))
        assert path.read_bytes() == data, f"source changed while copying: {path}"

    def copy_tree(path, destination):
        if str(path.absolute()) in omitted:
            assert path.is_dir() and not path.is_symlink(), path
            seen_omissions.add(str(path.absolute()))
            return
        assert not path.is_symlink(), path
        if path.is_file():
            copy_file(path, destination)
            return
        assert path.is_dir(), path
        destination.mkdir(parents=True, exist_ok=False)
        with os.scandir(path) as children:
            entries = sorted(children, key=lambda child: child.name)
        for child in entries:
            copy_tree(Path(child.path), destination / child.name)

    roots = config["roots"]
    assert len(set(roots.values())) == len(roots)
    for label, relative in roots.items():
        assert label and "/" not in label and label not in {".", ".."}
        origin = ROOT / relative
        destination = staging / "raw" / label
        copy_tree(origin, destination)
        copied_roots.append(dict(label=label, original=relative,
                                 archived=str(destination.relative_to(staging))))
    assert seen_omissions == omitted, (seen_omissions, omitted)

    # Bind the final validation snapshot to actual Git blob bytes, not timestamps
    # or the dirty/clean state recorded before the implementation commit.
    validation = json.loads((ROOT / config["validation"] / "report.json").read_bytes())
    assert validation["source_stability"]
    source_map = validation["source_sha256_before"]
    assert source_map == validation["source_sha256_after"]
    paths = sorted(source_map)
    request = "".join(f"{commit}:{name}\n" for name in paths).encode()
    raw = subprocess.check_output(["git", "cat-file", "--batch"], input=request)
    (staging / "git-blob-request.bin").write_bytes(request)
    (staging / "git-blob-response.bin").write_bytes(raw)
    cursor = 0
    binding = []
    for name in paths:
        end = raw.index(b"\n", cursor)
        blob, kind, length = raw[cursor:end].split()
        assert kind == b"blob"
        length = int(length)
        start = end + 1
        data = raw[start:start + length]
        assert len(data) == length and raw[start + length:start + length + 1] == b"\n"
        cursor = start + length + 1
        assert sha(data) == source_map[name], f"final source differs from Git: {name}"
        assert sha((ROOT / name).read_bytes()) == source_map[name]
        assert sha((ROOT / config["validation"] / "sources" / name).read_bytes()) == source_map[name]
        binding.append(dict(path=name, git_blob=blob.decode(), bytes=length, sha256=sha(data)))
    assert cursor == len(raw)
    (staging / "git-source-binding.json").write_bytes(encode(dict(commit=commit, files=binding)))
    dependencies = []
    for item in config["historical_dependencies"]:
        data = (ROOT / item["path"]).read_bytes()
        assert len(data) == item["bytes"] and sha(data) == item["sha256"], item["path"]
        dependencies.append(item)
    inventory = dict(schema_version=1, implementation_commit=commit,
                     roots=copied_roots, original_files=original_rows,
                     omitted_build_caches=config["omitted_build_caches"],
                     omission_scope="Direct directories pruned before enumeration; no payload counts or hashes claimed.",
                     historical_dependencies=dependencies,
                     compatibility_complete=False, performance_targets_established=False)
    (staging / "PACKAGING.json").write_bytes(encode(inventory))
    destination = ROOT / config["archive"]
    assert not destination.exists(), destination
    evidence.create(staging, destination, [])
    # Copying and archive creation must not change the original acquisitions.
    for row in original_rows:
        data = (ROOT / row["original"]).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
    archive_data = destination.read_bytes()
    result = dict(archive=config["archive"], bytes=len(archive_data), sha256=sha(archive_data),
                  implementation_commit=commit, original_files=len(original_rows),
                  git_bound_files=len(binding), roots=len(copied_roots),
                  omitted_build_caches=config["omitted_build_caches"])
    result_path = ROOT / config["pack_result"]
    assert not result_path.exists()
    result_path.write_bytes(encode(result))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
