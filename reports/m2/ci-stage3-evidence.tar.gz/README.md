# M2 stage 3 CI evidence

The `package` directory retains original GitHub artifact ZIPs, metadata, and
independent exact-commit verifiers. Follow `package/README.md` to repeat the check.
`offline-proof` contains the raw process capture and result from a successful
portable rerun of that unchanged package. The outer EVIDENCE.json covers both.

Known mismatches and incomplete full language/API/performance requirements remain
failures and incomplete scope. CI success establishes the development contract.
