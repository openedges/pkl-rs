from pathlib import Path
import hashlib,json,sys
R=Path.cwd();O=R/'target/m2/stage38-review-native-02';sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes());x=rd(O/'report.json');matrix=rd(O/'matrix.json');assert len(matrix)==65 and len(x['results'])==130 and x['status_counts']=={'pass':78,'mismatch':52}
assert x['source_stability'] and x['binary_stability'] and x['controlled_fixture_stability'];assert sha(O/'scalar_context_probe')==x['binary_sha256']
for rel,h in x['source_hashes_before'].items():assert sha(O/'sources'/rel)==h==x['source_hashes_after'][rel]
for c in x['commands']:
 assert c['record']['status']=='executed' and c['record']['exit_code']==0 and c['source_hashes_after']==x['source_hashes_before']
 for ch in ['stdout','stderr']:benchmark.raw_channel(c['record'],ch)
channels=equal=0
for row in x['results']:
 d=O/'cases'/row['id']/str(row['repeat']);assert rd(d/'comparison.json')==row;case=next(c for c in matrix if c['id']==row['id']);assert sha(d.parent/'input.pkl')==case['source_sha256'] and (d.parent/'input.pkl').read_bytes()==case['source'].encode();context=rd(d.parent/'context.json');assert context['module_uri']==case['module_uri'] and context['module_name']==case['module_name'];assert row['native']['command'][-3:]==[case['module_uri'],case['module_name'],case['expression']]
 assert row['native']['status']=='executed' and row['native']['exit_code'] in [0,1] and sha(d/'java.status.bin')==row['java_status_sha256'] and sha(d/'status.bin')==row['native_status_sha256']
 for ch in ['stdout','stderr']:benchmark.raw_channel(row['native'],ch);benchmark.raw_channel(row['java'],ch)
 for comp in row['comparisons']:
  channel=comp['channel'];expected=d/('java.'+channel);actual=d/('native.'+channel) if channel in ['stdout.bin','stderr.bin'] else d/channel
  assert sha(expected)==comp['expected_sha256'] and sha(actual)==comp['actual_sha256'];match=expected.read_bytes()==actual.read_bytes();assert match==comp['raw_equal'];channels+=1;equal+=match
 match=all(c['raw_equal'] for c in row['comparisons']) and row['status_category_match'] and row['native']['exit_code']==row['java']['exit_code'];assert match==(row['status']=='pass')
for case in matrix:
 a,b=[r for r in x['results'] if r['id']==case['id']];assert a['status']==b['status'] and [c['actual_sha256'] for c in a['comparisons']]==[c['actual_sha256'] for c in b['comparisons']]
known={'uri-unpaired-surrogate','env-missing-nullable','prop-missing-nullable','env-hierarchical-missing-nullable','prop-normalized-hierarchical-nullable','nullable-denied-life','nullable-denied-http','nullable-malformed','file-absolute-text','file-absolute-uri','file-absolute-normalized-uri','file-relative-text','file-relative-normalized-uri','file-relative-space','file-relative-literal-percent','file-absolute-encoded-space','file-relative-empty','file-relative-missing','file-relative-missing-nullable','read-null-type-before-uri','env-path-nullable','env-home-nullable','prop-user-home-nullable','prop-java-version-nullable','file-encoded-dot-uri','file-encoded-dot-text'}
assert {r['id'] for r in x['results'] if r['status']=='mismatch'}==known
benchmark.write_json(O/'audit-report.json',{'scope':'Independent integrity audit of exact pre-nullability exploratory native candidate; all26 failing contracts retained. Source stability is specific to this historical build, not current Stage38 source.','passed':True,'report_sha256':sha(O/'report.json'),'binary_sha256':sha(O/'scalar_context_probe'),'source_count':len(x['source_hashes_before']),'source_stable_during_build_and_execution':True,'raw_channels_verified':channels,'raw_channels_equal':equal,'case_count':65,'executions':130,'status_counts':x['status_counts'],'mismatch_case_ids':sorted(known),'repeat_raw_stability':True,'controlled_fixture_stability':True,'compatibility_complete':False,'script_sha256':sha(Path(__file__))})
print('audit passed')
