# Stage38 core 동결 기록

## 변경

- `host/resources.rs`에서 URI-like 문자열과 escape하는 상대 경로를 구분한다. authored 문자열, 해석된 URI, 정규화된 URI를 분리하며 구문 검사가 정책 검사보다 먼저 실행된다. 현재 상대 해석은 authored file source를 대상으로 한다.
- `ReadRequest`는 원래 operand와 선언 source URI, nullable 여부를 보관한다. source URI는 일반 canonical ModuleKey 구현을 의미하지 않는다. 명시적 Host가 받는 원래 URI 문자열은 변경하지 않았다.
- scalar `evaluation::poll`은 기본 프로필 결과를 `Vm::resume`으로 전달한다. 실제 읽기 프레임, 강제 평가 실패 정리, 재시도·GC 동작을 공용 VM이 처리한다. 기본 프로필의 env/prop 설정은 Java scalar helper와 같이 빈 map이다.
- `ReadResourceOrNull`은 찾지 못한 env/prop 결과만 null로 바꾼다. 구문·정책·reader 오류를 null로 숨기지 않는다. ordinary/nullable 전용 AST와 quoted 이름 구분은 B 소유 변경이다.
- 읽기 operand의 잘못된 타입은 공용 nonforcing 진단 renderer의 80-unit 표시 경계를 사용한다. 타입 검사 전에 URI 처리를 시작하지 않는다.
- implicit method lookup의 실제 opcode provenance로 qualification 없는 오류와 lexical/local/base 후보를 구성한다. explicit module lookup은 상속 메서드 목록과 scoped suggestions를 표시한다. 진단용 이름/시그니처 catalogue가 해당 builtin 본문 구현을 뜻하지 않는다.

A 소유 변경 9개 경로의 기준은 `owned-source-manifest.json`이다. setup에서 복사한 Stage37 변경은 Stage38 변경으로 다시 계산하지 않았다. seed 목록에 없는 기존 경로는 setup base commit의 원래 bytes를 기준으로 기록했다. Git mutation이나 MAIN/이전 worktree 소스 변경은 수행하지 않았다.

## 검증

`workspace-report.json`의 `cargo test --workspace --locked`는 exit 0이다. `checks-report.json`의 fmt, workspace all-targets Clippy(-D warnings), xtask verify, wasm32 runtime check도 모두 exit 0이다. 두 실행 집합 모두 runtime src/tests의 전후 SHA256이 일치한다. Rust/Cargo 버전 출력과 전체 stdout/stderr를 보관했다.

추가 raw 증거는 서로 다른 후보/경계를 구분한다.

- C `stage38-review-native-03`: 원래 65개 × 2회 중 51개 일치, 14개 미일치. generic method 보완 이전의 역사적 후보이다. 남은 14개는 허용 파일 I/O 13개와 unmatched UTF-16 URI 1개이며 원본은 유지했다.
- C `stage38-review-uri-edges-native-01`: 같은 역사적 artifact로 일반 결과 4개 × 2회 raw 일치, HTTP request 생성의 Java 내부 오류 3개 × 2회는 oracle-error로 보존했다. 현재 소스와 artifact 동일성을 주장하지 않는다.
- B `stage38-frontend-validation-03`: 마지막 core 후보를 사용한 36개 원본의 exit/stdout/stderr 전체가 Java와 일치했다. original/read-shadow/power assertion/generic-method 입력을 유지했다.
- A `stage38-uri-primitive-oracle-01`: pinned IoUtils와 oracle JDK를 직접 호출한 URI primitive 관측 22개이다. evaluator나 I/O 호환성 증거로 확대하지 않는다.

처음의 stale no-Host 기대 때문에 실패한 전체 runtime 실행과 closure drop Clippy 실패는 validation01/03에 그대로 보관했다. 원래 scalar sequence 소스는 변경하지 않았고, C의 새 Java same-evaluator 오류/42/재시도 전체 바이트를 근거로 test 기대를 갱신했다. 마지막 workspace 실행은 이후 소스로 다시 수행했다.

## 남은 의무

허용된 파일·네트워크·package/modulepath reader, resource cache, module loader/canonical ModuleKey, configurable security manager, custom Host의 일반 missing-resource completion, read glob, IPv6/network-path 및 복합 HTTP URI 선행검사, unmatched UTF-16 URI/오류 transport는 완료하지 않았다. 허용됨을 실제 I/O 지원으로 바꾸거나 missing으로 가장하지 않았다. 일부 요청 형식에서 발생하는 Java 내부 오류도 성공으로 집계하지 않았다.

동결된 소스에 대한 실제 플랫폼 취득과 최종 MAIN 전체 언어/순차 비교는 root/C의 별도 실행이다. 이 기록은 M2 완료나 전체 Java API/URI 호환성 선언이 아니다.
