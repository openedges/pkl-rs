#!/usr/bin/env python3
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import collections,hashlib,json,os,shutil,sys
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes())
origin=ROOT/'target/m2/stage38-review-uri-edges-01';candidate=ROOT/'target/m2/stage38-review-native-03';out=ROOT/'target/m2/stage38-review-uri-edges-native-01';out.mkdir(exist_ok=False)
assert sha(origin/'closure.json')=='d1753aa184afc724d921f4c6921203dd8594d2f46b000b26f4c9e70252142585'
closure=rd(origin/'closure.json')
for rel,h in closure['files_sha256'].items():assert sha(origin/rel)==h,(rel,'origin hash')
report=rd(candidate/'report.json');assert report['source_stability'] and report['binary_stability'];assert sha(candidate/'scalar_context_probe')==report['binary_sha256']
shutil.copyfile(candidate/'scalar_context_probe',out/'scalar_context_probe');binary=out/'scalar_context_probe';binary.chmod(0o755);shutil.copyfile(__file__,out/'acquire.py');shutil.copyfile(candidate/'report.json',out/'candidate-report.json');shutil.copyfile(origin/'closure.json',out/'oracle-closure.json')
rows=rd(origin/'manifest.json');benchmark.write_json(out/'matrix.json',rows)
for c in rows:
 d=out/'cases'/c['id'];d.mkdir(parents=True);shutil.copyfile(origin/'cases'/c['id']/'input.pkl',d/'input.pkl');assert (d/'input.pkl').read_bytes()==c['source'].encode()
def run(pair):
 c,n=pair;old=origin/'cases'/c['id']/str(n);d=out/'cases'/c['id']/str(n);d.mkdir();java=rd(old/'record.json');rec=benchmark.capture([str(binary),str(d),str(d.parent/'input.pkl'),c['module_uri'],'stage38-uri-edges',c['expression']],ROOT,dict(os.environ),d/'native',timeout=90)
 status=(old/'status.bin').read_bytes();(d/'java.status.bin').write_bytes(status);category=b'success\n' if status==b'success\n' else b'error\n' if status==b'pkl-exception\torg.pkl.core.PklException\n' else None
 expected={'stdout.bin':benchmark.raw_channel(java['process'],'stdout'),'stderr.bin':benchmark.raw_channel(java['process'],'stderr'),'value.code-units.bin':(old/'value.code-units.bin').read_bytes(),'error.code-units.bin':(old/'error.code-units.bin').read_bytes()};comparisons=[]
 for channel,data in expected.items():
  (d/('java.'+channel)).write_bytes(data);actual=benchmark.raw_channel(rec,channel[:-4]) if channel in ['stdout.bin','stderr.bin'] else (d/channel).read_bytes() if (d/channel).exists() else None
  if channel in ['stdout.bin','stderr.bin']:(d/('native.'+channel)).write_bytes(actual)
  comparisons.append(dict(channel=channel,expected_sha256=hashlib.sha256(data).hexdigest(),actual_sha256=hashlib.sha256(actual).hexdigest() if actual is not None else None,raw_equal=data==actual))
 native_status=(d/'status.bin').read_bytes() if (d/'status.bin').exists() else None;admitted=rec['status']=='executed' and rec['exit_code'] in [0,1] and native_status in [b'success\n',b'error\n'];valid=category is not None and java['process']['status']=='executed';match=valid and admitted and native_status==category and rec['exit_code']==java['process']['exit_code'] and all(x['raw_equal'] for x in comparisons)
 result=dict(id=c['id'],repeat=n,status='oracle-error' if not valid else 'acquisition-failed' if not admitted else 'pass' if match else 'mismatch',native=rec,java=java['process'],java_status=status.decode(),native_status=native_status.decode() if native_status else None,comparisons=comparisons);benchmark.write_json(d/'comparison.json',result);return result
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,[(c,n) for c in rows for n in [0,1]]))
r=dict(scope='Additional7 exact Java source/URI contracts; same immutable native03 artifact, no Java rerun or source build. JavaBug originals remain oracle-error.',case_count=7,repetitions=2,results=results,status_counts=dict(collections.Counter(x['status'] for x in results)),candidate_report_sha256=sha(candidate/'report.json'),candidate_source_hashes=report['source_hashes_before'],binary_sha256=report['binary_sha256'],binary_stability=sha(binary)==report['binary_sha256'],oracle_closure_sha256=sha(origin/'closure.json'),oracle_unchanged=all(sha(origin/rel)==h for rel,h in closure['files_sha256'].items()),source_binding='Historical native03 build snapshot, not current source claim.')
benchmark.write_json(out/'report.json',r);print(json.dumps({k:r[k] for k in ['status_counts','binary_stability','oracle_unchanged']},indent=2));raise SystemExit(int(any(x['status']!='pass' for x in results)))
