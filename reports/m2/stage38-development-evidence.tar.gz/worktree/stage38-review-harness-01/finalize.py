from pathlib import Path
import json,hashlib,os,sys,shutil
R=Path.cwd();sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes())
# Verify standalone edge comparisons independently of acquisition's recorded booleans.
O=R/'target/m2/stage38-review-uri-edges-native-01';r=rd(O/'report.json');assert r['status_counts']=={'oracle-error':6,'pass':8};assert sha(O/'scalar_context_probe')==r['binary_sha256'];assert sha(O/'candidate-report.json')==r['candidate_report_sha256'];assert sha(O/'oracle-closure.json')==r['oracle_closure_sha256'];n=equal=0
for row in r['results']:
 d=O/'cases'/row['id']/str(row['repeat']);assert rd(d/'comparison.json')==row;assert row['native']['status']=='executed' and row['native']['exit_code'] in [0,1]
 for ch in ['stdout','stderr']:benchmark.raw_channel(row['native'],ch);benchmark.raw_channel(row['java'],ch)
 for c in row['comparisons']:
  expected=d/('java.'+c['channel']);actual=d/('native.'+c['channel']) if c['channel'] in ['stdout.bin','stderr.bin'] else d/c['channel'];assert sha(expected)==c['expected_sha256'] and sha(actual)==c['actual_sha256'];assert (expected.read_bytes()==actual.read_bytes())==c['raw_equal'];n+=1;equal+=c['raw_equal']
 assert (row['status']=='oracle-error')==(row['java_status']!='pkl-exception\torg.pkl.core.PklException\n')
 if row['status']=='pass':assert all(c['raw_equal'] for c in row['comparisons'])
for case in rd(O/'matrix.json'):
 a,b=[x for x in r['results'] if x['id']==case['id']];assert a['status']==b['status'];assert [x['actual_sha256'] for x in a['comparisons']]==[x['actual_sha256'] for x in b['comparisons']]
benchmark.write_json(O/'audit-report.json',dict(passed=True,scope='No rerun: full edge7 raw/hash/repeat/artifact audit;3JavaBug contracts remain oracle-error.',raw_channels_verified=n,raw_channels_equal=equal,status_counts=r['status_counts'],report_sha256=sha(O/'report.json'),binary_sha256=sha(O/'scalar_context_probe')))
# Verify Java sequence originals, source/URI/helper/JDK artifact and all8calls.
O=R/'target/m2/stage38-review-sequence-oracle-01';r=rd(O/'report.json');assert sha(O/'input.pkl')==r['source_sha256'];assert sha(O/'Stage38SequenceProbe.java')==r['helper_sha256'];assert sha(O/'run.py')==r['driver_sha256'];assert sha(Path(rd(O/'oracle.json')['artifact']))==r['jar_sha256'];assert r['module_uri']=='file:///m2-platform.pkl' and r['expressions']==['first','first','second','first']
for rec in [r['compile'],*r['processes']]:
 assert rec['status']=='executed' and rec['exit_code']==0
 for ch in ['stdout','stderr']:benchmark.raw_channel(rec,ch)
for rel,h in r['raw_sha256'].items():assert sha(O/rel)==h
for p in (O/'0').glob('*.bin'):assert p.read_bytes()==(O/'1'/p.name).read_bytes()
for repeat in [0,1]:
 d=O/str(repeat)
 for call in [0,1,3]:
  assert (d/f'call-{call}.status.bin').read_bytes()==b'pkl-exception\torg.pkl.core.PklException\n';assert not (d/f'call-{call}.stdout.bin').read_bytes();assert (d/f'call-{call}.stderr.bin').read_bytes()==(d/'call-0.stderr.bin').read_bytes()
 assert (d/'call-2.stdout.bin').read_bytes()==b'42' and (d/'call-2.status.bin').read_bytes()==b'success\n'
benchmark.write_json(O/'audit-report.json',dict(passed=True,scope='Fresh Java2evaluators×4calls; exact source/URI and fullraw repeated errors/value isolation verified. Identical error does not prove observable reader call counts.',report_sha256=sha(O/'report.json'),source_sha256=r['source_sha256'],evaluators=2,calls=8,raw_files_verified=len(r['raw_sha256']),repeat_raw_stability=True))
# Preserve terminal wrapper logs before recording immutable closed roots.
for name,stem in [('stage38-review-native-01','native-01'),('stage38-review-native-02','native-02'),('stage38-review-native-03','native-03'),('stage38-review-uri-edges-native-01','edges-native-01')]:
 for channel in ['stdout','stderr']:
  p=R/'target/m2/stage38-review-harness-01'/f'{stem}.{channel}.log'
  if p.exists():shutil.copyfile(p,R/'target/m2'/name/f'wrapper.{channel}.log')
for name in ['stage38-review-native-01','stage38-review-native-02','stage38-review-native-03','stage38-review-uri-edges-native-01','stage38-review-sequence-oracle-01']:
 O=R/'target/m2'/name;assert not (O/'closure.json').exists();files={}
 for directory,dirs,names in os.walk(O,topdown=True):
  dirs[:]=sorted(d for d in dirs if d not in {'target','node_modules','.cache','.git'} and not d.endswith('-cargo'))
  for filename in sorted(names):
   p=Path(directory)/filename;assert not p.is_symlink();files[str(p.relative_to(O))]=sha(p)
 benchmark.write_json(O/'closure.json',dict(frozen=True,scope='Closed independent Stage38 development acquisition; historical outcomes/failures preserved; no full Host or M4 claim.',files_sha256=files,excluded_before_traversal=['target','node_modules','.cache','.git','*-cargo'],terminal=True));print(name,len(files),sha(O/'closure.json'))
