# Stage38 독립 검토와 원시 비교 harness

## 검토 범위와 현재 상태

생산 소스는 읽기 전용으로 검토합니다. MAIN의 동결된 Java 65개 계약과 기존 원본은 변경하거나 다시 실행하지 않았습니다. `matrix-validation.json`은 원래 130개 Java 캡처의 manifest·입력·채널 해시를 읽기 전용으로 확인한 결과이며, 후보 실행이나 Rust 호환성 결과가 아닙니다.

동결 설계는 URI 파싱→선언 모듈 기준 해석→정규화→policy→reader 순서, authored URI와 정규화 URI의 분리, `Vm::resume`을 통한 실제 read 위치 보존을 적절히 구분합니다. 다음 경계는 구현·보고에서 명시해야 합니다.

- 거부는 정규화 URI를, 찾지 못함은 authored URI를 표시합니다. `prop:/a/../missing`과 `life:/a/../text`를 같은 문자열 필드로 덮어쓰면 안 됩니다.
- `file-relative-empty`의 실제 Java 값은 `module.pkl\n`입니다. 빈 상대 참조는 모듈 파일이 아니라 그 디렉터리로 해석되며 파일 URL reader의 directory listing을 읽습니다. 원래 controlled directory에 새 파일을 쓰면 이 기대값이 바뀝니다. harness는 입력 복사본을 새 결과 디렉터리에만 씁니다.
- 상대 path의 `%`, 공백 escaping과 절대 URI의 percent escape는 다릅니다. `#`와 `?`도 path 생성 branch에서 escape되지만 이 두 추가 문자는 현재 65개 matrix의 실행 근거가 아닙니다. 검증되지 않은 일반 URI 호환성으로 확대하지 않습니다.
- `RuntimeSource.uri`는 항상 canonical ModuleKey가 아닙니다. `stdlib_sources.rs`는 base/ref에 실제 `pkl:` 식별자가 아닌 GitHub 진단 URL을 저장합니다. 현재 authored file module 범위를 넘어 사용할 때에는 canonical 선언 모듈 식별자와 표시 URI를 분리해야 합니다.
- 현재 VM의 unmatched UTF-16 URI 제한과 `RuntimeError.message: String` 경계는 Java `D800` unit을 보존했다고 주장할 수 없습니다. 원본 UTF-8의 `?`와 UTF-16 `D800` snapshot을 모두 비교하며, 제한을 새 문자열 치환으로 숨기지 않습니다.
- `read?` parser, 허용된 file/network/package I/O, 일반 cache/loader가 미구현이면 원본 계약을 유지한 불일치입니다. policy가 허용한다는 것과 reader가 구현되었다는 것은 다릅니다.
- custom Host의 기존 URI/응답 계약에 기본 scalar policy를 암묵적으로 적용하지 않습니다. 기본 경계의 오류만 정상 completion으로 전달하고 취소·frame 합성으로 대체하지 않습니다.

## native 비교 도구

`scalar_context_probe.rs`는 공통 `scalar_expression_with_options`를 직접 호출하는 target 전용 adapter입니다. 새 정책·URI 구현이나 Java fallback이 없습니다. 물리 입력 파일과 원래 `ModuleSource` URI를 별도 인수로 받습니다. 기존 `language_probe`는 입력 경로를 canonicalize해 URI를 만들기 때문에 이 matrix를 그대로 실행하는 데 사용할 수 없습니다.

후보가 준비되면 아래 명령으로 새 디렉터리를 생성합니다.

```sh
python3 target/m2/stage38-review-harness-01/run.py \
  --output target/m2/stage38-review-native-01
```

- 원래 MAIN의 `stage38-default-host-oracle-01/closure.json` 해시와 세 개 원본 manifest를 검증합니다.
- 65개 계약과 각각의 Java 두 반복을 모두 유지합니다. 원래 source bytes·URI·expression은 바꾸지 않습니다. 두 module name 문맥도 명시적으로 기록합니다.
- 새 `target/m2/stage38-review-cargo` cache에서 pinned Rust release library를 build하고 adapter를 연결합니다. 코드와 증거는 cache 바깥에 둡니다. snapshot 순회는 `target`, `node_modules`, `.cache`, `.git`를 하강 전에 제외합니다.
- 명령·도구 버전·build 원시 출력·생산 소스 해시 전후·adapter artifact 해시·controlled fixture 해시를 보존합니다. source drift가 있으면 최종 호환성 근거로 삼지 않습니다.
- 각 계약을 새 native process에서 두 번 평가하고 exit code, 전체 stdout/stderr, value/error UTF-16 snapshot을 Java 원본과 비교합니다. JVM exception class marker는 원시 provenance로 보존하며 Rust에 가짜 JVM class를 쓰지 않습니다. success/error 상태는 기존 scalar API처럼 exit와 `Result` 종류를 함께 확인합니다.
- parser·URI·I/O·UTF-16 미지원, panic, 누락 출력과 raw 불일치는 삭제·정규화·예외 통과로 처리하지 않습니다. 모든 계약이 실제 통과하지 않으면 strict exit는 1입니다.

현재 실행한 것은 Python syntax 검사와 원본 matrix loader 해시 검증뿐입니다. Rust build/후보 실행은 아직 수행하지 않았습니다.

## 실제 Node/Chromium 후속 비교

A 소스가 안정되면 native 결과에 사용한 동일 생산 snapshot으로 실제 NAPI/Wasm artifact를 한 번 build하고 고정 복사본을 사용합니다. 기존 API `evaluateLanguage(source, uri, moduleName, expression, false)`가 각 계약의 URI를 그대로 받을 수 있으므로 binding 또는 생산 도구를 바꿀 필요가 없습니다.

ignored JS driver는 원래 65개 계약 전체를 두 플랫폼에서 각각 두 fresh 호출로 실행해야 합니다. scalar 결과/오류의 전체 JS 문자열, UTF-16 code units와 원시 UTF-8 transport bytes를 별도로 보존합니다. lone surrogate의 Java `?`와 JS replacement 경계를 자동 치환하여 통과시키지 않습니다. 브라우저 파일 reader/VFS 부재와 다른 미지원은 원본 불일치로 유지합니다.

artifact·Playwright pin·실제 browser/Node 실행 파일 및 버전·source/fixture 전후 hash를 기록하고, architecture와 Java 호환성을 분리합니다. compilation만으로 Wasm 실행 통과를 선언하지 않습니다. 같은 artifact의 표준 platform 계약과 실제 custom Host 42개 회귀도 별도 유지하며 중복 release build를 피합니다.
