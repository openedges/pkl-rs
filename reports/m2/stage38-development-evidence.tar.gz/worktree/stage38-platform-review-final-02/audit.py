from pathlib import Path
import json,hashlib,sys
R=Path.cwd();O=R/'target/m2/stage38-platform-review-final-02';sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes());B=R/'target/m2/stage38-platforms-final-01';build=rd(B/'report.json');process=rd(R/'target/m2/stage38-portable-processes-final-02/report.json');assert process['artifact_stability'] and process['source_stability'];assert process['artifacts_before']==process['artifacts_after']==build['artifacts'];assert set(process['intentional_tool_changes_since_build_snapshot'])=={'tools/platform/compare-language-cases.mjs','tools/platform/compare-language-cases.test.mjs'}
for p,h in process['source_hashes_before'].items():
 assert sha(R/p)==h==process['source_hashes_after'][p]
 if p not in process['intentional_tool_changes_since_build_snapshot']:assert h==build['source_hashes'][p]
for p,h in build['artifacts'].items():assert sha(B/p)==h
assert [c['record']['exit_code'] for c in process['commands']]==[1,0,1]
for c in process['commands']:
 assert c['record']['status']=='executed'
 for ch in ['stdout','stderr']:benchmark.raw_channel(c['record'],ch)
def node_utf8(units):
 # Python surrogatepass preserves unmatched units; replace only those remaining
 # after proper pairs have decoded, matching the JS UTF8 encoder boundary.
 text=units.decode('utf-16-be','surrogatepass')
 return ''.join('\ufffd' if 0xd800<=ord(c)<=0xdfff else c for c in text).encode('utf-8')
summary={};channels=0;divergent=[]
for name,count,expected in [('read91',91,(87,1,3)),('trace18',18,(18,0,0)),('repeat20',20,(18,2,0))]:
 D=R/'target/m2'/f'stage38-{name}-platform-final-02';P=R/'target/m2'/f'stage38-{name}-platform-final-01';r=rd(D/'execution.json');old=rd(P/'execution.json');fixture=rd(D/'fixtures.json');assert r['caseCount']==count and not r['infrastructureErrors'] and not r['browserErrors'] and not r['stability']['changed'];assert fixture==rd(P/'fixtures.json');assert r['playwright']==r['playwrightCore']==r['playwrightPin']=='1.64.1';assert r['browser']=='156.0.8078.4'
 for p,h in r['artifactHashes'].items():assert sha(R/p)==h
 if name=='read91':assert fixture['cases']==rd(R/'target/m2/stage38-platform-oracle-01/fixed-payloads.json')
 for target,t in r['targets'].items():
  assert t['complete'] and len(t['results'])==count*2;assert (t['passingCases'],t['mismatchingCases'],t['oracleErrorCases'])==expected
  seen=set()
  for row in t['results']:
   pair=(row['id'],row['repetition']);assert pair not in seen;seen.add(pair);case=next(x for x in fixture['cases'] if x['id']==row['id']);prior=next(x for x in old['targets'][target]['results'] if (x['id'],x['repetition'])==pair)
   assert row['powerAssertions']==case.get('powerAssertions',fixture['context']['powerAssertions']);e=D/row['expectedFile'];a=D/row['actualFile'];assert sha(e)==row['expectedSha256']==row['originalJavaUtf8Sha256'];assert sha(a)==row['actualSha256'];assert row['originalJavaUtf8File']==row['expectedFile'];assert e.read_bytes()==case.get('expectedValue',case.get('expectedError')).encode();original_equal=e.read_bytes()==a.read_bytes();assert original_equal==row['originalJavaUtf8Match']==row['utf8Match'];channels+=2
   # Actual runtime and original Java byte channels did not change; the tool
   # comparison contract is the only authorized correction.
   assert sha(e)==prior['expectedSha256'] and sha(a)==prior['actualSha256'];assert row['status']==prior['status']
   units_equal=True;node_expected=e.read_bytes()
   if 'expectedCodeUnitsHex' in case:
    assert row['comparisonBoundary']=='js-string-api';eu=D/row['expectedCodeUnitsFile'];au=D/row['actualCodeUnitsFile'];ne=D/row['expectedNodeUtf8File'];assert sha(eu)==row['expectedCodeUnitsSha256'];assert sha(au)==row['actualCodeUnitsSha256'];assert eu.read_bytes().hex()==case['expectedCodeUnitsHex'];assert node_utf8(eu.read_bytes())==ne.read_bytes();assert sha(ne)==row['expectedNodeUtf8Sha256'];assert node_utf8(au.read_bytes())==a.read_bytes();units_equal=eu.read_bytes()==au.read_bytes();assert units_equal==row['codeUnitsMatch'];node_expected=ne.read_bytes();channels+=3
   else:assert row['comparisonBoundary']=='raw-utf8' and row['expectedNodeUtf8File'] is None and row['codeUnitsMatch'] is None
   assert (node_expected==a.read_bytes())==row['nodeUtf8Match'];divergence=e.read_bytes()!=node_expected;assert divergence==row['javaVsNodeSerializationDivergence'];match=row['actualStatus']==row['expectedStatus'] and row['nodeUtf8Match'] and units_equal;assert match==row['rawMatch'];assert row['status']==('oracle-error' if case.get('oracleError') else 'pass' if match else 'mismatch')
   if divergence:divergent.append(dict(target=target,id=row['id'],repeat=row['repetition'],status=row['status'],originalJavaUtf8Match=row['originalJavaUtf8Match'],nodeUtf8Match=row['nodeUtf8Match'],codeUnitsMatch=row['codeUnitsMatch']))
  assert t['passingExecutions']==sum(x['status']=='pass' for x in t['results']);assert not any(x['status']=='pass' and x['oracleError'] for x in t['results'])
  if name=='read91':assert t['mismatchIds']==['read-stage38-uri-unpaired-surrogate'];assert len([x for x in t['results'] if x['powerAssertions'] and x['status']=='pass'])==4
 summary[name]={k:{p:v[p] for p in ['passingCases','mismatchingCases','oracleErrorCases','executions']} for k,v in r['targets'].items()}
assert len(divergent)==4 and {x['id'] for x in divergent}=={'read-stage38-uri-unpaired-surrogate'}
closed={'stage38-platforms-final-01':'d4f50769706f563fe2e04f761b50f4e92e764a767a14da7b065556eb870c2e91','stage38-read91-platform-final-01':'add9e28d7c9c537ccb167295ef32ee92056de55ea857d137073b9df8d62f8f8d','stage38-trace18-platform-final-01':'5432018a8a07ecc12b7d7baa2ca0b1823228f5fbbe7d6ea658835c9b4e27b4cc','stage38-repeat20-platform-final-01':'cd1b9c7ba700cd50f0ef4998c3cfa209b1f04961b3e0fe50b6406058dfcfa4ff','stage38-trace42-platform-final-01':'5b02216d947aa68729721dc2d52bf0be97216f102b7749c0dc06cfafa9f18214','stage38-platform-review-final-01':'cf153d84615dcd4c4468d95cfa5ca2b12429c09ae52de252e6359b4e0347d209'}
for name,h in closed.items():assert sha(R/'target/m2'/name/'closure.json')==h
benchmark.write_json(O/'report.json',dict(passed=True,scope='Independent corrected JS-string API audit: exactUTF16+NodeUTF8 derived from Javaunits, originalJavaUTF8 retained separately; no cross-encoding byte parity claim. All final01captures remain historical.',platforms=summary,raw_payload_files_verified=channels,serialization_divergent_executions=divergent,source_stability=True,runtime_source_matches_build_snapshot=True,artifact_stability=True,artifacts=build['artifacts'],historical_closure_identities_unchanged=closed,source_session42_rerun=False,script_sha256=sha(Path(__file__))))
print('audit passed',channels)
