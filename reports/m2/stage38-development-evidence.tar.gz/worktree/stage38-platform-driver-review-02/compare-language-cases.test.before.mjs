// Synthetic driver logic checks; these are not Java compatibility observations.
import assert from 'node:assert/strict';
import test from 'node:test';
import { compareLanguagePayload, evaluateLanguageFixtures } from './compare-language-cases.mjs';

test('explicit power flags override context in both directions and absent flags inherit', () => {
  for (const inherited of [false, true]) {
    const observed = [];
    const api = { evaluateLanguage(_source, _uri, _module, expression, power) {
      observed.push({ expression, power });
      return '7';
    } };
    const fixtures = [{ id: 'inherit', source: '', expression: 'inherit' },
      { id: 'false', source: '', expression: 'false', powerAssertions: false },
      { id: 'true', source: '', expression: 'true', powerAssertions: true }];
    const results = evaluateLanguageFixtures(api, fixtures, { uri: 'file:///synthetic.pkl',
      moduleName: 'synthetic', powerAssertions: inherited }, 1);
    assert.deepEqual(observed, [{ expression: 'inherit', power: inherited },
      { expression: 'false', power: false }, { expression: 'true', power: true }]);
    assert.equal(results.length, 3);
  }
});

test('UTF16 comparison distinguishes lone units despite identical UTF8 replacement', () => {
  const observed = compareLanguagePayload({ expectedValue: '\ud800', expectedCodeUnitsHex: 'd800' }, 'value', '\udc00');
  assert.equal(observed.utf8Match, true);
  assert.equal(observed.codeUnitsMatch, false);
  assert.equal(observed.status, 'mismatch');
  assert.equal(observed.actualCodeUnits.toString('hex'), 'dc00');
});

test('Java UTF8 question-mark boundary does not conceal an expected lone surrogate', () => {
  const observed = compareLanguagePayload({ expectedError: '?', expectedCodeUnitsHex: 'd800' }, 'error', '?');
  assert.equal(observed.utf8Match, true);
  assert.equal(observed.codeUnitsMatch, false);
  assert.equal(observed.status, 'mismatch');
});

test('matching internal-error payload is always oracle-error and never pass', () => {
  const observed = compareLanguagePayload({ expectedError: 'synthetic internal error', oracleError: true,
    expectedCodeUnitsHex: Buffer.from('synthetic internal error', 'utf16le').swap16().toString('hex') },
  'error', 'synthetic internal error');
  assert.equal(observed.rawMatch, true);
  assert.equal(observed.status, 'oracle-error');
  assert.equal([observed].filter(row => row.status === 'pass').length, 0);
});

test('unmarked legacy fixtures retain UTF8 pass/mismatch classification', () => {
  assert.equal(compareLanguagePayload({ expectedValue: '7' }, 'value', '7').status, 'pass');
  assert.equal(compareLanguagePayload({ expectedError: 'error' }, 'error', 'different').status, 'mismatch');
  assert.equal(compareLanguagePayload({ expectedError: 'error' }, 'value', 'error').status, 'mismatch');
});
