from pathlib import Path
import json,hashlib,collections,sys
R=Path.cwd();O=R/'target/m2/stage38-platform-review-final-01';sys.path.insert(0,str(R/'tools'));import benchmark,m1_platforms
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes());B=R/'target/m2/stage38-platforms-final-01';s=rd(B/'report.json');assert s['source_stability'];assert s['total']==s['shared_engine_passed']==6078;assert s['oracle_passed']==dict(rust=6076,node=6076,browser=6076);assert s['experiment_contract_status']=='pass' and s['compatibility_status']=='fail';m1_platforms.check_scenarios(s['execution'])
for p,h in s['source_hashes'].items():assert sha(R/p)==sha(B/'sources'/p)==h
for p,h in s['artifacts'].items():assert sha(B/p)==h
captures={'java':(B/'oracle-native/java.stdout.bin').read_bytes(),'rust':(B/'oracle-native/rust.stdout.bin').read_bytes(),'node':(B/'execution/node.stdout.bin').read_bytes(),'browser':(B/'execution/browser.stdout.bin').read_bytes()};assert m1_platforms.compare(m1_platforms.generate_cases()['cases'],captures)==s['comparisons']
A=R/'target/m2/stage38-core-validation-04/owned-source-manifest.json';assert sha(A)=='26d2697f1b3b4d222a508a85cc321cefaff68054abd2d524943b6c249e1e79fb'
for p,v in rd(A)['files'].items():
 assert sha(R/p)==v['stage38_sha256']
 if p in s['source_hashes']:assert s['source_hashes'][p]==v['stage38_sha256']
counts={};raw_channels=0
for name,count,expected in [('read91',91,(87,1,3)),('trace18',18,(18,0,0)),('repeat20',20,(18,2,0))]:
 D=R/'target/m2'/f'stage38-{name}-platform-final-01';r=rd(D/'execution.json');fixture=rd(D/'fixtures.json');assert r['caseCount']==count and not r['infrastructureErrors'] and not r['browserErrors'] and not r['stability']['changed'];assert r['artifactHashes'][str((B/'pkl_napi.node').relative_to(R))]==s['artifacts']['pkl_napi.node'];assert r['artifactHashes'][str((B/'wasm/pkl_wasm_bg.wasm').relative_to(R))]==s['artifacts']['wasm/pkl_wasm_bg.wasm'];assert r['playwright']==r['playwrightCore']==r['playwrightPin']=='1.64.1' and r['browser']=='156.0.8078.4'
 for p,h in r['artifactHashes'].items():assert sha(R/p)==h
 for c in fixture['cases']:assert sha(R/'tests/fixtures/m2'/f"{c['id']}.pkl")==c['sourceSha256']
 if name=='read91':assert fixture['cases']==rd(R/'target/m2/stage38-platform-oracle-01/fixed-payloads.json')
 for target,t in r['targets'].items():
  assert t['complete'] and len(t['results'])==count*2;assert (t['passingCases'],t['mismatchingCases'],t['oracleErrorCases'])==expected;seen=set()
  for row in t['results']:
   key=(row['id'],row['repetition']);assert key not in seen;seen.add(key);c=next(x for x in fixture['cases'] if x['id']==row['id']);assert row['powerAssertions']==c.get('powerAssertions',fixture['context']['powerAssertions']);expected_file=D/row['expectedFile'];actual_file=D/row['actualFile'];assert sha(expected_file)==row['expectedSha256'] and sha(actual_file)==row['actualSha256'];assert expected_file.read_bytes()==c.get('expectedValue',c.get('expectedError')).encode();utf8=expected_file.read_bytes()==actual_file.read_bytes();assert utf8==row['utf8Match'];raw_channels+=2;units=True
   if 'expectedCodeUnitsHex' in c:
    e=D/row['expectedCodeUnitsFile'];a=D/row['actualCodeUnitsFile'];assert sha(e)==row['expectedCodeUnitsSha256'] and sha(a)==row['actualCodeUnitsSha256'];assert e.read_bytes().hex()==c['expectedCodeUnitsHex'];units=e.read_bytes()==a.read_bytes();assert units==row['codeUnitsMatch'];raw_channels+=2
   match=row['actualStatus']==row['expectedStatus'] and utf8 and units;assert match==row['rawMatch'];assert row['status']==('oracle-error' if c.get('oracleError') else 'pass' if match else 'mismatch')
  assert t['passingExecutions']==sum(x['status']=='pass' for x in t['results']);assert not any(x['status']=='pass' and x['oracleError'] for x in t['results'])
  if name=='read91':assert t['mismatchIds']==['read-stage38-uri-unpaired-surrogate'];assert len([x for x in t['results'] if x['powerAssertions'] and x['status']=='pass'])==4
 counts[name]={k:{p:v[p] for p in ['passingCases','mismatchingCases','oracleErrorCases','executions']} for k,v in r['targets'].items()}
D=R/'target/m2/stage38-trace42-platform-final-01';r=rd(D/'execution.json');assert r['selectedCases']==42 and r['architecturePassed'] and not r['compatibilityComplete'];assert not r['infrastructureErrors'] and not r['browserErrors'] and not r['changedInputs'];assert r['oracleReportSha256']=='4d271632fa08f044386c5f752e926e945ee25ef2e8f6e7e02fc5cdd30f5b12a3'
for p,h in r['artifactAndInputHashes'].items():assert sha(Path(p))==h
for target,t in r['targets'].items():
 assert t['complete'] and len(t['results'])==84 and t['statusCounts']=={'pass':54,'oracle-error':30}
 for row in t['results']:
  dest=D/target/row['id']/str(row['repeat']);assert rd(dest/'result.json')==row;assert not row['acquisitionError'];assert row['architecture']['retainedEventBytesStable'];assert (row['status']=='oracle-error')==bool(row['oracleErrors'])
  for c in row['comparisons']:
   a=dest/c['name'];e=dest/('java.'+c['name']);assert (sha(e) if e.exists() else None)==c['expectedSha256'];assert (sha(a) if a.exists() else None)==c['actualSha256'];equal=e.exists() and a.exists() and e.read_bytes()==a.read_bytes();assert equal==c['rawEqual'];raw_channels+=2
  if row['status']=='pass':assert all(x['rawEqual'] for x in row['comparisons'])
counts['trace42']={k:v['statusCounts'] for k,v in r['targets'].items()}
process=rd(R/'target/m2/stage38-portable-processes-final-01/report.json');assert process['source_stability'] and process['artifact_stability'];assert [c['record']['exit_code'] for c in process['commands']]==[1,0,1,1]
for c in process['commands']:
 assert c['record']['status']=='executed'
 for channel in ['stdout','stderr']:benchmark.raw_channel(c['record'],channel)
benchmark.write_json(O/'report.json',dict(passed=True,scope='Independent no-rerun raw/source/artifact audit of standardplatform +91new +18trace +20repeat +42source-session. Java bugs/UTF16/regex failures remain explicit.',standard_report_sha256=sha(B/'report.json'),standard=dict(scenarios=92,shared=6078,java_each=6076,contract='pass',compatibility='fail'),platforms=counts,raw_payload_files_verified=raw_channels,source_stability=True,artifact_stability=True,artifacts=s['artifacts'],A_owned_source_manifest_sha256=sha(A),browser=r['browser'],playwright=r['playwright'],script_sha256=sha(Path(__file__))))
print('audit passed',raw_channels)
