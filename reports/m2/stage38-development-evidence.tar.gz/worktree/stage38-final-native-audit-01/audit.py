from pathlib import Path
import json, hashlib, collections, os, sys, subprocess, shutil
R=Path.cwd();O=R/'target/m2/stage38-final-native-audit-01';sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rd=lambda p:json.loads(p.read_bytes())

def raw_audit(root):
 r=rd(root/'report.json');counts=collections.Counter();equal=channels=0
 matrix={c['id']:c for c in rd(root/'matrix.json')};assert len(matrix)==r['case_count']
 for row in r['results']:
  d=root/'cases'/row['id']/str(row['repeat']);case=matrix[row['id']]
  assert rd(d/'comparison.json')==row
  assert (d.parent/'input.pkl').read_bytes()==case['source'].encode()
  native=row['native'];java=row['java']
  assert native['status']=='executed' and native['exit_code'] in (0,1)
  for process in (native,java):
   for ch in ('stdout','stderr'):benchmark.raw_channel(process,ch)
  js=(d/'java.status.bin').read_bytes();ns=(d/'status.bin').read_bytes()
  category=b'success\n' if js==b'success\n' else b'error\n' if js==b'pkl-exception\torg.pkl.core.PklException\n' else None
  if 'captures' in case:
   old=Path(case['captures'][row['repeat']]['directory'])
   assert (old/'status.bin').read_bytes()==js
   assert row['java']==case['captures'][row['repeat']]['record']['process']
  else:old=R/'target/m2/stage38-review-uri-edges-01/cases'/row['id']/str(row['repeat'])
  for c in row['comparisons']:
   ch=c['channel'];expected=d/('java.'+ch);actual=d/('native.'+ch) if ch in ('stdout.bin','stderr.bin') else d/ch
   assert sha(expected)==c['expected_sha256'] and sha(actual)==c['actual_sha256']
   truth=expected.read_bytes()==actual.read_bytes();assert truth==c['raw_equal'];equal+=truth;channels+=1
   original=benchmark.raw_channel(java,ch[:-4]) if ch in ('stdout.bin','stderr.bin') else (old/ch).read_bytes()
   assert expected.read_bytes()==original
  expected_status='oracle-error' if category is None else 'pass' if ns==category and native['exit_code']==java['exit_code'] and all(c['raw_equal'] for c in row['comparisons']) else 'mismatch'
  assert row['status']==expected_status;counts[expected_status]+=1
 for id in matrix:
  rows=[x for x in r['results'] if x['id']==id];assert {x['repeat'] for x in rows}=={0,1}
  a,b=rows;assert a['status']==b['status'] and a['native']['exit_code']==b['native']['exit_code']
  assert [(c['expected_sha256'],c['actual_sha256']) for c in a['comparisons']]==[(c['expected_sha256'],c['actual_sha256']) for c in b['comparisons']]
 assert dict(counts)==r['status_counts']
 assert sha(root/'scalar_context_probe')==r['binary_sha256'] and r['binary_stability']
 return {'report_sha256':sha(root/'report.json'),'status_counts':dict(counts),'raw_channels_verified':channels,'raw_channels_equal':equal,'repeat_raw_stability':True,'binary_sha256':r['binary_sha256'],'case_count':len(matrix)}

native=R/'target/m2/stage38-final-native-01';edge=R/'target/m2/stage38-final-uri-edges-01'
n=rd(native/'report.json');e=rd(edge/'report.json')
na=raw_audit(native);ea=raw_audit(edge)
assert na['status_counts']=={'pass':102,'mismatch':28}
assert ea['status_counts']=={'oracle-error':6,'pass':8}
assert n['binary_sha256']==e['binary_sha256'] and sha(edge/'candidate-report.json')==sha(native/'report.json')
assert n['source_stability'] and n['source_hashes_before']==n['source_hashes_after']
assert e['source_stability'] and e['source_hashes_before']==e['source_hashes_after']==n['source_hashes_before']
for p,h in n['source_hashes_before'].items():assert sha(R/p)==h and sha(native/'sources'/p)==h
for c in n['commands']:
 assert c['record']['status']=='executed' and c['record']['exit_code']==0 and c['source_hashes_after']==n['source_hashes_before']
 for ch in ('stdout','stderr'):benchmark.raw_channel(c['record'],ch)
origin=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage38-default-host-oracle-01')
assert sha(origin/'closure.json')==n['original_closure_sha256']=='1effb34c18d1d7c96d094f377800eca99553572e4053a87cf25e8b8ede9917c8'
for p,h in n['controlled_fixture_hashes_before'].items():assert sha(origin/p)==h==n['controlled_fixture_hashes_after'][p]
assert n['controlled_fixture_stability']
for group in ['', 'additional-empty-profile', 'prior-exact-controls']:
 for case in rd(origin/group/'manifest.json'):
  assert (origin/group/'cases'/case['id']/'input.pkl').read_bytes()==(native/'cases'/case['id']/'input.pkl').read_bytes()
edge_origin=R/'target/m2/stage38-review-uri-edges-01'
assert sha(edge_origin/'closure.json')==e['oracle_closure_sha256']
for rel,h in rd(edge_origin/'closure.json')['files_sha256'].items():assert sha(edge_origin/rel)==h

freeze=R/'target/m2/stage38-core-validation-04/freeze.json';f=rd(freeze)
assert len(f['sources'])==117
for p,h in f['sources'].items():assert n['source_hashes_before'][p]==h
front=R/'target/m2/stage38-frontend-validation-03';fc=rd(front/'comparison.json')
for rel,info in rd(front/'closure.json')['files'].items():assert sha(front/rel)==info['sha256'] and (front/rel).stat().st_size==info['bytes']
assert fc['count']==fc['passing']==36 and fc['owned_source_stability']
for rel,h in fc['owned_sources'].items():
 assert sha(R/rel)==h and sha(front/'sources'/rel)==h
 if rel in n['source_hashes_before']:assert n['source_hashes_before'][rel]==h
for row in fc['results']:
 assert row['pass'] and row['exit_equal'] and all(row['raw_equal'].values())
 for ch in ('stdout','stderr'):
  actual=benchmark.raw_channel(row['process'],ch);expected=R/'target/m2'/row['group']/'cases'/row['id']/'java/process'/(ch+'.bin');assert actual==expected.read_bytes()
assert sha(front/'scalar_probe')==fc['wrapper_sha256'] and sha(front/'linked-runtime.rlib')==fc['rlib_sha256']
version=benchmark.capture(['cargo','-vV'],R,dict(os.environ),O/'cargo-version',timeout=30)
assert version['status']=='executed' and version['exit_code']==0
remaining={id for id in {r['id'] for r in n['results']} if any(x['id']==id and x['status']=='mismatch' for x in n['results'])}
assert len(remaining)==14 and 'uri-unpaired-surrogate' in remaining and all(x.startswith('file-') for x in remaining-{'uri-unpaired-surrogate'})
report={'scope':'Offline raw/build/source audit of final65+edge7 acquisitions; existing frontend36 debug execution remains separate and is reused only through exact unchanged source binding. No Java rerun or artifact equivalence claim.','passed':True,'native65':na,'edge7':ea,'remaining_distinct_mismatches':sorted(remaining),'same_release_artifact_for_65_and_edges':True,'final_source_count':len(n['source_hashes_before']),'core_freeze_sha256':sha(freeze),'core_freeze_sources_bound':117,'frontend36':{'comparison_sha256':sha(front/'comparison.json'),'closure_sha256':sha(front/'closure.json'),'count':36,'source_count':len(fc['owned_sources']),'source_binding_matches':True,'wrapper_sha256':fc['wrapper_sha256'],'rlib_sha256':fc['rlib_sha256'],'execution_repeated':False,'artifact_identity_separate_from_release':True},'cargo_version':version,'reference_lock_sha256':sha(R/'references.lock'),'acquisition_driver_sha256':sha(native/'acquire.py'),'edge_driver_sha256':sha(edge/'acquire.py'),'tool_sha256':sha(R/'tools/benchmark.py'),'audit_script_sha256':sha(Path(__file__)),'all_known_outcomes_retained':True}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for name in ['stage38-final-native-01','stage38-final-uri-edges-01']:
 p=R/'target/m2'/name
 for ch in ('stdout','stderr'):shutil.copyfile(R/'target/m2'/f'{name}.{ch}.log',p/f'wrapper.{ch}.log')
for p in [native,edge,O]:
 assert not (p/'closure.json').exists();files={}
 for directory,dirs,names in os.walk(p,topdown=True):
  dirs[:]=sorted(d for d in dirs if d not in {'target','node_modules','.cache','.git','__pycache__'} and not d.endswith('-cargo'))
  for name in sorted(names):
   q=Path(directory)/name;assert not q.is_symlink();files[str(q.relative_to(p))]={'sha256':sha(q),'bytes':q.stat().st_size}
 (p/'closure.json').write_text(json.dumps({'closed':True,'terminal':True,'scope':'Final frozen Stage38 native evidence; all mismatches and oracle errors retained.','excluded_before_traversal':['target','node_modules','.cache','.git','__pycache__','*-cargo'],'files':files},indent=2)+'\n')
 print(p.name,sha(p/'report.json'),sha(p/'closure.json'))
