import { readFileSync,writeFileSync } from 'node:fs';
import { compareLanguagePayload as before } from './compare-language-cases.before.mjs';
import { compareLanguagePayload as after } from './compare-language-cases.after.mjs';
const base=new URL('.',import.meta.url);
const payloads=JSON.parse(readFileSync(new URL('../stage38-platform-oracle-01/fixed-payloads.json',base)));
const fixture=payloads.find(row=>row.id==='read-stage38-uri-unpaired-surrogate');
const expectedUnits=Buffer.from(fixture.expectedCodeUnitsHex,'hex');
let exact='';for(let i=0;i<expectedUnits.length;i+=2)exact+=String.fromCharCode(expectedUnits.readUInt16BE(i));
const rows=[];
for(const [name,value] of [['exact-java-units',exact],['java-utf8-replacement-text',fixture.expectedError]]){
 const old=before(fixture,'error',value),now=after(fixture,'error',value);
 writeFileSync(new URL(name+'.node-utf8.bin',base),Buffer.from(value,'utf8'));
 writeFileSync(new URL(name+'.code-units.bin',base),now.actualCodeUnits);
 rows.push({name,before:{status:old.status,utf8Match:old.utf8Match,codeUnitsMatch:old.codeUnitsMatch},after:{status:now.status,rawMatch:now.rawMatch,originalJavaUtf8Match:now.originalJavaUtf8Match,nodeUtf8Match:now.nodeUtf8Match,codeUnitsMatch:now.codeUnitsMatch,javaVsNodeSerializationDivergence:now.javaVsNodeSerializationDivergence,comparisonBoundary:now.comparisonBoundary}});
}
if(rows[0].before.status!=='mismatch'||rows[0].before.codeUnitsMatch!==true||rows[0].before.utf8Match!==false)throw Error('old exact-unit false negative not reproduced');
if(rows[0].after.status!=='pass'||rows[0].after.originalJavaUtf8Match!==false||rows[1].after.status!=='mismatch')throw Error('new JS-string boundary violated');
writeFileSync(new URL('original-java-utf8.bin',base),Buffer.from(fixture.expectedError,'utf8'));
writeFileSync(new URL('original-java-utf16be.bin',base),expectedUnits);
writeFileSync(new URL('utf16-proof.json',base),JSON.stringify({scope:'Synthetic comparator-only logic proof using unchanged pinned Java payload; no evaluator/build/browser execution.',id:fixture.id,rows},null,2)+'\n');
console.log(JSON.stringify(rows));
