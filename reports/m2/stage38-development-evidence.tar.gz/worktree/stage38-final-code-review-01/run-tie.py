from pathlib import Path
import json,sys,os,hashlib,shutil
R=Path.cwd();O=R/'target/m2/stage38-final-code-review-01/suggestion-tie';O.mkdir();sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();snapshot=json.loads((R/'target/m2/stage38-frontend-validation-03/comparison.json').read_text());before={n:sha(R/n) for n in snapshot['owned_sources']};assert before==snapshot['owned_sources']
source='function Listing(x,y,z)=x\nresult=Listin(1)\n';(O/'input.pkl').write_bytes(source.encode());shutil.copy2(R/'target/m2/stage38-frontend-validation-03/scalar_probe',O/'scalar_probe');assert sha(O/'scalar_probe')==snapshot['wrapper_sha256']
meta=json.loads((R/'target/m2/stage38-read-frontend-oracle-01/oracle.json').read_text());assert sha(Path(meta['artifact']))==meta['artifact_sha256']
for n in ('home','tmp','java-output'):(O/n).mkdir()
env=dict(meta['environment']);env.update(HOME=str(O/'home'),TMPDIR=str(O/'tmp'),TMP=str(O/'tmp'),TEMP=str(O/'tmp'))
base=list(meta['command'][:-1]);base=[('-Duser.home='+str(O/'home')) if s.startswith('-Duser.home=') else ('-Djava.io.tmpdir='+str(O/'tmp')) if s.startswith('-Djava.io.tmpdir=') else s for s in base];base[base.index('-cp')+1]=str(R/'target/m2/stage38-read-frontend-oracle-01/classes')+os.pathsep+meta['artifact']
java=benchmark.capture([*base,'Stage38DefaultHostProbe',str(O/'java-output'),str(O/'input.pkl'),'file:///stage38-read-frontend.pkl','result'],R,env,O/'java-process',timeout=60)
rust=benchmark.capture([str(O/'scalar_probe'),str(O/'input.pkl')],R,env,O/'rust-process',timeout=30)
after={n:sha(R/n) for n in snapshot['owned_sources']};assert after==before
same={ch:(O/'java-process'/(ch+'.bin')).read_bytes()==(O/'rust-process'/(ch+'.bin')).read_bytes() for ch in ('stdout','stderr')}
report={'source':source,'source_sha256':sha(O/'input.pkl'),'uri':'file:///stage38-read-frontend.pkl','expression':'result','java':java,'rust':rust,'raw_equal':same,'exit_equal':java['exit_code']==rust['exit_code'],'candidate_sha256':sha(O/'scalar_probe'),'current_frozen_sources':before,'source_stability':before==after,'original_build_binding':'target/m2/stage38-frontend-validation-03/comparison.json','original_build_binding_sha256':sha(R/'target/m2/stage38-frontend-validation-03/comparison.json'),'java_helper_sha256':sha(R/'target/m2/stage38-read-frontend-oracle-01/Stage38DefaultHostProbe.java'),'java_class_sha256':sha(R/'target/m2/stage38-read-frontend-oracle-01/classes/Stage38DefaultHostProbe.class'),'jar_sha256':meta['artifact_sha256'],'jar':meta['artifact']}
(O/'oracle.json').write_text(json.dumps(meta,indent=2)+'\n');(O/'environment.json').write_text(json.dumps(env,indent=2)+'\n');(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'exit_equal':report['exit_equal'],'raw_equal':same}))
