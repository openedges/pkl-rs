// Compare every selected Java value/error on both portable targets without normalization.
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import { resolve, dirname, relative, sep, extname, basename } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const script = fileURLToPath(import.meta.url);


// The same function runs against N-API and browser Wasm; every failure is captured.
export function evaluateLanguageFixtures(api, fixtures, settings, count) {
  const rows = [];
  for (let repetition = 0; repetition < count; repetition++) {
    for (const fixture of fixtures) {
      let status, payload;
      try {
        payload = api.evaluateLanguage(fixture.source, settings.uri, settings.moduleName,
          fixture.expression, Object.hasOwn(fixture, 'powerAssertions') ? fixture.powerAssertions : settings.powerAssertions);
        status = typeof payload === 'string' ? 'value' : 'harness_error';
        if (status === 'harness_error') payload = 'Unexpected non-string return: ' + String(payload);
      } catch (error) {
        status = error instanceof Error ? 'error' : 'harness_error';
        payload = error instanceof Error ? error.message : String(error);
      }
      rows.push({ id: fixture.id, repetition, status, payload });
    }
  }
  return rows;
}

export function compareLanguagePayload(fixture, actualStatus, payload) {
  const expectedStatus = Object.hasOwn(fixture, 'expectedError') ? 'error' : 'value';
  const expected = Buffer.from(fixture.expectedError ?? fixture.expectedValue, 'utf8');
  const actual = Buffer.from(payload, 'utf8');
  const actualCodeUnits = Buffer.alloc(payload.length * 2);
  for (let index = 0; index < payload.length; index++) actualCodeUnits.writeUInt16BE(payload.charCodeAt(index), index * 2);
  const expectedCodeUnits = Object.hasOwn(fixture, 'expectedCodeUnitsHex') ? Buffer.from(fixture.expectedCodeUnitsHex, 'hex') : null;
  const utf8Match = actual.equals(expected);
  const codeUnitsMatch = expectedCodeUnits === null ? null : actualCodeUnits.equals(expectedCodeUnits);
  const rawMatch = actualStatus === expectedStatus && utf8Match && codeUnitsMatch !== false;
  return { expectedStatus, expected, actual, expectedCodeUnits, actualCodeUnits, utf8Match, codeUnitsMatch,
    rawMatch, status: fixture.oracleError === true ? 'oracle-error' : rawMatch ? 'pass' : 'mismatch' };
}

export async function compareLanguageCases(args) {
  const root = resolve(dirname(script), '../..');
  const [outputArg, wasmArg, addonArg, fixtureArg] = args;
  if (args.length !== 4 || args.some(arg => !arg)) throw Error('usage: compare-language-cases.mjs OUTPUT WASM_DIR NAPI_BINARY FIXTURE_MODULE');
  const output = resolve(outputArg);
  const addon = resolve(addonArg);
  const wasm = resolve(wasmArg);
  const fixturePath = resolve(fixtureArg);
  const require = createRequire(resolve(root, 'tools/platform/package.json'));
  const { chromium } = require('playwright');
  const sha = bytes => createHash('sha256').update(bytes).digest('hex');
  const json = value => JSON.stringify(value, null, 2) + '\n';
  const repetitions = 2;
  const { cases, context } = await import(pathToFileURL(fixturePath));
  if (!Array.isArray(cases) || !cases.length || new Set(cases.map(row => row.id)).size !== cases.length
      || cases.some(row => !/^[a-zA-Z0-9_-]+$/.test(row.id) || typeof row.source !== 'string' || typeof row.expression !== 'string'))
    throw Error('expected nonempty distinct language fixtures with safe identifiers');
  if (!context || typeof context.uri !== 'string' || typeof context.moduleName !== 'string' || typeof context.powerAssertions !== 'boolean')
    throw Error('expected an explicit language evaluation context');
  if (cases.some(row => Object.hasOwn(row, 'powerAssertions') && typeof row.powerAssertions !== 'boolean'))
    throw Error('fixture powerAssertions override must be boolean');
  if (cases.some(row => Object.hasOwn(row, 'oracleError') && typeof row.oracleError !== 'boolean'))
    throw Error('fixture oracleError marker must be boolean');
  if (cases.some(row => Object.hasOwn(row, 'expectedCodeUnitsHex')
      && (typeof row.expectedCodeUnitsHex !== 'string' || row.expectedCodeUnitsHex.length % 4 !== 0 || !/^[0-9a-fA-F]*$/.test(row.expectedCodeUnitsHex))))
    throw Error('fixture expectedCodeUnitsHex must contain complete UTF16 units');
  const caseIds = cases.map(row => row.id);
  const packagePath = resolve(root, 'tools/platform/package.json');
  const lockPath = resolve(root, 'tools/platform/package-lock.json');
  const manifest = JSON.parse(await readFile(packagePath));
  const lock = JSON.parse(await readFile(lockPath));
  const pin = manifest.devDependencies.playwright;
  const playwright = require('playwright/package.json').version;
  const playwrightCore = require('playwright-core/package.json').version;
  if (!/^\d+\.\d+\.\d+$/.test(pin) || playwright !== pin || playwrightCore !== pin
      || lock.packages[''].devDependencies.playwright !== pin
      || lock.packages['node_modules/playwright'].version !== pin
      || lock.packages['node_modules/playwright-core'].version !== pin) throw Error('Playwright installation differs from manifest/lock pin');
  // Refuse an existing evidence directory; never overwrite earlier captures.
  await mkdir(output, { recursive: false });
  const sourceHashes = {};
  for (const fixture of cases) {
    const bytes = Buffer.from(fixture.source, 'utf8');
    if (sha(bytes) !== fixture.sourceSha256) throw Error('fixture source hash differs: ' + fixture.id);
    const original = await readFile(resolve(root, 'tests/fixtures/m2', fixture.id + '.pkl'));
    if (!bytes.equals(original)) throw Error('fixture source differs from selected input: ' + fixture.id);
    if (Object.hasOwn(fixture, 'expectedError') === Object.hasOwn(fixture, 'expectedValue')) throw Error('fixture must have one expected outcome: ' + fixture.id);
    sourceHashes[fixture.id] = sha(bytes);
  }
  await writeFile(resolve(output, 'fixtures.json'), json({ context, cases }));
  await writeFile(resolve(output, basename(script)), await readFile(script));
  const invocation = resolve(process.argv[1]);
  if (invocation !== script) await writeFile(resolve(output, basename(invocation)), await readFile(invocation));
  const artifactHashes = {};
  async function recordFile(path) { artifactHashes[relative(root, path)] = sha(await readFile(path)); }
  async function recordTree(path) {
    for (const entry of await readdir(path, { withFileTypes: true })) {
      const child = resolve(path, entry.name);
      if (entry.isDirectory()) await recordTree(child);
      else if (entry.isFile()) await recordFile(child);
      else throw Error('unexpected artifact entry: ' + child);
    }
  }
  await recordFile(addon);
  await recordTree(wasm);
  await recordFile(fixturePath);
  await recordFile(packagePath);
  await recordFile(lockPath);
  await recordFile(script);
  if (invocation !== script) await recordFile(invocation);
  const browserErrors = [];
  const infrastructureErrors = [];
  const report = { schema: 1, scope: `All ${cases.length} selected language cases, two fresh evaluator calls per case on Node and Chromium; full UTF-8 values/errors without normalization.`,
    caseCount: cases.length, caseIds, caseIdsSha256: sha(Buffer.from(JSON.stringify(caseIds), 'utf8')),
    argv: process.argv, cwd: process.cwd(), context, repetitions, sourceHashes, artifactHashes,
    fixtureSha256: sha(await readFile(fixturePath)), node: process.version, nodeVersions: process.versions,
    nodeExecutable: process.execPath, nodeExecutableSha256: sha(await readFile(process.execPath)),
    playwright, playwrightCore, playwrightPin: pin, browserErrors, infrastructureErrors, targets: {} };


  async function saveTarget(target, rows) {
    const dir = resolve(output, target);
    await mkdir(dir);
    const expectedPairs = new Set(cases.flatMap(fixture => Array.from({ length: repetitions },
      (_, repetition) => `${fixture.id}\u0000${repetition}`)));
    const observedPairs = new Set();
    const results = [];
    for (const row of rows) {
      const fixture = cases.find(fixture => fixture.id === row.id);
      const pair = `${row.id}\u0000${row.repetition}`;
      if (!expectedPairs.has(pair) || observedPairs.has(pair)) throw Error('unexpected or duplicate execution pair: ' + pair);
      observedPairs.add(pair);
      const compared = compareLanguagePayload(fixture, row.status, row.payload);
      const { expectedStatus, expected, actual, expectedCodeUnits, actualCodeUnits } = compared;
      const prefix = `${row.id}.repeat-${row.repetition}`;
      await writeFile(resolve(dir, prefix + '.expected.bin'), expected);
      await writeFile(resolve(dir, prefix + '.actual.bin'), actual);
      if (expectedCodeUnits !== null) {
        await writeFile(resolve(dir, prefix + '.expected.code-units.bin'), expectedCodeUnits);
        await writeFile(resolve(dir, prefix + '.actual.code-units.bin'), actualCodeUnits);
      }
      const result = { id: row.id, repetition: row.repetition,
        powerAssertions: Object.hasOwn(fixture, 'powerAssertions') ? fixture.powerAssertions : context.powerAssertions,
        status: compared.status, rawMatch: compared.rawMatch, utf8Match: compared.utf8Match,
        codeUnitsMatch: compared.codeUnitsMatch, oracleError: fixture.oracleError === true,
        expectedStatus, actualStatus: row.status, expectedSha256: sha(expected), actualSha256: sha(actual),
        expectedBytes: expected.length, actualBytes: actual.length,
        expectedCodeUnitsSha256: expectedCodeUnits === null ? null : sha(expectedCodeUnits),
        actualCodeUnitsSha256: expectedCodeUnits === null ? null : sha(actualCodeUnits),
        expectedCodeUnitsFile: expectedCodeUnits === null ? null : `${target}/${prefix}.expected.code-units.bin`,
        actualCodeUnitsFile: expectedCodeUnits === null ? null : `${target}/${prefix}.actual.code-units.bin`,
        expectedFile: `${target}/${prefix}.expected.bin`, actualFile: `${target}/${prefix}.actual.bin` };
      await writeFile(resolve(dir, prefix + '.json'), json(result));
      results.push(result);
    }
    const mismatchIds = cases.filter(fixture => results.some(row => row.id === fixture.id && row.status === 'mismatch')).map(fixture => fixture.id);
    const oracleErrorIds = cases.filter(fixture => fixture.oracleError === true).map(fixture => fixture.id);
    const passingCases = cases.filter(fixture => results.filter(row => row.id === fixture.id).every(row => row.status === 'pass')).length;
    const complete = observedPairs.size === expectedPairs.size;
    return { complete, executions: rows.length, passingExecutions: results.filter(row => row.status === 'pass').length,
      mismatchingExecutions: results.filter(row => row.status === 'mismatch').length,
      oracleErrorExecutions: results.filter(row => row.status === 'oracle-error').length,
      matchingOracleErrorExecutions: results.filter(row => row.status === 'oracle-error' && row.rawMatch).length,
      passingCases: complete ? passingCases : 0, mismatchingCases: mismatchIds.length,
      oracleErrorCases: oracleErrorIds.length, oracleErrorIds, mismatchIds, results };
  }

  try {
    const native = require(addon);
    report.targets.node = await saveTarget('node', evaluateLanguageFixtures(native, cases, context, repetitions));
  } catch (error) { infrastructureErrors.push({ target: 'node', message: error.message, stack: error.stack }); }

  const server = createServer(async (request, response) => {
    try {
      const url = new URL(request.url, 'http://127.0.0.1');
      if (url.pathname === '/') {
        response.writeHead(200, { 'Content-Type': 'text/html' });
        response.end('<!doctype html><title>Language raw comparison</title>');
        return;
      }
      const path = resolve(wasm, '.' + decodeURIComponent(url.pathname));
      if (!path.startsWith(wasm + sep)) throw Error('invalid Wasm path');
      response.writeHead(200, { 'Content-Type': extname(path) === '.wasm' ? 'application/wasm' : 'text/javascript' });
      response.end(await readFile(path));
    } catch { response.writeHead(404); response.end(); }
  });
  let browser;
  try {
    await new Promise((ok, fail) => { server.once('error', fail); server.listen(0, '127.0.0.1', ok); });
    browser = await chromium.launch({ headless: true });
    report.browser = browser.version();
    report.browserExecutable = chromium.executablePath();
    report.browserExecutableSha256 = sha(await readFile(report.browserExecutable));
    const page = await browser.newPage();
    page.on('pageerror', error => browserErrors.push({ type: 'pageerror', message: error.message, stack: error.stack }));
    page.on('crash', () => browserErrors.push({ type: 'crash' }));
    await page.goto(`http://127.0.0.1:${server.address().port}`);
    const rows = await page.evaluate(async ({ fixtures, settings, count, evaluateSource }) => {
      const api = await import('/pkl_wasm.js');
      await api.default();
      const run = (0, eval)('(' + evaluateSource + ')');
      return run(api, fixtures, settings, count);
    }, { fixtures: cases, settings: context, count: repetitions, evaluateSource: evaluateLanguageFixtures.toString() });
    report.targets.browser = await saveTarget('browser', rows);
  } catch (error) { infrastructureErrors.push({ target: 'browser', message: error.message, stack: error.stack }); }
  finally {
    if (browser) await browser.close();
    if (server.listening) await new Promise(ok => server.close(ok));
  }
  // A concurrent build or source edit invalidates this comparison's provenance.
  report.stability = { artifactHashes: {}, sourceHashes: {}, changed: [] };
  async function finalHash(path) {
    try { return sha(await readFile(resolve(root, path))); }
    catch (error) {
      infrastructureErrors.push({ target: 'all', message: 'Cannot reread comparison input', path, error: error.message });
      return null;
    }
  }
  for (const [path, expected] of Object.entries(artifactHashes)) {
    const actual = await finalHash(path);
    report.stability.artifactHashes[path] = actual;
    if (actual !== expected) report.stability.changed.push(path);
  }
  for (const fixture of cases) {
    const path = `tests/fixtures/m2/${fixture.id}.pkl`;
    const actual = await finalHash(path);
    report.stability.sourceHashes[fixture.id] = actual;
    if (actual !== sourceHashes[fixture.id]) report.stability.changed.push(path);
  }
  if (report.stability.changed.length) infrastructureErrors.push({ target: 'all',
    message: 'Sources or artifacts changed during comparison', paths: report.stability.changed });
  report.status = infrastructureErrors.length || browserErrors.length
    || !['node', 'browser'].every(target => report.targets[target]?.complete && report.targets[target].mismatchingExecutions === 0
      && report.targets[target].oracleErrorExecutions === 0)
    ? 'failed' : 'passed';
  await writeFile(resolve(output, 'execution.json'), json(report));
  console.log(json({ status: report.status, output, targets: Object.fromEntries(Object.entries(report.targets).map(([target, result]) =>
    [target, { complete: result.complete, executions: result.executions, passingCases: result.passingCases,
      mismatchingCases: result.mismatchingCases, oracleErrorCases: result.oracleErrorCases,
      oracleErrorIds: result.oracleErrorIds, mismatchIds: result.mismatchIds }])), browserErrors, infrastructureErrors }));
  if (report.status !== 'passed') process.exitCode = 1;
  return report;
}

if (process.argv[1] && resolve(process.argv[1]) === script) {
  await compareLanguageCases(process.argv.slice(2));
}
