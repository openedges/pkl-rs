use std::{env,fs,io::{self,Write}};
fn main() {
    let args: Vec<_> = env::args().collect();
    let source=fs::read_to_string(&args[1]).unwrap();
    match pkl_runtime::evaluation::scalar_expression(&source,"file:///stage38-read-frontend.pkl","stage38-read-frontend","result") {
        Ok(value) => io::stdout().write_all(value.as_bytes()).unwrap(),
        Err(error) => {io::stderr().write_all(error.as_bytes()).unwrap();std::process::exit(1);}
    }
}
