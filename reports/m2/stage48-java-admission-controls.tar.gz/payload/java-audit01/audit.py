from pathlib import Path
import collections,hashlib,json,os,stat
O=Path(__file__).parent.resolve();P=O.parent/'stage48-module-admission-oracle-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
r=json.loads((P/'report.json').read_bytes());terminal=json.loads((P/'outer-terminal.json').read_bytes());checks=[]
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label)
def raw(prefix,suffix):return (P/(prefix+'.'+suffix)).read_bytes()
def decode(u):return u.decode('utf-16-be','surrogatepass').encode('utf-8','replace')
def counters(text):return dict((k,int(v))for k,v in (x.split('=')for x in text.splitlines()))
check(terminal['exitCode']==0 and not terminal['liveHandles'],'outer terminal0/no live handles')
check(terminal['sourceBefore']==terminal['sourceAfter'],'outer source stable')
for path,digest in terminal['sourceAfter'].items():check(sha(P/path)==digest,'current outer source '+path)
for path,digest in r['inputHashes'].items():check(sha(Path(path))==digest,'producer input '+path)
check(not r['inputChanges'] and r['workspacesUnchanged'] and r['jarStable'],'producer input/workspace/jar unchanged')
check(not any(d['rawPathDifferences']for d in r['repeatDifferences']) and not r['trustRepeatDifferences'],'producer repeats identical')
api=collections.Counter();events=0;all_denials=[]
for o in r['observations']:
 record=next(x for x in r['records']if x['case']==o['case'] and x['repeat']==o['repeat']);check(record['exitCode']==0 and not record['timedOut'],'JVM terminal '+o['case']+str(o['repeat']))
 combined=[]
 for session in o['sessions']:
  index=session['session'];session_path=P/'cases'/o['case']/str(o['repeat'])/'calls'/('session-'+str(index));ev=session['events'];count=counters(session['counters']);check((session_path/'counters.bin').read_text()==session['counters'],'final counter raw')
  check(len(ev)==count['event'],'complete event count');event_bytes=[]
  for i,e in enumerate(ev):
   p=e['rawPrefix'];b=raw(p,'bin');u=raw(p,'code-units.bin');check(e['index']==i and b.hex()==e['utf8Hex'] and u.hex()==e['utf16BEHex'] and decode(u)==b,'actual event raw/units/index');event_bytes.append(b)
  combined.extend(event_bytes);events+=len(ev)
  # Derive observer counters only from actual event bytes, retaining every event in its original position.
  prefixes={'resolve':b'policy-resolve-module ','import':b'policy-import ','securePath':b'secure-path ','denied':b'actual-','factory':b'factory-','factoryHit':b'factory-hit-','keyResolve':b'key-resolve ','sourceLoad':b'load-source ','isCached':b'key-is-cached ','policyRead':b'policy-read-resource ','resolveResource':b'policy-resolve-resource '}
  def recount(end):
   observed=event_bytes[:end];v={k:sum(b.startswith(pre)for b in observed)for k,pre in prefixes.items()};v['factory']=sum(b.startswith(b'factory-') and not b.startswith((b'factory-hit-',b'factory-custom-hit '))for b in observed);v['factoryHit']=sum(b.startswith((b'factory-hit-',b'factory-custom-hit '))for b in observed);v['event']=end;return v
  check(recount(len(ev))==count,'all observer counters derive from actual events')
  calls=[c for c in o['calls']if c['session']==index]
  for c in calls:
   p=c['rawPrefix'];check(not c['missingFields'],'all APIs reached capture');s=raw(p,'status.bin');check(s in (b'success\n',b'error\n') and s.decode()==c['status'],'exact status');api[s.decode()]+=1
   for channel in ['stdout','stderr']:
    b=raw(p,channel+'.bin');u=raw(p,channel+'.code-units.bin');check(b.hex()==c[channel+'Utf8Hex'] and u.hex()==c[channel+'Utf16BEHex'] and decode(u)==b,'API channel UTF16/UTF8 raw')
   check(raw(p,'expression.bin').decode()==c['expression'] and raw(p,'source.bin').decode()==c['source'],'actual expression/source')
   for when in ['Before','After']:
    text=c['counters'+when];check(raw(p,'counters-'+when.lower()+'.bin').decode()==text,'raw report counter binding');cs=counters(text);check(recount(cs['event'])==cs,'API counter event projection')
   check(raw(p,'error-class.bin').decode()==c['errorClass'] and raw(p,'message-null.bin').decode()==c['messageNull'],'actual error class/null')
  for i in range(count['denied']):
   null=(session_path/f'denial-{i}.message-null.bin').read_bytes();b=(session_path/f'denial-{i}.message.bin').read_bytes();u=(session_path/f'denial-{i}.message.code-units.bin').read_bytes();check(null in (b'true',b'false') and decode(u)==b,'actual typed cause encoded independently')
   all_denials.append({'case':o['case'],'repeat':o['repeat'],'session':index,'index':i,'context':(session_path/f'denial-{i}.context.bin').read_text(),'messageUtf16BEHex':u.hex(),'messageUtf8Hex':b.hex(),'messageNull':null.decode()})
 process=P/'cases'/o['case']/str(o['repeat']);check((process/'stdout.bin').read_bytes()==b''.join(b+b'\n'for b in combined),'complete process stdout event stream');check(sha(process/'stdout.bin')==record['stdoutSha256'] and sha(process/'stderr.bin')==record['stderrSha256'],'process raw hashes')
direct=collections.Counter();direct_events=0
for o in r['trustObservations']:
 d=P/'trust'/str(o['repeat'])/'calls'/('batch-'+str(o['batch']));evs=int((d/'events.bin').read_text());check(evs==2*len(o['calls']),'direct events 2/call')
 for c in o['calls']:
  p=c['rawPrefix'];check(raw(p,'status.bin').decode()==c['status'],'direct status');direct[c['status']]+=1
  for channel in ['stdout','stderr']:
   b=raw(p,channel+'.bin');u=raw(p,channel+'.code-units.bin');check(b.hex()==c[channel+'Utf8Hex'] and u.hex()==c[channel+'Utf16BEHex'] and decode(u)==b,'direct channel raw')
 for i in range(evs):check(decode((d/f'event-{i}.code-units.bin').read_bytes())==(d/f'event-{i}.bin').read_bytes(),'direct event units/raw')
 direct_events+=evs
for repeat,record in enumerate(r['trustRecords']):
 d=P/'trust'/str(repeat);combined=[]
 for batch in [0,1]:
  q=d/'calls'/('batch-'+str(batch));combined.extend((q/f'event-{i}.bin').read_bytes()+b'\n'for i in range(int((q/'events.bin').read_text())))
 check(record['exitCode']==0 and not record['timedOut'] and (d/'stdout.bin').read_bytes()==b''.join(combined),'direct process terminal/full stdout')
check(dict(api)==r['evaluatorStatusCounts'] and sum(api.values())==468,'468 actual Evaluator APIs')
check(dict(direct)==r['directStatusCounts'] and sum(direct.values())==392,'392 separate direct APIs')
intent={'queryAliasLookupNotReached':{'apis':16,'cases':{'resolve-denial-retry-catch':[3,4],'singleton-edge-trust':[2,6]},'reason':'test import alias is not visible to standalone query; original name errors retained; module-scoped wrappers acquired separately.'},'cycleInitializationFailureNotReached':{'apis':36,'case':'cycle-partial-return-later-init-failure','reason':'Class declarations remained lazy. All nine calls/session succeeded. No claim of partial receiver followed by failed initialization.'},'customKeyOpaqueUri':{'case':'custom-key-pkl-uri-not-stdlib-kind','result':'All20 APIs succeeded; actualcustom pkl:base key is nonstdlib and tag99 was reached. hasHierarchicalUris=true is explicit custom SPI choice, not a standardkey claim.'},'publicLifecycle':'Actual Java primary/repl factory and policy events retained. SourceProbe supplied-primary text omission must remain full trace/counter mismatch; never synthesize these events.', 'unimplementedScopes':['general custom ModuleKeyFactory/isCached=false until actual native support','import*','cross-evaluator JVM singleton identity','full public Evaluator lifecycle','unsupported request phases/error classes remain explicit'], 'gc':'System.gc requested only; no proof collection occurred.'}
write(O/'intent-ledger.json',intent);write(O/'typed-cause-observations.json',all_denials)
write(O/'audit.json',{'schema':1,'source':str(P),'reportSha256':sha(P/'report.json'),'outerTerminalSha256':sha(P/'outer-terminal.json'),'checks':len(checks),'checksFailed':0,'evaluatorApiCalls':sum(api.values()),'evaluatorStatusCounts':dict(api),'evaluatorOrderedEvents':events,'directSecurityManagerApiCalls':sum(direct.values()),'directStatusCounts':dict(direct),'directObserverEvents':direct_events,'actualTypedDenials':len(all_denials),'observedToolHandle':66323,'toolHandlePoll':'Unknown process id on resumed poll; no restart. Authoritative waited outer terminal PID16792 exit0.','liveHandles':[],'sourceProofNotCompatibility':True,'nativeExecuted':False})
write(O/'checks.json',checks)
# Explicit root traversal, no generic cache/build exclusions; captures include compiled Java helpers.
files={};dirs={}
def visit(d):
 for e in sorted(os.scandir(d),key=lambda x:x.name):
  p=Path(e.path);rel=str(p.relative_to(P));st=p.lstat()
  if p.parent==P and p.name in ['inventory.json','closure.json']:continue
  if stat.S_ISDIR(st.st_mode):dirs[rel]={'mode':stat.S_IMODE(st.st_mode)};visit(p)
  elif stat.S_ISREG(st.st_mode):files[rel]={'kind':'regular','sha256':sha(p),'bytes':st.st_size,'mode':stat.S_IMODE(st.st_mode)}
  elif stat.S_ISLNK(st.st_mode):
   b=os.fsencode(os.readlink(p));files[rel]={'kind':'symlink','target':os.readlink(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'mode':stat.S_IMODE(st.st_mode),'targetPayloadSha256':sha(p)}
  else:raise AssertionError(rel)
visit(P);write(P/'inventory.json',{'schema':1,'files':files,'directories':dirs,'prewalkPrune':[],'unlistedGeneratedPayload':False});write(P/'closure.json',{'sealed':True,'reportSha256':sha(P/'report.json'),'outerTerminalSha256':sha(P/'outer-terminal.json'),'inventorySha256':sha(P/'inventory.json'),'auditRoot':str(O),'auditSha256':sha(O/'audit.json'),'files':len(files),'liveHandles':[]})
write(O/'handoff.json',{'oracle':str(P),'reportSha256':sha(P/'report.json'),'inventorySha256':sha(P/'inventory.json'),'closureSha256':sha(P/'closure.json'),'auditSha256':sha(O/'audit.json'),'intentLedgerSha256':sha(O/'intent-ledger.json'),'typedCausesSha256':sha(O/'typed-cause-observations.json'),'apiScope':'468 Evaluator +392 separately direct policy APIs; no Rust run or native pass claim; 16 alias lookup failures and36 no-init-failure APIs explicitly not reached.'})
print(json.dumps(json.loads((O/'audit.json').read_text()),indent=2));print('handoffSha256',sha(O/'handoff.json'))
