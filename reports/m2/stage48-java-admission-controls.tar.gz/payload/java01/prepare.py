from pathlib import Path
import json,os
O=Path(__file__).parent.resolve();cases=[]
def ev(expression,source='main.pkl'):return {'kind':'evaluate','source':source,'expression':expression}
def gc():return {'kind':'gc'}
def policy(value):return {'kind':'policy','value':value}
def cache(value):return {'kind':'cache','value':value}
def add(name,source,ops,mode='allow',files=None,plans=None,entry='main.pkl',scope=''):
 work=O/'workspace'/name;work.mkdir(parents=True,exist_ok=False);(work/'main.pkl').write_text(source)
 for path,data in(files or{}).items():
  p=work/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 rows=[]
 for original,resolved,relative,cached in(plans or[]):rows.append('\t'.join([original,resolved(work),relative,cached]))
 (work/'module-plan.tsv').write_text(''.join(row+'\n'for row in rows))
 operations=[]
 for op in ops:
  if op['kind']=='gc':operations.append('GC')
  elif op['kind']=='policy':operations.append('POLICY\t'+op['value'])
  elif op['kind']=='cache':operations.append('CACHE\t'+op['value'])
  else:operations.append(op['source']+'\t'+op['expression'])
 (work/'operations.tsv').write_text(''.join(row+'\n'for row in operations))
 cases.append({'id':name,'workspace':str(work),'entry':entry,'sourceUri':(work/entry).as_uri(),'mode':mode,'operations':ops,'scope':scope,'inputPaths':[str(p.relative_to(work))for p in work.rglob('*')if p.is_file()]})
 return work
add('site-cache-query-and-closure-sharing','''function one() = import("pkl:json")
function two() = import("pkl:json")
make = (seed) -> ((x) -> import("pkl:json"))
c1 = make.apply(1)
c2 = make.apply(2)
stable = 7
''',[ev('stable'),ev('one().Property.toString()'),ev('one().Property.toString()'),ev('two().Property.toString()'),ev('import("pkl:json").Property.toString()'),ev('import("pkl:json").Property.toString()'),ev('c1.apply(0).Property.toString()'),ev('c2.apply(0).Property.toString()'),ev('c1.apply(0).Property.toString()'),gc(),ev('one().Property.toString()'),ev('two().Property.toString()'),ev('c2.apply(0).Property.toString()'),ev('stable')],scope='Same authored site versus other site and freshquery AST; closures fromsame FunctionLiteralNode; URIcache andsitecache effects separated byactualtrace.')
add('resolve-denial-retry-catch','''import "pkl:test" as test
function one() = import("pkl:json")
function two() = import("pkl:json")
function three() = import("pkl:json")
function four() = import("pkl:json")
stable = 7
''',[ev('stable'),ev('one().Property.toString()'),ev('one().Property.toString()'),ev('test.catch(() -> one().Property.toString())'),ev('test.catchOrNull(() -> one().Property.toString())'),policy('allow'),ev('one().Property.toString()'),ev('one().Property.toString()'),ev('two().Property.toString()'),policy('deny-json'),ev('one().Property.toString()'),ev('three().Property.toString()'),policy('trust-json'),ev('one().Property.toString()'),ev('four().Property.toString()'),gc(),ev('stable')],mode='deny-json',scope='ActualStandardSecurityManager allowlistdenial, retry, guestcatch, laterURIcache andsitecache underpolicychanges. No sourceerror rewriting.')
add('singleton-edge-trust','''import "pkl:test" as test
function one() = import("pkl:base")
function two() = import("pkl:base")
stable = 7
''',[ev('stable'),ev('one().Int.toString()'),ev('test.catch(() -> one().Int.toString())'),policy('allow'),ev('one().Int.toString()'),policy('trust-base'),ev('one().Int.toString()'),ev('two().Int.toString()'),ev('test.catchOrNull(() -> two().Int.toString())'),gc(),ev('stable')],mode='trust-base',scope='Actualcustomtrustfunction deniespklbaseedge whileallowlistpermits; standardkeys keptunwrapped; singletonresolve bypass distinct.')
work=add('file-symlink-resolved-importer','unused = 1\nstable = 7\n',[ev('stable','entry.pkl'),ev('child().tag','entry.pkl'),ev('child().tag','entry.pkl'),gc(),ev('import("pkl:base").Int.toString()','entry.pkl'),ev('stable','entry.pkl')],files={'actual/main.pkl':'function child() = import("./child.pkl")\nstable = 7\n','child.pkl':'tag = "original-base-child"\n','actual/child.pkl':'tag = "resolved-base-child"\n'},entry='entry.pkl',scope='ActualFile symlink primary: originalbase relativepreparation andresolvedURI edgeimporter distinguished; no customkey.')
(work/'entry.pkl').symlink_to('actual/main.pkl');cases[-1]['inputPaths'].append('entry.pkl')
work_uri=lambda w:(w/'real/aliased.pkl').as_uri()
work=O/'workspace/custom-resolved-importer';child_uri=(work/'actual/child.pkl').as_uri()
add('custom-resolved-importer','function alias() = import("memo:/aliased.pkl")\nstable = 7\n',[ev('stable'),ev('alias().child().tag'),ev('alias().child().tag'),ev('import("memo:/aliased.pkl").child().tag'),gc(),ev('alias().child().tag'),ev('stable')],files={'alias-source.pkl':'function child() = import("'+child_uri+'")\nstable = 7\n','actual/child.pkl':'tag = "resolved-child"\n'},plans=[('memo:/aliased.pkl',work_uri,'alias-source.pkl','true')],scope='Publiccustomkey originalmemo(trust10)→resolvedfile(trust30),absolutechildfile30: actualedgeimporter resolvedidentity; customfactory/native support separate.')
add('resolved-cache-alias-no-original-seed','''function first() = import("memo:/aliasA.pkl")
function second() = import("memo:/aliasB.pkl")
function third() = import("memo:/aliasB.pkl")
stable = 7
''',[ev('stable'),ev('first().tag'),ev('second().tag'),ev('third().tag'),ev('second().tag'),ev('import("memo:/aliasB.pkl").tag'),gc(),ev('third().tag'),ev('stable')],files={'shared.pkl':'tag = 7\nclass C {}\n'},plans=[(u,lambda w:(w/'real/shared.pkl').as_uri(),'shared.pkl','true')for u in ['memo:/aliasA.pkl','memo:/aliasB.pkl']],scope='Twooriginalaliasesonesame resolvedURI; resolved-cache hitdoesnotseedneworiginalalias. Exactsource/getter/resolve logs retained.')
add('uncached-policy-toggle','''function one() = import("memo:/toggle.pkl")
function two() = import("memo:/toggle.pkl")
function three() = import("memo:/toggle.pkl")
function four() = import("memo:/toggle.pkl")
stable = 7
''',[ev('stable'),cache('off'),ev('one().tag'),ev('two().tag'),cache('on'),ev('three().tag'),ev('four().tag'),cache('off'),ev('three().tag'),ev('import("memo:/toggle.pkl").tag'),gc(),ev('stable')],files={'shared.pkl':'tag = 7\nclass C {}\n'},plans=[('memo:/toggle.pkl',lambda w:(w/'real/shared.pkl').as_uri(),'shared.pkl','dynamic')],scope='RealcustomModuleKey.isCached snapshotperfactorycreate; uncached-load cachepublication andlatercachedlookup separately observed. UnimplementednativeSPI scope remains.')
add('cycle-partial-return-later-init-failure','function a() = import("./a.pkl")\nfunction b() = import("./b.pkl")\nstable = 7\n',[ev('stable'),ev('a().Good.toString()'),ev('b().saved().Good.toString()'),ev('b().fresh().Good.toString()'),ev('b().saved().Good.toString()'),ev('a().Good.toString()'),gc(),ev('b().saved().Good.toString()'),ev('b().fresh().Good.toString()'),ev('stable')],files={'a.pkl':'import "./b.pkl" as b\nclass Good {}\nclass NeedB extends b.B {}\nclass LaterFailure extends b.Missing {}\n','b.pkl':'function getA() = import("./a.pkl")\nlocal Super = getA().Good\nclass B extends Super {}\nfunction saved() = getA()\nfunction fresh() = import("./a.pkl")\n'},scope='IntendedA.Good→Bclass(superproperty callsgetA)→Apartialreturned/sitecached, thenA laterMissingtype initfails; cachedgetA vsnewfreshsite. Intentreachmustbea uditedfromactualtrace/results, neverassumed.')
for scheme,role in [('noLoader','no-loader'),('throwing','factory-throw')]:
 add('clause-unused-'+role,'import "'+scheme+':x" as unused\nstable = 7\n',[ev('stable'),ev('stable'),gc(),ev('unused'),ev('stable')],scope='Importclausealways performsASTfactoryselection beforestable,evenwithalias; unknownfactoryoractualIOException cause captured; no earlyedge fabrication.')
 add('expr-unused-'+role,'unused = import("'+scheme+':x")\nstable = 7\n',[ev('stable'),ev('stable'),ev('unused'),ev('unused'),gc(),ev('stable'),ev('import("'+scheme+':x")')],scope='UnusedImportExprhasnoASTfactoryselection; forcednodeedge precedesfactory. Directfreshquery distinguished fromcachedproperty/site.')
variants=[]
for module,escaped in [('base','%62ase'),('ref','%72ef'),('test','%74est')]:
 for variant in [module+'#tag',escaped]:variants.append(ev('import("pkl:'+module+'") == import("pkl:'+variant+'")'))
variants += [ev('import("pkl:json#tag").Property.toString()'),ev('import("pkl:%6ason").Property.toString()')]
add('stdlib-uri-spelling-singleton-vs-catalog','stable = 7\n',[ev('stable'),*variants,gc(),ev('stable')],scope='Actualstdkeykind, rawedgeURI spelling versuscanonicalsingletonreceiver identity; decodedSSP ignoresfragment forsingleton, exactcatalog forjson. No outputnormalization.')
add('custom-key-pkl-uri-not-stdlib-kind','function custom() = import("pkl:base")\nstable = 7\n',[ev('stable'),ev('custom().tag'),ev('custom().tag'),ev('import("pkl:base").tag'),gc(),ev('stable')],files={'custom-base.pkl':'tag = 99\n'},plans=[('pkl:base',lambda w:(w/'real/custom-base.pkl').as_uri(),'custom-base.pkl','true')],scope='Prioritypublicfactory returnsnonstdlibkey withpkl:baseURI; keykind isnot inferredfromstring. Generalfactoryprofile separatelyunsupportednative untilimplemented.')
work=O/'workspace/resolved-nested-jar-default-trust';child=(work/'actual/child.pkl').as_uri()
add('resolved-nested-jar-default-trust','function alias() = import("memo:/jarNested.pkl")\nstable = 7\n',[ev('stable'),ev('alias().file().tag'),ev('alias().base().Int.toString()'),ev('alias().peer().tag'),ev('alias().file().tag'),gc(),ev('stable')],files={'jar-source.pkl':'function file() = import("'+child+'")\nfunction base() = import("pkl:base")\nfunction peer() = import("memo:/peer.pkl")\n','peer.pkl':'tag = "peer"\n','actual/child.pkl':'tag = "file"\n'},plans=[('memo:/jarNested.pkl',lambda w:'jar:nested:/stage48/app.jar/!BOOT-INF/classes!/jarNested.pkl','jar-source.pkl','true'),('memo:/peer.pkl',lambda w:(w/'real/peer.pkl').as_uri(),'peer.pkl','true')],scope='Actualresolvedjar:nested importertrust via publiccustomkey, no jar/network I/O. Filetargetdenial versuspkl/memo targets fullraw. Directtrustmatrix separateAPI.')
add('qualified-ref-nullable-type-init-denial','import "pkl:ref"\nx: ref.Reference? = null\nstable = 7\n',[ev('stable'),ev('x'),policy('allow'),ev('x'),ev('stable'),gc(),ev('x'),ev('stable')],mode='trust-ref',scope='Arequestedexactsource: authoredrefimport whilequalifiednullabletype initializes; denial followedallow mustrevealmodule-initializerfailurecache vsordinarylazyretry. No assumedreach/result.')
(O/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(O/'input-paths.json').write_text(json.dumps({case['id']:case['inputPaths']for case in cases},indent=2)+'\n')
(O/'PLAN.ko.md').write_text('''# Stage48 새 Java admission controls

고정 0.32.0 JAR/JDK 공개 Evaluator와 실제 StandardSecurityManager를 사용합니다. 같은 site/별도 site/fresh query/closure 공유, resolve deny/retry/catch, singleton edge trust, original/resolved importer, cached/uncached alias, 부분 receiver 뒤 초기화 실패, ImportClause와 ImportExpr factory 시점, stdlib URI spelling, nested jar trust와 qualified ref type 초기화를 새 원문으로 취득합니다. 일반 custom factory/key와 공개 primary/repl lifecycle은 첫 bundled 구현과 별도 미완료 gate입니다.

각 JVM은 같은 원문에서 evaluator 2개를 순차 생성하며 두 fresh JVM repeat를 실행합니다. event는 실제 callback/observer action에서만 발생하고 UTF16과 JavaUTF8를 독립 캡처합니다. 표준 key는 wrapping하지 않으며 factory만 관찰해 singleton 종류를 바꾸지 않습니다. source/key/cache 상태는 실제 callback trace로 판정하고 의도 미도달·오류·내부 boundary는 그대로 남깁니다. Jar URI는 정책 계산과 custom resolved identity일 뿐 실제 jar/network I/O를 하지 않습니다. 새 production/Rust/native/Git 변경이나 Java fallback은 없습니다.
''')
print(json.dumps({'cases':len(cases),'plannedApisPerEvaluator':sum(sum(op['kind']=='evaluate'for op in c['operations'])for c in cases),'plannedApiTotal':4*sum(sum(op['kind']=='evaluate'for op in c['operations'])for c in cases)},indent=2))
