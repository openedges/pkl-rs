from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).parent.resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();command=[sys.executable,str(O/'run.py')]
r={'parentPid':os.getpid(),'command':command,'cwd':str(O),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'PYTHONDONTWRITEBYTECODE':'1'},'sourceBefore':{name:sha(O/name)for name in ['AdmissionProbe.java','TrustProbe.java','prepare.py','run.py','cases.json','trust-uris.txt','launch.py']}}
with(O/'outer.stdout.bin').open('wb')as out,(O/'outer.stderr.bin').open('wb')as err:
 p=subprocess.Popen(command,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);r['pid']=p.pid;(O/'outer-launch.json').write_text(json.dumps(r,indent=2)+'\n');r['exitCode']=p.wait()
r['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['sourceAfter']={name:sha(O/name)for name in r['sourceBefore']};r['stdoutSha256']=sha(O/'outer.stdout.bin');r['stderrSha256']=sha(O/'outer.stderr.bin');r['liveHandles']=[];(O/'outer-terminal.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(r['exitCode'])
