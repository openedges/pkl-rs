# Stage48 새 Java admission controls

고정 0.32.0 JAR/JDK 공개 Evaluator와 실제 StandardSecurityManager를 사용합니다. 같은 site/별도 site/fresh query/closure 공유, resolve deny/retry/catch, singleton edge trust, original/resolved importer, cached/uncached alias, 부분 receiver 뒤 초기화 실패, ImportClause와 ImportExpr factory 시점, stdlib URI spelling, nested jar trust와 qualified ref type 초기화를 새 원문으로 취득합니다. 일반 custom factory/key와 공개 primary/repl lifecycle은 첫 bundled 구현과 별도 미완료 gate입니다.

각 JVM은 같은 원문에서 evaluator 2개를 순차 생성하며 두 fresh JVM repeat를 실행합니다. event는 실제 callback/observer action에서만 발생하고 UTF16과 JavaUTF8를 독립 캡처합니다. 표준 key는 wrapping하지 않으며 factory만 관찰해 singleton 종류를 바꾸지 않습니다. source/key/cache 상태는 실제 callback trace로 판정하고 의도 미도달·오류·내부 boundary는 그대로 남깁니다. Jar URI는 정책 계산과 custom resolved identity일 뿐 실제 jar/network I/O를 하지 않습니다. 새 production/Rust/native/Git 변경이나 Java fallback은 없습니다.
