import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.pkl.core.*;
public final class TrustProbe {
 static Path out;static int events;
 static void text(String name,String value)throws IOException{Files.write(out.resolve(name),value.getBytes(StandardCharsets.UTF_8));}
 static void units(String name,String value)throws IOException{try(var d=new DataOutputStream(Files.newOutputStream(out.resolve(name)))){for(int i=0;i<value.length();i++)d.writeChar(value.charAt(i));}}
 static void event(String value)throws IOException{int i=events++;text("event-"+i+".bin",value);units("event-"+i+".code-units.bin",value);System.out.println(value);}
 interface Action{String run()throws Exception;}
 static void capture(int index,String kind,URI from,URI to,Action action)throws IOException{
  String p="outer-"+index;text(p+".kind.bin",kind);text(p+".from.bin",from.toString());text(p+".to.bin",to==null?"":to.toString());text(p+".events-before.bin",Integer.toString(events));event("api "+kind+" "+from+(to==null?"":" -> "+to));
  try{String value=action.run();text(p+".status.bin","success\n");text(p+".stdout.bin",value);units(p+".stdout.code-units.bin",value);text(p+".stderr.bin","");units(p+".stderr.code-units.bin","");text(p+".error-class.bin","");text(p+".message-null.bin","false");event(p+" success");}
  catch(Exception e){String value=e.getMessage();text(p+".status.bin","error\n");text(p+".stdout.bin","");units(p+".stdout.code-units.bin","");text(p+".stderr.bin",value==null?"":value);units(p+".stderr.code-units.bin",value==null?"":value);text(p+".error-class.bin",e.getClass().getName());text(p+".message-null.bin",Boolean.toString(value==null));var s=new StringWriter();e.printStackTrace(new PrintWriter(s));text(p+".java-stack.bin",s.toString());event(p+" error "+e.getClass().getName());}
  text(p+".events-after.bin",Integer.toString(events));
 }
 public static void main(String[]args)throws Exception{
  Path root=Path.of(args[0]);var uris=Files.readAllLines(Path.of(args[1]));var targets=List.of("repl:text","file:///stage48/target.pkl","file://server/share/target.pkl","modulepath:/target.pkl","pkl:base","https://example.invalid/target.pkl");
  for(int batch=0;batch<2;batch++){
   out=root.resolve("batch-"+batch);Files.createDirectories(out);events=0;int index=0;
   for(String value:uris){URI uri=URI.create(value);capture(index++,"default-trust-level",uri,null,()->SecurityManagers.defaultTrustLevels.apply(uri).toString());}
   for(String value:uris){URI from=URI.create(value);for(String target:targets){URI to=URI.create(target);capture(index++,"check-import",from,to,()->{SecurityManagers.defaultManager.checkImportModule(from,to);return "allowed";});}}
   text("calls.bin",Integer.toString(index));text("events.bin",Integer.toString(events));
  }
 }
}
