from pathlib import Path
import json,os
O=Path(__file__).parent.resolve();cases=[]
def ev(expression,source='main.pkl'):return {'kind':'evaluate','source':source,'expression':expression}
def gc():return {'kind':'gc'}
def policy(value):return {'kind':'policy','value':value}
def cache(value):return {'kind':'cache','value':value}
def add(name,source,ops,mode='allow',files=None,plans=None,entry='main.pkl',scope=''):
 work=O/'workspace'/name;work.mkdir(parents=True,exist_ok=False);(work/'main.pkl').write_text(source)
 for path,data in(files or{}).items():
  p=work/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 rows=[]
 for original,resolved,relative,cached in(plans or[]):rows.append('\t'.join([original,resolved(work),relative,cached]))
 (work/'module-plan.tsv').write_text(''.join(row+'\n'for row in rows))
 operations=[]
 for op in ops:
  if op['kind']=='gc':operations.append('GC')
  elif op['kind']=='policy':operations.append('POLICY\t'+op['value'])
  elif op['kind']=='cache':operations.append('CACHE\t'+op['value'])
  else:operations.append(op['source']+'\t'+op['expression'])
 (work/'operations.tsv').write_text(''.join(row+'\n'for row in operations))
 cases.append({'id':name,'workspace':str(work),'entry':entry,'sourceUri':(work/entry).as_uri(),'mode':mode,'operations':ops,'scope':scope,'inputPaths':[str(p.relative_to(work))for p in work.rglob('*')if p.is_file()]})
 return work
add('resolve-denial-catch-in-module-scope','import "pkl:test" as test\nfunction one() = import("pkl:json")\nfunction caught() = test.catch(() -> one().Property.toString())\nfunction nullable() = test.catchOrNull(() -> one().Property.toString())\nstable = 7\n',[ev('stable'),ev('caught()'),ev('nullable()'),ev('one().Property.toString()'),policy('allow'),ev('caught()'),ev('nullable()'),ev('one().Property.toString()'),policy('trust-json'),ev('one().Property.toString()'),gc(),ev('stable')],mode='deny-json',scope='Corrected fresh module-scoped catch wrappers; 01 query alias lookup failures remain not-reached. Actual denial, retry and site-cache reuse.')
add('singleton-denial-catch-in-module-scope','import "pkl:test" as test\nfunction one() = import("pkl:base")\nfunction two() = import("pkl:base")\nfunction caught() = test.catch(() -> one().Int.toString())\nfunction nullable() = test.catchOrNull(() -> two().Int.toString())\nstable = 7\n',[ev('stable'),ev('caught()'),ev('nullable()'),policy('allow'),ev('one().Int.toString()'),policy('trust-base'),ev('one().Int.toString()'),ev('nullable()'),gc(),ev('stable')],mode='trust-base',scope='Fresh module-scoped actual singleton trust denial catch/catchOrNull; cached successful one differs from still-denied two.')
add('cycle-eager-types-partial-return-init-failure','function a() = import("./a.pkl")\nfunction b() = import("./b.pkl")\nstable = 7\n',[ev('stable'),ev('a().Good.toString()'),ev('b().saved().Good.toString()'),ev('b().fresh().Good.toString()'),ev('b().saved().Good.toString()'),ev('a().Good.toString()'),gc(),ev('b().saved().Good.toString()'),ev('b().fresh().Good.toString()'),ev('stable')],files={'a.pkl':'import "./b.pkl" as b\nopen class Good {}\np: b.B? = null\nq: b.Missing? = null\n','b.pkl':'import "./a.pkl" as a\nclass B {}\np: a.Good? = null\nfunction saved() = a\nfunction fresh() = import("./a.pkl")\n'},scope='Fresh eager nullable property type initialization: A p→B p→A partial import cached, then A q missing type fails. Saved import-clause property vs fresh ImportExpr; actual reach must be audited.')
(O/'cases.json').write_text(json.dumps(cases,indent=2)+'\n')
(O/'input-paths.json').write_text(json.dumps({case['id']:case['inputPaths']for case in cases},indent=2)+'\n')
(O/'PLAN.ko.md').write_text('''# Stage48 admission controls 교정 획득

01의 query-local test 이름 미발견과 lazy class 초기화 미도달을 원문 그대로 보존하고, 새 module-scoped catch 및 eager nullable property type cycle을 별도 취득합니다. 원래 trust matrix는 재취득하지 않습니다. 실제 원시 결과만 기대값이며 의도 미도달은 통과가 아닙니다.
''')
print(json.dumps({'cases':len(cases),'plannedApis':4*sum(sum(op['kind']=='evaluate'for op in c['operations'])for c in cases)},indent=2))
