"""Stage28 suite checks derived from the reviewed Stage26 checker.

Only named function definitions are reused; no donor main or captured evaluator is executed.
The validation counter below adds the new isolated string tests.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess,sys,tarfile
sys.dont_write_bytecode=True
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'tools'))
KNOWN_LANGUAGE={'error-cycle':'oracle-error','error-remainder-zero':'mismatch'}
SOURCE_PROOF={}

def validation_test_counts(output, sources):
    summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',output)
    require(summaries and all(int(row[1])==0 for row in summaries),'missing successful Rust summaries')
    groups=[('m2_frontend_lifecycle.rs',r'^authored frontend completed: (\w+); stack=262144; depth=768$',5),
            ('m2_string_frontend_lifecycle.rs',r'^authored string frontend completed: (\w+); stack=262144$',4),
            ('m2_lexical_diagnostic_lifecycle.rs',r'^lexical diagnostic lifecycle completed: (\w+); stack=262144$',2),
            ('m2_unicode_diagnostic_lifecycle.rs',r'^stage28 unicode diagnostic completed: (\w+); stack=262144$',2)]
    names=[]
    summaries_by_filtered=Counter()
    for filename,pattern,expected in groups:
        source=(sources/'crates/pkl-runtime/tests'/filename).read_text()
        tests=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',source)
        require(len(tests)==len(set(tests))==expected,'isolated source inventory differs: '+filename)
        require(Counter(re.findall(pattern,output,re.M))==Counter(tests),'isolated completion coverage differs: '+filename)
        # Parent and child writes may interleave after the numeric fields. The
        # exact successful summary prefix and explicit completion markers suffice
        # to count child duplicates without rewriting the captured output.
        prefix=r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; '+str(expected-1)+r' filtered out'
        summaries_by_filtered[expected-1] += expected
        names.extend(tests)
    for filtered,expected in summaries_by_filtered.items():
        prefix=r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; '+str(filtered)+r' filtered out'
        require(len(re.findall(prefix,output))==expected,'isolated harness summary coverage differs')
    require(len(names)==len(set(names)),'duplicate isolated test names')
    for name in names:
        require(len(re.findall(r'test '+re.escape(name)+r' \.\.\.',output))==2,'child/parent test invocation coverage differs: '+name)
    harness=sum(int(row[0]) for row in summaries)
    return dict(rust_passed=harness-len(names),rust_harness_passed=harness,
                rust_isolated_child_duplicate_passed=len(names),rust_isolated_child_tests=names,
                rust_intentionally_ignored=sum(int(row[2]) for row in summaries))

def require(condition, message):
    if not condition: raise ValueError(message)

def load(path): return json.loads(Path(path).read_bytes())

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def encoded(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def write(path, value):
    with path.open('xb') as stream: stream.write(encoded(value))

def identity(path, digest, size=None):
    require(sha(path) == digest and (size is None or path.stat().st_size == size), 'identity differs: ' + str(path))

def old_report(references, suite):
    with tarfile.open(ROOT / references['archives'][suite]['path']) as stream:
        return json.load(stream.extractfile('report.json'))

def raw_process(process):
    require(process['status'] == 'executed', 'process did not execute')
    values = []
    for channel in ['stdout', 'stderr']:
        row = process[channel]; path = Path(row['path']); identity(path, row['sha256'], row['bytes']); values.append(path.read_bytes())
    return (process['exit_code'], *values)

def verify_validation(directory):
    report = load(directory / 'report.json')
    require(report['source_stability'] and report['source_sha256_before'] and report['source_sha256_before']==report['source_sha256_after'], 'required validation sources changed during acquisition')
    observed={p.relative_to(directory/'sources').as_posix() for p in (directory/'sources').rglob('*') if p.is_file()}
    require(observed==set(report['source_sha256_before']), 'validation source snapshot closure differs')
    for name,digest in report['source_sha256_before'].items():identity(directory/'sources'/name,digest)
    for label,row in report['identities'].items():
        require(row['exit_code']==0,'validation environment identification failed')
        for channel in ['stdout','stderr']:identity(directory/(label+'.'+channel+'.bin'),row[channel+'_sha256'])
    required = [['cargo','xtask','verify'],['cargo','fmt','--all','--','--check'],
        ['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],
        ['cargo','test','--workspace','--locked'],['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked']]
    require([r['command'] for r in report['checks'][:5]] == required and len(report['checks']) == 7, 'required checks changed')
    require(report['checks'][5]['command'][1:] == ['-m','unittest','discover','-s','tools/tests','-v'] and
            report['checks'][6]['command'][1:] == ['tools/m2_manifest.py','--check'], 'required Python/inventory checks changed')
    outputs = []
    for index, row in enumerate(report['checks']):
        require(row['exit_code'] == 0, 'required check failed: ' + repr(row['command']))
        text = ''
        for channel in ['stdout','stderr']:
            path = directory / f'{index}.{channel}.bin'; identity(path,row[channel+'_sha256']); text += path.read_text()
        outputs.append(text)
    rust = validation_test_counts(outputs[3],directory/'sources')
    python = re.findall(r'Ran (\d+) tests? in ', outputs[5])
    require(len(python)==1 and re.search(r'\nOK\s*$',outputs[5]), 'missing successful Python test summary')
    return dict(**rust,python_passed=int(python[0]), required_commands=7)

def audit_suite(name,directory,references):
    import m1_frontend,m1_lifecycle,m1_platforms,m1_runtime,m2_class_lifecycle,m2_language
    if name=='language':
        report=m2_language.check_report(directory)
        require(m2_language.development_passes(report,directory),'language development gate failed')
        require(report['candidate']['source_binding']=='recorded-build','final language candidate lacks recorded build')
        failures={r['id']:r['status'] for r in report['results'] if r['status']!='pass'}
        require(set(failures)==set(KNOWN_LANGUAGE) and failures['error-remainder-zero']=='mismatch' and failures['error-cycle'] in ['oracle-error','mismatch'],'language known failure inventory changed')
        previous=old_report(references,'language')
        old_relations=previous['metamorphic_results'];new_relations=report['metamorphic_results']
        relation_key=lambda row:(row['kind'],tuple(row['case_ids']))
        old_keys={relation_key(row) for row in old_relations};new_keys={relation_key(row) for row in new_relations}
        require(len(old_keys)==len(old_relations) and len(new_keys)==len(new_relations),'duplicate metamorphic relation identity')
        require([row for row in new_relations if relation_key(row) in old_keys]==old_relations,
                'old metamorphic relation records or relative order changed')
        return dict(selected_count=report['selected_count'],status_counts=report['status_counts'],inventory_counts=report['inventory_counts'],
                    metamorphic_relations=len(report['metamorphic_results']),metamorphic_passed=sum(r['status']=='pass' for r in report['metamorphic_results']),
                    full_gate_failure_count=len(report['full_gate_failures']),candidate=report['candidate'])
    if name=='validation': return verify_validation(directory)
    if name=='frontend':
        report=m1_frontend.check_report(directory)
        return dict(cases=len(report['results']),passed=sum(r['passed'] for r in report['results']))
    if name=='lifecycle':
        report=m1_lifecycle.check_report(directory)
        return dict(cases=len(report['cases']),compatibility_complete=report['compatibility_complete'],limitations=report['limitations'])
    if name=='class-lifecycle':
        report=m2_class_lifecycle.check_report(directory);require(m2_class_lifecycle.contract_passes(report),'persistent contract failed')
        old=old_report(references,'class-lifecycle');oldids={r['id'] for r in old['cases']};preserved=[r for r in report['cases'] if r['id'] in oldids]
        require(len(preserved)==len(old['cases']) and report['repetitions']==old['repetitions'],'old sequence coverage changed')
        for a,b in zip(old['cases'],preserved):
            require((a['id'],a['repetition'])==(b['id'],b['repetition']) and a['observations']['comparisons']==b['observations']['comparisons'],'old persistent observations changed')
            for engine in ['java','rust']:
                require(a['observations']['processes'][engine]['calls']==b['observations']['processes'][engine]['calls'],'old persistent raw channels changed')
        return dict(unique_sequences=len(report['cases'])//report['repetitions'],executions=len(report['cases']),
                    comparisons=sum(len(r['observations']['comparisons']) for r in report['cases']),unexecuted_groups=report['unexecuted_groups'])
    if name=='runtime':
        report=load(directory/'report.json');require([r['id'] for r in report['cases']]==list(m1_runtime.SUCCESS_CASES+m1_runtime.ERROR_CASES),'runtime coverage changed')
        require(report['identities'], 'runtime source/artifact identities missing')
        binary_paths={directory/'binaries'/name for name in ['runtime_probe','runtime_bench']}
        recorded_binaries=set()
        for row in report['identities']:
            path=Path(row.get('snapshot',row['path']))
            identity(path,row['sha256'],row['bytes'])
            if 'snapshot' in row:
                require(path.is_relative_to(directory/'sources'), 'runtime source identity outside snapshot closure')
            else:
                require(path in binary_paths, 'unexpected runtime binary identity')
                require(path not in recorded_binaries, 'duplicate runtime binary identity')
                recorded_binaries.add(path)
        require(recorded_binaries==binary_paths, 'runtime binary identity coverage differs')
        counts=Counter()
        for row in report['cases']:
            require(row['rust']['command']==[str(directory/'binaries/runtime_probe'),row['input'],'result'],
                    'runtime process does not execute retained probe/input')
            java=raw_process(row['java']);rust=raw_process(row['rust']);require(row['raw_equal']==(java==rust),'runtime raw equality differs')
            if row['id'] in m1_runtime.SUCCESS_CASES:
                require(java[0]==rust[0]==0 and java==rust, 'runtime success raw bytes or exits differ: '+row['id'])
            else:
                require(java[0]==rust[0]==1, 'runtime error exits differ: '+row['id'])
            expected='bounded-value-bytes-match' if row['id'] in m1_runtime.SUCCESS_CASES else ('diagnostic-bytes-match' if java==rust else 'diagnostic-byte-mismatch')
            require(row['status']==expected and (expected!='diagnostic-byte-mismatch' or row['id']=='forcing-cycle'),'new runtime mismatch');counts[expected]+=1
        return dict(status_counts=dict(counts),compatibility_complete=False)
    if name=='platforms':
        report=load(directory/'report.json');execution=load(directory/'execution/execution.json')
        source_hashes=report['source_hashes']
        require(source_hashes and source_hashes==load(directory/'sources.json'), 'platform declared source identities differ or are empty')
        snapshots={p.relative_to(directory/'sources').as_posix() for p in (directory/'sources').rglob('*') if p.is_file()}
        require(snapshots==set(source_hashes), 'platform source snapshot closure differs')
        for path,digest in source_hashes.items():identity(directory/'sources'/path,digest)
        require(report['execution']==execution,'platform execution metadata differs');m1_platforms.check_scenarios(execution)
        for target in ['node','browser']:require(execution[target+'Checks']==load(directory/('execution/'+target+'-checks.json')),'platform scenario capture differs')
        captures={key:(directory/path).read_bytes() for key,path in [('java','oracle-native/java.stdout.bin'),('rust','oracle-native/rust.stdout.bin'),('node','execution/node.stdout.bin'),('browser','execution/browser.stdout.bin')]}
        rows=m1_platforms.compare(m1_platforms.generate_cases()['cases'],captures)
        require(rows==report['comparisons'] and report['source_stability'] and m1_platforms.contract_matches(rows),'platform raw contract failed')
        for path,digest in report['artifacts'].items():identity(directory/path,digest)
        counts=dict(total=len(rows),shared_engine_passed=sum(r['shared_engine_match'] for r in rows),
                    oracle_passed={target:sum(r['oracle_matches'][target] for r in rows) for target in ['rust','node','browser']})
        for key,value in counts.items():require(report[key]==value,'platform exported count differs: '+key)
        require(set(report['known_gaps'])==m1_platforms.KNOWN_GAPS,'platform known gap inventory changed')
        commands=load(directory/'commands.json')
        require([row['name'] for row in commands]==['bindgen-version','rust-version','native-build','napi-build','wasm-build','wasm-bindgen','oracle-native','platforms'],
                'platform command coverage/order differs')
        bindgen=commands[0]['command'][0]
        native='semantics_probe.exe' if sys.platform=='win32' else 'semantics_probe'
        expected_commands=[
            [bindgen,'--version'],['rustc','-Vv'],
            ['cargo','build','-p','pkl-runtime','--example','semantics_probe','--locked'],
            ['cargo','build','-p','pkl-napi','--release','--locked'],
            ['cargo','build','-p','pkl-wasm','--target','wasm32-unknown-unknown','--release','--locked'],
            [bindgen,'--target','web','--out-dir',str(directory/'wasm'),str(ROOT/'target/wasm32-unknown-unknown/release/pkl_wasm.wasm')],
            [sys.executable,'tools/m1_semantics.py','--candidate',str(directory/native),'--output',str(directory/'oracle-native')],
            ['node','tools/platform/run.mjs',str(directory/'execution'),str(directory/'wasm'),str(directory/'pkl_napi.node'),str(ROOT/'tests/fixtures/m1/semantics/cases.json')],
        ]
        require([row['command'] for row in commands]==expected_commands, 'platform command arguments differ')
        identity(Path(bindgen),report['wasm_bindgen_sha256'])
        require((directory/'bindgen-version.stdout.bin').read_bytes()==b'wasm-bindgen 0.2.108\n', 'platform bindgen version differs')
        for row in commands:
            require(row['exit_code']==(1 if row['name']=='oracle-native' else 0), 'platform build/execution command failed or known failure exit changed')
            for channel in ['stdout','stderr']:
                require((directory/(row['name']+'.'+channel+'.bin')).is_file(), 'platform raw command channel missing')
        old=old_report(references,'platforms')
        for field in ['nodeChecks','browserChecks']:
            require([x for x in execution[field] if x in old['execution'][field]]==old['execution'][field],'old platform order changed')
        return dict(total=len(rows),shared_engine_passed=sum(r['shared_engine_match'] for r in rows),
                    oracle_passed={target:sum(r['oracle_matches'][target] for r in rows) for target in ['rust','node','browser']},
                    node_scenarios=len(execution['nodeChecks']),browser_scenarios=len(execution['browserChecks']),known_gaps=report['known_gaps'])
    if name=='prior-selection':return verify_prior(directory,references)
    if name=='release-build':
        report=load(directory/'candidate.json')
        require(report['source_binding']=='recorded-build' and report['source_stability'] and report['source_sha256_before']==report['source_sha256_after'], 'final release source/build binding failed')
        for label in ['build','rustc','cargo']:
            row=report[label];require(row['exit_code']==0 and not row['timed_out'], 'release build command failed')
            for channel in ['stdout','stderr']:identity(directory/(( 'cargo-version' if label=='cargo' else label)+'.'+channel+'.bin'),row[channel+'_sha256'])
        for label,row in report['artifacts'].items():identity(directory/'artifacts'/label,row['frozen_sha256'])
        return dict(artifacts=report['artifacts'],source_stability=True)
    if name=='native-frontend':
        report=load(directory/'report.json')
        require(report['source_stability'] and report['source_sha256_before'] and report['source_sha256_before']==report['source_sha256_after'],'focused lifecycle source drift or missing identities')
        snapshots={path.relative_to(directory/'sources').as_posix() for path in (directory/'sources').rglob('*') if path.is_file()}
        require(snapshots==set(report['source_sha256_before']), 'focused native source snapshot closure differs')
        expected_sources={path.relative_to(ROOT).as_posix() for path in (ROOT/'crates/pkl-runtime/src').rglob('*')
                          if path.is_file() and path.suffix in {'.rs','.pkl','.mjs','.json'}}
        expected_sources.update(['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock',
                                 'crates/pkl-runtime/Cargo.toml','crates/pkl-runtime/tests/m2_unicode_diagnostic_lifecycle.rs'])
        require(snapshots==expected_sources, 'focused native required source closure differs')
        for source,digest in report['source_sha256_before'].items():identity(directory/'sources'/source,digest)
        require([row['name'] for row in report['commands']]==['git-head','git-status','rust-version','build','native-lifecycle'],
                'focused native command coverage/order differs')
        for row in report['commands']:
            require(row['exit_code']==0 and not row['timed_out'],'focused native/tool command failed: '+row['name'])
            for channel in ['stdout','stderr']:identity(directory/(row['name']+'.'+channel+'.bin'),row[channel+'_sha256'])
        for row in report['artifacts']: identity(directory/row['path'],row['sha256'],row['bytes'])
        require(len(report['artifacts'])==1, 'focused lifecycle binary closure differs')
        build=next(row for row in report['commands'] if row['name']=='build')
        require(build['command']==['cargo','test','-p','pkl-runtime','--locked','--test','m2_unicode_diagnostic_lifecycle','--no-run','--message-format=json'],
                'focused native build command differs')
        messages=[json.loads(line) for line in (directory/'build.stdout.bin').read_bytes().splitlines()]
        origins=[row for row in messages if row.get('reason')=='compiler-artifact' and row.get('executable')
                 and row.get('target',{}).get('name')=='m2_unicode_diagnostic_lifecycle']
        require(len(origins)==1 and origins[0]['target'].get('kind')==['test'], 'focused native compiler artifact origin differs')
        artifact=Path(report['artifacts'][0]['path'])
        require(artifact==Path('artifacts')/Path(origins[0]['executable']).name,
                'focused native retained artifact differs from compiler output')
        executions=[row for row in report['commands'] if row['name']=='native-lifecycle']
        require(len(executions)==1 and executions[0]['command']==[
            str(directory/report['artifacts'][0]['path']),'--nocapture','--test-threads=1'],
            'focused native execution is filtered or does not use retained binary')
        raw=(directory/'native-lifecycle.stdout.bin').read_text();counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed;',raw)
        require(counts and not any(int(row[1]) for row in counts),'focused native lifecycle result missing')
        expected=(directory/'sources/crates/pkl-runtime/tests/m2_unicode_diagnostic_lifecycle.rs').read_text().count('#[test]')
        require(int(counts[-1][0])==expected,'native lifecycle top-level count differs from recorded source')
        return dict(passed=expected,source_stability=True,conditions=report['conditions'])
    raise ValueError('unknown suite '+name)

def source_binding(commit,directories):
    require(re.fullmatch('[0-9a-f]{40}',commit) is not None,'full implementation commit required')
    kind=subprocess.check_output(['git','cat-file','-t',commit],cwd=ROOT)
    require(kind==b'commit\n','implementation identity is not a Git commit')
    copies=[];helpers=[]
    for suite,directory in directories.items():
        for source_root in [directory/'sources',directory/'oracle-native/sources']:
            if not source_root.is_dir():continue
            for path in sorted(source_root.rglob('*')):
                if not path.is_file():continue
                name=path.relative_to(source_root).as_posix()
                row=dict(suite=suite,path=name,snapshot=str(path.relative_to(ROOT)),sha256=sha(path),bytes=path.stat().st_size)
                if name.startswith('target/'):
                    helpers.append(row);continue
                require(not name.startswith('external/'),'upstream source copies need explicit gitlink proof')
                copies.append(row)
    names=sorted({r['path'] for r in copies});require(names,'no final source snapshots')
    request=('\n'.join(commit+':'+name for name in names)+'\n').encode()
    process=subprocess.run(['git','cat-file','--batch'],input=request,cwd=ROOT,capture_output=True)
    require(process.returncode==0,'Git source proof command failed')
    SOURCE_PROOF.update(command=['git','cat-file','--batch'],request=request,stdout=process.stdout,stderr=process.stderr,exit_code=process.returncode)
    position=0;blobs={};blob_ids={}
    for name in names:
        end=process.stdout.index(b'\n',position);fields=process.stdout[position:end].split()
        require(len(fields)==3 and fields[1]==b'blob','missing implementation source '+name)
        size=int(fields[2]);blobs[name]=process.stdout[end+1:end+1+size];blob_ids[name]=fields[0].decode();position=end+size+2
    require(position==len(process.stdout),'extra Git source proof bytes')
    for row in copies:
        row['git_blob']=blob_ids[row['path']]
        require((ROOT/row['snapshot']).read_bytes()==blobs[row['path']],'snapshot differs from exact commit: '+row['snapshot'])
        require((ROOT/row['path']).read_bytes()==blobs[row['path']],'working source differs from exact commit: '+row['path'])
    return dict(implementation_commit=commit,source_snapshot_copies=len(copies),unique_source_files=len(names),
                upstream_source_snapshot_copies=0,upstream_blob_proof_claimed=False,copies=copies,
                untracked_helpers_with_separate_hashes=helpers,git_request_sha256=hashlib.sha256(request).hexdigest(),
                git_response_sha256=hashlib.sha256(process.stdout).hexdigest(),scope='Only final project source copies enumerated here equal exact implementation Git bytes. Historical focused/exploratory sources retain separate provenance.')
