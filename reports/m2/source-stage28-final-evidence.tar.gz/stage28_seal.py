"""Seal explicit Stage28 acquisitions after source, byte and contract checks.

No evaluator is run. Historical Stage27 evidence remains a hash dependency.
Only configured direct Cargo build directories may be omitted without enumeration.
"""
from pathlib import Path
from collections import Counter
import argparse, ast, datetime, hashlib, json, os, shutil, subprocess, sys

sys.dont_write_bytecode = True
ROOT = Path.cwd()
sys.path[:0] = [str(ROOT/'tools'), str(ROOT/'target/m2')]
import evidence
import stage28_suite_checks as checks

BASELINE = '2822ecaae5316f7a49e8f81aa19a9db7879d61cb'
SUITES = ['language','validation','platforms','frontend','runtime','lifecycle','class-lifecycle','native-frontend']

def need(ok, message):
    if not ok:
        raise ValueError(message)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def identity(path):
    path=Path(path)
    raw=path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(),bytes=len(raw),sha256=digest(raw))

def git_blob(commit, name):
    return subprocess.check_output(['git','show',commit+':'+name],cwd=ROOT)

def preserve(commit):
    selected='tests/fixtures/m2/cases.json'
    sequences='compatibility/m2-class-lifecycle/manifest.json'
    old=json.loads(git_blob(BASELINE,selected))['cases']
    new=json.loads(git_blob(commit,selected))['cases']
    need(new[:len(old)]==old and len({r['id'] for r in new})==len(new),'original selection changed or duplicate IDs')
    before=json.loads(git_blob(BASELINE,sequences));after=json.loads(git_blob(commit,sequences))
    need(git_blob(BASELINE,sequences)==git_blob(commit,sequences),'persistent sequence manifest bytes changed')
    need(len({r['id'] for r in after['sequences']})==len(after['sequences']),'duplicate sequences')
    for key in ['schema','uri','module_name','power_assertions']:
        need(before[key]==after[key],'sequence context changed: '+key)
    need(all(row in after['unexecuted_groups'] for row in before['unexecuted_groups']),'removed unexecuted scope')
    changes=subprocess.check_output(['git','diff','--name-status','--no-renames',BASELINE,commit,'--',
        'tests/fixtures/m2','compatibility/m2-class-lifecycle','crates/pkl-runtime/tests'],cwd=ROOT).decode().splitlines()
    for line in changes:
        status,path=line.split('\t')
        need(status=='A' or (status=='M' and path==selected),'existing fixture/test changed: '+line)
    def scenarios(raw):
        return next(ast.literal_eval(n.value) for n in ast.parse(raw).body if isinstance(n,ast.Assign)
                    and any(isinstance(t,ast.Name) and t.id=='REQUIRED_SCENARIOS' for t in n.targets))
    original=scenarios(git_blob(BASELINE,'tools/m1_platforms.py'))
    current=scenarios(git_blob(commit,'tools/m1_platforms.py'))
    need(original<=current,'original platform scenarios removed')
    need(git_blob(BASELINE,'references.lock')==git_blob(commit,'references.lock'),'reference pins changed')
    return dict(baseline=BASELINE,original_selected=len(old),current_selected=len(new),
        added_ids=[r['id'] for r in new[len(old):]],added_expected_outcomes=dict(Counter(r['expected_outcome'] for r in new[len(old):])),
        original_sequences=len(before['sequences']),current_sequences=len(after['sequences']),
        original_platform_scenarios=len(original),current_platform_scenarios=len(current),
        original_fixture_and_native_test_bytes_unchanged=True,fixture_changes=changes)

def copy_tree(source, target, omitted, originals):
    """Do not descend into explicitly named direct-child Cargo build caches."""
    source=Path(source)
    need(source.exists() and not source.is_symlink(),'missing/linked source '+str(source))
    if source in omitted:
        need(source.is_dir() and source.name=='build','invalid omitted cache')
        return
    if source.is_file():
        raw=source.read_bytes();target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as stream: stream.write(raw)
        originals.append(dict(path=source.relative_to(ROOT).as_posix(),bytes=len(raw),sha256=digest(raw),
                              archive_path=target.relative_to(STAGING).as_posix()))
        return
    for child in sorted(source.iterdir()):
        copy_tree(child,target/child.name,omitted,originals)

def closure(roots, omitted):
    result={}
    def visit(path):
        need(path.exists() and not path.is_symlink(),'missing/linked evidence '+str(path))
        if path in omitted:
            need(path.is_dir() and path.name=='build','invalid omitted cache')
        elif path.is_file():
            row=identity(path);result[row['path']]=row
        else:
            for child in sorted(path.iterdir()):visit(child)
    for root in roots:visit(root)
    return result

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--config',type=Path,required=True)
args=parser.parse_args()
config=read(args.config)
commit=config['implementation_commit']
need(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()==commit,'HEAD is not implementation commit')
directories={name:(ROOT/path).resolve() for name,path in config['suites'].items()}
need(set(directories)==set(SUITES),'suite closure differs')
support_roots=[(ROOT/p).resolve() for p in config['support_roots']]
support_omitted={(ROOT/p).resolve() for p in config['support_omitted_build_caches']}
core_omitted={directory/'build' for directory in directories.values() if (directory/'build').is_dir()}
all_roots=[*directories.values(),*support_roots]
STAGING=(ROOT/config['staging']).resolve()
need(len(support_roots)==len(set(support_roots)),'duplicate support roots')
need(len(directories)==len(set(directories.values())),'duplicate core roots')
need(all(not a.is_relative_to(b) for a in directories.values() for b in directories.values() if a!=b),'nested core roots')
need(all(not a.is_relative_to(b) for a in support_roots for b in support_roots if a!=b),'nested support roots')
need(all(not a.is_relative_to(b) and not b.is_relative_to(a) for a in support_roots for b in directories.values()),'support/core overlap')
need(all(not STAGING.is_relative_to(path) and not path.is_relative_to(STAGING) for path in all_roots),'staging overlaps an acquisition root')
for path in support_omitted:
    need(path.name=='build' and path.parent in support_roots and path.is_dir(),'cache not direct child of explicit support root')
preflight=closure(all_roots,core_omitted|support_omitted)
history_path=ROOT/'reports/m2/stage27-final-summary.json'
need(history_path.read_bytes()==git_blob(BASELINE,'reports/m2/stage27-final-summary.json'),'historical summary differs from baseline')
history=read(history_path)
for row in history['archives'].values():
    need(identity(ROOT/row['path'])=={key:row[key] for key in ['path','bytes','sha256']},'historical archive changed')
history_extras={}
for label,name in [('audit','stage27-post-seal-audit.json'),('completion','stage27-completion-captures.json')]:
    path=ROOT/'reports/m2'/name
    need(path.read_bytes()==git_blob(BASELINE,'reports/m2/'+name),'historical '+label+' changed')
    history_extras[label]=identity(path)
references=dict(summary=identity(history_path),archives=history['archives'],**history_extras,
    scope='Direct Stage27 archive identities verified; inherited evidence remains referenced through its immutable summary, not recursively rerun or re-audited.')
preservation=preserve(commit)
outcomes={name:checks.audit_suite(name,directories[name],references) for name in SUITES}
binding=checks.source_binding(commit,directories)
need(not binding['untracked_helpers_with_separate_hashes'],'unexpected target-only helper among final project snapshots')
gate_dir=(ROOT/config['gates']).resolve()
need(gate_dir in support_roots,'gate captures absent from explicit support closure')
gates=read(gate_dir/'report.json')['gates']
gate_specs=[('report','tools/m2_language.py','--verify-report','language',0),
            ('development','tools/m2_language.py','--verify-development','language',0),
            ('subset','tools/m2_language.py','--verify-subset','language',1),
            ('full','tools/m2_language.py','--verify-full','language',1),
            ('class-report','tools/m2_class_lifecycle.py','--verify-report','class-lifecycle',0),
            ('class-contract','tools/m2_class_lifecycle.py','--verify-contract','class-lifecycle',0)]
need(len(gates)==len(gate_specs),'gate coverage differs')
for row,(name,tool,flag,suite,expected) in zip(gates,gate_specs):
    need(row['name']==name and row['expected_exit']==row['exit_code']==expected and not row['timed_out'],'gate outcome differs '+name)
    need(row['command'][1:]==[tool,flag,directories[suite].relative_to(ROOT).as_posix()],'gate invocation differs '+name)
    for channel in ['stdout','stderr']:
        need(digest((gate_dir/(name+'.'+channel+'.bin')).read_bytes())==row[channel+'_sha256'],'gate raw channel differs '+name)
language=read(directories['language']/'report.json')
result_by_id={row['id']:row for row in language['results']}
need(all(result_by_id[name]['status']=='pass' for name in preservation['added_ids']),'new selected case failed')

STAGING.mkdir(parents=True,exist_ok=False)
source=STAGING/'source';source.mkdir()
write(source/'source-binding.json',binding)
for key in ['request','stdout','stderr']:
    (source/('git-'+key+'.bin')).write_bytes(checks.SOURCE_PROOF[key])
write(source/'git-process.json',{k:v for k,v in checks.SOURCE_PROOF.items() if k not in ['request','stdout','stderr']})
write(source/'preservation.json',preservation)
write(source/'acquisition-preflight.json',dict(files=list(preflight.values()),omitted_roots=[p.relative_to(ROOT).as_posix() for p in sorted(core_omitted|support_omitted)]))
write(source/'config.json',config)
helpers=[Path(__file__).resolve(),ROOT/'target/m2/stage28_suite_checks.py',ROOT/'target/m2/stage28-suite-checks-preparation.json']
for path in helpers:
    shutil.copy2(path,source/path.name)
review_rows=[]
for name in config['reviews']:
    path=ROOT/name;row=read(path)
    need(row['status']=='pass' and row['implementation_commit']==commit,'incomplete review '+name)
    shutil.copy2(path,source/path.name);review_rows.append(identity(path))

archives={};omissions=[]
for name in SUITES:
    directory=directories[name]
    omitted={directory/'build'} if (directory/'build').is_dir() else set()
    originals=[];destination=STAGING/name
    copy_tree(directory,destination,omitted,originals)
    for path in omitted:
        omissions.append(dict(path=path.relative_to(ROOT).as_posix(),payload_enumerated=False,
            reason='Direct suite Cargo build cache; captured artifact, build output and source snapshots are retained.'))
    write(destination/'STAGE28-ORIGINALS.json',dict(files=originals,omitted_build_caches=[p.relative_to(ROOT).as_posix() for p in omitted]))
    archive=ROOT/'reports/m2'/(name+'-stage28-final-evidence.tar.gz')
    need(not archive.exists(),'archive already exists '+str(archive))
    evidence.create(destination,archive,[]);archives[name]=identity(archive)

support=STAGING/'support';support.mkdir()
omitted=support_omitted
for path in omitted:
    omissions.append(dict(path=path.relative_to(ROOT).as_posix(),payload_enumerated=False,
        reason='Exploratory Cargo build cache; complete captured source/artifact/process records retained.'))
originals=[]
for root in support_roots:
    copy_tree(root,support/root.relative_to(ROOT),omitted,originals)
write(support/'STAGE28-ORIGINALS.json',dict(files=originals,explicit_roots=config['support_roots'],
    omitted_build_caches=config['support_omitted_build_caches']))
for path in [support,source]:
    archive=ROOT/'reports/m2'/(path.name+'-stage28-final-evidence.tar.gz')
    need(not archive.exists(),'archive already exists '+str(archive))
    evidence.create(path,archive,[]);archives[path.name]=identity(archive)
for row in originals:
    need(identity(ROOT/row['path'])=={k:row[k] for k in ['path','bytes','sha256']},'support changed during sealing')
for name,directory in directories.items():
    rows=read(STAGING/name/'STAGE28-ORIGINALS.json')['files']
    need(all(identity(ROOT/r['path'])=={k:r[k] for k in ['path','bytes','sha256']} for r in rows),'core changed during sealing '+name)
need(closure(all_roots,core_omitted|support_omitted)==preflight,'acquisition closure changed between preflight, audit and sealing')
summary=dict(schema=1,status='ready',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    implementation_commit=commit,completed_suites=outcomes,preservation=preservation,
    source_binding={k:v for k,v in binding.items() if k not in ['copies','untracked_helpers_with_separate_hashes']},
    archives=archives,historical_dependencies=references,reviews=review_rows,
    gates=gates,
    helper_provenance=[identity(p) for p in helpers],configuration=identity(args.config.resolve()),
    support=dict(original_files=len(originals),explicit_roots=config['support_roots']),
    omitted_build_caches=omissions,omitted_cache_payload_sizes_and_hashes_claimed=False,
    captured_evaluators_executed=False,compatibility_complete=False,performance_targets_established=False,
    known_unverified_scope=config['known_unverified_scope'])
output=ROOT/'reports/m2/stage28-final-summary.json';write(output,summary)
print(json.dumps(dict(status='sealed',summary=identity(output),archives=len(archives),
    source_copies=binding['source_snapshot_copies'],unique_source_files=binding['unique_source_files'])),flush=True)
