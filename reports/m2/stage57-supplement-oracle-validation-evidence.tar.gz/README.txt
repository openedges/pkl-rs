Stage57 separate A2 DataSize/Bytes Java supplement validation

This archive contains frozen local check logs, source/fixture inputs, and an independent review. The 7,612-member raw Java archive is a separate public fixture at tests/fixtures/m2-data-size-supplement/oracle-evidence.tar.gz, SHA-256 ab8c59f0a42611aa8325d70ab2c1cc83ec59f19d12a848ee816829acbed6b6ad. Capture04 remains incomplete. Candidate passes claimed: zero. See manifest.json for each packaged source SHA-256 and size. Actual Git object binding is pending.
