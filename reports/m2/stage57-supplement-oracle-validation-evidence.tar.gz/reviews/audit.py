import collections, hashlib, json, pathlib, re, tarfile
root = pathlib.Path.cwd()
fix = root / 'tests/fixtures/m2-data-size-supplement'
arc = fix / 'oracle-evidence.tar.gz'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(arc.read_bytes()) == 'ab8c59f0a42611aa8325d70ab2c1cc83ec59f19d12a848ee816829acbed6b6ad'
with tarfile.open(arc) as tf:
    ms = {m.name: tf.extractfile(m).read() for m in tf if m.isfile()}
assert len(ms) == 7612
result = {'archive_sha256': sha(arc.read_bytes()), 'members': len(ms), 'cohorts': {}}
for c in ('04','05','06','07','08','09'):
    pre = f'capture-{c}/'
    files = {n[len(pre):]:b for n,b in ms.items() if n.startswith(pre)}
    cases = json.loads(files['cases.json']); prov = json.loads(files['provenance.json'])
    rows = cases['rows']; ids = [r['id'] for r in rows]
    assert len(ids) == len(set(ids))
    q = files['queries.tsv'].decode().splitlines()
    assert q == [r['id']+'\t'+r['expression'] for r in rows]
    assert cases['repetitions'] == 2 and cases['module_uri'] == prov['sessions'][0]['command'][-1] if c!='06' else cases['module_uri'] == prov['runs'][0]['command'][-1]
    assert prov['artifact_sha256'] == prov['artifact_after_sha256'] == 'c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059'
    assert prov['input_before'] == prov['input_after']
    assert prov['source_before'] == prov['source_after']
    assert prov['stable'] is True
    assert prov['complete'] is (c!='04')
    for n,h in prov['input_before'].items(): assert sha(files[n]) == h, (c,n)
    sessions = prov.get('sessions',prov.get('runs'))
    assert len(sessions) == (2 if c=='06' else 4)
    assert len({s['pid'] for s in sessions}) == len(sessions)
    bymode=collections.defaultdict(list)
    for s in sessions:
        mode = s.get('mode','identity'); rep=s['repeat']; bymode[mode].append(rep)
        assert s['exit_code']==0 and s['query_directories']==len(rows)
        assert s['command'][0] == '/usr/bin/java' and '-cp' in s['command'] and s['command'][-1] == cases['module_uri']
        assert s['command'][-3].endswith(f'repeat-{rep}') or (c=='06' and s['command'][-3].endswith(f'repeat-{rep}'))
        prefix = f'{mode}/repeat-{rep}' if mode!='identity' else f'repeat-{rep}'
        for stream in ('stdout','stderr'):
            b=files[f'{prefix}/process.{stream}.bin']
            assert len(b)==s[f'{stream}_bytes'] and sha(b)==s[f'{stream}_sha256']
    assert all(sorted(v)==[0,1] for v in bymode.values())
    summary={'rows':len(rows),'sessions':len(sessions),'complete':prov['complete'],'modes':{},'module_sha256':sha(files['module.pkl']),'query_sha256':sha(files['queries.tsv']),'jdk':prov['jdk'],'artifact_sha256':prov['artifact_sha256']}
    for mode in bymode:
        base = '' if mode=='identity' else mode+'/'
        status=[]; raw_file_count=0
        for rep in (0,1):
            dirs=[f'{base}repeat-{rep}/{i:03d}-{rid}/' for i,rid in enumerate(ids)]
            for i,d in enumerate(dirs):
                assert files[d+'expression.bin']==rows[i]['expression'].encode('utf-8')
                assert files[d+'expression.code-units.bin']==rows[i]['expression'].encode('utf-16-be')
                sn=d+('call-0.status.bin' if mode=='identity' or mode=='export' else 'result.status.bin')
                stat=files[sn]; assert stat in (b'success\n',b'error\n')
                if rep==0:status.append(stat.decode().strip())
                else:assert stat.decode().strip()==status[i]
                if stat==b'error\n':
                    error = files[d+('call-0.error.bin' if mode=='identity' or mode=='export' else 'result.stderr.bin')]
                    assert error, (c,mode,rep,i)
            p=f'{base}repeat-{rep}/'; names=[n for n in files if n.startswith(p)]
            raw_file_count=len(names)
            if rep==0: first={n[len(p):]:files[n] for n in names if not n.endswith('/process.stdout.bin') and not n.endswith('/process.stderr.bin') and not n.endswith('process.stdout.bin') and not n.endswith('process.stderr.bin')}
            else:
                second={n[len(p):]:files[n] for n in names if not n.endswith('/process.stdout.bin') and not n.endswith('/process.stderr.bin') and not n.endswith('process.stdout.bin') and not n.endswith('process.stderr.bin')}
                assert first==second, (c,mode,'repeat diff')
        summary['modes'][mode]={'success':status.count('success'),'error':status.count('error'),'status_vector':''.join('S' if v=='success' else 'E' for v in status),'repeat_equal':True,'repeat_1_files':raw_file_count}
    assert prov['jdk']['executable_sha256']=='51ec0764f7225b40d5b286b01401aa6b3990d0d171b446d7dc81ca7542b45552'
    assert prov['jdk']['modules_sha256']=='40fcf7a32bada7e299e3513939a4472d27f8f61eb81cdd1675ea00648de7e7cf'
    result['cohorts'][c]=summary
# exact fixture source closure
manifest=json.loads((fix/'manifest.json').read_text())['files']
assert set(manifest)=={str(p.relative_to(fix)) for p in fix.rglob('*') if p.is_file() and p.name!='manifest.json'}
for n,h in manifest.items():assert sha((fix/n).read_bytes())==h
Afreeze=json.loads((root/'target/m2/stage57-data-size-authority-checks-01/freeze.json').read_text())
result['canonical_A_freeze_sha256']=sha((root/'target/m2/stage57-data-size-authority-checks-01/freeze.json').read_bytes())
result['canonical_A_archive_sha256']=sha((root/'tests/fixtures/m2-data-size/oracle-evidence.tar.gz').read_bytes())
assert result['canonical_A_freeze_sha256']=='9f44ec258ddb020af6a730241232281cdf9350d2e44c405fe2c20e4caf27d0c0'
assert result['canonical_A_archive_sha256']=='51e14a2c80836141c61a9bbb18aaa708e6a963c238132854e55e7bf6493c6b8e'
out=root/'target/m2/stage57-supplement-review-01/independent.json'
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({c:v['modes'] for c,v in result['cohorts'].items()},indent=2))
