# admission migration 02 보완

01의 소스·실행·closure는 변경하지 않았다. 이 추가 변경은 할당된 m2_module_admission.rs 하나에만 적용했다. 새 공개 lifecycle enum에 대응하는 phase literal 두 개(resolve-key, resolve-import-uri)를 추가했다. supplied-source 테스트의 기존 exact phase assertion은 뜻밖의 공개 요청을 통과로 흡수하지 않는다.

Host에서 읽은 module의 원래 declaration key는 절대 import operand에도 resolveUri를 호출한다(Java IoUtils:432–438). resolved_importer_trust 테스트는 이 효과가 선언 key file:///admission/child.pkl과 authored file:///secret.pkl를 가지고 runtime denied edge 이전에 정확히 한 번 발생하는지 확인한다. URI 해석은 명시 default helper에 위임하고 기존 importer original/resolved/display 구분·실제 보안 거부·source1회·close0을 그대로 유지한다.

Cycle 첫 로딩에서는 A의 clause b, B의 clause a, B.fresh의 아직 실행하지 않은 import 표현식에 대해 AST URI 준비가 각각 한 번 추가된다. 따라서 기존 migration01의 call별 exact29 요청에 세 resolve-import-uri를 원래 방문 위치에 추가해 exact32로 유지한다. 문자열 클래스 값, saved partial 성공, fresh 실패, source2회, GC와 복구 원래 기대는 그대로다. ImportUri 요청을 알려진 종류로 명시 처리했으며 예상 밖 효과를 건너뛰지 않는다.

외부 child의 six-phase close/cancel 입력에는 별도 import가 없으므로 이 테스트의 기존 여섯 phase는 유지한다. 기존 poll100000/instruction1/deadline1ms, 실제12 temporary stale/child생존/동일live+executable plateau, close slots0, UTF16/오류동등성·rawDenied/callback·wrongtoken 조건을 낮추지 않았다.

집중 cargo actual64095 exit0, 15/15 성공, 명시 bounded runtime/src(새 untracked source 포함)와 build controls/test/support before=after다. 이는 작업 중인 소스에 대한 집중 architecture 회귀이며 전체 candidate freeze·public evaluator·Java·플랫폼·full gate 통과가 아니다. 추가 cargo는 실행하지 않는다. formatter는 target 안의 test/support 복사본에서만 실행하고 할당 test만 되돌려 썼으므로 production support traversal 변경은 없다.
