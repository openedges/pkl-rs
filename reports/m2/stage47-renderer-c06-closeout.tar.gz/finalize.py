from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess,sys,tarfile
O=Path(__file__).parent.resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
primary=json.loads((O/'report.json').read_bytes());terminal=json.loads((O/'publisher.terminal.json').read_bytes());assert terminal['exitCode']==0 and terminal['sourceBefore']==terminal['sourceAfter'];index=json.loads((O/'selection.json').read_bytes());archives=primary['archives'];commands=[]
# Explicit accounting clarification; primary producer records remain unchanged.
labels=sorted({r['rootLabel']for r in index['records']});catalog={r['label']for r in index['roots']};sparse=sorted(set(labels)-catalog)
assert sparse==['stage47-renderer-identity-regression-fixtures-01']
write(O/'selection-accounting-addendum.json',{'schema':1,'cataloguedAnchoredRoots':len(catalog),'additionalSparseHistoricalRoots':sparse,'totalUniqueSelectedRootLabels':len(labels),'selectedOriginalFiles':len(index['records']),'scope':'Primary selection-summary.roots counts the20 sealed/manifest-anchored rootcatalog rows. Two original failedmetadata-export files also belong to one explicitly sparse invalidfixture01 root, giving21physicalsource roots inrecords. No files omitted, changed or newly treatedaspass. The originalmetadata remains preserved.'})
# Materialize content from the actual archive members, not from gathered source.
EXTRACT=O/'archive-member-source';EXTRACT.mkdir(exist_ok=False)
for item in archives:
 dest=EXTRACT/item['group'];dest.mkdir()
 with tarfile.open(item['path'],'r:gz')as tar:
  seen=set()
  for member in tar.getmembers():
   p=Path(member.name)
   if not member.isfile()or p.is_absolute()or'..'in p.parts or member.name in seen:raise ValueError('unsafe archive member')
   seen.add(member.name);target=dest/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read())
def command(name,argv):
 r={'name':name,'command':argv,'cwd':str(O),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentPid':os.getpid()}
 with(O/(name+'.stdout.bin')).open('wb')as out,(O/(name+'.stderr.bin')).open('wb')as err:
  p=subprocess.Popen(argv,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);r['pid']=p.pid;write(O/(name+'.launch.json'),r);r['exitCode']=p.wait()
 r['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['stdoutSha256']=sha(O/(name+'.stdout.bin'));r['stderrSha256']=sha(O/(name+'.stderr.bin'));write(O/(name+'.terminal.json'),r);commands.append(r)
 if r['exitCode']!=0:raise RuntimeError(name+'failed')
 return r
T=EXTRACT/'oracles-tools'
command('archive-restore',[sys.executable,str(T/'restore.py'),'--index',str(T/'selection.json'),'--objects',str(EXTRACT),'--output',str(O/'restored-from-archives'),'--git-fixture',index['gitFixture']['localFixtureRoot'],'--external-map',str(O/'external-live-map.json')])
command('archive-offline-raw-verify',[sys.executable,str(T/'verify_raw.py'),'--restored',str(O/'restored-from-archives')])
# No selected original may change while packaging or restoring.
changes=[]
for name,row in json.loads((O/'source-before.json').read_bytes()).items():
 p=Path(name)
 if sha(p)!=row['sha256']or p.stat().st_size!=row['bytes']or stat.S_IMODE(p.stat().st_mode)!=row['mode']:changes.append(name)
assert not changes
write(O/'original-after-archive-roundtrip.json',{'originalChanges':changes,'sourceBeforeSha256':sha(O/'source-before.json'),'originalEntriesRechecked':len(json.loads((O/'source-before.json').read_bytes())),'noOriginalDirectoryWalk':True,'noEvaluatorExecutions':True})
write(O/'external-reference-summary.json',{'gitFixture':{k:v for k,v in index['gitFixture'].items()if k!='files'},'gitFiles':len(index['gitFixture']['files']),'canonicalReferences':index['canonicalReferences'],'priorPublishedArchives':index['priorPublishedArchives'],'historicalReferences':index['historicalReferences'],'fullIndexArchive':'renderer-c06-oracles-tools.tar.gz/selection.json','fullIndexSha256':sha(O/'selection.json'),'noBgitCommands':True,'actualModesAndBytes':'AllselectedoriginalfileSHA/size/mode storedinindex. Gitblobs computedfromrawbytecontent; actualGitcommit association is rootprovided.'})
(O/'README.md').write_text('''# C06 renderer raw evidence archives

Download all four archives and the external references listed in `external-reference-summary.json`. `renderer-c06-oracles-tools.tar.gz` contains `selection.json`, the content-addressed source map, pinned standalone verifiers and restore/offline verification tools. The native and portable archives contain the other content objects. Each archive has an EVIDENCE inventory and group CAPTURE_SELECTION. Objects are stored once across these archives; every original selected path, hash, byte count and mode remains recorded. The archive headers normalize modes/time; restoration reapplies captured file modes.

The original860 fixture is referenced at commit 674d3cabdd0e9c421a2cb9b820a22f2456755629 under tests/fixtures/m2-renderer-portable. B invoked no Git; root supplied the committed identity, while B verified original/installed literal bytes and computed blob IDs. Canonical C06 native/build/platform assets are separately owned by A/C and are referenced by exact SHA/length, never duplicated here. Point `restore.py --git-fixture` at that fixture checkout and `--external-map` at a JSON map of canonical SHA to the corresponding unpacked A/C evidence file. Use --objects with a directory containing native, portable and oracles-tools extracted groups. Run verify_raw.py --restored on the restored output. No evaluator, Java, Node, browser, network or Git is executed by those offline tools.

The actual archive-member roundtrip verified 1840 native and 980 Node plus 980 Chromium raw observations, with all pinned expected channels, counters, reader plans and ownership/terminal checks. Original source/path/mode changes were zero. Original CLI comparisons and primary root860 portable are separately packaged by A/C. C05 remains intermediate. Historical references and selected C03/C04 mismatch raw and failed tool/metadata attempts remain explicit. The root catalogue lists20 anchored roots plus one sparse invalid-fixture historical root,21 unique physical source roots total.

Wrong-method16 are raw comparisons and are excluded from intended identity coverage. Java/native shared Resource backing does not survive portable copied completion transport, so no alias-branch equivalence is claimed. Policy84 and close28 remain separately unexecuted; one Java powerAssertions=true profile differs from Rust Observe modes, and GC requests differ from collection schedules. No full identity, renderer, M2, platform-release or performance claim follows from these bounded results.
''')
# Closeout captures the original publisher terminal and every primary create/verify/restore record.
CLOSE=O/'closeout-source';CLOSE.mkdir(exist_ok=False)
fixed=['publisher.launch.json','publisher.terminal.json','publisher.stdout.bin','publisher.stderr.bin','run.py','finalize.py','report.json','archive-index.json','selection-summary.json','source-before.json','prewalk-exclusions.json','selection-accounting-addendum.json','external-reference-summary.json','original-after-archive-roundtrip.json','README.md']
names=set(fixed)
for r in primary['commands']+commands:
 for suffix in ['launch.json','terminal.json','stdout.bin','stderr.bin']:names.add(r['name']+'.'+suffix)
for name in sorted(names):shutil.copy2(O/name,CLOSE/name)
write(CLOSE/'CAPTURE_SELECTION.json',{'schema':1,'scope':'Originalpublisher/process/command/verification/roundtrip/sourceidentity receipts. Finalcloseout verification is detached in final-report/handoff to avoid recursive self-inclusion.','files':{name:{'sha256':sha(O/name),'bytes':(O/name).stat().st_size}for name in sorted(names)},'primaryArchives':archives,'publisherActualTerminalExit':terminal['exitCode'],'toolHandle':20483,'rawMemberAndOfflineChecks':'Allprimarymembers alreadyverified; this closeout also independentlyverified/readback.'})
close_archive=O/'archives/renderer-c06-closeout.tar.gz';command('closeout-create',[sys.executable,str(O/'evidence.py'),'create',str(CLOSE),str(close_archive)]);command('closeout-verify',[sys.executable,str(O/'evidence.py'),'verify',str(close_archive)])
with tarfile.open(close_archive,'r:gz')as tar:
 members={m.name:m for m in tar.getmembers()};inv=json.load(tar.extractfile(members['EVIDENCE.json']));assert set(members)=={r['path']for r in inv['files']}|{'EVIDENCE.json'}
 for row in inv['files']:
  m=members[row['path']];data=tar.extractfile(m).read();assert m.isfile()and m.mode==0o644 and m.mtime==0 and len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']and data==(CLOSE/row['path']).read_bytes()
close={'group':'closeout','path':str(close_archive),'sha256':sha(close_archive),'bytes':close_archive.stat().st_size,'payloadFiles':len(inv['files']),'membersIncludingEvidence':len(inv['files'])+1}
allarchives=archives+[close]
write(O/'final-archive-index.json',{'schema':1,'archives':allarchives,'totalCompressedBytes':sum(a['bytes']for a in allarchives),'totalPayloadMembers':sum(a['payloadFiles']for a in allarchives),'globalSelectionSha256':sha(O/'selection.json'),'closeoutSourceIndexSha256':sha(CLOSE/'CAPTURE_SELECTION.json')})
final={'schema':1,'scope':primary['scope'],'archives':allarchives,'totalCompressedBytes':sum(a['bytes']for a in allarchives),'allCreateAndSeparateVerifyExitsZero':True,'allRawMembersReadback':True,'allArchiveMemberRestorationVerified':True,'offlineRawVerificationFromActualArchives':json.loads((O/'archive-offline-raw-verify.stdout.bin').read_bytes()),'selectedOriginalFiles':len(index['records']),'selectedOriginalBytes':sum(r['bytes']for r in index['records']),'selectedPhysicalRootLabels':len(labels),'anchoredRootCatalogue':len(catalog),'additionalSparseHistoricalRoots':sparse,'storedUniqueContentObjects':len(index['objects']),'storedContentObjectBytes':sum(r['bytes']for r in index['objects'].values()),'originalSourceChanges':changes,'originalBeforeAfterProofSha256':sha(O/'original-after-archive-roundtrip.json'),'gitFixturePayloadCopies':0,'canonicalCompiledArtifactCopies':0,'producerTerminalSha256':sha(O/'publisher.terminal.json'),'producerActualToolHandle':20483,'producerActualExitCode':0,'primaryCommandCount':len(primary['commands']),'closeoutCommands':commands,'finalArchiveIndexSha256':sha(O/'final-archive-index.json'),'globalIndexArchive':'renderer-c06-oracles-tools.tar.gz/selection.json','globalIndexSha256':sha(O/'selection.json'),'limitations':index['limitations'],'mainReportsGitWrites':0,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'liveHandles':[]}
write(O/'final-report.json',final);print(json.dumps({'archives':allarchives,'totalBytes':final['totalCompressedBytes'],'offline':final['offlineRawVerificationFromActualArchives'],'sourceChanges':changes,'reportSha256':sha(O/'final-report.json')},indent=2))
