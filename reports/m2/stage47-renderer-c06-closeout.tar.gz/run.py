from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).parent.resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
r={'parentPid':os.getpid(),'command':[sys.executable,str(O/'publish.py')],'cwd':str(O),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBefore':{name:sha(O/name)for name in ['publish.py','restore.py','verify_raw.py','run.py']},'environment':{'PYTHONDONTWRITEBYTECODE':'1'},'evaluatorExecutions':0,'mainReportsGitWrites':0}
with (O/'publisher.stdout.bin').open('wb')as out,(O/'publisher.stderr.bin').open('wb')as err:
 p=subprocess.Popen(r['command'],cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);r['pid']=p.pid;(O/'publisher.launch.json').write_text(json.dumps(r,indent=2)+'\n');r['exitCode']=p.wait()
r['finishedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['sourceAfter']={name:sha(O/name)for name in r['sourceBefore']};r['stdoutSha256']=sha(O/'publisher.stdout.bin');r['stderrSha256']=sha(O/'publisher.stderr.bin');r['liveHandles']=[];(O/'publisher.terminal.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(r['exitCode'])
