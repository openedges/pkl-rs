#!/usr/bin/env python3
"""Package Stage 58 Java validation source copies and raw transcripts."""
from __future__ import annotations
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
SRC = ROOT / 'target/m2/stage58-java-validation-01'
OUT = ROOT / 'reports/m2/stage58-java-validation.tar.gz'
assert not OUT.exists(), OUT

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

files = {}
for file in sorted(SRC.rglob('*')):
    assert not file.is_symlink(), file
    if file.is_file():
        name = file.relative_to(SRC).as_posix()
        if name == 'validation-archive.stdout.json':
            continue
        files[name] = {'bytes': file.stat().st_size, 'sha256': sha(file.read_bytes())}
    else:
        assert file.is_dir(), file
assert 'validation.json' in files and 'checkpoint.stdout.json' in files
assert 'sources/tools/any_if_non_null_fixtures.py' in files
manifest = {'schema': 1, 'kind': 'stage58-any-java-validation',
            'origin': 'target/m2/stage58-java-validation-01', 'members': files}
raw_manifest = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
with OUT.open('wb') as stream:
    with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name in sorted(files):
                raw = (SRC / name).read_bytes()
                assert {'bytes': len(raw), 'sha256': sha(raw)} == files[name]
                member = tarfile.TarInfo(name)
                member.size = len(raw)
                member.mode = 0o644
                member.mtime = 0
                archive.addfile(member, io.BytesIO(raw))
            member = tarfile.TarInfo('MANIFEST.json')
            member.size = len(raw_manifest)
            member.mode = 0o644
            member.mtime = 0
            archive.addfile(member, io.BytesIO(raw_manifest))
with tarfile.open(OUT, 'r:gz') as archive:
    names = archive.getnames()
    assert len(names) == len(set(names)) == len(files) + 1
    assert set(names) == set(files) | {'MANIFEST.json'}
    assert archive.extractfile('MANIFEST.json').read() == raw_manifest
    for entry in archive:
        assert entry.isfile() and not entry.issym() and not entry.islnk(), entry.name
        if entry.name == 'MANIFEST.json':
            continue
        raw = archive.extractfile(entry).read()
        assert {'bytes': len(raw), 'sha256': sha(raw)} == files[entry.name]
        assert raw == (SRC / entry.name).read_bytes()
print(json.dumps({'archive': str(OUT), 'archive_sha256': sha(OUT.read_bytes()),
                  'archive_bytes': OUT.stat().st_size, 'members': len(files),
                  'manifest_sha256': sha(raw_manifest)}, sort_keys=True))
