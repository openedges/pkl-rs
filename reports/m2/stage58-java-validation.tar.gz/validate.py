"""One-shot local Java fixture validation recorder; does not alter project sources."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SOURCES = [
    'tools/any_if_non_null_oracle.py',
    'tools/any_if_non_null_supplement_oracle.py',
    'tools/any_if_non_null_fixtures.py',
    'tools/any_if_non_null_supplement_fixtures.py',
    'tools/tests/test_any_if_non_null_fixtures.py',
    'tools/tests/test_any_if_non_null_supplement_fixtures.py',
    'tools/java/AnyIfNonNullOracle.java',
    'tools/inventory.py', 'tools/m2_manifest.py',
    'oracle.lock.json', 'references.lock',
    'compatibility/m2-language.json', 'compatibility/m2-mappings.json',
    'compatibility/inventory.json', 'compatibility/rev1-inventory.json',
    'external/pkl/stdlib/base.pkl', 'external/pkl/stdlib/ref.pkl',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/AnyNodes.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/lambda/ApplyVmFunction1Node.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmNull.java',
    'external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/ExternalMethod1Node.java',
]
for name in ('m2-any-if-non-null', 'm2-any-if-non-null-supplement'):
    SOURCES.extend(str(p.relative_to(ROOT)) for p in sorted((ROOT / 'tests/fixtures' / name).iterdir()) if p.is_file())
SOURCES = sorted(set(SOURCES))

def sha(raw): return hashlib.sha256(raw).hexdigest()
def record(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': sha(raw)}

before = {name: record(ROOT / name) for name in SOURCES}
for name in SOURCES:
    target = OUT / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
    assert record(target) == before[name]

commands = [
    ('canonical-verifier', [sys.executable, 'tools/any_if_non_null_fixtures.py']),
    ('supplement-verifier', [sys.executable, 'tools/any_if_non_null_supplement_fixtures.py']),
    ('fixture-tests', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p',
                       'test_any_if_non_null*fixtures.py', '-v']),
    ('canonical-verifier-O', [sys.executable, '-O', 'tools/any_if_non_null_fixtures.py']),
    ('supplement-verifier-O', [sys.executable, '-O', 'tools/any_if_non_null_supplement_fixtures.py']),
    ('fixture-tests-O', [sys.executable, '-O', '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p',
                         'test_any_if_non_null*fixtures.py', '-v']),
    ('source-inventory', [sys.executable, 'tools/inventory.py', '--check']),
    ('m2-inventory', [sys.executable, 'tools/m2_manifest.py', '--check']),
]
results = []
for label, argv in commands:
    started = time.time()
    proc = subprocess.run(argv, cwd=ROOT, env=os.environ.copy(), stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, timeout=1200)
    stdout = OUT / f'{label}.stdout.bin'
    stderr = OUT / f'{label}.stderr.bin'
    stdout.write_bytes(proc.stdout)
    stderr.write_bytes(proc.stderr)
    results.append({'name': label, 'argv': argv, 'cwd': str(ROOT), 'started_epoch': started,
                    'finished_epoch': time.time(), 'exit_code': proc.returncode,
                    'stdout': record(stdout), 'stderr': record(stderr)})
    print(label, proc.returncode, len(proc.stdout), len(proc.stderr), flush=True)

after = {name: record(ROOT / name) for name in SOURCES}
java = subprocess.run(['/usr/bin/java', '-version'], cwd=ROOT,
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
(OUT / 'java-version.stdout.bin').write_bytes(java.stdout)
(OUT / 'java-version.stderr.bin').write_bytes(java.stderr)
report = {'schema': 1, 'kind': 'stage58-java-offline-validation', 'workspace': str(ROOT),
          'host': {'platform': platform.platform(), 'machine': platform.machine(),
                   'system': platform.system(), 'release': platform.release()},
          'python': {'executable': sys.executable, 'version': sys.version,
                     'executable_identity': record(Path(sys.executable)),
                     'optimization_normal': 0, 'optimization_rerun': 1},
          'java': {'argv': ['/usr/bin/java', '-version'], 'exit_code': java.returncode,
                   'stdout': record(OUT / 'java-version.stdout.bin'),
                   'stderr': record(OUT / 'java-version.stderr.bin')},
          'source_before': before, 'source_after': after, 'source_stable': before == after,
          'sources_copied': len(SOURCES), 'commands': results,
          'all_exit_zero': all(result['exit_code'] == 0 for result in results),
          'supplement_python_helper_closure_complete': False,
          'supplement_python_helper_limit':
              'Supplement run.py imports tools/any_if_non_null_oracle.py; the historical supplement capture did not copy/hash that imported helper. Sealed probe, module, query, JAR and raw JVM observations remain verifiable; complete historical Python helper closure is not claimed.'}
(OUT / 'validation.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print('source_stable', report['source_stable'], 'all_exit_zero', report['all_exit_zero'], flush=True)
