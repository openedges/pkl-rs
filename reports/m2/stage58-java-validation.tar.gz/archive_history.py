#!/usr/bin/env python3
"""Archive prior Stage 58 Java capture attempts verbatim with member readback."""
from __future__ import annotations
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'reports/m2/stage58-java-history.tar.gz'
NAMES = ('stage58-any-oracle-01', 'stage58-any-oracle-02',
         'stage58-any-oracle-03', 'stage58-any-oracle-supplement-01')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

assert not OUT.exists(), OUT
members = {}
for dirname in NAMES:
    folder = ROOT / 'target/m2' / dirname
    assert folder.is_dir()
    for file in sorted(folder.rglob('*')):
        assert not file.is_symlink(), file
        if file.is_file():
            relative = file.relative_to(ROOT / 'target/m2').as_posix()
            members[relative] = {'bytes': file.stat().st_size,
                                 'sha256': sha(file.read_bytes())}
        else:
            assert file.is_dir(), file
manifest = {'schema': 1, 'kind': 'prior-stage58-any-java-capture-history',
            'scope': list(NAMES), 'members': members,
            'note': 'Preserves prior captures as historical attempts; no candidate compatibility claim.'}
raw_manifest = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
OUT.parent.mkdir(parents=True, exist_ok=True)
with OUT.open('wb') as output:
    with gzip.GzipFile(filename='', fileobj=output, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for relative in sorted(members):
                raw = (ROOT / 'target/m2' / relative).read_bytes()
                assert sha(raw) == members[relative]['sha256']
                entry = tarfile.TarInfo(relative)
                entry.size = len(raw)
                entry.mode = 0o644
                entry.mtime = 0
                archive.addfile(entry, io.BytesIO(raw))
            entry = tarfile.TarInfo('MANIFEST.json')
            entry.size = len(raw_manifest)
            entry.mode = 0o644
            entry.mtime = 0
            archive.addfile(entry, io.BytesIO(raw_manifest))
with tarfile.open(OUT, 'r:gz') as archive:
    names = archive.getnames()
    assert len(names) == len(set(names)) == len(members) + 1
    assert set(names) == set(members) | {'MANIFEST.json'}
    assert archive.extractfile('MANIFEST.json').read() == raw_manifest
    for entry in archive:
        assert entry.isfile() and not entry.issym() and not entry.islnk(), entry.name
        if entry.name == 'MANIFEST.json':
            continue
        raw = archive.extractfile(entry).read()
        assert {'bytes': len(raw), 'sha256': sha(raw)} == members[entry.name], entry.name
        assert raw == (ROOT / 'target/m2' / entry.name).read_bytes(), entry.name
print(json.dumps({'archive': str(OUT), 'archive_sha256': sha(OUT.read_bytes()),
                  'archive_bytes': OUT.stat().st_size, 'members': len(members),
                  'per_capture': {name: sum(k.startswith(name + '/') for k in members)
                                  for name in NAMES},
                  'manifest_sha256': sha(raw_manifest)}, sort_keys=True))
