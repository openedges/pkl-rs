#!/usr/bin/env python3
"""Bind sealed Java fixture validation, runtime identity, and history archive."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
VALID = ROOT / 'target/m2/stage58-java-validation-01'
REPORT = ROOT / 'reports/m2/stage58-java-checkpoint.json'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    raw = path.read_bytes()
    return {'sha256': sha(raw), 'bytes': len(raw)}

def read(path):
    return json.loads(path.read_bytes())

def sealed(name, prefix, verifier):
    folder = ROOT / 'tests/fixtures' / name
    archive = folder / 'oracle-evidence.tar.gz'
    result = read(VALID / (verifier + '.stdout.bin'))
    with tarfile.open(archive, 'r:gz') as stream:
        files = {m.name[len(prefix) + 1:]: stream.extractfile(m).read()
                 for m in stream if m.isfile() and m.name.startswith(prefix + '/')}
    provenance = json.loads(files['provenance.json'])
    archive_id = read(folder / 'archive-identity.json')
    assert result['archive_sha256'] == archive_id['archive_sha256'] == sha(archive.read_bytes())
    assert result['fileset_sha256'] == archive_id['fileset_sha256']
    assert len(files) == archive_id['members']
    assert provenance['complete'] and provenance['stable'] and provenance['raw_equal']
    assert provenance['raw_differences'] == []
    assert provenance['input_before'] == provenance['input_after']
    assert provenance['source_before'] == provenance['source_after']
    assert provenance['artifact_sha256'] == provenance['artifact_after_sha256']
    assert len(provenance['sessions']) == 2
    assert all(s['exit_code'] == 0 and s['stderr_bytes'] == 0 and
               s['query_directories'] == result['rows'] for s in provenance['sessions'])
    for name, digest in provenance['source_before'].items():
        assert sha(files['sources/' + name]) == digest
    for name, digest in provenance['input_before'].items():
        assert sha(files[name]) == digest
    return result, provenance, files, {'folder': str(folder.relative_to(ROOT)),
        'archive': str(archive.relative_to(ROOT)), 'archive_identity': identity(archive),
        'fileset_sha256': archive_id['fileset_sha256'], 'members': len(files),
        'rows': result['rows'], 'repetitions': 2, 'statuses': result['statuses'],
        'raw_files_per_repetition': provenance['raw_files'],
        'raw_repetitions_equal': result['raw_repetitions_equal'],
        'probe_sha256': sha(files['AnyIfNonNullOracle.java']),
        'archived_run_py_sha256': sha(files['run.py'])}

validation = read(VALID / 'validation.json')
assert validation['all_exit_zero'] and validation['source_stable']
assert len(validation['commands']) == 8
assert validation['sources_copied'] == len(validation['source_before'])
assert [x['name'] for x in validation['commands']] == [
    'canonical-verifier', 'supplement-verifier', 'fixture-tests',
    'canonical-verifier-O', 'supplement-verifier-O', 'fixture-tests-O',
    'source-inventory', 'm2-inventory']
for rel, item in validation['source_before'].items():
    assert validation['source_after'][rel] == item
    assert identity(ROOT / rel) == item
    assert identity(VALID / 'sources' / rel) == item
for command in validation['commands']:
    assert command['exit_code'] == 0
    for channel in ('stdout', 'stderr'):
        assert identity(VALID / (command['name'] + '.' + channel + '.bin')) == command[channel]
for name in ('fixture-tests', 'fixture-tests-O'):
    assert b'Ran 6 tests' in (VALID / (name + '.stderr.bin')).read_bytes()
for name in ('canonical-verifier', 'supplement-verifier'):
    assert (VALID / (name + '.stdout.bin')).read_bytes() == (VALID / (name + '-O.stdout.bin')).read_bytes()
    assert (VALID / (name + '.stderr.bin')).read_bytes() == (VALID / (name + '-O.stderr.bin')).read_bytes()

canonical_result, canonical, canonical_files, canonical_summary = sealed(
    'm2-any-if-non-null', 'capture-04', 'canonical-verifier')
supp_result, supplement, supp_files, supp_summary = sealed(
    'm2-any-if-non-null-supplement', 'capture-supplement-02', 'supplement-verifier')
assert canonical_result['rows'] == 86 and canonical_result['statuses'] == {'success': 61, 'error': 25}
assert supp_result['rows'] == 13 and supp_result['statuses'] == {'success': 12, 'error': 1}
assert canonical_summary['members'] == 1569 and canonical_summary['raw_files_per_repetition'] == 776
assert supp_summary['members'] == 255 and supp_summary['raw_files_per_repetition'] == 119
assert canonical['reference_revision'] == supplement['reference_revision'] == 'e51fb2f91774265666f94980ec630db794a4db2d'
assert canonical['source_before'] == supplement['source_before']
assert canonical['oracle_lock_sha256'] == supplement['oracle_lock_sha256']
assert canonical['references_lock_sha256'] == supplement['references_lock_sha256']
assert canonical['artifact_sha256'] == supplement['artifact_sha256']
assert {k: v for k, v in canonical['jdk'].items() if k != 'properties'} == {
    k: v for k, v in supplement['jdk'].items() if k != 'properties'}
assert {k: v for k, v in canonical['jdk']['properties'].items() if k != 'user.dir'} == {
    k: v for k, v in supplement['jdk']['properties'].items() if k != 'user.dir'}
assert canonical_files['AnyIfNonNullOracle.java'] == supp_files['AnyIfNonNullOracle.java']
assert sha(canonical_files['AnyIfNonNullOracle.java']) == sha((ROOT / 'tools/java/AnyIfNonNullOracle.java').read_bytes())
assert sha((ROOT / '.cache/oracle/pkl-tools-0.32.0.jar').read_bytes()) == canonical['artifact_sha256']
for path, field in [('bin/java', 'executable_sha256'), ('lib/modules', 'modules_sha256'), ('release', 'release_sha256')]:
    home = Path(canonical['jdk']['executable']).parent.parent
    assert sha((home / path).read_bytes()) == canonical['jdk'][field]
for name, digest in canonical['source_before'].items():
    assert sha((ROOT / name).read_bytes()) == digest
assert 'from tools.any_if_non_null_oracle import' in supp_files['run.py'].decode()
assert 'tools/any_if_non_null_oracle.py' not in supp_files
assert supp_summary['archived_run_py_sha256'] == sha((ROOT / 'tools/any_if_non_null_supplement_oracle.py').read_bytes())

history = read(VALID / 'history-archive.stdout.json')
history_path = ROOT / 'reports/m2/stage58-java-history.tar.gz'
assert history['archive_sha256'] == sha(history_path.read_bytes())
with tarfile.open(history_path, 'r:gz') as stream:
    manifest = json.load(stream.extractfile('MANIFEST.json'))
    assert len(manifest['members']) == history['members']
    assert all(stream.getmember(name).isfile() for name in manifest['members'])
    assert sha((json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()) == history['manifest_sha256']

report = {'schema': 1, 'kind': 'stage58-any-java-authority-checkpoint',
    'baseline': 'Pkl 0.32.0',
    'validation': {'directory': str(VALID.relative_to(ROOT)),
                   'record': str((VALID / 'validation.json').relative_to(ROOT)),
                   'record_identity': identity(VALID / 'validation.json'),
                   'source_stable': True, 'all_exit_zero': True,
                   'checks': [{'name': c['name'], 'exit_code': c['exit_code'],
                               'stdout': c['stdout'], 'stderr': c['stderr']}
                              for c in validation['commands']],
                   'host': validation['host'], 'python': validation['python'],
                   'java_version': validation['java']},
    'canonical': canonical_summary, 'supplement': supp_summary,
    'shared_java_runtime': {'reference_revision': canonical['reference_revision'],
        'references_lock_sha256': canonical['references_lock_sha256'],
        'oracle_lock_sha256': canonical['oracle_lock_sha256'],
        'jar_sha256': canonical['artifact_sha256'],
        'jdk_executable_sha256': canonical['jdk']['executable_sha256'],
        'jdk_modules_sha256': canonical['jdk']['modules_sha256'],
        'jdk_release_sha256': canonical['jdk']['release_sha256'],
        'source_before_after_equal': True, 'artifact_before_after_equal': True,
        'probe_sha256': canonical_summary['probe_sha256']},
    'history': {'archive': str(history_path.relative_to(ROOT)),
                'identity': identity(history_path),
                'members': history['members'],
                'per_capture': history['per_capture'],
                'embedded_manifest_sha256': history['manifest_sha256'],
                'member_hash_readback': True,
                'scope': 'Historical original 01–03 and supplemental 01 captures; not compatibility passes.'},
    'limits': ['Supplemental archived run.py imports tools.any_if_non_null_oracle, but that imported Python helper was not historically copied or hashed in the supplemental capture. Java probe, authored module/queries, JAR/JDK identities, and raw observations validate; complete historical Python helper closure is not claimed.',
               'These are Java reference observations and offline fixture/inventory checks; no Rust, browser, Node, typed export, full M2, or performance compatibility is claimed.'],
    'candidate_compatibility_passes_claimed': 0}
assert not REPORT.exists(), REPORT
REPORT.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'checkpoint': str(REPORT), 'sha256': identity(REPORT)['sha256'],
                  'canonical_rows': 86, 'supplement_rows': 13, 'checks': len(validation['commands'])}, sort_keys=True))
