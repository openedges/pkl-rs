"""Audit retained Stage 12 report claims without executing candidate binaries."""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.root.resolve()
    prior = root / 'target/m2/prior-selection-stage12-provisional-01'
    platform = root / 'target/m2/platforms-stage12-final-02'
    inputs = {}

    def read(path):
        inputs[str(path.relative_to(root))] = {'sha256': digest(path), 'bytes': path.stat().st_size}
        return load(path)

    selection = read(prior / 'original-selection.json')['cases']
    prior_report = read(prior / 'report.json')
    expected_ids = [row['id'] for row in selection]
    actual_ids = [row['id'] for row in prior_report['results']]
    require(expected_ids and len(expected_ids) == len(set(expected_ids)),
            'Original selection is empty or has duplicate IDs')
    require(len(actual_ids) == len(set(actual_ids)), 'Prior replay has duplicate result IDs')
    require(set(actual_ids) == set(expected_ids), 'Prior replay has missing or unexpected result IDs')
    require(actual_ids == expected_ids, 'Prior replay result IDs are reordered')
    current_selection = read(root / 'tests/fixtures/m2/cases.json')['cases']
    require(selection == current_selection, 'Current selection definitions differ from original replay selection')

    report = read(platform / 'report.json')
    execution = read(platform / 'execution/execution.json')
    node_checks = read(platform / 'execution/node-checks.json')
    browser_checks = read(platform / 'execution/browser-checks.json')
    require(report['execution'] == execution, 'Platform report.execution differs from retained execution.json')
    require(execution['nodeChecks'] == node_checks, 'Node scenario claims differ from retained node-checks.json')
    require(execution['browserChecks'] == browser_checks, 'Browser scenario claims differ from retained browser-checks.json')
    sys.path.insert(0, str(root / 'tools'))
    tool = importlib.import_module('m1_platforms')
    tool.check_scenarios(execution)
    captures = {}
    for name, relative in [('java', 'oracle-native/java.stdout.bin'), ('rust', 'oracle-native/rust.stdout.bin'),
                           ('node', 'execution/node.stdout.bin'), ('browser', 'execution/browser.stdout.bin')]:
        path = platform / relative
        inputs[str(path.relative_to(root))] = {'sha256': digest(path), 'bytes': path.stat().st_size}
        captures[name] = path.read_bytes()
    for relative in ['tools/m1_platforms.py', 'tools/m1_semantics.py', 'tests/fixtures/m1/semantics/cases.json',
                     'tools/platform/package.json']:
        path = root / relative
        inputs[relative] = {'sha256': digest(path), 'bytes': path.stat().st_size}
    rows = tool.compare(tool.generate_cases()['cases'], captures)
    require(rows == report['comparisons'], 'Platform comparisons differ from retained raw payloads')
    totals = {
        'total': len(rows),
        'oracle_passed': {name: sum(row['oracle_matches'][name] for row in rows)
                          for name in ['rust', 'node', 'browser']},
        'shared_engine_passed': sum(row['shared_engine_match'] for row in rows),
    }
    for name, value in totals.items():
        require(report[name] == value, 'Platform exported count differs from raw comparisons: ' + name)
    result = {
        'schema': 1,
        'scope': 'Read-only final report claim audit; no new language/API compatibility tests or captured binary execution.',
        'status': 'pass',
        'captured_binaries_executed': False,
        'new_compatibility_test_count': 0,
        'prior_replay': {'result_count': len(actual_ids), 'unique_ids': len(set(actual_ids)),
                         'exact_original_order': True, 'current_definitions_equal_original': True},
        'platforms': dict(totals, node_scenarios=len(node_checks), browser_scenarios=len(browser_checks),
                          report_execution_equals_retained=True, scenario_lists_equal_retained=True,
                          comparisons_recomputed_from_raw=True,
                          oracle_mismatch_ids={name: [row['id'] for row in rows if not row['oracle_matches'][name]]
                                               for name in ['rust', 'node', 'browser']}),
        'inputs': inputs,
        'auditor_sha256': digest(Path(__file__)),
    }
    with args.output.open('x') as stream:
        stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: result[key] for key in ['status', 'prior_replay', 'platforms', 'new_compatibility_test_count']}, sort_keys=True))


if __name__ == '__main__':
    main()
