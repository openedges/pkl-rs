"""Retain the exact-commit and final claim audits without changing raw suites."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
COMMIT = '50fc60b2aeac6fa9bb43c6c6043fc8f9976cb287'


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


binding = load(BASE / 'source-verification-stage12-final.json')
assert binding['implementation_commit'] == COMMIT
assert binding['verifier_sha256'] == sha(BASE / 'verify_stage12_implementation_sources.py')
audit_dir = BASE / 'stage12-final-claims-audit'
audit = load(audit_dir / 'audit.json')
assert audit['status'] == 'pass' and audit['captured_binaries_executed'] is False
for name, digest in load(audit_dir / 'evidence-sha256.json').items():
    assert sha(audit_dir / name) == digest

proof = BASE / 'source-stage12-final-evidence'
proof.mkdir(exist_ok=False)
for name in ['source-verification-stage12-final.json', 'verify_stage12_implementation_sources.py',
             'package_stage12_final.py', 'package_stage12_source_proof.py']:
    shutil.copyfile(BASE / name, proof / name)
for source, destination, expected in [
    ('source-stage12-final-process', 'source-binding-process', 0),
    ('package-stage12-final-process', 'packaging-first-attempt', 1),
    ('package-stage12-final-process-02', 'packaging-final', 0),
    ('language-stage12-command-02', 'language-command', 0),
    ('platforms-stage12-command-02', 'platforms-command', 0),
]:
    process_dir = BASE / source
    process = load(process_dir / 'process.json')
    assert process['exit_code'] == expected and not process['timed_out']
    for channel in ['stdout', 'stderr']:
        capture = process_dir / (channel + '.bin')
        assert sha(capture) == process[channel + '_sha256']
        assert capture.stat().st_size == process[channel + '_bytes']
    shutil.copytree(process_dir, proof / destination)
shutil.copytree(audit_dir, proof / 'claims-audit')
write(proof / 'scope.json', {
    'implementation_commit': COMMIT,
    'source_snapshot_copies': binding['verified_source_snapshot_copies'],
    'unique_source_files': binding['unique_source_files'],
    'captured_binaries_executed': False,
    'scope': 'Each final captured source copy equals exact Git implementation bytes; raw suite inventories and comparisons remain in their separate archives. The claims audit rechecks existing result identities, order, retained execution metadata, and counts without adding compatibility tests.',
    'packaging_first_attempt': 'A helper variable shadowed the language report; inspection stopped before creating final outputs. Original helper and failure captures are preserved. The corrected helper completed all packaging checks.',
})
archive = ROOT / 'reports/m2/source-stage12-final-evidence.tar.gz'
assert not archive.exists()
subprocess.run([sys.executable, 'tools/evidence.py', 'create', str(proof), str(archive)], check=True)
subprocess.run([sys.executable, 'tools/evidence.py', 'verify', str(archive)], check=True)
with tarfile.open(archive, 'r:gz') as stream:
    archive_files = len(stream.getmembers())
archive_identity = dict(path=str(archive.relative_to(ROOT)), sha256=sha(archive),
                        bytes=archive.stat().st_size, files_including_inventory=archive_files,
                        inventory_verified=True)
summary_path = ROOT / 'reports/m2/stage12-final-summary.json'
summary = load(summary_path)
assert summary['source_to_commit_binding'].startswith('Pending')
summary['implementation_commit'] = COMMIT
summary['source_to_commit_binding'] = 'All final captured source copies match exact Git implementation bytes; retained raw suites and recorded-build identities remain separate evidence.'
summary['implementation_source_verification'] = dict(
    source_snapshot_copies=binding['verified_source_snapshot_copies'],
    unique_source_files=binding['unique_source_files'],
    matched_exact_git_commit=True, report_sha256=sha(BASE / 'source-verification-stage12-final.json'),
    method='Each captured source hash and full bytes match git show at the exact implementation commit, resolving submodule paths through that commit\'s pinned gitlinks.',
    evidence=archive_identity,
)
summary['final_claims_audit'] = dict(status='pass', report_sha256=sha(audit_dir / 'audit.json'),
    source_evidence_path='claims-audit/audit.json', prior_replay=audit['prior_replay'],
    platforms=audit['platforms'], new_compatibility_test_count=0)
review = ROOT / 'reports/m2/stage12-class-review-evidence.tar.gz'
summary['outside_selected_class_review'] = dict(
    path=str(review.relative_to(ROOT)), sha256=sha(review),
    status='unresolved-oracle-error',
    scope='A failed class override followed by a read of an unpublished local declaration raises Java PklBugException versus a Rust missing-property diagnostic. Outside the 18 selected sequences; no pass or development exception added.',
)
write(summary_path, summary)
print(json.dumps(dict(archive=archive_identity, source_copies=binding['verified_source_snapshot_copies'],
                      unique_source_files=binding['unique_source_files']), sort_keys=True))
