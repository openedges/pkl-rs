//! String API queries from pinned Pkl 0.32.0 Java.
//! Compare full status, UTF8/UTF16 results and ordered Logger fields; Java
//! exception/class/cause metadata is retained in fixtures, not compared here.
#[path = "support/module_keys.rs"]
mod module_keys;
use pkl_runtime::{probe::SourceProbe, value::PklString};
use std::{
    fs,
    path::{Path, PathBuf},
};
fn root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("../../tests/fixtures/m2-string-apis-oracle")
}
fn units(raw: &[u8]) -> Vec<u16> {
    let (pairs, tail) = raw.as_chunks::<2>();
    assert!(tail.is_empty());
    pairs.iter().map(|p| u16::from_be_bytes(*p)).collect()
}
fn field(path: &Path, name: &str, actual: &[u16]) -> bool {
    units(&fs::read(path.join(format!("{name}.code-units.bin"))).unwrap()) == actual
        && fs::read(path.join(format!("{name}.bin"))).unwrap()
            == PklString::from_utf16(actual.to_vec())
                .to_java_utf8()
                .as_bytes()
}
fn capture(path: Option<&Path>, name: &str, value: &[u16]) {
    if let Some(path) = path {
        fs::write(
            path.join(format!("{name}.bin")),
            PklString::from_utf16(value.to_vec())
                .to_java_utf8()
                .as_bytes(),
        )
        .unwrap();
        fs::write(
            path.join(format!("{name}.code-units.bin")),
            value
                .iter()
                .flat_map(|x| x.to_be_bytes())
                .collect::<Vec<_>>(),
        )
        .unwrap();
    }
}
fn run(program: &str, count: usize, power_assertions: bool) {
    let input = root().join(program);
    let source = fs::read_to_string(input.join("module.pkl")).unwrap();
    let uri = fs::read_to_string(input.join("uri.txt")).unwrap();
    let queries = fs::read_to_string(input.join("comparable.tsv")).unwrap();
    assert_eq!(
        queries.lines().count(),
        count,
        "exact admitted query inventory"
    );
    let capture_root = std::env::var_os("PKL_FRAME_CAPTURE_DIR").map(PathBuf::from);
    let mut failures = Vec::new();
    for repeat in 0..2 {
        let mut probe =
            SourceProbe::new_module_evaluator("compact", true, false, power_assertions).unwrap();
        for line in queries.lines() {
            let columns = line.split('\t').collect::<Vec<_>>();
            assert_eq!(columns.len(), 4);
            assert_eq!(columns[0], "string");
            let id = columns[1];
            let expression = columns[2];
            let expected = input.join("repeat-0").join(columns[3]);
            assert_eq!(
                fs::read(expected.join("expression.bin")).unwrap(),
                expression.as_bytes()
            );
            let actual_dir = capture_root.as_ref().map(|r| {
                r.join(program)
                    .join(format!("repeat-{repeat}"))
                    .join(columns[3])
            });
            if let Some(p) = &actual_dir {
                fs::create_dir_all(p).unwrap();
            }
            probe
                .evaluate_module_source(&uri, Some(&source), expression, 0, None)
                .unwrap();
            let mut terminal = None;
            let mut logs = 0usize;
            let mut row_logs_match = true;
            for _ in 0..200_000 {
                probe.collect();
                let event = probe.poll(0, 1).unwrap();
                probe.collect();
                if event.kind == "yield" {
                    continue;
                }
                if event.kind == "module-request" {
                    let token = event.token.as_deref().unwrap();
                    assert!(module_keys::complete_probe(&mut probe, token, 0).unwrap());
                    continue;
                }
                if event.kind == "log" {
                    let log = event.log.as_ref().unwrap();
                    let position = format!(
                        "{}:{}-{}:{}",
                        log.start_line, log.start_column, log.end_line, log.end_column
                    );
                    let fields = [
                        log.level.encode_utf16().collect::<Vec<_>>(),
                        log.message.clone(),
                        log.module_uri.clone(),
                        log.member_name
                            .clone()
                            .unwrap_or_else(|| "null".encode_utf16().collect()),
                        position.encode_utf16().collect(),
                    ];
                    for (name, actual) in ["level", "message", "module-uri", "member", "position"]
                        .iter()
                        .zip(&fields)
                    {
                        let name = format!("log-{logs:03}.{name}");
                        capture(actual_dir.as_deref(), &name, actual);
                        if !expected.join(format!("{name}.bin")).exists()
                            || !field(&expected, &name, actual)
                        {
                            row_logs_match = false;
                            failures.push(format!("{program}/{id}: Logger {name}"));
                        }
                    }
                    logs += 1;
                    probe
                        .acknowledge_log(event.token.as_deref().unwrap(), None, 0)
                        .unwrap();
                    continue;
                }
                assert!(
                    matches!(event.kind, "value" | "error"),
                    "unexpected pending event: {event:?}"
                );
                terminal = Some(event);
                break;
            }
            let event = terminal.expect("bounded String API query");
            let actual_status = match event.kind {
                "value" => "success\n",
                "error" if event.disposition == Some("language-error") => "error\n",
                _ => "unsupported-or-api-error\n",
            };
            let stdout = event.value.as_deref().unwrap_or(&[]);
            let stderr = event.error.as_deref().unwrap_or(&[]);
            capture(actual_dir.as_deref(), "result.stdout", stdout);
            capture(actual_dir.as_deref(), "result.stderr", stderr);
            if let Some(p) = &actual_dir {
                fs::write(p.join("result.status.bin"), actual_status).unwrap();
                fs::write(p.join("logs.count.bin"), format!("{logs}\n")).unwrap();
            }
            let expected_logs = fs::read(expected.join("logs.count.bin")).unwrap();
            let equal = fs::read(expected.join("result.status.bin")).unwrap()
                == actual_status.as_bytes()
                && field(&expected, "result.stdout", stdout)
                && field(&expected, "result.stderr", stderr)
                && expected_logs == format!("{logs}\n").as_bytes()
                && row_logs_match;
            eprintln!(
                "string-api-row program={program} repeat={repeat} id={id} exact_match={equal}"
            );
            if !equal {
                failures.push(format!(
                    "{program}/{id}/repeat-{repeat}: {event:?}; logs={logs}, expected-count-bytes={expected_logs:?}"
                ));
            }
        }
        probe.close();
        assert_eq!(probe.collect().slots, 0);
    }
    assert!(failures.is_empty(), "{}", failures.join("\n"));
}

#[test]
fn java_case_mapping() {
    run("case-mapping", 72, false);
}

#[test]
fn java_prefix_and_nullable_index() {
    run("prefix-and-nullable-index", 255, false);
}

#[test]
fn java_predicate_slicing() {
    run("predicate-slicing", 92, false);
}

#[test]
fn java_trim_classifiers() {
    run("trim-classifiers", 108, false);
}

#[test]
fn java_padding_and_ranges() {
    run("padding-and-ranges", 46, false);
}

#[test]
fn java_glob_syntax() {
    run("glob-syntax", 47, false);
}

#[test]
fn java_numeric_parsing() {
    run("numeric-parsing", 140, false);
}

#[test]
fn java_boolean_and_digests() {
    run("boolean-and-digests", 56, false);
}

#[test]
fn java_arity_and_property_form() {
    run("arity-and-property-form", 51, false);
}

#[test]
fn java_constraint_method_resolution() {
    run("constraint-method-resolution", 6, false);
}

// These three queries have retained Java internal-error bytes, but no ordinary
// language-result authority. They remain unverified compatibility obligations.
#[test]
#[ignore = "three pinned Java glob internal errors; cross-runtime protocol unresolved"]
fn java_glob_internal_error_protocol_is_unresolved() {
    panic!(
        "See tests/fixtures/m2-string-apis-oracle/unresolved.json; no compatibility pass is claimed"
    );
}

#[test]
fn java_case_mapping_tr() {
    run("case-mapping-tr", 72, false);
}

#[test]
fn java_boolean_and_digests_tr() {
    run("boolean-and-digests-tr", 56, false);
}

#[test]
fn java_padding_and_ranges_power() {
    run("padding-and-ranges-power", 46, true);
}

#[test]
fn java_constraint_method_resolution_power() {
    run("constraint-method-resolution-power", 6, true);
}

#[test]
fn java_lowercase_boundaries() {
    run("lowercase-boundaries", 24, false);
}

#[test]
fn java_float_parsing_boundaries() {
    run("float-parsing-boundaries", 24, false);
}

#[test]
fn java_numeric_review_followups() {
    run("numeric-review-followups", 29, false);
}

#[test]
fn java_lowercase_renderer_identity() {
    run("lowercase-renderer-identity", 38, false);
}

#[test]
fn java_uppercase_renderer_identity() {
    run("uppercase-renderer-identity", 38, false);
}
