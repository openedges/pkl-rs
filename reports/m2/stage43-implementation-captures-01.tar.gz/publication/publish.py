"""Publish explicit closed roots; prune exact caches and aliases before walking."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
selection = json.loads((OUT/'selection.json').read_text())
exclusions = {Path(p) for p in selection['excludedBeforeTraversal']}
encoded = lambda value: (json.dumps(value, indent=2, sort_keys=True)+'\n').encode()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
paths = {}
for row in selection['roots']:
    source = Path(row['source'])
    assert source.is_dir() and source not in exclusions, source
    for directory, dirs, names in os.walk(source):
        directory = Path(directory)
        dirs[:] = sorted(d for d in dirs if directory/d not in exclusions)
        assert not any((directory/d).is_symlink() for d in dirs), directory
        for name in sorted(names):
            path = directory/name
            if path in exclusions:
                continue
            assert path.is_file() and not path.is_symlink(), path
            relative = str(Path(row['archivePrefix'])/path.relative_to(source))
            assert relative not in paths, relative
            paths[relative] = path
for row in selection['files']:
    path = Path(row['source'])
    assert path.is_file() and not path.is_symlink() and row['archivePath'] not in paths, path
    paths[row['archivePath']] = path
paths = dict(sorted(paths.items()))
for record in selection.get('symlinkRepresentations', []):
    assert hashlib.sha256(os.fsencode(os.readlink(record['originalPath']))).hexdigest() == record['targetSha256']
before = {name: {'originalPath': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)} for name,path in paths.items()}
(OUT/'inputs.before.json').write_bytes(encoded(before))
shards = []
current = []
size = 0
for name in paths:
    amount = before[name]['bytes']
    if current and size+amount > 75_000_000:
        shards.append(current)
        current,size = [],0
    current.append(name)
    size += amount
if current:
    shards.append(current)
archives = []
for number, names in enumerate(shards,1):
    dest = ROOT/f'reports/m2/stage43-implementation-captures-{number:02}.tar.gz'
    assert not dest.exists(), dest
    inventory = encoded({'schema_version':1, 'excluded_patterns':[], 'files':[
        {'path': name, 'bytes':before[name]['bytes'], 'sha256':before[name]['sha256']} for name in names]})
    with dest.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w') as archive:
            for name in names:
                payload = paths[name].read_bytes()
                assert hashlib.sha256(payload).hexdigest() == before[name]['sha256'], name
                member = tarfile.TarInfo(name)
                member.size,member.mode,member.mtime = len(payload),0o644,0
                archive.addfile(member,io.BytesIO(payload))
            member = tarfile.TarInfo('EVIDENCE.json')
            member.size,member.mode,member.mtime = len(inventory),0o644,0
            archive.addfile(member,io.BytesIO(inventory))
    command = [sys.executable,'tools/evidence.py','verify',str(dest.relative_to(ROOT))]
    result = subprocess.run(command,cwd=ROOT,capture_output=True)
    (OUT/f'verify-{number:02}.stdout.bin').write_bytes(result.stdout)
    (OUT/f'verify-{number:02}.stderr.bin').write_bytes(result.stderr)
    assert result.returncode == 0, dest
    archives.append({'path':str(dest.relative_to(ROOT)), 'bytes':dest.stat().st_size, 'sha256':sha(dest),
        'payloadFiles':len(names), 'payloadBytes':sum(before[name]['bytes'] for name in names),
        'verification':{'command':command,'exitCode':result.returncode}})
    print(dest.name,len(names),dest.stat().st_size,flush=True)
after = {name: {'originalPath':str(path),'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in paths.items()}
(OUT/'inputs.after.json').write_bytes(encoded(after))
assert before == after, 'source drift during publication'
for record in selection.get('symlinkRepresentations', []):
    assert hashlib.sha256(os.fsencode(os.readlink(record['originalPath']))).hexdigest() == record['targetSha256']
report = {'schema':1,'scope':selection['scope'],'fullM2Complete':False,'archives':archives,
    'roots':selection['roots'],'files':selection['files'],'excludedBeforeTraversal':selection['excludedBeforeTraversal'],
    'payloadFiles':len(paths),'payloadBytes':sum(r['bytes'] for r in before.values()),'sourceChanges':[],
    'preservation':'Each unique selected path is stored once. Raw failed and successful outcomes retained. Archive payload modes are 0644; no executable-mode equivalence claim.',
    'historicalInventoryScope':'Some original fixture/source-copy inventories describe their original full acquisition. Copies and initial failed inventories remain unchanged; outer publication verifies every selected payload byte.',
    'symlinkRepresentations':selection.get('symlinkRepresentations', []),'omissions':selection['omissions']}
(OUT/'report.json').write_bytes(encoded(report))
dest = ROOT/'reports/m2/stage43-implementation-captures.json'
assert not dest.exists(),dest
dest.write_bytes(encoded(report))
print('Closed selected Stage43 publication. M2 remains incomplete.',flush=True)
