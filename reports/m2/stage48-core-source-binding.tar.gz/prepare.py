from pathlib import Path
from collections import Counter
import datetime,hashlib,json,os,shutil,stat,subprocess,sys,time
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];MAIN=ROOT.parent/'pkl-rs';IMPL=ROOT/'target/m2/stage48-implementation-01';BASE='0e13a589d43c4cb1d83f41dd1ec416cac1770fc1'
CAND=IMPL/'admission-candidate-build-01';OLD=ROOT.parent/'pkl-rs.stage47/target/m2/stage47-core-publication-proposal-02'
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(n,x):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def progress(s,**k):save('progress.json',{'phase':s,**k});print(s,k,flush=True)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
reviews=['stage48-admission-plan-c-review-01','stage48-admission-source-c-review-01','stage48-admission-source-c-review-02','stage48-admission-source-c-review-03','stage48-heap-accounting-c-review-01']
roots=[(IMPL,'implementation')]+[(MAIN/'target/m2'/n,'reviews/'+n)for n in reviews]+[(ROOT/'target/m2'/n,n)for n in ['stage48-documentation-draft-01','stage48-bootstrap-regression-readback-01']]
pruned={IMPL/'source-blobs',CAND/'sources',CAND/'artifacts',ROOT/'target/stage48-cargo',ROOT/'target/debug',ROOT/'target/wasm32-unknown-unknown',ROOT/'tools/platform/node_modules',ROOT/'target/m2/stage48-c01-platform-control-01',ROOT/'target/m2/stage48-c01-bootstrap-control-01',ROOT/'target/m2/stage48-c01-bootstrap-control-02'}
# Enumerate exact known source snapshot directories before recursive evidence walk.
for n in ['admission-review-proposal-01','admission-review-proposal-02','admission-review-proposal-03','admission-heap-accounting-review-01','admission-heap-accounting-sources-addendum-01']:
 for leaf in ['sources','base']:pruned.add(IMPL/n/leaf)
for n in ['admission-workspace-tests-01','admission-host-consumers-02','admission-tests-09']:pruned.add(IMPL/'admission-heap-accounting-review-01/captures'/n/'sources')
save('selection-plan.json',{'base_commit':BASE,'roots':[{'path':str(p),'label':n}for p,n in roots],'exact_pre_walk_exclusions':[str(p)for p in sorted(pruned)],'contract':'Exact absolute directories pruned before os.scandir descent. Source snapshots/CAS are indexed only by recorded maps; build and platform caches never walked. No generic build exclusion. Closed core reviews only; current platform and B acquisition/audits belong to independent publishers.','bootstrap':'Include only read-only oldStage45 vs legacyStage48C01 classification, not root subsequent typed observer02 acquisition or in-progress C review.'})
selected=[]
def group(n):
 if n.startswith('reviews/')or not n.startswith('implementation/'):return'reviews-analysis'
 if n.startswith('implementation/admission-candidate-build-01/'):return'source-binding'
 return'checks-history'
def walk(p,n):
 if p in pruned:return
 s=p.lstat()
 if stat.S_ISLNK(s.st_mode):raise AssertionError('unexpected evidence symlink '+str(p))
 if stat.S_ISREG(s.st_mode):selected.append({'original':str(p),'path':'raw/'+n,'group':group(n),'bytes':s.st_size,'sha256':sha(p),'mode':stat.S_IMODE(s.st_mode)});return
 assert stat.S_ISDIR(s.st_mode)
 for e in sorted(os.scandir(p),key=lambda e:e.name):
  q=Path(e.path)
  if q not in pruned:walk(q,n+'/'+e.name)
for p,n in roots:walk(p,n)
save('selected-files.json',selected);progress('raw selected',files=len(selected),bytes=sum(r['bytes']for r in selected))
pairs=set();maps=[]
for row in selected:
 p=Path(row['original'])
 if p.name in ['source-before.json','source-after.json','source-map.json']:
  m=json.loads(p.read_text())
  if isinstance(m,dict)and m and all(isinstance(v,str)and len(v)==64 for v in m.values()):
   pairs.update(m.items());maps.append({'path':str(p),'sha256':row['sha256'],'entries':len(m)})
final=json.loads((CAND/'source-after.json').read_text());pairs.update(final.items());save('source-map-index.json',maps)
# Read current pinned Git tree membership; reuse previously independently
# archived object byte hashes only when exact Git object IDs match.
cached_path=OLD/'git-objects.json';cached={(x['repository'],x['object']):x for x in json.loads(cached_path.read_text())}
save('git-hash-reuse.json',{'table':str(cached_path),'sha256':sha(cached_path),'prior_archive':str(ROOT/'reports/m2/stage47-core-builds-source-binding.tar.gz'),'prior_archive_sha256':sha(ROOT/'reports/m2/stage47-core-builds-source-binding.tar.gz'),'scope':'Exact immutable Git object IDs reuse prior streamed raw-byte SHA256/size. New IDs below are streamed now; current pinned tree memberships are always read anew.'})
repos=[('project',ROOT,'',BASE),('pkl',ROOT/'external/pkl','external/pkl/','e51fb2f91774265666f94980ec630db794a4db2d'),('pkl-pantry',ROOT/'external/pkl-pantry','external/pkl-pantry/','904a68184e54da378b0a0e8a911a3fab3956f693')]
need={p for p,h in pairs};git={};objects=[]
for short,repo,prefix,rev in repos:
 if short!='project':assert subprocess.check_output(['git','--no-optional-locks','rev-parse','HEAD'],cwd=repo,text=True).strip()==rev
 use={}
 for row in subprocess.check_output(['git','--no-optional-locks','ls-tree','-rz',rev],cwd=repo).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split();name=prefix+os.fsdecode(path)
  if kind=='blob'and name in need:use.setdefault(oid,[]).append((name,mode))
 proc=subprocess.Popen(['git','--no-optional-locks','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 reused=0;read_now=0
 for oid,uses in use.items():
  obj=cached.get((short,oid))
  if obj is not None:reused+=1;digest=obj['sha256'];size=obj['bytes']
  else:
   proc.stdin.write((oid+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().strip().split();assert header[0]==oid and header[1]=='blob';size=int(header[2]);h=hashlib.sha256();remaining=size
   while remaining:
    data=proc.stdout.read(min(1024*1024,remaining));assert data;h.update(data);remaining-=len(data)
   assert proc.stdout.read(1)==b'\n';digest=h.hexdigest();read_now+=1
  objects.append({'repository':short,'object':oid,'bytes':size,'sha256':digest,'hash_source':'prior-archived-table'if obj is not None else'current-raw-Git-blob'})
  for name,mode in uses:
   if(name,digest)in pairs:git[name,digest]={'kind':'pinned-git-blob','repository':short,'commit':rev,'git_path':name[len(prefix):],'object':oid,'git_mode':mode,'bytes':size}
 proc.stdin.close();assert proc.wait()==0
 progress('Git objects bound',repository=short,reused=reused,streamed=read_now,bound=len(git))
save('git-objects.json',objects)
# Non-Git sources use exact captured CAS or the closed C01 file catalog.
loc={}
for n,h in final.items():loc[n,h]=CAND/'sources'/n
for row in selected:
 p=Path(row['original']);s=str(p)
 if '/sources/'in s:loc.setdefault((s.split('/sources/',1)[1],row['sha256']),p)
bindings=[];missing=[];blobs=OUT/'source-blobs';blobs.mkdir();archive_pointers=[]
for n,h in sorted(pairs):
 b=git.get((n,h))
 if b is None:
  cas=IMPL/'source-blobs'/h;src=cas if cas.is_file()else loc.get((n,h))
  if src is None:
   b={'kind':'historical-hash-only','reason':'No exact retained CAS/snapshot bytes or pinned Git blob found. Original hash remains evidence; reconstruction incomplete.'};missing.append({'path':n,'sha256':h})
  else:
   assert sha(src)==h
   if n.startswith('reports/')and n.endswith(('.tar.gz','.tgz','.zip','.tar.zst')):
    b={'kind':'separately-published-report-archive','canonical_capture':str(src),'bytes':src.stat().st_size};archive_pointers.append({'path':n,'sha256':h,**b})
   else:
    dst=blobs/h
    if not dst.exists():os.link(src,dst)
    assert sha(dst)==h;b={'kind':'archived-source-blob','blob':'source-blobs/'+h,'bytes':src.stat().st_size,'canonical_capture':str(src)}
 bindings.append({'path':n,'sha256':h,**b})
assert not(set(final.items())&{(x['path'],x['sha256'])for x in missing}), 'C01 binding must be complete'
save('source-bindings.json',bindings);save('unresolved-historical-sources.json',missing);save('separate-report-archives.json',archive_pointers)
save('checkout-byte-boundaries.json',{'scope':'Actual checkout bytes remain distinct from raw Git blobs; no normalization.','records':[x for x in bindings if x['path']in['external/pkl/gradlew.bat','external/pkl-pantry/gradlew.bat']]})
checks=[]
for child in sorted(IMPL.iterdir()):
 p=child/'report.json'
 if p.is_file():
  x=json.loads(p.read_text())
  if'exit_code'in x:checks.append({'label':child.name,'exit_code':x['exit_code'],'source_stable':x.get('source_stable'),'command':x.get('command'),'report_sha256':sha(p)})
save('check-outcomes.json',checks)
for row in selected:
 src=Path(row['original']);assert sha(src)==row['sha256'];dst=OUT/'staging'/row['group']/row['path'];dst.parent.mkdir(parents=True,exist_ok=True);os.link(src,dst)
sg=OUT/'staging/source-binding'
for p in blobs.iterdir():
 d=sg/'source-blobs'/p.name;d.parent.mkdir(parents=True,exist_ok=True);os.link(p,d)
for name in ['selection-plan.json','selected-files.json','source-map-index.json','git-hash-reuse.json','git-objects.json','source-bindings.json','unresolved-historical-sources.json','separate-report-archives.json','checkout-byte-boundaries.json','check-outcomes.json']:shutil.copyfile(OUT/name,sg/name)
artifacts=json.loads((CAND/'release.json').read_text())['artifacts']
for n,a in artifacts.items():
 src=Path(a['path']);assert sha(src)==a['sha256'];dst=OUT/'staging/artifacts'/n;dst.parent.mkdir(parents=True,exist_ok=True);os.link(src,dst)
summary={'schema':1,'status':'proposal-not-published','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate_release':str(CAND/'release.json'),'candidate_release_sha256':sha(CAND/'release.json'),'source_count':len(final),'source_links':11,'source_versions':len(pairs),'git_bound_versions':len(git),'source_blobs':len(list(blobs.iterdir())),'historical_hash_only':missing,'check_exit_counts':dict(Counter(str(x['exit_code'])for x in checks)),'qualifications':['No new evaluation or source/Git edits. Raw failures and unstable/setup/compiler observations retain original exit status.','Earlier Rust checks capture crates/.cargo plus four Cargo/reference controls. C01 build separately records full53236files/11symlinks with bytes/modes before/after; do not relabel narrow earlier captures whole-tree observations.','Successful actual default Rust checks and focused15admission/cycle+fixed3/ref4/diagnostic6 checks are development evidence, not fullJava policy/API/M2/performance completion.','Heap four-value attribution is source-derived(module,twoannotations,Accessclass), not an object-ID dump; unchanged12/12/15 and exactdescriptor/count/lifecycle assertions passed. No stack/poll/heap limit enlargement.','The raw640? policy comparison is independently owned by B: actual440rawpass/212SPIunexecuted/fullLifecycle0of52. No Boracle/acquisition payload is duplicated in this core proposal.','Bootstrap readback included here compares legacyStage48C01 observer with Stage45:194priorpasses preserved,+80pass,144reflectUnsupported/182mismatch remain. LegacyrespondString bypasses typedresourcecache; roottypedobserver02 is separate and intentionallyexcluded.','Customfactory/key-kind/isCached, primary/repl policy lifecycle, eagerclausefactoryselection, completeURIidentity, importglob and wholeM2 remain mandatoryunfinished.'],'separate_evidence':['B actualJava/nativepolicy packages','root/C actualplatform + typedbootstrap02','previously committed Stage47archives']}
summary['qualifications'][4]=summary['qualifications'][4].replace('raw640? policy','policy')
save('summary.json',summary);shutil.copyfile(OUT/'summary.json',sg/'summary.json');shutil.copyfile(__file__,sg/'prepare.py');shutil.copyfile(ROOT/'tools/evidence.py',sg/'evidence.py')
for row in selected:assert sha(Path(row['original']))==row['sha256']
for n,h in final.items():assert sha(CAND/'sources'/n)==h
save('preparation-report.json',{'exit_code':0,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected_files':len(selected),'selected_bytes':sum(x['bytes']for x in selected),'source_bindings':len(bindings),'historical_hash_only':len(missing),'C01_complete':True,'no_source_writes':True,'no_git_writes':True})
progress('prepared',source_bindings=len(bindings),historical_hash_only=len(missing),source_blobs=len(list(blobs.iterdir())))
