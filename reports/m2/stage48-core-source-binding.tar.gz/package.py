from pathlib import Path
import base64,datetime,hashlib,json,os,platform,shutil,subprocess,sys,tarfile,time
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];STAGE=OUT/'staging';TOOL=STAGE/'source-binding/evidence.py'
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
start=now();assert json.loads((OUT/'preparation-report.json').read_text())['exit_code']==0
for name in ['prepare.stdout.bin','prepare.stderr.bin']:
 dst=STAGE/'source-binding/preparation'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(OUT/name,dst)
(STAGE/'source-binding/preparation/actual-terminal.json').write_text(json.dumps({'tool_session':72976,'actual_exit_code':0,'qualification':'Actual tool terminal polled before packaging; no evaluation in this process.'},indent=2)+'\n')
shutil.copyfile(__file__,STAGE/'source-binding/package.py');assert sha(TOOL)==sha(ROOT/'tools/evidence.py')
inputs={}
# Staging contains only the explicit curated inputs, never source/cache trees.
for group in sorted(STAGE.iterdir()):
 rows=[]
 for p in sorted(group.rglob('*')):
  assert not p.is_symlink()
  if p.is_file():rows.append({'path':p.relative_to(group).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size})
 inputs[group.name]=rows
save('archive-inputs.json',inputs);save('packaging-environment.json',{'started_utc':start,'host':platform.platform(),'machine':platform.machine(),'python':sys.version,'executable':sys.executable,'cwd':str(ROOT),'evidence_tool_sha256':sha(TOOL),'input_list_sha256':sha(OUT/'archive-inputs.json'),'no_new_evaluation':True})
captures=OUT/'packaging-captures';captures.mkdir();commands=[]
def capture(label,argv):
 o=captures/(label+'.stdout.bin');e=captures/(label+'.stderr.bin');row={'label':label,'argv':argv,'cwd':str(ROOT),'started_utc':now()};tick=time.monotonic()
 with o.open('wb')as stdout,e.open('wb')as stderr:
  p=subprocess.Popen(argv,cwd=ROOT,stdout=stdout,stderr=stderr);row['pid']=p.pid;save('progress.json',{'phase':'packaging','command':row});row['exit_code']=p.wait()
 row.update(finished_utc=now(),elapsed_seconds=time.monotonic()-tick,stdout_sha256=sha(o),stderr_sha256=sha(e),stdout_base64=base64.b64encode(o.read_bytes()).decode(),stderr_base64=base64.b64encode(e.read_bytes()).decode())
 commands.append(row);save('packaging-commands.json',commands);print(label,row['exit_code'],flush=True);assert row['exit_code']==0;return row
archives=[]
for group,rows in inputs.items():
 archive=OUT/('stage48-core-'+group+'.tar.gz');assert not archive.exists()
 create=capture(group+'-create',[sys.executable,str(TOOL),'create',str(STAGE/group),str(archive)])
 verify=capture(group+'-verify',[sys.executable,str(TOOL),'verify',str(archive)])
 with tarfile.open(archive,'r:gz')as tar:
  inv=json.load(tar.extractfile('EVIDENCE.json'));assert inv['files']==rows
  for row in rows:
   stream=tar.extractfile(row['path']);assert stream is not None
   assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
   p=STAGE/group/row['path'];assert sha(p)==row['sha256']and p.stat().st_size==row['bytes']
 assert archive.stat().st_size<100*1024*1024
 archives.append({'name':archive.name,'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(rows),'raw_bytes':sum(x['bytes']for x in rows),'create':create,'separate_verify':verify,'full_member_readback':True})
for row in json.loads((OUT/'selected-files.json').read_text()):assert sha(Path(row['original']))==row['sha256']
index={'schema':1,'status':'proposal-for-root-review-not-published','started_utc':start,'finished_utc':now(),'archives':archives,'total_bytes':sum(x['bytes']for x in archives),'all_under_100MiB':True,'archive_inputs_sha256':sha(OUT/'archive-inputs.json'),'source_binding_archive':'stage48-core-source-binding.tar.gz','source_binding_path':'source-bindings.json','source_binding_sha256':sha(OUT/'source-bindings.json'),'summary_sha256':sha(OUT/'summary.json'),'historical_source_gaps':4,'C01_file_bindings_complete':53236,'C01_symlinks_recorded':11,'qualifications':['No new evaluation/source/Git mutations. Failed commands remain failed.','Archive headers use deterministic0644; actual source/artifact modes are separately captured.','Raw create/separateverify stdout/stderr retained asfiles and Base64 here; no report seals itself or active logs.','Previous published archives are not nested; current source bindings point to pinnedGit blobs or exactarchivedsource blobs.','Boracle/native/portable and root/Cplatform/typedbootstrap02 have separatepublication ownership.']}
save('archive-index.json',index);save('packaging-report.json',{'exit_code':0,'started_utc':start,'finished_utc':now(),'archive_count':len(archives),'create_commands':len(archives),'separate_verify_commands':len(archives),'total_bytes':index['total_bytes'],'full_member_readback':True,'original_selected_inputs_unchanged':True,'archive_index_sha256':sha(OUT/'archive-index.json')})
save('progress.json',{'phase':'complete','exit_code':0});print(json.dumps(json.loads((OUT/'packaging-report.json').read_text())),flush=True)
