"""Read-only review of actual C05 native/Node/Chromium Resource evidence."""
from pathlib import Path
import hashlib,json,re,struct,time
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46');B=ROOT/'target/m2'
A=B/'stage46-platform-acquisition-01';BASE=B/'stage46-platform-baseline-01';R=B/'stage46-resource-platform-01';C=B/'stage46-implementation-01/resource-candidate-build-05'
OUT=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage46-resource-platform-review-01')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(p.read_bytes())
def utf16(v):
 assert all(type(x)is int and 0<=x<=65535 for x in v)
 return struct.pack('>'+'H'*len(v),*v)
def java8(v):return utf16(v).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
start=time.time();top=load(A/'report.json');terminal=load(A/'outer-terminal.json');base=load(BASE/'report.json');resource=load(R/'execution.json');release=load(C/'release.json');source=load(C/'source-after.json')
assert sha(A/'report.json')=='f9ac2bcdf48028db749b389bee918786e308660933cfa0cf2c7d7326016efdc7'==terminal['reportSha256'];assert terminal['actualExitCode']==0 and terminal['toolSessionId']==70333
assert top['selectedAcquisitionPassed'] and top['fullCompatibilityPassed'] is False and not top['candidateSourceChangesBefore'] and not top['sourceChangesAfter']
assert top['candidateReleaseSha256']==sha(C/'release.json')==sha(A/'candidate-release.json') and top['candidateSourceMapSha256']==sha(C/'source-after.json')==sha(A/'candidate-sources.json') and top['sourceCount']==len(source)==32518
assert sha(A/'cargo-config.toml')==source['.cargo/config.toml'] and sha(A/'m1_platforms.py')==source['tools/m1_platforms.py']
for c in top['commands']:
 assert c['exitCode']==0
 for ch in ['stdout','stderr']:assert sha(A/(c['name']+'.'+ch+'.bin'))==c[ch+'Sha256']
for n,d in base['source_hashes'].items():assert sha(BASE/'sources'/n)==d==source[n],n
assert 'crates/pkl-runtime/src/stdlib/modules.txt' in base['source_hashes']
for n,d in base['artifacts'].items():assert sha(BASE/n)==d
commands=load(BASE/'commands.json');assert len(commands)==8 and all(c['exit_code']==(1 if c['name']=='oracle-native' else 0) for c in commands)
cases=load(BASE/'sources/tests/fixtures/m1/semantics/cases.json')['cases'];assert len(cases)==base['total']==6078 and [c['id']for c in cases]==[c['id']for c in base['comparisons']]
paths={'java':'oracle-native/java.stdout.bin','rust':'oracle-native/rust.stdout.bin','node':'execution/node.stdout.bin','browser':'execution/browser.stdout.bin'};decoded={}
for target,n in paths.items():
 lines=(BASE/n).read_bytes().split(b'\n');assert lines[-1]==b'' and len(lines)==6079
 assert all(re.fullmatch(rb'(?:[0-9a-f]{2})*',line) for line in lines[:-1]);decoded[target]=[bytes.fromhex(line.decode()) for line in lines[:-1]]
gaps={t:[] for t in ['rust','node','browser']}
for i,row in enumerate(base['comparisons']):
 values={t:v[i] for t,v in decoded.items()};assert values['rust']==values['node']==values['browser'] and row['shared_engine_match']
 for t,v in values.items():assert hashlib.sha256(v).hexdigest()==row['sha256'][t]
 for t in gaps:
  same=values[t]==values['java'];assert same==row['oracle_matches'][t]
  if not same:gaps[t].append(row['id'])
 if any(not row['oracle_matches'][t] for t in gaps):assert row['mismatched_bytes_hex']=={t:v.hex() for t,v in values.items()}
assert all(set(v)==set(['regex-unicode-15-vs-16','regex-zero-width-supplementary']) for v in gaps.values())
assert base['oracle_passed']=={'rust':6076,'node':6076,'browser':6076} and base['shared_engine_passed']==6078 and base['compatibility_status']=='fail' and base['experiment_contract_status']=='pass'
e=base['execution'];assert e==load(BASE/'execution/execution.json') and not e['browserErrors'] and e['playwright']==e['playwrightCore']==e['playwrightPin']=='1.64.1'
assert set(e['nodeChecks'])==set(e['browserChecks']) and len(e['nodeChecks'])==len(set(e['nodeChecks']))==92
assert resource['preflight']['exitCode']==0 and resource['preflight']==load(R/'preflight.process.json') and not resource['infrastructureErrors'] and not resource['browserErrors'] and not resource['changedInputs'] and resource['selectedContractPassed'] and resource['fullCompatibilityPassed'] is False
for p,d in resource['artifactAndInputHashes'].items():assert sha(Path(p))==d,p
assert sha(Path(resource['browserExecutable']))==resource['browserExecutableSha256'] and sha(Path(resource['nodeExecutable']))==top['nodeExecutableSha256']
for n,d in base['artifacts'].items():
 if n=='semantics_probe':continue
 assert resource['artifactAndInputHashes'][str(BASE/n)]==d,n
for n in ['tools/resource_fixtures.py','tools/export_resource_portable.py','tools/platform/compare-resource.mjs','tools/platform/resource-session.mjs','tools/platform/package.json','tools/platform/package-lock.json']:
 assert resource['artifactAndInputHashes'][str(ROOT/n)]==source[n],n
assert sha(R/'compare-resource.mjs')==source['tools/platform/compare-resource.mjs'] and sha(R/'resource-session.mjs')==source['tools/platform/resource-session.mjs']
fixture=load(R/'fixtures.json');golden=load(C/'sources/tests/fixtures/m2-resource-portable/fixtures.json');assert fixture==golden and len(fixture['fixtures'])==20 and fixture['javaApiCalls']==1272 and len(fixture['unexecutedApiBoundaries'])==264
assert resource['selectedApiCallsPerTarget']==1008 and resource['javaApiCalls']==1272
results={};traces=0
for target in ['node','browser']:
 actual=load(R/(target+'.raw.json'));assert len(actual)==20;compared=0;readers=0
 for index,(f,a) in enumerate(zip(fixture['fixtures'],actual)):
  assert (a['id'],a['repeat'],a['session'])==(f['id'],f['repeat'],f['session']) and a['constructorError'] is None and a['acquisitionError'] is None
  assert len(a['calls'])==len(f['expected'])==len(f['expressions']);assert a['readerUris']==[p['uri'] for p in f['readerPlan']]
  ar=a['architecture'];assert ar['terminalSlots']==0 and ar['ownedResultsStable'] is True and ar['consumedReaderPlan'] is True and ar['collections']>0
  directory=R/target/str(index);assert a==load(directory/'actual.json') and f['expected']==load(directory/'expected.json')
  for i,(call,expected) in enumerate(zip(a['calls'],f['expected'])):
   assert call['index']==i and call['expression']==f['expressions'][i] and call['status']==expected['status'] and call['readsBefore']==expected['readsBefore'] and call['readsAfter']==expected['readsAfter']
   assert call['status']=='success' or call['disposition']=='language-error'
   for ch in ['stdout','stderr']:
    v=call[ch+'Units'];assert v==expected[ch+'Units'] and java8(v).hex()==expected[ch+'Hex'];assert (directory/(str(i)+'.'+ch+'.utf16be.bin')).read_bytes()==utf16(v) and (directory/(str(i)+'.'+ch+'.java-utf8.bin')).read_bytes()==bytes.fromhex(expected[ch+'Hex'])
   compared+=1
  comparison=load(directory/'comparison.json');assert comparison['passed'] and all(comparison['checks'].values()) and all(c['status']=='pass' and all(c['checks'].values()) for c in comparison['comparisons'])
  readers+=len(a['readerUris'])
 assert compared==1008 and resource['targets'][target]['rawApiCounts']=={'pass':1008} and resource['targets'][target]['complete'] and resource['targets'][target]['selectedContractPassed']
 results[target]={'apiCalls':compared,'sessions':20,'actualReaderCallbacks':readers,'terminalSlotsAllZero':True,'ownedOutputsStable':True,'typedInputPayloadMutationGuardExercised':True}
print('Verified actual Resource API calls',results,flush=True)
result={'schema':1,'scope':'Independent read-only inspection of actual C05 platform evidence; no new build, Java, native, Node or browser execution.','acquisition':{'path':str(A/'report.json'),'sha256':sha(A/'report.json'),'outerTerminal':{'path':str(A/'outer-terminal.json'),'sha256':sha(A/'outer-terminal.json'),'session':70333,'exitCode':0}},'candidate':{'releaseSha256':sha(C/'release.json'),'sourceMapSha256':sha(C/'source-after.json'),'sourceCount':32518},'baseline':{'reportSha256':sha(BASE/'report.json'),'capturedSourceSnapshotsVerified':len(base['source_hashes']),'frozenArtifactsVerified':len(base['artifacts']),'sharedEngineRawMatches':6078,'javaRawMatchesEachTarget':6076,'knownRegexFailureIds':gaps,'architectureChecksEachTarget':92,'nativeOracleComparisonExitCode':1,'contractExitCode':0},'resource':{'executionSha256':sha(R/'execution.json'),'targets':results,'artifactAndInputHashesVerified':len(resource['artifactAndInputHashes']),'preflightExitCode':0,'allJavaApiCalls':1272,'unexecutedJavaApiBoundaries':264,'rawChannelFilesIndependentlyVerified':8064},'sourceBinding':['Baseline171source snapshots and all6artifacts are bound to C05; root Cargo config is separately captured by acquisition wrapper.','Parent wrapper checked all32518candidate inputs before/after; its copied immutable source map matches C05 exactly. Current live C06 edits are not used as C05 source evidence.','Resource driver inputs include the exact verifier and exporter, package/lock, driver/helper, fixtures and the same frozen NAPI/Wasm artifacts built by baseline.'],'findings':[],'qualifications':['Raw UTF16 API result arrays and their Java-equivalent UTF8 encoding are checked independently; these .java-utf8.bin files are encodings of the observed API text, not a claim of byte-output API coverage.','Owned callback buffers are overwritten after completion and retained outputs checked after close/GC. Wasm wrapper free is invoked; Node explicit free is optional and wrapper GC is not forced by this helper.','Two historical regex mismatches remain failed despite successful M1 architecture contract.','Only selected Resource20sessions/1008calls pertarget are covered. Module provider controls,264unselected boundaries, full original corpus, full M2/product/platform and performance requirements remain separate.','C05 clippy101 and later C06 correction remain separate provenance; this platform run is tied to frozen C05 only.'],'seconds':time.time()-start}
(OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'report':str(OUT/'report.json'),'sha256':sha(OUT/'report.json'),'seconds':result['seconds']}),flush=True)
