"""Freeze the immutable pre-Stage17 contract directly from Git object blobs."""
from pathlib import Path
import subprocess,json,hashlib,platform,datetime
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage17-baseline-contract';OUT.mkdir(exist_ok=False)
REV=subprocess.check_output(['git','rev-parse','a415e04^{commit}']).decode().strip()
command=['git','ls-tree','-r','--full-tree',REV]
listing=subprocess.check_output(command);(OUT/'git-ls-tree.bin').write_bytes(listing)
records=[]
for line in listing.decode().splitlines():
 header,path=line.split('\t',1);mode,kind,oid=header.split()
 if kind!='blob':continue
 if not(path.startswith(('tests/fixtures/m2/','compatibility/m2-class-lifecycle/','tools/platform/')) or path in ['compatibility/m2-language.json','compatibility/m2-mappings.json','tools/m1_platforms.py','tools/m2_manifest.py','tools/m2_language.py','tools/m2_class_lifecycle.py','oracle.lock.json','references.lock','Cargo.lock','rust-toolchain.toml','PLAN.md','TESTING.md','INTENT.md','AGENTS.md','docs/m2-language.md']):continue
 data=subprocess.check_output(['git','cat-file','blob',oid]);dest=OUT/'sources'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 records.append(dict(path=path,git_blob=oid,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),command=['git','cat-file','blob',oid],provenance=f'Immutable Git blob from {REV}:{path}'))
read=lambda p:json.loads((OUT/'sources'/p).read_bytes())
cases=read('tests/fixtures/m2/cases.json');manifest=read('compatibility/m2-class-lifecycle/manifest.json')
print('keys',cases.keys(),manifest.keys())
print('sequence example',manifest['sequences'][0])
print('cases first',cases['cases'][0]);print('language keys',read('compatibility/m2-language.json').keys())
summary=dict(schema=1,git_revision=REV,scope='Immutable pre-Stage17 selection, complete fixture directory, persistent contract, generated inventories/mappings, original platform source bytes, and provenance inputs. Not execution evidence.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host=platform.platform(),commands=[command,['git','cat-file','blob','<each recorded git_blob>']],source_count=len(records),selected_cases=len(cases['cases']),sources=records)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'freeze-helper.py').write_bytes(Path(__file__).read_bytes())
(OUT/'evidence-sha256.json').write_text(json.dumps({str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(OUT.rglob('*'))if p.is_file()},indent=2)+'\n')
print('Frozen',len(records),'files at',REV)
