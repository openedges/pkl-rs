//! Fixture factory objects and their getter snapshots. No evaluation or module cache lives here.
use pkl_runtime::modules::*;
use std::{collections::BTreeMap, fs, path::Path, sync::Arc};
struct Config {
    requested: String,
    selected: Arc<str>,
    resolved: Arc<str>,
    source: Arc<str>,
    mode: String,
}
pub struct Factory {
    configs: Vec<Config>,
    keys: BTreeMap<ModuleKeyId, (usize, bool)>,
    resolved: BTreeMap<ResolvedKeyId, ModuleKeyId>,
    pub cached: bool,
}
impl Factory {
    pub fn new(path: &Path) -> Self {
        let configs = fs::read_to_string(path)
            .expect("module factory configuration")
            .lines()
            .map(|line| {
                let columns = line.split('\t').collect::<Vec<_>>();
                assert_eq!(columns.len(), 5, "module factory columns");
                Config {
                    requested: columns[0].into(),
                    selected: columns[1].into(),
                    resolved: columns[2].into(),
                    source: fs::read_to_string(columns[3])
                        .expect("configured fixture source")
                        .into(),
                    mode: columns[4].into(),
                }
            })
            .collect();
        Self {
            configs,
            keys: BTreeMap::new(),
            resolved: BTreeMap::new(),
            cached: true,
        }
    }
    pub fn complete(&mut self, request: &ModuleRequest) -> Option<ModuleCompletion> {
        Some(match &request.kind {
            ModuleRequestKind::SelectKey { id, uri, .. } => {
                if uri.starts_with("throwing:") {
                    return Some(ModuleCompletion::KeySelected(Err(ModuleHostError::Io(
                        "stage48-factory-create".into(),
                    ))));
                }
                let index = self
                    .configs
                    .iter()
                    .position(|config| config.requested == uri.as_ref())?;
                let config = &self.configs[index];
                let cached = match config.mode.as_str() {
                    "true" => true,
                    "false" => false,
                    "dynamic" => self.cached,
                    _ => panic!("fixture cache mode"),
                };
                self.keys.insert(*id, (index, cached));
                ModuleCompletion::KeySelected(Ok(ModuleKey {
                    id: *id,
                    uri: config.selected.clone(),
                    kind: ModuleKeyKind::Host,
                    handle: format!("custom-key-{}", id.0).into(),
                }))
            }
            ModuleRequestKind::QueryCachePolicy { key } => {
                let (_, cached) = self.keys.get(&key.id)?;
                assert_eq!(key.handle.as_ref(), format!("custom-key-{}", key.id.0));
                ModuleCompletion::CachePolicy(Ok(*cached))
            }
            ModuleRequestKind::Resolve {
                key,
                resolved_key_id,
                ..
            }
            | ModuleRequestKind::ResolveKey {
                key,
                resolved_key_id,
                ..
            } => {
                let (index, _) = self.keys.get(&key.id)?;
                assert_eq!(key.handle.as_ref(), format!("custom-key-{}", key.id.0));
                let config = &self.configs[*index];
                self.resolved.insert(*resolved_key_id, key.id);
                ModuleCompletion::KeyResolved(Ok(ResolvedModuleKey {
                    id: *resolved_key_id,
                    key: key.clone(),
                    handle: format!("custom-resolved-{}", resolved_key_id.0).into(),
                    module: ResolvedModule {
                        original_uri: key.uri.clone(),
                        resolved_uri: config.resolved.clone(),
                        source_uri: key.uri.clone(),
                    },
                }))
            }
            ModuleRequestKind::LoadSource { key, .. } => {
                let id = self.resolved.get(&key.id)?;
                assert_eq!(*id, key.key.id);
                assert_eq!(key.handle.as_ref(), format!("custom-resolved-{}", key.id.0));
                let (index, _) = self.keys.get(id).expect("resolved original key");
                let config = &self.configs[*index];
                let name = config
                    .selected
                    .rsplit('/')
                    .next()
                    .unwrap()
                    .strip_suffix(".pkl")
                    .unwrap_or(&config.selected);
                ModuleCompletion::Source(Ok(ModuleSource {
                    text: config.source.clone(),
                    inferred_name: name.into(),
                }))
            }
            _ => return None,
        })
    }
}
