from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
root=Path(__file__).resolve().parents[3]
label,*command=sys.argv[1:]
out=Path(__file__).resolve().parent/label
out.mkdir(exist_ok=False)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():
 paths=[]
 for prefix in ['', 'external/pkl/','external/pkl-pantry/']:
  base=root/prefix
  listed=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=base)
  for raw in listed.split(b'\0'):
   if not raw:continue
   name=prefix+raw.decode();p=root/name
   if p.is_file() and not p.is_symlink():paths.append(name)
 return {name:sha(root/name) for name in sorted(set(paths))}
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
before=sources();write('source-before.json',before)
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
env=dict(os.environ,CARGO_TARGET_DIR=str(root/'target/stage46-cargo'),PYTHONDONTWRITEBYTECODE='1')
p=subprocess.run(command,cwd=root,env=env,capture_output=True)
(out/'stdout.bin').write_bytes(p.stdout);(out/'stderr.bin').write_bytes(p.stderr)
after=sources();write('source-after.json',after)
write('report.json',dict(command=command,cwd=str(root),started_utc=start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,exit_code=p.returncode,cargo_target_dir=env['CARGO_TARGET_DIR'],source_stable=before==after,source_before_sha256=sha(out/'source-before.json'),source_after_sha256=sha(out/'source-after.json'),stdout_sha256=sha(out/'stdout.bin'),stderr_sha256=sha(out/'stderr.bin')))
print(out,p.returncode,flush=True)
print(p.stdout.decode(errors='replace')[-3000:]);print(p.stderr.decode(errors='replace')[-4000:])
sys.exit(p.returncode)
