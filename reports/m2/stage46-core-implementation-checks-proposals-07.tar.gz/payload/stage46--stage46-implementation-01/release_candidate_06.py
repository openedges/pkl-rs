from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,platform
root=Path(__file__).resolve().parents[3]
number=sys.argv[1];base=Path(__file__).resolve().parent
out=base/f'resource-candidate-build-{number}'
report=json.loads((out/'report.json').read_text())
assert report['exit_code']==0 and report['source_stable']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=json.loads((out/'source-after.json').read_text())
previous=base/'resource-candidate-build-05';previous_map=json.loads((previous/'source-after.json').read_text())
counts={'hardlinks_from_immutable_candidate05':0,'copies':0}
for relative,digest in sources.items():
 live=root/relative;assert sha(live)==digest,relative
 dst=out/'sources'/relative;dst.parent.mkdir(parents=True,exist_ok=True)
 old=previous/'sources'/relative
 if previous_map.get(relative)==digest and old.is_file() and sha(old)==digest:
  os.link(old,dst);counts['hardlinks_from_immutable_candidate05']+=1
 else:
  shutil.copy2(live,dst);counts['copies']+=1
 assert sha(dst)==digest,relative
artifacts={};(out/'artifacts').mkdir()
for name in ['module_eval_probe','stage46_resource_probe','stage46_file_probe']:
 src=root/'target/stage46-cargo/debug/examples'/name;dst=out/'artifacts'/name
 shutil.copy2(src,dst);assert sha(src)==sha(dst)
 artifacts[name]={'path':str(dst),'sha256':sha(dst)}
for relative,digest in sources.items():assert sha(root/relative)==digest,relative
environment={'host':platform.uname()._asdict(),'python':sys.version,'commands':[]}
for command in [['rustc','--version','--verbose'],['cargo','--version'],['rustup','show','active-toolchain']]:
 observed=subprocess.run(command,cwd=root,capture_output=True)
 environment['commands'].append({'argv':command,'exit_code':observed.returncode,'stdout':observed.stdout.decode(),'stderr':observed.stderr.decode()})
 assert observed.returncode==0
(out/'environment.json').write_text(json.dumps(environment,indent=2)+'\n')
release={'schema':1,'environment':str(out/'environment.json'),'environment_sha256':sha(out/'environment.json'),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Resource/cache and shared AST preparation candidate. Typed File/policy and AST raw comparisons pending; forced read* and parameterized object bodies explicitly unsupported. No final M2 completion claim.','artifact':artifacts['stage46_resource_probe']['path'],'artifact_sha256':artifacts['stage46_resource_probe']['sha256'],'artifacts':artifacts,'source_map':str(out/'source-after.json'),'source_map_sha256':sha(out/'source-after.json'),'source_snapshot':str(out/'sources'),'source_count':len(sources),'build_report':str(out/'report.json'),'build_report_sha256':sha(out/'report.json'),'example_sha256':sources['crates/pkl-runtime/examples/stage46_resource_probe.rs'],'snapshot_method':dict(explicit_map_paths=True,all_source_and_snapshot_hashes_verified=True,**counts)}
(out/'release.json').write_text(json.dumps(release,indent=2)+'\n')
release['artifact']=artifacts['stage46_file_probe']['path'];release['artifact_sha256']=artifacts['stage46_file_probe']['sha256'];release['example_sha256']=sources['crates/pkl-runtime/examples/stage46_file_probe.rs']
(out/'file-probe-release.json').write_text(json.dumps(release,indent=2)+'\n')
print(json.dumps({'release':str(out/'release.json'),'release_sha256':sha(out/'release.json'),'file_release_sha256':sha(out/'file-probe-release.json'),'source_map_sha256':release['source_map_sha256'],'source_count':len(sources),'artifacts':artifacts},indent=2))
