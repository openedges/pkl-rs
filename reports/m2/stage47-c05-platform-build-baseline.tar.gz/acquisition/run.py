"""Acquire actual platform comparisons against an explicitly frozen Stage47 candidate."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--candidate-release', required=True, type=Path)
args = parser.parse_args()
release_path = args.candidate_release.resolve()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

assert not (OUT / 'report.json').exists(), 'Use a fresh acquisition directory.'
release = json.loads(release_path.read_bytes())
source_map = Path(release['source_map'])
assert sha(source_map) == release['source_map_sha256']
sources = json.loads(source_map.read_bytes())
assert '.cargo/config.toml' in sources
required = [
    'tools/platform/compare-renderer.mjs', 'tools/renderer_fixtures.py',
    'tools/platform/resource-session.mjs', 'tools/m1_platforms.py',
    'tests/fixtures/m2-renderer-portable/manifest.json',
]
assert all(name in sources for name in required), 'Candidate must bind the installed renderer consumer.'
changed_before = [name for name, digest in sources.items() if sha(ROOT / name) != digest]
assert not changed_before, changed_before
for source, name in [(release_path, 'candidate-release.json'), (source_map, 'candidate-sources.json'),
                     (ROOT / '.cargo/config.toml', 'cargo-config.toml')]:
    shutil.copyfile(source, OUT / name)
node = Path(shutil.which('node')).resolve()
bindgen = ROOT / '.cache/m1-tools/bin/wasm-bindgen'
environment = os.environ.copy()
environment['CARGO_TARGET_DIR'] = str(ROOT / 'target')
baseline = OUT / 'baseline'
comparisons = {
    'renderer': ('tools/platform/compare-renderer.mjs', 'tests/fixtures/m2-renderer-portable'),
    'resource': ('tools/platform/compare-resource.mjs', 'tests/fixtures/m2-resource-portable'),
    'module-preparation': ('tools/platform/compare-module-preparation.mjs', 'tests/fixtures/m2-module-portable'),
}
assert not baseline.exists() and all(not (OUT / name).exists() for name in comparisons)
report = {
    'schema': 1, 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Actual native/Node/Chromium M1 architecture and renderer/Resource/module-preparation comparisons. Known baseline regex failures, unselected API boundaries, original programs and full M2/performance gates remain separate.',
    'host': platform.platform(), 'pid': os.getpid(), 'cwd': str(ROOT),
    'candidateReleaseSha256': sha(release_path), 'candidateSourceMapSha256': sha(source_map),
    'sourceCount': len(sources), 'candidateSourceChangesBefore': changed_before,
    'runnerSha256': sha(Path(__file__)),
    'python': sys.version, 'pythonExecutable': sys.executable,
    'pythonExecutableSha256': sha(Path(sys.executable).resolve()),
    'nodeExecutable': str(node), 'nodeExecutableSha256': sha(node),
    'wasmBindgen': str(bindgen), 'wasmBindgenSha256': sha(bindgen),
    'environment': {name: environment.get(name) for name in [
        'CARGO_TARGET_DIR', 'RUSTUP_TOOLCHAIN', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
        'JAVA_HOME', 'PKL_ORACLE_JAVA', 'PLAYWRIGHT_BROWSERS_PATH', 'NODE_OPTIONS',
    ]},
    'plannedCommands': ['baseline', *comparisons], 'commands': [],
    'fullCompatibilityPassed': False, 'fullM2Passed': False,
}
save('report.json', report)

def execute(name, argv):
    argv = [str(value) for value in argv]
    with (OUT / f'{name}.stdout.bin').open('wb') as stdout, (OUT / f'{name}.stderr.bin').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
        save('active.json', {'name': name, 'pid': process.pid, 'argv': argv})
        code = process.wait()
    report['commands'].append({'name': name, 'argv': argv, 'pid': process.pid, 'exitCode': code,
        'stdoutSha256': sha(OUT / f'{name}.stdout.bin'), 'stderrSha256': sha(OUT / f'{name}.stderr.bin')})
    save('report.json', report)
    print(f'{name}: exit {code}', flush=True)
    return code

baseline_exit = execute('baseline', [sys.executable, 'tools/m1_platforms.py', '--output', baseline,
    '--wasm-bindgen', bindgen, '--verify-contract'])
if baseline_exit == 0:
    artifact_paths = [baseline / 'pkl_napi.node', *sorted((baseline / 'wasm').iterdir())]
    assert all(path.is_file() and not path.is_symlink() for path in artifact_paths)
    artifacts_before = {str(path.relative_to(OUT)): sha(path) for path in artifact_paths}
    report['bindingArtifactsBefore'] = artifacts_before
    save('report.json', report)
    for name, (driver, fixture) in comparisons.items():
        execute(name, [node, driver, OUT / name, baseline / 'wasm', baseline / 'pkl_napi.node',
                       ROOT / fixture, ROOT / 'tools/platform/package.json'])
    report['bindingArtifactChanges'] = [name for name, digest in artifacts_before.items() if sha(OUT / name) != digest]
else:
    report['unexecutedComparisons'] = list(comparisons)
    report['unexecutedReason'] = 'The required M1 architecture acquisition did not pass; inspect its raw failure before scheduling further comparisons.'
report['sourceChangesAfter'] = [name for name, digest in sources.items() if sha(ROOT / name) != digest]
report['selectedAcquisitionPassed'] = len(report['commands']) == 4 \
    and all(row['exitCode'] == 0 for row in report['commands']) \
    and not report['sourceChangesAfter'] and not report.get('bindingArtifactChanges', [])
report['finishedUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save('report.json', report)
save('active.json', {'terminal': True, 'exitCode': 0 if report['selectedAcquisitionPassed'] else 1})
print(json.dumps({key: report[key] for key in ['selectedAcquisitionPassed', 'sourceChangesAfter', 'fullCompatibilityPassed']}, indent=2))
sys.exit(0 if report['selectedAcquisitionPassed'] else 1)
