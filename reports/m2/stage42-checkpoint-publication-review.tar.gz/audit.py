from pathlib import Path
import hashlib,json,os,tarfile,datetime
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42')
OUT=Path(__file__).resolve().parent

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads((ROOT/p).read_bytes())
def write(n,x):(OUT/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
index=read('reports/m2/stage42-checkpoint-captures.json'); selection=read('target/m2/stage42-checkpoint-publication-01/selection.json')
assert len(selection['source_roots'])==104 and len(selection['direct_original_files'])==116
excluded={ROOT/p for p in selection['exact_cache_exclusions_before_traversal']}
expected={}; visited=[]
for name in selection['source_roots']:
 base=ROOT/name
 assert base not in excluded
 for current,dirs,files in os.walk(base,followlinks=False):
  current=Path(current); visited.append(str(current.relative_to(ROOT)))
  dirs[:]=[d for d in dirs if current/d not in excluded]
  assert not any((current/d).is_symlink() for d in dirs)
  for n in files:
   p=current/n
   if p in excluded:continue
   assert p.is_file() and not p.is_symlink(),p
   expected[str(p.relative_to(ROOT))]={'bytes':p.stat().st_size,'sha256':sha(p)}
for name in selection['direct_original_files']:
 p=ROOT/name; assert p.is_file() and not p.is_symlink()
 expected[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
assert not any(any((ROOT/v)==e or e in (ROOT/v).parents for e in excluded) for v in visited)
before=read('target/m2/stage42-checkpoint-publication-01/inputs.before.json');after=read('target/m2/stage42-checkpoint-publication-01/inputs.after.json')
assert expected==before==after
archived={}; archive_rows=[];duplicates=[]
for row in index['archives']:
 p=ROOT/row['path']; assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
 payload={}; evidence=None
 with tarfile.open(p,'r|gz') as tar:
  for member in tar:
   assert member.isfile() and member.mode==0o644
   data=tar.extractfile(member).read()
   if member.name=='EVIDENCE.json':
    assert evidence is None; evidence=json.loads(data);continue
   name=member.name; assert name not in payload
   record={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
   assert expected.get(name)==record,(name,'current original mismatch')
   payload[name]=record
   if name in archived:duplicates.append(name)
   archived[name]=record
 inv={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']} for r in evidence['files']}
 assert len(inv)==len(evidence['files']) and inv==payload
 assert len(payload)==row['payload_files'] and sum(r['bytes'] for r in payload.values())==row['uncompressed_payload_bytes']
 assert row['verification']['exit_code']==0
 archive_rows.append({'path':row['path'],'sha256':row['sha256'],'payloadFiles':len(payload),'payloadBytes':sum(r['bytes'] for r in payload.values())})
assert archived==expected
assert not duplicates,duplicates
special=[]
r=read('target/m2/stage42-checkpoint-inventory-scope-review-01/report.json')
for cp in r['checkpoints']:
 for row in cp['sourceCopiesOmittedFromOuterInventory']:
  assert archived[row['originalPath']]=={'bytes':row['bytes'],'sha256':row['sha256']};special.append(row['originalPath'])
assert len(special)==26
b=read('target/m2/stage42-b-closed-roots-audit-01/report.json')
for row in b['supplementalUnlistedOriginals']:
 assert archived[row['originalPath']]=={'bytes':row['bytes'],'sha256':row['sha256']};special.append(row['originalPath'])
assert len(special)==40
assert index['source_changes_during_publication']==[] and index['full_m2_complete'] is False
assert index['source_roots']==selection['source_roots'] and index['direct_original_files']==selection['direct_original_files']
write('union-inventory.json',archived)
write('special-historical-omissions.json',special)
write('report.json',{'status':'PASS','scope':'Independent offline exact archive-union/current-original audit; no evaluator, Java, build, or tooling-test rerun. Historical captures remain historical; no whole-language or M2 completion claim.','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'index':{'path':'reports/m2/stage42-checkpoint-captures.json','sha256':sha(ROOT/'reports/m2/stage42-checkpoint-captures.json')},'archives':archive_rows,'archiveCount':len(archive_rows),'summedPayloadFileCount':sum(r['payloadFiles'] for r in archive_rows),'uniquePayloadFileCount':len(archived),'duplicatePayloadPaths':duplicates,'uncompressedPayloadBytes':sum(r['bytes'] for r in archived.values()),'selectedRoots':len(selection['source_roots']),'directOriginalFiles':len(selection['direct_original_files']),'exactCoverageOfAllSelectedOriginalFiles':True,'currentOriginalBytesMatchBeforeAndAfterPublication':True,'allFortyHistoricalOmissionsPresentAtExactOriginalPaths':True,'checkpointOmissions':26,'moduleDriverOmissions':14,'cacheExclusionsBeforeTraversal':selection['exact_cache_exclusions_before_traversal'],'omittedLiveOrManagedRoots':selection['omitted_live_or_managed_roots'],'archiveModes':'Canonical 0644; original executable modes are not claimed preserved.','recordedToolVerification':'All five recorded evidence.py verify commands exit0; independently decoded all tar members and EVIDENCE inventories here, without rerunning tool tests.','sourceGuardLimitation':'This proves declared selected evidence inputs stable and current originals exact. It does not rebind old candidates to current production or assert held fix validity.'})
print(json.dumps({'status':'PASS','files':len(archived),'archives':len(archive_rows),'bytes':sum(r['bytes'] for r in archived.values())}))
