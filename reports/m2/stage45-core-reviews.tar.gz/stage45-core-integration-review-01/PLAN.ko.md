# Stage45 이후 원본 의무 해소 순서 제안

현재 생산 코드는 동결한다. 이 문서는 다음 구현의 우선순위 제안이며 구현 완료 또는 새 비교 통과를 뜻하지 않는다.

## 최종 bootstrap 600개 분류

| 결과 원인 | 호출 수 | 해석 |
| --- | ---: | --- |
| 통과 | 194 | 모든 비교 채널과 해당 read counter가 일치한다. |
| `pkl:reflect` 미구현 | 144 | annotation 조회 6개 식 × 24 evaluator session이다. |
| `JsonRenderer` 미구현 | 48 | test/사용자 output renderer 및 test output text가 직접 막힌다. |
| 값·오류·상태는 일치하고 read counter만 다름 | 166 | 동일 property resource의 반복 Host 읽기와 stdlib cache 생명주기 차이가 후속 호출까지 누적된다. |
| `pkl:test.output`의 evaluator 간 cache 차이 | 48 | Java JVM에서 먼저 성공한 renderer/text가 다음 evaluator에 남지만 Rust는 evaluator별로 초기화한다. |

위 분류는 배타적이며 합은 600이다. 겹치는 의존성은 별도로 유지한다: reflection Unsupported 중 72개, JSON Unsupported 중 20개, test-output payload mismatch 중 24개는 counter도 다르다. counter-only 166개 중 6개는 Java가 이전 evaluator의 test cache를 재사용하여 사용자 output의 첫 read 전까지 0회를 유지하는 순서에 의존한다. 따라서 resource cache만 구현하면 166개가 모두 통과한다고 주장하지 않는다. 600개의 raw channel과 counted before/after bytes를 다시 직접 비교했으며 원본을 정규화하거나 수정하지 않았다.

## 원본 사례를 우선하는 실행 순서

1. **기존 원본 `basic/read.pkl` 의무부터 해소한다.** 이미 `language-module-eval`에 등록된 ready 사례이며 source/argv/cwd/resource/expected-exit를 유지한다. 실제 file reader, 정상 `Resource` 값의 `uri`/`text`/`bytes`, triple-dot 탐색, 서로 다른 module 선언 URI에서 같은 상대 resource URI를 읽는 경계와 shared resource cache를 함께 구현한다. Resource SPI의 typed security/I/O 원인과 임의 raw Host 거절도 분리한다. 단순히 `prop:pkl.outputFormat` 결과를 특별 취급하거나 counter만 줄이지 않는다. Java `ResourceManager`처럼 해석하고 normalize한 URI를 key로 성공 값과 absence를 evaluator 생명주기 동안 유지하고, 예외는 다시 시도하며, raw Host protocol의 임의 완료·취소·close 의미는 보존한다. 새 callback/reentry controls는 이 원본 사례의 원인을 설명하는 보조 증거로만 추가한다. `basic/readGlob.pkl`은 별도의 package/HTTP/TLS fixture 요구가 있는 blocked 원본이므로 cache 완료를 이유로 통과시키지 않는다.
2. **일반 `JsonRenderer`와 `Module.output` 경로를 구현한다.** 원본 `api/jsonRenderer1.json.pkl`부터 `jsonRenderer9.json5.pkl`, `jsonRenderer2b.pkl`, `jsonRendererEmptyComposites.pkl`까지 11개 기존 ID를 순서와 바이트 그대로 사용한다. 현재 이 11개 row는 adapter가 없고 unimplemented이므로 원래 전체 module/output 계약을 먼저 연결하여 실제 첫 실패를 기록한다. 기존 객체/collection force·converter·진단 경로를 이용하여 중첩 값, escaping, 숫자, 빈 composite, 오류를 처리한다. bootstrap의 `{}` 또는 class-name만 반환하는 축소 구현은 목표가 아니다. 해결된 원본 row와 남은 실패를 각각 기록한다.
3. **source-backed `pkl:reflect`를 원본 declaration 계약에 연결한다.** `api/reflect1.pkl`–`reflect5.pkl`, `api/reflectedDeclaration.pkl`의 6개 기존 ID가 우선이다. 현재 annotation 객체와 class/module identity를 재사용하되 reflect module/class/type/member declaration의 owner·lazy property·annotations를 실제 메타데이터로 제공한다. bootstrap의 annotations.length만 맞추는 별도 가짜 객체를 만들지 않는다. 이 6개 row도 아직 adapter 없음/unimplemented이므로 새 scalar 선택 사례로 원본 상태를 대신 바꾸지 않는다.
4. **evaluator 간 stdlib cache 생명주기를 별도 설계한다.** payload mismatch 48개와 앞서 구분한 counter timing 6개를 제거할 실제 engine/context 소유권을 설계한다. JVM의 첫 성공 cache를 맞추려고 문자열 결과를 전역에 저장하거나 서로 다른 evaluator heap의 ObjectId를 공유하면 기존 수명·격리·close-zero 계약을 훼손할 수 있다. 먼저 immutable stdlib program과 mutable evaluated members의 소유자·동시성·종료 경계를 명시한다. 이 항목은 fresh-JVM 원본 module 사례를 줄이는 작업보다 후순위지만 삭제하거나 예외 통과로 바꾸지 않는다. ModuleInfo의 같은 evaluator/여러 root 후속 호출 56개도 별도 API 의무로 남긴다.

`original-next-obligations.json`에는 위 19개 원본 ID·source hash·현재 adapter/state를 보존했다. 다음 작업의 성공 기준은 새 selected pass의 수가 아니라 원래의 unimplemented/blocked/mismatch row를 동일한 계약으로 실제 실행하여 줄인 수이다. 본 분류 자체는 새 실행 결과나 19개 사례의 성공 예측이 아니다. Java-internal Unicode version parsing, 기존 두 regex 실패, empty stack-frame transformer profile 차이는 별도 미완료 범위를 유지한다.
