"""Read-only independent publication audit; never acquires/builds or writes Git."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
M2 = ROOT / "target/m2"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(relative):
    return (ROOT / relative).read_bytes()

def obj(relative):
    return json.loads(read(relative))

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)

def differences(a, b, prefix=""):
    if type(a) is not type(b):
        return [prefix]
    if isinstance(a, dict):
        assert a.keys() == b.keys(), prefix
        return [p for key in a for p in differences(a[key], b[key], prefix + "/" + key)]
    if isinstance(a, list):
        assert len(a) == len(b), prefix
        return [p for i, (x, y) in enumerate(zip(a, b)) for p in differences(x, y, prefix + "/" + str(i))]
    return [] if a == b else [prefix]

baseline_path = "target/m2/stage45-rust5-02/source-before.json"
baseline_bytes = read(baseline_path)
baseline = json.loads(baseline_bytes)
assert len(baseline) == 14216
binding_path = "target/m2/stage45-proposed-binding-01/source-map.json"
binding_bytes = read(binding_path)
binding = json.loads(binding_bytes)
binding_report = obj("target/m2/stage45-proposed-binding-01/report.json")
assert sha(binding_bytes) == binding_report["proposed_binding_map_sha256"]
assert sha(baseline_bytes) == binding_report["captured_source_map_sha256"]
assert baseline.keys() == binding.keys()
index = {}
for line in git("ls-files", "--stage", "-z").split(b"\0"):
    if line:
        metadata, name = line.split(b"\t", 1)
        mode, oid, stage = metadata.decode().split()
        assert stage == "0"
        index[name.decode()] = (mode, oid)
for path, expected in baseline.items():
    source = ROOT / path
    assert source.is_file() and not source.is_symlink(), path
    data = source.read_bytes()
    assert sha(data) == expected, path
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert binding[path] == {"sha256": expected, "git_blob": blob, "mode": index[path][0], "bytes": len(data)}, path
    assert index[path][1] == blob, path
assert not any(path.startswith("external/") for path in baseline)
for path, pin in binding_report["references"].items():
    assert index[path] == ("160000", pin)
    assert git("-C", str(ROOT / path), "rev-parse", "HEAD").decode().strip() == pin

rust = obj("target/m2/stage45-rust5-02/report.json")
assert rust["pass"] and len(rust["commands"]) == 5
for i, command in enumerate(rust["commands"]):
    assert command["exit_code"] == 0 and command["source_stable"] and not command["source_changes"]
    assert read(f"target/m2/stage45-rust5-02/{i}.source-after.json") == baseline_bytes
    for stream in ["stdout", "stderr"]:
        assert sha(read(f"target/m2/stage45-rust5-02/{i}.{stream}.bin")) == command[f"{stream}_sha256"]
assert read("target/m2/stage45-native-final-01/source-after.json") == baseline_bytes
assert read("target/m2/stage45-native-final-01/source-before.json") == baseline_bytes
native = obj("target/m2/stage45-native-final-01/report.json")
assert native["exit_code"] == 0 and native["source_stable"]

review02_path = "target/m2/stage45-core-review-02/frozen-candidate05/reviewed-sources.json"
review02 = obj(review02_path)
review03 = obj("target/m2/stage45-core-review-03/report.json")
assert sha(read(review02_path)) == obj("target/m2/stage45-core-review-02/report.json")["reviewed_sources_sha256"]
review02_drift = sorted(path for path, row in review02.items() if sha(read(path)) != row["sha256"])
assert set(review02_drift) == set(review03["after"]) & set(review02)
assert review03["sources_stable"] and not review03["additional_findings"]
assert all(baseline[path] == expected for path, expected in review03["after"].items())

staged = git("diff", "--cached", "--name-only", "-z").decode().split("\0")
authored = [path for path in staged if path.startswith(("crates/", "tests/fixtures/"))]
assert all(path in baseline for path in authored)

tooling = obj("target/m2/stage45-tooling-final-01/report.json")
assert tooling["complete"]
python_tests = 0
for command in tooling["commands"]:
    assert command["exit_code"] == command["expected_exit_code"]
    for stream in ["stdout", "stderr"]:
        raw = read(f"target/m2/stage45-tooling-final-01/{command['label']}.{stream}.bin")
        assert sha(raw) == command[f"{stream}_sha256"]
        if stream == "stderr":
            match = re.search(rb"Ran (\d+) tests", raw)
            if match:
                python_tests += int(match[1])
assert python_tests == 27
portable_stdout = read("target/m2/stage45-tooling-final-01/portable-transport-tests.stdout.bin")
assert b"tests 22" in portable_stdout and b"pass 22" in portable_stdout and b"fail 0" in portable_stdout
before = obj("target/m2/stage45-tooling-final-01/manifest-before.json")
after = obj("target/m2/stage45-tooling-final-01/manifest-after.json")
delta = differences(before, after)
assert len(delta) == 102 and all(path.endswith("/sha256") for path in delta)
assert before["cases"] == after["cases"] and len(after["cases"]) == 4527
assert read("compatibility/m2-language.json") == read("target/m2/stage45-tooling-final-01/manifest-after.json")
portable = obj("target/m2/stage45-portable-promotion-01/manifest.json")
for row in portable["entries"]:
    assert sha(read(row["path"])) == row["sha256"]
assert sum(row["action"] == "add" for row in portable["entries"]) == 9

docs = ["README.md", "PLAN.md", "TESTING.md", "docs/architecture.md", "docs/m2-moduleinfo-fixtures.md", "docs/m2-stdlib-bootstrap.md"]
evidence = [baseline_path, binding_path, "target/m2/stage45-proposed-binding-01/report.json",
            "target/m2/stage45-rust5-02/report.json", "target/m2/stage45-native-final-01/report.json",
            "target/m2/stage45-native-final-01/artifacts.json", "target/m2/stage45-core-review-02/report.json",
            "target/m2/stage45-core-review-03/report.json", "target/m2/stage45-tooling-final-01/report.json",
            "target/m2/stage45-portable-promotion-01/manifest.json", "target/m2/stage45-supplemental-platform-audit-03/report.json",
            "target/m2/stage45-original6-native-final-audit-01/report.json"]
report = {
    "schema": 1,
    "status": "No new publication blocker in the reviewed source/index binding and six documents.",
    "scope": "Read-only source/evidence/publication review. No builds, tests, Java acquisition, Git writes, source edits, full selected regression, hosted CI or performance verification.",
    "head_at_review": git("rev-parse", "HEAD").decode().strip(),
    "verified_explicit_source_paths": len(baseline),
    "live_source_changes_or_missing": [],
    "all_five_rust_post_command_maps_and_native_final_map_identical": True,
    "all_captured_paths_match_current_index_git_blobs": True,
    "reference_paths_in_capture": 0,
    "pinned_gitlinks_match": binding_report["references"],
    "staged_runtime_fixture_paths_verified": len(authored),
    "review02_paths": len(review02),
    "review02_changes_exactly_overlapping_review03_correction": review02_drift,
    "review03_additional_previously_unreviewed_file": sorted(set(review03["after"]) - set(review02)),
    "review03_corrected_sources_unchanged": True,
    "recorded_checks_verified": {"rust_required_commands": 5, "fixture_integrity_commands": 3, "python_tests": python_tests, "javascript_tests": 22, "tests_rerun_by_reviewer": 0},
    "generated_manifest": {"case_definitions_and_order_unchanged": True, "cases": 4527, "source_sha256_only_changes": len(delta)},
    "portable_addendum": {"new_files": 9, "existing_files": 3, "all_live_hashes_match_separate_runtime_tooling_manifest": True},
    "evidence_sha256": {path: sha(read(path)) for path in evidence},
    "reviewed_document_sha256": {path: sha(read(path)) for path in docs},
    "document_scope_review": [
        "PLAN preserves original6 x2, ModuleInfo156, actual security10 and full guest session/API counts separately from partial constructor/terminal boundaries.",
        "ModuleInfo Java internal12 and independent-root56 remain unsupported/unexecuted; Unicode digit specialization is not general regex parity.",
        "Broader bootstrap per-target194pass/192unsupported/214mismatch remains explicit and is not added to selected case counts.",
        "M1 common platform6078 shared-engine matches and Java6076 plus2known failures remain distinct from contract passes.",
        "Raw Host, terminal and logger failures remain outside guest exception conversion; typed security completions do not claim full Java policy.",
        "M1 collector modules.txt omission is honestly qualified by complete earlier freeze and native-after map, not relabeled directly captured.",
        "Full selected/sequential combined regression, broad raw archive publication, generic stdlib/API/platform coverage and performance remain open."
    ],
    "additional_findings": [],
    "full_m2_complete": False,
}
(OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "verified_explicit_source_paths": len(baseline), "staged_runtime_fixture_paths_verified": len(authored), "report_sha256": sha((OUT / "report.json").read_bytes())}))
