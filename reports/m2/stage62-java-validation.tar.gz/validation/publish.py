"""Publish and fully read back Stage 62 Java validation and authored history."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
VALIDATION = Path(__file__).resolve().parent
REPORTS = ROOT / "reports/m2"
FIXTURE = ROOT / "tests/fixtures/m2-collection-conversions"
CAPTURES = [
    (1, "Superseded authored module-local helpers were inaccessible to the public expression API."),
    (2, "Superseded after adding nested-lazy, inherited hidden, child-first error, and shadowing controls."),
    (3, "Superseded authored Dynamic hidden modifier was invalid; corrected in capture 04."),
    (4, "Canonical reviewed 236-row Java string authority; also embedded in the sealed fixture archive."),
]
EXPECTED_HEAD = "912c7319c418208351f1ff7f56d9e7f5dfa7b8ec"

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}

def need(condition, reason):
    if not condition:
        raise ValueError(reason)

def paths_under(root, prefix):
    need(root.is_dir() and not root.is_symlink(), "publication input missing or symlinked")
    result = {}
    for path in root.rglob("*"):
        need(not path.is_symlink(), "publication input contains symlink")
        if path.is_file():
            result[prefix + path.relative_to(root).as_posix()] = path
        else:
            need(path.is_dir(), "publication input contains nonregular path")
    return result

def emit_archive(path, files, scope):
    need(not path.exists(), "fresh publication archive required")
    entries = {name: source.read_bytes() for name, source in files.items()}
    before = {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in entries.items()}
    manifest = {"schema": 1, "scope": scope, "members": dict(sorted(before.items()))}
    entries["archive-manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with path.open("wb") as out:
        with gzip.GzipFile(fileobj=out, mode="wb", mtime=0, filename="") as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, raw in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(raw))
    after = {name: identity(source) for name, source in files.items()}
    need(before == after, "publication source changed while archived")
    observed = {}
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            need(member.isfile() and member.name not in observed
                 and not member.name.startswith("/") and ".." not in Path(member.name).parts,
                 "unsafe or duplicate archive member")
            raw = archive.extractfile(member).read()
            need(len(raw) == member.size, "archive member size differs")
            observed[member.name] = raw
    need(observed == entries and json.loads(observed["archive-manifest.json"]) == manifest,
         "full archive member byte/hash readback differs")
    return {"archive": path.relative_to(ROOT).as_posix(), "identity": identity(path),
            "members": len(observed), "member_hash_readback": True,
            "source_before_after_equal": before == after,
            "embedded_manifest_sha256": sha(observed["archive-manifest.json"])}

def check_capture(number, root):
    provenance = json.loads((root / "provenance.json").read_bytes())
    audit = json.loads((root / "audit.json").read_bytes())
    rows = json.loads((root / "cases.json").read_bytes())["rows"]
    need(audit["rows"] == len(rows) and len(rows) in (225, 227, 236),
         "history authored row count differs")
    need(provenance["complete"] is True and provenance["stable"] is True
         and provenance["raw_equal"] is True and provenance["raw_differences"] == []
         and provenance["input_before"] == provenance["input_after"]
         and provenance["source_before"] == provenance["source_after"]
         and provenance["artifact_sha256"] == provenance["artifact_after_sha256"],
         "history source or acquisition stability differs")
    for name, expected in provenance["input_before"].items():
        need(identity(root / name)["sha256"] == expected, "history input differs")
    for name, expected in provenance["source_before"].items():
        need(identity(root / "sources" / name)["sha256"] == expected, "history source copy differs")
    sessions = provenance["sessions"]
    need(len(sessions) == 2 and [session["repeat"] for session in sessions] == [0, 1]
         and len({session["pid"] for session in sessions}) == 2
         and sessions[0]["finished_epoch"] <= sessions[1]["started_epoch"],
         "history fresh ordered JVMs differ")
    raw_sets = []
    for session in sessions:
        folder = root / f"repeat-{session['repeat']}"
        need(session["exit_code"] == 0 and session["query_directories"] == len(rows),
             "history session incomplete")
        need(identity(folder / "process.stdout.bin")["sha256"] == session["stdout_sha256"]
             and identity(folder / "process.stderr.bin")["sha256"] == session["stderr_sha256"],
             "history process raw hash differs")
        need((folder / "process.stderr.bin").read_bytes() == b"", "history process stderr differs")
        protocol = [f"session-open mode=string rows={len(rows)}"]
        counts = Counter()
        for index, row in enumerate(rows):
            case = folder / f"{index:03d}-{row['id']}"
            need(case.is_dir() and row["mode"] == "string", "history row/mode differs")
            need((case / "expression.bin").read_text() == row["expression"],
                 "history expression differs")
            status = (case / "result.status.bin").read_text().strip()
            need(status in ("success", "error", "oracle-error", "api-exception"),
                 "history row status differs")
            counts[status] += 1
            call = f"string-{index}-{row['id']}"
            protocol.extend((f"call-enter={call}", f"call-exit={call} status={status}"))
        protocol.append(f"session-closed mode=string rows={len(rows)} public-calls={len(rows)} "
                        f"success={counts['success']} errors={len(rows)-counts['success']}")
        need((folder / "process.stdout.bin").read_bytes() == ("\n".join(protocol) + "\n").encode(),
             "history whole Java process protocol differs")
        need(dict(counts) == audit["statuses"], "history audit statuses differ")
        raw = {path.relative_to(folder).as_posix(): identity(path)["sha256"]
               for path in folder.rglob("*") if path.is_file()}
        need(len(raw) == provenance["raw_files"], "history raw file count differs")
        raw_sets.append(raw)
    need(raw_sets[0] == raw_sets[1], "history repeated raw bytes differ")
    return {"rows": len(rows), "statuses_per_session": audit["statuses"],
            "raw_files_per_session": provenance["raw_files"],
            "pids": [session["pid"] for session in sessions],
            "source_stable": provenance["stable"], "raw_repetitions_equal": True,
            "source_count": len(provenance["source_before"]),
            "artifact_sha256": provenance["artifact_sha256"],
            "jdk": {name: provenance["jdk"][name] for name in
                    ("executable_sha256", "modules_sha256", "release_sha256")}}

def main():
    validation = json.loads((VALIDATION / "validation.json").read_bytes())
    need(validation["baseline_head"] == EXPECTED_HEAD and validation["complete"] is True
         and validation["source_stable"] is True and validation["snapshot_matches"] is True
         and len(validation["checks"]) == 5
         and all(check["exit_code"] == 0 for check in validation["checks"]),
         "recorded Java-only validation incomplete")
    for name, expected in validation["source_before"].items():
        need(identity(VALIDATION / "sources" / name)["sha256"] == expected,
             "validation copied source differs")
    captures = {}
    history_files = {}
    for number, reason in CAPTURES:
        root = ROOT / f"target/m2/stage62-collection-conversions-oracle-0{number}"
        label = f"capture-0{number}"
        captures[label] = {**check_capture(number, root), "role": "canonical" if number == 4 else "superseded",
                           "reason": reason}
        history_files.update(paths_under(root, f"history/{root.name}/"))
    fixture_identity = json.loads((FIXTURE / "archive-identity.json").read_bytes())
    need(fixture_identity["captures"] == {"capture-04": "stage62-collection-conversions-oracle-04"}
         and fixture_identity["members"] == 9980
         and fixture_identity["archive_sha256"] == identity(FIXTURE / "oracle-evidence.tar.gz")["sha256"],
         "canonical fixture identity differs")
    for name in ("cases.json", "module.pkl", "queries.tsv"):
        need((FIXTURE / name).read_bytes() ==
             (ROOT / "target/m2/stage62-collection-conversions-oracle-04" / name).read_bytes(),
             "canonical authored input differs")
    history_archive = emit_archive(REPORTS / "stage62-java-history.tar.gz", history_files,
                                   "All Stage 62 collection conversion authored Java captures 01-04, including superseded attempts and canonical raw runs")
    validation_archive = emit_archive(REPORTS / "stage62-java-validation.tar.gz",
                                      paths_under(VALIDATION, "validation/"),
                                      "Stage 62 Java-only authority validation, raw checks and exact source snapshots")
    provenance = json.loads((ROOT / "target/m2/stage62-collection-conversions-oracle-04/provenance.json").read_bytes())
    checkpoint = {
        "schema": 1, "kind": "stage62-collection-conversions-java-authority-checkpoint",
        "baseline": "Pkl 0.32.0", "baseline_head": EXPECTED_HEAD,
        "candidate_compatibility_passes_claimed": 0,
        "canonical": {"path": FIXTURE.relative_to(ROOT).as_posix(),
                      "module_uri": "file:///stage62/collection-conversions.pkl",
                      "boundary": "string", "rows": 236,
                      "statuses_per_session": {"success": 158, "error": 78},
                      "archive_prefix": "capture-04", "archive": identity(FIXTURE / "oracle-evidence.tar.gz"),
                      "archive_members": fixture_identity["members"],
                      "fileset_sha256": fixture_identity["fileset_sha256"]},
        "java_runtime": {"reference_revision": provenance["reference_revision"],
                         "artifact_sha256": provenance["artifact_sha256"],
                         "jdk_executable_sha256": provenance["jdk"]["executable_sha256"],
                         "jdk_modules_sha256": provenance["jdk"]["modules_sha256"],
                         "jdk_release_sha256": provenance["jdk"]["release_sha256"],
                         "artifact_before_after_equal": provenance["artifact_sha256"] == provenance["artifact_after_sha256"]},
        "validation": {"directory": VALIDATION.relative_to(ROOT).as_posix(),
                       "record": (VALIDATION / "validation.json").relative_to(ROOT).as_posix(),
                       "record_identity": identity(VALIDATION / "validation.json"),
                       "source_stable": validation["source_stable"],
                       "source_count": len(validation["source_before"]),
                       "checks": validation["checks"],
                       "manifest_freshness_pass_claimed": False,
                       "deferred_final_integration": validation["deferred_final_integration"],
                       **validation_archive},
        "history": {"captures": captures, **history_archive},
        "limits": [
            "Java public string API observations only; no Rust candidate passes are claimed.",
            "Typed Java export and Java wrapper reference identity were not compared.",
            "Original upstream snippet replay, browser/Node, full M2 and performance gates remain separate.",
            "M2 manifest freshness is deferred until concurrent Rust/core source freeze and regeneration.",
            "A verifier-only raw JDK identity cross-check was added after early local verifier runs; this publication records fresh validation with that check.",
        ],
    }
    dest = REPORTS / "stage62-java-checkpoint.json"
    need(not dest.exists(), "fresh Java checkpoint publication required")
    dest.write_text(json.dumps(checkpoint, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"checkpoint": identity(dest), "validation": validation_archive,
                      "history": history_archive}, sort_keys=True))

if __name__ == "__main__":
    main()
