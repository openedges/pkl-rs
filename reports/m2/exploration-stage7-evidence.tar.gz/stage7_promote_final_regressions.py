from pathlib import Path
import sys,json
sys.path.insert(0,'tools');import m2_manifest as contract,oracle,m2_language as lang
selection=contract.ROOT/contract.SELECTION;current=json.loads(selection.read_bytes());assert len(current['cases'])==851
baseline=Path('target/m2/stage7-selection-baseline-04');baseline.mkdir(exist_ok=False)
(baseline/'cases.json').write_bytes(selection.read_bytes());(baseline/'identities.json').write_bytes(contract.encoded({x['id']:dict(definition=x,input_sha256=oracle.sha256(contract.ROOT/x['input'])) for x in current['cases']}))
promoted=[]
for dirname in ['stage7-review-key-force-order-java-01','stage7-constant-keys-java-01']:
 directory=Path('target/m2')/dirname
 for case in json.loads((directory/'matrix.json').read_bytes()):
  identifier=('equality-key-review-' if 'force-order' in dirname else 'equality-')+case['id'];file=Path('tests/fixtures/m2')/(identifier+'.pkl');folder=directory/'cases'/case['id'];process=json.loads((folder/'java.process.json').read_bytes());outcome=(folder/'java.outcome.bin').read_bytes();assert not process['timed_out']
  expected='success' if process['exit_code']==0 else 'failure';assert outcome==b'success\n' if expected=='success' else lang.valid_exception_outcome(outcome)
  requirements=['semantic:operators','semantic:objects','semantic:collections','semantic:lazy-evaluation','semantic:diagnostics']
  if 'force-order' in dirname:requirements.extend(['semantic:amendment','semantic:name-resolution'])
  if 'shadowed' in case['id']:requirements.extend(['semantic:functions','semantic:name-resolution'])
  if 'generator' in case['id']:requirements.append('semantic:generators')
  row=dict(id=identifier,input=str(file),expression=case['expression'],requirements=requirements,expected_outcome=expected)
  assert not file.exists();file.write_bytes(case['source'].encode());current['cases'].append(row)
  promoted.append(dict(id=identifier,exploration=str(directory),exploratory_case_id=case['id'],input_sha256=oracle.sha256(file)))
selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
Path('target/m2/stage7-final-regression-promotion.json').write_bytes(contract.encoded(dict(selected_count=len(promoted),provenance=promoted,reason='Last concrete override forcing regressions and constant-List-key resolver regression matrix; root authorized final selected corpus freeze at 864 cases.',original_851_definitions_and_bytes_preserved=True)))
print('Promoted',len(promoted),'total',len(current['cases']))
