"""Capture exact Java diagnostics using the URI supplied by JS adapter scenarios."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
import oracle
import m2_language as runner
import m2_manifest as manifest

output = ROOT / "target/m2/stage7-platform-java-01"
output.mkdir(parents=True, exist_ok=False)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
(output / "oracle.json").write_bytes(manifest.encoded(metadata))
helper = output / "M2BoundaryProbe.java"
helper.write_text("""import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
import org.pkl.core.PklException;
public final class M2BoundaryProbe {
  public static void main(String[] args) throws Exception {
    try (var evaluator = EvaluatorBuilder.preconfigured().setModuleCacheDir(null)
        .setPowerAssertionsEnabled(Boolean.parseBoolean(args[2])).setColor(false)
        .setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      try {
        var module = ModuleSource.create(URI.create(args[1]), Files.readString(Path.of(args[0])));
        var result = evaluator.evaluateExpressionString(module, "result");
        Files.writeString(Path.of(args[3]), "success\\n", StandardCharsets.UTF_8);\n        System.out.write(result.getBytes(StandardCharsets.UTF_8));
      } catch (PklException error) {
        Files.writeString(Path.of(args[3]), "pkl-exception\\t" + error.getClass().getName() + "\\n", StandardCharsets.UTF_8);\n        System.err.write(error.getMessage().getBytes(StandardCharsets.UTF_8));
        System.exit(1);
      }
    }
  }
}
""")
classes = output / "classes"
classes.mkdir()
compiled = runner.capture([
    str(Path(metadata["java"]).with_name("javac")), "-encoding", "UTF-8",
    "-cp", metadata["artifact"], "-d", str(classes), str(helper)
], output, "javac", metadata["environment"])
assert compiled["exit_code"] == 0
cases = [('equality-nested', 'left = new Dynamic { values = new Listing { new { x = 1 }; 2 }; ["a"] = 3 }\nright = new Dynamic { ["a"] = 3; values = new Listing { new { x = 1 }; 2 } }\nresult = left == right\n', False), ('equality-boxed-numeric', 'result = (1 == 1.0) && (new { x = 1 } != new { x = 1.0 }) && (List(0.0) != List(-0.0))\n', False), ('equality-identity-lazy', 'value = new Listing { throw("unforced") }\nresult = value == value && new Listing { throw("unforced") } != new Listing {}\n', False), ('equality-typed', 'class Item { x: Int; hidden ignored: Int = throw("hidden") }\nleft = new Item { x = 42 }\nright = new Item { x = 42 }\nresult = left == right\n', False), ('key-dynamic', 'values = new Mapping { [new { x = 1; y = List(2, 3) }] = 42 }\nresult = values[new { y = List(2, 3); x = 1 }]\n', False), ('key-amendment', 'base = new Mapping { [new { x = 1 }] = 1 }\nvalues = (base) { [new { x = 1 }] = 42 }\nresult = values[new { x = 1 }]\n', False), ('key-boxed-list', 'values = new Mapping { [List(1)] = 20; [List(1.0)] = 22 }\nresult = values[List(1)] + values[List(1.0)]\n', False), ('key-duplicate-error', 'values = new Mapping { [new { x = 1 }] = 1; [new { x = 1 }] = 2 }\nresult = values.length\n', False), ('equality-force-error', 'left = new { x = new { fail = throw("left nested") } }\nright = new { x = 2 }\nresult = left == right\n', False), ('equality-power', 'left = new Listing { 1; 2 }\nright = new Listing { 1; 3 }\nresult: Int(left == right) = 0\n', True)]

prefix = metadata["command"][:metadata["command"].index("-cp")]
rows = []
for name, source, power in cases:
    directory = output / name
    directory.mkdir()
    path = directory / "input.pkl"
    path.write_bytes(source.encode())
    command = [*prefix, "-cp", str(classes) + ":" + metadata["artifact"],
               "M2BoundaryProbe", str(path), "file:///m2-platform.pkl", str(power).lower(), str(directory / "java.outcome.bin")]
    capture = runner.capture(command, directory, "java", metadata["environment"])
    rows.append({
        "id": name, "source": source, "source_sha256": oracle.sha256(path),
        "power_assertions": power, "capture": capture,
        "outcome_sha256": oracle.sha256(directory / "java.outcome.bin"),
        "stdout": (directory / "java.stdout.bin").read_text(),
        "stderr": (directory / "java.stderr.bin").read_text(),
    })
    print(name, capture["exit_code"], flush=True)
(output / "report.json").write_bytes(manifest.encoded({
    "scope": "Pinned Java-only observations for exact JS adapter source URI; Rust platform verification separate.",
    "helper_sha256": oracle.sha256(helper), "uri": "file:///m2-platform.pkl", "results": rows
}))
