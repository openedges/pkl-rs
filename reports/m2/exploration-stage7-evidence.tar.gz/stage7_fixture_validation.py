from pathlib import Path
import sys,json
sys.path.insert(0,'tools');import m2_language as lang,m2_manifest as contract
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
commands=[['python3','tools/m2_manifest.py','--check'],['python3','-m','unittest','discover','-s','tools/tests','-p','test_m2_language.py','-v']]
rows=[]
for index,command in enumerate(commands):
 row=lang.capture(command,out,str(index),timeout=300);rows.append(row);print(index,row['exit_code'])
(out/'results.json').write_bytes(contract.encoded(rows))
assert all(x['exit_code']==0 for x in rows)
