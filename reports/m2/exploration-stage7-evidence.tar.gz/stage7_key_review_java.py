from pathlib import Path
import sys
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
row=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert row['exit_code']==0
cases=[]
def add(id,source):cases.append(dict(id=id,source=source+'\n',expression='result'))
add('constructor-one', 'result=let(m=new Dynamic {[new Dynamic {x=throw("key")}]=0}) 1')
add('constructor-mapping-one', 'result=let(m=new Mapping {[new Dynamic {x=throw("key")}]=0}) 1')
add('constructor-four', 'result=let(m=new Dynamic {[new Dynamic {x=throw("key")}]=0;["a"]=1;["b"]=2;["c"]=3}) 1')
add('constructor-five', 'result=let(m=new Dynamic {[new Dynamic {x=throw("key")}]=0;["a"]=1;["b"]=2;["c"]=3;["d"]=4}) 1')
add('constructor-generated-four', 'result=let(m=new Dynamic {for(x in List(0)){[new Dynamic {x=throw("key")}]=0;["a"]=1;["b"]=2;["c"]=3}}) 1')
add('constructor-generated-five', 'result=let(m=new Dynamic {for(x in List(0)){[new Dynamic {x=throw("key")}]=0;["a"]=1;["b"]=2;["c"]=3;["d"]=4}}) 1')
add('constructor-five-hash-order', 'result=let(m=new Dynamic {[new Listing {throw("first")}]=0;[new Dynamic {x=throw("second")}]=1;["b"]=2;["c"]=3;["d"]=4}) 1')
add('identity-duplicate', 'key=new Dynamic {x=throw("unforced")}; result=let(m=new Dynamic {[key]=0;[key]=1}) 1')
add('lookup-identity', 'key=new Dynamic {x=throw("unforced")}; result=new Dynamic {[key]=7}[key]')
add('lookup-query-left', 'old=new Dynamic {x=throw("old")};query=new Dynamic {x=throw("query")}; result=new Dynamic {[old]=7}[query]')
add('insert-query-left', 'old=new Dynamic {x=throw("old")};query=new Dynamic {x=throw("query")}; result=let(m=new Dynamic {[old]=0;[query]=1}) 1')
add('constructor-listing-size-skip', 'result=let(m=new Dynamic {[new Listing {throw("old")}]=0;[new Listing {}]=1}) 1')
add('constructor-kind-skip', 'result=let(m=new Dynamic {[new Dynamic {x=throw("old")}]=0;[new Listing {throw("query")}]=1}) 1')
add('mapping-length-hash', 'result=new Mapping {[new Dynamic {x=throw("key")}]=0}.length')
add('mapping-parent-first-hash', 'p=new Mapping {[new Dynamic {x=throw("parent")}]=0};c=(p){[new Dynamic {x=throw("child")}]=1};result=c.length')
add('mapping-parent-identity-key', 'key=new Dynamic {x=throw("key")};p=new Mapping {[key]=0};c=(p){[key]=1};result=let(m=c) 1')
add('typed-target-before-key', 'class C {}; result=let(m=new C {[new Dynamic {x=throw("key")}]=0}) 1')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','target/m2/stage7_key_review_java.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{x}.java' for x in ['Object','Dynamic','Listing','Mapping','List','Typed']]
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((contract.ROOT/p).read_bytes())
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
results=[]
for case in cases:
 d=out/'cases'/case['id'];d.mkdir(parents=True);source=d/'input.pkl';source.write_text(case['source'])
 java=lang.capture_java(meta,art/'language_probe',case['id'],source,case['expression'],d)
 result=dict(id=case['id'],java=java,input_sha256=oracle.sha256(source),stdout=(d/'java.stdout.bin').read_bytes().decode(),stderr=(d/'java.stderr.bin').read_bytes().decode(),outcome=(d/'java.outcome.bin').read_bytes().decode());results.append(result)
 print(case['id'],java['exit_code'],repr(result['stdout']),repr(result['stderr'][:160]),flush=True)
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
