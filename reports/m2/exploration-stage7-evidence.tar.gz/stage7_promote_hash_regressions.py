from pathlib import Path
import sys,json
sys.path.insert(0,'tools');import m2_manifest as contract,oracle,m2_language as lang
selection=contract.ROOT/contract.SELECTION;current=json.loads(selection.read_bytes());assert len(current['cases'])==864
baseline=Path('target/m2/stage7-selection-baseline-05');baseline.mkdir(exist_ok=False)
(baseline/'cases.json').write_bytes(selection.read_bytes());(baseline/'identities.json').write_bytes(contract.encoded({x['id']:dict(definition=x,input_sha256=oracle.sha256(contract.ROOT/x['input'])) for x in current['cases']}))
promoted=[]
for dirname in ['stage7-equality-hash-transition-java-01','stage7-equality-length-hash-java-01']:
 directory=Path('target/m2')/dirname
 for case in json.loads((directory/'matrix.json').read_bytes()):
  identifier='equality-'+case['id'];file=Path('tests/fixtures/m2')/(identifier+'.pkl');folder=directory/'cases'/case['id'];process=json.loads((folder/'java.process.json').read_bytes());outcome=(folder/'java.outcome.bin').read_bytes();assert not process['timed_out'] and process['exit_code']==1 and lang.valid_exception_outcome(outcome)
  requirements=['semantic:operators','semantic:objects','semantic:collections','semantic:lazy-evaluation','semantic:diagnostics']
  if 'fifth' in case['id']:requirements.append('semantic:generators')
  row=dict(id=identifier,input=str(file),expression=case['expression'],requirements=requirements,expected_outcome='failure')
  assert not file.exists();file.write_bytes(case['source'].encode());current['cases'].append(row)
  promoted.append(dict(id=identifier,exploration=str(directory),exploratory_case_id=case['id'],input_sha256=oracle.sha256(file)))
selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
Path('target/m2/stage7-hash-regression-promotion.json').write_bytes(contract.encoded(dict(selected_count=len(promoted),provenance=promoted,reason='Four concrete implementation bugs found during final audit: member-table hashing transition after non-entry insertion and Mapping equality getLength key hashing before count comparison. Root authorized these last bounded regression reproductions.',original_864_definitions_and_bytes_preserved=True)))
print('Promoted',len(promoted),'total',len(current['cases']))
