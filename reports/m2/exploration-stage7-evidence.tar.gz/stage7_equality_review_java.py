from pathlib import Path
import sys
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
row=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert row['exit_code']==0
cases=[]
def add(id,source):cases.append(dict(id=id,source=source+'\n',expression='result'))
add('dynamic-size-force','result=new Dynamic {x=throw("left")}==new Dynamic {}')
add('mapping-size-force','result=new Mapping {["x"]=throw("left")}==new Mapping {}')
add('listing-size-skip','result=new Listing {throw("left")}==new Listing {}')
add('strict-list-early-false','result=List(0,new Dynamic {x=throw("later")})==List(1,new Dynamic {x=0})')
add('nested-force-before-false','result=new Dynamic {x=0;y=new Dynamic {z=throw("nested")}}==new Dynamic {x=1;y=new Dynamic {z=0}}')
add('identity-skip','left=new Dynamic {x=throw("identity")}; result=left==left')
add('cycle-identity-skip','left=new Dynamic {self=left}; result=left==left')
add('typed-class-skip','class A {x=throw("class A")};class B {x=throw("class B")}; result=new A {}==new B {}')
add('boxed-nested-number','result=new Dynamic {x=1}==new Dynamic {x=1.0}')
add('boxed-nested-zero','result=new Listing {-0.0}==new Listing {0.0}')
add('key-nested-number','m=new Mapping {[new Dynamic {x=1}]=1;[new Dynamic {x=1.0}]=2}; result=m[new Dynamic {x=1.0}]')
add('default-force','result=new Dynamic {default=throw("default");x=0}==new Dynamic {x=0}')
add('listing-default-force','result=new Listing {default=throw("default");0}==new Listing {0}')
add('dynamic-local-skip','result=new Dynamic {local x=throw("local");y=1}==new Dynamic {y=1}')
add('key-default-force','m=new Mapping {[new Dynamic {default=throw("key default");x=1}]=0}; result=m.length')
add('key-deep-force','m=new Mapping {[new Dynamic {x=new Dynamic {y=throw("key nested")}}]=0}; result=m.length')
add('wrapper-equality-force','checked:Listing<Int> =new Listing {"bad"};result=checked==new Listing {"bad"}')
add('wrapper-identity-skip','checked:Listing<Int> =new Listing {"bad"};result=checked==checked')
add('wrapper-length-skip','checked:Listing<Int> =new Listing {"bad"};result=checked==new Listing {}')
add('nested-order-child-first','p=new Dynamic {x=throw("ancestor")};c=(p){y=new Dynamic {z=throw("child nested")}}; result=c==new Dynamic {}')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','target/m2/stage7_equality_review_java.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{x}.java' for x in ['Object','Dynamic','Listing','Mapping','List','Typed']]
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((contract.ROOT/p).read_bytes())
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
results=[]
for case in cases:
 d=out/'cases'/case['id'];d.mkdir(parents=True);source=d/'input.pkl';source.write_text(case['source'])
 java=lang.capture_java(meta,art/'language_probe',case['id'],source,case['expression'],d)
 result=dict(id=case['id'],java=java,input_sha256=oracle.sha256(source),stdout=(d/'java.stdout.bin').read_bytes().decode(),stderr=(d/'java.stderr.bin').read_bytes().decode(),outcome=(d/'java.outcome.bin').read_bytes().decode());results.append(result)
 print(case['id'],java['exit_code'],repr(result['stdout']),repr(result['stderr'][:160]),flush=True)
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
