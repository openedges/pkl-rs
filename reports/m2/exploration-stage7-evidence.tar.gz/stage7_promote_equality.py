from pathlib import Path
import sys,json
sys.path.insert(0,'tools');import m2_manifest as contract,oracle
base=Path('target/m2/stage7-selection-baseline-01');selection=contract.ROOT/contract.SELECTION
original=json.loads((base/'cases.json').read_bytes());current=json.loads(selection.read_bytes());assert len(original['cases'])==673 and current==original
identities=json.loads((base/'identities.json').read_bytes())
for row in original['cases']:assert oracle.sha256(contract.ROOT/row['input'])==identities[row['id']]['input_sha256']
held={'dynamic-hidden':'Pinned language disallows hidden modifier on object members; typed hidden regular-member exclusion is selected separately.','dynamic-hidden-override':'Pinned language disallows hidden modifier on Dynamic object members; typed hidden override is selected separately.','dynamic-hash-cycle':'Pinned oracle emits caught PklBugException for cyclic structural hashing; cyclic key compatibility remains unimplemented and is not a new development exception.','listing-hash-cycle':'Pinned oracle emits caught PklBugException for cyclic structural hashing; cyclic key compatibility remains unimplemented and is not a new development exception.','dynamic-equal-cycle':'Pinned oracle emits caught PklBugException for distinct cyclic structural equality; cycle compatibility remains unimplemented and is not a new development exception.'}
curated={};superseded=[];deferred=[]
for n in range(1,5):
 dirname=f'stage7-equality-java-{n:02}'
 for case in json.loads((Path('target/m2')/dirname/'matrix.json').read_bytes()):
  if case['id'] in curated:superseded.append(dict(id=case['id'],exploration=curated[case['id']][1],reason='Initial exploratory input was identical on both sides or used a non-local object method; corrected input captured separately. Original raw evidence retained.'))
  curated[case['id']]=(case,dirname)
relations={}
for a,b,domain in [('key-amend-replace','key-amend-replace-direct','Replacing an inherited entry keyed by fixed Dynamic { x = 1 } equals constructing that entry with value 42.'),('key-predicate-replace','key-predicate-replace-direct','Selecting the one inherited value 1 and replacing it with 42 preserves lookup by structural List(1).'),('dynamic-inherited','dynamic-inherited-direct','Overriding inherited x=missing with x=2 and retaining y=3 equals constructing fixed Dynamic { x=2; y=3 }.')]:
 relation=dict(kind='equal-stdout',case_ids=['equality-'+a,'equality-'+b],domain=domain);relations[a]=relation;relations[b]=relation
additional=[]
for case,dirname in curated.values():
 if case['id'] in held:deferred.append(dict(id=case['id'],exploration=dirname,reason=held[case['id']]));continue
 identifier='equality-'+case['id'];file=Path('tests/fixtures/m2')/(identifier+'.pkl');family=case['family']
 req=['semantic:operators','semantic:collections','semantic:objects','semantic:lazy-evaluation']
 if 'typed' in identifier or 'class' in identifier:req.append('semantic:classes')
 if 'function' in identifier or 'method' in identifier:req.extend(['semantic:functions','semantic:closures'])
 if family=='numeric':req.append('semantic:numeric-literals')
 if family=='modifiers' or 'hidden' in identifier or 'local' in identifier:req.append('semantic:modifiers')
 if family=='inheritance' or 'amend' in identifier or 'predicate' in identifier:req.extend(['semantic:amendment','semantic:name-resolution'])
 if any(s in identifier for s in ['generator','spread','predicate']):req.append('semantic:generators')
 if family=='wrappers' or 'wrapper' in identifier:req.extend(['semantic:types','semantic:generics'])
 if case['power_assertions']:req.append('semantic:constraints')
 directory=Path('target/m2')/dirname/'cases'/case['id'];process=json.loads((directory/'java.process.json').read_bytes());outcome=(directory/'java.outcome.bin').read_bytes();assert not process['timed_out']
 expected='success' if process['exit_code']==0 else 'failure';assert outcome==b'success\n' if expected=='success' else outcome.startswith(b'pkl-exception\torg.pkl.core.PklException\n')
 if expected=='failure':req.append('semantic:diagnostics')
 row=dict(id=identifier,input=str(file),expression=case['expression'],requirements=list(dict.fromkeys(req)),expected_outcome=expected)
 if case['power_assertions']:row['power_assertions']=True
 if case['id'] in relations:row['metamorphic_relation']=relations[case['id']];row['requirements'].append('semantic:generated-verification')
 additional.append((row,case['source'].encode(),dirname,case['id']))
assert len(additional)==139
for row,source,_,_ in additional:path=contract.ROOT/row['input'];assert not path.exists();path.write_bytes(source)
current['cases'].extend(row for row,_,_,_ in additional);selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
out=Path('target/m2/stage7-equality-promotion.json');assert not out.exists();out.write_bytes(contract.encoded(dict(raw_exploratory_captures=147,curated_inputs=len(curated),selected_count=len(additional),held=deferred,superseded=superseded,provenance=[dict(id=row['id'],exploration='target/m2/'+dirname,exploratory_case_id=identifier,input_sha256=contract.digest(source)) for row,source,dirname,identifier in additional])))
print('Promoted',len(additional),'held',len(deferred),'superseded',len(superseded),'total',len(current['cases']))
