from pathlib import Path
import sys,json,concurrent.futures
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
r=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert r['exit_code']==0
cases=[]
def add(id,source,family='cache',power=False):cases.append(dict(id=id,source=source+'\n',family=family,expression='result',power_assertions=power))
for k,body,plain in [('Listing','local x = 1; x','1'),('Mapping','local x = 1; ["x"] = x','["x"] = 1'),('Dynamic','local x = 1; y = x','y = 1')]:
 add(k.lower()+'-local-cached-equality',f'a = new {k} {{ {body} }}\nb = new {k} {{ {plain} }}\nresult = a == b')
 add(k.lower()+'-local-cached-key',f'a = new {k} {{ {body} }}\nb = new {k} {{ {plain} }}\nm = new Mapping {{ [a] = 42 }}\nresult = m[b]')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{k}.java' for k in ['Dynamic','Listing','Mapping','Typed','List','Function','Class']]+['external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/binary/EqualNode.java']
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 q=out/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 folder=out/'cases'/c['id'];folder.mkdir(parents=True);source=folder/'input.pkl';source.write_bytes(c['source'].encode())
 row=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],folder,c['power_assertions'])
 return dict(id=c['id'],family=c['family'],java=row,input_sha256=oracle.sha256(source),stdout=(folder/'java.stdout.bin').read_bytes().decode(),stderr=(folder/'java.stderr.bin').read_bytes().decode(),outcome=(folder/'java.outcome.bin').read_bytes().decode())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
for r in results:print(r['id'],r['java']['exit_code'],repr(r['stdout']),repr(r['stderr'][:100]),flush=True)
