from pathlib import Path
import sys
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
row=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert row['exit_code']==0
cases=[]
def add(id,source):cases.append(dict(id=id,source=source+'\n',expression='result'))
add('mapping-override-key-force-order', 'p=new Mapping {[new Dynamic {x=throw("ancestor key")}]=throw("parent body")};c=(p){[new Dynamic {x=throw("child key")}]=7};result=c==new Mapping {}')
add('dynamic-override-key-force-order', 'p=new Dynamic {[new Dynamic {x=throw("ancestor key")}]=throw("parent body")};c=(p){[new Dynamic {x=throw("child key")}]=7};result=c==new Dynamic {}')
add('mapping-override-value-before-key', 'p=new Mapping {[new Dynamic {x=throw("ancestor key")}]=throw("parent body")};c=(p){[new Dynamic {x=throw("child key")}]=throw("child value")};result=c==new Mapping {}')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','target/m2/stage7_key_force_order_review_java.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{x}.java' for x in ['Object','Dynamic','Listing','Mapping','List','Typed']]
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((contract.ROOT/p).read_bytes())
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
results=[]
for case in cases:
 d=out/'cases'/case['id'];d.mkdir(parents=True);source=d/'input.pkl';source.write_text(case['source'])
 java=lang.capture_java(meta,art/'language_probe',case['id'],source,case['expression'],d)
 result=dict(id=case['id'],java=java,input_sha256=oracle.sha256(source),stdout=(d/'java.stdout.bin').read_bytes().decode(),stderr=(d/'java.stderr.bin').read_bytes().decode(),outcome=(d/'java.outcome.bin').read_bytes().decode());results.append(result)
 print(case['id'],java['exit_code'],repr(result['stdout']),repr(result['stderr'][:160]),flush=True)
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
