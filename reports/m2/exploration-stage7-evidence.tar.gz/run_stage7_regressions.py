import json,subprocess,sys
from pathlib import Path
out=Path("target/m2/regression-commands-stage7-final")
out.mkdir(exist_ok=False)
for name in ["frontend", "runtime", "lifecycle"]:
 command=[sys.executable, f"tools/m1_{name}.py", "--output", f"target/m2/{name}-stage7-final"]
 r=subprocess.run(command,capture_output=True)
 (out/(name+".stdout.bin")).write_bytes(r.stdout)
 (out/(name+".stderr.bin")).write_bytes(r.stderr)
 print(json.dumps({"command":command,"exit_code":r.returncode}),flush=True)
 if r.returncode:
  print(r.stdout.decode(errors="replace")[-4000:]+r.stderr.decode(errors="replace")[-4000:])
  raise SystemExit(r.returncode)
