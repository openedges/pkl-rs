from pathlib import Path
import sys,json,concurrent.futures
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
r=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert r['exit_code']==0
cases=[]
def add(id,source,family='structural',power=False):cases.append(dict(id=id,source=source+'\n',family=family,expression='result',power_assertions=power))
def eq(id,a,b,pre='',family='structural'):add(id,pre+f'a = {a}\nb = {b}\nresult = a == b',family)
for kind,left,right in [('dynamic','new Dynamic { x = 1; y = 2 }','new Dynamic { y = 2; x = 1 }'),('listing','new Listing { 1; 2 }','new Listing { 1; 2 }'),('mapping','new Mapping { ["x"] = 1; ["y"] = 2 }','new Mapping { ["y"] = 2; ["x"] = 1 }'),('list','List(1, 2)','List(1, 2)'),('typed','new C {}','new C {}')]:
 pre='class C { x = 1; y = 2 }\n' if kind=='typed' else ''
 eq(kind+'-equal',left,right,pre)
 eq(kind+'-nested-mixed',left.replace('1','1.0'),right,pre)
 eq(kind+'-unequal',left.replace('1','9'),right,pre)
 add(kind+'-identity',pre+f'a = {left}\nresult = a == a','identity')
for kind,make in [('dynamic',lambda x:f'new Dynamic {{ x = {x} }}'),('listing',lambda x:f'new Listing {{ {x} }}'),('mapping',lambda x:f'new Mapping {{ ["x"] = {x} }}'),('list',lambda x:f'List({x})'),('typed',lambda x:f'new C {{ x = {x} }}')]:
 pre='class C { x: Any }\n' if kind=='typed' else ''
 for suffix,l,r in [('nan','NaN','NaN'),('signed-zero','0.0','-0.0')]:eq(kind+'-'+suffix,make(l),make(r),pre,'numeric')
 eq(kind+'-recursive',make('new Listing { new Dynamic { v = 1 } }'),make('new Listing { new Dynamic { v = 1 } }'),pre)
for suffix,l,r in [('mixed','1','1.0'),('nan','NaN','NaN'),('signed-zero','0.0','-0.0')]:eq('semantic-number-'+suffix,l,r,family='numeric')
for name,a,b in [('dynamic-listing','new Dynamic { 1 }','new Listing { 1 }'),('dynamic-mapping','new Dynamic { ["x"] = 1 }','new Mapping { ["x"] = 1 }'),('listing-list','new Listing { 1 }','List(1)'),('dynamic-typed','new Dynamic { x = 1 }','new C {}')]:eq('kind-'+name,a,b,'class C { x = 1 }\n' if 'typed' in name else '')
eq('dynamic-property-entry','new Dynamic { x = 1 }','new Dynamic { ["x"] = 1 }')
eq('dynamic-element-entry','new Dynamic { 1 }','new Dynamic { [0] = 1 }')
eq('dynamic-hidden','new Dynamic { hidden x = missing; y = 1 }','new Dynamic { y = 1 }',family='modifiers')
eq('dynamic-local','new Dynamic { local x = missing; y = 1 }','new Dynamic { y = 1 }',family='modifiers')
eq('dynamic-method','new Dynamic { function x() = missing; y = 1 }','new Dynamic { y = 1 }',family='modifiers')
eq('listing-default','new Listing { default = (i) -> missing; 1 }','new Listing { 1 }',family='modifiers')
eq('mapping-default','new Mapping { default = (k) -> missing; ["x"] = 1 }','new Mapping { ["x"] = 1 }',family='modifiers')
eq('typed-hidden','new C { hiddenValue = 9 }','new C {}','class C { hidden hiddenValue = 1; x = 2 }\n','modifiers')
eq('typed-class-distinct','new C {}','new D {}','class C { x = missing }\nclass D { x = missing }\n','identity')
eq('typed-class-child','new C {}','new D {}','open class C { x = 1 }\nclass D extends C {}\n','identity')
eq('class-self','C','C','class C {}\n','identity')
eq('class-distinct','C','D','class C {}\nclass D {}\n','identity')
eq('function-distinct','(x) -> x','(x) -> x',family='identity')
add('function-same','f = (x) -> x\nresult = f == f','identity')
for kind,body in [('Dynamic','x = missing'),('Listing','missing'),('Mapping','["x"] = missing')]:
 add(kind.lower()+'-self-unforced',f'a = new {kind} {{ {body} }}\nresult = a == a','forcing')
 eq(kind.lower()+'-other-kind-unforced',f'new {kind} {{ {body} }}','1',family='forcing')
 empty=f'new {kind} {{}}'
 eq(kind.lower()+'-length-before-force',f'new {kind} {{ {body} }}',empty,family='forcing')
 eq(kind.lower()+'-deep-before-mismatch',f'new {kind} {{ '+('x = 1; y = new { z = missing }' if kind=='Dynamic' else '1; new { z = missing }' if kind=='Listing' else '["x"] = 1; ["y"] = new { z = missing }')+' }',f'new {kind} {{ '+('x = 2; y = 0' if kind=='Dynamic' else '2; 0' if kind=='Listing' else '["x"] = 2; ["y"] = 0')+' }',family='forcing')
 eq(kind.lower()+'-left-before-right',f'new {kind} {{ {body} }}',f'new {kind} {{ '+body.replace('missing','1 ~/ 0')+' }',family='forcing')
eq('dynamic-inherited','(p) { x = 2 }','new Dynamic { x = 2; y = 3 }','p = new Dynamic { x = missing; y = 3 }\n','inheritance')
eq('listing-inherited','(p) { [0] = 2 }','new Listing { 2; 3 }','p = new Listing { missing; 3 }\n','inheritance')
eq('mapping-inherited','(p) { ["x"] = 2 }','new Mapping { ["x"] = 2; ["y"] = 3 }','p = new Mapping { ["x"] = missing; ["y"] = 3 }\n','inheritance')
# Structural key construction, lookup, duplicate detection and numeric boundaries.
keyforms=[('dynamic','new Dynamic { x = 1 }','new Dynamic { x = 1 }',''),('listing','new Listing { 1; 2 }','new Listing { 1; 2 }',''),('mapping','new Mapping { ["a"] = 1 }','new Mapping { ["a"] = 1 }',''),('list','List(1, 2)','List(1, 2)',''),('typed','new C {}','new C {}','class C { x = 1 }\n'),('function','f','f','f = (x) -> x\n'),('class','C','C','class C {}\n')]
for name,left,right,pre in keyforms:
 add('key-'+name+'-lookup',pre+f'a = {left}\nb = {right}\nm = new Mapping {{ [a] = 42 }}\nresult = m[b]','keys')
 add('key-'+name+'-duplicate',pre+f'a = {left}\nb = {right}\nm = new Mapping {{ [a] = 1; [b] = 2 }}\nresult = m.length','keys')
add('key-nested-nan','m = new Mapping { [List(NaN)] = 42 }\nresult = m[List(NaN)]','keys')
add('key-nested-mixed-distinct','m = new Mapping { [List(1)] = 10; [List(1.0)] = 20 }\nresult = m[List(1)] + m[List(1.0)]','keys')
add('key-nested-zero-distinct','m = new Mapping { [List(0.0)] = 10; [List(-0.0)] = 20 }\nresult = m[List(0.0)] + m[List(-0.0)]','keys')
add('key-dynamic-property-entry-distinct','a = new Dynamic { x = 1 }\nb = new Dynamic { ["x"] = 1 }\nm = new Mapping { [a] = 10; [b] = 20 }\nresult = m[a] + m[b]','keys')
add('key-order-independent','a = new Mapping { ["a"] = 1; ["b"] = 2 }\nb = new Mapping { ["b"] = 2; ["a"] = 1 }\nm = new Mapping { [a] = 42 }\nresult = m[b]','keys')
add('key-forces-deep','a = new Listing { new { x = missing } }\nm = new Mapping { [a] = 1 }\nresult = m.length','forcing')
add('key-before-value','a = new Dynamic { x = missing }\nm = new Mapping { [a] = 1 ~/ 0 }\nresult = m.length','forcing')
add('key-amend-replace','a = new Dynamic { x = 1 }\np = new Mapping { [a] = 1 }\nm = (p) { [new Dynamic { x = 1 }] = 42 }\nresult = m[a]','keys')
add('key-amend-body','a = List(1)\np = new Mapping { [a] = new { x = 1 } }\nm = (p) { [List(1)] { x = super.x + 1 } }\nresult = m[a].x','keys')
add('key-generator-duplicate','m = new Mapping { for (i in List(1, 1)) { [new Dynamic { x = i }] = i } }\nresult = m.length','keys')
add('key-spread-duplicate','p = new Mapping { [List(1)] = 1 }\nm = new Mapping { ...p; [List(1)] = 2 }\nresult = m.length','keys')
add('key-predicate-replace','p = new Mapping { [List(1)] = 1 }\nm = (p) { [[this == 1]] = 42 }\nresult = m[List(1)]','keys')
add('key-function-distinct','f = (x) -> x\ng = (x) -> x\nm = new Mapping { [f] = 1; [g] = 2 }\nresult = m.length','keys')
add('key-class-distinct','class C {}\nclass D {}\nm = new Mapping { [C] = 1; [D] = 2 }\nresult = m.length','keys')
add('listing-wrapper-equal','a: Listing<Int> = new Listing { 1; 2 }\nb = new Listing { 1; 2 }\nresult = a == b','wrappers')
add('listing-wrapper-force-bad','a: Listing<Int> = new Listing { "bad" }\nb = new Listing { 1 }\nresult = a == b','wrappers')
add('mapping-wrapper-equal','a: Mapping<String, Int> = new Mapping { ["x"] = 1 }\nb = new Mapping { ["x"] = 1 }\nresult = a == b','wrappers')
add('key-wrapper-listing','a: Listing<Int> = new Listing { 1 }\nm = new Mapping { [a] = 42 }\nresult = m[new Listing { 1 }]','wrappers')
add('key-wrapper-listing-bad','a: Listing<Int> = new Listing { "bad" }\nm = new Mapping { [a] = 42 }\nresult = m.length','wrappers')
add('power-equal-false','a = new Listing { 1 }\nb = new Listing { 2 }\nresult: Boolean(this == true) = a == b','power',True)
add('power-equal-object-false','a = new Dynamic { x = 1 }\nb = new Dynamic { x = 2 }\nresult: Boolean(a == b) = true','power',True)
add('power-key-missing','m = new Mapping { [List(1)] = 42 }\nresult = m[List(2)]','power',True)
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{k}.java' for k in ['Dynamic','Listing','Mapping','Typed','List','Function','Class']]+['external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/binary/EqualNode.java']
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 q=out/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 folder=out/'cases'/c['id'];folder.mkdir(parents=True);source=folder/'input.pkl';source.write_bytes(c['source'].encode())
 row=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],folder,c['power_assertions'])
 return dict(id=c['id'],family=c['family'],java=row,input_sha256=oracle.sha256(source),stdout=(folder/'java.stdout.bin').read_bytes().decode(),stderr=(folder/'java.stderr.bin').read_bytes().decode(),outcome=(folder/'java.outcome.bin').read_bytes().decode())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
for r in results:print(r['id'],r['java']['exit_code'],repr(r['stdout']),repr(r['stderr'][:100]),flush=True)
