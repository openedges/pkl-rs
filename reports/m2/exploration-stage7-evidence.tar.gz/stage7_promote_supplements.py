from pathlib import Path
import sys,json
sys.path.insert(0,'tools');import m2_manifest as contract,oracle,m2_language as lang
sources={'stage7-diagnostic-java-01':{'key-missing-dynamic','key-missing-class','key-listing-reject-object','key-duplicate-long','key-lookup-force-error','key-rejected-typed-force-order','equality-hidden-cache'},'stage7-review-java-02':{'cycle-identity-skip','wrapper-identity-skip','wrapper-length-skip','nested-order-child-first'}}
selection=contract.ROOT/contract.SELECTION;current=json.loads(selection.read_bytes());assert len(current['cases'])==812
promoted=[];unselected=[]
for dirname,ids in sources.items():
 directory=Path('target/m2')/dirname
 for case in json.loads((directory/'matrix.json').read_bytes()):
  if case['id'] not in ids:unselected.append(dict(id=case['id'],exploration=dirname,reason='Redundant with selected fixed structural equality/key behavior; original raw Java observation retained.'));continue
  identifier='equality-supplement-'+case['id'];file=Path('tests/fixtures/m2')/(identifier+'.pkl')
  folder=directory/'cases'/case['id'];process=json.loads((folder/'java.process.json').read_bytes());outcome=(folder/'java.outcome.bin').read_bytes();assert not process['timed_out']
  expected='success' if process['exit_code']==0 else 'failure';assert outcome==b'success\n' if expected=='success' else lang.valid_exception_outcome(outcome)
  requirements=['semantic:operators','semantic:objects','semantic:collections','semantic:lazy-evaluation']
  if any(x in case['id'] for x in ['class','typed','hidden']):requirements.append('semantic:classes')
  if 'hidden' in case['id']:requirements.append('semantic:modifiers')
  if 'wrapper' in case['id']:requirements.extend(['semantic:types','semantic:generics'])
  if 'nested-order' in case['id']:requirements.extend(['semantic:amendment','semantic:name-resolution'])
  if expected=='failure':requirements.append('semantic:diagnostics')
  row=dict(id=identifier,input=str(file),expression=case['expression'],requirements=requirements,expected_outcome=expected)
  assert not file.exists();file.write_bytes(case['source'].encode());current['cases'].append(row)
  promoted.append(dict(id=identifier,exploration='target/m2/'+dirname,exploratory_case_id=case['id'],input_sha256=oracle.sha256(file)))
selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
Path('target/m2/stage7-supplement-promotion.json').write_bytes(contract.encoded(dict(selected_count=len(promoted),provenance=promoted,unselected=unselected,review_initial_capture='stage7-review-java-01 retains all initial implicit-new and corrected/repeated explicit Dynamic observations; no bytes overwritten')))
print('Promoted',len(promoted),'total',len(current['cases']))
