from pathlib import Path
import sys,json
sys.path.insert(0,'tools');import m2_manifest as contract,oracle,m2_language as lang
selection=contract.ROOT/contract.SELECTION;current=json.loads(selection.read_bytes());assert len(current['cases'])==840
baseline=Path('target/m2/stage7-selection-baseline-03');baseline.mkdir(exist_ok=False)
(baseline/'cases.json').write_bytes(selection.read_bytes());(baseline/'identities.json').write_bytes(contract.encoded({x['id']:dict(definition=x,input_sha256=oracle.sha256(contract.ROOT/x['input'])) for x in current['cases']}))
promoted=[];unselected=[]
for dirname in ['stage7-review-key-inheritance-java-01','stage7-review-key-lookup-java-01','stage7-review-key-override-java-01']:
 directory=Path('target/m2')/dirname
 for case in json.loads((directory/'matrix.json').read_bytes()):
  if case['id']=='mapping-inherited-constructor-equal-unforced':unselected.append(dict(id=case['id'],exploration=str(directory),reason='Identical source and behavior to newly selected mapping-inherited-constructor-unforced; original raw capture retained.'));continue
  identifier='equality-key-review-'+case['id'];file=Path('tests/fixtures/m2')/(identifier+'.pkl');folder=directory/'cases'/case['id'];process=json.loads((folder/'java.process.json').read_bytes());outcome=(folder/'java.outcome.bin').read_bytes();assert not process['timed_out'] and process['exit_code']==0 and outcome==b'success\n'
  requirements=['semantic:operators','semantic:objects','semantic:collections','semantic:lazy-evaluation','semantic:amendment','semantic:name-resolution']
  if any(x in case['id'] for x in ['loop','spread']):requirements.append('semantic:generators')
  row=dict(id=identifier,input=str(file),expression=case['expression'],requirements=requirements,expected_outcome='success')
  assert not file.exists();file.write_bytes(case['source'].encode());current['cases'].append(row)
  promoted.append(dict(id=identifier,exploration=str(directory),exploratory_case_id=case['id'],input_sha256=oracle.sha256(file)))
selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
Path('target/m2/stage7-key-inheritance-promotion.json').write_bytes(contract.encoded(dict(selected_count=len(promoted),provenance=promoted,unselected=unselected,reason='Concrete regression reproductions for inherited declaration-local key construction, child-first lookup shortcuts and forcing/spread/for traversal of structurally overridden entries. Additional exploratory growth stops here except concrete discovered bugs.',original_840_definitions_and_bytes_preserved=True)))
print('Promoted',len(promoted),'total',len(current['cases']))
