from pathlib import Path
import sys,json
sys.path.insert(0,'tools');import m2_manifest as contract,oracle,m2_language as lang
selection=contract.ROOT/contract.SELECTION;current=json.loads(selection.read_bytes());assert len(current['cases'])==868
baseline=Path('target/m2/stage7-selection-baseline-06');baseline.mkdir(exist_ok=False)
(baseline/'cases.json').write_bytes(selection.read_bytes());(baseline/'identities.json').write_bytes(contract.encoded({x['id']:dict(definition=x,input_sha256=oracle.sha256(contract.ROOT/x['input'])) for x in current['cases']}))
promoted=[]
for dirname in ['stage7-constant-keys-java-02','stage7-constant-keys-java-03']:
 directory=Path('target/m2')/dirname
 for case in json.loads((directory/'matrix.json').read_bytes()):
  identifier='equality-'+case['id'];file=Path('tests/fixtures/m2')/(identifier+'.pkl');folder=directory/'cases'/case['id'];process=json.loads((folder/'java.process.json').read_bytes());outcome=(folder/'java.outcome.bin').read_bytes();assert not process['timed_out'] and process['exit_code']==1 and lang.valid_exception_outcome(outcome)
  requirements=['semantic:operators','semantic:objects','semantic:collections','semantic:lazy-evaluation','semantic:diagnostics','semantic:lexing']
  if 'interpolation' in case['id']:requirements.append('semantic:strings')
  row=dict(id=identifier,input=str(file),expression=case['expression'],requirements=requirements,expected_outcome='failure')
  assert not file.exists();file.write_bytes(case['source'].encode());current['cases'].append(row)
  promoted.append(dict(id=identifier,exploration=str(directory),exploratory_case_id=case['id'],input_sha256=oracle.sha256(file)))
selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
Path('target/m2/stage7-key-span-promotion.json').write_bytes(contract.encoded(dict(selected_count=len(promoted),provenance=promoted,reason='Six exact source-span regressions for the newly added parser token-span metadata: direct/grouped negative numeric keys, spaces, negative zero, and interpolation. Root authorized final selected corpus freeze at 874 cases after resolving the previously exploratory span gap.',original_868_definitions_and_bytes_preserved=True)))
print('Promoted',len(promoted),'total',len(current['cases']))
