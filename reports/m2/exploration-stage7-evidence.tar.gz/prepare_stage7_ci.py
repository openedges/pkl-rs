"""Prepare target-only exact-commit CI evidence helpers without starting CI."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

base=Path('target/m2')
source=base/'ci-stage6'
destination=base/'ci-stage7'
destination.mkdir(exist_ok=False)
names=['capture_process.py','m1_checks.py','monitor_status.py','package.py','test_verify.py','unpack_and_verify.py','verify.py']
source_hashes={}
for name in names:
    payload=(source/name).read_bytes()
    source_hashes[name]=hashlib.sha256(payload).hexdigest()
    text=payload.decode().replace('stage6','stage7')
    (destination/name).write_text(text)

def capture(label, command):
    subprocess.run([sys.executable,str(destination/'capture_process.py'),'--output',str(destination/label),'--',*command],check=True)

capture('self-test',[sys.executable,str(destination/'test_verify.py'),'-v'])
capture('ast-check',[sys.executable,'-c','import ast;from pathlib import Path;p=Path("target/m2/ci-stage7");files=sorted(p.glob("*.py"));[ast.parse(f.read_bytes(),filename=str(f)) for f in files];print(f"Parsed {len(files)} helpers")'])
metadata={
 'schema_version':1,
 'scope':'Target-only M2 stage7 CI verifier preparation; no CI run, status acquisition, artifact acquisition, or compatibility checks executed.',
 'source_directory':str(source), 'destination_directory':str(destination),
 'tracked_files_modified':False,
 'source_files_sha256':source_hashes,
 'files':{name:hashlib.sha256((destination/name).read_bytes()).hexdigest() for name in names},
 'counts_hardcoded_for_previous_stage':False,
 'inspection':{
  'selected_case_counts':'Frozen compatibility/m2-language.json selected adapter entries and captured report status_counts.',
  'language_source_paths':'Frozen m2_language.source_paths over exact Git commit path index.',
  'new_equality_resolver_modules_and_tests':'Included dynamically by Rust *.rs recursive enumeration over the exact committed path set.',
  'm1_cases':'Frozen frontend CASES, Host MODES, runtime SUCCESS_CASES/ERROR_CASES, lifecycle reports, primitive fixture and KNOWN_GAPS.',
  'platform_scenarios':'Frozen m1_platforms.REQUIRED_SCENARIOS.',
  'package_inventory':'Computed after packaging; preserves original GitHub artifact ZIP bytes.',
  'stage7_scope':'Acquisition requires caller-supplied exact implementation commit and run ID; monitoring and acquisition require fresh output directories.'},
 'verifier_unit_tests':{'capture':str(destination/'self-test/process.json'),'command':[sys.executable,str(destination/'test_verify.py'),'-v'],'executed':2,'passed':2,'failed':0,'scope':['Archive traversal/absolute/drive/backslash/symlink rejection.','Artifact corruption, exact commit, incomplete jobs and failed jobs rejection.']},
 'syntax_checks':{'capture':str(destination/'ast-check/process.json'),'parsed_helpers':len(names),'passed':True}}
(destination/'preparation.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n')
print(json.dumps({'directory':str(destination),'helpers':len(names),'self_tests':2,'ci_started':False},sort_keys=True))
