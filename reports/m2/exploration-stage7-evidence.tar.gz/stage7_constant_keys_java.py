from pathlib import Path
import sys, json, concurrent.futures
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out = Path('target/m2/stage7-constant-keys-java-01').resolve()
out.mkdir(exist_ok=False)
metadata = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts'; artifacts.mkdir(); classes=artifacts/'java'; classes.mkdir()
lang.capture([str(Path(metadata['java']).with_name('javac')), '-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment'])
cases=[]
def add(id, source, power=False):
    cases.append(dict(id=id,source=source+'\n',family='structural-key-diagnostics',expected_outcome='observation',expression='result',power_assertions=power))
add('constant-duplicate-unused','unused = new Mapping { [List(1)] = 1; [List(1)] = 2 }\nresult = 42')
add('constant-nested-list-duplicate','m = new Mapping { [List(List(1), null, true)] = 1; [List(List(1), null, true)] = 2 }\nresult = m.length')
add('constant-list-boxed-distinct','m = new Mapping { [List(1)] = 1; [List(1.0)] = 2 }\nresult = m.length')
add('constant-list-zero-distinct','m = new Mapping { [List(0.0)] = 1; [List(-0.0)] = 2 }\nresult = m.length')
add('dynamic-key-defers-duplicates','key = List(2)\nm = new Mapping { [List(1)] = 1; [List(1)] = 2; [key] = 3 }\nresult = m.length')
add('generator-defers-duplicates','m = new Mapping { [List(1)] = 1; [List(1)] = 2; when(false) { [List(2)] = 3 } }\nresult = m.length')
add('shadowed-list-constructor','function List(x) = x + 1\nm = new Mapping { [List(1)] = 1; [List(1)] = 2 }\nresult = m.length')
add('constant-parenthesized-span','m = new Mapping { [(List(1))] = 1; [(List(1))] = 2 }\nresult = m.length')
add('constant-duplicate-negative','m = new Mapping { [List(-1)] = 1; [List(-1)] = 2 }\nresult = m.length')
add('constant-duplicate-long','m = new Mapping { [List("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")] = 1; [List("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")] = 2 }\nresult = m.length')
(out/'matrix.json').write_bytes(contract.encoded(cases))
(out/'source-identities.json').write_bytes(contract.encoded({str(p):oracle.sha256(contract.ROOT/p) for p in ['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']}))
def run(case):
    folder=out/'cases'/case['id']; folder.mkdir(parents=True)
    source=folder/'input.pkl'; source.write_text(case['source'])
    row=lang.capture_java(metadata, artifacts/'language_probe',case['id'],source,case['expression'],folder,case.get('power_assertions',False))
    stdout=(folder/'java.stdout.bin').read_bytes(); stderr=(folder/'java.stderr.bin').read_bytes()
    return dict(id=case['id'],family=case['family'],expected_outcome=case['expected_outcome'],java=row,stdout=stdout.decode(),stderr=stderr.decode(),outcome=(folder/'java.outcome.bin').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
for row in results:
    print(row['id'], row['java']['exit_code'], repr(row['stdout']), repr(row['stderr'][:150]),flush=True)
