from pathlib import Path
import os,json,hashlib,tarfile,subprocess,shutil,re
R=Path.cwd();P=R/'target/m2/stage43-implementation-publication-01';O=R/'target/m2/stage43-publication-review-01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,obj):(O/name).write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n')
selection=json.loads((P/'selection.json').read_text());index=json.loads((R/'reports/m2/stage43-implementation-captures.json').read_text());before=json.loads((P/'inputs.before.json').read_text());after=json.loads((P/'inputs.after.json').read_text());assert before==after
for key in ['roots','files','excludedBeforeTraversal','symlinkRepresentations','scope']:assert selection[key]==index[key],key
excluded={Path(p) for p in selection['excludedBeforeTraversal']};expected={};rootcounts={}
for row in selection['roots']:
 source=Path(row['source']);count=0
 for top,dirs,names in os.walk(source,followlinks=False):
  top=Path(top);dirs[:]=sorted(d for d in dirs if top/d not in excluded)
  assert not any((top/d).is_symlink() for d in dirs),str(top)
  for name in sorted(names):
   path=top/name
   if path in excluded:continue
   assert path.is_file() and not path.is_symlink(),str(path)
   rel=str(Path(row['archivePrefix'])/path.relative_to(source));assert rel not in expected
   expected[rel]={'originalPath':str(path),'bytes':path.stat().st_size,'sha256':sha(path)};count+=1
 rootcounts[row['archivePrefix']]=count
for row in selection['files']:
 path=Path(row['source']);assert path.is_file() and not path.is_symlink();assert row['archivePath'] not in expected
 expected[row['archivePath']]={'originalPath':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}
assert expected==before,{'missing':sorted(set(before)-set(expected)),'extra':sorted(set(expected)-set(before))}
put('original-membership.json',expected);print('original selection verified',len(expected),flush=True)
union={};archives=[]
for item in index['archives']:
 path=R/item['path'];assert path.stat().st_size==item['bytes'];assert sha(path)==item['sha256'];observed={};inner=None
 with tarfile.open(path,'r|gz') as archive:
  for member in archive:
   assert member.isfile() and member.mode==0o644,member.name
   content=archive.extractfile(member);assert content is not None
   if member.name=='EVIDENCE.json':assert inner is None;inner=json.loads(content.read());continue
   assert member.name not in observed and member.name not in union,member.name
   h=hashlib.sha256();size=0
   while block:=content.read(1024*1024):h.update(block);size+=len(block)
   rec={'bytes':size,'sha256':h.hexdigest()};assert rec=={k:expected[member.name][k] for k in ['bytes','sha256']},member.name
   observed[member.name]=rec;union[member.name]=rec
 assert inner is not None;declared={row['path']:{k:row[k] for k in ['bytes','sha256']} for row in inner['files']};assert len(declared)==len(inner['files']);assert declared==observed
 assert len(observed)==item['payloadFiles'];assert sum(x['bytes'] for x in observed.values())==item['payloadBytes'];assert item['verification']['exitCode']==0
 archives.append({**item,'independentPayloadsVerified':len(observed),'membersIncludingEvidence':len(observed)+1,'modes':'0644 representation only'});print(path.name,len(observed),'verified',flush=True)
assert set(union)==set(expected);assert len(union)==index['payloadFiles'];assert sum(x['bytes'] for x in union.values())==index['payloadBytes'];put('archive-membership.json',union)
linkproof=[]
for row in selection['symlinkRepresentations']:
 path=Path(row['originalPath']);raw=os.fsencode(os.readlink(path));assert raw.hex()==row['targetHex'];assert hashlib.sha256(raw).hexdigest()==row['targetSha256'];assert path in excluded
 gitraw=subprocess.check_output(['git','show',row['pinnedReference']+':'+row['referencePath']],cwd=R/'external/pkl');assert gitraw==raw
 prefix=next(x['archivePrefix'] for x in selection['roots'] if path.is_relative_to(Path(x['source'])));origin=next(Path(x['source']) for x in selection['roots'] if x['archivePrefix']==prefix);referent=path.resolve();represented=[name for name in union if name.startswith(str(Path(prefix)/referent.relative_to(origin))+'/')];assert represented
 linkproof.append({**row,'independentGitBlobBytesEqual':True,'includedReferentFiles':len(represented)})
required=R/'target/m2/stage43-required-checks-04';sb=json.loads((required/'sources.before.json').read_text());sa=json.loads((required/'sources.after.json').read_text());assert sb==sa;assert len(sa)==7026
for rel,h in sa.items():assert sha(R/rel)==h,rel;assert sha(required/'sources'/rel)==h,rel
requiredReport=json.loads((required/'report.json').read_text());assert all(x['exit_code']==0 for x in requiredReport['results']);assert len(requiredReport['results'])==5;assert requiredReport['source_stable'];assert requiredReport['harness_invocations']=={'passed':685,'failed':0,'ignored':1,'measured':0,'filtered_out':36}
assert sha(required/'report.json')==sha(R/'reports/m2/stage43-required-checks.json')
candidate=R/'target/m2/stage43-lossless-platform-candidate-02';cb=json.loads((candidate/'comparisons.sources-before.json').read_text());ca=json.loads((candidate/'comparisons.sources-after.json').read_text());assert cb==ca
srcmap={str(Path(p).relative_to(candidate/'workspace')):h for p,h in ca.items() if Path(p).is_relative_to(candidate/'workspace/crates') and '/src/' in p}
assert len(srcmap)==69
for rel,h in srcmap.items():assert sha(R/rel)==h and sha(candidate/'workspace'/rel)==h,rel
standard=json.loads((candidate/'standard02/report.json').read_text());assert standard['source_stability'];assert standard['shared_engine_passed']==6078;assert standard['oracle_passed']==6076
for rel,h in standard['source_hashes'].items():assert sha(candidate/'workspace'/rel)==h,rel
comparison=json.loads((candidate/'comparisons.report.json').read_text());assert comparison['sourceStability'];assert comparison['sourceChanges']==[]
summary=json.loads((candidate/'summary.json').read_text());assert summary==json.loads((R/'reports/m2/stage43-platform-summary.json').read_text());assert summary['vmSha256']==srcmap['crates/pkl-runtime/src/vm.rs']
checkpoint=json.loads((R/'reports/m2/stage43-implementation-checkpoint.json').read_text());assert not checkpoint['fullM2Complete'];assert checkpoint['requiredRustChecks']['sha256']==sha(R/checkpoint['requiredRustChecks']['report']);assert checkpoint['portable']['sha256']==sha(R/checkpoint['portable']['summary']);assert checkpoint['independentReview']['sha256']==sha(R/checkpoint['independentReview']['report'])
# Code review snapshot is historical before adding the final test module; its proof and later negative control are retained separately.
codeReview=json.loads((R/'reports/m2/stage43-code-review.json').read_text());assert codeReview['finding']['correctedSha256']==srcmap['crates/pkl-runtime/src/vm.rs'];assert codeReview['finding']['noObservedApiMismatchClaim']
for rel in ['README.md','PLAN.md','reports/m2/README.md','reports/m2/stage43-implementation-checkpoint.json','reports/m2/stage43-code-review.json','reports/m2/stage43-platform-summary.json','reports/m2/stage43-required-checks.json','reports/m2/stage43-implementation-captures.json']:
 dest=O/'publication-snapshots'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,dest)
for name in ['selection.json','publish.py','inputs.before.json','inputs.after.json','report.json','source-link-01.json']:
 shutil.copyfile(P/name,O/('final-'+name))
put('final-review.json',{'status':'independent bounded archive/source review passed','archiveCount':len(archives),'payloadFiles':len(union),'payloadBytes':sum(x['bytes'] for x in union.values()),'compressedBytes':sum(a['bytes'] for a in archives),'roots':len(selection['roots']),'directFiles':len(selection['files']),'exactExclusionsBeforeTraversal':len(excluded),'rootCounts':rootcounts,'archives':archives,'symlinkRepresentations':linkproof,'requiredSourceRecordsExact':len(sa),'correctedPlatformSrcRecordsExact':len(srcmap),'requiredFiveExitCodes':[x['exit_code'] for x in requiredReport['results']],'requiredHarnessCounts':requiredReport['harness_invocations'],'initialPreflightBlockerResolved':True,'duplicateOrMissingSelectedPaths':[],'originalSourceChanges':[],'knownOutcomesPreserved':['Pre-correction core/portable evidence remains historical','Negative control remains expected101','Known primitive regex failures2','Trace58pass32oracle-error per target','Internal32predicate calls distinct from actual48APIcalls; no inferred API mismatch'],'docsScopeReview':'README/PLAN/reports README distinguish bounded implementation checkpoint, historical UTF8-only fixtures, known Stage44 losses, pending full corpus and open M2; no material overclaim found.','runtimeReruns':0,'scope':'Exact selected path/hash/membership and source bindings only. Prior/full corpus/performance/product compatibility not completed by this audit.'})
print('all final checks passed',len(union),'source',len(sa),'candidate',len(srcmap),flush=True)
