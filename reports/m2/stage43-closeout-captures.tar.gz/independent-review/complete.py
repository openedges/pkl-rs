from pathlib import Path
import json,hashlib,subprocess,shutil,os
R=Path.cwd();O=R/'target/m2/stage43-publication-review-01';P=R/'target/m2/stage43-implementation-publication-01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,v):(O/n).write_text(json.dumps(v,indent=2,ensure_ascii=True)+'\n')
index=json.loads((R/'reports/m2/stage43-implementation-captures.json').read_text());selection=json.loads((P/'selection.json').read_text());expected=json.loads((O/'original-membership.json').read_text());union=json.loads((O/'archive-membership.json').read_text());assert set(union)==set(expected)
assert all(v=={k:expected[p][k] for k in ['bytes','sha256']} for p,v in union.items());assert len(union)==index['payloadFiles']==80907;assert sum(x['bytes'] for x in union.values())==index['payloadBytes']==474836718
initialstderr=(O/'audit.stderr.bin').read_text();assert 'assert len(srcmap)==69' in initialstderr
stdout=(O/'audit.stdout.bin').read_text();assert all(Path(a['path']).name+' '+str(a['payloadFiles'])+' verified' in stdout for a in index['archives']);assert len(index['archives'])==7
required=R/'target/m2/stage43-required-checks-04';requiredMap=json.loads((required/'sources.after.json').read_text());assert len(requiredMap)==7026;assert requiredMap==json.loads((required/'sources.before.json').read_text())
candidate=R/'target/m2/stage43-lossless-platform-candidate-02';standard=json.loads((candidate/'standard02/report.json').read_text());assert standard['source_stability'];assert standard['shared_engine_passed']==6078;assert standard['oracle_passed']=={'rust':6076,'node':6076,'browser':6076}
for rel,h in standard['source_hashes'].items():assert sha(candidate/'workspace'/rel)==h and sha(R/rel)==h,rel
srcmap={rel:h for rel,h in standard['source_hashes'].items() if rel.startswith('crates/pkl-runtime/src/')};assert len(srcmap)==69
cb=json.loads((candidate/'comparisons.sources-before.json').read_text());ca=json.loads((candidate/'comparisons.sources-after.json').read_text());assert cb==ca
runtimeGuard={str(Path(p).relative_to(candidate/'workspace')):h for p,h in ca.items() if Path(p).is_relative_to(candidate/'workspace/crates') and '/src/' in p};assert len(runtimeGuard)==67;assert all(srcmap[p]==h for p,h in runtimeGuard.items())
comparison=json.loads((candidate/'comparisons.report.json').read_text());assert comparison['sourceStability'] and comparison['sourceChanges']==[]
summary=json.loads((candidate/'summary.json').read_text());assert summary==json.loads((R/'reports/m2/stage43-platform-summary.json').read_text());assert summary['vmSha256']==srcmap['crates/pkl-runtime/src/vm.rs']
checkpoint=json.loads((R/'reports/m2/stage43-implementation-checkpoint.json').read_text());assert not checkpoint['fullM2Complete']
for group in ['requiredRustChecks','portable','independentReview']:
 entry=checkpoint[group];path=entry.get('report',entry.get('summary'));assert sha(R/path)==entry['sha256'],group
codeReview=json.loads((R/'reports/m2/stage43-code-review.json').read_text());assert codeReview['finding']['correctedSha256']==srcmap['crates/pkl-runtime/src/vm.rs'];assert codeReview['finding']['noObservedApiMismatchClaim']
requiredReport=json.loads((required/'report.json').read_text());assert requiredReport==json.loads((R/'reports/m2/stage43-required-checks.json').read_text());assert len(requiredReport['results'])==5;assert all(x['exit_code']==0 for x in requiredReport['results']);assert requiredReport['source_stable'];assert requiredReport['harness_invocations']=={'passed':685,'failed':0,'ignored':1,'measured':0,'filtered_out':36}
# Independently read the actual staged objects, without walking target/cache trees.
provided=R/'target/m2/stage43-index-validation-01/sources.json';bound=json.loads(provided.read_text());assert len(bound)==7093
entries={}
for line in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=R).split(b'\0'):
 if not line:continue
 meta,path=line.split(b'\t',1);mode,oid,stage=meta.split();
 if stage==b'0':entries[os.fsdecode(path)]=(mode.decode(),oid.decode())
objects={}
for path,record in bound.items():
 assert entries[path]==(record['gitMode'],record['gitBlob']),path
 assert sha(R/path)==record['sha256'],path
 if record['gitBlob'] in objects:assert objects[record['gitBlob']]==record['sha256']
 else:objects[record['gitBlob']]=record['sha256']
assert len(objects)==4581
proc=subprocess.Popen(['git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for oid,h in objects.items():
 proc.stdin.write((oid+'\n').encode());proc.stdin.flush();header=proc.stdout.readline().decode().split();assert header[0]==oid and header[1]=='blob';size=int(header[2]);data=bytearray()
 while len(data)<size:
  chunk=proc.stdout.read(size-len(data));assert chunk;data.extend(chunk)
 assert proc.stdout.read(1)==b'\n';assert hashlib.sha256(data).hexdigest()==h,oid
proc.stdin.close();assert proc.wait()==0;assert not proc.stderr.read()
for rel,h in requiredMap.items():assert bound[rel]['sha256']==h,rel
for rel,h in standard['source_hashes'].items():assert bound[rel]['sha256']==h,rel
linkproof=[]
for row in selection['symlinkRepresentations']:
 raw=os.fsencode(os.readlink(row['originalPath']));assert raw.hex()==row['targetHex'];assert hashlib.sha256(raw).hexdigest()==row['targetSha256'];assert row['originalPath'] in selection['excludedBeforeTraversal']
 gitraw=subprocess.check_output(['git','show',row['pinnedReference']+':'+row['referencePath']],cwd=R/'external/pkl');assert gitraw==raw
 linkproof.append({**row,'independentPinnedGitBlobBytesMatch':True})
for rel in ['README.md','PLAN.md','reports/m2/README.md','reports/m2/stage43-implementation-checkpoint.json','reports/m2/stage43-code-review.json','reports/m2/stage43-platform-summary.json','reports/m2/stage43-required-checks.json','reports/m2/stage43-implementation-captures.json']:
 dest=O/'publication-snapshots'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,dest)
for name in ['selection.json','publish.py','inputs.before.json','inputs.after.json','report.json','source-link-01.json']:
 shutil.copyfile(P/name,O/('final-'+name))
shutil.copyfile(provided,O/'staged-source-bindings.json')
put('final-review.json',{'status':'independent bounded archive/source review passed','archiveCount':7,'payloadFiles':len(union),'payloadBytes':sum(x['bytes'] for x in union.values()),'compressedBytes':sum(a['bytes'] for a in index['archives']),'roots':len(selection['roots']),'directFiles':len(selection['files']),'exactExclusionsBeforeTraversal':len(selection['excludedBeforeTraversal']),'archives':index['archives'],'archiveProof':'audit.py + original-membership.json + archive-membership.json + audit.stdout.bin; completed before the recorded metadata-assumption failure','initialAuditFailure':{'stage':'Source-map shape assertion after all archives and required source copies verified','reason':'Comparison map has67runtime Rust files; standard147map has69runtime src entries including2embedded stdlib Pkl files, plus2binding source files (71crate-src total). oracle_passed is per-target dict. Both initial count assumptions are retained as tool errors.','impact':'No archive/source integrity failure; all initial logs and script retained. No archive reread or evaluator rerun.'},'symlinkRepresentations':linkproof,'requiredSourceRecordsExact':7026,'requiredCopiesExactInArchivePhase':True,'correctedPlatformBuildRecordsExact':len(standard['source_hashes']),'correctedRuntimeSrcRecordsExact':69,'allCrateSrcRecordsExact':71,'comparisonRuntimeGuardRecordsExact':67,'stagedIndexPathsChecked':7093,'uniqueStagedGitBlobBytesRead':4581,'stagedIndexMismatch':[],'requiredFiveExitCodes':[x['exit_code'] for x in requiredReport['results']],'requiredHarnessCounts':requiredReport['harness_invocations'],'duplicateOrMissingSelectedPaths':[],'originalSourceChanges':[],'modes':'0644 archive representation; original executable modes not claimed','knownOutcomesPreserved':['Pre-correction core/portable evidence remains historical','Negative control expected101','Known primitive regex failures2','Trace58pass32oracle-error per portable target','Internal32predicate calls distinct from actual48APIcalls; no inferred API mismatch'],'docsScopeReview':'README/PLAN/reports README preserve bounded checkpoint, historical UTF8-only comparison boundary, Stage44 gaps, pending full corpus and open M2. No material overclaim found.','runtimeReruns':0,'scope':'Exact selected path/hash/membership/current source+staged object bindings only; no whole-language/product/performance completion.'})
print('final passed',len(union),'payloads',len(standard['source_hashes']),'platformbuild sources',len(bound),'staged paths',len(objects),'actualGitblobs',flush=True)
