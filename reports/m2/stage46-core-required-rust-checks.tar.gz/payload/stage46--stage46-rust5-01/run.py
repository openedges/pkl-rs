from pathlib import Path
import datetime,hashlib,json,os,platform,subprocess,time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
RELEASE=ROOT/'target/m2/stage46-implementation-01/resource-candidate-build-05/release.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def inputs():
 paths=set()
 for prefix in ['', 'external/pkl/','external/pkl-pantry/']:
  listed=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=ROOT/prefix)
  for raw in listed.split(b'\0'):
   if not raw:continue
   name=prefix+raw.decode();p=ROOT/name
   if p.is_file() and not p.is_symlink():paths.add(name)
 return {name:sha(ROOT/name) for name in sorted(paths)}
r=json.loads(RELEASE.read_text());before=inputs();save('source-before.json',before)
assert before==json.loads(Path(r['source_map']).read_text())
env=dict(os.environ,CARGO_TARGET_DIR=str(ROOT/'target/stage46-cargo'),PYTHONDONTWRITEBYTECODE='1')
save('environment.json',{'host':platform.uname()._asdict(),'cargoTargetDir':env['CARGO_TARGET_DIR'],'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'release':str(RELEASE),'releaseSha256':sha(RELEASE)})
commands=[['cargo','xtask','verify'],['cargo','fmt','--all','--','--check'],['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],['cargo','test','--workspace','--locked'],['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked']]
records=[];start=now();tick=time.monotonic()
for i,command in enumerate(commands):
 step=OUT/str(i);step.mkdir();begin=now();clock=time.monotonic()
 with (step/'stdout.bin').open('wb') as stdout,(step/'stderr.bin').open('wb') as stderr:
  process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
  save(f'{i}/launch.json',{'argv':command,'cwd':str(ROOT),'pid':process.pid,'startedUtc':begin})
  code=process.wait()
 record={'argv':command,'cwd':str(ROOT),'pid':process.pid,'startedUtc':begin,'finishedUtc':now(),'elapsedSeconds':time.monotonic()-clock,'exitCode':code,'stdoutSha256':sha(step/'stdout.bin'),'stderrSha256':sha(step/'stderr.bin')}
 records.append(record);save(f'{i}/report.json',record);print(i,code,flush=True)
after=inputs();save('source-after.json',after)
report={'scope':'Required local Rust checks on frozen Stage46 C05. Separate from original-case, actual platform and full M2 compatibility gates.','startedUtc':start,'finishedUtc':now(),'elapsedSeconds':time.monotonic()-tick,'records':records,'allPass':all(r['exitCode']==0 for r in records),'sourceStable':before==after,'sourceCount':len(before),'sourceBeforeSha256':sha(OUT/'source-before.json'),'sourceAfterSha256':sha(OUT/'source-after.json'),'releaseSha256':sha(RELEASE)}
save('report.json',report);print(json.dumps(report,indent=2),flush=True)
raise SystemExit(0 if report['allPass'] and report['sourceStable'] else 1)
