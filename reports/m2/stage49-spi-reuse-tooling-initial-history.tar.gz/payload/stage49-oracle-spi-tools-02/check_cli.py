from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).resolve().parent
G=O.parent/'stage49-oracle-spi-fixtures-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cwd=O/'empty-cwd';cwd.mkdir(exist_ok=False)
command=[sys.executable,'-B',str(O/'modulekey_fixtures.py'),'--fixtures',str(G)]
row={'command':command,'cwd':str(cwd),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixtureManifestSha256Before':sha(G/'manifest.json'),'toolSha256Before':sha(O/'modulekey_fixtures.py')}
with (O/'cli.stdout.bin').open('wb') as out,(O/'cli.stderr.bin').open('wb') as err:
    p=subprocess.Popen(command,cwd=cwd,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=p.pid
    (O/'cli-launch.json').write_text(json.dumps(row,indent=2)+'\n');row['exitCode']=p.wait()
row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha(O/'cli.stdout.bin'),stderrSha256=sha(O/'cli.stderr.bin'),fixtureManifestSha256After=sha(G/'manifest.json'),toolSha256After=sha(O/'modulekey_fixtures.py'))
(O/'cli-terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2));raise SystemExit(row['exitCode'])
