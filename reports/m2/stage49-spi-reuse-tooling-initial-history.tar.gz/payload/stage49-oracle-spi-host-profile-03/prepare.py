from pathlib import Path
import hashlib,json,re,shutil
O=Path(__file__).resolve().parent;B=O.parent;G=B/'stage49-oracle-spi-fixtures-01';V1=B/'stage49-oracle-spi-host-profile-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(G/'manifest.json')=='ebd3591361efc0a03e98e38695b120e9c625d9c09d0438fc641de420114aab97'
assert sha(V1/'host-metadata.json')=='5dbfd67ac3b81584011388fd831b5a000f7eb7f5a218f309aab34fcaeb45a521'
assert sha(G/'provenance/inventory.json')=='11f1dbb9c1fc0b57761075c6ef9bf618210462f9f7ecefe32f02402cc7e41b29'
assert sha(G/'original/AdmissionProbe.java')=='7509222bebfbbea487ae20548671d827a68bff364a7f10e5df30bb9dcd6a6346'
manifest=json.loads((G/'manifest.json').read_bytes())['files'];inventory=json.loads((G/'provenance/inventory.json').read_bytes())['files']
def get(rel):
    p=G/rel;assert sha(p)==manifest[rel]['sha256']and p.stat().st_size==manifest[rel]['bytes'];return p.read_bytes()
helper=get('original/AdmissionProbe.java').decode();rule='if(uri.getScheme().equals("throwing"))throw new IOException("stage48-factory-create");'
assert helper.count(rule)==1 and helper.index(rule)<helper.index('Plan p=plans.get(uri);')
meta=json.loads((V1/'host-metadata.json').read_bytes());meta['schema']=2
for rel,proof in meta['sourceProof'].items():
    source=V1/proof['copy'];assert sha(source)==proof['sha256'];target=O/proof['copy'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
old=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-module-admission-oracle-01')
for rel in ['pkl-core/src/main/java/org/pkl/core/runtime/ModuleResolver.java','pkl-core/src/main/java/org/pkl/core/module/ModuleKeyFactories.java']:
    key='upstream/'+rel;expected=inventory[key];source=old/key;assert sha(source)==expected['sha256'];target=O/key;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
    meta['sourceProof'][rel]={'source':str(source),'sha256':sha(source),'copy':key,'copySha256':sha(target),'authority':'Copied original Java01 pinned inventory entry, not current live implementation.'}
bundle=json.loads(get('fixtures.json'));proofs=[]
for profile in meta['profiles']:
    profile['factoryFailures']=[{'scheme':'throwing','errorKind':'io','message':'stage48-factory-create'}]
    fixtures=[f for f in bundle['fixtures']if f['id']==profile['id']]
    # URI input facts are source literals plus actual registry-call traces, never expected errors.
    literals=set(re.findall(r'\bimport\s*\(?\s*"([^"\n]*)"',fixtures[0]['source']))
    candidates=sorted(uri for uri in literals if uri.startswith('noLoader:'))
    profile['noLoaderUris']=[]
    for uri in candidates:
        traces=[]
        for f in fixtures:
            observed=[(e,get('original/'+e['rawPrefix']+'.bin').decode())for e in f['orderedEvents']]
            custom=[(i,e,text)for i,(e,text)in enumerate(observed)if text=='factory-custom '+uri]
            assert custom
            for start,ce,ct in custom:
                end=next((i for i in range(start+1,len(observed))if observed[i][1].startswith('factory-custom ')),len(observed))
                attempt=observed[start:end];numbers=[]
                for e,text in attempt:
                    match=re.fullmatch(r'factory-(\d+) '+re.escape(uri),text)
                    if match:numbers.append(int(match[1]))
                    assert not(re.fullmatch(r'factory-hit-\d+ '+re.escape(uri)+r'.*',text))
                    assert text!='factory-custom-hit '+uri
                    if match or text==ct:traces.append({'repeat':f['repeat'],'session':f['session'],'rawPrefix':e['rawPrefix'],'utf8Hex':e['utf8Hex'],'utf16BEHex':e['utf16BEHex']})
                assert numbers and numbers==list(range(max(numbers)+1)), 'complete sequential empty registry per actual attempt'
        assert not profile['customModules']
        profile['noLoaderUris'].append(uri)
        proofs.append({'id':profile['id'],'uri':uri,'authoredSource':fixtures[0]['sourcePath'],'authoredSourceSha256':manifest[fixtures[0]['sourcePath']]['sha256'],'sourceLiteralUtf8Hex':('"'+uri+'"').encode().hex(),'actualEmptyFactoryTrace':traces,'noFactoryHitObserved':True,'sourceRule':'Original ModuleResolver iterates configured factories and raises NoLoader only after all Optional.empty. No expected diagnostic/API status was inspected.'})
meta['factoryFailureProof']={'sourcePath':'original/AdmissionProbe.java','sha256':sha(G/'original/AdmissionProbe.java'),'exactRuleUtf8Hex':rule.encode().hex(),'predicate':'URI.getScheme().equals("throwing"), case-sensitive; no URI normalization or expected-message inference.','placement':'Actual select-key callback before configured custom/default selection','originalSourceBinding':'Pinned fixture original helper source, authenticated by literal original inventory.'}
meta['noLoaderProofs']=proofs
meta['scope']+=['Factory failures are actual authored Host IOException inputs; Pkl error text/frame generation remains shared engine responsibility.','NoLoader input is exact URI registry-miss membership from authenticated source literals + actual empty factory trace, only after shared default returns false. Other unconfigured URIs remain acquisition failures.']
(O/'host-metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
(O/'report.json').write_text(json.dumps({'schema':1,'previousSidecarSha256':sha(V1/'host-metadata.json'),'fixtureManifestSha256':sha(G/'manifest.json'),'hostMetadataSha256':sha(O/'host-metadata.json'),'profiles':len(meta['profiles']),'factoryFailureRules':9,'noLoaderUris':{p['id']:p['noLoaderUris']for p in meta['profiles']if p['noLoaderUris']},'newEvaluations':0,'expectedErrorsInspected':False,'scriptSha256':sha(Path(__file__))},indent=2)+'\n')
print(json.dumps(json.loads((O/'report.json').read_bytes()),indent=2))
