# Stage49 원래 SPI 관찰의 소비 계약

`controls.json`은 Java01의 봉인된 report/inventory/closure를 literal SHA로 인증하고 원래 7,233개 경로를 직접 hash 대조하여 구성했다. 원본을 복사하거나 재실행하지 않았다. 먼저 `spi132` 5개 case/132 API/1,488 ordered events(124 success, 8 error), 그다음 `factory80` 4개 case/80 API/760 events(24 success, 56 error)를 구분한다. 원래 C01의 212 미실행 판정을 소급 변경하지 않는다.

## 입력

- case에는 원래 `main.pkl`, `operations.tsv`, `module-plan.tsv`와 모든 source 경로가 있다. 새 consumer는 case의 원래 절대 URI를 유지하고 원래 read-only 경로를 사용한다.
- `moduleProviders`는 Java helper가 사전 구성한 Host 입력이다. requested/selected URI는 기존 helper에서는 같고 resolved URI는 별도다. source는 사전 읽은 text이며 factory.create 안의 I/O가 아니다.
- `cacheMode`는 true/false/dynamic이다. dynamic은 CACHE operation 시점의 값을 **factory가 key를 생성할 때 snapshot**한다. `isCached` getter 요청 때 그 snapshot을 돌려준다. snapshot과 getter 호출 시점을 합치지 않는다.
- operation은 evaluate(source, expression), CACHE on/off, POLICY mode, GC를 원래 순서대로 실행한다. 두 evaluator/session은 별도 cache를 쓰며 같은 JVM 두 session과 fresh JVM repeat 구분을 유지한다.

## 실제 실행 adapter 제안

새 frozen probe는 원래 `stage48_policy_probe`의 configurable fixture CLI/파일 출력 구조를 확장한다. SelectKey는 custom provider를 먼저 조회하고 없으면 shared default helper에 명시 위임한다. custom completion의 opaque key handle은 생성마다 새로 발급하며 `QueryCachePolicy`에서 getter를 기록한다. Resolve는 selected handle에서 resolved handle을 만들고 LoadSource는 해당 resolved handle의 사전 구성 text를 전달한다. URI cache/site cache/정규화/stdlib 분류는 Host가 구현하지 않는다. unknown scheme 및 IOException은 Stage49 공통 factory failure taxonomy로 완료한다.

core의 새 API 이름/구조가 고정되기 전 Python exporter가 Rust request를 추정하지 않는다. A가 typed API를 전달하면 B는 target-only exporter/admission/strict compare를 준비하며 A/root가 compile한 frozen artifact만 실행한다. Python 측 예상치는 `observations.calls`의 status, UTF16BE, JavaUTF8, raw counters를 직접 소비한다. `observations.sessions.events`는 순서 있는 전체 원문이며 request projection과 별도 gate다. Java implementation-class label을 실제 Rust 이벤트처럼 합성하지 않는다.

## 종료 조건과 남은 범위

raw API gate, 실제 typed request/handle/token gate, Java full event/counter gate를 각각 기록한다. primary/repl lifecycle이 없으면 full gate는 그대로 failed/unexecuted다. JVM별 singleton 수명·factory close·custom URI equality·import* 및 취소/reentry는 이 212개만으로 닫히지 않는다. 실제 native 실행이 없는 현재 문서는 통과 주장 없이 source/consumer 제안만 제공한다.
