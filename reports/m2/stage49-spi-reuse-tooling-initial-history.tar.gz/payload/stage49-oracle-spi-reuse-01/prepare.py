from pathlib import Path
import collections, hashlib, json

O = Path(__file__).resolve().parent
J = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-module-admission-oracle-01')
PINS = {'report.json': 'dcaa95e8eab8b1a7efda01d2494758d44e5045abe7c75eb79224e0079d768efc', 'inventory.json': '11f1dbb9c1fc0b57761075c6ef9bf618210462f9f7ecefe32f02402cc7e41b29', 'closure.json': '40750b468c747e60b09f35ede8839983edd5400883b8731a2a2f85f3d173fcfd'}
FIRST = {'custom-resolved-importer', 'resolved-cache-alias-no-original-seed', 'uncached-policy-toggle', 'custom-key-pkl-uri-not-stdlib-kind', 'resolved-nested-jar-default-trust'}
NEXT = {'clause-unused-no-loader', 'expr-unused-no-loader', 'clause-unused-factory-throw', 'expr-unused-factory-throw'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, obj):
    (O / name).write_text(json.dumps(obj, indent=2) + '\n')
for rel, expected in PINS.items():
    assert sha(J / rel) == expected, rel
inventory = json.loads((J / 'inventory.json').read_bytes())['files']
report = json.loads((J / 'report.json').read_bytes())
declared = json.loads((J / 'cases.json').read_bytes())
selected = {}
def bind(rel):
    row = inventory[rel]
    p = J / rel
    assert row['kind'] == 'regular' and not p.is_symlink() and p.is_file(), rel
    assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], rel
    selected[rel] = row
for rel in ['AdmissionProbe.java', 'cases.json', 'profile.json', 'outer-terminal.json']:
    bind(rel)
cases = []
for case in declared:
    if case['id'] not in FIRST | NEXT:
        continue
    for rel in case['inputPaths']:
        bind(str((Path(case['workspace']) / rel).relative_to(J)))
    observations = [r for r in report['observations'] if r['case'] == case['id']]
    records = [r for r in report['records'] if r['case'] == case['id']]
    for obs in observations:
        prefix = f"cases/{case['id']}/{obs['repeat']}/"
        for rel in inventory:
            if rel.startswith(prefix):
                bind(rel)
        for call in obs['calls']:
            raw = J / call['rawPrefix']
            for channel in ['stdout', 'stderr']:
                assert raw.with_name(raw.name + '.' + channel + '.bin').read_bytes().hex() == call[channel + 'Utf8Hex']
                assert raw.with_name(raw.name + '.' + channel + '.code-units.bin').read_bytes().hex() == call[channel + 'Utf16BEHex']
            for suffix, field in [('status.bin', 'status'), ('counters-before.bin', 'countersBefore'), ('counters-after.bin', 'countersAfter')]:
                assert raw.with_name(raw.name + '.' + suffix).read_bytes() == call[field].encode(), (case['id'], call['index'], field)
        for session in obs['sessions']:
            event_bytes = b''
            for event in session['events']:
                p = J / event['rawPrefix']
                assert p.with_name(p.name + '.bin').read_bytes().hex() == event['utf8Hex']
                assert p.with_name(p.name + '.code-units.bin').read_bytes().hex() == event['utf16BEHex']
                event_bytes += bytes.fromhex(event['utf8Hex']) + b'\n'
            assert int(dict(line.split('=', 1) for line in session['counters'].splitlines())['event']) == len(session['events'])
    plan = (Path(case['workspace']) / 'module-plan.tsv').read_text()
    providers = [dict(zip(['requestedUri', 'selectedUri', 'resolvedUri', 'sourcePath', 'cacheMode'], [f[0], f[0], f[1], f[2], f[3]])) for line in plan.splitlines() if (f := line.split('\t')) and line]
    cases.append({'case': case, 'cohort': 'spi132' if case['id'] in FIRST else 'factory80', 'moduleProviders': providers, 'observations': observations, 'processes': records})
summary = {}
for cohort in ['spi132', 'factory80']:
    rows = [c for c in cases if c['cohort'] == cohort]
    calls = [v for c in rows for obs in c['observations'] for v in obs['calls']]
    summary[cohort] = {'cases': len(rows), 'apiCalls': len(calls), 'statuses': dict(collections.Counter(v['status'] for v in calls)), 'orderedEvents': sum(len(s['events']) for c in rows for obs in c['observations'] for s in obs['sessions'])}
assert summary['spi132']['apiCalls'] == 132 and summary['factory80']['apiCalls'] == 80
write('controls.json', {'schema': 1, 'oracleRoot': str(J), 'pins': PINS, 'summary': summary, 'cases': cases, 'scope': 'Existing original Java observations only. No evaluation or native compatibility result. Preserve all full events/counters, including primary/repl and implementation-class labels; no synthetic Rust events. The old C01 212 unexecuted status is unchanged.'})
write('source-bindings.json', {'oracleRoot': str(J), 'pins': PINS, 'files': selected})
write('report.json', {'schema': 1, 'kind': 'read-only authenticated reuse', 'summary': summary, 'authenticatedFiles': len(selected), 'authenticatedBytes': sum(r['bytes'] for r in selected.values()), 'newJavaExecutions': 0, 'nativeExecutions': 0, 'changesToOriginal': 0, 'outputs': {n: sha(O / n) for n in ['controls.json', 'source-bindings.json', 'prepare.py']}})
print(json.dumps(json.loads((O / 'report.json').read_bytes()), indent=2))
