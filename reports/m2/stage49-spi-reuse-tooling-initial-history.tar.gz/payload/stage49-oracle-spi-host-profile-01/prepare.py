"""Bounded source-derived Host metadata; never Java expected output or events."""
from pathlib import Path
import hashlib, importlib.util, json, shutil
O=Path(__file__).resolve().parent;R=O.parents[2]
G=O.parent/'stage49-oracle-spi-fixtures-01';T=O.parent/'stage49-oracle-spi-tools-01/modulekey_fixtures.py'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(G/'manifest.json')=='ebd3591361efc0a03e98e38695b120e9c625d9c09d0438fc641de420114aab97'
assert sha(T)=='14b95a5cf0b9268b7072a0070d1b2f289c00f67c8212ca0b5ace3aa5174306c8'
spec=importlib.util.spec_from_file_location('fixtures',T);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
proof=m.verify(G);bundle=json.loads((G/'fixtures.json').read_bytes());declared=json.loads((G/'original/cases.json').read_bytes());manifest=json.loads((G/'manifest.json').read_bytes())['files']
source_proofs={}
for rel in ['pkl-core/src/main/java/org/pkl/core/util/IoUtils.java','pkl-core/src/main/java/org/pkl/core/module/ModuleKeys.java','pkl-core/src/main/java/org/pkl/core/module/ModuleKey.java','pkl-core/src/main/java/org/pkl/core/runtime/ReaderBase.java','pkl-core/src/main/java/org/pkl/core/runtime/ModuleCache.java']:
    src=R/'external/pkl'/rel;dst=O/'upstream'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    source_proofs[rel]={'source':str(src),'sha256':sha(src),'copy':'upstream/'+rel,'copySha256':sha(dst)}
profiles=[]
for c in declared:
    selected=[f for f in bundle['fixtures'] if f['id']==c['id']]
    if not selected:continue
    f=selected[0];custom=[]
    for p in f['moduleProviders']:
        uri=p['selectedUri']
        # Deliberately bounded to the literal old helper URIs, not a new general resolver.
        assert uri=='pkl:base' or uri.startswith('memo:/') and uri.endswith('.pkl')
        inferred='base' if uri=='pkl:base' else uri.rsplit('/',1)[1][:-4]
        custom.append({**p,'sourceUri':uri,'inferredName':inferred,'local':True,'hierarchical':True,'fragmentPaths':False,'isGlobbable':False,'metadataProvenance':'Source-derived old PlannedKey contract plus pinned IoUtils.inferModuleName, NOT directly observed Java name/getter output; no expected bytes/events changed.'})
    files=[]
    for rel in c['inputPaths']:
        if not rel.endswith('.pkl'):continue
        payload='original/workspace/'+c['id']+'/'+rel;b=(G/payload).read_bytes();assert sha(G/payload)==manifest[payload]['sha256']
        original=Path(c['workspace'])/rel
        assert original.is_file() and not original.is_symlink() and original.read_bytes()==b
        uri=original.as_uri();resolved=original.resolve(strict=True).as_uri()
        files.append({'requestedUri':uri,'selectedUri':uri,'resolvedUri':resolved,'sourceUri':uri,'sourceText':b.decode(),'inferredName':Path(rel).stem,'sourcePath':payload,'sourceSha256':sha(G/payload),'originalAbsolutePath':str(original),'local':True,'hierarchical':True,'fragmentPaths':False,'isGlobbable':True,'isCached':True,'metadataProvenance':'Source-derived pinned ModuleKeys.File/getOriginal and IoUtils.inferModuleName; physical declared regular input realpath, NOT a synthetic Java callback or observed expected event.'})
    profiles.append({'id':c['id'],'customModules':custom,'fileModules':files,'factoryIOExceptionScheme':'throwing','factoryIOExceptionMessage':'stage48-factory-create','noLoaderScheme':'noLoader','profile':'Original Java helper custom-first registry; all unlisted custom requests delegate shared default explicitly. No Host semantic URI/site cache.'})
result={'schema':1,'fixtureManifestSha256':proof['manifestSha256'],'fixtureVerifierSha256':sha(T),'sourceProof':source_proofs,'profiles':profiles,'scope':['Additional Host source/configuration metadata only; Java expected API channels/events/counters remain unchanged.','No primary/repl/factory/default implementation-class events fabricated.','ModuleName inference is a bounded source specialization for this old input set, not a general URI parser/resolver.','Physical file bindings enumerate original declared source files only; no cache/source tree traversal or network.']}
(O/'host-metadata.json').write_text(json.dumps(result,indent=2)+'\n')
(O/'report.json').write_text(json.dumps({'schema':1,'profiles':len(profiles),'customModules':sum(len(p['customModules'])for p in profiles),'fileModules':sum(len(p['fileModules'])for p in profiles),'fixtureProof':proof,'hostMetadataSha256':sha(O/'host-metadata.json'),'newEvaluations':0,'sourceProof':source_proofs},indent=2)+'\n')
print(json.dumps({'hostMetadataSha256':sha(O/'host-metadata.json'),'profiles':len(profiles),'newEvaluations':0}))
