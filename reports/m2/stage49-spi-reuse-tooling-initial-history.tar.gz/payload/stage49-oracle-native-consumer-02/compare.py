"""Explicit frozen first-boundary native comparison; never builds or invokes Java."""
from pathlib import Path
import argparse, datetime, hashlib, json, os, subprocess, sys
import prepare_inputs as fixtures
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def check(ok,msg):
    if not ok:raise ValueError(msg)
def admit(config,inputs):
    check(sha(O/'prepare_inputs.py')==config['prepareSha256'],'exact input exporter source')
    check(sha(fixtures.TOOL)==config['verifierSha256'],'exact transitive fixture verifier')
    proof=fixtures.verify(inputs)
    build=Path(config['buildRoot'])
    for rel,h in config['buildPins'].items():check(sha(build/rel)==h,'explicit frozen build input '+rel)
    r=json.loads((build/'build.json').read_bytes())
    check(r['exitCode']==0 and r['sourceStable'] and r['sourceCount']==222,'actual successful stable isolated build')
    check((build/'sources-before.json').read_bytes()==(build/'sources-after.json').read_bytes(),'build source maps byte equality')
    mapping=json.loads((build/'sources-after.json').read_bytes())
    check(len(mapping)==222,'declared complete relevant source map')
    for rel,h in mapping.items():check(sha(build/'sources'/rel)==h,'exact frozen source snapshot '+rel)
    binary=Path(r['artifact']);check(sha(binary)==r['artifactSha256']==config['artifactSha256'],'exact admitted frozen binary')
    bundle=json.loads((inputs/'inputs.json').read_bytes())
    original_sources={}
    for c in bundle['cases']:
        for p in c['moduleProviders']:
            path=Path(p['originalAbsoluteSource']);check(path.read_bytes()==p['sourceText'].encode(),'actual preloaded Host source matches Java input');original_sources[str(path)]=sha(path)
    return proof,binary,bundle,original_sources
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',type=Path,required=True);parser.add_argument('--config-sha256',required=True);parser.add_argument('--inputs',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);parser.add_argument('--execute',action='store_true');a=parser.parse_args();a.config=a.config.resolve();a.inputs=a.inputs.resolve();a.output=a.output.resolve()
    check(sha(a.config)==a.config_sha256,'explicit consumer config pin');config=json.loads(a.config.read_bytes())
    check(not a.output.exists(),'fresh output root required');a.output.mkdir(parents=True)
    proof,binary,bundle,sources=admit(config,a.inputs)
    toolpins={n:sha(O/n) for n in ['compare.py','prepare_inputs.py','config.json']}
    write(a.output/'preflight.json',{'config':config,'configSha256':a.config_sha256,'inputs':str(a.inputs),'inputProof':proof,'actualBuildScope':'Frozen relevant222 source capture; not a full Git checkout capture. Actual cargo build source stability is producer-declared and independently byte-rechecked.','toolPins':toolpins,'originalProviderSources':sources,'execute':a.execute})
    if not a.execute:return 0
    records=[];unexecuted=[]
    for case in bundle['cases']:
        if not case['runnableAtFirstBoundary']:
            unexecuted.append({'key':case['key'],'apis':case['rawApiCount'],'reason':case['unexecutedReason']});continue
        target=a.output/case['key'];target.mkdir(parents=True)
        command=[str(binary),str(a.inputs/case['sourceFile']),case['uri'],case['moduleName'],str(a.inputs/case['operationsFile']),str(target/'raw'),'1',case['initialPolicy'],str(a.inputs/'causes.tsv'),bundle['profile'],str(a.inputs/case['modulePlanFile'])]
        process={'key':case['key'],'command':command,'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'TZ':'UTC','LANG':'C','LC_ALL':'C'}}
        with (target/'stdout.bin').open('wb') as out,(target/'stderr.bin').open('wb') as err:
            proc=subprocess.Popen(command,cwd=O,env={**os.environ,**process['environment']},stdout=out,stderr=err);process['pid']=proc.pid;write(target/'launch.json',process)
            try:process['exitCode']=proc.wait(timeout=120);process['timedOut']=False
            except subprocess.TimeoutExpired:proc.kill();process['exitCode']=proc.wait();process['timedOut']=True
        process.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha(target/'stdout.bin'),stderrSha256=sha(target/'stderr.bin'));write(target/'terminal.json',process)
        raw=target/'raw/session-0';outcomes=[]
        for index,e in enumerate(case['expected']):
            checks={};missing=[]
            expected={'status.bin':bytes.fromhex(e['statusRawHex'])}
            for channel in ['stdout','stderr']:
                expected[channel+'.bin']=bytes.fromhex(e[channel+'Hex']);expected[channel+'.code-units.bin']=b''.join(u.to_bytes(2,'big') for u in e[channel+'Units'])
            for suffix,b in expected.items():
                p=raw/f'outer-{index}.{suffix}'
                if p.is_file():checks[suffix]=p.read_bytes()==b
                else:missing.append(suffix)
            outcomes.append({'index':index,'expression':case['expressions'][index],'missing':missing,'checks':checks,'pass':not missing and all(checks.values())})
        native_events=[];i=0
        while (raw/f'event-{i}.text.bin').is_file():native_events.append((raw/f'event-{i}.text.bin').read_bytes().hex());i+=1
        full_events=native_events==[e['utf8Hex'] for e in case['orderedEvents']]
        full_counters=all((p:=raw/f'outer-{i}.counters-{when.lower()}.bin').is_file() and p.read_bytes().hex()==e['counterBytes'+when+'Hex'] for i,e in enumerate(case['expected']) for when in ['Before','After'])
        row={'process':process,'api':outcomes,'rawApiPass':sum(v['pass'] for v in outcomes),'rawApiMismatchOrMissing':sum(not v['pass'] for v in outcomes),'fullEventBytesEqual':full_events,'fullCounterBytesEqual':full_counters,'fullLifecyclePass':full_events and full_counters,'nativeTerminalSlots':(raw/'terminal-slots.bin').read_text() if (raw/'terminal-slots.bin').is_file() else None,'nativeEvents':native_events}
        write(target/'comparison.json',row);records.append(row);write(a.output/'progress.json',{'completedProcesses':len(records),'lastCase':case['key']})
    after,_,_,sources_after=admit(config,a.inputs)
    stable=toolpins=={n:sha(O/n) for n in toolpins} and sources==sources_after
    report={'scope':'Original SPI132 raw API first boundary only; remaining factory80 unexecuted. Full primary/repl/factory/security event and counter bytes stay a distinct strict gate; no synthetic events.','records':records,'rawApiPass':sum(r['rawApiPass'] for r in records),'rawApiMismatchOrMissing':sum(r['rawApiMismatchOrMissing'] for r in records),'unexecuted':unexecuted,'unexecutedApiCalls':sum(r['apis'] for r in unexecuted),'fullLifecyclePassSessions':sum(r['fullLifecyclePass'] for r in records),'fullLifecycleFailSessions':sum(not r['fullLifecyclePass'] for r in records),'inputProofAfter':after,'inputsAndToolsStable':stable,'allProcessesTerminal':True,'liveHandles':[]}
    write(a.output/'report.json',report)
    return 0 if stable and all(r['process']['exitCode']==0 and not r['process']['timedOut'] for r in records) else 1
if __name__=='__main__':raise SystemExit(main())
