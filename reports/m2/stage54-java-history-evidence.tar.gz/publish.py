#!/usr/bin/env python3
"""Publish unchanged Java history only; no evaluation, Git operation or candidate capture."""
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import sys
import tarfile

ROOT = Path.cwd().resolve()
PUBLICATION = ROOT / 'target/m2/stage54-java-history-publication-01'
ARCHIVE = ROOT / 'reports/m2/stage54-java-history-evidence.tar.gz'
COHORTS = [
    ('stage54-deprecation-oracle-01', 'Initial 39-session Java acquisition; original generator syntax and other failed authoring observations remain unchanged.'),
    ('stage54-deprecation-oracle-02', 'Corrected 41-session Java acquisition; original API/internal failures remain unchanged.'),
    ('stage54-deprecation-oracle-03', '45-session Java acquisition including receiver-class callback reentry controls.'),
    ('stage54-deprecation-object-local-01', 'Original failed object-annotation syntax and amended-local direct-query authoring controls.'),
    ('stage54-deprecation-amends-local-01', 'Follow-up amended-local output.text observation; separate from failed original controls.'),
    ('stage54-boundary-oracle-01', 'All 22 supplemental Java close/transformer boundary runs, with their frozen drivers, sources and raw failures.'),
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(data):
    return dict(sha256=sha(data), bytes=len(data))


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode()


def file_set(records):
    return sha(json.dumps(records, sort_keys=True, separators=(',', ':')).encode())


def tree(root):
    require(root.is_dir() and not root.is_symlink(), 'invalid acquisition root')
    result = {}
    for folder, directories, names in os.walk(root, followlinks=False):
        for name in directories + names:
            require(not (Path(folder) / name).is_symlink(), 'acquisition contains a symlink')
        for name in names:
            path = Path(folder) / name
            require(path.is_file(), 'nonregular acquisition entry')
            relative = path.relative_to(root).as_posix()
            result[relative] = record(path.read_bytes())
    return dict(sorted(result.items()))


def oracle_identity(metadata):
    require(metadata['version'] == '0.32.0'
            and metadata['source']['revision'] == 'e51fb2f91774265666f94980ec630db794a4db2d'
            and metadata['artifact_sha256'] == 'c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059'
            and '-Xms64m' in metadata['command'] and '-Xmx512m' in metadata['command'],
            'Java oracle or heap conditions differ')


def main():
    require(not ARCHIVE.exists() and not (PUBLICATION / 'manifest.json').exists(), 'publication output already exists')
    sys.path.insert(0, str(ROOT / 'tools'))
    import deprecation_fixtures
    import m2_deprecation

    fixture = ROOT / 'tests/fixtures/m2-deprecation'
    fixture_verification = deprecation_fixtures.verify(fixture)
    fixture_archive = fixture / 'oracle-evidence.tar.gz'
    omissions = []
    fixture_data = {}
    with tarfile.open(fixture_archive, 'r:gz') as stream:
        entries = stream.getmembers()
        names = [entry.name for entry in entries]
        require(len(names) == len(set(names)), 'duplicate fixture archive path')
        for entry in entries:
            name = PurePosixPath(entry.name)
            require(not name.is_absolute() and '..' not in name.parts and (entry.isfile() or entry.isdir()), 'unsafe fixture archive path')
            if entry.isfile():
                fixture_data[entry.name] = stream.extractfile(entry).read()
    for name, prefix in [('stage54-deprecation-oracle-04', 'main'), ('stage54-deprecation-cycles-oracle-01', 'cycles')]:
        source = ROOT / 'target/m2' / name
        records = tree(source)
        archived = {member.removeprefix(prefix + '/'): data for member, data in fixture_data.items() if member.startswith(prefix + '/')}
        require(set(records) == set(archived), 'omitted final authority file sets differ: ' + name)
        for member, data in archived.items():
            require((source / member).read_bytes() == data, 'omitted final authority bytes differ: ' + name + '/' + member)
        omissions.append(dict(source='target/m2/' + name, archive_prefix=prefix, files=records,
                              file_set_sha256=file_set(records), every_file_raw_equal=True))

    payloads, cohorts, before = {}, [], {}
    for name, scope in COHORTS:
        relative = 'target/m2/' + name
        source = ROOT / relative
        records = tree(source)
        before[relative] = records
        for member, identity in records.items():
            require(not member.endswith(('.rs', '.wasm', '.node')) and 'candidate-trace' not in member,
                    'candidate/Rust artifact outside Java history scope')
            path = 'evidence/' + relative + '/' + member
            require(path not in payloads, 'duplicate selected payload path')
            payloads[path] = dict(identity)
        metadata = json.loads((source / 'oracle.json').read_bytes())
        oracle_identity(metadata)
        statuses = {}
        for path in source.rglob('*.status.bin'):
            status = path.read_bytes().decode('ascii')
            statuses[status] = statuses.get(status, 0) + 1
        cohort = dict(source=relative, scope=scope, files=len(records), bytes=sum(row['bytes'] for row in records.values()),
                      file_set_sha256=file_set(records), raw_public_call_statuses=statuses)
        report = json.loads((source / 'report.json').read_bytes())
        if name in {row[0] for row in COHORTS[:3]}:
            checked = m2_deprecation.verify_report(source)
            cohort.update(java_runs=len(checked['results']), sessions=len(checked['cases']),
                          fresh_process_repeat_pairs_raw_equal=sum(checked['replay_equal'].values()),
                          original_report_integrity_verified=True)
        elif name == 'stage54-boundary-oracle-01':
            require(len(report['results']) == 22 and len(report['cases']) == 11,
                    'supplemental boundary run coverage differs')
            require([(row['id'], row['repeat']) for row in report['results']]
                    == [(case['id'], repeat) for case in report['cases'] for repeat in range(2)],
                    'supplemental boundary selection differs')
            for member, identity in report['files'].items():
                require(records[member] == identity, 'supplemental report member differs')
            seal = json.loads((source / 'seal.json').read_bytes())
            require(seal['files'] == {key: value for key, value in records.items() if key != 'seal.json'}, 'supplemental seal coverage differs')
            audit = json.loads((source / 'audit.json').read_bytes())
            require(audit['report_sha256'] == sha((source / 'report.json').read_bytes())
                    and audit['runs'] == 22 and audit['all_raw_repeat_pairs_equal'] is True,
                    'supplemental audit differs')
            require(report['sources_before'] == report['sources_after'], 'supplemental sources changed')
            for member, digest in report['sources_before'].items():
                require(sha((source / 'sources' / member).read_bytes()) == digest, 'supplemental source snapshot differs')
            driver = report['frozen_driver']
            require(driver['report_sha256'] == sha(fixture_data['main/report.json'])
                    and driver['source_sha256'] == sha(fixture_data['main/sources/tools/java/M2DeprecationProbe.java']),
                    'supplemental frozen driver reference differs')
            for member, digest in driver['classes'].items():
                require(sha((source / 'frozen-classes' / member).read_bytes()) == digest
                        and sha(fixture_data['main/classes/' + member]) == digest, 'supplemental frozen driver class differs')
            for row in report['results']:
                directory = source / 'cases' / row['id'] / str(row['repeat'])
                require(json.loads((directory / 'process/result.json').read_bytes()) == row['process'], 'supplemental process identity differs')
                require(row['process']['status'] == 'executed' and row['process']['exit_code'] == 0, 'supplemental process was not executed')
                for channel in ['stdout', 'stderr']:
                    require(record((directory / 'process' / (channel + '.bin')).read_bytes())
                            == {key: row['process'][channel][key] for key in ['sha256', 'bytes']}, 'supplemental process bytes differ')
            cohort.update(java_runs=22, sessions=11, original_report_integrity_verified=True,
                          source_hashes_stable=True, frozen_driver_bound_to_omitted_fixture=True)
        else:
            cohort.update(java_runs=2 if name.endswith('object-local-01') else 1,
                          original_raw_exploration_preserved=True,
                          borrowed_driver='target/m2/stage54-deprecation-oracle-02/classes (included unchanged)')
        cohorts.append(cohort)
    historical_count = len(payloads)
    for name in ['README.md', 'verify.py', 'publish.py']:
        payloads[name] = record((PUBLICATION / name).read_bytes())
    payloads = dict(sorted(payloads.items()))
    manifest = dict(schema=1, scope='Unchanged Java-only Stage54 acquisition history and supplemental boundary observations; no candidate, Rust or validation packet.',
        oracle_baseline='Pkl 0.32.0', cohorts=cohorts, historical_payload_files=historical_count,
        compatibility_passes_claimed=0, files=payloads, payload_file_set_sha256=file_set(payloads),
        omitted_duplicate_authority=dict(path='tests/fixtures/m2-deprecation/oracle-evidence.tar.gz',
            archive=record(fixture_archive.read_bytes()), verification=fixture_verification, cohorts=omissions,
            reason='Final main04 and sequential evaluator cycles are already fully preserved by the committed independent fixture authority. Every local file and complete file set were compared directly to that archive before deduplication.'),
        boundaries=['Historical authoring failures are retained without substitution or promotion.',
            'All original paths, commands, runtime/heap identities, source bytes and raw outcomes remain unchanged.',
            'Java internal errors and API exceptions remain observations, never compatibility passes.',
            'Candidate/native/portable/Rust/validation publications are owned and sealed separately.',
            'No Git operation, reference update, Java evaluation or production file edit was performed.'])
    (PUBLICATION / 'manifest.json').write_bytes(encoded(manifest))
    ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
    with ARCHIVE.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as stream:
                for name in ['manifest.json', *payloads]:
                    source = PUBLICATION / name if not name.startswith('evidence/') else ROOT / name.removeprefix('evidence/')
                    data = source.read_bytes()
                    if name != 'manifest.json':
                        require(record(data) == payloads[name], 'payload changed before archiving')
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    stream.addfile(info, io.BytesIO(data))
    for relative, records in before.items():
        require(tree(ROOT / relative) == records, 'original acquisition changed during publication')
    for cohort in omissions:
        require(tree(ROOT / cohort['source']) == cohort['files'], 'omitted authority source changed during publication')
    specification = importlib.util.spec_from_file_location('history_verify', PUBLICATION / 'verify.py')
    verifier = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(verifier)
    result = verifier.verify(ARCHIVE, fixture_archive)
    result.update(original_sources_unchanged=True, final_authority_duplicates_omitted=True,
                  historical_java_runs=sum(row['java_runs'] for row in cohorts))
    (PUBLICATION / 'report.json').write_bytes(encoded(result))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
