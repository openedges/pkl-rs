# Stage54 Java history publication

This archive preserves the unchanged initial Java acquisitions `-01`, `-02`,
and `-03`, both object-local/amended-local exploratory directories, and all 22
supplemental boundary runs. Failed authoring inputs, Java internal errors, API
exceptions, original commands, source snapshots and raw bytes remain intact.
It contains no native or portable candidate, Rust or validation publication.

The final main `-04` matrix and sequential evaluator cycles are already preserved
in the committed independent Java fixture archive. They are not duplicated.
Before publication, every local file and the complete file sets were compared
directly with that archive; the manifest preserves the SHA-256 and size of every
omitted file and identifies its existing archive member.

`manifest.json` lists every payload member's SHA-256 and size. The standalone
verifier rejects unsafe paths, nonregular members, duplicates, missing/extra
members, altered bytes and mismatched final fixture authority. It reads archives
without extracting them or executing Java. From the project root:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 target/m2/stage54-java-history-publication-01/verify.py \
  reports/m2/stage54-java-history-evidence.tar.gz \
  --fixture-archive tests/fixtures/m2-deprecation/oracle-evidence.tar.gz
```

Without `--fixture-archive`, historical payload integrity is checked but omitted
fixture integrity is explicitly unverified. No comparison in this publication
claims Rust compatibility or completion of language, API or performance goals.
