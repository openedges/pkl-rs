#!/usr/bin/env python3
"""Read-only SHA/size, membership and omission audit for the Java history archive."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return dict(sha256=sha(data), bytes=len(data))


def file_set(records):
    return sha(json.dumps(records, sort_keys=True, separators=(',', ':')).encode())


def members(stream, allow_directories=False):
    entries = stream.getmembers()
    names = [entry.name for entry in entries]
    require(len(names) == len(set(names)), 'duplicate archive member')
    result = {}
    for entry in entries:
        name = PurePosixPath(entry.name)
        require(str(name) == entry.name and not name.is_absolute() and '..' not in name.parts,
                'unsafe archive path')
        require(entry.isfile() or allow_directories and entry.isdir(), 'nonregular archive member')
        if entry.isfile():
            result[entry.name] = entry
    return result


def verify(archive, fixture_archive=None):
    archive = Path(archive)
    with tarfile.open(archive, 'r:gz') as stream:
        entries = members(stream)
        require('manifest.json' in entries, 'history manifest missing')
        manifest_bytes = stream.extractfile(entries['manifest.json']).read()
        manifest = json.loads(manifest_bytes)
        require(manifest['schema'] == 1 and manifest['compatibility_passes_claimed'] == 0,
                'unsupported history manifest')
        records = manifest['files']
        require(set(entries) == set(records) | {'manifest.json'}, 'history archive file set differs')
        for name, record in records.items():
            require(identity(stream.extractfile(entries[name]).read()) == record,
                    'history member SHA/size differs: ' + name)
        require(manifest['payload_file_set_sha256'] == file_set(records), 'payload file-set digest differs')
        historical = 0
        for cohort in manifest['cohorts']:
            prefix = 'evidence/' + cohort['source'] + '/'
            selected = {name.removeprefix(prefix): record for name, record in records.items() if name.startswith(prefix)}
            require(len(selected) == cohort['files'] and file_set(selected) == cohort['file_set_sha256'],
                    'historical cohort coverage differs')
            historical += len(selected)
        require(historical == manifest['historical_payload_files'], 'historical payload count differs')
        omissions = manifest['omitted_duplicate_authority']
        omitted_verified = False
        if fixture_archive is not None:
            fixture_archive = Path(fixture_archive)
            require(identity(fixture_archive.read_bytes()) == omissions['archive'], 'committed fixture archive identity differs')
            with tarfile.open(fixture_archive, 'r:gz') as fixture:
                fixture_entries = members(fixture, allow_directories=True)
                for cohort in omissions['cohorts']:
                    prefix = cohort['archive_prefix'] + '/'
                    names = {name.removeprefix(prefix): entry for name, entry in fixture_entries.items() if name.startswith(prefix)}
                    require(set(names) == set(cohort['files']), 'omitted fixture file set differs')
                    for name, entry in names.items():
                        require(identity(fixture.extractfile(entry).read()) == cohort['files'][name],
                                'omitted fixture member SHA/size differs: ' + name)
                    require(file_set(cohort['files']) == cohort['file_set_sha256'], 'omitted fixture file-set digest differs')
            omitted_verified = True
    return dict(schema=1, archive=str(archive), archive_sha256=sha(archive.read_bytes()),
                archive_bytes=archive.stat().st_size, archive_members=len(entries),
                payload_members=len(records), historical_payload_files=historical,
                payload_bytes=sum(row['bytes'] for row in records.values()),
                manifest_sha256=sha(manifest_bytes), historical_integrity_verified=True,
                omitted_fixture_integrity_verified=omitted_verified,
                omitted_fixture_files=sum(len(row['files']) for row in omissions['cohorts']),
                duplicate_members=False, safe_regular_member_paths=True, compatibility_passes_claimed=0)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--fixture-archive', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.archive, args.fixture_archive), indent=2))
