"""Publish fully read-back Stage 62 Dynamic rendering Java A5 evidence."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
VALIDATION = Path(__file__).resolve().parent
REPORTS = ROOT / "reports/m2"
FIXTURE = ROOT / "tests/fixtures/m2-collection-dynamic-render"
CANONICAL = ROOT / "target/m2/stage62-collection-dynamic-render-oracle-01"
HISTORY = [ROOT / "target/m2/stage62-dynamic-render-01"]
BASELINE_HEAD = "32956e6c37082fae4aca496afc2f8a7e64d29b55"
JAR_SHA256 = "c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059"
JDK_SHA256 = (
    "51ec0764f7225b40d5b286b01401aa6b3990d0d171b446d7dc81ca7542b45552",
    "40fcf7a32bada7e299e3513939a4472d27f8f61eb81cdd1675ea00648de7e7cf",
    "ab66b8afeea98b25f1869fbe7c0dde368d448e7cc0f7bab0359b322ade134fe1",
)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}

def need(ok, message):
    if not ok:
        raise ValueError(message)

def paths_under(root, prefix):
    need(root.is_dir() and not root.is_symlink(), "publication source directory missing")
    result = {}
    for path in root.rglob("*"):
        need(not path.is_symlink(), "publication source symlink")
        if path.is_file():
            result[prefix + path.relative_to(root).as_posix()] = path
        else:
            need(path.is_dir(), "publication source nonregular path")
    return result

def check_canonical():
    p = json.loads((CANONICAL / "provenance.json").read_bytes())
    a = json.loads((CANONICAL / "audit.json").read_bytes())
    rows = json.loads((CANONICAL / "cases.json").read_bytes())["rows"]
    need(len(rows) == a["rows"] == 10 and a["statuses"] == {"success": 10}
         and p["complete"] is True and p["stable"] is True and p["raw_equal"] is True
         and p["raw_differences"] == [] and p["raw_files"] == 212
         and p["input_before"] == p["input_after"]
         and p["source_before"] == p["source_after"]
         and len(p["source_before"]) == 68
         and p["artifact_sha256"] == p["artifact_after_sha256"] == JAR_SHA256,
         "canonical capture status, source or artifact differs")
    need((p["jdk"]["executable_sha256"], p["jdk"]["modules_sha256"],
          p["jdk"]["release_sha256"]) == JDK_SHA256, "canonical JDK differs")
    for name, expected in p["input_before"].items():
        need(identity(CANONICAL / name)["sha256"] == expected, "canonical executed input differs")
    for name, expected in p["source_before"].items():
        need(identity(CANONICAL / "sources" / name)["sha256"] == expected,
             "canonical copied source differs")
    sessions = p["sessions"]
    need(len(sessions) == 2 and [s["repeat"] for s in sessions] == [0, 1]
         and len({s["pid"] for s in sessions}) == 2
         and sessions[0]["finished_epoch"] <= sessions[1]["started_epoch"],
         "canonical JVM ordering differs")
    raw_sets = []
    for session in sessions:
        folder = CANONICAL / f"repeat-{session['repeat']}"
        need(session["exit_code"] == 0 and session["query_directories"] == 10
             and identity(folder / "process.stdout.bin")["sha256"] == session["stdout_sha256"]
             and identity(folder / "process.stderr.bin")["sha256"] == session["stderr_sha256"]
             and (folder / "process.stderr.bin").read_bytes() == b"",
             "canonical process identity differs")
        counts = Counter()
        protocol = ["session-open mode=string rows=10"]
        for index, row in enumerate(rows):
            case = folder / f"{index:03d}-{row['id']}"
            need(row["mode"] == "string" and (case / "expression.bin").read_text() == row["expression"],
                 "canonical row order/input differs")
            status = (case / "result.status.bin").read_text().strip()
            need(status in ("success", "error"), "canonical nonordinary status")
            counts[status] += 1
            call = f"string-{index}-{row['id']}"
            protocol.extend((f"call-enter={call}", f"call-exit={call} status={status}"))
        protocol.append(f"session-closed mode=string rows=10 public-calls=10 success={counts['success']} errors={counts['error']}")
        need((folder / "process.stdout.bin").read_bytes() == ("\n".join(protocol) + "\n").encode()
             and dict(counts) == a["statuses"], "canonical whole process protocol differs")
        raw = {path.relative_to(folder).as_posix(): identity(path)["sha256"]
               for path in folder.rglob("*") if path.is_file()}
        need(len(raw) == 212, "canonical raw file count differs")
        raw_sets.append(raw)
    need(raw_sets[0] == raw_sets[1], "canonical raw repetitions differ")
    fixture_identity = json.loads((FIXTURE / "archive-identity.json").read_bytes())
    need(fixture_identity["captures"] == {"capture-01": CANONICAL.name}
         and fixture_identity["members"] == 501
         and fixture_identity["archive_sha256"] == identity(FIXTURE / "oracle-evidence.tar.gz")["sha256"],
         "fixture archive identity differs")
    for name in ("cases.json", "queries.tsv", "module.pkl"):
        need((FIXTURE / name).read_bytes() == (CANONICAL / name).read_bytes(),
             "canonical authored input differs")
    return {"path": CANONICAL.relative_to(ROOT).as_posix(), "rows": 10,
            "statuses_per_session": a["statuses"], "raw_files_per_repetition": 212,
            "source_files": 68, "pids": [s["pid"] for s in sessions],
            "fixture_archive": identity(FIXTURE / "oracle-evidence.tar.gz"),
            "fixture_archive_members": fixture_identity["members"],
            "fixture_fileset_sha256": fixture_identity["fileset_sha256"],
            "module_uri": "file:///stage62/dynamic-render.pkl"}

def check_history(root, rows, statuses):
    p = json.loads((root / "provenance.json").read_bytes())
    a = json.loads((root / "audit.json").read_bytes())
    need(p["complete"] is True and p["raw_equal"] is True and p["raw_files"] == rows * 21 + 2
         and p["input_before"] == p["input_after"]
         and p["source_before"] == p["source_after"] and len(p["source_before"]) == 67
         and p["jar"]["sha256"] == p["jar_after_sha256"] == JAR_SHA256
         and a["rows"] == rows and a["statuses"] == statuses,
         "historical target probe incomplete")
    for name, expected in p["input_before"].items():
        need(identity(root / name)["sha256"] == expected, "historical probe input differs")
    for name, expected in p["source_before"].items():
        need(identity(root / "sources" / name)["sha256"] == expected,
             "historical probe source copy differs")
    sessions = p["sessions"]
    need(len(sessions) == 2 and len({s["pid"] for s in sessions}) == 2
         and sessions[0]["finished_epoch"] <= sessions[1]["started_epoch"]
         and all(s["exit_code"] == 0 and s["query_directories"] == rows for s in sessions),
         "historical fresh JVM coverage differs")
    return {"path": root.relative_to(ROOT).as_posix(), "rows": rows,
            "statuses_per_session": statuses, "raw_files_per_repetition": p["raw_files"]}

def emit_archive(path, files):
    need(not path.exists(), "fresh Java A5 evidence archive required")
    entries = {name: source.read_bytes() for name, source in files.items()}
    before = {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in entries.items()}
    manifest = {"schema": 1, "scope": "Stage 62 Dynamic rendering Java A5 validation, canonical capture and exploratory probes",
                "members": dict(sorted(before.items()))}
    entries["archive-manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with path.open("wb") as out:
        with gzip.GzipFile(fileobj=out, mode="wb", filename="", mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, raw in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(raw))
    after = {name: identity(source) for name, source in files.items()}
    need(before == after, "evidence source changed during archive write")
    observed = {}
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            need(member.isfile() and member.name not in observed and not member.name.startswith("/")
                 and ".." not in Path(member.name).parts, "unsafe or duplicate evidence member")
            raw = archive.extractfile(member).read()
            need(len(raw) == member.size, "evidence member size differs")
            observed[member.name] = raw
    need(observed == entries and json.loads(observed["archive-manifest.json"]) == manifest,
         "full evidence readback differs")
    return {"archive": path.relative_to(ROOT).as_posix(), "identity": identity(path),
            "members": len(observed), "member_hash_readback": True,
            "source_before_after_equal": before == after,
            "embedded_manifest_sha256": sha(observed["archive-manifest.json"])}

def main():
    validation = json.loads((VALIDATION / "validation.json").read_bytes())
    need(validation["baseline_head"] == BASELINE_HEAD and validation["complete"] is True
         and validation["source_stable"] is True and validation["snapshot_matches"] is True
         and validation["manifest_freshness_pass_claimed"] is False
         and len(validation["checks"]) == 5
         and all(check["exit_code"] == 0 for check in validation["checks"]),
         "fresh Java A5 validation incomplete")
    for name, expected in validation["source_before"].items():
        need(identity(VALIDATION / "sources" / name)["sha256"] == expected,
             "validation copied source differs")
    canonical = check_canonical()
    exploratory = check_history(HISTORY[0], 10, {"success": 10})
    files = paths_under(VALIDATION, "validation/")
    files.update(paths_under(CANONICAL, "captures/" + CANONICAL.name + "/"))
    for root in HISTORY:
        files.update(paths_under(root, "history/" + root.name + "/"))
    evidence = emit_archive(REPORTS / "stage62-dynamic-render-java-evidence.tar.gz", files)
    checkpoint = {
        "schema": 1, "kind": "stage62-collection-dynamic-render-java-authority-checkpoint",
        "baseline": "Pkl 0.32.0", "baseline_head": BASELINE_HEAD,
        "candidate_compatibility_passes_claimed": 0,
        "canonical": canonical,
        "history": {HISTORY[0].name: {**exploratory,
                    "scope": "Earlier target-only 10-row rendering probe; superseded by the tracked permanent fixture and fresh canonical capture."}},
        "java_runtime": {"artifact_sha256": JAR_SHA256,
                         "jdk_executable_sha256": JDK_SHA256[0],
                         "jdk_modules_sha256": JDK_SHA256[1],
                         "jdk_release_sha256": JDK_SHA256[2],
                         "reference_revision": "e51fb2f91774265666f94980ec630db794a4db2d"},
        "validation": {"directory": VALIDATION.relative_to(ROOT).as_posix(),
                       "record": (VALIDATION / "validation.json").relative_to(ROOT).as_posix(),
                       "record_identity": identity(VALIDATION / "validation.json"),
                       "checks": validation["checks"],
                       "source_stable": validation["source_stable"],
                       "copied_sources": len(validation["source_before"]),
                       "manifest_freshness_pass_claimed": False},
        "evidence": evidence,
        "limits": ["Public Java string observations only; no Rust candidate pass is claimed.",
                   "Unpaired surrogate names require raw UTF-16 code units; Java UTF-8 is lossy.",
                   "Typed Java export and wrapper reference identity remain unverified.",
                   "M2 manifest freshness is deferred until concurrent Rust source changes freeze.",
                   "Original upstream programs, browser, Node, full M2 and performance gates remain separate."],
    }
    dest = REPORTS / "stage62-dynamic-render-java-checkpoint.json"
    need(not dest.exists(), "fresh Java A5 checkpoint required")
    dest.write_text(json.dumps(checkpoint, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"checkpoint": identity(dest), "evidence": evidence}, sort_keys=True))

if __name__ == "__main__":
    main()
