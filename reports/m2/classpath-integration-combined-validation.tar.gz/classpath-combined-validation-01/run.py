import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

root=Path.cwd()
out=root/'target/m2/classpath-combined-validation-01'
report={'host':platform.platform(),'cwd':str(root),'commands':[],'complete':False}
def run(label, argv, expected=0):
    started=time.time()
    print('start',label,flush=True)
    result=subprocess.run(argv,cwd=root,capture_output=True)
    (out/(label+'.stdout.bin')).write_bytes(result.stdout)
    (out/(label+'.stderr.bin')).write_bytes(result.stderr)
    report['commands'].append({'label':label,'argv':argv,'exit_code':result.returncode,'expected_exit_code':expected,'seconds':time.time()-started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print('done',label,result.returncode,flush=True)
    assert result.returncode==expected,label

for name in ['m2_execution_profiles','m2_language','m2_jvm_classpath','m2_module_eval','m2_mappings','m1_platforms','runtime_source_inputs']:
    run(name,[sys.executable,'-m','unittest','discover','-s','tools/tests','-p','test_'+name+'.py'])
run('manifest-freshness',[sys.executable,'tools/m2_manifest.py','--check'])
run('jvm-profile-freshness',[sys.executable,'tools/m2_jvm_classpath.py','--check'])
run('corpus-freshness',[sys.executable,'tools/compat.py','--check'])
run('focused-acquire',[sys.executable,'tools/m2_language.py','--output','target/m2/classpath-combined-focused-01','--adapter','language-jvm-classpath-output','--record-only'])
for label,expected in [('report',0),('subset',0),('full',1)]:
    run('focused-verify-'+label,[sys.executable,'tools/m2_language.py','--verify-'+label,'target/m2/classpath-combined-focused-01'],expected)
report['complete']=True
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
