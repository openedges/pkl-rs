"""Seal closed Stage36 observations using the audited flat file list."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT.with_name('pkl-rs.stage36')
inventory_root = WORK / 'target/m2/stage36-origins-inventory-01'
inventory = json.loads((inventory_root / 'final-report.json').read_bytes())
originals = json.loads((inventory_root / 'original-files.json').read_bytes())
assert inventory['status'] == 'pass' and inventory['all_closed_files_rechecked_after_review_closure']
assert len(originals) == inventory['original_regular_file_count']
staging = ROOT / 'target/m2-evidence-stage36-origins-01'
staging.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha(inventory_root / 'original-files.json') == inventory['original_files_manifest_sha256']
files = []

def add(source, relative, expected=None):
    assert source.is_file() and not source.is_symlink(), str(source)
    digest = sha(source)
    assert expected is None or expected == digest, str(source)
    dest = staging / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    os.link(source, dest)
    files.append(dict(source=str(source), archived=str(relative), sha256=digest,
                      bytes=source.stat().st_size))

for row in originals:
    assert row['kind'] == 'file'
    add(WORK / 'target/m2' / row['path'], Path('worktree') / row['path'], row['sha256'])
for source in sorted(inventory_root.iterdir()):
    assert source.is_file()
    add(source, Path('worktree-inventory') / source.name)

# This closed Java/original-baseline root contains only captures, source files,
# Java classes and a frozen executable; direct helpers/children were inspected.
# Never walk the general target tree or the excluded Cargo caches.
main_origin = ROOT / 'target/m2/stage36-object-string-oracle-01'
for folder, directories, names in os.walk(main_origin):
    assert not any((Path(folder) / name).is_symlink() for name in directories)
    for name in names:
        source = Path(folder) / name
        add(source, Path('main') / main_origin.name / source.relative_to(main_origin))

(staging / 'seal-origins.py').write_bytes(Path(__file__).read_bytes())
(staging / 'ORIGINS.json').write_text(json.dumps(files, indent=2) + '\n')
(staging / 'EXCLUSIONS.json').write_text(json.dumps(inventory['exclusions'], indent=2) + '\n')
archive = ROOT / 'reports/m2/stage36-origins-evidence.tar.gz'
assert not archive.exists()
subprocess.run([sys.executable, 'tools/evidence.py', 'create', str(staging), str(archive)], cwd=ROOT, check=True)
assert all(sha(Path(row['source'])) == row['sha256'] for row in files)
with tarfile.open(archive) as stream:
    packed = json.load(stream.extractfile('EVIDENCE.json'))
    hashes = {row['path']: row['sha256'] for row in packed['files']}
    assert all(hashes[row['archived']] == row['sha256'] for row in files)
report = dict(scope='Original Stage36 Java observations, intermediate failures, frozen worktree checks and audits. Main final acquisitions are separate.',
              archive=str(archive.relative_to(ROOT)), sha256=sha(archive), bytes=archive.stat().st_size,
              original_files=len(files), inventory_files=len(packed['files']), source_stability=True,
              worktree_inventory_sha256=sha(inventory_root / 'final-report.json'),
              worktree_originals=inventory['original_regular_file_count'],
              excluded_before_traversal=inventory['exclusions'],
              tooling_duplication=inventory['original_tooling_duplication'],
              stage37_excluded=True, compatibility_complete=False)
(ROOT / 'reports/m2/stage36-origins-archive.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ('archive','sha256','bytes','original_files','inventory_files','source_stability')}))
