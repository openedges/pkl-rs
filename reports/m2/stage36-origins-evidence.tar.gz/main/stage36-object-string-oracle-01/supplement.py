import json,sys,concurrent.futures
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import oracle,m2_language as m,m2_manifest as c
root=Path.cwd();out=root/'target/m2/stage36-object-string-oracle-01';meta=json.loads((out/'oracle.json').read_bytes());binary=out/'artifacts/language_probe'
p={
 'typed-nested-corrected':'class C { x: Int=1 }\nclass D { child: C=new C {}; other: Listing<Int> = new { 2 } }\nobj=new D {}\nresult=obj.toString()\n',
 'dynamic-local-method-corrected':'obj=new Dynamic { x=1; local private=throw("local"); local function f()=throw("method") }\nresult=obj.toString()\n',
 'mixed-first-error-property-before-entry':'obj=new Dynamic { ["entry"]=throw("entry"); prop=throw("prop") }\nresult=obj.toString()\n',
 'mixed-first-error-property-before-element':'obj=new Dynamic { throw("element"); prop=throw("prop") }\nresult=obj.toString()\n',
 'mapping-key-object-snapshot':'obj=new Mapping { [new Dynamic { x=throw("key") }]=1 }\nresult=obj.toString()\n',
 'undefined-nested-in-strict-list':'obj=new Dynamic { list=List(new Dynamic { x=??? }) }\nresult=obj.toString()\n',
 'undefined-nested-in-strict-map-key':'obj=new Dynamic { map=Map(new Dynamic { x=??? },1) }\nresult=obj.toString()\n',
 'undefined-typed-parent-default':'class C { x: Int }\nobj=new C { x=??? }\nresult=obj.toString()\n',
 'module-skip-output-default':'hidden result=module.output.toString()\n',
 'unlimited-single-line':'obj=new Dynamic { text="'+('a'*256)+'" }\nresult=obj.toString()\n',
 'strict-set-forced-in-object':'obj=new Dynamic { set=Set(new Dynamic { x=throw("set nested") }) }\nresult=obj.toString()\n',
 'nested-render-context-mixed':'class C { x=1 }\nobj=new Dynamic { c=new C {}; list=List(new C {}); map=Map("c",new C {}); listing=new Listing { new C {} }; mapping=new Mapping { ["c"]=new C {} } }\nresult=obj.toString()\n',
 'shared-child-finite':'child=new Dynamic { value=1 }\nobj=new Dynamic { first=child; second=child }\nresult=obj.toString()\n',
}
(out/'supplement-sources.json').write_bytes(c.encoded(p))
def run(item):
 name,source=item;d=out/'cases/supplement'/name;d.mkdir(parents=True);path=d/'input.pkl';path.write_text(source);identifier='supplement/'+name;j=m.capture_java(meta,binary,identifier,path,'result',d);r=m.capture([str(binary),str(path),'result'],d,'rust',meta['environment']);cmd=m.java_case_command(meta,binary,identifier,path,'result');cmd[1]='-Dpkl.m2.outcome='+str(d/'java-fixed.outcome.bin');cmd[cmd.index('M2LanguageProbe')]='Stage36FixedProbe';f=m.capture(cmd,d,'java-fixed',meta['environment']);assert (d/'java-fixed.outcome.bin').is_file();f['outcome_sha256']=oracle.sha256(d/'java-fixed.outcome.bin');(d/'java-fixed.process.json').write_bytes(c.encoded(f));print(name,j['exit_code'],(d/'java.stdout.bin').read_bytes().decode(),(d/'java.stderr.bin').read_bytes().decode().split('\n')[1:3],flush=True);return dict(id=name,input=str(path.relative_to(root)),input_sha256=oracle.sha256(path),expression='result',java=j,rust=r,java_fixed=f)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,p.items()))
(out/'supplement-report.json').write_bytes(c.encoded(dict(scope='Additional corrected/branch probes. Original parser failures and crash evidence preserved.',oracle=meta,results=results,files={str(p.relative_to(out)):oracle.sha256(p) for p in (out/'cases/supplement').rglob('*') if p.is_file()})))
