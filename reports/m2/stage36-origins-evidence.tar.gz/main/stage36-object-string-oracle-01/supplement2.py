import json,sys,concurrent.futures
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'tools'))
import oracle,m2_language as m,m2_manifest as c
root=Path.cwd();out=root/'target/m2/stage36-object-string-oracle-01';meta=json.loads((out/'oracle.json').read_bytes());binary=out/'artifacts/language_probe'
p={
 'dynamic-undefined-required-property':'class C { missing: Int }\nobj=new Dynamic { x=(new C {}).missing; y=2 }\nresult=obj.toString()\n',
 'listing-undefined-required-property':'class C { missing: Int }\nobj=new Listing { (new C {}).missing; 2 }\nresult=obj.toString()\n',
 'mapping-undefined-required-property':'class C { missing: Int }\nobj=new Mapping { ["a"]=(new C {}).missing; ["b"]=2 }\nresult=obj.toString()\n',
 'nested-undefined-required-property':'class C { missing: Int }\nobj=new Dynamic { nested=new C {}; y=2 }\nresult=obj.toString()\n',
 'undefined-before-later-error':'class C { missing: Int }\nobj=new Dynamic { x=(new C {}).missing; y=throw("after undefined") }\nresult=obj.toString()\n',
 'undefined-nested-in-strict-list-corrected':'class C { missing: Int }\nobj=new Dynamic { list=List(new C {}) }\nresult=obj.toString()\n',
 'undefined-nested-in-strict-map-key-corrected':'class C { missing: Int }\nobj=new Dynamic { map=Map(new C {},1) }\nresult=obj.toString()\n',
 'typed-undefined-expression':'class C { missing: Int }\nobj=new C { missing=(new C {}).missing }\nresult=obj.toString()\n',
 'mutual-object-cycle-corrected':'first=new Dynamic { other=second }\nsecond=new Dynamic { other=first }\nresult=first.toString()\n',
}
(out/'supplement2-sources.json').write_bytes(c.encoded(p))
def run(item):
 name,source=item;d=out/'cases/supplement2'/name;d.mkdir(parents=True);path=d/'input.pkl';path.write_text(source);identifier='supplement2/'+name;j=m.capture_java(meta,binary,identifier,path,'result',d);r=m.capture([str(binary),str(path),'result'],d,'rust',meta['environment']);cmd=m.java_case_command(meta,binary,identifier,path,'result');cmd[1]='-Dpkl.m2.outcome='+str(d/'java-fixed.outcome.bin');cmd[cmd.index('M2LanguageProbe')]='Stage36FixedProbe';f=m.capture(cmd,d,'java-fixed',meta['environment']);f['outcome_sha256']=oracle.sha256(d/'java-fixed.outcome.bin') if (d/'java-fixed.outcome.bin').is_file() else None;(d/'java-fixed.process.json').write_bytes(c.encoded(f));print(name,j['exit_code'],(d/'java.stdout.bin').read_bytes().decode(),(d/'java.stderr.bin').read_bytes().decode().split('\n')[1:3],flush=True);return dict(id=name,input=str(path.relative_to(root)),input_sha256=oracle.sha256(path),expression='result',java=j,rust=r,java_fixed=f)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,p.items()))
(out/'supplement2-report.json').write_bytes(c.encoded(dict(scope='Additional corrected/branch probes. Original parser failures and crash evidence preserved.',oracle=meta,results=results,files={str(p.relative_to(out)):oracle.sha256(p) for p in (out/'cases/supplement2').rglob('*') if p.is_file()})))
