from pathlib import Path
import json,os,sys,platform
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage36-host-boundary-nested-02';sys.path.insert(0,str(ROOT/'tools'));import oracle,benchmark
meta=oracle.ensure_oracle(ROOT,fetch=False)
sha=lambda p:oracle.sha256(p)
benchmark.write_json(OUT/'oracle.json',meta);(OUT/'classes').mkdir();javac=benchmark.capture([str(Path(meta['java']).with_name('javac')),'-cp',meta['artifact'],'-d',str(OUT/'classes'),str(OUT/'Stage36BoundaryHostProbe.java')],ROOT,meta['environment'],OUT/'javac');assert javac['exit_code']==0
cp=meta['command'].index('-cp');java=[*meta['command'][:cp],'-cp',str(OUT/'classes')+os.pathsep+meta['artifact'],'Stage36BoundaryHostProbe']
base='class Required { missing: Int }\nrequired=new Required {}\n';tail='callbackError=required.missing\nstable="ok"\n'
cases={'nested-method-boundaries-corrected':(base+'class C { function readOuter()=read("life:outer"); function readInner()=read("life:inner") }\nc=new C {}\nfirst=c.readOuter()\nenterNested=c.readInner()\n'+tail,['first','stable'],['enterNested'],['callbackError','throw("nested-expression")'])}
rows=[]
for name,(source,outer,level1,level2) in cases.items():
 for repetition in range(2):
  d=OUT/name/str(repetition);d.mkdir(parents=True);(d/'input.pkl').write_text(source)
  for name_,items in [('outer.expressions',outer),('inner-depth-1.expressions',level1),('inner-depth-2.expressions',level2)]: (d/name_).write_text(''.join(x+'\n' for x in items))
  result=benchmark.capture([*java,str(d)],ROOT,meta['environment'],d/'process',timeout=30);calls=[]
  for p in sorted(d.glob('*.status.bin')):
   prefix=p.name.removesuffix('.status.bin');calls.append(dict(prefix=prefix,**{ch:(d/(prefix+'.'+ch+'.bin')).read_text() for ch in ['status','stdout','stderr','error-class']}))
  rows.append(dict(id=name,repetition=repetition,source_sha256=sha(d/'input.pkl'),process=result,calls=calls));print(name,repetition,result['exit_code'],flush=True)
report=dict(prior_failure='Original method source used reserved outer keyword; parser failures remain in observation01, corrected source uses readOuter/readInner.',scope='Java-only two-level actual-source reader reentry boundary stack observations; no Rust equality claim',host=platform.platform(),oracle=meta,javac=javac,cases=rows,evidence_sha256={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file()});benchmark.write_json(OUT/'report.json',report)
