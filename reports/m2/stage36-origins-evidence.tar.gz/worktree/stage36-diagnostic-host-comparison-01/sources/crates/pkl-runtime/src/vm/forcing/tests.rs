//! Ownership and scheduler assertions; raw compatibility is checked against Java.
use super::*;
use crate::host::{HostPoll, HostSession};
use crate::parser::parse_module;
use crate::resolver::resolve_module;

fn program(source: &str) -> Arc<Program> {
    compile_module(&resolve_module(&parse_module(source).unwrap()).unwrap()).unwrap()
}
fn event(vm: &mut Vm) -> VmPoll {
    for _ in 0..200_000 {
        match vm.poll(1) {
            VmPoll::Yielded => {
                vm.collect(&[]);
            }
            event => return event,
        }
    }
    panic!("VM did not settle")
}
fn ready(vm: &mut Vm) -> Result<Value, RuntimeError> {
    match event(vm) {
        VmPoll::Ready(result) => result,
        event => panic!("unexpected {event:?}"),
    }
}
fn read(vm: &mut Vm) -> u64 {
    match event(vm) {
        VmPoll::Pending(request) => request.id,
        event => panic!("unexpected {event:?}"),
    }
}
fn setup(source: &str) -> (Vm, Value) {
    let p = program(source);
    let entry = p.entry;
    let mut vm = Vm::new(p);
    vm.start(entry, vec![]).unwrap();
    let module = ready(&mut vm).unwrap();
    (vm, module)
}
fn member(vm: &mut Vm, object: &Value, name: &str) -> Result<Value, RuntimeError> {
    vm.start_member(object.as_object().unwrap(), name).unwrap();
    ready(vm)
}
fn callback_program(source: &str, names: &[&str]) -> (Arc<Program>, Vec<usize>) {
    let mut p = (*program(source)).clone();
    let entries = names
        .iter()
        .map(|name| {
            let entry = p.blocks.len();
            p.blocks.push(vec![
                Instruction::Input(0),
                Instruction::GetMember((*name).into()),
                Instruction::Return,
            ]);
            entry
        })
        .collect();
    (Arc::new(p), entries)
}

#[test]
fn reentrant_partial_string_and_callback_undefined_keep_outer_force_alive() {
    let (p, entries) = callback_program(
        r#"
class Required { missing: Int }
required = new Required {}
obj = new Dynamic { x = read("mem:outer"); y = 2 }
first = obj.toString()
second = obj.toString()
callback = obj.toString()
missing = required.missing
"#,
        &["callback", "missing"],
    );
    let entry = p.entry;
    let mut vm = Vm::new(p);
    vm.start(entry, vec![]).unwrap();
    let module = ready(&mut vm).unwrap();
    vm.start_member(module.as_object().unwrap(), "first")
        .unwrap();
    let request = read(&mut vm);
    vm.reenter(request, entries[1], vec![module.clone()])
        .unwrap();
    assert!(ready(&mut vm).unwrap_err().undefined_value);
    vm.finish_reentry();
    vm.reenter(request, entries[0], vec![module.clone()])
        .unwrap();
    assert_eq!(
        ready(&mut vm),
        Ok(Value::string("new Dynamic { x = ?; y = ? }"))
    );
    vm.finish_reentry();
    vm.collect(&[]);
    vm.resume(request, Ok(Value::string("read"))).unwrap();
    assert_eq!(
        ready(&mut vm),
        Ok(Value::string("new Dynamic { x = \"read\"; y = 2 }"))
    );
    assert_eq!(
        member(&mut vm, &module, "second"),
        Ok(Value::string("new Dynamic { x = \"read\"; y = 2 }"))
    );
    vm.close();
    assert_eq!(vm.heap_stats().slots, 0);
}

#[test]
fn undefined_success_survives_parent_failure_and_direct_reads_still_fail() {
    let (mut vm, module) = setup(
        r#"
class Required { missing: Int }
required = new Required {}
child = new Dynamic { x = if (read("mem:child") == "go") required.missing else 0 }
obj = new Dynamic { nested = List(child); bad = throw("later") }
first = obj.toString()
second = obj.toString()
childString = child.toString()
"#,
    );
    vm.start_member(module.as_object().unwrap(), "first")
        .unwrap();
    let request = read(&mut vm);
    vm.resume(request, Ok(Value::string("go"))).unwrap();
    assert_eq!(ready(&mut vm).unwrap_err().message, "later");
    let child = member(&mut vm, &module, "child").unwrap();
    let obj = member(&mut vm, &module, "obj").unwrap();
    assert!(vm.heap.get(child.as_object().unwrap()).unwrap().forced);
    assert!(!vm.heap.get(obj.as_object().unwrap()).unwrap().forced);
    assert_eq!(
        member(&mut vm, &module, "second").unwrap_err().message,
        "later"
    );
    assert_eq!(
        member(&mut vm, &module, "childString"),
        Ok(Value::string("new Dynamic { x = ? }"))
    );
    vm.start_member(child.as_object().unwrap(), "x").unwrap();
    let retry = read(&mut vm);
    vm.resume(retry, Ok(Value::string("go"))).unwrap();
    assert!(ready(&mut vm).unwrap_err().undefined_value);
    assert!(vm.heap.get(child.as_object().unwrap()).unwrap().forced);
    vm.close();
}

#[test]
fn nonterminal_cancel_resets_only_unfinished_forces_in_all_contexts() {
    let (p, entries) = callback_program(
        r#"
child = new Dynamic { done = 1 }
obj = new Dynamic { child = module.child; x = read("mem:outer") }
nested = new Dynamic { x = read("mem:inner") }
first = obj.toString()
callback = nested.toString()
"#,
        &["callback"],
    );
    let entry = p.entry;
    let mut vm = Vm::new(p);
    vm.start(entry, vec![]).unwrap();
    let module = ready(&mut vm).unwrap();
    vm.start_member(module.as_object().unwrap(), "first")
        .unwrap();
    let outer = read(&mut vm);
    vm.reenter(outer, entries[0], vec![module.clone()]).unwrap();
    let inner = read(&mut vm);
    vm.cancel();
    assert_eq!(ready(&mut vm).unwrap_err().kind, ErrorKind::Cancelled);
    vm.collect(std::slice::from_ref(&module));
    for name in ["obj", "nested"] {
        let object = member(&mut vm, &module, name).unwrap();
        assert!(!vm.heap.get(object.as_object().unwrap()).unwrap().forced);
    }
    let child = member(&mut vm, &module, "child").unwrap();
    assert!(vm.heap.get(child.as_object().unwrap()).unwrap().forced);
    for request in [outer, inner] {
        assert_eq!(
            vm.resume(request, Ok(Value::Null)).unwrap_err().kind,
            ErrorKind::Host
        );
    }
    vm.start_member(module.as_object().unwrap(), "first")
        .unwrap();
    let retry = read(&mut vm);
    vm.resume(retry, Ok(Value::Int(9))).unwrap();
    assert!(ready(&mut vm).is_ok());
    vm.close();
    assert_eq!(vm.heap_stats().live, 0);
}

#[test]
fn terminal_host_actions_release_pending_force_and_render_hash_roots() {
    for source in [
        "obj=new Dynamic { x=read(\"mem:outer\") }; first=obj.toString(); nested=new Dynamic { x=read(\"mem:inner\") }; callback=nested.toString()",
        "key=new Dynamic { x=read(\"mem:key\") }; obj=new Mapping { [key]=1 }; first=obj.toString(); nested=new Dynamic { x=read(\"mem:inner\") }; callback=nested.toString()",
    ] {
        for terminal in [ErrorKind::Cancelled, ErrorKind::Closed, ErrorKind::Timeout] {
            let (p, entries) = callback_program(source, &["first", "callback"]);
            let entry = p.entry;
            let mut session = HostSession::new(p);
            session.start(entry, vec![], 0, None).unwrap();
            let module = loop {
                match session.poll(0, 1) {
                    HostPoll::Ready(result) => break result.unwrap(),
                    HostPoll::Yielded => {
                        session.collect(&[]);
                    }
                    event => panic!("{event:?}"),
                }
            };
            session
                .start(entries[0], vec![module.clone()], 1, Some(10))
                .unwrap();
            let outer = loop {
                match session.poll(1, 1) {
                    HostPoll::Read { token, .. } => break token,
                    HostPoll::Yielded => {
                        session.collect(&[]);
                    }
                    event => panic!("{event:?}"),
                }
            };
            session
                .reenter(&outer, entries[1], vec![module], 2, None)
                .unwrap();
            let inner = loop {
                match session.poll(2, 1) {
                    HostPoll::Read { token, .. } => break token,
                    HostPoll::Yielded => {
                        session.collect(&[]);
                    }
                    event => panic!("{event:?}"),
                }
            };
            assert!(session.collect(&[]).live > 0);
            match terminal {
                ErrorKind::Cancelled => session.cancel(),
                ErrorKind::Closed => session.close(),
                _ => {}
            }
            assert!(
                matches!(session.poll(12,1),HostPoll::Ready(Err(error)) if error.kind==terminal)
            );
            assert_eq!(session.heap_stats().slots, 0);
            assert_eq!(
                session.drain_cancelled_reads(),
                [outer.clone(), inner.clone()]
            );
            for token in [outer, inner] {
                assert_eq!(
                    session
                        .resume(&token, Ok(Value::Null), 12)
                        .unwrap_err()
                        .kind,
                    ErrorKind::Closed
                );
            }
        }
    }
}

#[test]
fn inherited_hidden_owners_and_undefined_parent_fallback_use_receiver_cache() {
    let (mut vm, module) = setup(
        r#"
class Required { missing: Int }
open class Base { x=5 }
class Child extends Base { x=(new Required {}).missing }
open class Visible { x=1 }
class Hidden extends Visible { hidden x=2 }
child=new Child {}
cold=new Hidden {}
warm=new Hidden {}
coldString=cold.toString()
warmValue=warm.x
warmString=warm.toString()
childString=child.toString()
"#,
    );
    assert_eq!(
        member(&mut vm, &module, "childString"),
        Ok(Value::string("new Child { x = 5 }"))
    );
    assert_eq!(
        member(&mut vm, &module, "coldString"),
        Ok(Value::string("new Hidden { x = 1 }"))
    );
    assert_eq!(member(&mut vm, &module, "warmValue"), Ok(Value::Int(1)));
    assert_eq!(
        member(&mut vm, &module, "warmString"),
        Ok(Value::string("new Hidden { x = 1 }"))
    );
    let (mut fresh, module) = setup(
        "open class Base { x=1 }; class Child extends Base { hidden x=2 }; obj=new Child {}; value=obj.x; result=obj.toString()",
    );
    assert_eq!(member(&mut fresh, &module, "value"), Ok(Value::Int(2)));
    assert_eq!(
        member(&mut fresh, &module, "result"),
        Ok(Value::string("new Child { x = 2 }"))
    );
}

#[test]
fn builtin_integer_alias_values_have_stable_evaluator_local_identity_and_shadowing() {
    let p = program("result=List(Int8==Int8,Int8==UInt8,Int8.toString()).toString()\nalias=Int8\n");
    let mut values = Vec::new();
    for _ in 0..2 {
        let mut vm = Vm::new(p.clone());
        vm.start(p.entry, vec![]).unwrap();
        let module = ready(&mut vm).unwrap();
        assert_eq!(
            member(&mut vm, &module, "result"),
            Ok(Value::string("List(true, false, \"Int8\")"))
        );
        values.push(member(&mut vm, &module, "alias").unwrap());
        vm.close();
    }
    assert_ne!(values[0], values[1]);
    let (mut vm, module) = setup("Int8=17\nresult=Int8\n");
    assert_eq!(member(&mut vm, &module, "result"), Ok(Value::Int(17)));
}

#[test]
fn deep_force_and_render_are_iterative_and_render_cycles_are_bounded() {
    std::thread::Builder::new()
        .stack_size(256 * 1024)
        .spawn(|| {
            let p = Arc::new(Program::new(vec![vec![
                Instruction::Input(0),
                Instruction::ToString,
                Instruction::Return,
            ]]));
            let mut vm = Vm::new(p);
            let mut value = Value::Int(1);
            for _ in 0..2000 {
                let mut object = Object::default();
                object.members.push(Member {
                    flags: 0,
                    entry: false,
                    name: "x".into(),
                    code: usize::MAX,
                    local: false,
                    method: false,
                    ty: None,
                    type_span: None,
                    constant: false,
                    fixed: false,
                });
                object.complete_cache(
                    CacheKey {
                        entry: false,
                        owner: None,
                        name: "x".into(),
                        method: false,
                    },
                    value,
                );
                value = Value::Object(vm.heap.allocate(object));
            }
            vm.start(0, vec![value]).unwrap();
            let mut yields = 0;
            let result = loop {
                match vm.poll(37) {
                    VmPoll::Ready(result) => break result,
                    VmPoll::Yielded => {
                        yields += 1;
                        if yields % 17 == 0 {
                            vm.collect(&[]);
                        }
                    }
                    event => panic!("{event:?}"),
                }
            };
            let Value::String(text) = result.unwrap() else {
                panic!("string")
            };
            assert!(text.as_str().unwrap().starts_with("new Dynamic { x { x {"));
            vm.close();
            assert_eq!(vm.heap_stats().slots, 0);
        })
        .unwrap()
        .join()
        .unwrap();
    let (mut vm, module) = setup("obj=new Dynamic { x=module.obj }\nresult=obj.toString()\n");
    assert_eq!(
        member(&mut vm, &module, "result").unwrap_err().kind,
        ErrorKind::Cycle
    );
    let obj = member(&mut vm, &module, "obj").unwrap();
    assert!(vm.heap.get(obj.as_object().unwrap()).unwrap().forced);
    vm.close();
}

#[test]
fn interpolation_dispatches_typed_override_without_forcing_unrelated_members() {
    let (mut vm, module) = setup(
        r#"
class C {
  bad = throw("unforced")
  function toString(): String = "custom"
}
obj = new C {}
result = "value=\(obj)"
direct = obj.toString()
"#,
    );
    assert_eq!(
        member(&mut vm, &module, "result").unwrap(),
        Value::string("value=custom")
    );
    assert_eq!(
        member(&mut vm, &module, "direct").unwrap(),
        Value::string("custom")
    );
    let obj = member(&mut vm, &module, "obj").unwrap();
    assert!(!vm.heap.get(obj.as_object().unwrap()).unwrap().forced);
    assert_eq!(
        member(&mut vm, &obj, "bad").unwrap_err().message,
        "unforced"
    );
}

#[test]
fn inherited_object_entry_keys_compare_before_ancestor_reads_and_render_at_parent_position() {
    let (mut vm, module) = setup(
        r#"
k1 = new Dynamic { x = 1 }
k2 = new Dynamic { x = 1 }
k3 = new Dynamic { y = 0 }
base = new Mapping { [k1] = throw("overridden") }
obj = (base) { [k2] = "child"; [k3] = "collision" }
result = obj.toString()
"#,
    );
    assert_eq!(
        member(&mut vm, &module, "result").unwrap(),
        Value::string(
            "new Mapping { [new Dynamic { x = 1 }] = \"child\"; [new Dynamic { y = 0 }] = \"collision\" }"
        )
    );
}
