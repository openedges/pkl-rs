from pathlib import Path
import concurrent.futures
import json
import os
import platform
import shutil
import sys

ROOT = Path.cwd()
OUT = ROOT / 'target/m2/stage36-host-callback-errors-01'
sys.path.insert(0, str(ROOT / 'tools'))
import benchmark
import oracle
import m2_manifest as encoding

metadata = oracle.ensure_oracle(ROOT, fetch=False)
(OUT / 'oracle.json').write_bytes(encoding.encoded(metadata))
origin = ROOT / 'target/m2/stage36-host-observation-01/Stage35HostProbe.java'
helper = OUT / 'Stage35HostProbe.java'
shutil.copyfile(origin, helper)
classes = OUT / 'classes'
classes.mkdir(exist_ok=False)
compiled = benchmark.capture([str(Path(metadata['java']).with_name('javac')),
                              '-encoding', 'UTF-8', '-cp', metadata['artifact'],
                              '-d', str(classes), str(helper)],
                             ROOT, metadata['environment'], OUT / 'javac')
assert compiled['exit_code'] == 0
cp = metadata['command'].index('-cp')
java = [*metadata['command'][:cp], '-cp', str(classes) + os.pathsep + metadata['artifact'], 'Stage35HostProbe']
object_prefix = 'obj=new Dynamic { x=read("life:text"); y=2 }\nfirst=obj.toString()\nsecond=obj.toString()\n'
method_prefix = 'function readResource()=read("life:text")\nfunction runOuter()=readResource()\nfirst=runOuter()\nsecond=runOuter()\n'
suffix = 'recovered=(new Dynamic { ok=7 }).toString()\nstable="ok"\n'
definitions = [
    dict(id='object-force-callback-direct-throw', source=object_prefix + 'callback=throw("callback-direct")\n' + suffix,
         outer=['first', 'second', 'callback', 'recovered', 'stable'], inner=['callback', 'recovered', 'callback', 'recovered']),
    dict(id='object-force-callback-property-type', source=object_prefix + 'callback: Int="bad"\n' + suffix,
         outer=['first', 'second', 'callback', 'recovered', 'stable'], inner=['callback', 'recovered', 'callback', 'recovered']),
    dict(id='object-force-callback-missing-member', source=object_prefix + 'callback=(new Dynamic {}).absent\n' + suffix,
         outer=['first', 'second', 'callback', 'recovered', 'stable'], inner=['callback', 'recovered', 'callback', 'recovered']),
    dict(id='ordinary-method-callback-function-throw', source=method_prefix + 'function failInner()=throw("callback-function")\ncallback=failInner()\n' + suffix,
         outer=['first', 'second', 'callback', 'recovered', 'stable'], inner=['callback', 'recovered', 'callback', 'recovered']),
    dict(id='ordinary-property-callback-direct-throw', source='first=read("life:text")\nsecond=first\ncallback=throw("callback-property")\n' + suffix,
         outer=['first', 'second', 'callback', 'recovered', 'stable'], inner=['callback', 'recovered', 'callback', 'recovered']),
    dict(id='ordinary-method-callback-expression-throw', source=method_prefix + suffix,
         outer=['first', 'second', 'recovered', 'stable'],
         inner=['throw("callback-expression")', 'recovered', 'throw("callback-expression")', 'recovered'],
         limitation='Java expression API control. Native Host scalar property-path adapter cannot represent an arbitrary inner expression; this remains separately accounted.')
]
(OUT / 'definitions.json').write_bytes(encoding.encoded(definitions))


def run(specification):
    results = []
    for repeat in range(2):
        folder = OUT / specification['id'] / str(repeat)
        folder.mkdir(parents=True)
        (folder / 'input.pkl').write_text(specification['source'])
        (folder / 'outer.expressions').write_text(''.join(s + '\n' for s in specification['outer']))
        (folder / 'inner.expressions').write_text(''.join(s + '\n' for s in specification['inner']))
        process = benchmark.capture([*java, str(folder), 'false'], ROOT,
                                    metadata['environment'], folder / 'process', timeout=30)
        assert process['exit_code'] == 0
        observations = []
        for status in sorted(folder.glob('*.status.bin')):
            prefix = status.name.removesuffix('.status.bin')
            raw = {ch: (folder / f'{prefix}.{ch}.bin').read_bytes()
                   for ch in ['status', 'stdout', 'stderr', 'error-class']}
            observations.append(dict(prefix=prefix,
                                     channels={ch: dict(bytes=len(data), sha256=encoding.digest(data))
                                               for ch, data in raw.items()},
                                     **{ch.replace('-', '_'): data.decode() for ch, data in raw.items()}))
        results.append(dict(repetition=repeat, source_sha256=oracle.sha256(folder / 'input.pkl'),
                            process=process, calls=observations))
    raw_equal = all((OUT / specification['id'] / '0' / path.name).read_bytes() == path.read_bytes()
                    for path in (OUT / specification['id'] / '1').glob('*.bin'))
    return dict(id=specification['id'], results=results, fresh_repetition_raw_equal=raw_equal,
                limitation=specification.get('limitation'))


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(run, definitions))
report = dict(scope='Additional actual-source Java Host callback diagnostics; full raw nested/outer calls, '
                    'retry and success-after-error retained. Existing seven object-string Host observations are separate. '
                    'No Rust comparison, GC or cancellation parity claimed.',
              host=platform.platform(), oracle=metadata, javac=compiled,
              helper_origin=str(origin.relative_to(ROOT)), helper_sha256=oracle.sha256(helper),
              fixed_uri='file:///m2-platform.pkl', power_assertions=False,
              results=results,
              total_calls=sum(len(repetition['calls']) for row in results for repetition in row['results']),
              all_fresh_repetitions_raw_equal=all(row['fresh_repetition_raw_equal'] for row in results),
              files={str(p.relative_to(OUT)): oracle.sha256(p) for p in OUT.rglob('*') if p.is_file()})
(OUT / 'report.json').write_bytes(encoding.encoded(report))
print(json.dumps(dict(cases=len(results), calls=report['total_calls'],
                     fresh_raw_equal=report['all_fresh_repetitions_raw_equal']), indent=2))
