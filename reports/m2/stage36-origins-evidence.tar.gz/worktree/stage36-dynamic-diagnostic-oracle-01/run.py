import concurrent.futures
import difflib
import json
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
OUT = ROOT / 'target/m2/stage36-dynamic-diagnostic-oracle-01'
sys.path.insert(0, str(ROOT / 'tools'))
import m2_language as language
import m2_manifest as encoding
import oracle

metadata = oracle.ensure_oracle(ROOT, fetch=False)
(OUT / 'oracle.json').write_bytes(encoding.encoded(metadata))
candidate = ROOT / 'target/m2/stage36-core-cargo/debug/examples/language_probe'
binary = OUT / 'artifacts/language_probe'
classes = binary.parent / 'java'
classes.mkdir(parents=True)
shutil.copyfile(candidate, binary)
binary.chmod(0o755)
candidate_sha256 = oracle.sha256(candidate)
source_files = ['tools/java/M2LanguageProbe.java', 'tools/m2_language.py', 'oracle.lock.json', 'references.lock']
for relative in source_files:
    target = OUT / 'sources' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / relative, target)
compiled = language.capture([str(Path(metadata['java']).with_name('javac')), '-encoding', 'UTF-8',
                            '-cp', metadata['artifact'], '-d', str(classes),
                            str(OUT / 'sources/tools/java/M2LanguageProbe.java')],
                           OUT, 'javac', metadata['environment'])
assert compiled['exit_code'] == 0
definitions = {
    'empty-missing-property': 'result=(new Dynamic {}).absent\n',
    'inherited-properties-exclude-local': 'base=new Dynamic { visible=1; local localValue=2 }\nobj=(base) { later=3; hidden secret=4 }\nresult=obj.absent\n',
    'default-property-typo': 'result=(new Dynamic {}).defaut\n',
    'method-as-property-typo': 'result=(new Dynamic {}).toStrng\n',
    'absent-method-available-list': 'result=(new Dynamic { visible=1 }).absent()\n',
}
inputs = OUT / 'inputs'
inputs.mkdir()
for identifier, source in definitions.items():
    (inputs / f'{identifier}.pkl').write_text(source)
(OUT / 'definitions.json').write_bytes(encoding.encoded(definitions))


def capture(identifier):
    directory = OUT / 'cases' / identifier
    directory.mkdir(parents=True)
    source = inputs / f'{identifier}.pkl'
    (directory / 'input.pkl').write_bytes(source.read_bytes())
    java = language.capture_java(metadata, binary, identifier, source, 'result', directory)
    rust = language.capture([str(binary), str(source), 'result'], directory, 'rust', metadata['environment'])
    outcome = (directory / 'java.outcome.bin').read_bytes()
    state = language.status(dict(expected_outcome='failure'), java, rust,
                            *((directory / f'{runtime}.{channel}.bin').read_bytes()
                              for runtime in ['java', 'rust'] for channel in ['stdout', 'stderr']), outcome)
    difference = ''.join(difflib.unified_diff(
        (directory / 'java.stderr.bin').read_text().splitlines(keepends=True),
        (directory / 'rust.stderr.bin').read_text().splitlines(keepends=True),
        fromfile='java.stderr.bin', tofile='rust.stderr.bin'))
    (directory / 'stderr.diff').write_text(difference)
    return dict(id=identifier, source=str(source.relative_to(ROOT)), source_sha256=oracle.sha256(source),
                java=java, rust=rust, status=state,
                comparison='full status/stdout/stderr raw bytes; textual diff is explanatory only')


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(capture, definitions))
report = dict(scope='Fresh ignored pinned Java actual-source Dynamic missing-member controls and current core debug candidate comparison; '
                    'not selected coverage or final build/source binding.',
              oracle=metadata, javac=compiled,
              candidate=dict(path=str(candidate), sha256=candidate_sha256, source_binding='caller-supplied exploratory debug'),
              artifact_stability=oracle.sha256(candidate) == oracle.sha256(binary) == candidate_sha256,
              results=results,
              files={str(p.relative_to(OUT)): oracle.sha256(p) for p in OUT.rglob('*') if p.is_file()})
(OUT / 'report.json').write_bytes(encoding.encoded(report))
print(json.dumps({r['id']: r['status'] for r in results}, indent=2))
