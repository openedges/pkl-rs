import java.net.URI;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;
import java.io.IOException;
import org.pkl.core.*;
import org.pkl.core.resource.ResourceReader;
public final class Stage36BoundaryHostProbe {
 static Path out;
 static void capture(Evaluator eval,ModuleSource source,String expression,String prefix) throws Exception {
  String status="success\n",value="",error="",type="";
  try { value=eval.evaluateExpressionString(source,expression); }
  catch(PklException e){status=e instanceof PklBugException?"oracle-error\n":"error\n";error=e.getMessage();type=e.getClass().getName()+"\n";}
  Files.writeString(out.resolve(prefix+".status.bin"),status,StandardCharsets.UTF_8);
  Files.writeString(out.resolve(prefix+".stdout.bin"),value,StandardCharsets.UTF_8);
  Files.writeString(out.resolve(prefix+".stderr.bin"),error,StandardCharsets.UTF_8);
  Files.writeString(out.resolve(prefix+".error-class.bin"),type,StandardCharsets.UTF_8);
 }
 static final class Reader implements ResourceReader {
  int calls,depth; Evaluator evaluator;ModuleSource source;List<List<String>> levels;
  public String getUriScheme(){return "life";}public boolean hasHierarchicalUris(){return false;}public boolean isGlobbable(){return false;}
  public Optional<Object> read(URI uri) throws IOException {
   int call=++calls,level=++depth;System.out.println("host-read="+uri+" calls="+call+" depth="+level);
   try {
    if(level>levels.size()) throw new IOException("unexpected nested reader depth "+level);
    var expressions=levels.get(level-1);
    for(int i=0;i<expressions.size();i++){
     try{capture(evaluator,source,expressions.get(i),"inner-"+call+"-"+i);}catch(Exception e){throw new RuntimeException(e);}
    }
    return Optional.of("resource");
   } finally {depth--;}
  }
 }
 public static void main(String[]args)throws Exception {
  out=Path.of(args[0]);var reader=new Reader();reader.levels=List.of(Files.readAllLines(out.resolve("inner-depth-1.expressions")),Files.readAllLines(out.resolve("inner-depth-2.expressions")));
  try(var eval=EvaluatorBuilder.preconfigured().setColor(false).setModuleCacheDir(null).setPowerAssertionsEnabled(false).setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).setAllowedResources(List.of(Pattern.compile("life:.*"))).setResourceReaders(List.of(reader)).build()){
   var source=ModuleSource.create(URI.create("file:///m2-platform.pkl"),Files.readString(out.resolve("input.pkl")));reader.evaluator=eval;reader.source=source;
   var calls=Files.readAllLines(out.resolve("outer.expressions"));for(int i=0;i<calls.size();i++){capture(eval,source,calls.get(i),"outer-"+i);System.out.println("attempt="+i+" calls="+reader.calls);}
  }
 }
}
