#!/usr/bin/env python3
"""Exact-source Stage36 development Host/GC differential; preserves every raw mismatch."""
from pathlib import Path
import json,os,platform,shutil,subprocess,sys
from collections import Counter
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tools'))
import oracle,benchmark
OUT=Path(sys.argv[1]).resolve();OUT.mkdir();MODE=sys.argv[2] if len(sys.argv)>2 else 'object-string';assert MODE in ['object-string','diagnostic','nested']
ORIGIN=ROOT/'target/m2';META=json.loads((ORIGIN/('stage36-host-boundary-properties-01' if MODE=='nested' else 'stage36-host-observation-01')/'oracle.json').read_bytes())
ORACLE_ROOT=ROOT if MODE=='nested' else Path('/Users/cody.ij.hwang/Projects/pkl-rs')
def sha(path):return oracle.sha256(path)
assert oracle.ensure_oracle(ORACLE_ROOT,fetch=False)==META
source_paths=[ROOT/p for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','oracle.lock.json','tools/oracle.py','tools/benchmark.py']]
source_paths+=sorted(p for p in (ROOT/'crates').rglob('*') if p.is_file())
source_paths+=[Path(__file__).resolve()]
sources=[]
for path in source_paths:
 rel=path.relative_to(ROOT);dest=OUT/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest);sources.append(dict(path=str(rel),sha256=sha(path),bytes=path.stat().st_size))
def stable():
 return all((ROOT/r['path']).is_file() and sha(ROOT/r['path'])==r['sha256'] for r in sources) and {str(p.relative_to(ROOT)) for p in (ROOT/'crates').rglob('*') if p.is_file()}=={r['path'] for r in sources if r['path'].startswith('crates/')}
benchmark.write_json(OUT/'oracle.json',META)
identity={name:benchmark.capture(cmd,ROOT,dict(os.environ),OUT/name) for name,cmd in [('rustc',['rustc','-vV']),('cargo-identity',['cargo','-vV'])]}
build=benchmark.capture(['cargo','build','-p','pkl-runtime','--locked','--release','--example','annotation_host_probe','--message-format=json'],ROOT,dict(os.environ,CARGO_TARGET_DIR=str(OUT/'build')),OUT/'cargo',timeout=240)
report=dict(schema=1,mode=MODE,scope=('Seven exact-source object toString Host callback/GC cases, twice each' if MODE=='object-string' else ('Four explicitly property-path-supported two-depth Host callback contracts, twice each' if MODE=='nested' else 'Two finite diagnostic key-hash Host observations, twice each; expected unsupported suspension remains a real mismatch'))+'; no full language/Host API equivalence claim',head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),host=platform.platform(),sources=sources,oracle=META,toolchain=identity,build=build,stable_after_build=stable(),cases=[])
if build['exit_code']!=0:report['acquisition_error']='Native probe build failed'
else:
 messages=[json.loads(line) for line in benchmark.raw_channel(build,'stdout').splitlines()]
 paths=[Path(row['executable']) for row in messages if row.get('reason')=='compiler-artifact' and row.get('executable') and row.get('target',{}).get('name')=='annotation_host_probe'];assert len(paths)==1
 (OUT/'binaries').mkdir();binary=OUT/'binaries/annotation_host_probe';shutil.copy2(paths[0],binary)
 cases=[('stage36-host-observation-01',x) for x in ['pending-success','parent-failure-retry','shared-child','undefined-after-read']]+[('stage36-host-observation-02','completed-child-parent-failure-corrected')]+[('stage36-host-observation-03',x) for x in ['callback-undefined-isolation','mapping-key-host']]
 if MODE=='nested':cases=[('stage36-host-boundary-properties-01',x) for x in ['nested-force-property-paths','nested-ordinary-property-paths','nested-direct-method-property-paths','nested-wrapped-method-property-paths']]
 if MODE=='diagnostic':cases=[('stage36-host-observation-04',x) for x in ['diagnostic-mapping-key-host','diagnostic-truncation-before-key']]
 report['java_origins']=[]
 for origin in sorted(set(x[0] for x in cases)):
  directory=ORIGIN/origin;original=json.loads((directory/'report.json').read_bytes());assert original['oracle']==META
  probe_class='Stage36BoundaryHostProbe' if MODE=='nested' else 'Stage35HostProbe'
  artifact_paths=[probe_class+'.java','classes/'+probe_class+'.class','classes/'+probe_class+'$Reader.class']
  identities={x:sha(directory/x) for x in artifact_paths};assert all(original['evidence_sha256'][x]==h for x,h in identities.items())
  report['java_origins'].append(dict(path=str(directory.relative_to(ROOT)),report_sha256=sha(directory/'report.json'),artifact_sha256=identities))
 for origin,name in cases:
  for repeat in range(2):
   old=ORIGIN/origin/name/str(repeat);dest=OUT/name/str(repeat);dest.mkdir(parents=True);java=dest/'java';shutil.copytree(old,java)
   inputs=['input.pkl','outer.expressions',*(['inner-depth-1.expressions','inner-depth-2.expressions'] if MODE=='nested' else ['inner.expressions'])]
   for file in inputs:shutil.copy2(old/file,dest/file)
   rust=dest/'rust';rust.mkdir();command=[str(binary),str(dest/'input.pkl'),str(dest/'outer.expressions'),str(dest/('inner-depth-1.expressions' if MODE=='nested' else 'inner.expressions')),str(rust)]
   if MODE=='nested':command.append(str(dest/'inner-depth-2.expressions'))
   rr=benchmark.capture(command,ROOT,META['environment'],rust/'process',timeout=30)
   jr=json.loads((java/'process/result.json').read_bytes());comparison=[]
   statuses=sorted(java.glob('*.status.bin'))
   for status in statuses:
    prefix=status.name.removesuffix('.status.bin')
    for channel in ['status','stdout','stderr']:
     file=prefix+'.'+channel+'.bin';a=java/file;b=rust/file;comparison.append(dict(path=file,raw_equal=a.is_file() and b.is_file() and a.read_bytes()==b.read_bytes()))
   for channel in ['stdout','stderr']:
    comparison.append(dict(path='process/'+channel+'.bin',raw_equal=benchmark.raw_channel(jr,channel)==benchmark.raw_channel(rr,channel)))
   java_prefixes={status.name.removesuffix('.status.bin') for status in statuses};rust_prefixes={status.name.removesuffix('.status.bin') for status in rust.glob('*.status.bin')};capture_set_equal=java_prefixes==rust_prefixes
   oracle_errors=[status.name.removesuffix('.status.bin') for status in statuses if status.read_bytes()==b'oracle-error\n' or (java/(status.name.removesuffix('.status.bin')+'.error-class.bin')).read_bytes()==b'org.pkl.core.PklBugException\n']
   row=dict(id=name,repetition=repeat,java_origin=str(old.relative_to(ROOT)),java=jr,rust=rr,expected_java_calls=len(statuses),paired_calls=len(java_prefixes & rust_prefixes),missing_rust_calls=sorted(java_prefixes-rust_prefixes),unexpected_rust_calls=sorted(rust_prefixes-java_prefixes),oracle_error_calls=oracle_errors,comparisons=comparison,passed=not oracle_errors and capture_set_equal and bool(statuses) and all(r['raw_equal'] for r in comparison) and jr['status']==rr['status']=='executed' and jr['exit_code']==rr['exit_code']==0)
   row['status']='oracle-error' if oracle_errors or jr['exit_code']!=0 or jr['status']!='executed' else ('pass' if row['passed'] else 'mismatch')
   report['cases'].append(row);print(name,repeat,'passed='+str(row['passed']),flush=True)
report['status_counts']=dict(Counter(row['status'] for row in report['cases']))
report['stable_after_execution']=stable()
report['artifact_stability']=not report.get('acquisition_error') and sha(binary)==sha(paths[0])
report['oracle_runtime_stability']=oracle.ensure_oracle(ORACLE_ROOT,fetch=False)==META
report['limitations']=['Only selected authored source cases and property-path callbacks are compared. Original malformed recursive fifth source remains failed in Java observation01; corrected source is separately identified in observation02.','Java error-class provenance is retained; Rust class-name equality is not claimed.','Only configured callback depths/property-path expressions are executed; arbitrary callback REPL expressions, injected Host I/O failure and cancellation/timeout remain outside this comparison.','Native GC/context assertions and terminal heap zero are separate architecture observations, not Java byte comparisons.']
report['passed']=not report.get('acquisition_error') and report['stable_after_build'] and report['stable_after_execution'] and report['artifact_stability'] and report['oracle_runtime_stability'] and len(report['cases'])==len(cases)*2 and all(r['passed'] for r in report['cases'])
report['artifacts']={str(p.relative_to(OUT)):sha(p) for p in (OUT/'binaries').glob('*') if p.is_file()} if (OUT/'binaries').exists() else {}
files=[]
for directory,children,names in os.walk(OUT):
 if Path(directory)==OUT:children[:]=[name for name in children if name!='build']
 files.extend(Path(directory)/name for name in names)
report['evidence_sha256']={str(p.relative_to(OUT)):sha(p) for p in sorted(files)}
benchmark.write_json(OUT/'report.json',report)
print(OUT/'report.json','passed='+str(report['passed']))
