"""Compare five existing property-path Host callback controls to a supplied frozen artifact."""
from pathlib import Path
import concurrent.futures
import json
import platform
import shutil
import sys

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'tools'))
import benchmark
import oracle
import m2_manifest as encoding

OUT = Path(sys.argv[1]).resolve()
CANDIDATE = Path(sys.argv[2]).resolve()
ORIGIN = ROOT / 'target/m2/stage36-host-callback-errors-01'
OUT.mkdir(parents=True, exist_ok=False)
origin_report = json.loads((ORIGIN / 'report.json').read_bytes())
assert all(oracle.sha256(ORIGIN / relative) == digest
           for relative, digest in origin_report['files'].items())
definitions = json.loads((ORIGIN / 'definitions.json').read_bytes())
selected = [row for row in definitions if 'limitation' not in row]
assert len(selected) == 5
metadata = origin_report['oracle']
oracle_hashes = {path: oracle.sha256(Path(path))
                 for path in [metadata['java'], metadata['artifact']]}
frozen = OUT / 'artifacts/annotation_host_probe'
frozen.parent.mkdir()
shutil.copyfile(CANDIDATE, frozen)
frozen.chmod(0o755)
candidate_sha256 = oracle.sha256(CANDIDATE)
(OUT / 'oracle-origin.json').write_bytes(encoding.encoded(metadata))
shutil.copyfile(Path(__file__), OUT / 'driver.py')


def compare(specification):
    results = []
    for repetition in range(2):
        origin = ORIGIN / specification['id'] / str(repetition)
        folder = OUT / specification['id'] / str(repetition)
        native = folder / 'rust'
        native.mkdir(parents=True)
        java = folder / 'java'
        java.mkdir()
        input_hashes = {}
        for name in ['input.pkl', 'outer.expressions', 'inner.expressions']:
            shutil.copyfile(origin / name, folder / name)
            input_hashes[name] = oracle.sha256(origin / name)
        for path in origin.glob('*.bin'):
            shutil.copyfile(path, java / path.name)
        for name in ['stdout.bin', 'stderr.bin', 'process.json']:
            shutil.copyfile(origin / 'process' / name, java / name)
        command = [str(frozen), str(folder / 'input.pkl'),
                   str(folder / 'outer.expressions'), str(folder / 'inner.expressions'), str(native)]
        process = benchmark.capture(command, ROOT, metadata['environment'], native / 'process', timeout=30)
        comparisons = []
        expected = sorted(java.glob('*.status.bin'))
        for status in expected:
            prefix = status.name.removesuffix('.status.bin')
            channels = {}
            for channel in ['status', 'stdout', 'stderr']:
                original = java / f'{prefix}.{channel}.bin'
                actual = native / f'{prefix}.{channel}.bin'
                channels[channel] = dict(expected_sha256=oracle.sha256(original),
                                         actual_sha256=oracle.sha256(actual) if actual.is_file() else None,
                                         raw_equal=actual.is_file() and original.read_bytes() == actual.read_bytes())
            comparisons.append(dict(prefix=prefix, channels=channels,
                                     raw_equal=all(c['raw_equal'] for c in channels.values())))
        protocol = {name: benchmark.raw_channel(process, name) == (java / f'{name}.bin').read_bytes()
                    for name in ['stdout', 'stderr']}
        architecture = native / 'architecture.json'
        observation = json.loads(architecture.read_bytes()) if architecture.is_file() else None
        same_names = {p.name for p in java.glob('*.status.bin')} == {p.name for p in native.glob('*.status.bin')}
        executed = process['exit_code'] == 0 and process['status'] == 'executed'
        results.append(dict(repetition=repetition, process=process, comparisons=comparisons,
                            process_protocol_raw_equal=protocol, exact_per_call_coverage=same_names,
                            architecture=observation,
                            input_hashes=input_hashes,
                            inputs_stable=all(oracle.sha256(folder / name) == value for name, value in input_hashes.items()),
                            all_raw_equal=executed and same_names and all(protocol.values()) and
                                all(c['raw_equal'] for c in comparisons)))
    return dict(id=specification['id'], results=results)


with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(compare, selected))
report = dict(scope='Independent five-case actual-source Host callback comparison to unchanged acquired Java bytes. '
                    'Error class files retained, not cross-language compared. Architecture observations separate. '
                    'Sixth arbitrary-expression Java case remains unsupported by native property-path adapter.',
              host=platform.platform(), origin_report_sha256=oracle.sha256(ORIGIN / 'report.json'),
              artifact=dict(origin=str(CANDIDATE), sha256=candidate_sha256,
                            source_binding='caller-supplied; independent source/build binding required'),
              artifact_stable=oracle.sha256(frozen) == candidate_sha256 == oracle.sha256(CANDIDATE),
              oracle_origins_stable=all(oracle.sha256(Path(path)) == value for path, value in oracle_hashes.items()),
              results=results, passed=all(run['all_raw_equal'] for row in results for run in row['results']),
              call_count=sum(len(run['comparisons']) for row in results for run in row['results']),
              files={str(p.relative_to(OUT)): oracle.sha256(p) for p in OUT.rglob('*') if p.is_file()})
(OUT / 'report.json').write_bytes(encoding.encoded(report))
print(json.dumps(dict(passed=report['passed'], calls=report['call_count'],
                     failed_cases=[row['id'] for row in results if not all(r['all_raw_equal'] for r in row['results'])]), indent=2))
