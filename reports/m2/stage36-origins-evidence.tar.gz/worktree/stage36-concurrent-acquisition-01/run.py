import json
import os
import platform
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
sys.path.insert(0, str(ROOT / 'tools'))
import m2_language as language
import m2_manifest as contract
import oracle

OUT = ROOT / 'target/m2/stage36-concurrent-acquisition-01'
manifest_path = ROOT / contract.MANIFEST
manifest = json.loads(manifest_path.read_bytes())
ids = ['int-zero', 'int-negative', 'error-remainder-zero',
       'error-missing', 'power-constraint-false', 'reference-stage10-render-to-string']
selected = [row for row in manifest['cases'] if row['id'] in ids]
assert len(selected) == len(ids)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
baseline = MAIN / 'target/m2/language-stage35-final-01/artifacts/language_probe'
assert oracle.sha256(baseline) == '04780a951968c9d59e97c4815d585ba2c6a0a2c939846438315ba9e7ea812b26'
inputs = {}
for row in selected:
    path = ROOT / row['input']
    assert oracle.sha256(path) == row['input_sha256']
    assert path.read_bytes() == (MAIN / row['input']).read_bytes()
    inputs[row['input']] = row['input_sha256']
(OUT / 'selected-original-rows.json').write_bytes(contract.encoded(selected))
(OUT / 'oracle.json').write_bytes(contract.encoded(metadata))
snapshots = {}
for relative in ['tools/m2_language.py', 'tools/tests/test_m2_language.py',
                 'tools/java/M2LanguageProbe.java', 'oracle.lock.json', 'references.lock',
                 str(contract.MANIFEST), *inputs]:
    dest = OUT / 'sources' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / relative, dest)
    snapshots[relative] = oracle.sha256(dest)
snapshots['run.py'] = oracle.sha256(Path(__file__))
observed = []
for workers, name in [(1, 'serial'), (3, 'parallel')]:
    directory = OUT / name
    directory.mkdir(exist_ok=False)
    artifacts = directory / 'artifacts'
    classes = artifacts / 'java'
    classes.mkdir(parents=True)
    frozen = artifacts / 'language_probe'
    shutil.copyfile(baseline, frozen)
    frozen.chmod(0o755)
    compiler = language.capture([str(Path(metadata['java']).with_name('javac')),
                                '-encoding', 'UTF-8', '-cp', metadata['artifact'],
                                '-d', str(classes), str(ROOT / 'tools/java/M2LanguageProbe.java')],
                               directory, 'javac', metadata['environment'])
    assert compiler['exit_code'] == 0
    results = language.acquire_cases(selected, directory, metadata, frozen, workers=workers)
    run = dict(execution=dict(workers=workers), results=results,
               artifact_sha256=oracle.sha256(frozen),
               status_counts={status: sum(row['status'] == status for row in results)
                              for status in sorted({row['status'] for row in results})})
    (directory / 'acquisition.json').write_bytes(contract.encoded(run))
    observed.append(run)
comparisons = []
for case in selected:
    relative = Path('cases') / case['id']
    comparisons.append(dict(id=case['id'], channels={
        str(p.relative_to(OUT / 'serial')):
            p.read_bytes() == (OUT / 'parallel' / p.relative_to(OUT / 'serial')).read_bytes()
        for p in (OUT / 'serial' / relative).rglob('*.bin')},
        process_status_equal=all(
            {k: v for k, v in serial.items() if k != 'command'} ==
            {k: v for k, v in parallel.items() if k != 'command'}
            for serial, parallel in [(observed[0]['results'][selected.index(case)][name],
                                      observed[1]['results'][selected.index(case)][name])
                                     for name in ['java', 'rust'] +
                                     (['java_repeat'] if case['id'] == 'error-remainder-zero' else [])])))
stable = all(oracle.sha256(ROOT / path) == expected for path, expected in snapshots.items()
             if path != 'run.py')
report = dict(scope='Fresh six-case serial/parallel acquisition equivalence, using unchanged existing '
                    'fixture bytes and pinned Java plus frozen Stage35 artifact. '
                    'The original corpus failures remain failures. Acquisition throughput only; '
                    'not runtime performance evidence or a full manifest verification report.',
              host=platform.platform(), oracle=metadata,
              baseline=dict(path=str(baseline), sha256=oracle.sha256(baseline),
                            source_binding='frozen Stage35 original artifact, not current Stage36 runtime'),
              snapshots=snapshots, source_stability=stable,
              execution_settings=[r['execution'] for r in observed],
              selected_ids=[r['id'] for r in selected],
              statuses=[r['status_counts'] for r in observed], comparisons=comparisons,
              all_raw_pairs_equal=all(all(r['channels'].values()) and r['process_status_equal'] for r in comparisons),
              status_order_equal=[(r['id'], r['status']) for r in observed[0]['results']] ==
                                 [(r['id'], r['status']) for r in observed[1]['results']],
              files={str(p.relative_to(OUT)): oracle.sha256(p) for p in OUT.rglob('*') if p.is_file()})
(OUT / 'report.json').write_bytes(contract.encoded(report))
print(json.dumps({key: report[key] for key in ['all_raw_pairs_equal', 'status_order_equal', 'source_stability', 'statuses']}, indent=2))
