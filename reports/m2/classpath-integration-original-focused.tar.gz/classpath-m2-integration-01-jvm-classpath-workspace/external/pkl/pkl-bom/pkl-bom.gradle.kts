/*
 * Copyright © 2024-2026 Apple Inc. and the Pkl project authors. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
plugins {
  id("pklAllProjects")
  `java-platform`
  `maven-publish`
  signing
}

description = "Pkl BOM that includes all modules"

dependencies {
  constraints {
    api(projects.pklCli)
    api(projects.pklCodegenJava)
    api(projects.pklCodegenKotlin)
    // Use explicit coordinates for pkl-config-java to avoid ambiguity with fatJar publication
    api("${project.group}:pkl-config-java:${project.version}")
    api("${project.group}:pkl-config-java-all:${project.version}")
    api(projects.pklConfigKotlin)
    api(projects.pklCore)
    api(projects.pklDoc)
    api(projects.pklExecutor)
    api(projects.pklFormatter)
    api(projects.pklGradle)
    api(projects.pklParser)
    api(projects.pklTools)
  }
}

publishing {
  publications {
    create<MavenPublication>("library") {
      from(components["javaPlatform"])
      pom {
        url.set("https://github.com/apple/pkl/tree/main/pkl-bom")
        description.set("Bill of Materials for managing Pkl dependency versions")
      }
    }
  }
}

configurePklPomMetadata()

configurePomValidation()

configurePklSigning()
