"""Retain Stage 38 implementation publication receipts and Git source binding."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent
CLOSE = ROOT / 'target/m2/closeout-stage38-01'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text())
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
binding = read(ROOT / 'reports/m2/stage38-source-binding.json')
assert binding['implementation_commit'] == commit and binding['git_binding_performed']
remote = (CLOSE / 'processes/implementation-remote/stdout.bin').read_text().split()
assert remote == [commit, 'refs/heads/main'], remote
required = ['git-add', 'staged-whitespace', 'implementation-commit', 'source-binding',
            'implementation-push', 'implementation-remote']
processes = {name: read(CLOSE / 'processes' / name / 'process.json') for name in required}
assert all(row['exit_code'] == 0 for row in processes.values())
paths = [(p, 'closeout/' + p.relative_to(CLOSE).as_posix())
         for p in sorted(CLOSE.rglob('*')) if p.is_file() and '__pycache__' not in p.parts]
paths += [(ROOT / 'target/m2/stage38-final-seal-01/report.json', 'final-archive-verification.json'),
          (Path(__file__), 'capture_completion.py')]
files = {name: dict(origin=str(path), bytes=path.stat().st_size, sha256=sha(path)) for path, name in paths}
inventory = (json.dumps(dict(files=files, implementation_commit=commit,
                             scope='Implementation publication and source-binding receipts; later documentation commit is separate.'),
                        indent=2) + '\n').encode()
destination = ROOT / 'reports/m2/stage38-completion-evidence.tar.gz'
with destination.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as archive:
    for path, name in paths:
        assert sha(path) == files[name]['sha256']
        info = archive.gettarinfo(str(path), arcname=name)
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        with path.open('rb') as stream:
            archive.addfile(info, stream)
    info = tarfile.TarInfo('inventory.json')
    info.size = len(inventory)
    archive.addfile(info, io.BytesIO(inventory))
seen = set()
with tarfile.open(destination, 'r:gz') as archive:
    for member in archive:
        assert member.name not in seen
        seen.add(member.name)
        data = archive.extractfile(member).read()
        if member.name == 'inventory.json':
            assert data == inventory
        else:
            assert hashlib.sha256(data).hexdigest() == files[member.name]['sha256']
assert seen == set(files) | {'inventory.json'}
report = dict(schema=1, scope='Closed Stage 38 implementation publication and Git source identity.',
              implementation_commit=commit, remote_main_verified=commit, compatibility_complete=False,
              source_binding_passed=True, distinct_committed_paths=binding['distinct_source_paths'],
              source_binding_sha256=sha(ROOT / 'reports/m2/stage38-source-binding.json'),
              processes=processes, original_files=len(files), extracted_files_verified=len(seen),
              archive=dict(path=str(destination.relative_to(ROOT)), bytes=destination.stat().st_size,
                           sha256=sha(destination), inventory_sha256=hashlib.sha256(inventory).hexdigest()),
              final_summary_sha256=sha(ROOT / 'reports/m2/stage38-final-summary.json'))
(ROOT / 'reports/m2/stage38-completion-captures.json').write_text(json.dumps(report, indent=2) + '\n')
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(implementation_commit=commit, committed_paths=binding['distinct_source_paths'],
                     original_files=len(files), archive_sha256=report['archive']['sha256'])), flush=True)
