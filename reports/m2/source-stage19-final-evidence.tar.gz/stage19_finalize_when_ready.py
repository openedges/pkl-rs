"""Wait for the retained full Java process, then seal once from frozen helper bytes."""
from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd();process_path=root/'target/m2/language-stage19-command-final-01/process.json';deadline=time.monotonic()+3600
print(json.dumps(dict(status='waiting-for-full-java',pid=os.getpid(),process=str(process_path))),flush=True)
while not process_path.is_file():
 if time.monotonic()>=deadline:raise SystemExit('Full Java process did not finish within one hour; no final archive was created.')
 time.sleep(10)
process=json.loads(process_path.read_bytes())
if process['exit_code']!=0 or process.get('timed_out'):raise SystemExit('Full Java acquisition failed; no final archive was created.')
command=[sys.executable,'target/m2/run_stage19_package.py','--output','target/m2/stage19-package-captured-final-01','--','--commit','a0801b9b4d614f6d936d9c410f67a05be59e7733']
print(json.dumps(dict(status='full-java-finished-sealing',command=command)),flush=True)
raise SystemExit(subprocess.run(command,cwd=root).returncode)
