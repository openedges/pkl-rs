"""Record the root review with exact committed source bytes; no evaluator execution."""
import hashlib,json,subprocess,datetime
from pathlib import Path
commit='a0801b9b4d614f6d936d9c410f67a05be59e7733'
paths=['crates/pkl-runtime/src/heap.rs','crates/pkl-runtime/src/vm.rs','crates/pkl-runtime/src/vm/generics.rs','crates/pkl-runtime/src/vm/generics/tests.rs','crates/pkl-runtime/src/vm/reference.rs','crates/pkl-runtime/src/vm/typecheck.rs','crates/pkl-runtime/src/vm/collections.rs','crates/pkl-runtime/tests/m2_generic_metadata_lifecycle.rs','tools/m1_platforms.py','tools/platform/scenarios.mjs','tools/platform/generic-metadata-cases.mjs','tools/platform/run.mjs','tests/fixtures/m2/cases.json','compatibility/m2-class-lifecycle/manifest.json','compatibility/m2-language.json','compatibility/m2-mappings.json']
source={}
for name in paths:
 raw=Path(name).read_bytes();assert subprocess.check_output(['git','show',commit+':'+name])==raw
 source[name]=hashlib.sha256(raw).hexdigest()
build=json.loads(Path('target/m2/stage19-release-probe-build-final-01/candidate.json').read_text());assert build['source_stability']
for name,digest in build['source_sha256_after'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
review={
 'schema':1,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'implementation_commit':commit,'status':'reviewed-bounded-scope','reviewer':'root',
 'source_sha256':source,
 'scope':{'independent_review':['Shared argument ownership and iterative concurrent last release','Default task scheduling and temporary roots across GC/cancellation','Captured argument handling through type-check task consumers','New lifecycle harness timeout/exit propagation and unchanged historical assertions','Narrow mapping migration and preservation accounting'],
 'author_review':['Reference iterative normalization, metadata identity, names and subtype comparisons','Reference direct class-id shortcut fix and three internal tests'],
 'independence_note':'Root authored Reference changes; runtime agent independently reviewed them. Core generic/default implementation was authored by the runtime agent and reviewed by root and the lifecycle agent.'},
 'observations':[
 'Substitution stops at immutable instantiated argument nodes; no Java production fallback or arbitrary type-depth compatibility cutoff was added.',
 'Last-owner Arc::into_inner reclamation drains owned and shared metadata children explicitly, including constraint argument maps. Shared nodes carry no evaluator heap handles.',
 'Default construction suspends at each descent/allocation/unwind and traces its target, unfinished parents and current value. Nonterminal cancellation preserves evaluator declarations; terminal cleanup releases all heap slots.',
 'Reference canonical identity uses exact interned structural records; traversal-local pointers do not enter the identity. The representation changes internal equality keys, not the Java numeric hash contract.',
 'Independent review found the missing equal-class-id shortcut for Domain and it was fixed before final release/native/platform acquisition. The first successful candidate and its captures remain superseded history.',
 'Constraint actual-argument equivalence semantics were left unchanged because no concrete Java witness established a correction.',
 'Old selected definitions, fixture bytes, sequence definitions and known outcomes remain separate from new additions; explicit symbol/clause migrations preserve the semantic obligations.'
 ],
 'validation_boundary':'Final release artifact sources equal the reviewed committed bytes. Actual suite results and source stability are recorded in their own final reports; this read-only review does not substitute for pending whole-Java or required-check execution.',
 'final_release_artifacts':build['artifacts'],
 'remaining_scope':['Java-compatible general stack-overflow diagnostics','Instruction-internal Reference metadata work and uniform wall-time cancellation bounds','Potential expanded diagnostic output size','Arbitrary authored parser/compiler nesting','Remaining type/default/Reference/const-scope diagnostics and complete language/API/platform requirements','Execution-time and peak-RSS parity']}
p=Path('target/m2/stage19-final-source-review.json');assert not p.exists();p.write_text(json.dumps(review,indent=2)+'\n');print('Root review committed-source identities:',len(source))
