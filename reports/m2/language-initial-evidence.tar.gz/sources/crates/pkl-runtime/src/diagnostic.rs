//! Structured diagnostics before product-specific rendering.
use crate::source::{Source, SourceId, Span};
use std::fmt;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum DiagnosticKind {
    Syntax,
    Unsupported,
    DuplicateMember,
    IntegerRange,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LogicalFrame {
    pub source: SourceId,
    pub span: Span,
    pub member: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Diagnostic {
    pub kind: DiagnosticKind,
    pub span: Span,
    pub message: String,
    /// Synthetic JVM underline width (not a source byte length), e.g. at EOF.
    pub highlight_length_utf16: Option<usize>,
    pub frames: Vec<LogicalFrame>,
}

impl Diagnostic {
    pub fn new(kind: DiagnosticKind, span: Span, message: impl Into<String>) -> Self {
        Self {
            kind,
            span,
            message: message.into(),
            highlight_length_utf16: None,
            frames: Vec::new(),
        }
    }
}

impl fmt::Display for Diagnostic {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(&self.message)
    }
}

impl std::error::Error for Diagnostic {}

/// A resolved logical frame at the uncolored text boundary.
///
/// The evaluator supplies source identities and authored names. The renderer does
/// not infer frames from message text or from the Rust call stack.
pub struct RenderFrame<'a> {
    pub source: &'a Source,
    pub uri: &'a str,
    pub member: &'a str,
    pub span: Span,
    pub highlight_length_utf16: Option<usize>,
}

/// Render the ordinary, uncolored Pkl exception layout.
///
/// Recursive frame compression, source transformers, and colored output remain
/// separate compatibility requirements.
pub fn render_error(message: &str, frames: &[RenderFrame<'_>], hint: Option<&str>) -> String {
    use std::fmt::Write;
    let mut output = format!("–– Pkl Error ––\n{message}\n");
    for (index, frame) in frames.iter().enumerate() {
        output.push('\n');
        render_frame(&mut output, frame);
        if index == 0
            && let Some(hint) = hint
        {
            write!(output, "\n{hint}\n").unwrap();
        }
    }
    if frames.is_empty()
        && let Some(hint) = hint
    {
        write!(output, "\n{hint}\n").unwrap();
    }
    output
}

fn render_frame(output: &mut String, frame: &RenderFrame<'_>) {
    use std::fmt::Write;
    let text = frame.source.text();
    let Some(position) = frame.source.position(frame.span.start) else {
        return;
    };
    let line_start = text[..frame.span.start]
        .rfind('\n')
        .map_or(0, |index| index + 1);
    let line_end = text[line_start..]
        .find('\n')
        .map_or(text.len(), |index| line_start + index);
    let original = &text[line_start..line_end];
    let stripped = original.trim_matches(java_whitespace);
    let leading_utf16 = original
        .chars()
        .take_while(|ch| java_whitespace(*ch))
        .map(char::len_utf16)
        .sum::<usize>();
    let column = position.column_utf16.saturating_sub(leading_utf16 + 1);
    let width = frame.highlight_length_utf16.unwrap_or_else(|| {
        let end = frame
            .source
            .position(frame.span.end)
            .filter(|end| end.line == position.line)
            .map_or_else(
                || stripped.encode_utf16().count().saturating_sub(column),
                |end| end.utf16.saturating_sub(position.utf16),
            );
        end.max(1)
    });
    let prefix = format!("{} | ", position.line);
    writeln!(output, "{prefix}{stripped}").unwrap();
    writeln!(
        output,
        "{}{}",
        " ".repeat(prefix.len() + column),
        "^".repeat(width)
    )
    .unwrap();
    writeln!(output, "at {} ({})", frame.member, frame.uri).unwrap();
}

// Java Character.isWhitespace deliberately excludes the non-breaking spaces.
fn java_whitespace(ch: char) -> bool {
    matches!(ch, '\u{0009}'..='\u{000d}' | '\u{001c}'..='\u{0020}' | '\u{1680}'
        | '\u{2000}'..='\u{2006}' | '\u{2008}'..='\u{200a}' | '\u{2028}'
        | '\u{2029}' | '\u{205f}' | '\u{3000}')
}
