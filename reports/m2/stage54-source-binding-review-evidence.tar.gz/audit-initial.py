from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,subprocess,collections
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;B='9f92573a1262729158103f2a32ddf254ad1cf631'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=ROOT):return subprocess.check_output(['git',*args],cwd=cwd)
def tree(cwd,commit):
 result={}
 for item in git('ls-tree','-rz',commit,cwd=cwd).split(b'\0'):
  if item:
   head,name=item.split(b'\t',1);mode,kind,oid=head.decode().split();result[name.decode()]=(mode,kind,oid)
 return result
publication=json.loads((ROOT/'reports/m2/stage54-source-binding.json').read_bytes());report=json.loads((ROOT/'target/m2/stage54-source-binding-01/report.json').read_bytes())
assert {k:v for k,v in publication.items() if k!='archive'}==report and report['implementation_commit']==B and report['all_match'] is True and report['failures']==[]
archive=ROOT/publication['archive']['path'];archive_sha=sha(archive.read_bytes());assert archive_sha==publication['archive']['sha256'];assert archive.stat().st_size==publication['archive']['bytes']
contents={}
with tarfile.open(archive,'r|gz') as stream:
 for m in stream:
  assert m.isfile() and m.name not in contents and len(PurePosixPath(m.name).parts)==1 and m.name not in {'.','..'} and '/' not in m.name and '\\' not in m.name
  d=stream.extractfile(m).read();assert len(d)==m.size;contents[m.name]=d
manifest=json.loads(contents['MANIFEST.json']);assert set(contents)==set(manifest['files'])|{'MANIFEST.json'}
for n,v in manifest['files'].items():assert sha(contents[n])==v['sha256'] and len(contents[n])==v['bytes']
assert json.loads(contents['report.json'])==report and sha(contents['bindings.jsonl'])==report['details_sha256']
assert sha(contents['bind.py'])=='98d3649857b89f753c8937713b0842cf4348ef279cfb0a0b6ccf5c2dff9afb0c'
project=tree(ROOT,B);refs={}
for p,c in report['gitlinks'].items():
 assert project[p]==('160000','commit',c);refs[p]=tree(ROOT/p,c)
manifest_maps={};group_counts={};seen={};critical={}
for group in report['groups']:
 d=(ROOT/group['manifest']).read_bytes();assert sha(d)==group['manifest_sha256'];v=json.loads(d);assert len(v)==group['files'];manifest_maps[group['group']]=v;seen[group['group']]=set();group_counts[group['group']]=collections.Counter()
for line in contents['bindings.jsonl'].splitlines():
 row=json.loads(line);g=row['group'];path=row['path'];assert path not in seen[g];seen[g].add(path)
 assert row['matches_manifest_and_git_blob'] is True and row['sha256']==manifest_maps[g][path]
 repo='.';revision=B;gitpath=path;entries=project
 for prefix,reference in refs.items():
  if path.startswith(prefix+'/'):repo=prefix;revision=report['gitlinks'][prefix];gitpath=path[len(prefix)+1:];entries=reference;break
 assert row['repository']==repo and row['commit']==revision and row['git_path']==gitpath
 entry=entries[gitpath];assert entry[1]=='blob' and row['git_blob']==entry[2]
 assert type(row['bytes']) is int and row['bytes']>=0
 group_counts[g]['project' if repo=='.' else 'references']+=1
 if g=='final-validation-inputs':critical[path]=row
assert sum(len(v) for v in seen.values())==report['binding_rows']==167496
for group in report['groups']:
 g=group['group'];assert seen[g]==set(manifest_maps[g]);assert dict(group_counts[g])==group['counts']
# Independent byte reads from actual committed blob objects, never current workspace source.
paths=[v['path'] for v in json.loads((ROOT/'target/m2/stage54-core-checks-01/core-freeze.json').read_bytes())['files']]+['crates/pkl-runtime/examples/deprecation_fixture_probe.rs','tools/deprecation_compare.py','tools/tests/test_deprecation_compare.py','tools/platform/deprecation-session.mjs','tools/platform/deprecation-session.test.mjs','tools/platform/capture-deprecation.mjs','tools/platform/capture-deprecation.test.mjs','Cargo.lock','tools/platform/package-lock.json','tests/fixtures/m2-deprecation/oracle-evidence.tar.gz','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/member/ClassMethod.java']
critical_reads=[]
for path in paths:
 row=critical[path];cwd=ROOT if row['repository']=='.' else ROOT/row['repository'];data=git('cat-file','blob',row['git_blob'],cwd=cwd)
 assert sha(data)==row['sha256'] and len(data)==row['bytes'];assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_blob']
 critical_reads.append({'path':path,'git_blob':row['git_blob'],'sha256':sha(data),'bytes':len(data)})
record={'schema':1,'scope':'Read-only post-B binding result audit; archive streamed without complete extraction, no guest/test execution and no current workspace source freeze check. Documentation C may intentionally differ.','implementation_commit':B,'archive_sha256':archive_sha,'archive_bytes':archive.stat().st_size,'archive_members':len(contents),'safe_unique_regular_paths':True,'full_archive_manifest_and_report_match':True,'archived_bind_script_matches_preexecution_review':True,'rows':report['binding_rows'],'group_counts':{g:dict(c) for g,c in group_counts.items()},'all_row_path_sets_sha256_and_actual_tree_oids_match':True,'gitlinks':report['gitlinks'],'critical_committed_blob_reads':critical_reads,'reconstruction_scope':'All167496 recorded rows bind original catalogSHA256 and actual B/gitlink blob OIDs. 29 selected committed blobs independently re-read as bytes. Other original snapshot bytes were checked by archived bind.py execution; this audit does not repeat reading all162919 local originals. Reconstruction requires original published catalogs plus B/reference Git object availability.','blockers':[]}
(OUT/'audit.json').write_text(json.dumps(record,indent=2)+'\n');print('verified',report['binding_rows'],'critical blobs',len(critical_reads),'archive',archive_sha)
