import sys,json,subprocess,hashlib,os,platform,time
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-platform-build-session-01';sys.path.insert(0,str(ROOT/'tools'));import m1_platforms
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=m1_platforms.source_paths();before={str(p.relative_to(ROOT)):sha(p) for p in paths};(OUT/'sources-before.json').write_text(json.dumps(before,indent=2)+'\n')
command=[sys.executable,'tools/m1_platforms.py','--output','target/m2/stage39-platforms-final-01','--verify-contract'];env=os.environ.copy()
# The prescribed helper addresses ROOT/target artifacts explicitly.
env.pop('CARGO_TARGET_DIR',None);env.pop('CARGO_BUILD_TARGET',None)
record={'command':command,'cwd':str(ROOT),'python':sys.version,'host':platform.platform(),'startedUnixNs':time.time_ns(),'sourceCount':len(before),'environmentOverrides':{'CARGO_TARGET_DIR':'removed if inherited; helper uses ROOT/target','CARGO_BUILD_TARGET':'removed if inherited; target explicitly set by helper'},'cachePreparation':'../stage39-platform-preparation-01/cache-layout.json'};(OUT/'process.json').write_text(json.dumps(record,indent=2)+'\n')
with (OUT/'stdout.bin').open('wb') as stdout,(OUT/'stderr.bin').open('wb') as stderr:
 result=subprocess.run(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
after={str(p.relative_to(ROOT)):sha(p) for p in paths};(OUT/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n');record.update({'exitCode':result.returncode,'finishedUnixNs':time.time_ns(),'sourceStability':before==after,'changedSources':[p for p in before if before[p]!=after[p]],'stdoutSha256':sha(OUT/'stdout.bin'),'stderrSha256':sha(OUT/'stderr.bin')});(OUT/'process.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(result.returncode)
