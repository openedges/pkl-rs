# C05 isolated platform 원본 감사

기존 원본 evidence를 직접 대조했고 선택된 C05 platform 계약에서 새 차단 결함은 찾지 못했다. 새 evaluator, Java, Rust, Node, browser, build 또는 test를 실행하지 않았다. 감사 스크립트의 source/raw readback은 actual exit 0이다.

## 실제 실행과 분모

원본 wrapper는 session 51839, terminal 0이고 report SHA는 `864cee13fff317cd477db294a03a46e335e0a88a82945afa4eafd63da1152fa3`이다. baseline/renderer/Resource/module-preparation 네 명령의 actual terminal과 stdout/stderr hash를 대조했다.

| 비교 | 각 target API | 각 target raw success / ordinary error | 각 target session |
| --- | ---: | ---: | ---: |
| Renderer | 860 | 652 / 208 | 44 |
| Resource | 1,008 | 812 / 196 | 20 |
| Module preparation | 252 | 136 / 116 | 24 |

각 행은 Node와 Chromium에서 각각 실행됐다. ordinary error도 원래 Java가 낸 동일 오류일 때만 비교 통과이다. 총 4,240개 API의 status, expression, 두 채널의 UTF16BE와 JavaUTF8 원문, 전후 read count를 fixture에 보존된 Java raw로 직접 연결했다. 개별 binary 파일도 실제 raw JSON의 unit vector와 동일했다. 총 176개 session의 terminal slots는 0이고 reader plan 소비와 결과 소유권 확인이 기록돼 있다.

Baseline은 raw transport 전체 6,078개를 decode해 Rust/Node/browser payload가 모두 같은지 다시 비교했다. 각 target의 Java 일치는 6,076개이며 정확히 `regex-unicode-15-vs-16`, `regex-zero-width-supplementary` 두 차이가 남는다. `baseline/oracle-native` child의 strict exit 1도 보존되며, outer architecture contract exit 0과 구별한다. 과거 JavaUTF8-only fixture group의 별도 JS unit 관찰을 full UTF16 oracle 증거로 바꾸지 않았다.

## source·mode·artifact 연결

C05 release는 `93439249df0358843498ff16f62e80616a9916aa0c2faad257ad464fe1f55221`, source map은 `24e362fcbd1610e8ce9710178b3ac39464c26656014822c85e649bd99d8840d8`이다. 명시된 47,909개 regular source를 immutable snapshot과 isolated build workspace 양쪽에서 직접 읽어 hash와 mode가 동일함을 확인했다. `.cargo/config.toml`, Cargo controls, runtime stdlib literal inputs도 포함한다. baseline의 별도 source capture와 그 source map도 해당 C05 입력에 연결했다.

실제 platform build 명령/원문과 produced `semantics_probe`, N-API addon, Wasm binary·glue·declaration을 읽고 baseline 및 supplemental report의 artifact SHA와 대조했다. 이는 isolated C05 source에서 새로 build한 platform artifact 연결이다. C05 release의 다른 native renderer/module probe와 같은 binary라고 주장하지 않는다.

## browser·HTTP·도구

모든 driver는 기록한 browser executable 경로를 `chromium.launch`의 `executablePath`에 명시한다. 실제 경로의 SHA `c8509aee32abd6977968e9999769980b7a420dea05402d90042d9e5b41db15ef`, launch options, Node 실행 파일, pinned Playwright/package lock과 설치 package version을 대조했다. 설치 Playwright 전체 소스 파일을 별도로 전수 hash한 증거라고 확대하지 않는다.

HTTP가 실제 제공한 copied helper와 Wasm asset은 driver의 hash/postcheck 대상이다. Copied helper/driver 7개가 C05 candidate source와 같은 바이트임도 추가로 확인했다. 세 supplemental driver의 missing asset probe는 actual 404/empty body이며 infrastructure/browser/input-change 목록은 비었다. 이전의 default-headless-shell 경로 추정이나 writeHead-before-readFile 오류를 이번 실행의 provenance로 대체하지 않는다. 이번 기록은 explicit path와 read-before-headers 교정을 사용한다.

## typed module provider 경계

각 target의 실제 요청을 unordered fixture provider fact에 exact identity로 다시 join했다. capabilities 144, has-element 392, resolve 36, load-source 36, counted reader 44, uncounted typed denied read 28개이다. 모든 실제 URI와 countedReader disposition이 맞고, pending collect 수 및 실제 요청 순서로 만든 per-call observable event projection이 raw/fixture의 740개 Java observable event와 일치했다.

이는 입력 fact 전체의 호출·순서를 Java가 직접 관찰했다는 뜻이 아니다. Java가 보지 않은 capabilities/hasElement SPI 순서나 browser의 실제 filesystem을 지원했다고 주장하지 않는다. denied read 28개를 reader 실행 횟수에 더하지 않았다. primary/query admission 등 fixture의 outsideContract 이벤트도 여전히 별도 의무다.

## 초기 setup 실패와 reference link 복구

Preparation session 94291은 regular-file snapshot에 빠진 11개 tracked reference symlink를 Git status에서 검출해 build 전에 exit 1로 끝났다. 원문과 terminal을 그대로 보존했다. Session 24154는 pinned reference mode 120000 blob만 복구했고 exit 0이었다. literal target을 real pinned checkout과 비교하고 Git blob SHA1, target SHA256, captured `ls-tree` mode/blob를 대조했다. 두 reference clone의 원래 clean-status 출력도 확인했다. 이 11개 link를 과거 C05 regular-source map에 소급 추가하지 않았다.

감사 자체 초기 `preparation-binding.json`의 `restoredSymlinks` 필드는 양쪽 원본·복사 link 경로와 runtime alias를 합친 23개를 가리켜 이름이 부정확했다. 초기 바이트를 `execution-01/preparation-binding.initial.json`에 보존했고, 최종 review 출력은 literal link path 23개와 복구된 reference path 11개를 분리한다. 원본 producer 파일은 수정하지 않았다.

## 안정성과 남은 범위

명시 regular 입력 113,609개와 literal link 경로 23개의 전후 content/mode/target 변화는 0이다. cache/source tree의 recursive walk는 사용하지 않았다. 선택은 고정 source/fixture maps, command 이름과 session/call index로 만들었으며 exact cache 경계는 `traversal-policy.json`에 남겼다.

이 감사는 C05 intermediate platform result에 한정한다. 최신 live heap/lifecycle test edits, 전체 workspace/Rust5 및 full M2 완료를 입증하지 않는다. Renderer의 별도 policy 84개와 Java07 이후 새 identity/capture/close 대조군, Resource 미선택 264개, Module 미선택 48개, 원본 CLI와 전체 언어·성능 gate는 이 선택 실행 밖이다. Portable collection/owned-result 검사는 driver가 수행한 측정이며 Java GC 이벤트와 일치한다는 주장이 아니다.
