"""Bind already completed readback to copied drivers and publish its review only."""
from pathlib import Path
import json
import hashlib

OUT=Path(__file__).resolve().parent
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
WORK=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2/stage47-c05-platform-workspace-01')
RUN=WORK/'target/m2/stage47-platform-acquisition-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
def obj(p):return json.loads(p.read_bytes())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
assert obj(OUT/'execution-01/execution.json')['exitCode']==0
checks=[]
for name,driver in [('renderer','compare-renderer.mjs'),('resource','compare-resource.mjs'),('module-preparation','compare-module-preparation.mjs')]:
    for file in [driver,'resource-session.mjs']+(['module-preparation-session.mjs'] if name=='module-preparation' else []):
        copied=RUN/name/file;source=WORK/'tools/platform'/file
        assert copied.read_bytes()==source.read_bytes()
        checks.append({'copy':str(copied),'candidateSource':str(source),'sha256':sha(copied.read_bytes())})
    er=obj(RUN/name/'execution.json')
    assert er['selectedContractPassed'] and not er['fullCompatibilityPassed']
    for target in ['node','browser']:
        assert er['targets'][target]['rawApiCounts']=={'pass':er['selectedApiCallsPerTarget']}
        assert er['targets'][target]['selectedContractPassed']
prep=OUT/'preparation-binding.json'
initial=prep.read_bytes()
(OUT/'execution-01/preparation-binding.initial.json').write_bytes(initial)
data=json.loads(initial)
count=data.pop('restoredSymlinks')
original=obj(MAIN/'target/m2/stage47-c05-platform-preparation-02/report.json')
data['literalLinkPathsReadThroughPreparation']=count
data['restoredReferenceSymlinkPaths']=len(original['restoredReferenceSymlinks'])
data['fieldNameQualification']='The initial audit output used restoredSymlinks for all literal link paths read, including both original and copied reference paths and a runtime alias. Its exact initial bytes are preserved. The restored reference path count is recorded separately here.'
save(prep,data)
save(OUT/'copied-driver-binding.json',{'checks':checks,
 'preparationFieldCorrection':{'initialSha256':sha(initial),'finalSha256':sha(prep.read_bytes()),
 'literalLinkPathsReadThroughPreparation':count,'restoredReferenceSymlinkPaths':data['restoredReferenceSymlinkPaths']},
 'scope':'Additional read-only check of copied served helper/driver bytes. New review output field-name correction only; no original producer evidence/source changes or new evaluator run.'})
print(json.dumps({'copiedDriverAndHelperChecks':len(checks),'restoredReferenceSymlinkPaths':data['restoredReferenceSymlinkPaths']}))
