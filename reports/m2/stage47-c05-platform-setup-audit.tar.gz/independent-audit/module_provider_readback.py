"""Join captured actual Host requests to unordered facts without executing them."""
from pathlib import Path
import json
import hashlib
import collections

OUT=Path(__file__).resolve().parent
RUN=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2/stage47-c05-platform-workspace-01/target/m2/stage47-platform-acquisition-01/module-preparation')
bound=json.loads((OUT/'inputs-before.json').read_bytes())
def read(path):
    data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==bound[str(path)]['sha256'];return json.loads(data)
fields={'capabilities':['kind','originalUri','importerOriginalUri','importerResolvedUri'],
 'has-element':['kind','originalUri','importerOriginalUri','importerResolvedUri'],
 'resolve':['kind','originalUri','importUri','importerOriginalUri','importerResolvedUri'],
 'load-source':['kind','originalUri','resolvedUri','sourceUri']}
def key(request):return tuple(request[n] for n in fields[request['kind']])
fixtures=read(RUN/'fixtures.json')['fixtures'];results=[]
for target in ['node','browser']:
    rows=read(RUN/(target+'.raw.json'));counts=collections.Counter();sessions=[]
    for fixture,actual in zip(fixtures,rows):
        providers={key(p['request']):p for p in fixture['moduleProviders']}
        reads={p['uri']:p for p in fixture['readProviders']}
        assert len(providers)==len(fixture['moduleProviders']) and len(reads)==len(fixture['readProviders'])
        projected=[[] for _ in actual['calls']];counted=[];pending=0
        for request in actual['moduleRequests']:
            index=request['callIndex'];assert 0<=index<len(projected)
            assert isinstance(request['token'],str) and request['token']
            if request['kind']=='module-request':
                module=request['module'];provider=providers[key(module)]
                assert module['id'].isdecimal()
                assert all(k in fields[module['kind']] or k=='id' or v is None for k,v in module.items())
                counts[module['kind']]+=1;pending+=1
            else:
                assert request['kind']=='read';provider=reads[request['uri']]
                assert request['countedReader']==provider['countedReader']
                counts['counted-read' if provider['countedReader'] else 'uncounted-denied-read']+=1
                if provider['countedReader']:counted.append(request['uri'])
                else:
                    assert provider['result']['kind']=='security-manager-exception';pending+=1
            projected[index].extend(provider['observableEvents'])
        assert counted==actual['readerUris']
        assert pending==actual['architecture']['pendingModuleOrDeniedReadCollections']
        assert projected==actual['observableEventsByCall']==[c['observableEvents'] for c in actual['calls']]
        assert projected==[c['observableEvents'] for c in fixture['expected']]
        sessions.append({'id':actual['id'],'repeat':actual['repeat'],'session':actual['session'],
          'actualRequestRows':len(actual['moduleRequests']),'countedReaderCalls':len(counted),
          'pendingModuleOrDeniedReadCollections':pending})
    results.append({'target':target,'requestCounts':dict(counts),'sessions':sessions})
(OUT/'module-provider-readback.json').write_text(json.dumps({'targets':results,
 'qualification':'Every actual captured request has an exact configured provider identity; actual ordered provider projections match Java observable event selection. Unused unordered facts are not claimed Java SPI calls; uncounted typed denied reads are distinct from reader execution.'},indent=2)+'\n')
print(json.dumps({'targets':[{k:v for k,v in r.items() if k!='sessions'} for r in results]}))
