"""Audit existing C05 platform raw outputs and explicit source maps; no execution."""
from pathlib import Path
import collections
import hashlib
import json
import os
import stat
import struct

OUT=Path(__file__).resolve().parent
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
STAGE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
CAND=STAGE/'target/m2/stage47-implementation-01/renderer-candidate-build-05'
WORK=STAGE/'target/m2/stage47-c05-platform-workspace-01'
RUN=WORK/'target/m2/stage47-platform-acquisition-01'
PINS={CAND/'release.json':'93439249df0358843498ff16f62e80616a9916aa0c2faad257ad464fe1f55221',
      CAND/'source-after.json':'24e362fcbd1610e8ce9710178b3ac39464c26656014822c85e649bd99d8840d8',
      RUN/'report.json':'864cee13fff317cd477db294a03a46e335e0a88a82945afa4eafd63da1152fa3',
      RUN/'baseline/report.json':'fce3424bc7b5a617f467a60f3e91caec0b40994a048f7c1546b0386ec155e06b'}
inputs={};links={}
def digest(b):return hashlib.sha256(b).hexdigest()
def read(p):
    p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode),p
    data=p.read_bytes();row={'sha256':digest(data),'bytes':len(data),'mode':stat.S_IMODE(s.st_mode)}
    assert inputs.setdefault(str(p),row)==row,p
    if p in PINS:assert row['sha256']==PINS[p],p
    return data
def obj(p):return json.loads(read(p))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
def link(p):
    assert stat.S_ISLNK(p.lstat().st_mode),p
    data=os.fsencode(os.readlink(p));row={'targetHex':data.hex(),'sha256':digest(data),'bytes':len(data)}
    assert links.setdefault(str(p),row)==row,p
    return data
def known_runtime(p):
    p=Path(p)
    if p.is_symlink():link(p)
    return read(p.resolve(strict=True))
release=obj(CAND/'release.json');sources=obj(CAND/'source-after.json');modes=obj(CAND/'source-modes.json')
assert digest(read(CAND/'source-modes.json'))==release['source_modes_sha256']
assert set(modes)==set(sources)
assert obj(RUN/'candidate-release.json')==release and obj(RUN/'candidate-sources.json')==sources
source_rows=[]
for name,expected in sources.items():
    relative=Path(name);assert not relative.is_absolute() and '..' not in relative.parts
    for root in [CAND/'sources',WORK]:
        path=root/name;data=read(path)
        assert digest(data)==expected and stat.S_IMODE(path.lstat().st_mode)==modes[name],path
    source_rows.append({'path':name,'sha256':expected,'mode':modes[name]})
save('candidate-source-binding.json',{'releaseSha256':PINS[CAND/'release.json'],
 'sourceMapSha256':PINS[CAND/'source-after.json'],'paths':source_rows,
 'qualification':'Both immutable snapshot and isolated build workspace directly hashed with exact mode. Restored reference symlinks are separate and are not retroactively inserted into this regular-file map.'})

# No tree walker is used. Record exact build/tool-cache boundaries before any
# optional directory enumeration; direct authenticated files may be read within.
save('traversal-policy.json',{'recursiveTraversalUsed':False,'selection':'Explicit authenticated source/fixture maps, session indexes and producer command names only.',
 'exactCacheBoundaries':[str(WORK/'target/debug'),str(WORK/'target/release'),
 str(WORK/'target/wasm32-unknown-unknown'),str(WORK/'tools/platform/node_modules'),
 str(WORK/'.cache'),str(WORK/'external/pkl/.git'),str(WORK/'external/pkl-pantry/.git')],
 'directExceptions':['Pinned runtime binaries, installed Playwright package JSONs, captured artifacts and explicitly named output metadata only. No generic build-name exclusion.']})
preps=[]
for number in [1,2]:
    root=MAIN/f'target/m2/stage47-c05-platform-preparation-{number:02}'
    r=obj(root/'report.json');terminal=obj(root/'outer-terminal.json');read(root/'prepare.py');read(root/'active.json')
    assert terminal['reportSha256']==digest(read(root/'report.json'))
    for command in r['commands']:
        for ch in ['stdout','stderr']:
            assert digest(read(root/(command['name']+'.'+ch+'.bin')))==command[ch+'Sha256']
    assert r['releaseSha256']==PINS[CAND/'release.json'] and r['sourceMapSha256']==PINS[CAND/'source-after.json']
    preps.append({'root':str(root),'reportSha256':digest(read(root/'report.json')),'terminal':terminal})
    if number==1:
        assert read(root/'pkl-clean.stdout.bin')
    else:
        assert not read(root/'pkl-clean.stdout.bin') and not read(root/'pkl-pantry-clean.stdout.bin')
        assert read(root/'pkl-head.stdout.bin')==b'e51fb2f91774265666f94980ec630db794a4db2d\n'
        trees={}
        for ref in ['pkl','pkl-pantry']:
            raw=read(root/(ref+'-tree.stdout.bin'));tree={}
            for entry in raw.split(b'\0'):
                if not entry:continue
                header,path=entry.split(b'\t',1);mode,kind,blob=header.decode().split(' ')
                tree[os.fsdecode(path)]=(mode,kind,blob)
            trees[ref]=tree
        for restored in r['restoredReferenceSymlinks']:
            data=link(WORK/'external'/restored['reference']/restored['path'])
            original=link(STAGE/'external'/restored['reference']/restored['path'])
            assert data==original and data.hex()==restored['targetHex'] and digest(data)==restored['targetSha256']
            blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            assert blob==restored['blob']
            assert trees[restored['reference']][restored['path']]==('120000','blob',blob)
        for path,expected in r['runtimeTools'].items():assert digest(known_runtime(WORK/path))==expected
assert preps[0]['terminal']['exitCode']==1 and preps[1]['terminal']['exitCode']==0
save('preparation-binding.json',{'records':preps,'restoredSymlinks':len(links),
 'qualification':'Initial setup failure retained. Restored reference links are pinned Git mode120000 blobs whose literal target matches real pinned checkout; no reference update or candidate regular-file change.'})

top=obj(RUN/'report.json');terminal=obj(RUN/'outer-terminal.json')
assert terminal['exitCode']==0 and terminal['reportSha256']==PINS[RUN/'report.json']
assert top['candidateReleaseSha256']==PINS[CAND/'release.json']
assert top['candidateSourceMapSha256']==PINS[CAND/'source-after.json']
assert not top['candidateSourceChangesBefore'] and not top['sourceChangesAfter'] and not top['bindingArtifactChanges']
assert digest(read(RUN/'run.py'))==top['runnerSha256']
assert read(RUN/'cargo-config.toml')==read(WORK/'.cargo/config.toml')
for ch in top['commands']:
    assert ch['exitCode']==0
    for side in ['stdout','stderr']:assert digest(read(RUN/(ch['name']+'.'+side+'.bin')))==ch[side+'Sha256']
for rel,expected in top['bindingArtifactsBefore'].items():assert digest(read(RUN/rel))==expected
for k in ['nodeExecutable','pythonExecutable','wasmBindgen']:
    assert digest(known_runtime(top[k]))==top[k+'Sha256']

base=RUN/'baseline';br=obj(base/'report.json');bm=obj(base/'sources.json')
assert bm==br['source_hashes']
for name,expected in bm.items():
    assert sources[name]==expected
    assert digest(read(base/'sources'/name))==expected
for command in obj(base/'commands.json'):
    assert command['exit_code'] in ([0,1] if command['name']=='oracle-native' else [0])
    read(base/(command['name']+'.stdout.bin'));read(base/(command['name']+'.stderr.bin'))
for name,expected in br['artifacts'].items():assert digest(read(base/name))==expected
native=obj(base/'oracle-native/report.json');cases=obj(base/'oracle-native/cases.json')['cases']
assert obj(WORK/'tests/fixtures/m1/semantics/cases.json')['cases']==cases
captures={}
for target,relative in [('java','oracle-native/java.stdout.bin'),('rust','oracle-native/rust.stdout.bin'),('node','execution/node.stdout.bin'),('browser','execution/browser.stdout.bin')]:
    data=read(base/relative);assert data.endswith(b'\n')
    lines=data[:-1].split(b'\n');assert len(lines)==len(cases)
    assert all(len(line)%2==0 and all(c in b'0123456789abcdef' for c in line) for line in lines)
    captures[target]=[bytes.fromhex(line.decode()) for line in lines]
for target,record in native['records'].items():
    for ch in ['stdout','stderr']:assert digest(read(base/'oracle-native'/(target+'.'+ch+'.bin')))==record[ch+'_sha256']
    assert record['exit_code']==0
baseline_rows=[];baseline_gaps={t:[] for t in ['rust','node','browser']}
for index,case in enumerate(cases):
    values={t:rows[index] for t,rows in captures.items()}
    row=br['comparisons'][index];assert row['id']==case['id']
    assert values['rust']==values['node']==values['browser']
    for target in values:assert digest(values[target])==row['sha256'][target]
    for target in baseline_gaps:
        match=values[target]==values['java'];assert match==row['oracle_matches'][target]
        if not match:baseline_gaps[target].append(case['id'])
    if any(values[t]!=values['java'] for t in baseline_gaps):
        assert row['mismatched_bytes_hex']=={t:v.hex() for t,v in values.items()}
        baseline_rows.append(row)
assert all(set(rows)==set(br['known_gaps']) for rows in baseline_gaps.values())
be=obj(base/'execution/execution.json');assert be==br['execution']
for n in ['node-checks.json','browser-checks.json','browser-launch.json','node-legacy-utf8-observations.json','browser-legacy-utf8-observations.json']:read(base/'execution'/n)
for ch in ['node','browser']:assert obj(base/'execution'/(ch+'-checks.json'))==be[ch+'Checks']
assert be['browserLaunchOptions']['executablePath']==be['browserExecutable']
assert digest(known_runtime(be['browserExecutable']))==be['browserExecutableSha256']
save('baseline-raw-audit.json',{'total':len(cases),'sharedEqual':len(cases),
 'oracleMatches':{t:len(cases)-len(g) for t,g in baseline_gaps.items()},'rawKnownGaps':baseline_rows,
 'capturedCommands':obj(base/'commands.json'),
 'qualification':'Decode complete canonical hex transport only; compare raw payload bytes without trimming or normalization. Historical Java-UTF8-only groups retain separate JS-unit observations.'})

def unit_bytes(units):
    assert all(isinstance(n,int) and 0<=n<=65535 for n in units)
    return b''.join(struct.pack('>H',n) for n in units)
def java_utf8(units):return unit_bytes(units).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
def counter(raw):return dict(line.split('=',1) for line in raw.decode().splitlines())
supplements=[];all_calls=[]
for name,fixture_name in [('renderer','m2-renderer-portable'),('resource','m2-resource-portable'),('module-preparation','m2-module-portable')]:
    root=RUN/name;fixture_root=WORK/'tests/fixtures'/fixture_name
    er=obj(root/'execution.json');bundle=obj(root/'fixtures.json');assert bundle==obj(fixture_root/'fixtures.json')
    assert er['preflight']==obj(root/'preflight.process.json') and er['preflight']['exitCode']==0
    read(root/'preflight.stdout.bin');read(root/'preflight.stderr.bin')
    assert not er['infrastructureErrors'] and not er['browserErrors'] and not er['changedInputs']
    assert er['serverMissingAssetProbe']['status']==404 and er['serverMissingAssetProbe']['bodyHex']==''
    assert er['browserLaunchOptions']['executablePath']==er['browserExecutable']
    assert digest(known_runtime(er['browserExecutable']))==er['browserExecutableSha256']
    for path,expected in er['artifactAndInputHashes'].items():assert digest(read(Path(path)))==expected,path
    manifest=obj(fixture_root/'manifest.json')
    for relative,record in manifest['files'].items():
        data=read(fixture_root/relative);assert digest(data)==record['sha256'] and len(data)==record['bytes']
    provenance=obj(fixture_root/'provenance.json') if fixture_name!='m2-renderer-portable' else None
    reader_total={};counts={};events={}
    for target in ['node','browser']:
        raw=obj(root/(target+'.raw.json'));assert len(raw)==len(bundle['fixtures'])
        count=collections.Counter();reader_total[target]=0;events[target]=0
        for session_index,(f,a) in enumerate(zip(bundle['fixtures'],raw)):
            assert (f['id'],f['repeat'],f['session'])==(a['id'],a['repeat'],a['session'])
            assert a['constructorError'] is None and a['acquisitionError'] is None
            assert len(a['calls'])==len(f['expected'])==len(f['expressions'])
            assert a['readerUris']==[p['uri'] for p in f['readerPlan']]
            reader_total[target]+=len(a['readerUris'])
            architecture=a['architecture'];assert architecture['terminalSlots']==0 and architecture['ownedResultsStable'] and architecture['consumedReaderPlan']
            directory=root/target/str(session_index)
            assert obj(directory/'actual.json')==a and obj(directory/'expected.json')==f['expected']
            obj(directory/'comparison.json')
            if name=='module-preparation':assert len(a['observableEventsByCall'])==len(a['calls'])
            for index,(expected,call) in enumerate(zip(f['expected'],a['calls'])):
                assert call['index']==index and call['expression']==f['expressions'][index]
                for field in ['status','stdoutUnits','stderrUnits','readsBefore','readsAfter']:assert call[field]==expected[field],(name,target,session_index,index,field)
                assert call['status'] in ['success','error']
                if call['status']=='error':assert call['disposition']=='language-error'
                if name=='module-preparation':
                    assert call['observableEvents']==expected['observableEvents']==a['observableEventsByCall'][index]
                    events[target]+=len(call['observableEvents'])
                # Link each expected channel/status/count back to captured Java
                # bytes, separately from trusting the comparison booleans.
                if name=='renderer':
                    group,case=f['id'].split('/',1)
                    prefix=fixture_root/'provenance'/group/'cases'/case/str(f['repeat'])/'calls'/('session-'+str(f['session']))/('outer-'+str(index))
                    java_read=lambda suffix:read(Path(str(prefix)+'.'+suffix+'.bin'))
                elif name=='resource':
                    sessions=[s for s in provenance['sessions'] if (s['id'],s['repeat'],s['session'])==(f['id'],f['repeat'],f['session'])]
                    assert len(sessions)==1
                    prefix=fixture_root/sessions[0]['selectedRawJava'][index]['rawLocalPrefix']
                    java_read=lambda suffix:read(Path(str(prefix)+'.'+suffix+'.bin'))
                else:
                    group,case=f['id'].split('/',1)
                    original=Path(provenance['pins']['groups'][group]['root'])/'cases'/case/str(f['repeat'])/'calls'/('session-'+str(f['session']))/('outer-'+str(index))
                    def java_read(suffix):
                        record=provenance['originalPaths'][str(original)+'.'+suffix+'.bin']
                        data=read(fixture_root/record['path']);assert digest(data)==record['sha256'];return data
                assert java_read('status')==(expected['status']+'\n').encode()
                assert java_read('expression')==f['expressions'][index].encode()
                for side in ['before','after']:
                    cnt=int(counter(java_read('counters-'+side))['read'])
                    assert java_read('reads-'+side)==str(cnt).encode() and cnt==expected['reads'+side.title()]
                channel_hashes={}
                for channel in ['stdout','stderr']:
                    units=unit_bytes(call[channel+'Units']);utf8=java_utf8(call[channel+'Units'])
                    assert units==java_read(channel+'.code-units') and utf8==java_read(channel)
                    assert utf8.hex()==expected[channel+'Hex']
                    assert read(directory/f'{index}.{channel}.utf16be.bin')==units
                    assert read(directory/f'{index}.{channel}.java-utf8.bin')==utf8
                    channel_hashes[channel]={'utf16be':digest(units),'javaUtf8':digest(utf8)}
                count[call['status']]+=1
                all_calls.append({'group':name,'target':target,'sessionIndex':session_index,'callIndex':index,'status':call['status'],'channels':channel_hashes})
        counts[target]=dict(count)
    assert er['selectedApiCallsPerTarget']==sum(len(f['expressions']) for f in bundle['fixtures'])
    supplements.append({'group':name,'executionSha256':digest(read(root/'execution.json')),
        'sessionsPerTarget':len(bundle['fixtures']),'callsPerTarget':er['selectedApiCallsPerTarget'],
        'counts':counts,'readerRequests':reader_total,'observableProjectionEvents':events,
        'terminalSlotsAllZero':True,'missingAsset404EmptyBody':True,
        'unselectedOrOtherBoundaries':bundle['unexecutedApiBoundaries']})

package=obj(WORK/'tools/platform/package.json');lock=obj(WORK/'tools/platform/package-lock.json')
pin=package['devDependencies']['playwright']
for name in ['playwright','playwright-core']:
    assert obj(WORK/'tools/platform/node_modules'/name/'package.json')['version']==pin
    assert lock['packages']['node_modules/'+name]['version']==pin
save('supplemental-raw-audit.json',{'targets':supplements,'fullChannelCalls':len(all_calls),'callBindings':all_calls,
 'qualification':'Actual full channel bytes and declared reader/observable projections matched. Owned-view stability and collection counts remain source-bound driver measurements, not independent replay or Java GC equivalence. No policy SPI order or actual browser filesystem claim.'})
save('inputs-before.json',inputs);save('literal-links-before.json',links)
changes=[]
for path,before in inputs.items():
    p=Path(path);s=p.lstat();data=p.read_bytes();after={'sha256':digest(data),'bytes':len(data),'mode':stat.S_IMODE(s.st_mode)}
    if before!=after:changes.append({'path':path,'before':before,'after':after})
for path,before in links.items():
    p=Path(path);assert stat.S_ISLNK(p.lstat().st_mode);data=os.fsencode(os.readlink(p))
    after={'targetHex':data.hex(),'sha256':digest(data),'bytes':len(data)}
    if before!=after:changes.append({'path':path,'before':before,'after':after})
assert not changes,changes
save('source-stability.json',{'explicitRegularInputs':len(inputs),'explicitLiteralLinks':len(links),'changes':changes})
print(json.dumps({'sourcePaths':len(sources),'baseline':len(cases),'baselineGaps':baseline_gaps,
 'supplementalFullChannelCalls':len(all_calls),'explicitInputs':len(inputs),'literalLinks':len(links),'changes':changes}))
