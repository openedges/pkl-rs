"""Prepare an isolated, source-identical C05 workspace for actual platform checks."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys

MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
LIVE = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
OUT = Path(__file__).resolve().parent
WORK = LIVE / 'target/m2/stage47-c05-platform-workspace-01'
RELEASE = LIVE / 'target/m2/stage47-implementation-01/renderer-candidate-build-05/release.json'

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

assert not (OUT / 'report.json').exists()
assert not WORK.exists()
release = json.loads(RELEASE.read_bytes())
assert sha(RELEASE) == '93439249df0358843498ff16f62e80616a9916aa0c2faad257ad464fe1f55221'
source_map = Path(release['source_map'])
mode_map = Path(release['source_modes'])
assert sha(source_map) == release['source_map_sha256']
assert sha(mode_map) == release['source_modes_sha256']
sources = json.loads(source_map.read_bytes())
modes = json.loads(mode_map.read_bytes())
snapshot = Path(release['source_snapshot'])
assert set(sources) == set(modes)
report = {'schema': 1, 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Isolated C05 platform preparation only. Actual platform execution is a separate record.',
          'workspace': str(WORK), 'releaseSha256': sha(RELEASE),
          'sourceMapSha256': sha(source_map), 'sourceModesSha256': sha(mode_map),
          'baseCommit': release['base_commit'], 'commands': [], 'copiedSources': 0,
          'hardlinkedReadOnlyReportSources': 0, 'sourceCount': len(sources)}
save('report.json', report)

def execute(name, argv, cwd=MAIN):
    argv = list(map(str, argv))
    with (OUT / f'{name}.stdout.bin').open('wb') as stdout, (OUT / f'{name}.stderr.bin').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=cwd, stdout=stdout, stderr=stderr)
        save('active.json', {'name': name, 'pid': process.pid, 'argv': argv})
        code = process.wait()
    report['commands'].append({'name': name, 'argv': argv, 'cwd': str(cwd), 'pid': process.pid,
                               'exitCode': code, 'stdoutSha256': sha(OUT / f'{name}.stdout.bin'),
                               'stderrSha256': sha(OUT / f'{name}.stderr.bin')})
    save('report.json', report)
    print(f'{name}: exit {code}', flush=True)
    assert code == 0, name

execute('worktree-create', ['git', 'worktree', 'add', '--detach', '--no-checkout', WORK, release['base_commit']])
execute('worktree-index', ['git', 'read-tree', release['base_commit']], WORK)
for reference in ['pkl', 'pkl-pantry']:
    execute(f'{reference}-clone', ['git', 'clone', '--shared', '--no-checkout', LIVE / 'external' / reference,
                                  WORK / 'external' / reference])
    execute(f'{reference}-index', ['git', 'read-tree', 'HEAD'], WORK / 'external' / reference)
for index, (name, expected) in enumerate(sources.items(), 1):
    original = snapshot / name
    assert original.is_file() and not original.is_symlink(), name
    assert sha(original) == expected and stat.S_IMODE(original.stat().st_mode) == modes[name], name
    destination = WORK / name
    assert not destination.exists(), name
    destination.parent.mkdir(parents=True, exist_ok=True)
    if name.startswith('reports/'):
        os.link(original, destination)
        report['hardlinkedReadOnlyReportSources'] += 1
    else:
        shutil.copy2(original, destination)
        report['copiedSources'] += 1
    assert sha(destination) == expected and stat.S_IMODE(destination.stat().st_mode) == modes[name], name
    if index % 10000 == 0:
        print(f'verified {index}/{len(sources)} source paths', flush=True)
report['sourceBytesAndModesEqual'] = True
for reference in ['pkl', 'pkl-pantry']:
    execute(f'{reference}-head', ['git', 'rev-parse', 'HEAD'], WORK / 'external' / reference)
    execute(f'{reference}-clean', ['git', 'status', '--porcelain', '--untracked-files=all'], WORK / 'external' / reference)
    assert (OUT / f'{reference}-clean.stdout.bin').read_bytes() == b''
for relative in ['.cache/oracle/pkl-tools-0.32.0.jar', '.cache/m1-tools/bin/wasm-bindgen']:
    source = LIVE / relative
    destination = WORK / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    assert sha(source) == sha(destination)
    report.setdefault('runtimeTools', {})[relative] = sha(destination)
execute('npm-ci', ['npm', 'ci', '--ignore-scripts', '--prefix', 'tools/platform'], WORK)
execute('oracle-verify', [sys.executable, 'tools/oracle.py', 'verify'], WORK)
acquisition = WORK / 'target/m2/stage47-platform-acquisition-01'
acquisition.mkdir(parents=True)
runner = LIVE / 'target/m2/stage47-platform-acquisition-01/run.py'
shutil.copy2(runner, acquisition / 'run.py')
report['acquisitionRunner'] = str(acquisition / 'run.py')
report['acquisitionRunnerSha256'] = sha(runner)
report['sourceChangesAfter'] = [name for name, expected in sources.items()
                               if sha(WORK / name) != expected or stat.S_IMODE((WORK / name).stat().st_mode) != modes[name]]
assert report['sourceChangesAfter'] == []
report['finishedUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
save('report.json', report)
save('active.json', {'terminal': True, 'exitCode': 0})
print(json.dumps({key: report[key] for key in ['workspace', 'sourceCount', 'copiedSources',
                                            'hardlinkedReadOnlyReportSources', 'sourceChangesAfter']}), flush=True)
