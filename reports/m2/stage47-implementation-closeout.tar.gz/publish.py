"""Publish the root's final source/index, installation and claim reviews."""
from pathlib import Path
import base64
import datetime
import hashlib
import json
import shutil
import subprocess
import sys

main = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
root = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
out = Path(__file__).parent
stage = out / 'staging'
stage.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
directories = [
    'stage47-final-index-review-01',
    'stage47-core-publication-c-review-01',
    'stage47-checkpoint-claim-review-01',
    'stage47-c06-platform-installation-01',
    'stage47-core-installation-01',
    'stage47-oracle-installation-01',
    'stage47-post-c06-docs-01',
    'stage47-frame-identity-installed-checks-01',
    'stage47-metadata-integration-01',
    'stage47-manifest-refresh-01',
]
rows = []
for label in directories:
    source = main / 'target/m2' / label
    target = stage / label
    target.mkdir()
    # These known review directories contain small direct files. Never descend.
    for p in sorted(source.iterdir()):
        if p.is_dir():
            continue
        assert p.is_file() and not p.is_symlink(), p
        dest = target / p.name
        shutil.copy2(p, dest)
        assert sha(p) == sha(dest)
        rows.append({'source': str(p), 'member': str(dest.relative_to(stage)), 'sha256': sha(p), 'bytes': p.stat().st_size})
shutil.copy2(__file__, stage / 'publish.py')
shutil.copy2(root / 'tools/evidence.py', stage / 'evidence.py')
(stage / 'selection.json').write_text(json.dumps(rows, indent=2) + '\n')
archive = root / 'reports/m2/stage47-implementation-closeout.tar.gz'
assert not archive.exists()
commands = []
for operation in ['create', 'verify']:
    argv = [sys.executable, str(stage / 'evidence.py'), operation]
    if operation == 'create':
        argv.append(str(stage))
    argv.append(str(archive))
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    child = subprocess.Popen(argv, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = child.communicate()
    (out / (operation + '.stdout.bin')).write_bytes(stdout)
    (out / (operation + '.stderr.bin')).write_bytes(stderr)
    commands.append({'argv': argv, 'cwd': str(root), 'pid': child.pid, 'exitCode': child.returncode, 'startedUtc': start, 'finishedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'stdoutBase64': base64.b64encode(stdout).decode(), 'stderrBase64': base64.b64encode(stderr).decode()})
    assert child.returncode == 0, commands[-1]
for row in rows:
    assert sha(Path(row['source'])) == row['sha256']
index = {'schema': 1, 'scope': 'Root source/index binding, exact installation receipts and independent claim reviews; no new evaluation or CI result.', 'archives': [{'path': 'reports/m2/' + archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size}], 'selectedOriginalFiles': len(rows), 'selectionSha256': sha(stage / 'selection.json'), 'commands': commands, 'allOriginalInputsStable': True, 'candidateRuntimeInputsUnchanged': True, 'sourceIndexBinding': {'path': 'reports/m2/stage47-implementation-source-binding.json', 'sha256': sha(root / 'reports/m2/stage47-implementation-source-binding.json')}, 'claimReview': {'path': 'reports/m2/stage47-implementation-review.json', 'sha256': sha(root / 'reports/m2/stage47-implementation-review.json')}, 'actualCommitBinding': 'The recorded staged code/fixture inputs are checked against the actual commit after committing. This publication adds reports only.'}
(root / 'reports/m2/stage47-implementation-closeout.json').write_text(json.dumps(index, indent=2) + '\n')
(out / 'report.json').write_text(json.dumps(index, indent=2) + '\n')
print(json.dumps({'files': len(rows), 'archiveBytes': archive.stat().st_size, 'commandsPassed': len(commands)}), flush=True)
