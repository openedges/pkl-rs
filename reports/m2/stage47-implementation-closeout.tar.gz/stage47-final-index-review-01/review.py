"""Bind the frozen C06 code/fixtures to the staged implementation checkpoint."""
from pathlib import Path
import datetime
import hashlib
import json
import stat
import subprocess

root = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
out = Path(__file__).parent
candidate = root / 'target/m2/stage47-implementation-01/renderer-candidate-build-06'
sha = lambda data: hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

sources = json.loads((candidate / 'source-after.json').read_text())
modes = json.loads((candidate / 'source-modes.json').read_text())
assert sha((candidate / 'source-after.json').read_bytes()) == 'f736de4eef08949b42bca21b276da80ee1c914b5ce6dbd442fcc636feb5738f1'
entries = {}
for record in git('ls-files', '--stage', '-z').split(b'\0'):
    if not record:
        continue
    metadata, path = record.split(b'\t', 1)
    mode, oid, stage = metadata.decode().split()
    assert stage == '0'
    entries[path.decode()] = {'mode': mode, 'oid': oid}
changed = [p.decode() for p in git('diff', '--cached', '--name-only', '-z').split(b'\0') if p]
assert not any(p.startswith('external/') for p in changed)
allowed_docs = {'PLAN.md', 'docs/architecture.md', 'docs/m2-json-rendering.md'}
matched = []
documentation = []
for path, expected in sources.items():
    if path.startswith(('external/', 'reports/')):
        continue
    entry = entries[path]
    p = root / path
    assert p.is_file() and not p.is_symlink(), path
    data = p.read_bytes()
    actual = sha(data)
    assert stat.S_IMODE(p.stat().st_mode) == modes[path], (path, 'mode changed')
    object_id = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert object_id == entry['oid'], (path, 'index differs from working bytes')
    if actual != expected:
        assert path in allowed_docs, (path, 'unexpected post-C06 change')
        documentation.append({'path': path, 'candidateSha256': expected, 'stagedSha256': actual, 'gitBlob': object_id})
    else:
        matched.append({'path': path, 'sha256': actual, 'gitBlob': object_id})
assert {row['path'] for row in documentation} == allowed_docs
save('candidate-index-bindings.json', {'matched': matched, 'documentationDelta': documentation})

# Read every changed staged blob directly, including all newly published archives.
process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
staged = []
for path in changed:
    entry = entries[path]
    assert path in sources or path.startswith('reports/m2/'), (path, 'new unchecked implementation input')
    process.stdin.write((entry['oid'] + '\n').encode())
    process.stdin.flush()
    oid, kind, length = process.stdout.readline().decode().strip().split()
    assert oid == entry['oid'] and kind == 'blob', path
    remaining = int(length)
    digest = hashlib.sha256()
    while remaining:
        chunk = process.stdout.read(min(remaining, 1024 * 1024))
        assert chunk
        remaining -= len(chunk)
        digest.update(chunk)
    assert process.stdout.read(1) == b'\n'
    p = root / path
    assert digest.hexdigest() == sha(p.read_bytes()), (path, 'staged byte difference')
    assert int(length) < 100 * 1024 * 1024, (path, 'large Git object')
    staged.append({'path': path, 'gitBlob': oid, 'sha256': digest.hexdigest(), 'bytes': int(length), 'mode': entry['mode']})
process.stdin.close()
assert process.wait() == 0
save('staged-files.json', staged)
gitlinks = {path: row for path, row in entries.items() if row['mode'] == '160000'}
assert {p: r['oid'] for p, r in gitlinks.items()} == {
    'external/pkl': 'e51fb2f91774265666f94980ec630db794a4db2d',
    'external/pkl-pantry': '904a68184e54da378b0a0e8a911a3fab3956f693',
}
assert git('diff', '--cached', '--check') == b''
save('report.json', {
    'schema': 1,
    'scope': 'C06 project code, fixtures and control inputs bound to actual staged Git blobs; new report artifacts checked as exact staged bytes. No runtime/build/test execution.',
    'createdUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseCommit': git('rev-parse', 'HEAD').decode().strip(),
    'candidateSourceMapSha256': sha((candidate / 'source-after.json').read_bytes()),
    'candidateProjectInputsMatched': len(matched),
    'postCandidateDocumentationDelta': documentation,
    'otherCandidateInputs': 'Captured external sources and historical reports retain their separate full source/archive audits; reference gitlinks are checked here.',
    'changedStagedFiles': len(staged),
    'stagedAllBytesEqualWorkingTree': True,
    'allChangedObjectsBelow100MiB': True,
    'referenceGitlinks': gitlinks,
    'diffCheckPassed': True,
    'bindingsSha256': sha((out / 'candidate-index-bindings.json').read_bytes()),
    'stagedFilesSha256': sha((out / 'staged-files.json').read_bytes()),
    'followupPublication': 'This audit and subsequent review/binding reports are additional documentation artifacts, not C06 runtime inputs. Actual commit binding follows separately.',
})
print(json.dumps({'candidateInputsMatched': len(matched), 'docsDelta': len(documentation), 'stagedFiles': len(staged), 'passed': True}), flush=True)
