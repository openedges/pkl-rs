from pathlib import Path
import hashlib,json,collections,stat
OUT=Path(__file__).resolve().parent;MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');S=MAIN.parent/'pkl-rs.stage47';P=S/'target/m2/stage47-core-publication-proposal-02'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def obj(p):return json.loads(p.read_bytes())
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
receipt=MAIN/'target/m2/stage47-core-installation-01/report.json';r=obj(receipt);installed=[]
assert len(r['copied'])==12
for row in r['copied']:
 source=Path(row['source']);target=S/row['path'];assert stat.S_ISREG(target.lstat().st_mode)
 assert h(source)==h(target)==row['sha256'] and target.stat().st_size==row['bytes']
 installed.append({'path':str(target),'sha256':row['sha256'],'bytes':row['bytes']})
a=obj(P/'archive-inputs-final.json');outcomes=P/'staging/builds-source-binding/check-outcomes.json';binding=next(x for x in a['builds-source-binding'] if x['path']=='check-outcomes.json');assert h(outcomes)==binding['sha256']
counts=collections.Counter()
for row in obj(outcomes):
 p=Path(row['report']);assert h(p)==row['report_sha256'];d=obj(p);assert d['exit_code']==row['exit_code'] and d['source_stable']==row['source_stable'];counts[str(row['exit_code'])]+=1
summary=obj(P/'summary-final.json');assert dict(counts)==summary['check_exit_counts']
save('installation-and-outcomes.json',{'installationReceiptPath':str(receipt),'installationReceiptSha256':h(receipt),'installedPayloads':installed,'copied12FilesEqualSourceBytes':True,'historicalCheckExitCounts':dict(counts),'historicalOutcomeRecordsCompared':sum(counts.values()),'originalRecordedFailuresUnchanged':True,'runtimeReruns':0})
save('execution.json',{'actualReviewToolSession':26246,'actualExitCode':0,'stdoutSha256':h(OUT/'stdout.bin'),'stderrSha256':h(OUT/'stderr.bin'),'qualification':'Actual tool terminal0. Raw archive/source metadata readback only; no evaluator/test reruns.'})
report=obj(OUT/'report.json');report['installationReadback']='installation-and-outcomes.json';report['historicalCheckOutcomeCount']=sum(counts.values());report['historicalCheckExitCounts']=dict(counts);save('report.json',report)
files=['review.py','finish_review.py','report.json','inputs.json','stdout.bin','stderr.bin','execution.json','installation-and-outcomes.json']
save('closure.json',{'closed':True,'files':[{'path':n,'sha256':h(OUT/n),'bytes':(OUT/n).stat().st_size} for n in files],'ownLiveHandles':[]})
print(json.dumps({'reportSha256':h(OUT/'report.json'),'closureSha256':h(OUT/'closure.json'),'installedPayloads':len(installed),'outcomes':dict(counts),'blockers':[]}))
