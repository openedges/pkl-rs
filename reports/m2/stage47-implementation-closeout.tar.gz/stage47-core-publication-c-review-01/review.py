"""Read-only core publication integrity/binding review; never traverses evidence/cache trees."""
from pathlib import Path
import json,hashlib,stat,tarfile,collections,time
OUT=Path(__file__).resolve().parent;MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');S=MAIN.parent/'pkl-rs.stage47';P=S/'target/m2/stage47-core-publication-proposal-02';C=S/'target/m2/stage47-implementation-01/renderer-candidate-build-06'
seen={};start=time.monotonic()
def read(p,expected=None):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode),p;b=p.read_bytes();h=hashlib.sha256(b).hexdigest()
 if expected:assert h==expected,(p,h,expected)
 seen[str(p)]={'path':str(p),'bytes':len(b),'sha256':h,'mode':stat.S_IMODE(s.st_mode)};return b
def obj(p,h=None):return json.loads(read(p,h))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
handoff=obj(P/'handoff.json','6f68202ecf3a81569ab705139e0dd9cabc52c4caec549b1153417d90e98edb30');idx=obj(P/'archive-index.json',handoff['archive_index_sha256']);assert handoff['actual_exit_code']==0
for row in handoff['sidecars']:assert len(read(P/row['path'],row['sha256']))==row['bytes']
summary=obj(P/idx['summary']['path'],idx['summary']['sha256']);final=obj(P/idx['final_binding']['path'],idx['final_binding']['sha256']);catalog=obj(P/idx['source_catalog']['path'],idx['source_catalog']['sha256']);gaps=obj(P/idx['historical_source_gaps']['path'],idx['historical_source_gaps']['sha256']);inputs=obj(P/idx['input_list']['path'],idx['input_list']['sha256']);originals=obj(P/'selected-files.json');maps=obj(P/'source-map-index.json');addendum=obj(P/'basename-binding-addendum.json')
assert idx['summary']['path']=='summary-final.json' and len(gaps)==idx['historical_source_gaps']['count']==7
assert len(addendum)==8 and summary['resolved_basename_metadata_versions']==8
assert len(catalog)==summary['source_path_versions'] and len(originals)==summary['selected_raw_files']
assert sum(r['bytes'] for r in originals)==summary['selected_raw_bytes']
archives=[];archived={}
for a in idx['archives']:
 path=Path(a['path']);assert len(read(path,a['sha256']))==a['bytes'] and a['bytes']<100*1024*1024
 assert a['create']['exit_code']==a['separate_verify']['exit_code']==0
 group=a['name'][len('stage47-core-'):-len('.tar.gz')];expected={r['path']:r for r in inputs[group]};actual=set();raw=0
 with tarfile.open(path,'r|gz') as tf:
  for member in tf:
   assert member.isfile() and member.name not in actual and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
   actual.add(member.name);data=tf.extractfile(member).read();h=hashlib.sha256(data).hexdigest()
   assert member.mode==0o644 and member.mtime==0
   if member.name=='EVIDENCE.json':
    evidence=json.loads(data);assert {r['path'] for r in evidence['files']}==set(expected);continue
   row=expected[member.name];assert len(data)==row['bytes'] and h==row['sha256'];raw+=len(data);archived[(group,member.name)]={'bytes':len(data),'sha256':h}
 assert actual==set(expected)|{'EVIDENCE.json'} and len(expected)==a['files'] and raw==a['raw_bytes']
 for phase in ['create','separate_verify']:
  command=a[phase]
  for side in ['stdout','stderr']:read(P/'packaging-captures'/(command['label']+'.'+side+'.bin'),command[side+'_sha256'])
 archives.append({'name':a['name'],'bytes':a['bytes'],'sha256':a['sha256'],'payloads':len(expected),'allPayloadHashesAndPathsEqual':True,'below100MiB':True});print(a['name']+': raw/readback0',flush=True)
assert sum(a['bytes'] for a in archives)==idx['total_archive_bytes']==handoff['total_archive_bytes']
# Direct original paths only, preserving modes; no output tree/cache enumeration.
for row in originals:
 b=read(row['original'],row['sha256']);assert len(b)==row['bytes'] and seen[row['original']]['mode']==row['mode']
 ar=archived[(row['group'],row['archive_path'])];assert ar['sha256']==row['sha256'] and ar['bytes']==row['bytes']
# Explicit immutable C06 map and archived catalog reconstructability.
release=obj(C/'release.json',final['release_sha256']);sm=obj(C/'source-after.json',final['source_map_sha256']);modes=obj(C/'source-modes.json',final['source_modes_sha256']);assert len(sm)==final['entries']==51745
bykey={(r['path'],r['sha256']):r for r in catalog};assert len(bykey)==len(catalog)
counts=collections.Counter()
for name,h in sm.items():
 row=bykey[(name,h)];kind=row['kind'];assert kind!='unresolved-historical-source';counts[kind]+=1
 b=read(C/'sources'/name,h);assert len(b)==row['bytes'] and seen[str(C/'sources'/name)]['mode']==modes[name]
 if kind=='pinned-git-blob':assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['object']
 elif kind=='archived-source-blob':assert archived[('builds-source-binding',row['blob'])]['sha256']==h
 elif kind=='separately-published-report-archive':assert read(row['canonical_capture'],h)==b
 else:raise AssertionError(kind)
assert dict(counts)==final['binding_counts']
# Every archived source version's content-addressed payload is present.
for row in catalog:
 if row['kind']=='archived-source-blob':assert archived[('builds-source-binding',row['blob'])]['sha256']==row['sha256']
# Seven historical hash-only versions stay tied to original maps and do not affect C06.
map_index={r['path']:r for r in maps};gap_records=[]
for gap in gaps:
 assert gap['kind']=='unresolved-historical-source' and bykey[(gap['path'],gap['sha256'])]==gap
 assert sm.get(gap['path'])!=gap['sha256']
 for name in gap['recorded_maps']:
  m=obj(name,map_index[name]['sha256']);assert m[gap['path']]==gap['sha256']
 gap_records.append({'path':gap['path'],'sha256':gap['sha256'],'historicalMapCount':len(gap['recorded_maps']),'affectsC06':False})
for row in addendum:
 replacement=row['replacement'];assert replacement['kind']=='archived-source-blob';assert bykey[(replacement['path'],replacement['sha256'])]==replacement
 b=read(replacement['canonical_capture'],replacement['sha256']);assert len(b)==replacement['bytes'] and replacement['full_path_binding'].endswith('/'+replacement['path'])
# Published authoritative reports match independently reviewed final verification inputs.
assert summary['final']['rust5_report_sha256']=='c0d053b20146ebd74e0bb1642b1a7a8f0f00e6e15484985bc79d314d17a0c3fe'
assert summary['final']['original_cli_report_sha256']=='3f8870b2199bdf78ca3fa6eeba52713f232f58f8a73e7d5d7ed1c940b80f0275'
assert summary['final']['source_unresolved']==0 and summary['final']['source_entries_bound']==51745
report={'schema':1,'scope':'Read-only core publication/archive/source binding review; no runtime/build/test/oracle execution, Git/source edits, or directory/cache traversal.','blockers':[],'handoffSha256':seen[str(P/'handoff.json')]['sha256'],'archiveIndexSha256':seen[str(P/'archive-index.json')]['sha256'],'authoritativeSummary':'summary-final.json','archives':archives,'totalArchiveBytes':sum(a['bytes'] for a in archives),'largestArchiveBytes':max(a['bytes'] for a in archives),'allArchivesBelow100MiB':True,'selectedOriginalRawFilesVerified':len(originals),'selectedOriginalRawBytesVerified':sum(r['bytes'] for r in originals),'C06SourcePathsDirectlyRehashed':len(sm),'C06BindingCounts':dict(counts),'historicalHashOnlyVersions':gap_records,'resolvedBasenameVersions':8,'originalKindsModesBytesEqual':True,'sourceAndGitWrites':False,'newRuntimeExecutions':0,'qualifications':['Old preparation summary.json is historical; index points explicitly to authoritative summary-final.json with7 historical hash-only versions.','Hash-only historical versions have original map SHA and outcomes; source-complete historical verification is not claimed.','C06 pinned Git object identifiers were checked from exact captured bytes; this review does not rerun Git commit-tree extraction.','Native1840, supplementary portable980 and actual primary platform evidence are separate owners/packages.','Full-selected Stage47 regression, stdlib admission, complete identity, wholeM2 and performance gates remain open.'],'elapsedSeconds':time.monotonic()-start}
save('report.json',report);save('inputs.json',{'files':list(seen.values()),'recursiveTraversal':False});print(json.dumps({'archives':len(archives),'maxBytes':report['largestArchiveBytes'],'C06paths':len(sm),'historicalHashOnly':len(gaps),'blockers':[]}))
