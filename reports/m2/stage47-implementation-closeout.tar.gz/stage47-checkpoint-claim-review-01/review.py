"""Bind reviewed C06 aggregate claims to existing sealed records; no evaluation."""
from pathlib import Path
import json,hashlib,stat
OUT=Path(__file__).resolve().parent;MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');S=MAIN.parent/'pkl-rs.stage47';inputs={}
def read(p,h=None):
 p=Path(p);assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();digest=hashlib.sha256(b).hexdigest()
 if h:assert digest==h,(p,digest,h)
 inputs[str(p)]={'path':str(p),'sha256':digest,'bytes':len(b)};return b
def obj(p,h=None):return json.loads(read(p,h))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
claimPath=S/'reports/m2/stage47-implementation-checkpoint.json';claim=obj(claimPath,'372c5c7df78c8e3cd3d006603e26cdd185466b237ec8c26dc173ecac573d5c7c')
docs=['reports/m2/README.md','PLAN.md','README.md','docs/m2-json-rendering.md','docs/architecture.md']
snap=OUT/'reviewed-claims';snap.mkdir()
for name in ['reports/m2/stage47-implementation-checkpoint.json']+docs:
 dest=snap/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(read(S/name))
for e in claim['evidence'].values():read(S/e['path'],e['sha256'])
base=MAIN/'target/m2/stage47-c06-platform-audit-01';pa=obj(base/'report.json','4da7aa4a376fca19ddd3568ecb53b5467fdfdcde6c85e4040fa3d98d50d274d1');pr=obj(base/'supplemental-raw-audit.json');cp=obj(MAIN/'target/m2/stage47-c06-closeout-inputs-01/summary-proposal.json','26c08e86ad6dce72eb6201c17ec93ddcc12f950ed85e5f3ade876eedfe6dc045');core=obj(S/'reports/m2/stage47-core-summary.json')
B=S/'target/m2/stage47-oracle-publication-01';bh=obj(B/'handoff.json','09302ea78b08200eb6775afe4ef5cc88ca81515431d5523d4bbe97192e2ffbc7');br=obj(bh['reportPath'],bh['reportSha256']);bi=obj(bh['archiveIndexPath'],bh['archiveIndexSha256']);obj(bh['summaryPath'],bh['summarySha256'])
for key in ['publisher','finalize']:obj(bh['actualTerminalReceipts'][key],bh['actualTerminalReceipts'][key+'Sha256'])
assert claim['candidate']['releaseSha256']==cp['candidate']['releaseSha256']==pa['candidate']['releaseSha256']
assert claim['candidate']['sourceMapSha256']==cp['candidate']['sourceMapSha256'] and claim['candidate']['fullyBoundInputs']==51745 and claim['candidate']['unresolvedFinalInputs']==0
checks=claim['checks'];assert checks['requiredRustCommands']['passed']==cp['completed']['requiredRustCommands']==5 and checks['requiredRustCommands']['failed']==0
assert checks['originalCli']['rawMatches']==cp['completed']['untouchedOriginalCliCalls']==4 and checks['originalCli']['repetitionsPerCase']==2
api=checks['rendererApi'];primary={r['group']:r['callsPerTarget'] for r in pr['targets']};bc=br['offlineRawVerificationFromActualArchives']['counts'];assert api['primaryCohort']==primary['renderer']==860 and api['supplementaryCohorts']==[424,436,120]
assert api['native']==bc['native']==1840 and api['node']==primary['renderer']+bc['node']==1840 and api['chromium']==primary['renderer']+bc['browser']==1840
for group,key in [('resource','resourceApi'),('module-preparation','modulePreparationApi')]:assert checks[key]['node']==checks[key]['chromium']==primary[group]
sp=checks['sharedPrimitives'];assert sp['crossTargetMatches']==pa['baseline']['sharedEqual']==6078 and all(v==sp['javaMatchesPerTarget']==6076 for v in pa['baseline']['oracleMatches'].values()) and len(pa['baseline']['rawKnownGaps'])==sp['knownRegexMismatches']==2 and sp['strictCompatibilityPassed'] is False
identity=checks['permanentIdentityRegression'];assert identity['actualJavaObservations']==240 and identity['javaPowerAssertions'] is True and identity['rustInstrumentationConfigurations']==2 and identity['rawComparisons']==480 and identity['fixturePythonTestsPassed']==7
installed=obj(MAIN/'target/m2/stage47-frame-identity-installed-checks-01/report.json');read(MAIN/'target/m2/stage47-frame-identity-installed-checks-01/outer-terminal.json');read(MAIN/'target/m2/stage47-frame-identity-installed-checks-01/tests.stderr.bin')
# Exact B installation mapping and receipt; do not repeat historical raw acquisitions.
receipt=obj(MAIN/'target/m2/stage47-oracle-installation-01/report.json');assert len(receipt['copied'])==9
for row in receipt['copied']:assert read(row['source'],row['sha256'])==read(S/row['path'],row['sha256'])
byname={Path(a['path']).name:a for a in bi['archives']};assert len(claim['archiveInstallation'])==4
for row in claim['archiveInstallation']:assert row['sha256']==byname[row['sourceBasename']]['sha256'];read(S/row['repositoryPath'],row['sha256'])
assert claim['publishedFullSelectedBaseline']=={'stage':46,'matched':3650,'selected':3664,'unsupported':4,'mismatched':9,'oracleError':1,'isC06Result':False}
assert claim['fullM2Complete'] is False and claim['performanceTargetsEstablished'] is False
# Existing post-C06 doc-only declaration; new aggregate/publication docs are explicit reviewed files.
post=obj(MAIN/'target/m2/stage47-metadata-review-01/post-c06-docs-addendum.json','2cd7e247c4ad4dbfd85fd368e6446946edd0ac4bea0a16d606b4cfca27e871ac');assert len(post['changedPaths'])==3 and post['otherCandidateDeclaredPathsChanged']==[]
# Recheck only explicitly reviewed inputs; no directory/cache traversal.
for row in list(inputs.values()):read(row['path'],row['sha256'])
report={'schema':1,'scope':'C06 aggregate/documentation publication claim review against sealed existing records; no new evaluation/build/tests or production/Git writes.','materialFindings':[],'reviewedAggregatePath':str(claimPath),'reviewedAggregateSha256':inputs[str(claimPath)]['sha256'],'claimSourceHashes':[{ 'path':str(S/n),'sha256':inputs[str(S/n)]['sha256']} for n in docs],'evidencePointersChecked':len(claim['evidence']),'BInstalledFilesExact':9,'BArchiveNamesMapped':4,'validatedClaims':{'rustCommands':5,'originalCliMatches':4,'rendererPerNativeNodeBrowser':1840,'resourcePerNodeBrowser':1008,'modulePreparationPerNodeBrowser':252,'sharedMatches':6078,'javaMatchesPerTarget':6076,'preservedRegexMismatches':2,'oneJavaBaselineObservations':240,'twoRustConfigurationComparisons':480,'C06SourceInputsBound':51745,'historicalHashOnlyVersions':7},'qualificationsConfirmed':['API totals overlap repeats/platforms/configurations; no overall M2 completion percentage.','Default renderer consumer scope does not complete policy84,close28,shared-backing-array equivalence or JavaGC/portable collection equivalence.','Wrong-method16 observations retained without intended-identity branch proof.','240×2 consumes one actual Java powertrue baseline; no Java off/on comparison.','Stage46 3650/3664 is explicitly not C06 full-selected result.','Stdlib admission/import-edge policy, complete identity, fresh full-selected/persistent regression and wholeM2/performance/release obligations remain open.','Post-C06 docs/publication delta is separate from immutable tested candidate; future index/commit binding is not inferred by this review.'],'pendingPublicationStep':'Root final staged index/actual commit binding may add report-only pointers; reviewed aggregate bytes are preserved here.','inputChanges':[],'newRuntimeExecutions':0}
save('report.json',report);save('inputs.json',{'files':list(inputs.values()),'recursiveTraversal':False});print(json.dumps({'reviewedAggregateSha256':report['reviewedAggregateSha256'],'inputs':len(inputs),'materialFindings':[]}))
