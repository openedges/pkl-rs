"""Publish and fully read back Stage64 Java A authority and preserved attempts."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
REPORTS = ROOT / "reports/m2"
BASE = "b7af226b62da218a0d42fdf80ec60270eae998e2"
MAIN = ROOT / "tests/fixtures/m2-amendment-construction"
DECL = ROOT / "tests/fixtures/m2-amendment-declarations"
EXPLORATION = ROOT / "target/m2/stage64-amendment-exploration-01"
MAIN_CAPTURE = ROOT / "target/m2/stage64-amendment-oracle-01"
DECL_CAPTURE = ROOT / "target/m2/stage64-amendment-declarations-oracle-01"
VALIDATION = ROOT / "target/m2/stage64-java-validation-01"
DIRS = (
    "stage64-amendment-exploration-01",
    "stage64-amendment-exploration-review-01",
    "stage64-amendment-canonical-launch-01",
    "stage64-amendment-declaration-launch-01",
    "stage64-amendment-oracle-01",
    "stage64-amendment-declarations-oracle-01",
    "stage64-amendment-seal-01",
    "stage64-amendment-declarations-seal-01",
    "stage64-java-validation-01",
    "stage64-amendment-local-controls-01",
    "stage64-amendment-eof-newline-01",
)
HISTORY = {
    "capture-01": (150, {"error": 150}),
    "capture-02": (150, {"success": 42, "error": 108}),
    "capture-03": (150, {"success": 70, "error": 80}),
    "capture-04": (154, {"success": 81, "error": 73}),
    "candidate-01": (178, {"success": 95, "error": 83}),
    "candidate-02": (188, {"success": 102, "error": 86}),
    "original-control-01": (4, {"success": 4}),
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}


def need(condition, message):
    if not condition:
        raise ValueError(message)


def head():
    return subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                          capture_output=True, check=True).stdout.decode().strip()


def walk(root, prefix):
    need(root.is_dir() and not root.is_symlink(), "publication input directory missing")
    paths = {}
    for path in root.rglob("*"):
        need(not path.is_symlink(), "publication source symlink")
        if "__pycache__" in path.parts:
            continue
        if path.is_file():
            name = prefix + path.relative_to(root).as_posix()
            need(name not in paths, "duplicate publication source")
            paths[name] = path
        else:
            need(path.is_dir(), "nonregular publication input")
    return paths


def check_history():
    history = {}
    for name, (rows, statuses) in HISTORY.items():
        folder = EXPLORATION / name
        provenance = json.loads((folder / "provenance.json").read_bytes())
        audit = json.loads((folder / "audit.json").read_bytes())
        need(provenance["complete"] and provenance["stable"] and provenance["raw_equal"]
             and provenance["raw_differences"] == [] and audit["rows"] == rows
             and audit["statuses"] == statuses
             and len(provenance["sessions"]) == 2
             and len({session["pid"] for session in provenance["sessions"]}) == 2,
             "Stage64 exploratory history status/protocol differs")
        for key, digest in provenance["input_before"].items():
            need(identity(folder / key)["sha256"] == digest == provenance["input_after"][key],
                 "exploration input drift")
        for key, digest in provenance["source_before"].items():
            need(identity(folder / "sources" / key)["sha256"] == digest == provenance["source_after"][key],
                 "exploration pinned source copy drift")
        history[name] = {"rows": rows, "statuses": statuses,
                         "module_uri": json.loads((folder / "cases.json").read_bytes())["module_uri"],
                         "provenance": identity(folder / "provenance.json"),
                         "pids": [session["pid"] for session in provenance["sessions"]],
                         "role": "selected original source public calls" if name == "original-control-01"
                                 else "authored exploration, not canonical"}
    upstream = ROOT / "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/amendsChains.pkl"
    need((EXPLORATION / "original-control-01/module.pkl").read_bytes() == upstream.read_bytes(),
         "pinned original selected program differs")
    declarations = {}
    for number, expected in ((1, (5, {"success": 3, "error": 2})),
                             (2, (5, {"success": 1, "error": 4})),
                             (3, (11, {"success": 3, "error": 8}))):
        name = f"declarations-{number:02d}"
        report = json.loads((EXPLORATION / name / "report.json").read_bytes())
        counts = dict(Counter(entry["status"] for entry in report["programs"].values()))
        need(report["complete"] and (len(report["programs"]), counts) == expected,
             "historical separate declaration programs differ")
        for entry in report["programs"].values():
            child = EXPLORATION / entry["capture"]
            provenance = json.loads((child / "provenance.json").read_bytes())
            need(provenance["complete"] and provenance["raw_equal"] and provenance["stable"]
                 and len(provenance["sessions"]) == 2 and
                 identity(child / "provenance.json")["sha256"] == entry["capture_provenance_sha256"],
                 "historical declaration Java protocol differs")
        declarations[name] = {"programs": expected[0], "statuses": counts,
                              "report": identity(EXPLORATION / name / "report.json")}
    identity_status = {}
    for number, complete, rows in ((1, True, 9), (2, False, 12), (3, True, 12)):
        name = f"identity-{number:02d}"
        folder = EXPLORATION / name
        report = json.loads((folder / "report.json").read_bytes())
        raw = (folder / "repeat-0/process.stdout.bin").read_bytes()
        need(report["complete"] is complete and len(report["sessions"]) == 2
             and len(raw.decode().splitlines()) == rows
             and raw == (folder / "repeat-1/process.stdout.bin").read_bytes()
             and all(session["exit_code"] == (0 if complete else 1)
                     for session in report["sessions"]),
             "direct VM identity history differs")
        identity_status[name] = {"complete": complete, "rows_before_failure_or_exit": rows,
                                 "report": identity(folder / "report.json"),
                                 "role": "final direct VM identity" if number == 3
                                         else "historical failed Module-class proxy" if number == 2
                                         else "earlier direct VM identity"}
    trace = json.loads((EXPLORATION / "trace-01/report.json").read_bytes())
    need(trace["complete"] and trace["raw_equal"] and len(trace["sessions"]) == 2,
         "Host trace supplement differs")
    analysis = json.loads((EXPLORATION / "analysis-02/report.json").read_bytes())
    need(analysis["complete"] and analysis["candidate_compatibility_passes_claimed"] == 0
         and analysis["original_public_control"]["full_original_cli_or_output_files_executed"] is False
         and analysis["vm_identity"]["user_class_identity_observed"] is False,
         "corrected Java boundary analysis differs")
    return {"string_attempts": history, "declaration_attempts": declarations,
            "direct_identity": identity_status,
            "host_trace": identity(EXPLORATION / "trace-01/report.json"),
            "corrected_analysis": identity(EXPLORATION / "analysis-02/report.json")}


def check_supplements():
    observed = {}
    for name, rows, statuses, uri in (
        ("stage64-amendment-local-controls-01", 18, {"success": 2, "error": 16},
         "file:///stage64/amendment-local-controls.pkl"),
        ("stage64-amendment-eof-newline-01", 3, {"error": 3},
         "file:///stage64/amendment-eof-newline.pkl"),
    ):
        folder = ROOT / "target/m2" / name
        capture = folder / "capture-01"
        process = json.loads((folder / "process.json").read_bytes())
        provenance = json.loads((capture / "provenance.json").read_bytes())
        audit = json.loads((capture / "audit.json").read_bytes())
        cases = json.loads((folder / "inputs-01/cases.json").read_bytes())
        need(process["exit_code"] == 0 and process["source_stable"]
             and process["capture_provenance"] == identity(capture / "provenance.json")
             and provenance["complete"] and provenance["stable"] and provenance["raw_equal"]
             and provenance["raw_differences"] == []
             and len(provenance["sessions"]) == 2
             and len({item["pid"] for item in provenance["sessions"]}) == 2
             and all(item["exit_code"] == 0 for item in provenance["sessions"])
             and audit["rows"] == rows and audit["statuses"] == statuses
             and len(audit["observations"]) == rows
             and cases["module_uri"] == uri and len(cases["rows"]) == rows,
             "Java producer-only supplement differs")
        for key, digest in provenance["input_before"].items():
            need(identity(capture / key)["sha256"] == digest == provenance["input_after"][key],
                 "supplement input changed")
        for key, digest in provenance["source_before"].items():
            need(identity(capture / "sources" / key)["sha256"] == digest == provenance["source_after"][key],
                 "supplement pinned source copy changed")
        observed[name] = {"rows": rows, "statuses": statuses, "module_uri": uri,
                          "capture_provenance": identity(capture / "provenance.json"),
                          "recorded_process": identity(folder / "process.json"),
                          "boundary": "producer-only public Java string diagnostic controls; not catalog profile"}
    return observed


def archive(files):
    output = REPORTS / "stage64-java-evidence.tar.gz"
    need(not output.exists(), "fresh Stage64 Java evidence archive required")
    before = {name: identity(path) for name, path in files.items()}
    manifest = {"schema": 1, "scope": "Stage64 two Java fixtures, raw validation, and retained explorations",
                "members": dict(sorted(before.items()))}
    manifest_raw = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with output.open("wb") as destination:
        with gzip.GzipFile(fileobj=destination, mode="wb", filename="", mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as writer:
                for name, path in sorted(files.items()):
                    raw = path.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    writer.addfile(info, io.BytesIO(raw))
                info = tarfile.TarInfo("archive-manifest.json")
                info.size = len(manifest_raw)
                info.mode = 0o644
                info.mtime = 0
                writer.addfile(info, io.BytesIO(manifest_raw))
    after = {name: identity(path) for name, path in files.items()}
    need(before == after, "Java publication source changed during archive")
    observed = {}
    with tarfile.open(output, "r:gz") as published:
        for member in published:
            need(member.isfile() and not Path(member.name).is_absolute()
                 and ".." not in Path(member.name).parts and member.name not in observed,
                 "unsafe or duplicate Java publication member")
            raw = published.extractfile(member).read()
            need(len(raw) == member.size, "Java publication member size differs")
            observed[member.name] = {"bytes": len(raw), "sha256": sha(raw)}
    need(len(observed) == len(before) + 1 and
         {name: value for name, value in observed.items() if name != "archive-manifest.json"} == before
         and observed["archive-manifest.json"]["sha256"] == sha(manifest_raw),
         "Java publication full-member hash readback differs")
    return {"path": output.relative_to(ROOT).as_posix(), "identity": identity(output),
            "members": len(observed), "member_hash_readback": True,
            "source_before_after_equal": True,
            "embedded_manifest_sha256": sha(manifest_raw)}


def main():
    need(head() == BASE, "Stage64 Java A baseline HEAD differs")
    validation = json.loads((VALIDATION / "report.json").read_bytes())
    need(validation["complete"] and validation["source_stable"]
         and validation["copied_sources_match"] and validation["tool_checks_passed"]
         and validation["m2_manifest_freshness_pass_claimed"] is False
         and len(validation["checks"]) == 6
         and all(check["exit_code"] == 0 for check in validation["checks"][:5])
         and validation["checks"][5]["exit_code"] == 1
         and len(validation["source_before"]) == 199,
         "recorded Stage64 Java tool validation differs")
    need(b"Ran 37 tests" in (VALIDATION / "python-tests.stderr.bin").read_bytes()
         and b"Ran 37 tests" in (VALIDATION / "python-tests-O.stderr.bin").read_bytes()
         and b"tests 10" in (VALIDATION / "js-tests.stdout.bin").read_bytes(),
         "recorded Stage64 test counts differ")
    need(b"M2 manifest stale" in (VALIDATION / "m2-manifest-observation.stderr.bin").read_bytes(),
         "stale M2 manifest observation differs")
    for name, expected in validation["source_before"].items():
        need(identity(VALIDATION / "sources" / name) == expected == validation["source_after"][name],
             "validation source snapshot differs")
    import sys
    sys.path.insert(0, str(ROOT / "tools"))
    from amendment_construction_fixtures import verify as verify_main
    from amendment_declarations_fixtures import verify as verify_declarations
    main_fixture = verify_main(MAIN)
    declaration_fixture = verify_declarations(DECL)
    need(main_fixture["rows"] == 188 and main_fixture["statuses"] == {"success": 102, "error": 86}
         and declaration_fixture["programs"] == 11
         and declaration_fixture["statuses"] == {"success": 3, "error": 8},
         "sealed Stage64 Java authorities differ")
    history = check_history()
    supplements = check_supplements()
    files = {}
    files.update(walk(MAIN, "fixtures/m2-amendment-construction/"))
    files.update(walk(DECL, "fixtures/m2-amendment-declarations/"))
    for name in DIRS:
        files.update(walk(ROOT / "target/m2" / name, f"target/{name}/"))
    files["publication-source/publish.py"] = HERE / "publish.py"
    files["publication-source/launch.py"] = HERE / "launch.py"
    publication = archive(files)
    need(head() == BASE, "Stage64 Java A baseline moved during publication")
    main_provenance = json.loads((MAIN_CAPTURE / "provenance.json").read_bytes())
    decl_provenance = json.loads((DECL_CAPTURE / "provenance.json").read_bytes())
    checkpoint = {"schema": 1, "kind": "stage64-amendment-java-authority-checkpoint",
       "baseline": "Pkl 0.32.0", "baseline_head": BASE,
       "candidate_compatibility_passes_claimed": 0,
       "canonical_string": {"fixture": MAIN.relative_to(ROOT).as_posix(),
          "module_uri": "file:///stage64/amendment-construction.pkl",
          "rows": 188, "statuses_per_session": {"success": 102, "error": 86},
          "archive_prefix": "capture-01", "archive": identity(MAIN / "oracle-evidence.tar.gz"),
          "archive_members": 7983,
          "fileset_sha256": json.loads((MAIN / "archive-identity.json").read_bytes())["fileset_sha256"],
          "source_count": len(main_provenance["source_before"])},
       "canonical_declarations": {"fixture": DECL.relative_to(ROOT).as_posix(),
          "module_uri": "file:///stage64/amendment-declarations.pkl",
          "programs": 11, "statuses_per_program": {"success": 3, "error": 8},
          "archive_prefix": "capture-01", "archive": identity(DECL / "oracle-evidence.tar.gz"),
          "archive_members": 632,
          "fileset_sha256": json.loads((DECL / "archive-identity.json").read_bytes())["fileset_sha256"],
          "source_count": len(decl_provenance["source_before"])},
       "java_runtime": {"reference_revision": "e51fb2f91774265666f94980ec630db794a4db2d",
                        "artifact_sha256": main_provenance["artifact_sha256"],
                        "main_jdk": main_provenance["jdk"],
                        "declaration_jdk": decl_provenance["jdk"]},
       "validation": {"directory": VALIDATION.relative_to(ROOT).as_posix(),
                      "record": identity(VALIDATION / "report.json"),
                      "source_count": 199, "source_stable": True,
                      "checks": validation["checks"],
                      "m2_manifest_freshness_pass_claimed": False,
                      "deferred_final_integration": "Concurrent Rust/runtime and manifest changes require later regeneration."},
       "history": history, "producer_only_diagnostic_supplements": supplements,
       "publication": publication,
       "limits": ["Public 188-row string fixture and eleven separate declaration programs are distinct authorities.",
                  "Direct VM identity is producer-only and does not establish user-class identity.",
                  "Exact upstream amendsChains.pkl was evaluated for four public expressions; full original CLI/output-file execution remains unverified.",
                  "Identity-02 failed Java launcher execution and remains failed historical evidence.",
                  "No Rust candidate, typed export, Node, browser, full M2 or performance pass is claimed.",
                  "M2 manifest freshness waits for source freeze and regeneration."]}
    need(not HERE.joinpath("draft.json").exists(), "fresh Stage64 Java checkpoint draft required")
    (HERE / "draft.json").write_text(json.dumps(checkpoint, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"draft": identity(HERE / "draft.json"),
                      "publication": publication}, sort_keys=True))


if __name__ == "__main__":
    main()
