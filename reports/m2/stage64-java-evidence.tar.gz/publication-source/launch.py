"""Record the actual Stage64 Java A publication process and its raw streams."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = ROOT / "target/m2/stage64-java-publication-execution-01"
CHECKPOINT = ROOT / "reports/m2/stage64-java-checkpoint.json"
ARCHIVE = ROOT / "reports/m2/stage64-java-evidence.tar.gz"
EXPECTED_HEAD = "b7af226b62da218a0d42fdf80ec60270eae998e2"


def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def head():
    return subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                          capture_output=True, check=True).stdout.decode().strip()


def main():
    if OUT.exists() or CHECKPOINT.exists() or ARCHIVE.exists() or (HERE / "draft.json").exists():
        raise ValueError("fresh recorded Stage64 Java A publication required")
    if head() != EXPECTED_HEAD:
        raise ValueError("Stage64 Java A baseline HEAD differs")
    observed = [HERE / "publish.py", HERE / "launch.py",
                ROOT / "target/m2/stage64-java-validation-01/report.json",
                ROOT / "tests/fixtures/m2-amendment-construction/oracle-evidence.tar.gz",
                ROOT / "tests/fixtures/m2-amendment-declarations/oracle-evidence.tar.gz",
                ROOT / "target/m2/stage64-amendment-exploration-01/analysis-02/report.json",
                ROOT / "target/m2/stage64-amendment-local-controls-01/process.json",
                ROOT / "target/m2/stage64-amendment-eof-newline-01/process.json"]
    before = {path.relative_to(ROOT).as_posix(): identity(path) for path in observed}
    OUT.mkdir(parents=True, exist_ok=False)
    environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    argv = [sys.executable, "-B", str(HERE / "publish.py")]
    started = time.time()
    process = subprocess.Popen(argv, cwd=ROOT, env=environment,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        stdout, stderr = process.communicate(timeout=900)
    except subprocess.TimeoutExpired:
        process.kill()
        stdout, stderr = process.communicate()
        (OUT / "stdout.bin").write_bytes(stdout)
        (OUT / "stderr.bin").write_bytes(stderr)
        raise RuntimeError("publication timed out; raw streams retained")
    (OUT / "stdout.bin").write_bytes(stdout)
    (OUT / "stderr.bin").write_bytes(stderr)
    after = {path.relative_to(ROOT).as_posix(): identity(path) for path in observed}
    report = {"schema": 1, "kind": "stage64-java-a-publication-execution",
              "argv": argv, "cwd": str(ROOT), "host": platform.uname()._asdict(),
              "python": sys.version, "python_executable": sys.executable,
              "environment_relevant": {key: environment.get(key) for key in
                  ("PATH", "LANG", "LC_ALL", "TZ", "PYTHONDONTWRITEBYTECODE", "PKL_ORACLE_JAVA")},
              "pid": process.pid, "started_epoch": started, "finished_epoch": time.time(),
              "exit_code": process.returncode, "stdout": identity(OUT / "stdout.bin"),
              "stderr": identity(OUT / "stderr.bin"),
              "input_before": before, "input_after": after, "source_stable": before == after,
              "baseline_head_before_after": head() == EXPECTED_HEAD,
              "candidate_compatibility_passes_claimed": 0}
    save(OUT / "process.json", report)
    if process.returncode or before != after or head() != EXPECTED_HEAD:
        raise RuntimeError("publication failed or changed inputs; raw streams retained")
    if not (HERE / "draft.json").is_file() or not ARCHIVE.is_file():
        raise RuntimeError("publication output missing; raw streams retained")
    draft = json.loads((HERE / "draft.json").read_bytes())
    if draft["publication"]["identity"] != identity(ARCHIVE):
        raise RuntimeError("published archive identity differs")
    draft["publication_execution"] = {"path": (OUT / "process.json").relative_to(ROOT).as_posix(),
                                      "identity": identity(OUT / "process.json"),
                                      "exit_code": process.returncode,
                                      "stdout": report["stdout"], "stderr": report["stderr"],
                                      "source_stable": True,
                                      "archived_with_this_publication": False,
                                      "later_implementation_evidence_required": True}
    save(CHECKPOINT, draft)
    save(OUT / "result.json", {"schema": 1, "checkpoint": identity(CHECKPOINT),
                               "archive": identity(ARCHIVE),
                               "original_publication_raw_captured": True,
                               "candidate_compatibility_passes_claimed": 0})
    print(json.dumps({"checkpoint": identity(CHECKPOINT), "archive": identity(ARCHIVE),
                      "execution": identity(OUT / "process.json")}, sort_keys=True))


if __name__ == "__main__":
    main()
