from pathlib import Path
import datetime,hashlib,json,os,platform,subprocess,time
out=Path(__file__).resolve().parent
root=out.parents[2]
excluded={Path(p) for p in json.loads((out/'exclusions.json').read_text())['exact_paths']}
def sha(p):return hashlib.sha256(os.readlink(p).encode() if p.is_symlink() else p.read_bytes()).hexdigest()
def snapshot():
 paths=[]
 for name in ['crates','tests','tools','.cargo','xtask']:
  for base,dirs,files in os.walk(root/name,topdown=True,followlinks=False):
   base=Path(base);dirs[:]=sorted(d for d in dirs if base/d not in excluded)
   for d in list(dirs):
    if (base/d).is_symlink():paths.append(base/d);dirs.remove(d)
   paths.extend(base/f for f in sorted(files))
 paths.extend(root/n for n in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','oracle.lock.json','.gitmodules'])
 return {str(p.relative_to(root)):sha(p) for p in paths}
commands=[['cargo','xtask','verify'],['cargo','fmt','--all','--','--check'],['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],['cargo','test','--workspace','--locked'],['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked']]
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
record={'host':platform.platform(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cwd':str(root),'cargo_target_dir':str(root/'target'),'environment':{n:os.environ[n] for n in ['PATH','RUSTUP_HOME','CARGO_HOME','CARGO_TARGET_DIR'] if n in os.environ},'commands':[]}
assert 'CARGO_TARGET_DIR' not in os.environ
for i,cmd in enumerate(commands):
 start=time.time()
 with (out/f'{i}.stdout.bin').open('wb') as stdout,(out/f'{i}.stderr.bin').open('wb') as stderr:
  result=subprocess.run(cmd,cwd=root,stdout=stdout,stderr=stderr)
 after=snapshot();(out/f'{i}.source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
 row={'argv':cmd,'exit_code':result.returncode,'seconds':time.time()-start,'source_stable':before==after,'source_changes':[p for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)],'stdout_sha256':sha(out/f'{i}.stdout.bin'),'stderr_sha256':sha(out/f'{i}.stderr.bin')}
 record['commands'].append(row);(out/'report.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(row),flush=True)
record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['pass']=all(r['exit_code']==0 and r['source_stable'] for r in record['commands']);(out/'report.json').write_text(json.dumps(record,indent=2)+'\n')
raise SystemExit(0 if record['pass'] else 1)
