from pathlib import Path
import hashlib,json,os,tarfile
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PUB=ROOT/'target/m2/stage44-implementation-publication-01'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):(OUT/p).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
selection=load(PUB/'selection.json');before=load(PUB/'inputs.before.json');after=load(PUB/'inputs.after.json')
assert before==after
index=load(ROOT/'reports/m2/stage44-implementation-captures.json')
assert index==load(PUB/'report.json')
assert index['sourceChanges']==[] and index['fullM2Complete'] is False
exclusions={Path(p) for p in selection['excludedBeforeTraversal']}
# Prune exact aliases/caches before walking and never follow links.
paths={}
for row in selection['roots']:
 root=Path(row['source']);assert root not in exclusions and root.is_dir()
 for directory,dirs,files in os.walk(root,followlinks=False):
  directory=Path(directory);dirs[:]=sorted(d for d in dirs if directory/d not in exclusions)
  assert not any((directory/d).is_symlink() for d in dirs),str(directory)
  for name in sorted(files):
   p=directory/name
   if p in exclusions:continue
   assert p.is_file() and not p.is_symlink(),str(p)
   dest=str(Path(row['archivePrefix'])/p.relative_to(root))
   assert dest not in paths,dest;paths[dest]=p
for row in selection['files']:
 p=Path(row['source']);dest=row['archivePath'];assert p.is_file() and not p.is_symlink() and dest not in paths
 paths[dest]=p
assert set(paths)==set(before)
for p,q in paths.items():assert str(q)==before[p]['originalPath']
link_records=[]
for row in selection['symlinkRepresentations']:
 raw=os.fsencode(os.readlink(row['originalPath']))
 assert raw.hex()==row['targetHex'] and hashlib.sha256(raw).hexdigest()==row['targetSha256']
 assert Path(row['originalPath']) in exclusions
 link_records.append(row)
seen={};archives=[]
for a in index['archives']:
 p=ROOT/a['path'];assert p.stat().st_size==a['bytes'] and sha(p)==a['sha256']
 with tarfile.open(p,'r:gz') as tf:
  inventory=None;members={}
  for m in tf:
   assert m.isfile() and m.mode==0o644,m.name
   assert not m.name.startswith('/') and '..' not in Path(m.name).parts,m.name
   b=tf.extractfile(m).read();assert len(b)==m.size
   if m.name=='EVIDENCE.json':
    assert inventory is None;inventory=json.loads(b);continue
   assert m.name not in seen and m.name in paths,m.name
   actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
   expected={k:before[m.name][k] for k in actual}
   assert actual==expected,m.name
   q=paths[m.name];assert q.stat().st_size==len(b) and sha(q)==actual['sha256'],str(q)
   members[m.name]=actual;seen[m.name]=actual
  assert inventory is not None
  assert {v['path']:{'bytes':v['bytes'],'sha256':v['sha256']} for v in inventory['files']}==members
  assert len(members)==a['payloadFiles'] and sum(v['bytes'] for v in members.values())==a['payloadBytes']
  archives.append({**a,'independentlyVerified':True})
assert set(seen)==set(paths)
assert len(seen)==index['payloadFiles']==43938
assert sum(v['bytes'] for v in seen.values())==index['payloadBytes']==198057357
assert sum(a['payloadFiles'] for a in archives)==len(seen)
assert all(a['verification']['exitCode']==0 for a in archives)
save('independent-payload-map.json',seen)
save('selection.snapshot.json',selection)
save('publication-index.snapshot.json',index)
save('publication-review.json',{'roots':len(selection['roots']),'directFiles':len(selection['files']),'exactBeforeWalkExclusions':len(exclusions),'linkRepresentations':link_records,'archives':archives,'payloadFiles':len(seen),'payloadBytes':sum(v['bytes'] for v in seen.values()),'compressedBytes':sum(a['bytes'] for a in archives),'currentOriginalsAndBeforeAfterAndUnionAndInnerInventoryMatch':True,'duplicatePaths':[],'missingPaths':[],'payloadMode':'0644 representation; executable modes not claimed','priorFailuresPreservedByCompleteSelectedPathUnion':True,'noRuntimeOrJavaOrEvidenceToolReplay':True})
print(json.dumps({'archives':len(archives),'payloads':len(seen),'payloadBytes':index['payloadBytes'],'compressedBytes':sum(a['bytes'] for a in archives),'allChecksPass':True}))
