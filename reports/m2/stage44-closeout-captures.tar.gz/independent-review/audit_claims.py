from pathlib import Path
import collections,hashlib,json,subprocess
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PRIOR=ROOT.parent/'pkl-rs.stage42/target/m2';CAND=PRIOR/'stage44-lossless-platform-candidate-01'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,x):(OUT/p).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
checkpoint=load(ROOT/'reports/m2/stage44-implementation-checkpoint.json')
summary=load(ROOT/'reports/m2/stage44-platform-summary.json')
assert checkpoint['fullM2Complete'] is False
for key in ['requiredRustChecks','portable','independentCodeReview']:
 d=checkpoint[key];p=d.get('report',d.get('summary'));assert sha(ROOT/p)==d['sha256']
assert sha(ROOT/checkpoint['evidenceIndex'])==checkpoint['evidenceIndexSha256']
assert (ROOT/'reports/m2/stage44-required-checks.json').read_bytes()==(ROOT/'target/m2/stage44-required-checks-01/report.json').read_bytes()
assert (ROOT/'reports/m2/stage44-code-review.json').read_bytes()==(PRIOR/'stage44-independent-review-01/report.json').read_bytes()
assert checkpoint['sourceProof']==load(ROOT/'target/m2/stage44-index-validation-01/report.json')
# Follow declared report paths only. Preserve outcome classifications.
for x in summary['regressions'].values(): assert sha(CAND/x['reportPath'])==x['reportSha256']
assert sha(CAND/'standard/report.json')==summary['standard']['reportSha256']
assert sha(CAND/'lossless-host11/execution.json')==summary['newHost11']['reportSha256']
standard=load(CAND/'standard/report.json')
assert standard['total']==standard['shared_engine_passed']==6078
assert standard['compatibility_status']=='fail' and standard['experiment_contract_status']=='pass' and standard['source_stability']
for p,h in summary['artifacts'].items():assert sha(CAND/'standard'/p)==h
host=load(CAND/'lossless-host11/execution.json');assert host['cases']==11 and host['repetitions']==2 and host['oracleApiEvaluations']==80
assert not host['infrastructureErrors'] and not host['browserErrors'] and not host['changedInputs']
raw_pairs=0;target_counts={}
for target,t in host['targets'].items():
 assert t['complete'] and len(t['results'])==22
 counts=collections.Counter();ids=set();calls=0
 for row in t['results']:
  key=(row['id'],row['repeat']);assert key not in ids;ids.add(key)
  counts[row['status']]+=1
  assert row['status']=='pass' and row['rawMatch'] and row['logsMatch'] and row['requestCountsMatch'] and row['resourceReadCountsMatch'] and row['architectureMatch'] and row['acquisitionError'] is None
  folder=CAND/'lossless-host11'/target/row['id']/str(row['repeat']);actual=load(folder/'actual.json');expected=load(folder/'expected.json')
  assert actual['acquisitionError'] is None and actual['architecture']['terminalSlots']==0 and actual['architecture']['ownedResultsStable']
  assert len(actual['results'])==len(expected['results'])
  assert actual['callbacks']==expected['callbacks']==[] and actual['logs']==expected['logs']==[]
  observed=collections.Counter(q['kind'] for q in actual['requests'])
  assert all(observed[k]==n for k,n in expected['requestCounts'].items()) and not(set(observed)-set(expected['requestCounts']))
  scope=expected['resourceReadScopePrefix']; reads=collections.Counter(q['uri'] for q in actual['reads'] if q['uri'].startswith(scope))
  assert all(reads[k]==n for k,n in expected['resourceReadCounts'].items()) and not(set(reads)-set(expected['resourceReadCounts']))
  for i,(a,e) in enumerate(zip(actual['results'],expected['results'])):
   assert a['actionIndex']==e['actionIndex'] and a['kind']==e['kind']
   units=a['errorUnits'] if a['kind']=='error' else a['valueUnits']
   expected_units=e['javaErrorUnits'] if e['kind']=='error' else e['javaValueUnits'];assert units==expected_units
   if a['kind']=='error':assert a['disposition']=='language-error'
   be=b''.join(int(u).to_bytes(2,'big') for u in units)
   java_utf8=be.decode('utf-16-be',errors='surrogatepass').encode('utf-8',errors='replace')
   assert java_utf8.hex()==e['javaUtf8Hex']
   for suffix,b in [('actual.bin',java_utf8),('java.bin',bytes.fromhex(e['javaUtf8Hex'])),('actual.utf16be.bin',be),('java.utf16be.bin',be)]:
    assert (folder/f'results-{i}.{suffix}').read_bytes()==b;raw_pairs+=1
   calls+=1
 assert calls==80 and dict(counts)=={'pass':22}
 target_counts[target]={'graphs':22,'calls':calls,'pass':calls}
assert target_counts==summary['newHost11']['targets']
for name in ['trace45','pcf192']:
 report=load(CAND/summary['regressions'][name]['reportPath'])
 for target,t in report['targets'].items():
  counts=dict(collections.Counter(r['status'] for r in t['results']));assert counts==t['statusCounts']==summary['regressions'][name]['targets'][target]['statusCounts']
  assert counts==({'pass':58,'oracle-error':32} if name=='trace45' else {'pass':384})
# Explicitly bind staged production changes and closeout prose without changing inputs.
indexmap=load(OUT/'independent-source-map.json')
changed=subprocess.check_output(['git','diff','--cached','--name-only','--','crates','xtask','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','references.lock','.gitmodules'],cwd=ROOT).decode().splitlines()
assert all(p in indexmap for p in changed)
docs=['README.md','PLAN.md','reports/m2/README.md','docs/architecture.md','reports/m2/stage44-implementation-checkpoint.json','reports/m2/stage44-platform-summary.json','reports/m2/stage44-required-checks.json','reports/m2/stage44-code-review.json']
doc_bindings={}
for p in docs:
 b=(ROOT/p).read_bytes();assert subprocess.check_output(['git','show',':'+p],cwd=ROOT)==b,p
 dest=OUT/'closeout-snapshots'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);doc_bindings[p]=hashlib.sha256(b).hexdigest()
save('claims-review.json',{'allExactReportCopiesAndHashesMatch':True,'hostCallsEachTarget':target_counts,'independentSavedRawPayloadChecks':raw_pairs,'hostBoundary':'exact UTF16 and separately Java UTF8; optional producer-phase class metadata is not cross-runtime identity','knownNonPassesPreserved':{'primitiveRegex':2,'traceEachTarget':{'pass':58,'oracle-error':32}},'stagedProductionChangesCovered':changed,'stagedCloseoutDocumentBindings':doc_bindings,'noWholeM2OrFullCorpusCompletionClaim':True})
print(json.dumps({'claims':'pass','rawPayloadChecks':raw_pairs,'stagedProductionFiles':len(changed),'stagedCloseoutFiles':len(docs)}))
