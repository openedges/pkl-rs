from pathlib import Path
import hashlib,json,os,re,subprocess
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
PRIOR=ROOT.parent/'pkl-rs.stage42/target/m2'
def load(p): return json.loads(Path(p).read_text())
def sha(p):
 p=Path(p); return hashlib.sha256(os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()).hexdigest()
def save(p,x): (OUT/p).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
required=ROOT/'target/m2/stage44-required-checks-01'
before=load(required/'sources.before.json');after=load(required/'sources.after.json')
assert before==after
platform=load(PRIOR/'stage44-lossless-platform-candidate-01/standard/sources.json')
tools=load(PRIOR/'stage44-lossless-platform-candidate-01/final-tooling-map.json')['files']
expected=dict(before)
for group in [platform,tools]:
 for p,h in group.items():
  assert p not in expected or expected[p]==h,p
  expected[p]=h
indexmap=load(ROOT/'target/m2/stage44-index-validation-01/sources.json')
assert expected=={p:v['sha256'] for p,v in indexmap.items()}
for p,h in expected.items(): assert sha(ROOT/p)==h,p
# Read actual staged entries and pinned tree blobs, not report-only identities.
entries={}
for record in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=ROOT).split(b'\0'):
 if not record: continue
 meta,p=record.split(b'\t',1); mode,oid,stage=meta.decode().split(); assert stage=='0'
 entries[p.decode()]={'gitMode':mode,'gitBlob':oid,'repository':'.'}
pins={'external/pkl':'e51fb2f91774265666f94980ec630db794a4db2d','external/pkl-pantry':'904a68184e54da378b0a0e8a911a3fab3956f693'}
for repo,commit in pins.items():
 assert entries[repo]['gitMode']=='160000' and entries[repo]['gitBlob']==commit
 for row in subprocess.check_output(['git','ls-tree','-rz',commit],cwd=ROOT/repo).split(b'\0'):
  if not row: continue
  meta,p=row.split(b'\t',1);mode,kind,oid=meta.decode().split()
  if kind=='blob':entries[repo+'/'+p.decode()]={'gitMode':mode,'gitBlob':oid,'repository':repo,'referenceCommit':commit}
selected={p:{**entries[p],'sha256':h} for p,h in sorted(expected.items())}
assert selected==indexmap
blob_count=0
for repo in ['.',*pins]:
 ids=sorted({v['gitBlob'] for v in selected.values() if v['repository']==repo})
 raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT/repo,input=('\n'.join(ids)+'\n').encode())
 pos=0;hs={}
 for oid in ids:
  end=raw.index(b'\n',pos);actual,kind,size=raw[pos:end].decode().split(); assert actual==oid and kind=='blob'
  pos=end+1; payload=raw[pos:pos+int(size)]; assert len(payload)==int(size);pos+=int(size);assert raw[pos:pos+1]==b'\n';pos+=1
  hs[oid]=hashlib.sha256(payload).hexdigest()
 assert pos==len(raw)
 for p,v in selected.items():
  if v['repository']==repo: assert hs[v['gitBlob']]==v['sha256'],p
 blob_count+=len(ids)
promotion=load(ROOT/'target/m2/stage44-promotion-01/report.json')
promoted=load(ROOT/'target/m2/stage44-promotion-01/sources.json')
core=load(PRIOR/'stage44-core-checkpoint-01/source-hashes.json')
assert sha(PRIOR/'stage44-core-checkpoint-01/report.json')==promotion['checkpointSha256']
assert sha(PRIOR/'stage44-core-checkpoint-01/source-hashes.json')==promotion['sourceMapSha256']
assert sha(PRIOR/'stage44-lossless-platform-candidate-01/final-tooling-map.json')==promotion['toolingMapSha256']
for p,h in core.items():assert before[p]==h and sha(ROOT/p)==h,p
for p,h in promoted.items():assert expected[p]==h and sha(ROOT/p)==h,p
report=load(required/'report.json'); commands=load(required/'commands.json')
assert commands==report['commands'] and len(commands)==5 and all(x['exitCode']==0 for x in commands)
counts={'passed':0,'failed':0,'ignored':0,'filteredOut':0}
for row in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; \d+ measured; (\d+) filtered out',(required/'3.stdout.bin').read_text()):
 for k,n in zip(counts,row):counts[k]+=int(n)
assert counts==report['workspaceHarnessInvocations']
assert counts=={'passed':692,'failed':0,'ignored':1,'filteredOut':36}
save('independent-source-map.json',selected)
save('source-review.json',{'requiredInputs':len(before),'platformInputs':len(platform),'toolInputs':len(tools),'uniquePaths':len(expected),'repositoryBlobs':blob_count,'projectPaths':sum(v['repository']=='.' for v in selected.values()),'referencePaths':sum(v['repository']!='.' for v in selected.values()),'allCurrentHashesMatch':True,'allActualStagedAndPinnedBlobsMatch':True,'coreInputs':len(core),'promotedInputs':len(promoted),'commands':commands,'harnessInvocations':counts,'noEvaluatorOrBuildRuns':True,'readOnlyGitCommands':['ls-files --stage -z','ls-tree -rz PIN','cat-file --batch']})
print(json.dumps(load(OUT/'source-review.json')))
