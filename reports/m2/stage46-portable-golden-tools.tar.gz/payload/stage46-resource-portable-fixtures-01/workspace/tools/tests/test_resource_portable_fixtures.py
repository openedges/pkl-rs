import importlib.util,unittest,subprocess,sys
from pathlib import Path
TOOLS=Path(__file__).parents[1]
def load(name):
 spec=importlib.util.spec_from_file_location(name,TOOLS/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
export=load('export_resource_portable');check=load('resource_fixtures')
class Contract(unittest.TestCase):
 def test_exact_success_status(self):self.assertEqual(export.parse_status(b'success\n'),'success')
 def test_exact_error_status(self):self.assertEqual(export.parse_status(b'error\n'),'error')
 def test_no_status_trim(self):
  for raw in [b'success',b' success\n',b'success\n\n',b'error\r\n',b'unsupported\n']:
   with self.assertRaises(ValueError):export.parse_status(raw)
 def test_java_unpaired_high_surrogate(self):self.assertEqual(export.java_utf8([0xD800]),b'?')
 def test_java_unpaired_low_surrogate(self):self.assertEqual(export.java_utf8([0xDC00]),b'?')
 def test_java_surrogate_pair(self):self.assertEqual(export.java_utf8([0xD83D,0xDE00]),b'\xf0\x9f\x98\x80')
 def test_invalid_unit_not_wrapped(self):
  with self.assertRaises(ValueError):export.java_utf8([65536])
 def test_half_utf16_byte_rejected(self):
  with self.assertRaises(ValueError):export.units(b'\x00')
 def test_missing_input_rule(self):self.assertEqual(check.derive('resource',{'workspace':'.'},dict(uri='res:/missing',attempt=1,total=2),Path('.'),{}),{'kind':'missing'})
 def test_typed_io_first_attempt(self):self.assertEqual(check.derive('resource',{'workspace':'.'},dict(uri='res:/retry',attempt=1,total=3),Path('.'),{}),{'kind':'io','message':'reader-first'})
 def test_authority_returns_actual_spelling(self):self.assertEqual(check.derive('authority',{'workspace':'.'},dict(uri='mem://HOST:080/item',attempt=1,total=1),Path('.'),{}),{'kind':'resource','resourceUri':'mem://HOST:080/item','bytes':list(b'payload-1')})
 def test_unknown_reader_not_defaulted(self):
  with self.assertRaises(ValueError):check.derive('resource',{'workspace':'.'},dict(uri='other:/unexpected',attempt=1,total=1),Path('.'),{})
 def test_portable_full_fixture_cli(self):
  base=TOOLS.parent/'tests/fixtures';fixture=base/'m2-resource-portable-final'
  if not fixture.exists():fixture=base/'m2-resource-portable'
  result=subprocess.run([sys.executable,str(TOOLS/'resource_fixtures.py'),'--fixtures',str(fixture)],capture_output=True);self.assertEqual(result.returncode,0,result.stderr)
if __name__=='__main__':unittest.main()
