"""Hermetic verification of Java-derived portable Resource fixtures."""
from pathlib import Path
import argparse,hashlib,json,re,sys,importlib.util
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('export',Path(__file__).with_name('export_resource_portable.py'));export=importlib.util.module_from_spec(spec);spec.loader.exec_module(export)
sha=export.sha

def contained(root,name):
 p=Path(name)
 if p.is_absolute()or'..'in p.parts:raise ValueError('unsafe fixture path')
 q=root/p
 if not q.resolve().is_relative_to(root.resolve())or q.is_symlink():raise ValueError('unsafe fixture link')
 return q

def derive(group,case,trace,root,bindings):
 uri=trace['uri'];attempt=trace['attempt'];total=trace['total'];work=Path(case['workspace'])
 if group=='authority':return {'kind':'resource','resourceUri':uri,'bytes':list(('payload-'+str(total)).encode())}
 if uri=='res:/missing':return {'kind':'missing'}
 if uri=='res:/retry'and attempt==1:return {'kind':'io','message':'reader-first'}
 if uri=='res:/resource':return {'kind':'resource','resourceUri':'res:/different-returned-uri','bytes':[65,13,10,0,66]}
 if re.fullmatch(r'res:/vector\d+',uri):
  n=uri[len('res:/vector'):];p=work/'payloads'/('vector'+n+'.bin');return {'kind':'resource','resourceUri':'res:/returned/vector'+n,'bytes':list(contained(root,bindings[str(p)]['path']).read_bytes())}
 if re.fullmatch(r'res:/b64-\d+',uri):
  n=uri[len('res:/b64-'):];p=work/'payloads'/('b64-'+n+'.units.bin');return {'kind':'text','units':export.units(contained(root,bindings[str(p)]['path']).read_bytes())}
 if uri in {'res:/key','res:/retry'}:return {'kind':'text','units':export.units(('payload-'+str(total)+' '+uri).encode('utf-16-be'))}
 raise ValueError('unknown captured Java reader rule')

def verify(root):
 manifest=json.loads((root/'manifest.json').read_bytes())
 if manifest['schema']!=1 or not manifest['files']:raise ValueError('empty/unknown manifest')
 for name,record in manifest['files'].items():
  p=contained(root,name)
  if sha(p)!=record['sha256']or p.stat().st_size!=record['bytes']:raise ValueError('fixture file differs: '+name)
 data=json.loads((root/'fixtures.json').read_bytes());provenance=json.loads((root/'provenance.json').read_bytes());bindings=provenance['originalPaths'];reports={};cases={};inventories={}
 for group,(name,pin)in export.PINS.items():
  p=root/'provenance'/group/'report.json'
  if sha(p)!=pin or provenance['groups'][group]['reportSha256']!=pin:raise ValueError('independent Java report pin differs')
  report=json.loads(p.read_bytes());reports[group]=report;casepath=root/'provenance'/group/'cases.json';originalroot=Path(provenance['groups'][group]['originalRoot'])
  if originalroot.name!=name or sha(casepath)!=report['inputHashes'][str(originalroot/'cases.json')]:raise ValueError('Java original cases differ')
  cases[group]={c['id']:c for c in json.loads(casepath.read_bytes())};inventories[group]={r['path']:r for r in json.loads((root/'provenance'/group/'inventory.json').read_bytes())['files']}
  helper={'resource':'ResourceProbe.java','authority':'AuthorityProbe.java','base64':'Base64Probe.java','extra':'ExtraProbe.java'}[group];helperpath=root/'provenance'/group/helper
  if sha(helperpath)!=report['inputHashes'][str(originalroot/helper)]:raise ValueError('Java reader rule source differs')
 for original,record in bindings.items():
  p=contained(root,record['path'])
  if sha(p)!=record['sha256']or p.stat().st_size!=record['bytes']:raise ValueError('original path binding differs')
  group=next((g for g,v in provenance['groups'].items()if Path(original).is_relative_to(Path(v['originalRoot']))),None)
  if group:
   relative=Path(original).relative_to(Path(provenance['groups'][group]['originalRoot'])).as_posix();pin=inventories[group].get(relative)
   if pin and(sha(p)!=pin['sha256']or p.stat().st_size!=pin['bytes']):raise ValueError('raw Java inventory binding differs')
   if record['kind']in {'Pkl source','Java expression sequence','raw resource bytes','raw UTF16 String reader input'}and sha(p)!=reports[group]['inputHashes'][original]:raise ValueError('Java source/input identity differs')
 expected_keys=[];excluded=[]
 for group in export.PINS:
  for ob in reports[group]['observations']:
   for session in [0,1]:
    calls=[c for c in ob['calls']if c['session']==session];selected=[c for c in calls if export.eligible(ob['case'],c)]
    if selected:expected_keys.append((group+'/'+ob['case'],ob['repeat'],session))
    for c in calls:
     if not export.eligible(ob['case'],c):excluded.append((group,ob['case'],ob['repeat'],session,c['prefix'],c['source'],c['expression']))
 if [(f['id'],f['repeat'],f['session'])for f in data['fixtures']]!=expected_keys:raise ValueError('session ordering/coverage differs')
 if [(r['group'],r['id'],r['repeat'],r['session'],r['prefix'],r['source'],r['expression'])for r in data['unexecutedApiBoundaries']]!=excluded:raise ValueError('unexecuted boundaries differ')
 selected_total=0;encoding_differences=0
 for f in data['fixtures']:
  group,case_id=f['id'].split('/',1);case=cases[group][case_id];report=reports[group];ob=next(o for o in report['observations']if o['case']==case_id and o['repeat']==f['repeat']);calls=[c for c in ob['calls']if c['session']==f['session']and export.eligible(case_id,c)];session=next(s for s in provenance['sessions']if(s['id'],s['repeat'],s['session'])==(f['id'],f['repeat'],f['session']))
  if f['source'].encode()!=contained(root,session['sourcePath']).read_bytes()or sha(contained(root,session['sourcePath']))!=report['inputHashes'][str(Path(case['workspace'])/'main.pkl')]or f['uri']!=case['sourceUri']or f['moduleName']!='main':raise ValueError('source/URI identity differs')
  if f['expressions']!=[c['expression']for c in calls]or len(f['expected'])!=len(calls):raise ValueError('API sequence differs')
  for actual,c,rawref in zip(f['expected'],calls,session['selectedRawJava']):
   stem=rawref['rawLocalPrefix'];read=lambda suffix:contained(root,stem+'.'+suffix).read_bytes();status=export.parse_status(read('status.bin'));target='stdout'if status=='success'else'stderr'
   if read('status.bin')!=c['status'].encode()or read(target+'.bin').hex()!=c['utf8Hex']or read(target+'.code-units.bin').hex()!=c['utf16BEHex']or c['errorClass']not in {'','org.pkl.core.PklException'}:raise ValueError('raw Java call/status differs')
   expected={'status':status,'stdoutUnits':export.units(read('stdout.code-units.bin')),'stderrUnits':export.units(read('stderr.code-units.bin')),'stdoutHex':read('stdout.bin').hex(),'stderrHex':read('stderr.bin').hex(),'readsBefore':int(read('reads-before.bin')),'readsAfter':int(read('reads-after.bin'))}
   if actual!=expected:raise ValueError('portable expected raw outputs/counts differ from Java')
   for channel in ['stdout','stderr']:
    if export.java_utf8(actual[channel+'Units']).hex()!=actual[channel+'Hex']:raise ValueError('Java UTF16/UTF8 relationship differs')
    node=bytes.fromhex(actual[channel+'Hex']);words=actual[channel+'Units'];js=''.join(chr(w)for w in words).encode('utf-16-le','surrogatepass').decode('utf-16-le','replace').encode('utf-8')
    if js!=node:encoding_differences+=1
   selected_total+=1
  if len(f['readerPlan'])!=len(session['readerTrace']):raise ValueError('reader trace count differs')
  for index,(plan,trace)in enumerate(zip(f['readerPlan'],session['readerTrace'])):
   value=contained(root,trace['rawPath']).read_bytes();match=re.fullmatch(rb'reader (.*?) attempt=(\d+) total=(\d+)',value)
   if not match or(trace['uri'],trace['attempt'],trace['total'])!=(match.group(1).decode(),int(match.group(2)),int(match.group(3)))or trace['total']!=index+1:raise ValueError('actual Java ordered reader event differs')
   if plan!={'uri':trace['uri'],'result':derive(group,case,trace,root,bindings)}:raise ValueError('reader input plan differs from Java helper rule')
 if data['schema']!=1 or data['javaApiCalls']!=sum(r['apiCalls']for r in reports.values())or data['javaApiCalls']!=1272 or selected_total!=1008 or len(excluded)!=264 or len(data['fixtures'])!=20:raise ValueError('coverage counts differ')
 return {'sessions':20,'selectedJavaApiCalls':1008,'allJavaApiCalls':1272,'unexecuted':264,'javaVsJsUtf8DifferentChannels':encoding_differences,'manifestSha256':sha(root/'manifest.json')}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--fixtures',required=True,type=Path);a=p.parse_args()
 try:print(json.dumps(verify(a.fixtures),indent=2));return 0
 except(OSError,ValueError,KeyError,StopIteration)as error:print('Resource portable fixture verification failed: '+str(error),file=sys.stderr);return 1
if __name__=='__main__':sys.exit(main())
