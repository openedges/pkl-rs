from pathlib import Path
import hashlib,json,os,tarfile,shutil
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2];PUB=ROOT/'target/m2/stage42-final-publication-01';STAGE42=ROOT.parent/'pkl-rs.stage42/target/m2'
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(n,x):(OUT/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
selection=load(PUB/'selection.json');before=load(PUB/'inputs.before.json');after=load(PUB/'inputs.after.json');assert before==after
index=load(ROOT/'reports/m2/stage42-final-regression-captures.json');assert index==load(PUB/'report.json')
assert index['sourceChanges']==[] and index['fullM2Complete'] is False
exclusions={Path(p) for p in selection['excludedBeforeTraversal']}
# Exact paths declared before traversal; no generic build filter and no link following.
paths={}
for row in selection['roots']:
 root=Path(row['source']);assert root not in exclusions
 for directory,dirs,names in os.walk(root,followlinks=False):
  directory=Path(directory);dirs[:]=sorted(d for d in dirs if directory/d not in exclusions)
  assert not any((directory/d).is_symlink() for d in dirs),str(directory)
  for name in sorted(names):
   p=directory/name
   if p in exclusions:continue
   assert p.is_file() and not p.is_symlink(),str(p)
   dest=str(Path(row['archivePrefix'])/p.relative_to(root));assert dest not in paths;paths[dest]=p
for row in selection['files']:
 p=Path(row['source']);dest=row['archivePath'];assert p.is_file() and not p.is_symlink() and dest not in paths;paths[dest]=p
assert set(paths)==set(before)
for p,v in paths.items():assert str(v)==before[p]['originalPath']
seen={};archives=[]
for a in index['archives']:
 p=ROOT/a['path'];assert p.stat().st_size==a['bytes'] and sha(p)==a['sha256']
 with tarfile.open(p,'r:gz') as tf:
  inventory=None;members={}
  for m in tf:
   assert m.isfile() and m.mode==0o644,m.name
   assert not m.name.startswith('/') and '..' not in Path(m.name).parts,m.name
   b=tf.extractfile(m).read();assert len(b)==m.size
   if m.name=='EVIDENCE.json':assert inventory is None;inventory=json.loads(b);continue
   assert m.name not in seen and m.name in paths,m.name
   actual={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert actual=={k:before[m.name][k] for k in actual},m.name
   q=paths[m.name];assert q.stat().st_size==len(b) and sha(q)==actual['sha256'],str(q)
   members[m.name]=actual;seen[m.name]=actual
  assert {v['path']:{'bytes':v['bytes'],'sha256':v['sha256']} for v in inventory['files']}==members
  assert len(members)==a['payloadFiles'] and sum(v['bytes'] for v in members.values())==a['payloadBytes']
 archives.append({**a,'independentHashMembershipAndOriginalByteChecks':True})
 print('verified archive',a['path'],len(members),flush=True)
assert set(seen)==set(paths) and len(seen)==index['payloadFiles']==58233
assert sum(v['bytes'] for v in seen.values())==index['payloadBytes']==98231160
assert sum(a['bytes'] for a in archives)==15035063
# Reuse the independently verified map identities, then bind every declared payload to archive union.
review=STAGE42/'stage42-final-regression-review-02';previous=load(review/'report.json')
assert sha(review/'report.json')=='718ae58620bfe6e5342554d7e7f4886567ee6e1303c455c67fbc96fd55a44b21'
for name in ['stage42-language-final-02','stage42-class-lifecycle-final-02']:
 report=load(STAGE42/name/'report.json');prefix='stage42-worktree/target/m2/'+name+'/'
 for rel,h in report['evidence_sha256'].items():assert seen[prefix+rel]['sha256']==h
 if 'source_sha256' in report:
  for rel,h in report['source_sha256'].items():assert seen[prefix+'sources/'+rel]['sha256']==h
 else:
  for r in report['sources']:assert seen[prefix+r['snapshot']]['sha256']==r['sha256']
summary=load(ROOT/'reports/m2/stage42-final-summary.json')
for name in ['source_binding','source_map','independent_regression_review','acquisition_audit','raw_captures','required_checks_and_platform_scope']:
 r=summary[name];assert sha(ROOT/r['path'])==r['sha256'],name
copies={'source_binding':review/'source-binding-report.json','source_map':review/'independent-commit-source-map.json','independent_regression_review':review/'report.json','acquisition_audit':STAGE42/'stage42-full-regression-audit-02/report.json'}
for name,origin in copies.items():assert (ROOT/summary[name]['path']).read_bytes()==origin.read_bytes()
assert summary['implementation_commit']=='7544699a9af8d5e1f200be5d2a6493884d164903' and summary['recorded_checkout']=='058d22417b3959ad5bdfb3b03f5f664003e67a53'
assert summary['selected_status_counts']==previous['language']['newStatuses']
assert summary['status_changes_from_pre_correction']==previous['language']['statusChanges']
assert summary['failures']==previous['language']['nonpasses']
assert summary['full_gate_failure_reasons']==previous['language']['fullGateReasons']==1837
assert summary['raw_language_changes_from_previous']==previous['language']['rawChangedRecords']
assert summary['non_path_raw_change_ids']==previous['language']['nontransportChangedIds']
assert summary['gates']==previous['terminal']['recordedCommandExits']
assert summary['persistent_calls_each_language']==2782 and summary['persistent_sequence_executions']==334 and summary['persistent_sequence_definitions']==167
assert summary['persistent_raw_changes_from_previous']==0
assert summary['persistent_status_counts_each']==previous['lifecycle']['callStatuses']['java']==previous['lifecycle']['callStatuses']['rust']
assert summary['unique_source_paths_bound']==4070 and summary['unique_project_blobs']==3942 and summary['original_module_inputs_bound_to_pinned_blobs']==137
assert not summary['full_m2_complete'] and not summary['compatibility_complete'] and not summary['hosted_ci_claimed'] and not summary['performance_target_claimed']
# All 4527 definitions, not just selected rows, are byte-structurally unchanged.
a=load(STAGE42/'stage42-language-final-01/sources/compatibility/m2-language.json');b=load(STAGE42/'stage42-language-final-02/sources/compatibility/m2-language.json')
assert a['cases']==b['cases'] and len(b['cases'])==4527 and summary['all_4527_case_definitions_unchanged']
for n in ['README.md','PLAN.md','reports/m2/README.md','reports/m2/stage42-final-summary.json']:
 p=ROOT/n;q=OUT/'closeout-snapshots'/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
put('independent-union-map.json',seen);put('selection.snapshot.json',selection);put('index.snapshot.json',index)
put('report.json',{'schema':1,'status':'pass-no-blocking-finding','scope':'Independent final Stage42 archive union and historical summary/docs scope; reused closed source/raw regression audit without evaluator or check replay.','archives':archives,'payloadFiles':len(seen),'payloadBytes':sum(v['bytes'] for v in seen.values()),'compressedBytes':sum(a['bytes'] for a in archives),'selectionRoots':len(selection['roots']),'directFiles':len(selection['files']),'exactExclusionsBeforeTraversal':sorted(str(p) for p in exclusions),'completeOriginalBeforeAfterUnionAndInnerInventoryEquality':True,'declaredSourceAndEvidenceMapsInUnion':True,'summaryCopiesLinksAndCountsMatchClosedAudit':True,'all4527CaseDefinitionsUnchanged':True,'historicalImplementation':summary['implementation_commit'],'recordedCheckout':summary['recorded_checkout'],'sourceProofReused':{'review':str(review/'report.json'),'sha256':sha(review/'report.json')},'knownNonPasses':summary['selected_status_counts'],'fullGateReasons':1837,'noNormalization':True,'noEvaluatorOrCheckOrBuildOrGitMutation':True,'payloadModes':'0644 archive representation; executable modes not claimed','fullM2Complete':False})
print('all archive/summary checks pass',flush=True)
