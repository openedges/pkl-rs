"""Preserve closed Stage 37 observations, pruning named Cargo caches before traversal."""
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'target/m2/stage37-origins-seal-01'
OUT.mkdir(exist_ok=False)
ARCHIVE=ROOT/'reports/m2/stage37-origins-evidence.tar.gz'
assert not ARCHIVE.exists()
roots={name:ROOT.with_name('pkl-rs.'+name)/'target/m2' for name in ['stage36','stage37']}
excluded={'stage37':{'stage37-bindings-cargo','stage37-core-cargo','stage37-frontend-cargo','stage37-platform-cargo','stage37-trace-comparison-02/build'},'stage36':set()}
def sha(p):
 return hashlib.sha256(p.read_bytes()).hexdigest()
entries={}; sources={}; selections={}
for label,root in roots.items():
 selections[label]=[p.name for p in sorted(root.iterdir()) if p.name.startswith('stage37-') and p.name not in excluded[label]]
 for name in selections[label]:
  selected=root/name
  if selected.is_symlink(): raise ValueError('Unexpected source symlink: '+str(selected))
  paths=[]
  if selected.is_file(): paths=[selected]
  else:
   for folder,dirs,files in os.walk(selected):
    dirs[:]=sorted(d for d in dirs if str((Path(folder)/d).relative_to(root)) not in excluded[label])
    for child in dirs:
     if (Path(folder)/child).is_symlink(): raise ValueError('Unexpected directory symlink')
    paths.extend(Path(folder)/f for f in sorted(files))
  for p in paths:
   if p.is_symlink() or not p.is_file(): raise ValueError('Unexpected evidence entry: '+str(p))
   key=label+'/target/m2/'+str(p.relative_to(root))
   assert key not in entries
   entries[key]={'sha256':sha(p),'bytes':p.stat().st_size};sources[key]=p
inventory={'schema':1,'scope':'Original Stage37 Java observations, source snapshots, intermediate failures, reviews and frozen worktree checks. MAIN final acquisitions are separate.',
 'source_roots':{k:str(v) for k,v in roots.items()},'selected_roots':selections,
 'excluded_before_traversal':{k:sorted(v) for k,v in excluded.items()},'files':entries,
 'helper_sha256':sha(Path(__file__))}
encoded=(json.dumps(inventory,indent=2)+'\n').encode()
(OUT/'inventory.json').write_bytes(encoded)
with tarfile.open(ARCHIVE,'w:gz',compresslevel=6) as archive:
 for name,p in sources.items():
  assert sha(p)==entries[name]['sha256'],name
  archive.add(p,arcname=name,recursive=False)
  assert sha(p)==entries[name]['sha256'],name
 for name,data in [('inventory.json',encoded),('seal_origins.py',Path(__file__).read_bytes())]:
  info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
verified=set()
with tarfile.open(ARCHIVE,'r:gz') as archive:
 for member in archive:
  assert member.isfile()
  data=archive.extractfile(member).read()
  if member.name in entries:
   assert hashlib.sha256(data).hexdigest()==entries[member.name]['sha256'],member.name
   verified.add(member.name)
  elif member.name=='inventory.json': assert data==encoded
  elif member.name=='seal_origins.py': assert data==Path(__file__).read_bytes()
  else: raise ValueError('Unexpected archive member: '+member.name)
assert verified==set(entries)
summary={'schema':1,'scope':inventory['scope'],'archive':str(ARCHIVE.relative_to(ROOT)),
 'sha256':sha(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'original_files':len(entries),
 'inventory_files':len(entries)+2,'source_stability':True,
 'inventory_sha256':sha(OUT/'inventory.json'),'excluded_before_traversal':inventory['excluded_before_traversal'],
 'selected_root_counts':{k:len(v) for k,v in selections.items()}}
(OUT/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
(ROOT/'reports/m2/stage37-origins-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
