"""Read-only combined tooling review; no tests, Java, builds or Git mutations."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
FOCUSED = ROOT / "target/m2/classpath-combined-focused-01"
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: (ROOT / path).read_bytes()
obj = lambda path: json.loads(read(path))
parent = json.loads((FOCUSED / "report.json").read_bytes())
child_raw = (FOCUSED / "jvm-classpath/report.json").read_bytes()
child = json.loads(child_raw)
assert parent["schema_version"] == 4 and parent["source_stability"] and parent["artifact_stability"]
assert parent["classpath_eval"]["child_report_sha256"] == sha(child_raw)
assert parent["selected_count"] == 1 and parent["status_counts"] == {"pass": 1}
assert len(parent["results"]) == 1 and len(child["results"]) == 2
assert all(result["status"] == "pass" and not result["differences"] for result in child["results"])
assert parent["source_sha256"] == child["sources"] == child["sources_after"]
assert len(parent["source_sha256"]) == 3823
for name, expected in parent["source_sha256"].items():
    assert sha(read(name)) == expected, name
    assert sha((FOCUSED / "sources" / name).read_bytes()) == expected, name
    assert sha((FOCUSED / "jvm-classpath/sources" / name).read_bytes()) == expected, name
modules = "crates/pkl-runtime/src/stdlib/modules.txt"
assert modules in parent["source_sha256"]
assert parent["oracle"] == child["oracle"]
assert parent["classpath_candidate"]["source_binding"] == "recorded-build"
assert parent["classpath_candidate"]["build"]["exit_code"] == 0
assert parent["classpath_candidate"]["build"]["command"][-2:] == ["--target-dir", str(ROOT / "target")]
assert child["candidate"]["source_binding"] == "unbound-caller-supplied"
assert child["candidate"]["original_path"] == str(FOCUSED / "artifacts/jvm_snippet_probe")
artifact_sha = parent["classpath_candidate"]["sha256"]
assert artifact_sha == child["candidate"]["sha256"] == sha((FOCUSED / "artifacts/jvm_snippet_probe").read_bytes())
assert artifact_sha == sha((FOCUSED / "jvm-classpath/artifacts/jvm_snippet_probe").read_bytes())
assert child["artifacts_before"] == child["artifacts_after"]
for name, expected in child["artifacts_before"].items():
    assert sha((FOCUSED / "jvm-classpath/artifacts" / name).read_bytes()) == expected, name
assert all(command["name"] == "javac" for command in child["commands"])
assert not (FOCUSED / "build").exists() and not (FOCUSED / "jvm-classpath/build").exists()
workspace = Path(parent["classpath_eval"]["workspace"])
assert not workspace.is_relative_to(FOCUSED) and str(workspace) == child["workspace"]
for index, result in enumerate(child["results"]):
    for channel in ["stdout", "stderr"]:
        native = (FOCUSED / f"jvm-classpath/cases/{index}/rust/{channel}.bin").read_bytes()
        java = (FOCUSED / f"jvm-classpath/cases/{index}/java/{channel}.bin").read_bytes()
        assert native == java
        for target in ["java", "rust"]:
            assert sha(java) == result["processes"][target]["capture"]["sha256"][channel]
    assert all(result["processes"][target]["capture"]["exit_code"] == 0 for target in ["java", "rust"])
    assert all(not result["processes"][target]["capture"]["files"] for target in ["java", "rust"])
assert len(parent["full_gate_failures"]) == 5476

old = json.loads(subprocess.check_output(["git", "show", "97b4da0:compatibility/m2-language.json"], cwd=ROOT))
new = obj("compatibility/m2-language.json")
assert len(old["cases"]) == len(new["cases"]) == 4527
assert len(old["requirements"]) == len(new["requirements"]) == 475
assert [case["id"] for case in old["cases"]] == [case["id"] for case in new["cases"]]
changed = [(before["id"], sorted(key for key in before.keys() | after.keys() if before.get(key) != after.get(key)))
           for before, after in zip(old["cases"], new["cases"]) if before != after]
assert changed == [(parent["results"][0]["id"], ["adapter", "execution", "execution_profile"])]
assert parent["results"][0]["execution_profile"] == new["cases"][[case["id"] for case in new["cases"]].index(changed[0][0])]["execution_profile"]
for name in ["compatibility/corpus.json", "compatibility/m2-module-eval.json"]:
    assert read(name) == subprocess.check_output(["git", "show", "97b4da0:" + name], cwd=ROOT)

validation = {}
for suffix in ["01", "02", "03"]:
    path = f"target/m2/classpath-combined-validation-{suffix}/report.json"
    report = obj(path)
    validation[suffix] = {"complete": report["complete"], "commands": []}
    for command in report["commands"]:
        for stream in ["stdout", "stderr"]:
            assert sha(read(f"target/m2/classpath-combined-validation-{suffix}/{command['label']}.{stream}.bin")) == command[f"{stream}_sha256"]
        validation[suffix]["commands"].append({"label": command["label"], "exit_code": command["exit_code"], "expected_exit_code": command["expected_exit_code"]})
assert validation["01"]["commands"][-1]["exit_code"] == 1
assert validation["02"]["commands"][-1]["exit_code"] == 2
assert validation["03"]["complete"] and [command["exit_code"] for command in validation["03"]["commands"]] == [0, 0, 0, 0, 1]

sources = {path: path.read_text() for path in (ROOT / "crates/pkl-runtime/src").rglob("*.rs")}
test_modules = set()
for path, text in sources.items():
    for name in re.findall(r"#\[cfg\(test\)\]\s*mod\s+(\w+)\s*;", text):
        directory = path.parent if path.name in ["lib.rs", "main.rs", "mod.rs"] else path.with_suffix("")
        test_modules.add(directory / (name + ".rs"))
embeds = set()
for path, text in sources.items():
    if path in test_modules:
        continue
    for relative in re.findall(r'include_(?:str|bytes)!\s*\(\s*"([^"]+)"', text):
        embeds.add((path.parent / relative).resolve().relative_to(ROOT).as_posix())
assert embeds == {modules, "crates/pkl-runtime/src/stdlib/base.pkl", "crates/pkl-runtime/src/stdlib/test.pkl", "crates/pkl-runtime/src/stdlib/ref.pkl"}
assert embeds <= parent["source_sha256"].keys()

proposal_root = Path("/Users/cody.ij.hwang/Projects/pkl-rs.classpath/target/m2/classpath-m2-integration-captures-01")
proposal = json.loads((proposal_root / "proposed-manifest.json").read_bytes())
drift = [row["path"] for row in proposal["files"] if sha(read(row["path"])) != row["sha256"]]
assert drift == ["PLAN.md", "compatibility/m2-language.json", "tools/m2_source_inputs.py"]
before = (proposal_root / "proposed-sources/tools/m2_source_inputs.py").read_text()
after = read("tools/m2_source_inputs.py").decode()
assert after == before.replace("'docs/m2-jvm-classpath.md'}", "'docs/m2-jvm-classpath.md', 'crates/pkl-runtime/src/stdlib/modules.txt'}")
reviewed_paths = ["tools/m1_platforms.py", "tools/m2_source_inputs.py", "tools/tests/test_m1_platforms.py", "tools/tests/test_runtime_source_inputs.py"]
report = {"schema": 1, "status": "No new blocker in the four-file integration delta and recorded combined focused binding.",
          "scope": "Read-only review only; no test, Java, build, Git or source mutations. Focused one-case success does not verify the remaining3663selected cases.",
          "reviewed_source_sha256": {path: sha(read(path)) for path in reviewed_paths},
          "proposal_drift_exactly_expected": drift, "captured_parent_child_current_frozen_sources": 3823,
          "modules_txt_in_both_frozen_source_maps": True, "recorded_parent_build_child_supplied_artifact_join": True,
          "artifact_sha256": artifact_sha, "no_child_build": True, "external_child_workspace": True,
          "same_oracle_and_two_complete_raw_successes": True,
          "case_inventory": {"cases": 4527, "requirements": 475, "default_selected": 3664, "case_order_unchanged": True, "changes": changed},
          "historical_corpus_and_cli_registry_unchanged": True, "literal_runtime_embeds_reviewed": sorted(embeds),
          "test_scope": "Current simple literal include_str/include_bytes sites; externally declared cfg(test) module fixtures are correctly excluded. This is not a general Rust parser or compile-graph proof.",
          "validation_history": validation, "full_gate_failure_count": 5476,
          "parent_report_sha256": sha((FOCUSED / "report.json").read_bytes()), "child_report_sha256": sha(child_raw),
          "additional_findings": [], "full_m2_complete": False}
(OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "report_sha256": sha((OUT / "report.json").read_bytes())}))
