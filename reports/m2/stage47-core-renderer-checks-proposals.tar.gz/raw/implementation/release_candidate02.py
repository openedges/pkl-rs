from pathlib import Path
import datetime,hashlib,json,os,platform,shutil,stat,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent/'renderer-candidate-build-02'
PREVIOUS=Path(__file__).resolve().parent/'renderer-candidate-build-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
report=json.loads((OUT/'report.json').read_text());assert report['exit_code']==0 and report['source_stable']
paths=json.loads((OUT/'source-after.json').read_text());previous=json.loads((PREVIOUS/'source-after.json').read_text())
counts={'copies':0,'hardlinksFromImmutableStage47C01':0};modes={}
for name,digest in paths.items():
 src=ROOT/name;dst=OUT/'sources'/name;old=PREVIOUS/'sources'/name
 assert src.is_file() and not src.is_symlink() and sha(src)==digest,name
 dst.parent.mkdir(parents=True,exist_ok=True)
 mode=stat.S_IMODE(src.stat().st_mode)
 if previous.get(name)==digest and old.is_file() and stat.S_IMODE(old.stat().st_mode)==mode and sha(old)==digest:
  os.link(old,dst);counts['hardlinksFromImmutableStage47C01']+=1
 else:
  shutil.copy2(src,dst);counts['copies']+=1
 assert sha(dst)==digest and stat.S_IMODE(dst.stat().st_mode)==mode,name
 modes[name]=mode
artifacts={};(OUT/'artifacts').mkdir()
for name in ['module_eval_probe','stage45_annotation_probe']:
 src=ROOT/'target/stage47-cargo/debug/examples'/name;dst=OUT/'artifacts'/name
 shutil.copy2(src,dst);assert sha(src)==sha(dst)
 artifacts[name]={'path':str(dst),'sha256':sha(dst)}
for name,digest in paths.items():assert sha(ROOT/name)==digest,name
save('source-modes.json',modes)
environment={'host':platform.uname()._asdict(),'python':sys.version,'commands':[]}
for command in [['rustc','--version','--verbose'],['cargo','--version'],['rustup','show','active-toolchain']]:
 p=subprocess.run(command,cwd=ROOT,capture_output=True);assert p.returncode==0
 environment['commands'].append({'argv':command,'exit_code':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
save('environment.json',environment)
release={'schema':1,'started_utc':start,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tick,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'scope':'Shared JsonRenderer/RenderDirective with source-backed pkl:json.Property and Collection.join; eight renderer/join development regressions passed. C01 original moduleOutput2 passed twice and pcfRenderer9 missing join failed twice; this candidate requires fresh whole-input comparison. Document conversion/Directive undefined hints and evaluator-owned stdlib policy admission remain explicit followups. No full M2 compatibility claim.','artifact':artifacts['module_eval_probe']['path'],'artifact_sha256':artifacts['module_eval_probe']['sha256'],'artifacts':artifacts,'source_map':str(OUT/'source-after.json'),'source_map_sha256':sha(OUT/'source-after.json'),'source_snapshot':str(OUT/'sources'),'source_count':len(paths),'source_modes':str(OUT/'source-modes.json'),'source_modes_sha256':sha(OUT/'source-modes.json'),'build_report':str(OUT/'report.json'),'build_report_sha256':sha(OUT/'report.json'),'environment':str(OUT/'environment.json'),'environment_sha256':sha(OUT/'environment.json'),'snapshot_method':dict(explicit_map_paths=True,all_source_and_snapshot_hashes_verified=True,all_snapshot_modes_equal_live=True,**counts)}
save('release.json',release);print(json.dumps(dict(release=str(OUT/'release.json'),release_sha256=sha(OUT/'release.json'),source_map_sha256=release['source_map_sha256'],source_count=len(paths),artifacts=artifacts),indent=2))
