# Stage47 공통 JSON 렌더링 구현 계획

기준은 a3eb3634558cef6f36189320498fe7e013296c48과 pinned Pkl 0.32.0이다. Stage46 소스와 증거는 수정하지 않는다.

1. 기존 ValueRenderer RenderRun/Task/Await/GC 루트에 포맷 상태를 추가한다. JSON은 동일한 shallow force·converter·property annotation·Host suspension 경로를 사용한다.
2. JsonRenderer와 RenderDirective의 클래스 identity, 상속, source-backed defaults/methods를 등록한다. text는 UTF16 그대로 유지하고 bytes default는 기존 UTF8 encoding을 재사용한다.
3. JSON의 indent/omitNull/options, collection 순서, non-string key/혼합 Dynamic/비finite 오류, newline과 JsonEscaper를 pinned source 및 실제 Java raw 관찰로 대조한다.
4. ConvertProperty transformer/annotation 후 일반converter, null 생략과 중첩 renderValue의 실제 순서를 검증한다.
5. 원본 moduleOutput2.pkl와 pcfRenderer9.pkl 전체 입력·환경·리소스·기대채널을 유지하여 두 번 비교한다. 재현 사례로 원본을 대체하지 않는다.
6. 단계별 실패를 새 출력 디렉터리에 보존하고 coherent candidate source map/artifacts를 release한다. 이후 Rust5, 실제 native/Node/Chromium/lifecycle 비교는 별도 증거로 수집한다.

전체 M2 gate·다른 renderer·JSON parser 완료를 주장하지 않는다. Java 관찰과 미실행 경계는 별도로 계수한다.
