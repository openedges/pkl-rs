# JSON rendering and render directives

The shared runtime implements `JsonRenderer.renderValue` and `renderDocument`
through the same frame-owned renderer continuation as `PcfRenderer`. Native,
Wasm, and N-API adapters do not contain independent JSON evaluators. Renderer
options, lazy members, converters, property annotation callbacks, and nested
renderer calls can suspend through the existing Host interface.

JSON strings retain UTF-16 code units, including unpaired surrogates. Escaping
operates on those units; conversion to Java-compatible UTF-8 bytes happens at
the output boundary. Object and collection iteration preserves language order.
Property annotations run before value converters, and null omission runs after
conversion. Converter paths retain the original property name when an
annotation changes its output name. JSON document output ends with a newline;
`renderValue` does not add a document newline.

`RenderDirective` supplies verbatim text to JSON and PCF rendering. Reading its
`text` uses ordinary lazy forcing and type checks; these renderers do not force
its `bytes` property. Pending directive receivers, paths, original and converted
values, and nested renderer state participate in the evaluator's GC roots.
Cancellation, closure, deadlines, and late Host completions use the shared
session lifecycle.

Supported `pkl:json.Property` and `Value` declarations are compiled from the
pinned `json.pkl` source in the ordinary module arena. The external JSON parser
remains unsupported. This checkpoint uses the default allow policy for bundled
modules. Evaluator-owned bundled module resolution, security admission, and
cache behavior remain a required follow-up; the pinned singleton bypass for
`pkl:base`, `pkl:ref`, and `pkl:test` must be preserved when adding it.

`List.join` and `Set.join` use a shared continuation with ordered element
stringification. Their Java `Object.toString` contract differs from Pkl's
virtual typed `toString`: ordinary objects force deeply, nested strict
collections render cached values, and directly joined Bytes retain all bytes.
The continuation can suspend during object or Reference stringification.

Document conversion hints preserve original and converted values. Object and
Bytes identities, unchanged string storage, and changed scalar values are
distinguished from language equality. The current immediate numeric carrier
cannot identify a reboxed equal number; an uncaught error requiring that
identity remains an explicit `Unsupported` boundary. Equal strings with
unproven reference identity have the same limitation. Guest catch exposes the
message rather than rendering these hints. This is not completion of Java
boxing identity or cached-exception hint compatibility.

The immutable Stage47 C02 candidate matched both untouched original
`api/moduleOutput2.pkl` and `api/pcfRenderer9.pkl` CLI programs twice, comparing
full stdout, stderr, exit status, generated files, and the original workspace.
C01's missing-join failures are retained. Development tests also exercise
suspension, collection, and terminal cleanup. Those results do not establish
complete renderer/API compatibility, all platform execution, the full M2 gate,
or the performance targets. New Java renderer controls and final platform and
Rust checks are separate verification obligations.
