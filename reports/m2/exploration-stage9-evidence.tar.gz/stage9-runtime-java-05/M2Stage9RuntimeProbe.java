import java.io.*;
import java.lang.reflect.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import org.pkl.core.*;
import org.pkl.core.resource.ResourceReader;
import org.pkl.core.runtime.*;
import org.graalvm.collections.*;
public final class M2Stage9RuntimeProbe {
 static Path output; static Evaluator evaluator; static ModuleSource source; static Method evaluate; static Object cacheObject;
 static Object field(Object o,String name)throws Exception {Class<?> c=o.getClass();while(c!=null){try{Field f=c.getDeclaredField(name);f.setAccessible(true);return f.get(o);}catch(NoSuchFieldException e){c=c.getSuperclass();}}throw new NoSuchFieldException(name);}
 static Object evalRaw(String expr)throws Exception {
  var security=(org.pkl.core.SecurityManager)field(evaluator,"securityManager");var resolver=(ModuleResolver)field(evaluator,"moduleResolver");
  try{return evaluate.invoke(evaluator,source,(Function<VmTyped,Object>)(m -> VmUtils.evaluateExpression(m,expr,security,resolver)));}catch(InvocationTargetException e){if(e.getCause() instanceof Exception x)throw x;throw e;}
 }
 static void call(String name,String expr)throws Exception{System.out.println("call "+name+" "+expr);try{String s=evaluator.evaluateExpressionString(source,expr);Files.writeString(output.resolve(name+".result.bin"),s,StandardCharsets.UTF_8);System.out.println("outcome "+name+" success "+s);}catch(Throwable e){Files.writeString(output.resolve(name+".error.bin"),e.getMessage()==null?"":e.getMessage(),StandardCharsets.UTF_8);StringWriter trace=new StringWriter();e.printStackTrace(new PrintWriter(trace));Files.writeString(output.resolve(name+".trace.bin"),trace.toString(),StandardCharsets.UTF_8);System.out.println("outcome "+name+" "+e.getClass().getName());}}
 static void snapshot(String label)throws Exception{Object c=cacheObject==null?evalRaw("c"):cacheObject;var map=(EconomicMap<?,?>)field(c,"cachedValues");byte[] hash=(byte[])field(map,"hashArray");Object[] entries=(Object[])field(map,"entries");System.out.println("state "+label+" size="+map.size()+" total="+field(map,"totalEntries")+" capacity="+(entries==null?0:entries.length/2)+" hash="+(hash==null?"null":Arrays.toString(hash)));var cur=map.getEntries();while(cur.advance())System.out.println("cache "+cur.getKey().getClass().getName()+" "+keyLabel(cur.getKey())+"="+(cur.getValue() instanceof VmValue?cur.getValue().getClass().getSimpleName():cur.getValue()));}
 static String keyLabel(Object k){return k instanceof String || k instanceof Long || k instanceof Identifier?k.toString():k.getClass().getSimpleName();}
 static final class Reader implements ResourceReader {
  final AtomicInteger calls=new AtomicInteger();final AtomicInteger keyCalls=new AtomicInteger();boolean fail;boolean gate;final CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);
  public String getUriScheme(){return "s9";}public boolean hasHierarchicalUris(){return false;}public boolean isGlobbable(){return false;}
  public Optional<Object> read(URI uri)throws IOException{int n=calls.incrementAndGet();boolean key=uri.toString().equals("s9:hash");if(key)keyCalls.incrementAndGet();System.out.println("read "+uri+" "+n);if(!key)return Optional.of("value");entered.countDown();if(gate)try{if(!release.await(10,TimeUnit.SECONDS))throw new IOException("gate timeout");}catch(InterruptedException e){throw new IOException(e);}if(fail&&keyCalls.get()==1)throw new IOException("stage9 first hash read");return Optional.of("ok");}
 }
 static String hashExpression(String expr)throws Exception {
  var security=(org.pkl.core.SecurityManager)field(evaluator,"securityManager");var resolver=(ModuleResolver)field(evaluator,"moduleResolver");
  return (String)evaluate.invoke(evaluator,source,(Function<VmTyped,String>)(m -> {Object obj=VmUtils.evaluateExpression(m,expr,security,resolver);return "hash\t"+expr+"\t"+obj.getClass().getName()+"\t"+obj.hashCode();}));
 }
 static void hashes()throws Exception {
  String[] exprs={"0","32","4294967296","4294967297","-9223372036854775808","9223372036854775807","0.0","-0.0","1.0","NaN","Infinity","-Infinity","true","false","\"\"","\"Aa\"","\"BB\"","\"😀\"","\"a😀z\"","null","List()","List(1)","List(1,2)","Set(1,2)","Map(1,2)","Pair(1,2)","IntSeq(1,5)","Regex(\"Aa\")","1.s","1000.ms","1.kb","new Listing {}","new Listing {1;2}","new Mapping {}","new Mapping {[1]=2}","new Dynamic {}","new Dynamic {[1]=2}","new C {a=1;b=2}","C","(x)->x"};
  for(int i=0;i<exprs.length;i++){String expr=exprs[i];try{System.out.println(hashExpression(expr));}catch(Throwable e){Files.writeString(output.resolve("hash-"+i+".error.bin"),e.toString());System.out.println("hash-error\t"+expr+"\t"+e);}}
  System.out.println("listing-cold "+hashExpression("left")+" "+hashExpression("right"));
  evalRaw("warmLeft[1]");System.out.println("listing-warm "+hashExpression("warmLeft")+" "+hashExpression("warmRight"));
 }
 public static void main(String[]args)throws Exception{
  output=Path.of(args[1]);Files.createDirectories(output);String mode=args[0];Reader reader=new Reader();reader.fail=mode.startsWith("retry");reader.gate=mode.startsWith("gate");
  Path input=output.resolve("input.pkl");String body=mode.equals("hashes")?"class C {a:Int;b:Int};left=new Listing {1;2};right=new Listing {1;2};warmLeft=new Listing {1;2};warmRight=new Listing {1;2}\n":"key=new Listing { read(\"s9:hash\") }; p=new Mapping {[key]=trace(9)}; c=(p) {[\"a\"]=trace(1);[\"b\"]=trace(2);[\"c\"]=trace(3);[\"d\"]=new Listing {(x)->x}}\n";
  Files.writeString(input,body,StandardCharsets.UTF_8);source=ModuleSource.path(input);evaluate=EvaluatorImpl.class.getDeclaredMethod("doEvaluate",ModuleSource.class,Function.class);evaluate.setAccessible(true);
  try(Evaluator e=EvaluatorBuilder.preconfigured().setLogger(new Logger(){public void trace(String message,StackFrame frame){System.out.println("trace "+message+" "+frame.getModuleUri()+" "+frame.getMemberName()+" "+frame.getStartLine()+":"+frame.getStartColumn());}}).setColor(false).setModuleCacheDir(null).setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).setAllowedResources(List.of(Pattern.compile("s9:.*"))).setResourceReaders(List.of(reader)).build()){
   evaluator=e;
   if(mode.equals("hashes")){hashes();return;}
   int index=mode.contains("-")?Integer.parseInt(mode.substring(mode.indexOf('-')+1)):0;var exprs=new ArrayList<>(List.of("c[\"a\"]","c[\"b\"]","c[\"c\"]","c[\"d\"]"));exprs.add(index,"c[key]");for(int i=0;i<4;i++)call("warm"+i,exprs.get(i));cacheObject=evalRaw("c");snapshot("before-fifth");
   if(reader.gate){var f=new FutureTask<Void>(() -> {call("fifth",exprs.get(4));return null;});new Thread(f).start();if(!reader.entered.await(10,TimeUnit.SECONDS))throw new IllegalStateException("not entered");System.out.println("pending "+!f.isDone());snapshot("gated");reader.release.countDown();f.get(10,TimeUnit.SECONDS);}else call("fifth",exprs.get(4));
   snapshot("after-fifth");call("retry-fifth",exprs.get(4));snapshot("after-retry-fifth");call("retry-key","c[key]");snapshot("after-retry-key");call("check-a","c[\"a\"]");System.gc();call("compare-after-gc","c == new Mapping {[key]=9;[\"a\"]=1;[\"b\"]=2;[\"c\"]=3;[\"d\"]=c[\"d\"]}");snapshot("after-inspect");System.out.println("reader-calls "+reader.calls.get());
  }
 }
}
