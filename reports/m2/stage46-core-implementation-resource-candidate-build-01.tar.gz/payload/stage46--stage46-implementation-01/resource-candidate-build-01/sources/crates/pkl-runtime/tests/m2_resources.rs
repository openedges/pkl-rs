//! Resource cache/Host/GC development regressions. Pinned Java acquisition is
//! separate evidence; these tests do not manufacture compatibility expectations.
use pkl_runtime::{
    host::ReadFailure,
    probe::{SourceEvent, SourceProbe},
    resources::{ReadResult, Resource},
};

fn probe(source: &str, expressions: &[&str]) -> SourceProbe {
    SourceProbe::new_expressions_text(
        source,
        "file:///resources/main.pkl",
        "main",
        &expressions.iter().map(|s| (*s).into()).collect::<Vec<_>>(),
        "compact",
        false,
        false,
        false,
    )
    .unwrap()
}
fn next(probe: &mut SourceProbe) -> SourceEvent {
    for _ in 0..100_000 {
        let event = probe.poll(0, 1).unwrap();
        probe.collect();
        if event.kind != "yield" {
            return event;
        }
    }
    panic!("resource operation did not settle");
}
fn text(event: SourceEvent) -> String {
    assert_eq!(event.kind, "value", "{event:?}");
    String::from_utf16(&event.value.unwrap()).unwrap()
}

#[test]
fn typed_string_cache_crosses_members_and_calls_but_not_evaluators() {
    for _ in 0..2 {
        let mut probe = probe("a=read(\"life:key\")\nb=read?(\"life:key\")\n", &["a", "b"]);
        probe.start_path(0, 0, None).unwrap();
        let event = next(&mut probe);
        assert_eq!(event.kind, "read");
        probe
            .complete_read(
                event.token.as_deref().unwrap(),
                Ok(ReadResult::Text("cached".into())),
                0,
            )
            .unwrap();
        assert_eq!(text(next(&mut probe)), "cached");
        probe.start_path(1, 0, None).unwrap();
        assert_eq!(text(next(&mut probe)), "cached");
        probe.close();
        assert_eq!(probe.collect().slots, 0);
    }
}

#[test]
fn absent_cache_preserves_each_authored_error_and_nullable_result() {
    let mut probe = probe(
        "import \"pkl:test\"\na=test.catch(() -> read(\"dir/../absent\"))\nb=test.catch(() -> read(\"absent\"))\nc=read?(\"absent\")\n",
        &["a", "b", "c"],
    );
    probe.start_path(0, 0, None).unwrap();
    let event = next(&mut probe);
    assert_eq!(event.kind, "read");
    probe
        .complete_read(event.token.as_deref().unwrap(), Ok(ReadResult::Missing), 0)
        .unwrap();
    assert_eq!(
        text(next(&mut probe)),
        "Cannot find resource `dir/../absent`."
    );
    probe.start_path(1, 0, None).unwrap();
    assert_eq!(text(next(&mut probe)), "Cannot find resource `absent`.");
    probe.start_path(2, 0, None).unwrap();
    assert_eq!(text(next(&mut probe)), "null");
}

#[test]
fn reader_errors_retry_and_invalid_tokens_do_not_publish() {
    let mut probe = probe(
        "a=read?(\"life:retry\")\nb=read(\"life:retry\")\n",
        &["a", "b"],
    );
    probe.start_path(0, 0, None).unwrap();
    let event = next(&mut probe);
    let token = event.token.unwrap();
    assert!(
        probe
            .complete_read("invalid", Ok(ReadResult::Missing), 0)
            .is_err()
    );
    probe
        .complete_read(&token, Err(ReadFailure::Io("retry me".into())), 0)
        .unwrap();
    assert_eq!(next(&mut probe).kind, "error");
    probe.start_path(1, 0, None).unwrap();
    let request = next(&mut probe);
    assert_eq!(request.kind, "read");
    probe
        .complete_read(
            request.token.as_deref().unwrap(),
            Ok(ReadResult::Text("ok".into())),
            0,
        )
        .unwrap();
    assert_eq!(text(next(&mut probe)), "ok");
    probe.start_path(0, 0, None).unwrap();
    assert_eq!(text(next(&mut probe)), "ok");
}

#[test]
fn resource_payload_class_bytes_and_cache_survive_safepoint_collection() {
    let mut probe = probe(
        "import \"pkl:base\" as b\na=read(\"life:resource\")\nother=read(\"life:resource\")\nsameClass = a.getClass() == Resource && Resource == b.Resource\n",
        &[
            "a.uri",
            "a.text",
            "a.base64",
            "sameClass",
            "other.bytes == a.bytes",
            "other.base64",
        ],
    );
    probe.start_path(0, 0, None).unwrap();
    let event = next(&mut probe);
    probe
        .complete_read(
            event.token.as_deref().unwrap(),
            Ok(ReadResult::Resource(Resource {
                uri: "life:returned".into(),
                bytes: b"abc\0\n".as_slice().into(),
            })),
            0,
        )
        .unwrap();
    assert_eq!(text(next(&mut probe)), "life:returned");
    for (index, expected) in [
        (1, "abc\0\n"),
        (2, "YWJjAAo="),
        (3, "true"),
        (4, "true"),
        (5, "YWJjAAo="),
    ] {
        probe.start_path(index, 0, None).unwrap();
        assert_eq!(text(next(&mut probe)), expected);
    }
    probe.close();
    assert_eq!(probe.collect().slots, 0);
}
