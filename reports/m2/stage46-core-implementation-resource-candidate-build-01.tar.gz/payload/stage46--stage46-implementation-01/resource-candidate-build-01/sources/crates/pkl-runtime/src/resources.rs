//! Typed resource-reader results. I/O stays in the Host; values and caches are
//! owned by the shared evaluator. Absence is distinct from a raw null callback.
use std::sync::Arc;

use crate::value::PklString;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Resource {
    /// The reader's returned URI, which need not equal the requested cache key.
    pub uri: PklString,
    pub bytes: Arc<[u8]>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ReadResult {
    Missing,
    Text(PklString),
    Resource(Resource),
}
