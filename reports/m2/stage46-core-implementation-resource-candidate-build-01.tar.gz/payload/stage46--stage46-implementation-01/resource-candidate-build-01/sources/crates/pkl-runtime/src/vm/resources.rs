//! ResourceReader values and evaluator-local successful/absent read cache.
use super::*;
use crate::resources::{ReadResult, Resource};

pub(crate) const RESOURCE: usize = usize::MAX - 300;
const FACTORY: usize = RESOURCE - 1;

#[derive(Clone, Copy, Debug)]
pub enum Property {
    Uri,
    Text,
    Bytes,
}

pub(super) fn builtin_members(
    blocks: &mut Vec<Vec<Instruction>>,
    metadata: &mut Vec<BlockMetadata>,
) -> BTreeMap<usize, Vec<Member>> {
    let source = crate::stdlib_sources::base();
    let class_start = source.text.find("class Resource {").unwrap();
    let mut definitions = BTreeMap::new();
    for factory in [false, true] {
        let mut members = Vec::new();
        for (name, ty, hidden, fixed) in [
            ("uri", TypeCheck::String, false, false),
            ("text", TypeCheck::String, false, false),
            ("base64", TypeCheck::String, false, false),
            ("bytes", TypeCheck::Bytes, true, false),
            ("md5", TypeCheck::String, true, true),
            ("sha1", TypeCheck::String, true, true),
            ("sha256", TypeCheck::String, true, true),
            ("sha256Int", TypeCheck::Int, true, true),
        ] {
            if factory && !matches!(name, "uri" | "text" | "bytes") {
                continue;
            }
            let start = class_start
                + source.text[class_start..]
                    .find(&format!("{name}:"))
                    .unwrap();
            let span = Span::new(start, start + name.len());
            let type_start = span.end + 2;
            let type_len = match name {
                "uri" | "sha256Int" => 3,
                _ => {
                    if matches!(ty, TypeCheck::Bytes) {
                        5
                    } else {
                        6
                    }
                }
            };
            let type_span = Span::new(type_start, type_start + type_len);
            let mut code = if factory {
                vec![Instruction::ResourceProperty(match name {
                    "uri" => Property::Uri,
                    "text" => Property::Text,
                    _ => Property::Bytes,
                })]
            } else if matches!(name, "uri" | "text") {
                vec![Instruction::Undefined(name.into())]
            } else if name == "base64" {
                vec![
                    Instruction::LoadThis,
                    Instruction::GetMember("bytes".into()),
                    Instruction::GetMember("base64".into()),
                ]
            } else {
                vec![Instruction::Fail(RuntimeError::new(
                    ErrorKind::Unsupported,
                    format!("Resource.{name} default binding is not implemented."),
                ))]
            };
            code.push(Instruction::CheckType(ty.clone()));
            code.push(Instruction::Return);
            let block = blocks.len();
            metadata.push(BlockMetadata {
                source: Some(source.clone()),
                member: format!("#Resource.{name}").into(),
                declaration: Some(span),
                spans: code
                    .iter()
                    .map(|instruction| {
                        Some(if matches!(instruction, Instruction::CheckType(_)) {
                            type_span
                        } else {
                            span
                        })
                    })
                    .collect(),
                ..Default::default()
            });
            blocks.push(code);
            members.push(Member {
                flags: if hidden { 0x08 } else { 0 },
                entry: false,
                name: name.into(),
                code: block,
                local: false,
                method: false,
                ty: Some(ty),
                type_span: Some(type_span),
                constant: false,
                fixed,
            });
        }
        definitions.insert(if factory { FACTORY } else { RESOURCE }, members);
    }
    definitions
}

impl Vm {
    /// Publish only a successful typed reader result. A cached absence retains
    /// no exception: every ordinary read creates its own authored URI/frame.
    pub fn complete_read(
        &mut self,
        id: u64,
        result: Result<ReadResult, RuntimeError>,
    ) -> Result<(), RuntimeError> {
        let request = match &self.state {
            State::Waiting(PendingRequest::Read(request)) if request.id == id => request.clone(),
            _ => return self.resume(id, Err(invalid("invalid resource completion"))),
        };
        let uri = match crate::host::resources::resolved_uri(&request) {
            Ok(uri) => uri,
            Err(error) => return self.resume(id, Err(error)),
        };
        let value = match result {
            Ok(ReadResult::Missing) => None,
            Ok(ReadResult::Text(text)) => Some(Value::String(text)),
            Ok(ReadResult::Resource(resource)) => Some(self.resource(resource)),
            Err(error) => return self.resume(id, Err(error)),
        };
        self.resources
            .insert(crate::host::resources::cache_key(&uri), value.clone());
        self.resume(
            id,
            match value {
                Some(value) => Ok(value),
                None if request.nullable => Ok(Value::Null),
                None => Err(crate::host::resources::missing(&request.uri)),
            },
        )
    }

    fn resource(&mut self, resource: Resource) -> Value {
        let parent = self
            .builtin_class(builtins::ty(RESOURCE))
            .heap_id()
            .unwrap();
        let object = Object {
            parent: Some(parent),
            resource: Some(Arc::new(resource)),
            members: self.program.builtin_members[&FACTORY].clone(),
            ..Default::default()
        };
        Value::Object(self.heap.allocate(object))
    }

    pub(super) fn resource_property(&mut self, property: Property) -> Result<(), RuntimeError> {
        let owner = self
            .frames
            .last()
            .and_then(|frame| frame.force.as_ref())
            .map(|force| force.owner)
            .ok_or_else(|| invalid("Resource property without declaration owner"))?;
        let resource = self
            .heap
            .get(owner)?
            .resource
            .as_ref()
            .ok_or_else(|| invalid("Resource payload missing"))?;
        let value = match property {
            Property::Uri => Value::String(resource.uri.clone()),
            Property::Text => Value::String(decode_utf8(&resource.bytes)),
            Property::Bytes => Value::Bytes(resource.bytes.clone()),
        };
        self.stack.push(value);
        Ok(())
    }
}

pub(super) fn base64(bytes: &[u8]) -> PklString {
    const ALPHABET: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut text = String::new();
    for chunk in bytes.chunks(3) {
        let value = (u32::from(chunk[0]) << 16)
            | (u32::from(*chunk.get(1).unwrap_or(&0)) << 8)
            | u32::from(*chunk.get(2).unwrap_or(&0));
        for (position, shift) in [18, 12, 6, 0].into_iter().enumerate() {
            text.push(if position > chunk.len() {
                '='
            } else {
                ALPHABET[((value >> shift) & 63) as usize] as char
            });
        }
    }
    text.into()
}

/// Java UTF-8 decoder consumes a malformed surrogate encoding as one sequence,
/// unlike Rust's lossy decoder. Other malformed sequences consume only their
/// valid prefix, leaving the next byte for the following decoding step.
fn decode_utf8(bytes: &[u8]) -> PklString {
    if let Ok(text) = std::str::from_utf8(bytes) {
        return text.into();
    }
    let mut text = String::new();
    let mut index = 0;
    while index < bytes.len() {
        let first = bytes[index];
        if first < 128 {
            text.push(first as char);
            index += 1;
            continue;
        }
        let width = match first {
            0xc2..=0xdf => 2,
            0xe0..=0xef => 3,
            0xf0..=0xf4 => 4,
            _ => 1,
        };
        let mut consumed = 1;
        while consumed < width && index + consumed < bytes.len() {
            let next = bytes[index + consumed];
            if next & 0xc0 != 0x80
                || consumed == 1
                    && (first == 0xe0 && next < 0xa0
                        || first == 0xf0 && next < 0x90
                        || first == 0xf4 && next >= 0x90)
            {
                break;
            }
            consumed += 1;
        }
        let valid = width > 1 && consumed == width;
        if valid {
            let mut point = u32::from(first & (0x7f >> width));
            for &byte in &bytes[index + 1..index + width] {
                point = point << 6 | u32::from(byte & 63);
            }
            text.push(char::from_u32(point).unwrap_or('\u{fffd}'));
        } else {
            text.push('\u{fffd}');
        }
        index += consumed;
    }
    text.into()
}
