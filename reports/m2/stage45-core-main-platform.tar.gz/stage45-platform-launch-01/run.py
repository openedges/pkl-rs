from pathlib import Path
import datetime,hashlib,json,os,platform,subprocess,time,sys
out=Path(__file__).resolve().parent
root=out.parents[2]
output=root/'target/m2/stage45-platform-candidate-01'
assert not output.exists()
assert 'CARGO_TARGET_DIR' not in os.environ
cmd=[sys.executable,'tools/m1_platforms.py','--output',str(output),'--wasm-bindgen','/Users/cody.ij.hwang/Projects/pkl-rs/.cache/m1-tools/bin/wasm-bindgen','--verify-contract']
record={'command':cmd,'cwd':str(root),'host':platform.platform(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Actual native/N-API/Chromium execution; --verify-contract does not waive strict oracle mismatches.'}
(out/'started.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'stdout.bin').open('wb') as stdout,(out/'stderr.bin').open('wb') as stderr:
 result=subprocess.run(cmd,cwd=root,stdout=stdout,stderr=stderr)
record.update(exit_code=result.returncode,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
for name in ['stdout.bin','stderr.bin']:record[name+'_sha256']=hashlib.sha256((out/name).read_bytes()).hexdigest()
(out/'report.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
raise SystemExit(result.returncode)
