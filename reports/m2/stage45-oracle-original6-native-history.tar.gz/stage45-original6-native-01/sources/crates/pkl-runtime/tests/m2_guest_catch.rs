//! Same-VM handler and standard-library bootstrap development regressions.
//! Fresh Java controls separately establish byte compatibility.
use pkl_runtime::probe::{SourceEvent, SourceProbe};

fn next(probe: &mut SourceProbe) -> SourceEvent {
    for _ in 0..100_000 {
        let event = probe.poll(0, 1).unwrap();
        probe.collect();
        if event.kind != "yield" { return event; }
    }
    panic!("guest catch did not settle");
}

#[test]
fn ordinary_catch_returns_in_same_module_and_retains_successful_values() {
    let source = "import \"pkl:test\"\ninner = test.catch(() -> throw(\"inner\"))\ncaughtOuter = test.catch(() -> test.catch(() -> 1))\nnormal = test.catchOrNull(() -> 7)\nstable = 9\n";
    let expressions = ["inner", "caughtOuter", "normal", "stable", "inner"];
    let mut probe = SourceProbe::new_expressions_text(source,"file:///guest-catch.pkl","main", &expressions.map(String::from),"compact",false,false,true).unwrap();
    for index in 0..expressions.len() {
        probe.start_path(index as u32,0,None).unwrap();
        let event = next(&mut probe);
        assert_eq!(event.kind,"value","{} {:?}",expressions[index],event);
        if index == 0 || index == 4 { assert_eq!(event.value.unwrap(),"inner".encode_utf16().collect::<Vec<_>>()); }
    }
    probe.close();
    assert_eq!(probe.collect().slots,0);
}

#[test]
fn base_module_aliases_and_implicit_class_share_actual_identity() {
    let source = "import \"pkl:base\" as a\nimport \"pkl:base\" as b\nresult = a == b && a.Int == Int && a.Module == Module\n";
    let mut probe = SourceProbe::new_expressions_text(source,"file:///base-identity.pkl","main", &["result".into()],"compact",false,false,false).unwrap();
    probe.start_path(0,0,None).unwrap();
    let event=next(&mut probe);
    assert_eq!(event.kind,"value","{event:?}");
    assert_eq!(event.value.unwrap(),"true".encode_utf16().collect::<Vec<_>>());
    probe.close();
    assert_eq!(probe.collect().slots,0);
}
