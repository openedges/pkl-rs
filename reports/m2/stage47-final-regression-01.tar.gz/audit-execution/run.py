from pathlib import Path
import subprocess,json,hashlib,os,sys,time
root=Path('/Users/cody.ij.hwang/Projects/pkl-rs');out=Path(__file__).parent;audit=root/'target/m2/stage47-final-audit-01/audit.py'
mode=sys.argv[1];assert mode in ['prepare','audit'];argv=[sys.executable,str(audit),'--'+mode]
if mode=='audit':argv+=['--wrapper-terminal','/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2/stage47-full-regression-01/outer-terminal.json']
start=time.time();env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'}
(out/(mode+'-launch.json')).write_text(json.dumps({'argv':argv,'cwd':str(root),'wrapperPid':os.getpid(),'startedUnix':start,'scriptSha256':hashlib.sha256(audit.read_bytes()).hexdigest(),'environmentOverrides':{k:env[k] for k in ['GIT_OPTIONAL_LOCKS','PYTHONDONTWRITEBYTECODE']}},indent=2)+'\n')
with(out/(mode+'.stdout.bin')).open('wb')as stdout,(out/(mode+'.stderr.bin')).open('wb')as stderr:r=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr)
report={'scope':'Independent terminal-only existing evidence audit. No acquisitions/builds/tests/oracle runs.','mode':mode,'argv':argv,'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'stdoutSha256':hashlib.sha256((out/(mode+'.stdout.bin')).read_bytes()).hexdigest(),'stderrSha256':hashlib.sha256((out/(mode+'.stderr.bin')).read_bytes()).hexdigest()}
(out/(mode+'-report.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(r.returncode)
