"""Independent terminal-only Stage47 regression audit proposal. Never acquire or build."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile
import stat
import re

ROOT = Path("/Users/cody.ij.hwang/Projects/pkl-rs.stage47")
MAIN = Path("/Users/cody.ij.hwang/Projects/pkl-rs")
OUT = Path(__file__).resolve().parent
COMMIT = "0e13a589d43c4cb1d83f41dd1ec416cac1770fc1"
LANG = ROOT / "target/m2/stage47-language-final-01"
LIFE = ROOT / "target/m2/stage47-class-lifecycle-final-01"
WRAPPER = ROOT / "target/m2/stage47-full-regression-01"
CASE = "pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/basic/import1b.pkl"
BASE_NAMES = ["stage46-final-summary.json", "stage46-final-raw-changes.json", "stage46-final-source-map.json", "stage46-final-regression-captures.json"]
COMMANDS = ["language-acquire", "language-verify-report", "language-verify-development", "language-verify-subset", "language-verify-full", "lifecycle-acquire", "lifecycle-verify-report", "lifecycle-verify-contract"]
INTEGRITY_COMMANDS = {"language-acquire", "language-verify-report", "lifecycle-acquire", "lifecycle-verify-report"}
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")

def git(*args, cwd=ROOT):
    return subprocess.check_output(["git", *args], cwd=cwd)

def safe(name):
    path = Path(name)
    assert not path.is_absolute() and path.parts and ".." not in path.parts and str(path) == name and name != ".", name
    return path

def regular_bytes(root, relative):
    path = root
    assert stat.S_ISDIR(root.lstat().st_mode), str(root)
    for part in safe(relative).parts[:-1]:
        path = path / part
        assert stat.S_ISDIR(path.lstat().st_mode), str(path)
    path = root / safe(relative)
    assert stat.S_ISREG(path.lstat().st_mode), str(path)
    return path.read_bytes()

def inventory(directory, declared):
    """Read declared exact files only. Never enumerate an evidence/cache tree."""
    excluded = {directory / "build", directory / "jvm-classpath/build"}
    rows = {}
    assert declared and "report.json" not in declared
    for name, digest in declared.items():
        path = directory / safe(name)
        assert not any(path == cache or cache in path.parents for cache in excluded), name
        raw = regular_bytes(directory, name)
        assert sha(raw) == digest, name
        rows[name] = {"sha256": digest, "bytes": len(raw)}
    return rows, [str(path) for path in sorted(excluded)]

def capture(directory):
    metadata = load(directory / "result.json")
    values = {channel: regular_bytes(directory, channel + ".bin") for channel in ["stdout", "stderr"]}
    assert all(sha(values[channel]) == metadata["sha256"][channel] for channel in values)
    files = {name: regular_bytes(directory / "files", name) for name in metadata["files"]}
    assert {name: sha(raw) for name, raw in files.items()} == metadata["files"]
    return {**values, "files": files, "exit_code": metadata["exit_code"], "timed_out": metadata["timed_out"], "workspace_changes": metadata["workspace_changes"]}

def cli_status(java, rust, expected_exit):
    if java["workspace_changes"]:
        return "oracle-error"
    if rust["workspace_changes"]:
        return "candidate-environment-error"
    if java["timed_out"] or java["exit_code"] not in [0, 1]:
        return "oracle-error"
    if java["exit_code"] == 1 and not java["stderr"].startswith("–– Pkl Error ––\n".encode()):
        return "oracle-error"
    if java["exit_code"] not in expected_exit:
        return "oracle-contract-mismatch"
    if rust["timed_out"]:
        return "candidate-timeout"
    if rust["exit_code"] in [2, 3, 4]:
        return {2: "candidate-unsupported", 3: "candidate-limit-exceeded", 4: "candidate-internal-error"}[rust["exit_code"]]
    return "pass" if java == rust else "mismatch"

def valid_outcome(raw):
    prefix = b"pkl-exception\torg.pkl.core."
    return raw.startswith(prefix) and raw.endswith(b"\n") and bool(raw[len(prefix):-1]) and all(byte in b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_$" for byte in raw[len(prefix):-1])

def full_failures(manifest, results):
    by_id = {row["id"]: row for row in results}
    failures = []
    if len(by_id) != len(results):
        failures.append("duplicate execution results")
    for row in manifest["requirements"]:
        if not row["required"]:
            continue
        if row["implementation"]["state"] != "implemented" or not row["implementation"]["links"]:
            failures.append("implementation incomplete: " + row["id"])
        if row["tests"]["state"] != "mapped" or not row["tests"]["case_ids"]:
            failures.append("test mapping incomplete: " + row["id"])
        elif any(by_id.get(identifier, {}).get("status") != "pass" for identifier in row["tests"]["case_ids"]):
            failures.append("requirement execution incomplete: " + row["id"])
    for row in manifest["cases"]:
        if row["required"] and (not row["requirements"] or row["execution"]["state"] != "ready" or by_id.get(row["id"], {}).get("status") != "pass"):
            failures.append("required case incomplete: " + row["id"])
    return failures

def metamorphic(manifest):
    definitions = {tuple(case["metamorphic_relation"]["case_ids"]): case["metamorphic_relation"] for case in manifest["cases"] if "metamorphic_relation" in case}
    results = []
    for identifiers, relation in sorted(definitions.items()):
        statuses = {}
        for runtime in ["java", "rust"]:
            captures = []
            for identifier in identifiers:
                folder = LANG / "cases" / identifier
                process = load(folder / (runtime + ".process.json"))
                captures.append((process["exit_code"], process["timed_out"], (folder / (runtime + ".stdout.bin")).read_bytes(), (folder / (runtime + ".stderr.bin")).read_bytes()))
            statuses[runtime] = all(row[:2] == (0, False) and row[3] == b"" for row in captures) and len(set(captures)) == 1
        results.append({**relation, "runtimes": statuses, "status": "pass" if all(statuses.values()) else "mismatch"})
    return results

def scalar_status(case, row):
    folder = LANG / "cases" / row["id"]
    values = {}
    for runtime in ["java", "rust"]:
        process = load(folder / (runtime + ".process.json"))
        assert process == row[runtime]
        raw = [(folder / (runtime + "." + channel + ".bin")).read_bytes() for channel in ["stdout", "stderr"]]
        assert all(sha(data) == process[channel + "_sha256"] for channel, data in zip(["stdout", "stderr"], raw))
        values[runtime] = [process["exit_code"], *raw]
    java, rust = values["java"], values["rust"]
    outcome = (folder / "java.outcome.bin").read_bytes()
    assert sha(outcome) == row["java"]["outcome_sha256"]
    expected = 0 if case["expected_outcome"] == "success" else 1
    java_ok = not row["java"]["timed_out"] and java[0] == expected and (not java[2] and outcome == b"success\n" if expected == 0 else not java[1] and bool(java[2]) and valid_outcome(outcome))
    return "oracle-error" if not java_ok else "candidate-timeout" if row["rust"]["timed_out"] else "pass" if java == rust else "mismatch"

def tree(commit, repository=ROOT):
    rows = {}
    for item in git("ls-tree", "-rz", commit, cwd=repository).split(b"\0"):
        if item:
            meta, name = item.split(b"\t", 1)
            mode, kind, oid = meta.decode().split()
            rows[name.decode()] = (mode, kind, oid)
    return rows

def prepare():
    assert not (OUT / "prepared.json").exists(), "Preserve previous preparation."
    inputs = {}
    for name in BASE_NAMES:
        source = MAIN / "reports/m2" / name
        raw = source.read_bytes()
        copy = OUT / "baseline" / name
        copy.parent.mkdir(exist_ok=True)
        copy.write_bytes(raw)
        inputs[str(source)] = sha(raw)
    summary = load(OUT / "baseline/stage46-final-summary.json")
    captures = load(OUT / "baseline/stage46-final-regression-captures.json")
    for key, name in [("source_map", "stage46-final-source-map.json"), ("raw_changes", "stage46-final-raw-changes.json"), ("captures", "stage46-final-regression-captures.json")]:
        assert summary[key]["sha256"] == sha((OUT / "baseline" / name).read_bytes())
    for row in captures["archives"]:
        archive = MAIN / safe(row["path"])
        assert sha(archive.read_bytes()) == row["sha256"]
        inputs[str(archive)] = row["sha256"]
    expected = git("show", COMMIT + ":compatibility/m2-language.json")
    (OUT / "expected-contract.json").write_bytes(expected)
    wrapper = (WRAPPER / "run.py").read_bytes()
    (OUT / "wrapper-run.py").write_bytes(wrapper)
    write("prepared.json", {
        "schema": 1, "status": "Prepared only; no current Stage47 result was read or classified.",
        "implementation_commit": COMMIT, "baseline_input_sha256": inputs,
        "expected_contract_sha256": sha(expected), "wrapper_source_sha256": sha(wrapper),
        "terminal_guard": "--audit requires wrapper complete, all8 final commands, root actual15695 exit0 receipt bound to process-report hash.",
        "planned_checks": ["Stage46 published summary/pointers/3archives", "caseID/order/selection and existing single JVM-profile mapping preserved", "manifest differences limited to source hash links", "independent raw status reconstruction/current nonpass/historical union", "full raw output/file/status and parent-child identities", "declared payload-only reads, no evidence/cache tree enumeration", "schema2 lifecycle direct Cargo control capture, ordered fixtures/calls/status/stdout/stderr", "Git/reference blobs for every captured source and stable artifacts", "strict failures retained; no result totals assumed", "publication and fullM2 completion remain separate"],
        "actual_audit_run": False,
    })
    print("Prepared only; no Stage47 completion or passing result claimed.")

def baseline_archive():
    prepared = load(OUT / "prepared.json")
    for name, expected in prepared["baseline_input_sha256"].items():
        assert sha(Path(name).read_bytes()) == expected
    captures = load(OUT / "baseline/stage46-final-regression-captures.json")
    data, total_files, total_bytes = {}, 0, 0
    for claim in captures["archives"]:
        with tarfile.open(MAIN / safe(claim["path"]), "r:gz") as archive:
            members = archive.getmembers()
            indexed = {member.name: member for member in members}
            assert len(indexed) == len(members)
            assert all(member.isfile() and safe(member.name) for member in members)
            declared = json.load(archive.extractfile(indexed["EVIDENCE.json"]))["files"]
            rows = {row["path"]: row for row in declared}
            assert len(rows) == len(declared) and rows.keys() == indexed.keys() - {"EVIDENCE.json"}
            assert len(rows) == claim["payload_files"]
            assert sum(row["bytes"] for row in rows.values()) == claim["payload_bytes"]
            for name, member in indexed.items():
                if name == "EVIDENCE.json":
                    continue
                assert name not in data, "duplicate archive payload: " + name
                raw = archive.extractfile(member).read()
                assert sha(raw) == rows[name]["sha256"] and len(raw) == rows[name]["bytes"]
                data[name] = raw
            total_files += len(rows)
            total_bytes += sum(row["bytes"] for row in rows.values())
    assert total_files == captures["payload_files"] and total_bytes == captures["payload_bytes"]
    return data

def only_hash_changes(left, right, path=""):
    if left == right:
        return []
    if isinstance(left, dict) and isinstance(right, dict):
        assert left.keys() == right.keys(), path
        return [change for key in left for change in only_hash_changes(left[key], right[key], path + "/" + key)]
    if isinstance(left, list) and isinstance(right, list):
        assert len(left) == len(right), path
        return [change for index, (a, b) in enumerate(zip(left, right)) for change in only_hash_changes(a, b, path + "/" + str(index))]
    assert re.fullmatch(r"requirements/\d+/implementation/links/\d+/sha256", path), "non-implementation-link-hash manifest change: " + path
    assert isinstance(left, str) and isinstance(right, str) and len(left) == len(right) == 64
    return [{"path": path, "before": left, "after": right}]

def strict_gate_stdout(row, lang):
    raw = (WRAPPER / (row["label"] + ".stdout.bin")).read_bytes()
    assert json.loads(raw) == {"selected": lang["status_counts"], "full_gate_failures": len(lang["full_gate_failures"])}

def development_gate(lang):
    """Use only the two captured, Git-bound, read-only exception predicates.

    Raw language statuses were reconstructed independently. This executes no
    verifier CLI, acquisition, build, Java, or tests. The captured predicates only
    read their known case payloads and return a development-only boolean.
    """
    import ast
    source = regular_bytes(LANG / "sources", "tools/m2_language.py").decode()
    names = {"remainder_development_exception", "development_passes"}
    functions = [node for node in ast.parse(source).body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in functions} == names
    namespace = {"ROOT": ROOT, "Path": Path}
    exec(compile(ast.Module(body=functions, type_ignores=[]), "<captured development predicates>", "exec"), namespace)
    return namespace["development_passes"](lang, LANG)

def lifecycle_process(directory, result, command, count):
    assert load(directory / "result.json") == result
    assert result["status"] == "executed" and result["exit_code"] == 0
    assert result["command"] == command and result["cwd"] == str(ROOT)
    for channel in ["stdout", "stderr"]:
        raw = regular_bytes(directory, channel + ".bin")
        assert result[channel]["sha256"] == sha(raw) and result[channel]["bytes"] == len(raw)
        assert result[channel]["path"] == str(directory / (channel + ".bin"))
    protocol = "".join(f"call={index} completed\n" for index in range(count)).encode() + b"closed\n"
    assert (directory / "stdout.bin").read_bytes() == protocol and not (directory / "stderr.bin").read_bytes()

def audit(terminal_receipt):
    assert terminal_receipt is not None, "Root actual wrapper terminal receipt is mandatory."
    receipt = load(terminal_receipt)
    assert receipt["session_id"] == 15695 and receipt["exit_code"] == 0, "Do not audit a live/failed wrapper as completed."
    assert receipt["process_report_sha256"] == sha((WRAPPER / "process-report.json").read_bytes())
    assert not (OUT / "report.json").exists(), "Preserve previous audit."
    driver = load(WRAPPER / "process-report.json")
    assert driver.get("complete") is True, "Acquisition/wrapper not terminal: no audit or closure claim."
    assert [row["label"] for row in driver["commands"]] == COMMANDS
    assert driver["commit"] == COMMIT and not driver["infrastructureFailures"]
    assert driver["cwd"] == str(ROOT)
    assert driver["languageConcurrency"]["workers"] == 4 and driver["languageConcurrency"]["priorStage46Workers"] == 2
    assert "not a performance comparison" in driver["languageConcurrency"]["scope"]
    assert all(type(row.get("returncode")) is int for row in driver["commands"])
    assert sha((WRAPPER / "run.py").read_bytes()) == driver["runnerSha256"] == load(OUT / "prepared.json")["wrapper_source_sha256"]
    for row in driver["commands"]:
        assert row["requiresZeroForIntegrity"] == (row["label"] in INTEGRITY_COMMANDS)
        if row["label"] in INTEGRITY_COMMANDS:
            assert row["returncode"] == 0
        else:
            assert row["returncode"] in [0, 1], "Usage/infrastructure exit must not be relabeled strict failure."
        for channel in ["stdout", "stderr"]:
            assert sha((WRAPPER / (row["label"] + "." + channel + ".bin")).read_bytes()) == row[channel + "_sha256"]
    expected_argv = {
        "language-acquire": [driver["python"], "tools/m2_language.py", "--output", str(LANG), "--record-only", "--workers", "4"],
        **{f"language-verify-{mode}": [driver["python"], "tools/m2_language.py", "--verify-" + mode, str(LANG)] for mode in ["report", "development", "subset", "full"]},
        "lifecycle-acquire": [driver["python"], "tools/m2_class_lifecycle.py", "--output", str(LIFE), "--record-only"],
        **{f"lifecycle-verify-{mode}": [driver["python"], "tools/m2_class_lifecycle.py", "--verify-" + mode, str(LIFE)] for mode in ["report", "contract"]},
    }
    assert all(row["argv"] == expected_argv[row["label"]] for row in driver["commands"])
    old = baseline_archive()
    old_lang = json.loads(old["language/report.json"])
    old_driver = json.loads(old["wrapper/process-report.json"])
    assert next(row["argv"] for row in old_driver["commands"] if row["label"] == "language-acquire")[-2:] == ["--workers", "2"]
    old_life = json.loads(old["lifecycle/report.json"])
    baseline_summary = load(OUT / "baseline/stage46-final-summary.json")
    assert sha(old["language/report.json"]) == baseline_summary["raw_reports"]["language"]
    assert sha(old["lifecycle/report.json"]) == baseline_summary["raw_reports"]["lifecycle"]
    lang = load(LANG / "report.json")
    life = load(LIFE / "report.json")
    manifests = {"old": json.loads(old["language/sources/compatibility/m2-language.json"]), "new": load(LANG / "sources/compatibility/m2-language.json")}
    assert (LANG / "sources/compatibility/m2-language.json").read_bytes() == (OUT / "expected-contract.json").read_bytes()
    report_inputs_before = {str(path): sha(path.read_bytes()) for path in [LANG / "report.json", LIFE / "report.json", WRAPPER / "process-report.json"]}
    before, after = manifests["old"], manifests["new"]
    assert [row["id"] for row in before["cases"]] == [row["id"] for row in after["cases"]]
    assert before["cases"] == after["cases"], "Preserve original IDs, definitions, required flags and profile mapping."
    requirement_hash_changes = only_hash_changes(before["requirements"], after["requirements"], "requirements")
    assert before["counts"] == after["counts"]
    assert len(before["requirements"]) == len(after["requirements"])
    changed = []
    profile_case = next(row for row in after["cases"] if row["id"] == CASE)
    assert profile_case["adapter"] == "language-jvm-classpath-output" and profile_case["execution"]["state"] == "ready"
    assert [row["id"] for row in after["cases"] if row["adapter"] == "language-jvm-classpath-output"] == [CASE]
    for name in ["compatibility/corpus.json", "compatibility/m2-module-eval.json", "compatibility/m2-execution-profiles.json", "compatibility/m2-jvm-classpath.json"]:
        assert old["language/sources/" + name] == (LANG / "sources" / name).read_bytes(), name
    assert lang["selection"] == old_lang["selection"]
    assert [row["id"] for row in lang["results"]] == lang["selection"]["case_ids"]
    assert len(lang["results"]) == lang["selected_count"] == len(old_lang["results"])
    assert len(set(lang["selection"]["case_ids"])) == lang["selected_count"]
    assert [row["id"] for row in after["cases"] if row.get("adapter") in lang["selection"]["adapters"]] == lang["selection"]["case_ids"]
    inventories = {}
    pruned = {}
    for label, directory, report in [("language", LANG, lang), ("lifecycle", LIFE, life)]:
        inventories[label], pruned[label] = inventory(directory, report["evidence_sha256"])
        assert {name: row["sha256"] for name, row in inventories[label].items()} == report["evidence_sha256"]
    assert lang["source_stability"] and lang["artifact_stability"]
    assert life["source_stability_before_execution"] and life["source_stability_after_execution"] and not life["acquisition_error"]
    case_by_id = {case["id"]: case for case in after["cases"]}
    reconstructed = {}
    for row in lang["results"]:
        case = case_by_id[row["id"]]
        if row.get("adapter") == "language-jvm-classpath-output":
            continue
        if row.get("adapter") == "language-module-eval":
            folder = LANG / "cases" / row["directory"]
            assert row["directory"] == sha(row["id"].encode())[:24]
            assert sha((folder / "input.pkl").read_bytes()) == case["input_sha256"]
            captures = {runtime: capture(folder / runtime) for runtime in ["java", "rust"]}
            for runtime in captures:
                assert load(folder / runtime / "process.json") == row[runtime]
                workspace = Path(lang["module_eval"]["workspace"])
                state = workspace / ".state" / row["directory"]
                prefix = lang["oracle"]["command"] if runtime == "java" else [str(LANG / "artifacts/module_eval_probe")]
                prefix = [f"-Duser.home={state / 'home'}" if arg.startswith("-Duser.home=") else f"-Djava.io.tmpdir={state / 'tmp'}" if arg.startswith("-Djava.io.tmpdir=") else arg for arg in prefix]
                assert row[runtime]["command"] == prefix + case["upstream_case"]["command"]
                assert row[runtime]["cwd"] == str(workspace / case["upstream_case"]["cwd"])
                assert row[runtime]["source_uri"] == (workspace / case["input"]).as_uri()
            reconstructed[row["id"]] = cli_status(captures["java"], captures["rust"], case["upstream_case"]["expected_exit"])
        else:
            folder = LANG / "cases" / row["id"]
            source = ROOT / case["input"]
            assert (folder / "input.pkl").read_bytes() == (LANG / "sources" / safe(case["input"])).read_bytes()
            arguments = [str(source), case["expression"], *(["--power-assertions"] if case.get("power_assertions", False) else [])]
            assert row["rust"]["command"] == [str(LANG / "artifacts/language_probe"), *arguments]
            java_prefix = list(lang["oracle"]["command"][:-1])
            java_prefix[-1] += os.pathsep + str(LANG / "artifacts/java")
            java_prefix.insert(1, "-Dpkl.m2.outcome=" + str(folder / "java.outcome.bin"))
            assert row["java"]["command"] == [*java_prefix, "M2LanguageProbe", *arguments]
            reconstructed[row["id"]] = scalar_status(case, row)
        assert reconstructed[row["id"]] == row["status"]
    context = lang["classpath_eval"]
    child_directory = LANG / "jvm-classpath"
    child_raw = (child_directory / "report.json").read_bytes()
    child = json.loads(child_raw)
    assert sha(child_raw) == context["child_report_sha256"] and context["directory"] == "jvm-classpath" and context["parent_output"] == str(LANG)
    assert child["sources"] == child["sources_after"] == lang["source_sha256"] and child["oracle"] == lang["oracle"]
    for name, digest in child["sources"].items():
        assert sha((child_directory / "sources" / safe(name)).read_bytes()) == digest
    assert child["profile"] == load(LANG / "sources/compatibility/m2-jvm-classpath.json")
    assert child["original_case"] == case_by_id[CASE]["upstream_case"] and child["original_cli_contract_preserved"] is True
    assert child["full_m2_complete"] is False and child["output"] == str(child_directory)
    child_inventory = {name[len("jvm-classpath/"):]: row["sha256"] for name, row in inventories["language"].items() if name.startswith("jvm-classpath/") and name != "jvm-classpath/report.json"}
    assert child_inventory == child["files"]
    assert child["workspace"] == context["workspace"] and not Path(context["workspace"]).is_relative_to(LANG)
    assert child["candidate"]["source_binding"] == "unbound-caller-supplied" and child["candidate"]["original_path"] == str(LANG / "artifacts/jvm_snippet_probe")
    assert child["candidate"]["sha256"] == lang["classpath_candidate"]["sha256"]
    assert child["artifacts_before"] == child["artifacts_after"] and [row["name"] for row in child["commands"]] == ["javac"]
    assert not (child_directory / "build").exists()
    for name, digest in child["artifacts_before"].items():
        assert sha((child_directory / "artifacts" / safe(name)).read_bytes()) == digest
    repetitions = []
    for index, row in enumerate(child["results"]):
        java, rust = [capture(child_directory / "cases" / str(index) / runtime) for runtime in ["java", "rust"]]
        outcome = (child_directory / "cases" / str(index) / "java/outcome.bin").read_bytes()
        assert outcome == b"success\n" and java["exit_code"] == 0 and not java["timed_out"] and not java["stderr"] and not java["workspace_changes"]
        status = "candidate-timeout" if rust["timed_out"] else {2: "candidate-unsupported", 3: "candidate-limit-exceeded", 4: "candidate-internal-error"}.get(rust["exit_code"], "pass" if java == rust else "mismatch")
        assert row["status"] == status
        staged_input = Path(context["workspace"]) / case_by_id[CASE]["input"]
        staged_classpath = Path(context["workspace"]) / "external/pkl/pkl-core/src/test/resources"
        assert sha(staged_input.read_bytes()) == case_by_id[CASE]["input_sha256"]
        for runtime in ["java", "rust"]:
            process = load(child_directory / "cases" / str(index) / runtime / "process.json")
            assert process == row["processes"][runtime]
            assert process["source_uri"] == staged_input.as_uri() and process["classpath_root"] == str(staged_classpath)
            assert process["cwd"] == str(Path(context["workspace"]) / child["original_case"]["cwd"])
            if runtime == "rust":
                assert process["command"] == [str(child_directory / "artifacts/jvm_snippet_probe"), str(staged_input), str(staged_classpath)]
            else:
                assert process["command"][-2:] == ["M2JvmSnippetOutputProbe", str(staged_input)]
                cp = process["command"][process["command"].index("-cp") + 1]
                assert cp == os.pathsep.join(map(str, [child_directory / "artifacts/pkl-tools-0.32.0.jar", child_directory / "artifacts/java", staged_classpath]))
        repetitions.append((java, rust))
    assert len(repetitions) == 2
    repeat_stable = all(repetitions[0][index] == repetitions[1][index] for index in [0, 1])
    child_status = "pass" if repeat_stable and all(row["status"] == "pass" for row in child["results"]) else next((row["status"] for row in child["results"] if row["status"] != "pass"), "mismatch")
    mapped = next(row for row in lang["results"] if row["id"] == CASE)
    assert mapped["status"] == child_status and mapped["execution_profile"] == case_by_id[CASE]["execution_profile"] and mapped["child_report_sha256"] == sha(child_raw)
    reconstructed[CASE] = child_status
    assert dict(Counter(reconstructed.values())) == lang["status_counts"]
    assert metamorphic(after) == lang["metamorphic_results"]
    assert full_failures(after, lang["results"]) == lang["full_gate_failures"]
    for report in [lang, life]:
        assert report["oracle"]["artifact_sha256"] == old_lang["oracle"]["artifact_sha256"]
        for key in ["executable_sha256", "runtime_modules_sha256", "release_sha256"]:
            assert report["oracle"]["jdk"][key] == old_lang["oracle"]["jdk"][key]
        lock = load((LANG if report is lang else LIFE) / "sources/oracle.lock.json")
        assert report["oracle"]["lock_sha256"] == sha(((LANG if report is lang else LIFE) / "sources/oracle.lock.json").read_bytes())
        assert report["oracle"]["artifact_sha256"] == lock["artifact"]["sha256"]
        assert report["oracle"]["release"]["commitId"] == lock["artifact"]["commit_id"]
        assert report["oracle"]["version"] == lock["version"] and report["oracle"]["source"] == lock["source"]
        assert all(report["oracle"]["jdk"]["properties"].get(key) == value for key, value in lock["jdk"]["properties"].items())
    build = load(LANG / "build.process.json")
    assert build["exit_code"] == 0 and not build["timed_out"]
    expected_build = ["cargo", "build", "-p", "pkl-runtime", "--locked", "--release"]
    for name, key in [("language_probe", "candidate"), ("module_eval_probe", "module_candidate"), ("jvm_snippet_probe", "classpath_candidate")]:
        claim = lang[key]
        assert claim["build"] == build and claim["source_binding"] == "recorded-build" and claim["path"] == str(ROOT / "target/release/examples" / name)
        assert sha((LANG / "artifacts" / name).read_bytes()) == claim["sha256"]
        expected_build += ["--example", name]
    assert build["command"] == expected_build + ["--target-dir", str(ROOT / "target")]
    assert life["languages"] == ["java", "rust"] and life["repetitions"] == 2 and life["comparison_channels"] == ["status", "stdout", "stderr"]
    assert [(row["id"], row["repetition"]) for row in life["cases"]] == [(row["id"], row["repetition"]) for row in old_life["cases"]]
    assert len(life["cases"]) == len(old_life["cases"])
    assert life["schema"] == 2, "Stage47 must directly capture Cargo controls under schema2."
    lifecycle_manifest = load(LIFE / "sources/compatibility/m2-class-lifecycle/manifest.json")
    expected_sequences = [(row, repetition) for row in lifecycle_manifest["sequences"] for repetition in range(life["repetitions"])]
    assert [(row["id"], row["repetition"]) for row in life["cases"]] == [(row["id"], repetition) for row, repetition in expected_sequences]
    assert lifecycle_manifest["unexecuted_groups"] == life["unexecuted_groups"]
    assert lifecycle_manifest["uri"] == "file:///m2-platform.pkl" and lifecycle_manifest["power_assertions"] is False
    assert load(LIFE / "oracle.json") == life["oracle"]
    java_classes = LIFE / "classes"
    cp_index = life["oracle"]["command"].index("-cp")
    java_prefix = [*life["oracle"]["command"][:cp_index], "-cp", os.pathsep.join([str(java_classes), life["oracle"]["artifact"]]), "M2ClassLifecycleProbe"]
    calls, life_mismatches, classes = 0, [], 0
    life_statuses = {runtime: Counter() for runtime in ["java", "rust"]}
    for row, (spec, repetition) in zip(life["cases"], expected_sequences):
        expressions = (LIFE / "sources/compatibility/m2-class-lifecycle" / safe(spec["expressions"])).read_text().splitlines()
        source = LIFE / "sources/compatibility/m2-class-lifecycle" / safe(spec["source"])
        expression_path = LIFE / "sources/compatibility/m2-class-lifecycle" / safe(spec["expressions"])
        assert row["directory"] == f"sequences/{spec['id']}/{repetition}" and row["group"] == spec["group"]
        for runtime in ["java", "rust"]:
            command = java_prefix if runtime == "java" else [str(LIFE / "binaries/class_lifecycle_probe")]
            destination = LIFE / row["directory"] / runtime
            lifecycle_process(destination, row[runtime], [*command, str(source), str(expression_path), str(destination)], len(expressions))
        java, rust = [row["observations"]["processes"][runtime]["calls"] for runtime in ["java", "rust"]]
        assert len(java) == len(rust) == len(row["observations"]["comparisons"])
        assert [call["expression"] for call in java] == expressions
        for left, right, comparison in zip(java, rust, row["observations"]["comparisons"]):
            assert left["index"] == right["index"] and left["expression"] == right["expression"]
            equal = True
            for channel in ["status", "stdout", "stderr", "error-class"]:
                raw = [(LIFE / row["directory"] / runtime / f"{call['index']}.{channel}.bin").read_bytes() for runtime, call in [("java", left), ("rust", right)]]
                for call, data in zip([left, right], raw):
                    assert call["channels"][channel] == {"bytes": len(data), "sha256": sha(data)}
                    if channel == "status":
                        assert data in [b"success\n", b"error\n", b"oracle-error\n"] and data == (call["status"] + "\n").encode()
                if channel == "error-class":
                    classes += raw[0] != raw[1]
                else:
                    equal &= raw[0] == raw[1]
            for runtime, call in [("java", left), ("rust", right)]:
                base = LIFE / row["directory"] / runtime
                stdout = (base / f"{call['index']}.stdout.bin").read_bytes()
                stderr = (base / f"{call['index']}.stderr.bin").read_bytes()
                assert (not stderr if call["status"] == "success" else bool(stderr) and not stdout)
            valid = left["status"] != "oracle-error" and right["status"] != "oracle-error"
            expected = "pass" if equal and valid else "mismatch"
            assert comparison["status"] == expected and comparison["raw_equal"] == equal
            if expected != "pass":
                life_mismatches.append({"id": row["id"], "repetition": row["repetition"], "index": left["index"], "expression": left["expression"]})
            for runtime, call in [("java", left), ("rust", right)]:
                life_statuses[runtime][call["status"]] += 1
            calls += 1
    old_calls = sum(len(row["observations"]["processes"]["java"]["calls"]) for row in old_life["cases"])
    assert calls == old_calls
    assert life["unexecuted_groups"] == old_life["unexecuted_groups"] and life["compatibility_complete"] is False
    for row in life["artifacts"]:
        data = (LIFE / safe(row["path"])).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
    assert sha((LIFE / "binaries/class_lifecycle_probe").read_bytes()) == life["candidate_build_sha256"]
    for label in ["javac", "rustc", "build"]:
        claim = life[label]
        assert claim["status"] == "executed" and claim["exit_code"] == 0
        folder = LIFE / ("cargo" if label == "build" else label)
        assert load(folder / "result.json") == claim
        for channel in ["stdout", "stderr"]:
            data = regular_bytes(folder, channel + ".bin")
            assert {"bytes": len(data), "sha256": sha(data), "path": str(folder / (channel + ".bin"))} == claim[channel]
    assert life["build"]["command"] == ["cargo", "build", "-p", "pkl-runtime", "--locked", "--release", "--example", "class_lifecycle_probe", "--message-format=json"]
    messages = [json.loads(line) for line in (LIFE / "cargo/stdout.bin").read_bytes().splitlines()]
    executables = [Path(row["executable"]) for row in messages if row.get("reason") == "compiler-artifact" and row.get("executable") and row.get("target", {}).get("name") == "class_lifecycle_probe"]
    assert len(executables) == 1 and executables[0].is_relative_to(LIFE / "build")
    project = tree(COMMIT)
    expanded = {name: (*row, COMMIT) for name, row in project.items()}
    pins = {}
    for name in ["external/pkl", "external/pkl-pantry"]:
        pin = project[name][2]
        pins[name] = pin
        expanded.update({name + "/" + path: (*row, pin) for path, row in tree(pin, ROOT / name).items()})
    records = [(name, LANG / "sources" / name, digest, "language") for name, digest in lang["source_sha256"].items()]
    records += [(row["path"], LIFE / row["snapshot"], row["sha256"], "lifecycle") for row in life["sources"]]
    bound = {}
    for name, path, digest, label in records:
        data = path.read_bytes()
        assert sha(data) == digest
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        mode, kind, oid, commit = expanded[name]
        assert kind == "blob" and oid == blob, name
        if name in bound:
            assert bound[name]["sha256"] == digest
            bound[name]["capture_scopes"].append(label)
        else:
            bound[name] = {"sha256": digest, "git_blob": blob, "commit": commit, "mode": mode, "capture_scopes": [label]}
    assert "crates/pkl-runtime/src/stdlib/modules.txt" in lang["source_sha256"]
    assert any(row["path"] == "crates/pkl-runtime/src/stdlib/modules.txt" for row in life["sources"])
    config = ".cargo/config.toml"
    assert config in lang["source_sha256"] and sha((ROOT / config).read_bytes()) == lang["source_sha256"][config]
    config_direct_lifecycle = any(row["path"] == config for row in life["sources"])
    assert config_direct_lifecycle, "schema2 missing direct.cargo/config.toml capture"
    for cargo_control in [".cargo/config.toml", "Cargo.toml", "Cargo.lock", "rust-toolchain.toml"]:
        assert cargo_control in lang["source_sha256"]
        claim = next(row for row in life["sources"] if row["path"] == cargo_control)
        assert claim["snapshot"] == "sources/" + cargo_control
        assert sha((LIFE / claim["snapshot"]).read_bytes()) == lang["source_sha256"][cargo_control]

    gate_codes = {row["label"]: row["returncode"] for row in driver["commands"]}
    subset_ok = all(row["status"] == "pass" for row in lang["results"]) and all(row["status"] == "pass" for row in lang["metamorphic_results"])
    bound_builds = all(row["source_binding"] == "recorded-build" for row in [lang.get("candidate"), lang.get("module_candidate"), lang.get("classpath_candidate")] if row)
    assert gate_codes["language-verify-subset"] == int(not subset_ok)
    assert gate_codes["language-verify-full"] == int(not subset_ok or bool(lang["full_gate_failures"]) or not bound_builds)
    assert gate_codes["language-verify-development"] == int(not development_gate(lang))
    assert gate_codes["lifecycle-verify-contract"] == int(bool(life_mismatches))
    for row in driver["commands"]:
        if row["label"].startswith("language-verify-"):
            strict_gate_stdout(row, lang)

    transitions = [{"id": row["id"], "before": previous["status"], "after": row["status"]} for previous, row in zip(old_lang["results"], lang["results"]) if previous["status"] != row["status"]]
    nonpass = [{"id": row["id"], "before": previous["status"], "after": row["status"]} for previous, row in zip(old_lang["results"], lang["results"]) if previous["status"] != "pass" or row["status"] != "pass"]
    raw_changes = {}
    for label in ["language", "lifecycle"]:
        old_bins = {name[len(label) + 1:]: sha(data) for name, data in old.items() if name.startswith(label + "/") and name.endswith(".bin")}
        new_bins = {name: row["sha256"] for name, row in inventories[label].items() if name.endswith(".bin")}
        raw_changes[label] = {"changed_common_bin_paths": sorted(name for name in old_bins.keys() & new_bins.keys() if old_bins[name] != new_bins[name]),
                              "added_bin_paths": sorted(new_bins.keys() - old_bins.keys()), "removed_bin_paths": sorted(old_bins.keys() - new_bins.keys()),
                              "note": "Exact hash changes only, with no path/diagnostic normalization and no implied compatibility."}
    # Final direct re-read binds source/artifact/raw stability to this audit's
    # observation interval. No directory enumeration or cache access is used.
    for label, directory, report in [("language", LANG, lang), ("lifecycle", LIFE, life)]:
        final_inventory, _ = inventory(directory, report["evidence_sha256"])
        assert final_inventory == inventories[label]
    assert all(sha(Path(path).read_bytes()) == digest for path, digest in report_inputs_before.items())
    terminal = None
    if terminal_receipt:
        receipt = load(terminal_receipt)
        assert receipt["exit_code"] == 0
        terminal = {"path": str(terminal_receipt), "sha256": sha(terminal_receipt.read_bytes()), "exit_code": receipt["exit_code"]}
    write("scheduling-comparison.json", {"baseline_stage": 46, "baseline_workers": 2, "current_workers": 4, "source": driver["languageConcurrency"], "qualification": "Independent expression-process concurrency changed. Raw channels and status comparisons remain exact; no timing/performance equivalence claim."})
    write("source-map.json", bound)
    write("case-changes.json", {"case_changes": changed, "requirement_source_hash_changes": requirement_hash_changes})
    write("status-changes.json", {"transitions": transitions, "all_old_or_new_nonpass": nonpass,
                                   "current_nonpass": [row for row in lang["results"] if row["status"] != "pass"],
                                   "historical_union_is_not_current_nonpass": True})
    write("raw-changes.json", raw_changes)
    write("payload-manifest.json", inventories)
    report = {"schema": 1, "scope": "Independent terminal data audit of Stage47/classpath full selected regression at0e13a58; not M2 completion, CI, platform or performance evidence.",
              "implementation_commit": COMMIT, "pinned_references": pins,
              "declared_inputs_unchanged_during_audit": True,
              "wrapper_commands_complete": True, "wrapper_own_terminal": terminal,
              "wrapper_terminal_qualification": "Required root receipt binds actual wrapper OS exit0 to the complete8command process report; strict child exit1 remains a failed gate.",
              "gates": {row["label"]: row["returncode"] for row in driver["commands"]},
              "scheduling_change": {"baseline_workers": 2, "current_workers": 4, "performance_comparison_claimed": False},
              "nonpass_union_qualification": "Union of baseline Stage46 current nonpass and current Stage47 nonpass; not all historical stages combined.",
              "language": {"report_sha256": sha((LANG / "report.json").read_bytes()), "case_definitions": len(after["cases"]), "requirements": len(after["requirements"]), "selected": len(lang["results"]),
                           "case_order_and_selection_unchanged": True, "status_counts": lang["status_counts"], "full_gate_failure_reasons": len(lang["full_gate_failures"]),
                           "status_transition_count": len(transitions), "current_nonpass_cases": sum(row["status"] != "pass" for row in lang["results"]), "historical_nonpass_comparison_union": len(nonpass), "declared_payloads_verified": len(inventories["language"]),
                           "classpath_child_report_sha256": sha(child_raw), "classpath_repetitions": 2, "classpath_same_case_counted_once": True},
              "lifecycle": {"report_sha256": sha((LIFE / "report.json").read_bytes()), "sequences": len(life["cases"]), "calls_each_language": calls,
                            "status_counts": {key: dict(value) for key, value in life_statuses.items()}, "raw_mismatches": life_mismatches,
                            "comparison_channels": ["status", "stdout", "stderr"], "error_class_differences_retained_excluded_from_equality": classes,
                            "declared_payloads_verified": len(inventories["lifecycle"]), "unexecuted_groups_preserved": True},
              "source_binding": {"captured_records": len(records), "unique_paths": len(bound), "all_match_commit_blobs": True,
                                 "lifecycle_config_directly_captured": config_direct_lifecycle,
                                 "config_qualification": "Stage47 schema2 directly captures root.cargo/config.toml and all4Rust Cargo controls, as did Stage46. Stage45 schema1 omission remains historical."},
              "exact_build_paths_never_enumerated": pruned, "payload_coverage_qualification": "Every declared payload was read directly; no evidence/cache directory tree was walked. The recorded producer integrity checks separately verify actual path coverage.",
              "output_pointers": {name: {"path": str(OUT / name), "sha256": sha((OUT / name).read_bytes())} for name in ["source-map.json", "case-changes.json", "status-changes.json", "raw-changes.json", "payload-manifest.json", "scheduling-comparison.json"]},
              "remaining": ["Root review and publication archive/summary/source pointers", "All remaining strict failures and unmapped/unimplemented requirements", "Stage48 stdlib admission is a separate unmerged source/evidence scope; further Stage47/M2 obligations remain open"],
              "full_m2_complete": False, "hosted_ci_claimed": False, "performance_target_claimed": False}
    write("report.json", report)
    print(json.dumps({"status": "Data audit complete; inspect retained compatibility failures and terminal qualification.", "report_sha256": sha((OUT / "report.json").read_bytes()), "language_status_counts": lang["status_counts"], "persistent_mismatches": len(life_mismatches)}))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--prepare", action="store_true")
    group.add_argument("--audit", action="store_true")
    parser.add_argument("--wrapper-terminal", type=Path)
    args = parser.parse_args()
    prepare() if args.prepare else audit(args.wrapper_terminal)
