"""Local Stage14 acceptance: frozen bytes, offline comparisons, one missing Java probe.

Captured native/Node/Wasm binaries are never executed. Original evidence is read
only. Verifier imports use exact implementation source bytes in a fresh overlay.
"""
from pathlib import Path
from functools import lru_cache
from collections import Counter
import hashlib
import importlib
import importlib.util
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
REPO = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
COMMIT = '4b27b7ecf2c6133e363ed228606b289e85c2e627'
REPORT_COMMIT = '8e47cfd'


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def need(condition, message):
    if not condition:
        raise ValueError(message)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def git(*args, repository=REPO):
    return subprocess.run(['git', *args], cwd=repository, check=True,
                          capture_output=True, timeout=60).stdout


@lru_cache(maxsize=None)
def committed(name):
    need(not Path(name).is_absolute() and '..' not in Path(name).parts, 'unsafe source path')
    for prefix in ['external/pkl/', 'external/pkl-pantry/']:
        if name.startswith(prefix):
            sub = prefix.rstrip('/')
            revision = git('rev-parse', COMMIT + ':' + sub).decode().strip()
            return git('show', revision + ':' + name[len(prefix):], repository=REPO / sub)
    return git('show', COMMIT + ':' + name)


def imported(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    sealed = OUT / 'relocated-sealed-evidence'
    sealed.mkdir(exist_ok=False)
    summary_path = REPO / 'reports/m2/stage14-final-summary.json'
    need(summary_path.read_bytes() == git('show', REPORT_COMMIT + ':reports/m2/stage14-final-summary.json'),
         'final report differs from committed report')
    summary = load(summary_path)
    need(summary['implementation_commit'] == COMMIT, 'wrong implementation')
    records = dict(summary['archives'])
    records['source'] = summary['implementation_source_verification']['evidence']
    records['blocked-ci'] = load(REPO / 'reports/m2/ci-stage14-summary.json')['evidence_archive']
    # The archive verifier is imported from Git bytes, not the mutable worktree.
    verifier = OUT / 'evidence.py'
    verifier.write_bytes(committed('tools/evidence.py'))
    evidence = imported('frozen_evidence', verifier)
    archive_results = {}
    for name, row in records.items():
        archive = REPO / row['path']
        need(sha(archive) == row['sha256'] and archive.stat().st_size == row['bytes'], 'archive identity changed')
        evidence.verify(archive)
        directory = sealed / name
        directory.mkdir()
        with tarfile.open(archive) as stream:
            for entry in stream.getmembers():
                if entry.name == 'EVIDENCE.json':
                    continue
                target = directory / entry.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(stream.extractfile(entry).read())
        archive_results[name] = dict(row, inventory_verified_now=True,
                                    extracted_without_inventory=True, relocated_directory=str(directory.relative_to(OUT)))
    print('Sealed archives independently verified and relocated', flush=True)
    source = sealed / 'source'
    binding = load(source / 'source-verification-stage14-final.json')
    overlay = OUT / 'verified-implementation'
    shutil.copytree(source / 'implementation-sources', overlay)
    index = load(source / 'source-copy-index.json')
    need(binding['implementation_commit'] == index['implementation_commit'] == COMMIT, 'source commit differs')
    for row in index['copies']:
        data = (source / row['snapshot']).read_bytes()
        need(hashlib.sha256(data).hexdigest() == row['sha256'] and data == committed(row['source']), 'deduplicated source differs')
    suite_dirs = {
        'language-stage14-final-02': sealed / 'language',
        'class-lifecycle-stage14-final-02': sealed / 'class-lifecycle',
        'frontend-stage14-final': sealed / 'regressions/frontend',
        'runtime-stage14-final': sealed / 'regressions/runtime',
        'lifecycle-stage14-final-02': sealed / 'regressions/lifecycle',
        'platforms-stage14-final': sealed / 'platforms',
    }

    def relocate(name):
        name = name.removeprefix(str(REPO) + '/')
        path = Path(name)
        need(path.parts[:2] == ('target', 'm2') and path.parts[2] in suite_dirs, 'unknown source suite path')
        return suite_dirs[path.parts[2]].joinpath(*path.parts[3:])

    for row in binding['source_checks']:
        data = relocate(row['snapshot']).read_bytes()
        need(hashlib.sha256(data).hexdigest() == row['sha256'] and data == committed(row['source']), 'captured source differs from Git')
    need(len(binding['source_checks']) == 1961 and len(index['copies']) == 1677, 'source accounting differs')
    for original, digest in binding['source_reports'].items():
        need(sha(relocate(original)) == digest, 'source-bound report differs')
    source_results = dict(implementation_commit=COMMIT, source_snapshot_copies=1961,
                          unique_source_files=1677, exact_git_bytes_verified_now=True,
                          pinned_submodule_blobs=True, source_proof_report_sha256=sha(source / 'source-verification-stage14-final.json'))
    # Add only committed support files absent from the captured source union.
    for name in git('ls-tree', '-r', '--name-only', COMMIT, 'tools', 'tests/fixtures/m1').decode().splitlines():
        destination = overlay / name
        if not destination.exists():
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(committed(name))
    sys.path.insert(0, str(overlay / 'tools'))
    modules = {name: importlib.import_module(name) for name in [
        'm2_language', 'm2_class_lifecycle', 'm2_identifier_tables', 'm1_frontend',
        'm1_runtime', 'm1_lifecycle', 'm1_platforms', 'oracle', 'm2_manifest']}
    for module in list(sys.modules.values()):
        filename = getattr(module, '__file__', '') or ''
        if Path(filename).name in {p.name for p in (overlay / 'tools').glob('*.py')}:
            need(Path(filename).resolve().is_relative_to(overlay), 'verifier import outside frozen overlay')
    language_tool = modules['m2_language']
    # ROOT is used only to reconstruct original command arguments; contract data
    # and freshness checks continue reading the exact immutable source overlay.
    language_tool.ROOT = REPO
    language = language_tool.check_report(sealed / 'language')
    need(language_tool.development_passes(language, sealed / 'language'), 'development contract failed')
    expected_ids = [r['id'] for r in load(overlay / 'tests/fixtures/m2/cases.json')['cases']]
    need([r['id'] for r in language['results']] == expected_ids, 'language order differs')
    classes = modules['m2_class_lifecycle'].check_report(sealed / 'class-lifecycle')
    need(modules['m2_class_lifecycle'].contract_passes(classes), 'class lifecycle contract failed')
    front = modules['m1_frontend'].check_report(sealed / 'regressions/frontend')
    lifecycle = modules['m1_lifecycle'].check_report(sealed / 'regressions/lifecycle')
    packaging = imported('frozen_stage14_packaging', source / 'package_stage14_final.py')
    validation = packaging.validation_report(sealed / 'validation')
    packaging.DIRECTORIES['platforms'] = sealed / 'platforms'
    platforms = packaging.platform_claims(load(sealed / 'platforms/report.json'), modules['m1_platforms'])
    need(modules['m1_platforms'].contract_matches(load(sealed / 'platforms/report.json')['comparisons']), 'platform contract failed')
    runtime = load(sealed / 'regressions/runtime/report.json')
    runtime_outcomes = []
    for row in runtime['cases']:
        captures = {}
        for target in ['java', 'rust']:
            process = row[target]
            need(process['status'] == 'executed', 'runtime process not executed')
            channels = []
            for channel in ['stdout', 'stderr']:
                info = process[channel]
                data = relocate(info['path']).read_bytes()
                need(len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256'], 'runtime raw identity differs')
                channels.append(data)
            captures[target] = (process['exit_code'], *channels)
        equal = captures['java'] == captures['rust']
        need(equal == row['raw_equal'], 'runtime raw equality differs')
        runtime_outcomes.append(dict(id=row['id'], raw_equal=equal))
    calls = [call for row in classes['cases'] for call in row['observations']['comparisons']]
    offline = dict(language_status_counts=language['status_counts'], selected=len(expected_ids),
                   metamorphic_relations=len(language['metamorphic_results']),
                   development_contract_passes=True, strict_subset_passes=language_tool.subset_passes(language),
                   full_m2_complete=False, full_gate_failure_reasons=len(language['full_gate_failures']),
                   class_unique_sequences=len({r['id'] for r in classes['cases']}),
                   class_sequence_executions=len(classes['cases']), class_call_comparisons=len(calls),
                   class_passing_calls=sum(r['status'] == 'pass' for r in calls),
                   class_unexecuted_groups=classes['unexecuted_groups'], frontend_raw_matches=len(front['results']),
                   lifecycle_protocol_matches=len(lifecycle['cases']),
                   lifecycle_full_diagnostic_mismatches=sum(not e['raw_equal'] for r in lifecycle['cases'] for e in r['observations']['diagnostics']),
                   runtime_raw_outcomes=runtime_outcomes, platforms=platforms,
                   validation={k: validation[k] for k in ['rust_passed', 'rust_intentionally_ignored', 'python_passed']})
    print('Frozen report, raw comparison, development and architecture contracts passed; known failures retained', flush=True)
    # The missing Java table probe uses committed input bytes from the overlay.
    # Existing pinned source checkout/JAR/JDK are independently verified in the
    # actual repository; no captured evaluator binary is started.
    for name in ['oracle.lock.json', 'references.lock']:
        need((REPO / name).read_bytes() == committed(name), 'oracle pins differ from implementation')
    oracle = modules['oracle']
    metadata = oracle.ensure_oracle(REPO)
    tool = modules['m2_identifier_tables']
    actual_ensure = oracle.ensure_oracle
    oracle.ensure_oracle = lambda root: metadata
    try:
        tool.execute(OUT / 'identifier-java', False)
    finally:
        oracle.ensure_oracle = actual_ensure
    identifier = load(OUT / 'identifier-java/report.json')
    need((OUT / 'identifier-java/unicode_identifier.rs').read_bytes() == committed(str(tool.TARGET)), 'generated table differs from commit')
    write(OUT / 'offline-verification.json', offline)
    write(OUT / 'source-verification.json', source_results)
    write(OUT / 'archive-verification.json', archive_results)
    workflow = committed('.github/workflows/ci.yml')
    (OUT / 'ci-stage14.yml').write_bytes(workflow)
    write(OUT / 'result.json', dict(implementation_commit=COMMIT, report_commit=git('rev-parse', REPORT_COMMIT).decode().strip(),
          status='accepted-local-development-scope', host=platform.platform(), captured_binaries_executed=False,
          new_compatibility_cases=0, original_archives_unchanged=True, offline=offline,
          source_verification=source_results, archives=archive_results,
          missing_local_check_completed=dict(command='tools/m2_identifier_tables.py --output <fresh identifier-java>',
              method='Frozen generator/probe/table inputs; existing pinned checkout/JAR/JDK verified by frozen oracle.ensure_oracle(REPO); metadata supplied to frozen generator wrapper.',
              interval_counts=identifier['interval_counts'], report_sha256=sha(OUT / 'identifier-java/report.json')),
          unavailable_platforms=['Linux', 'Windows'], github_ci_started_jobs=0,
          unavailable_scope='No Linux or Windows execution, fresh GitHub CI run, full language/API compatibility, or performance completion is claimed.'))
    print('Local Stage14 acceptance audit complete', flush=True)


if __name__ == '__main__':
    main()
