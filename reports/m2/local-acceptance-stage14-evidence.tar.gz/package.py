"""Seal the completed local audit without duplicating unchanged original suites."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import subprocess
import sys

sys.dont_write_bytecode = True
OUT = Path(__file__).resolve().parent
REPO = OUT.parents[2]


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    result = load(OUT / 'result.json')
    assert result['status'] == 'accepted-local-development-scope'
    assert (OUT / 'audit.stderr.bin').read_bytes() == b''
    implementation = result['implementation_commit']
    prior = 'f90d7b09124bb5a7d73dd5b2bfcddf2a90d2761f'
    unchanged = [
        '.github/workflows/ci.yml', 'references.lock', 'oracle.lock.json', 'external/pkl', 'external/pkl-pantry',
        'tools/inventory.py', 'tools/discover.py', 'tools/smoke_manifest.py', 'tools/regression_manifest.py',
        'tools/benchmark.py', 'tools/oracle.py', 'tools/compat.py', 'tools/m1_frontend.py',
        'tools/m1_semantics.py', 'tools/m1_host.py', 'tools/m1_graal.py', 'tools/java',
        'compatibility/inventory.json', 'compatibility/corpus.json', 'compatibility/rev1-inventory.json',
        'compatibility/smoke.json', 'compatibility/regressions.json', 'tests/fixtures/m0',
        'tests/fixtures/rev1', 'tests/fixtures/m1', 'benchmarks',
    ]
    command = ['git', 'diff', '--name-only', prior, implementation, '--', *unchanged]
    process = subprocess.run(command, cwd=REPO, check=True, capture_output=True, timeout=60)
    assert process.stdout == process.stderr == b''
    (OUT / 'unchanged-baseline.stdout.bin').write_bytes(process.stdout)
    (OUT / 'unchanged-baseline.stderr.bin').write_bytes(process.stderr)
    inherited = dict(prior_commit=prior, current_commit=implementation, compared_paths=unchanged,
                     command=command, exit_code=0, changed_paths=[],
                     scope='Inherited baseline inventory/oracle-only checks retain prior evidence; no new Stage14 execution or Linux/Windows result is claimed.')
    write(OUT / 'unchanged-baseline.json', inherited)
    mapping = [
        dict(job='workspace', checks=['cargo xtask verify', 'cargo fmt --all -- --check',
             'cargo clippy --workspace --all-targets --locked -- -D warnings', 'cargo test --workspace --locked',
             'cargo check -p pkl-runtime --target wasm32-unknown-unknown --locked'],
             status='retained-local-macos-pass', evidence='validation-stage14-final-evidence.tar.gz',
             raw_counts=dict(rust_passed=303, rust_ignored=1), unavailable=['Linux', 'Windows']),
        dict(job='compatibility-tooling', checks=['inventory.py --check', 'discover.py --check',
             'smoke_manifest.py --check', 'regression_manifest.py --check', 'benchmark.py --check-contract'],
             status='unchanged-baseline-inherited', evidence='unchanged-baseline.json and reports/m2/ci-stage13-summary.json'),
        dict(job='compatibility-tooling', checks=['python3 -m unittest discover -s tools/tests -v'],
             status='retained-local-macos-pass', evidence='validation-stage14-final-evidence.tar.gz', python_passed=194),
        dict(job='compatibility-tooling', checks=['oracle.py fetch', 'oracle.py smoke',
             'compat.py record/check/compare smoke', 'compat.py record/check selected historical regressions'],
             status='unchanged-oracle-only-baseline-inherited',
             fresh_check='Pinned artifact, JDK and clean reference source identities reverified for the identifier probe; no network fetch needed.',
             evidence='unchanged-baseline.json, identifier-java/report.json, reports/m2/ci-stage13-summary.json'),
        dict(job='m1-experiments', checks=['m1_frontend.py --check-contract', 'm1_semantics.py --check', 'test_m1_*.py'],
             status='retained-plus-offline-contract-pass',
             evidence='Full Python tests retained; frozen frontend contract and generated semantic cases rechecked against raw evidence.'),
        dict(job='m1-experiments', checks=['m1_graal.py --check-report retained evidence', 'm1_host.py Java Host observations'],
             status='unchanged-java-only-baseline-inherited', evidence='unchanged-baseline.json and reports/m2/ci-stage13-summary.json',
             scope='Graal and Java-only Host acquisition are unaffected by Stage14 Rust changes. Current Rust Host behavior is separately exercised by retained lifecycle and platform scenarios.'),
        dict(job='m1-experiments', checks=['m1_frontend.py', 'm1_runtime.py', 'm1_lifecycle.py', 'm1_platforms.py --verify-contract'],
             status='retained-plus-relocated-offline-pass-with-known-failures',
             evidence=['regressions-stage14-final-evidence.tar.gz', 'platforms-stage14-final-evidence.tar.gz', 'offline-verification.json']),
        dict(job='m2-language', checks=['m2_manifest.py --check', 'test_m2_*.py'],
             status='retained-plus-frozen-inventory-pass', evidence='validation-stage14-final-evidence.tar.gz and frozen m2_language.check_report'),
        dict(job='m2-language', checks=['m2_language.py --record-only', 'm2_language.py --verify-development',
             'm2_class_lifecycle.py --record-only', 'm2_class_lifecycle.py --verify-contract'],
             status='retained-plus-relocated-offline-development-pass',
             evidence=['language-stage14-final-evidence.tar.gz', 'class-lifecycle-stage14-final-evidence.tar.gz', 'offline-verification.json']),
        dict(job='m2-language', checks=['m2_identifier_tables.py --output <fresh>'],
             status='new-local-pinned-java-pass', evidence='identifier-java/report.json',
             scope='Full predicate interval transport regenerated by pinned Java and exact generated Rust bytes checked against implementation commit.'),
        dict(job='manual-full-gates', checks=['M0 full discovered corpus', 'm2_language.py --verify-full'],
             status='incomplete', scope='No fresh full-corpus run. Frozen M2 full gate remains failed with 1950 reasons; selected subset retains two known nonpasses.'),
        dict(job='hosted-setup-and-upload', checks=['GitHub runner setup', 'actions/upload-artifact', 'hosted artifact ZIP verification'],
             status='unavailable-not-applicable-to-local-artifacts',
             scope='All six Stage14 GitHub jobs failed before runner startup because of billing. Original blocked CI evidence is preserved; local tar inventories and relocatable raw verification provide local evidence only.'),
    ]
    write(OUT / 'workflow-check-map.json', mapping)
    platforms = load(OUT / 'relocated-sealed-evidence/platforms/report.json')
    identifier = load(OUT / 'identifier-java/report.json')
    audit_process = dict(command=[sys.executable, str(OUT / 'audit.py')], cwd=str(REPO), exit_code=0,
                         stdout_sha256=sha(OUT / 'audit.stdout.bin'), stderr_sha256=sha(OUT / 'audit.stderr.bin'),
                         python=sys.version, python_executable=sys.executable, helper_sha256=sha(OUT / 'audit.py'))
    write(OUT / 'audit-process.json', audit_process)
    report = dict(schema_version=1, created_utc=datetime.now(timezone.utc).isoformat(),
        acceptance='Local evidence accepted for continued M2 development by explicit user instruction; remote CI is not a prerequisite for this continuation.',
        implementation_commit=implementation, original_report_commit=result['report_commit'],
        status='pass-local-development-contract', host=result['host'], full_m2_complete=False,
        captured_binaries_executed=False, fresh_selected_java_rerun=False,
        retained_execution_scope=['macOS arm64 native workspace', 'Wasm compilation', 'Node N-API execution', 'Chromium Wasm execution'],
        unavailable_platform_execution=['Linux', 'Windows'],
        retained_runtimes=dict(node=platforms['execution']['node'], chromium=platforms['execution']['browser'],
             playwright=platforms['execution']['playwright'], rustc=(OUT / 'relocated-sealed-evidence/platforms/rust-version.stdout.bin').read_text()),
        new_local_java_identifier_check=dict(interval_counts=identifier['interval_counts'], exit_code=identifier['exit_code'],
             generated_table_matches_implementation_commit=True, oracle=identifier['oracle'],
             report_sha256=sha(OUT / 'identifier-java/report.json'), method=result['missing_local_check_completed']['method']),
        actual_retained_counts=result['offline'], source_verification=result['source_verification'],
        original_archives=result['archives'], original_archives_unchanged=True,
        workflow_check_map=mapping, unchanged_baseline=inherited, audit_process=audit_process,
        github_ci=dict(status='blocked-before-runner-start', run_id=39561429923, started_jobs=0, test_passes=0,
             original_report='reports/m2/ci-stage14-summary.json', retry_requested=False,
             scope='No hosted artifacts were created; no local evidence is relabeled as CI output.'),
        helper_preparation_failures=[
             dict(attempt='attempt-01', reason='Frozen verifier overlay omitted a committed M1 frontend support fixture; no implementation test failed.'),
             dict(attempt='attempt-02', reason='Frozen Java identifier overlay omitted the pinned upstream Lexer.java support blob; Java predicate probe had not started.')],
        limitations=['Selected language has 1470 passes, error-cycle oracle-error, and error-remainder-zero mismatch.',
             'Primitive oracle comparison retains regex-unicode-15-vs-16 and regex-zero-width-supplementary failures on all three targets.',
             'Runtime forcing-cycle diagnostic mismatch and four lifecycle full diagnostic mismatches remain failures.',
             'Class lifecycle unexecuted groups, 960 unimplemented cases, 40 unmapped cases and full M2 gate failures remain open.',
             'No full language/API compatibility or performance target completion is claimed.'],
        reproduction='Copy archived audit.py into a fresh target/m2/<new-directory>/audit.py in the original repository workspace, then run it with the unchanged original Stage14 archives available. Do not rerun inside the extracted audit package because it already contains identifier-java output. Captured commands retain the original absolute workspace paths. The helper refuses existing relocated proof directories. The identifier probe requires the pinned existing JDK/JAR; offline report proof executes no captured binaries.')
    write(OUT / 'acceptance.json', report)
    archive = REPO / 'reports/m2/local-acceptance-stage14-evidence.tar.gz'
    destination = REPO / 'reports/m2/local-acceptance-stage14.json'
    assert not archive.exists() and not destination.exists()
    spec = importlib.util.spec_from_file_location('frozen_evidence', OUT / 'evidence.py')
    evidence = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(evidence)
    excludes = ['relocated-sealed-evidence/*', 'verified-implementation/*',
                'attempt-*/relocated-sealed-evidence/*', 'attempt-*/verified-implementation/*']
    evidence.create(OUT, archive, excludes)
    report['evidence_archive'] = dict(path=str(archive.relative_to(REPO)), sha256=sha(archive), bytes=archive.stat().st_size,
             inventory_verified=True, exclusions=excludes,
             scope='Audit helpers, process captures, computed outcomes and fresh Java identifier evidence. Unchanged original sealed suites remain separate dependencies.')
    write(destination, report)
    print(json.dumps(dict(report=str(destination), archive=str(archive), bytes=archive.stat().st_size, sha256=sha(archive)), sort_keys=True))


if __name__ == '__main__':
    main()
