import importlib.util,tempfile,unittest,json,hashlib,subprocess,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('compare',Path(__file__).parents[1]/'m2_resource_compare.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class RawComparison(unittest.TestCase):
 def record(self):return dict(status=b'error\n',stdout=b'',stderr=b' x\n',stdoutUnits=b'',stderrUnits=b'\0 \0x\0\n',readsBefore=b'0',readsAfter=b'1')
 def test_full_equal(self):self.assertEqual(m.classify(self.record(),self.record()),'pass')
 def test_whitespace_not_trimmed(self):
  a=self.record();a['stderr']=b'x\n';self.assertEqual(m.classify(self.record(),a),'mismatch')
 def test_units_not_hidden_by_utf8(self):
  a=self.record();a['stderrUnits']=b'\0y';self.assertIn('stderrUnits',m.compare_channels(self.record(),a))
 def test_status_not_ignored(self):
  a=self.record();a['status']=b'success\n';self.assertEqual(m.classify(self.record(),a),'mismatch')
 def test_read_count_independent(self):
  a=self.record();a['readsAfter']=b'2';self.assertEqual(m.compare_channels(self.record(),a),['readsAfter'])
 def test_internal_not_compatibility_pass(self):self.assertEqual(m.classify(self.record(),self.record(),True),'oracle-internal-boundary')
 def test_constructor_unavailable_not_pass(self):self.assertEqual(m.classify(self.record(),{'unavailable':True}),'candidate-output-unavailable')
 def test_configured_property_not_selected(self):self.assertFalse(m.is_selected('base64-decoder','main.pkl','propValue'))
 def test_other_root_not_selected(self):self.assertFalse(m.is_selected('cache-text-resource-missing-retry','other.pkl','bb'))
 def test_authority_selected(self):self.assertTrue(m.is_selected('authority-key-pairs','main.pkl','u0'))
 def test_cli_with_only_unselected_calls_records_failure(self):
  with tempfile.TemporaryDirectory()as directory:
   root=Path(directory);oracle=root/'oracle';oracle.mkdir();snapshot=root/'snapshot';source=snapshot/'crates/pkl-runtime/examples/stage46_resource_probe.rs';source.parent.mkdir(parents=True);source.write_bytes(b'captured source')
   report={'observations':[{'case':'other-boundary','repeat':0,'calls':[{'source':'main.pkl','expression':'stable','session':0,'prefix':'outer-0'}]}],'apiCalls':1}
   def save(path,value):path.write_text(json.dumps(value))
   save(oracle/'report.json',report);save(oracle/'cases.json',[{'id':'other-boundary'}]);save(oracle/'inventory.json',{'files':[]});save(oracle/'closure.json',{'inventorySha256':m.sha(oracle/'inventory.json'),'reportSha256':m.sha(oracle/'report.json')})
   source_map=root/'source-map.json';save(source_map,{'crates/pkl-runtime/examples/stage46_resource_probe.rs':m.sha(source)})
   release=root/'release.json';save(release,{'artifact':sys.executable,'artifact_sha256':m.sha(Path(sys.executable)),'source_map':str(source_map),'source_map_sha256':m.sha(source_map),'source_snapshot':str(snapshot)})
   output=root/'output';result=subprocess.run([sys.executable,str(Path(m.__file__)),'--oracle',str(oracle),'--release',str(release),'--output',str(output)],capture_output=True)
   self.assertEqual(result.returncode,1,result.stderr)
   data=json.loads((output/'report.json').read_bytes());self.assertEqual(data['unexecutedApiCount'],1);self.assertEqual(data['selectedExpectedApiCalls'],0);self.assertFalse(data['strictSelectedCompatibilityPassed'])
 def test_unsafe_path_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   with self.assertRaises(ValueError):m.contained(Path(d),'../outside')
 def test_symlink_escape_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d);(p/'link').symlink_to('/tmp')
   with self.assertRaises(ValueError):m.contained(p,'link/x')
if __name__=='__main__':unittest.main()
