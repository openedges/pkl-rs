import importlib.util,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('compare',Path(__file__).parents[1]/'m2_resource_compare.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class RawComparison(unittest.TestCase):
 def record(self):return dict(status=b'error\n',stdout=b'',stderr=b' x\n',stdoutUnits=b'',stderrUnits=b'\0 \0x\0\n',readsBefore=b'0',readsAfter=b'1')
 def test_full_equal(self):self.assertEqual(m.classify(self.record(),self.record()),'pass')
 def test_whitespace_not_trimmed(self):
  a=self.record();a['stderr']=b'x\n';self.assertEqual(m.classify(self.record(),a),'mismatch')
 def test_units_not_hidden_by_utf8(self):
  a=self.record();a['stderrUnits']=b'\0y';self.assertIn('stderrUnits',m.compare_channels(self.record(),a))
 def test_status_not_ignored(self):
  a=self.record();a['status']=b'success\n';self.assertEqual(m.classify(self.record(),a),'mismatch')
 def test_read_count_independent(self):
  a=self.record();a['readsAfter']=b'2';self.assertEqual(m.compare_channels(self.record(),a),['readsAfter'])
 def test_internal_not_compatibility_pass(self):self.assertEqual(m.classify(self.record(),self.record(),True),'oracle-internal-boundary')
 def test_constructor_unavailable_not_pass(self):self.assertEqual(m.classify(self.record(),{'unavailable':True}),'candidate-output-unavailable')
 def test_unsafe_path_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   with self.assertRaises(ValueError):m.contained(Path(d),'../outside')
 def test_symlink_escape_rejected(self):
  with tempfile.TemporaryDirectory()as d:
   p=Path(d);(p/'link').symlink_to('/tmp')
   with self.assertRaises(ValueError):m.contained(p,'link/x')
if __name__=='__main__':unittest.main()
