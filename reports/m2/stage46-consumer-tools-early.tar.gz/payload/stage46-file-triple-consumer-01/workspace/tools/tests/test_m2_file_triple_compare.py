import importlib.util,unittest,tempfile,shutil,json,hashlib,subprocess,sys
from pathlib import Path
P=Path(__file__).parents[1]/'m2_file_triple_compare.py';spec=importlib.util.spec_from_file_location('compare',P);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
FIX=Path(__file__).parents[3]/'fixtures/triple-dot'
class Integrity(unittest.TestCase):
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)/'fixture';shutil.copytree(FIX,self.root)
 def tearDown(self):self.temp.cleanup()
 def mutate(self,change):
  p=self.root/'fixtures.json';d=json.loads(p.read_bytes());change(d);p.write_text(json.dumps(d));manifest=self.root/'manifest.json';r=json.loads(manifest.read_bytes());r['files']['fixtures.json']={'sha256':m.sha(p),'bytes':p.stat().st_size};manifest.write_text(json.dumps(r))
 def test_valid(self):self.assertEqual(m.verify_fixture(self.root)['javaApiCalls'],216)
 def test_reblessed_raw_whitespace_rejected(self):
  self.mutate(lambda d:d['cases'][0]['calls'][0]['channelsHex'].__setitem__('stdout.bin','20'))
  with self.assertRaises(ValueError):m.verify_fixture(self.root)
 def test_omitted_session_rejected(self):
  self.mutate(lambda d:d['cases'].pop())
  with self.assertRaises(ValueError):m.verify_fixture(self.root)
 def test_dropped_policy_event_rejected_even_reprojected(self):
  def change(d):
   c=d['cases'][0]['calls'][0];c['javaEvents'].pop(0);c['javaProjection']=m.project(c['javaEvents'],d['cases'][0]['sourceUri'])
  self.mutate(change)
  with self.assertRaises(ValueError):m.verify_fixture(self.root)
 def test_uri_swap_rejected(self):
  self.mutate(lambda d:d['cases'][0].__setitem__('sourceUri','file:///wrong.pkl'))
  with self.assertRaises(ValueError):m.verify_fixture(self.root)
 def test_unknown_event_not_silent(self):self.assertEqual(m.project(['mystery'],'file:///main')['unknownEvents'],['mystery'])
 def test_primary_and_repl_explicit_boundary(self):
  r=m.project(['policy-resolve-module file:///main','policy-resolve-module repl:text','policy-resolve-module file:///ancestor'],'file:///main');self.assertEqual(r['events'],['policy-resolve-module file:///ancestor']);self.assertEqual(len(r['outsideContract']),2)
 def test_raw_internal_completion_not_ordinary(self):self.assertTrue(m.project(['outer-0 error org.pkl.core.PklBugException'],'x')['unknownEvents'])
 def test_path_escape_rejected(self):
  with self.assertRaises(ValueError):m.safe(self.root,'../outside')
 def test_cli_verifier(self):
  r=subprocess.run([sys.executable,str(P),'verify','--fixture',str(self.root)],capture_output=True);self.assertEqual(r.returncode,0,r.stderr)
if __name__=='__main__':unittest.main()
