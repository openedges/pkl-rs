"""Strict raw primary-root typed Resource development comparison against sealed Java."""
from pathlib import Path
import argparse,collections,hashlib,json,re,shutil,subprocess,sys,time
SELECTED={'cache-text-resource-missing-retry','resource-bytes-utf8','authority-key-pairs','base64-decoder','missing-and-io-nullable-first'}
def selected(case_id,source,expression):return case_id in SELECTED and source=='main.pkl'and not(case_id=='base64-decoder'and expression in {'propValue','propNullable'})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def contained(root,name):
 p=Path(name)
 if p.is_absolute() or '..' in p.parts:raise ValueError('unsafe payload path')
 q=root/p
 if not q.resolve().is_relative_to(root.resolve()):raise ValueError('payload escapes oracle')
 return q
def compare_channels(expected,actual):
 return [n for n in ['status','stdout','stderr','stdoutUnits','stderrUnits','readsBefore','readsAfter']if expected[n]!=actual[n]]
def classify(expected,actual,internal=False):
 if internal:return 'oracle-internal-boundary'
 if actual.get('unavailable'):return 'candidate-output-unavailable'
 if actual.get('disposition')=='unsupported':return 'candidate-unsupported'
 return 'mismatch'if compare_channels(expected,actual)else'pass'
def channels(root,prefix,java=False):
 def read(suffix):return (root/(prefix+'.'+suffix)).read_bytes()
 v={'status':read('status.bin'),'stdout':read('stdout.bin'),'stderr':read('stderr.bin'),'stdoutUnits':read('stdout.code-units.bin'),'stderrUnits':read('stderr.code-units.bin'),'readsBefore':read('reads-before.bin'),'readsAfter':read('reads-after.bin')}
 for channel in ['stdout','stderr']:
  units=v[channel+'Units']
  if len(units)%2 or units.decode('utf-16-be','surrogatepass').encode('utf-8','replace')!=v[channel]:raise ValueError('Java UTF16/UTF8 payload inconsistency')
 if not java and(root/(prefix+'.disposition.bin')).exists():v['disposition']=read('disposition.bin').decode()
 return v
def reader_trace(directory):
 events=sorted(directory.glob('event-*.bin'),key=lambda p:int(p.stem.split('-')[1]));trace=[]
 for p in events:
  value=p.read_text();m=re.fullmatch(r'reader (.*?) attempt=(\d+) total=(\d+)',value)
  if m:trace.append(m.group(1).encode())
 return trace
def verify_oracle(oracle):
 inv=json.loads((oracle/'inventory.json').read_bytes());closure=json.loads((oracle/'closure.json').read_bytes())
 if sha(oracle/'inventory.json')!=closure['inventorySha256']or sha(oracle/'report.json')!=closure['reportSha256']:raise ValueError('oracle closure identity differs')
 for r in inv['files']:
  p=contained(oracle,r['path'])
  if sha(p)!=r['sha256']or p.stat().st_size!=r['bytes']:raise ValueError('oracle payload differs: '+r['path'])
 return json.loads((oracle/'report.json').read_bytes())
def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--oracle',type=Path,required=True);parser.add_argument('--release',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);a=parser.parse_args();o=a.output;o.mkdir(parents=True,exist_ok=False)
 write(o/'exclusions.json',{'declaredBeforeTraversal':True,'cargoCachePaths':[],'scope':'Exact sealedoracle inventory plus released20848-entry source map only;no source/cache walks. Source URI unchanged. Only explicit primary-root cases selected;configuredpropertyandsame-evaluatorother-root JavaAPIboundaries retainedunexecuted.'})
 oracle=a.oracle;report=verify_oracle(oracle);release=json.loads(a.release.read_bytes());candidate=Path(release['artifact']);sourcemap=Path(release['source_map']);snapshot=Path(release['source_snapshot'])
 assert sha(candidate)==release['artifact_sha256']and sha(sourcemap)==release['source_map_sha256']
 sourcehashes=json.loads(sourcemap.read_bytes())
 for rel,digest in sourcehashes.items():assert sha(contained(snapshot,rel))==digest,rel
 write(o/'release.json',release);shutil.copyfile(sourcemap,o/'source-map.json');shutil.copyfile(__file__,o/'comparator.py');shutil.copyfile(snapshot/'crates/pkl-runtime/examples/stage46_resource_probe.rs',o/'consumer.rs')
 cases=json.loads((oracle/'cases.json').read_bytes());records=[];comparisons=[];unexecuted=[];bycase={c['id']:c for c in cases}
 for ob in report['observations']:
  for call in ob['calls']:
   if not selected(ob['case'],call['source'],call['expression']):unexecuted.append({'case':ob['case'],'repeat':ob['repeat'],'session':call['session'],'prefix':call['prefix'],'reason':'same-evaluator independent ModuleSource API unavailable'if call['source']!='main.pkl'else'configured-property API or additional URI/policy typedfailure consumer contract not yet implemented'})
 for case in cases:
  if case['id']not in SELECTED:continue
  ops=[op[1]for op in case['operations']if op!='GC'and selected(case['id'],op[0],op[1])];expr=o/'inputs'/case['id']/'expressions.txt';expr.parent.mkdir(parents=True);expr.write_text('\n'.join(ops)+'\n');work=Path(case['workspace']);inputhashes={str(work/'main.pkl'):sha(work/'main.pkl'),str(expr):sha(expr)}
  payload=work/'payloads'
  if payload.exists():
   for q in payload.iterdir():
    if q.is_file():inputhashes[str(q)]=sha(q)
  for repeat in [0,1]:
   target=o/'cases'/case['id']/str(repeat);target.mkdir(parents=True);command=[str(candidate),str(work/'main.pkl'),case['sourceUri'],'main',str(expr),str(target/'calls'),str(payload),'2'];started=time.time_ns()
   with(target/'stdout.bin').open('wb')as stdout,(target/'stderr.bin').open('wb')as stderr:
    try:r=subprocess.run(command,stdout=stdout,stderr=stderr,timeout=90);code=r.returncode;timedout=False
    except subprocess.TimeoutExpired:code=None;timedout=True
   process={'command':command,'cwd':str(Path.cwd()),'startedUnixNs':started,'finishedUnixNs':time.time_ns(),'exitCode':code,'timedOut':timedout,'inputHashes':inputhashes};records.append(process);write(target/'process.json',process)
   ob=next(x for x in report['observations']if x['case']==case['id']and x['repeat']==repeat)
   for session in [0,1]:
    directory=target/'calls'/f'session-{session}';javadir=oracle/'cases'/case['id']/str(repeat)/'calls'/f'session-{session}';selected=[c for c in ob['calls']if c['session']==session and selected(case['id'],c['source'],c['expression'])]
    for index,call in enumerate(selected):
     expected=channels(javadir,call['prefix'],True);prefix=f'outer-{index}'
     try:actual=channels(directory,prefix)
     except(FileNotFoundError,ValueError)as e:actual={'unavailable':True,'reason':str(e)}
     status=classify(expected,actual,'PklBugException'in call['errorClass']);differences=[]if actual.get('unavailable')else compare_channels(expected,actual)
     comparisons.append({'case':case['id'],'repeat':repeat,'session':session,'javaPrefix':call['prefix'],'nativePrefix':prefix,'expression':call['expression'],'status':status,'differences':differences,'nativeDisposition':actual.get('disposition'),'unavailableReason':actual.get('reason')})
    expectedtrace=reader_trace(javadir);nativefiles=sorted(directory.glob('read-*.uri.bin'),key=lambda p:int(p.name.split('-')[1].split('.')[0]));actualtrace=[p.read_bytes()for p in nativefiles]
    write(directory/'reader-trace-comparison.json',{'expected': [x.hex()for x in expectedtrace],'actual':[x.hex()for x in actualtrace],'matches':expectedtrace==actualtrace,'scope':'Only actual ResourceReader callbacks compared. Standard policy counters/module loading/reader.close and JVM System.gc-request are preserved Java-only boundaries;native collect-every-poll is separate robustness evidence.'})
   assert all(sha(Path(p))==h for p,h in inputhashes.items())
 counts=dict(collections.Counter(r['status']for r in comparisons));traces=[]
 for case in cases:
  if case['id']in SELECTED:
   for repeat in [0,1]:
    for session in [0,1]:traces.append(json.loads((o/'cases'/case['id']/str(repeat)/'calls'/f'session-{session}'/'reader-trace-comparison.json').read_bytes()))
 assert sha(candidate)==release['artifact_sha256']and sha(sourcemap)==release['source_map_sha256']
 result={'scope':'Raw selected primary-root typed Resource/authority/base64 APIcalls only;countsderivedfromactualinputreport,notfullJavaAPI/standardsecuritypolicy/lifecycle parity. No normalization/filtering of compared rawchannels or APIreadcounts. JavaGC request vs native per-poll collection remain distinct.','counts':counts,'selectedExpectedApiCalls':len(comparisons),'javaApiCalls':report['apiCalls'],'unexecutedApiBoundaries':unexecuted,'unexecutedApiCount':len(unexecuted),'records':records,'comparisons':comparisons,'readerTraceCounts':{'pass':sum(t['matches']for t in traces),'mismatch':sum(not t['matches']for t in traces)},'releaseMetadataPath':str(a.release),'releaseMetadataSha256':sha(a.release),'artifactSha256':sha(candidate),'sourceMapSha256':sha(sourcemap),'sourceInputsVerified':len(sourcehashes),'consumerSha256':sha(o/'consumer.rs'),'oracleReportSha256':sha(oracle/'report.json'),'oracleInventorySha256':sha(oracle/'inventory.json'),'strictSelectedCompatibilityPassed':counts=={'pass':len(comparisons)}and all(t['matches']for t in traces)and all(r['exitCode']==0 and not r['timedOut']for r in records),'fullCompatibilityPassed':False};write(o/'report.json',result);print(json.dumps({'counts':counts,'selected':len(comparisons),'unexecuted':len(unexecuted),'readerTraces':result['readerTraceCounts'],'strictSelectedCompatibilityPassed':result['strictSelectedCompatibilityPassed']}));return 0 if result['strictSelectedCompatibilityPassed']else 1
if __name__=='__main__':sys.exit(main())
