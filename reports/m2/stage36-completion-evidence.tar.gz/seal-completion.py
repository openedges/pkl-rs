"""Preserve closed Stage36 source-commit and source-binding process captures."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'target/m2/stage36-completion-01'
OUT.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

files = []
processes = []
for name in ['seal-final', 'commit-source', 'push-source', 'remote-source', 'bind-sources']:
    directory = ROOT / 'target/m2/stage36-executions' / name
    process = json.loads((directory / 'process.json').read_bytes())
    assert process['exit_code'] == 0, name
    for channel in ['stdout', 'stderr']:
        assert sha(directory / (channel + '.bin')) == process[channel + '_sha256']
    processes.append(dict(name=name, **process))
    files.extend(sorted(directory.iterdir()))
files.extend(sorted((ROOT / 'target/m2/stage36-commit-binding-01').iterdir()))
rows = []
for source in files:
    assert source.is_file() and not source.is_symlink()
    relative = source.relative_to(ROOT / 'target/m2')
    destination = OUT / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    rows.append(dict(source=str(source), archived=str(relative), sha256=sha(source)))
(OUT / 'seal-completion.py').write_bytes(Path(__file__).read_bytes())
(OUT / 'ORIGINS.json').write_text(json.dumps(rows, indent=2) + '\n')
archive = ROOT / 'reports/m2/stage36-completion-evidence.tar.gz'
assert not archive.exists()
subprocess.run([sys.executable, 'tools/evidence.py', 'create', str(OUT), str(archive)], cwd=ROOT, check=True)
assert all(sha(Path(row['source'])) == row['sha256'] for row in rows)
binding = json.loads((ROOT / 'reports/m2/stage36-source-binding.json').read_bytes())
commit = binding['implementation_commit']
remote = (ROOT / 'target/m2/stage36-executions/remote-source/stdout.bin').read_bytes()
assert remote == (commit + '\trefs/heads/main\n').encode()
report = dict(scope='Closed Stage36 source implementation, archive and binding process records. No new runtime acquisition.',
              implementation_commit=commit, compatibility_complete=False,
              source_binding_passed=binding['source_binding_passed'],
              distinct_committed_paths=binding['distinct_committed_paths'],
              original_files=len(rows), processes=processes,
              archive=dict(path=str(archive.relative_to(ROOT)), sha256=sha(archive), bytes=archive.stat().st_size))
destination = ROOT / 'reports/m2/stage36-completion-captures.json'
assert not destination.exists()
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key:report[key] for key in ['implementation_commit', 'original_files', 'archive']}))
