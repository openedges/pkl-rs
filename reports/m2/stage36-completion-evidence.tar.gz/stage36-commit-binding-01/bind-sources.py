"""Bind completed Stage36 source snapshots to the exact implementation commit."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'target/m2/stage36-commit-binding-01'
OUT.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip()
sources={}
suites={}
for name,key in [('language-stage36-final-01','source_sha256'),
                 ('validation-stage36-final-01','sources'),
                 ('class-lifecycle-stage36-final-01','sources'),
                 ('platforms-stage36-final-01','source_hashes')]:
    report=ROOT/'target/m2'/name/'report.json'
    data=json.loads(report.read_bytes())[key]
    if isinstance(data,list): data={row['path']:row['sha256'] for row in data}
    suites[name]=dict(source_count=len(data),report_sha256=hashlib.sha256(report.read_bytes()).hexdigest())
    for path,digest in data.items():
        assert path not in sources or sources[path]==digest,path
        sources[path]=digest
helpers={name:digest for name,digest in sources.items() if name.startswith('target/')}
assert set(helpers)=={'target/m2/stage36-tools/checks.py'}
tracked={name:digest for name,digest in sources.items() if name not in helpers}
names=sorted(tracked)
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=ROOT,
       input=''.join(head+':'+name+'\n' for name in names).encode())
position=0
rows=[]
for name in names:
    end=raw.index(b'\n',position)
    oid,kind,length=raw[position:end].split()
    assert kind==b'blob',name
    position=end+1
    data=raw[position:position+int(length)]
    position+=int(length)
    assert raw[position:position+1]==b'\n'
    position+=1
    digest=hashlib.sha256(data).hexdigest()
    assert digest==tracked[name],name
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
    rows.append(dict(path=name,git_blob=oid.decode(),sha256=digest))
assert position==len(raw)
for name,digest in helpers.items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest
summary=dict(scope='Exact Git source binding for the completed Stage36 acquisitions; helper provenance is separate from committed production sources.',
             implementation_commit=head,source_binding_passed=True,compatibility_complete=False,
             distinct_committed_paths=len(rows),suites=suites,files=rows,
             ignored_captured_helpers=helpers,
             references_lock_sha256=hashlib.sha256((ROOT/'references.lock').read_bytes()).hexdigest())
(OUT/'bind-sources.py').write_bytes(Path(__file__).read_bytes())
(OUT/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
destination=ROOT/'reports/m2/stage36-source-binding.json'
assert not destination.exists()
destination.write_bytes((OUT/'report.json').read_bytes())
print(json.dumps({key:summary[key] for key in ('implementation_commit','source_binding_passed','distinct_committed_paths')}))
