"""Final portable comparator source bookends, tests, and one actual admission."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
M1 = ROOT / 'target/m2/stage57-m1-platform-contract-01'
CAPTURE = ROOT / 'target/m2/stage57-data-size-portable-capture-02'
BUILD = ROOT / 'target/m2/stage57-platform-validation-02'
CAPTURE_WRAPPER = ROOT / 'target/m2/stage57-platform-validation-04'
FIXTURE = ROOT / 'tests/fixtures/m2-data-size'
SOURCES = [
    'tools/data_size_portable_compare.py',
    'tools/tests/test_data_size_portable_compare.py',
    'tools/data_size_fixtures.py', 'tools/data_size_oracle.py',
    'tools/m1_platforms.py', 'tools/m2_source_inputs.py',
    'tools/platform/capture-data-size.mjs', 'tools/platform/data-size-session.mjs',
    'tools/platform/module-policy-session.mjs', 'tools/platform/resource-session.mjs',
    'tools/platform/package.json', 'tools/platform/package-lock.json',
]


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def put(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def snapshot():
    return {name: identity(ROOT / name) for name in SOURCES}


if any((OUT / name).exists() for name in ('sources', 'source-before.json',
                                          'commands.json', 'admission.stdout.bin')):
    raise ValueError('fresh comparator check directory required')
before = snapshot()
for name in SOURCES:
    target = OUT / 'sources' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
    if identity(target) != before[name]:
        raise ValueError('source changed during comparator snapshot: ' + name)
put('source-before.json', before)
commands = []
put('environment.json', {'cwd': str(ROOT), 'python': sys.version,
                         'python_executable': sys.executable,
                         'environment_sha256': hashlib.sha256(json.dumps(
                             dict(os.environ), sort_keys=True,
                             separators=(',', ':')).encode()).hexdigest(),
                         'selected_environment': {name: os.environ.get(name) for name in
                                                  ('PATH', 'HOME', 'TMPDIR', 'LANG',
                                                   'LC_ALL', 'TZ', 'TERM',
                                                   'PYTHONDONTWRITEBYTECODE')}})


def run(name, argv):
    start = time.time()
    result = subprocess.run(argv, cwd=ROOT, capture_output=True)
    (OUT / f'{name}.stdout.bin').write_bytes(result.stdout)
    (OUT / f'{name}.stderr.bin').write_bytes(result.stderr)
    commands.append({'name': name, 'argv': argv, 'cwd': str(ROOT),
                     'exit_code': result.returncode, 'started_epoch': start,
                     'finished_epoch': time.time(),
                     'stdout': identity(OUT / f'{name}.stdout.bin'),
                     'stderr': identity(OUT / f'{name}.stderr.bin')})
    put('commands.json', commands)
    return result.returncode


try:
    test = [sys.executable, '-B', '-m', 'unittest',
            'tools.tests.test_data_size_portable_compare']
    if run('normal-tests', test + ['-v']) != 0:
        raise ValueError('normal portable comparator tests failed')
    if run('optimized-tests', [sys.executable, '-O', *test[1:], '-q']) != 0:
        raise ValueError('optimized portable comparator tests failed')
    admission = [sys.executable, '-B', 'tools/data_size_portable_compare.py',
                 '--capture', str(CAPTURE), '--m1', str(M1),
                 '--build-wrapper', str(BUILD),
                 '--capture-wrapper', str(CAPTURE_WRAPPER),
                 '--fixture', str(FIXTURE), '--gate', 'string']
    code = run('admission', admission)
    if code == 0:
        verdict = json.loads((OUT / 'admission.stdout.bin').read_bytes())
        put('admission-summary.json', {
            'integrity': verdict['integrity'],
            'strict_string_passed': verdict['strict_string_passed'],
            'targets': {name: {'counts': value['counts'],
                               'sessions': value['sessions']} for name, value in
                        verdict['targets'].items()},
            'full_public_api_comparison_passed': verdict['full_public_api_comparison_passed'],
            'public_export_status': verdict['public_export_status'],
            'source_manifest_sha256': verdict['offline_verifier_source_manifest_sha256'],
        })
finally:
    after = snapshot()
    put('source-after.json', after)
    put('source-stability.json', {'stable': before == after and all(
        identity(OUT / 'sources' / name) == before[name] for name in SOURCES),
        'source_count': len(SOURCES)})
if before != after or any(row['exit_code'] != 0 for row in commands):
    raise SystemExit(1)
