import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
names = ['tools/data_size_portable_compare.py',
         'tools/tests/test_data_size_portable_compare.py']


def ident(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def put(name, value):
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


before = {name: ident(root / name) for name in names}
put('source-before.json', before)
commands = []
for tag, argv in [
    ('normal', [sys.executable, '-B', '-m', 'unittest',
                'tools.tests.test_data_size_portable_compare', '-v']),
    ('optimized', [sys.executable, '-O', '-B', '-m', 'unittest',
                   'tools.tests.test_data_size_portable_compare', '-q']),
]:
    start = time.time()
    result = subprocess.run(argv, cwd=root, capture_output=True)
    (out / f'{tag}.stdout.bin').write_bytes(result.stdout)
    (out / f'{tag}.stderr.bin').write_bytes(result.stderr)
    commands.append({'name': tag, 'argv': argv, 'cwd': str(root),
                     'exit_code': result.returncode,
                     'started_epoch': start, 'finished_epoch': time.time(),
                     'stdout': ident(out / f'{tag}.stdout.bin'),
                     'stderr': ident(out / f'{tag}.stderr.bin')})
    put('commands.json', commands)
after = {name: ident(root / name) for name in names}
put('source-after.json', after)
assert before == after and all(row['exit_code'] == 0 for row in commands)
