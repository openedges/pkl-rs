"""Single actual M1 acquisition followed by canonical portable DataSize sessions.
Run only after root's explicit build GO. Never deletes or rewrites captures.
"""
import gzip,hashlib,json,os,pathlib,platform,shutil,struct,subprocess,sys,time
ROOT=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
W=ROOT/'target/m2/stage57-platform-validation-02'
M=ROOT/'target/m2/stage57-m1-platform-contract-01'
D=ROOT/'target/m2/stage57-data-size-portable-capture-01'
sys.path.insert(0,str(ROOT/'tools'))
from m1_platforms import source_paths
h=lambda p:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def put(n,o):(W/n).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
old=json.loads((ROOT/'target/m2/stage57-native-build-08/source-before.json').read_text())
extra=['tools/data_size_fixtures.py','tools/data_size_oracle.py','tools/java/DataSizeSplitOracle.java','tests/fixtures/m2-data-size/cases.json','tests/fixtures/m2-data-size/module.pkl','tests/fixtures/m2-data-size/queries.tsv','tests/fixtures/m2-data-size/oracle-evidence.tar.gz','tests/fixtures/m2-data-size/manifest.json','oracle.lock.json','references.lock']
paths={str(p.relative_to(ROOT)):p for p in source_paths()}
for n in set(old)|set(extra):paths[n]=ROOT/n
assert not (W/'acquisition-source-before.json').exists() and not M.exists() and not D.exists()
assert all(h(ROOT/n)==v for n,v in old.items()),'helper08 source changed'
def snap():return {n:h(p) for n,p in sorted(paths.items())}
before=snap();put('acquisition-source-before.json',before)
assert all(n in before for n in ['crates/pkl-runtime/src/stdlib/'+v for v in ['base.pkl','json.pkl','ref.pkl','test.pkl','modules.txt']])
env=os.environ.copy();env.update({'CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0','PYTHONDONTWRITEBYTECODE':'1'})
put('acquisition-environment.json',{'host':platform.platform(),'python':sys.version,'cwd':str(ROOT),'selected_env':{n:env.get(n) for n in ['PATH','HOME','TMPDIR','LANG','LC_ALL','TZ','TERM','PLAYWRIGHT_BROWSERS_PATH','PKL_FIXTURE_PYTHON','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','PYTHONDONTWRITEBYTECODE']},'free_disk_before':shutil.disk_usage(ROOT).free,'source_count':len(before),'helper08_source_match':True,'wrapper_source':h(pathlib.Path(__file__)),'embedded_stdlib':{n:before[n] for n in before if n in {'crates/pkl-runtime/src/stdlib/'+v for v in ['base.pkl','json.pkl','ref.pkl','test.pkl','modules.txt']}}})
def record_process(tag):
 for name,cmd in [('ps',['ps','-axo','pid,ppid,command']),('lsof-debug',['lsof','-nP','+D',str(ROOT/'target/debug')])]:
  r=subprocess.run(cmd,cwd=ROOT,capture_output=True,timeout=30)
  (W/f'{tag}-{name}.stdout.bin').write_bytes(r.stdout);(W/f'{tag}-{name}.stderr.bin').write_bytes(r.stderr)
  put(f'{tag}-{name}.json',{'argv':cmd,'exit_code':r.returncode,'stdout':h(W/f'{tag}-{name}.stdout.bin'),'stderr':h(W/f'{tag}-{name}.stderr.bin')})
record_process('before')
active=[line for line in (W/'before-ps.stdout.bin').read_text(errors='replace').splitlines() if (' cargo ' in line or ' rustc ' in line or '/cargo ' in line or '/rustc ' in line) and 'acquire.py' not in line]
assert not active,f'Concurrent Rust build processes: {active[:10]}'
commands=[]
def run(name,cmd,timeout):
 start=time.time()
 if name=='datasize-portable':
  seen=set();rows=[];sample_count=0
  with (W/f'{name}.stdout.bin').open('xb') as out, (W/f'{name}.stderr.bin').open('xb') as err, gzip.open(W/'browser-process-samples.bin.gz','xb',compresslevel=1) as samples:
   proc=subprocess.Popen(cmd,cwd=ROOT,stdout=out,stderr=err,env=env)
   while proc.poll() is None:
    ps=subprocess.run(['ps','-axo','pid,ppid,command'],capture_output=True)
    samples.write(struct.pack('!dii',time.time(),ps.returncode,len(ps.stdout)));samples.write(ps.stdout)
    sample_count+=1
    if ps.returncode==0:
     for line in ps.stdout.decode(errors='replace').splitlines()[1:]:
      if ('Chromium' in line or 'chromium' in line or 'capture-data-size.mjs' in line) and line not in seen:
       seen.add(line);rows.append(line)
       parts=line.strip().split(None,2)
       if len(parts)>=3 and parts[0].isdigit() and ('Chromium' in line or 'chromium' in line):
        pid=parts[0];l=subprocess.run(['lsof','-nP','-p',pid,'-d','txt','-Fpcn'],capture_output=True)
        (W/f'browser-lsof-{pid}.stdout.bin').write_bytes(l.stdout)
        (W/f'browser-lsof-{pid}.stderr.bin').write_bytes(l.stderr)
        put(f'browser-lsof-{pid}.json',{'argv':['lsof','-nP','-p',pid,'-d','txt','-Fpcn'],'exit_code':l.returncode,'stdout':h(W/f'browser-lsof-{pid}.stdout.bin'),'stderr':h(W/f'browser-lsof-{pid}.stderr.bin')})
    if time.time()-start>timeout:proc.kill();proc.wait();raise TimeoutError('portable capture timed out')
    time.sleep(0.35)
   rc=proc.wait()
  put('browser-process-attestation.json',{'scope':'Out-of-band sampled OS process tree; sampling can miss short-lived processes and does not independently prove every page context','raw_samples':'browser-process-samples.bin.gz','raw_samples_identity':h(W/'browser-process-samples.bin.gz'),'sample_count':sample_count,'observed_rows':rows,'node_capture_pid':proc.pid})
 else:
  r=subprocess.run(cmd,cwd=ROOT,capture_output=True,env=env,timeout=timeout)
  (W/f'{name}.stdout.bin').write_bytes(r.stdout);(W/f'{name}.stderr.bin').write_bytes(r.stderr)
  rc=r.returncode

 d={'name':name,'argv':cmd,'cwd':str(ROOT),'environment':{n:env[n] for n in ['PATH','HOME','TMPDIR','LANG','LC_ALL','TZ','TERM','PLAYWRIGHT_BROWSERS_PATH','PKL_FIXTURE_PYTHON','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','PYTHONDONTWRITEBYTECODE'] if n in env},'exit_code':rc,'signal':-rc if rc<0 else None,'started_epoch':start,'finished_epoch':time.time(),'stdout_log':str(W/f'{name}.stdout.bin'),'stderr_log':str(W/f'{name}.stderr.bin'),'stdout':h(W/f'{name}.stdout.bin'),'stderr':h(W/f'{name}.stderr.bin'),'free_disk_after':shutil.disk_usage(ROOT).free};commands.append(d);put('acquisition-commands.json',commands)
 return rc
m1=run('m1-contract',['python3','tools/m1_platforms.py','--output',str(M),'--verify-contract'],3600)
if m1==0 and (M/'report.json').is_file():
 report=json.loads((M/'report.json').read_text())
 assert report['compatibility_status']=='fail' and report['experiment_contract_status']=='pass'
 assert report['source_stability'] is True and report['total']>0
 assert all(report['oracle_passed'][t]==report['total']-2 for t in ['rust','node','browser'])
 assert {row['id'] for row in report['comparisons'] if not all(row['oracle_matches'].values())}=={'regex-unicode-15-vs-16','regex-zero-width-supplementary'}
 artifacts={n:h(p) for n,p in [('napi',M/'pkl_napi.node'),('wasm_js',M/'wasm/pkl_wasm.js'),('wasm_bg',M/'wasm/pkl_wasm_bg.wasm'),('native',M/'semantics_probe')]}
 put('m1-artifacts-before-capture.json',artifacts)
 c=run('datasize-portable',[shutil.which('node'),str(ROOT/'tools/platform/capture-data-size.mjs'),str(D),str(M/'wasm'),str(M/'pkl_napi.node'),str(ROOT/'tests/fixtures/m2-data-size')],1800)
 put('m1-artifacts-after-capture.json',{n:h(p) for n,p in [('napi',M/'pkl_napi.node'),('wasm_js',M/'wasm/pkl_wasm.js'),('wasm_bg',M/'wasm/pkl_wasm_bg.wasm'),('native',M/'semantics_probe')]})
 assert artifacts==json.loads((W/'m1-artifacts-after-capture.json').read_text()),'build artifacts changed during capture'
else:c=None
put('acquisition-source-after.json',snap())
record_process('after')
summary={'m1_exit':m1,'datasize_capture_exit':c,'source_stable':before==snap(),'free_disk_after':shutil.disk_usage(ROOT).free,'m1_report_present':(M/'report.json').is_file(),'capture_report_present':(D/'report.json').is_file()}
if (D/'report.json').is_file():
 p=json.loads((D/'report.json').read_text());summary['capture_complete']=p['complete'];summary['capture_report']=h(D/'report.json')
put('acquisition-summary.json',summary)
print(json.dumps(summary,sort_keys=True))
if m1!=0 or c!=0 or not summary['source_stable']:sys.exit(1)
