"""Freeze and run focused portable DataSize syntax/transport tests only."""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
out = root / 'target/m2/stage57-data-size-portable-tests-01'
node = Path('/opt/homebrew/Cellar/node/26.10.0_1/bin/node')
names = [
    'tools/platform/data-size-session.mjs',
    'tools/platform/data-size-session.test.mjs',
    'tools/platform/capture-data-size.mjs',
    'tools/platform/capture-data-size.test.mjs',
    'tools/platform/module-policy-session.mjs',
    'tools/platform/resource-session.mjs',
    'tools/platform/package.json',
    'tools/platform/package-lock.json',
    'tools/data_size_fixtures.py',
    'tools/data_size_oracle.py',
    'tools/java/DataSizeSplitOracle.java',
]
def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def save(name, value):
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

before = {name: identity(root / name) for name in names}
save('source-before.json', before)
runtime = {'node': str(node), 'node_identity': identity(node),
           'version': subprocess.run([node, '--version'], cwd=root, capture_output=True, check=True).stdout.decode().strip()}
save('runtime.json', runtime)
commands = [[str(node), '--check', name] for name in names[:4]]
commands.append([str(node), '--test', names[1], names[3]])
records = []
for index, command in enumerate(commands):
    result = subprocess.run(command, cwd=root, capture_output=True, timeout=120)
    (out / f'{index}.stdout.bin').write_bytes(result.stdout)
    (out / f'{index}.stderr.bin').write_bytes(result.stderr)
    record = {'argv': command, 'cwd': str(root), 'exit_code': result.returncode,
              'stdout': identity(out / f'{index}.stdout.bin'),
              'stderr': identity(out / f'{index}.stderr.bin')}
    records.append(record)
    save('commands.json', records)
after = {name: identity(root / name) for name in names}
save('source-after.json', after)
if before != after:
    raise RuntimeError('portable source changed during focused checks')
print(json.dumps({'exits': [record['exit_code'] for record in records],
                  'source_stable': before == after, 'commands': len(records)}))
if any(record['exit_code'] for record in records):
    raise SystemExit(1)
