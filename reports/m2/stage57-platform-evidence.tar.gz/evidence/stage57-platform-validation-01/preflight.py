import hashlib,json,os,pathlib,platform,shutil,subprocess,sys,time
ROOT=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57'); W=ROOT/'target/m2/stage57-platform-validation-01'
sys.path.insert(0,str(ROOT/'tools'))
from m1_platforms import source_paths
extra=['tools/platform/capture-data-size.mjs','tools/platform/data-size-session.mjs','tools/platform/capture-data-size.test.mjs','tools/platform/data-size-session.test.mjs','tools/data_size_fixtures.py','tools/data_size_oracle.py','tools/java/DataSizeSplitOracle.java','tests/fixtures/m2-data-size/cases.json','tests/fixtures/m2-data-size/module.pkl','tests/fixtures/m2-data-size/queries.tsv','tests/fixtures/m2-data-size/oracle-evidence.tar.gz','oracle.lock.json','references.lock','crates/pkl-runtime/src/stdlib/base.pkl','crates/pkl-runtime/src/stdlib/json.pkl','crates/pkl-runtime/src/stdlib/ref.pkl','crates/pkl-runtime/src/stdlib/test.pkl','crates/pkl-runtime/src/stdlib/modules.txt']
paths={p.relative_to(ROOT).as_posix():p for p in source_paths()}
for n in extra:paths[n]=ROOT/n
h=lambda p:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def snap():return {n:h(p) for n,p in sorted(paths.items())}
def put(n,o):(W/n).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
assert not (W/'source-before.json').exists()
before=snap();put('source-before.json',before)
node=shutil.which('node');assert node
commands=[]
for name,cmd in [(f'syntax-{i}',[node,'--check',n]) for i,n in enumerate(extra[:4])]+[('focused-tests',[node,'--test','tools/platform/data-size-session.test.mjs','tools/platform/capture-data-size.test.mjs'])]:
 result=subprocess.run(cmd,cwd=ROOT,capture_output=True,env=os.environ.copy(),timeout=180)
 (W/f'{name}.stdout.bin').write_bytes(result.stdout);(W/f'{name}.stderr.bin').write_bytes(result.stderr)
 commands.append({'name':name,'argv':cmd,'cwd':str(ROOT),'exit_code':result.returncode,'stdout':h(W/f'{name}.stdout.bin'),'stderr':h(W/f'{name}.stderr.bin')})
put('commands.json',commands)
after=snap();put('source-after.json',after)
put('environment.json',{'host':platform.platform(),'python':sys.version,'node_executable':node,'node_version':subprocess.run([node,'--version'],capture_output=True).stdout.decode().strip(),'environment':{k:os.environ[k] for k in ['PATH','HOME','TMPDIR','LANG','LC_ALL','TZ','TERM','PLAYWRIGHT_BROWSERS_PATH','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG'] if k in os.environ},'source_stable':before==after,'source_files':len(before),'embedded_stdlib':{n:before[n] for n in extra[-5:]}})
print(json.dumps({'source_files':len(before),'stable':before==after,'commands':[(c['name'],c['exit_code']) for c in commands]},sort_keys=True))
if not before==after or any(c['exit_code'] for c in commands):sys.exit(1)
