#!/usr/bin/env python3
"""Add canonical checkpoint/index names and summaries derived from retained raw bytes."""
import json
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import compat
import evidence
import oracle

PUBLICATION = Path(__file__).resolve().parent
summary_path = ROOT / 'reports/m2/classpath-implementation-summary.json'
captures_path = ROOT / 'reports/m2/classpath-captures.json'
closeout_archive = ROOT / 'reports/m2/classpath-closeout-captures.tar.gz'
if any(path.exists() for path in (summary_path, captures_path, closeout_archive)):
    raise ValueError('canonical publication paths must be fresh')
summary = compat.read_json(ROOT / 'reports/m2/classpath-checkpoint-summary.json')
binding = compat.read_json(ROOT / 'reports/m2/classpath-source-binding.json')


def harness(path):
    rows = [tuple(map(int, row)) for row in re.findall(
        r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',
        path.read_text())]
    if not rows:
        raise ValueError('missing original harness outcome')
    return dict(zip(('passed', 'failed', 'ignored', 'measured', 'filtered_out'), map(sum, zip(*rows))))


def python_count(path):
    rows = re.findall(r'Ran (\d+) tests? in', path.read_text())
    if len(rows) != 1:
        raise ValueError('missing original Python test outcome')
    return int(rows[0])


workspace = harness(ROOT / 'target/m2/classpath-required-checks-01/3.stdout.bin')
example = harness(ROOT / 'target/m2/classpath-example-tests-01/stdout.bin')
latest_python = python_count(PUBLICATION / 'final-tooling/0/stderr.bin')
module_python = python_count(ROOT / 'target/m2/classpath-tooling-checks-01/1.stderr.bin')
initial_python = python_count(ROOT / 'target/m2/classpath-tooling-checks-01/0.stderr.bin')
if workspace != dict(passed=692, failed=0, ignored=1, measured=0, filtered_out=36):
    raise ValueError('unexpected workspace counts; retain and review')
if example != dict(passed=6, failed=0, ignored=0, measured=0, filtered_out=0):
    raise ValueError('unexpected example counts; retain and review')
if (latest_python, module_python, initial_python) != (15, 11, 10):
    raise ValueError('unexpected Python counts; retain and review')
summary['required_rust_checks']['workspace_harness_invocations'] = workspace
summary['example_tests'] = dict(path='target/m2/classpath-example-tests-01', harness_invocations=example)
summary['tooling']['python_tests'] = dict(final_classpath=latest_python, retained_module_adapter=module_python,
    distinct_tests=latest_python + module_python, historical_initial_classpath=initial_python,
    historical_initial_added_to_total=False, counts_are_feature_coverage=False)
source_qualifications = {}
for name, snapshot in binding['captured_sources'].items():
    rust_and_build = [path for path in snapshot['entries'] if path.startswith('crates/')
        or path in ('.cargo/config.toml', 'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'xtask/Cargo.toml')]
    rust_differences = [path for path in rust_and_build if not snapshot['entries'][path]['matches_current']]
    if rust_differences:
        raise ValueError('Rust/build source changed after recorded checks: ' + str(rust_differences))
    source_qualifications[name] = dict(captured_source_count=snapshot['count'],
        root_cargo_config_present=snapshot['root_cargo_config_present'],
        rust_and_build_captured_inputs=len(rust_and_build), rust_and_build_differences=rust_differences,
        all_captured_rust_and_build_inputs_match=True,
        differences={path: snapshot['entries'][path] for path in snapshot['differs_from_current']})
summary['source_qualifications'] = source_qualifications
summary['source_qualification'] = (
    'Final original02 captures current Rust, engine, reference, Cargo configuration and strengthened tooling. '
    'Its only captured/current difference is the subsequently added results prose in docs/m2-jvm-classpath.md. '
    'Initial01 is historical: root Cargo config was omitted and its verifier/tests predate three integrity fixes. '
    'Required Rust checks precede those Python-only fixes; their captured Rust/build inputs still match. '
    'No claim that all historical captured paths equal the proposed current files.')
summary['captures_index'] = 'reports/m2/classpath-captures.json'
compat.write_json(summary_path, summary)
links = {}
for path in [summary_path, ROOT / 'reports/m2/classpath-checkpoint-summary.json',
             ROOT / 'reports/m2/classpath-source-binding.json', ROOT / 'reports/m2/classpath-publication-audit.json']:
    links[path.relative_to(ROOT).as_posix()] = dict(sha256=oracle.sha256(path), bytes=path.stat().st_size)
captures = dict(schema=1, scope='Native directory-classpath checkpoint publication index; strict nonpasses retained.',
    archive=summary['archive'], publications=links,
    roots=compat.read_json(ROOT / 'reports/m2/classpath-publication-audit.json')['roots'],
    exact_exclusions_before_walking=['target/m2/classpath-original-01/build', 'target/m2/classpath-original-02/build'],
    symlinks=dict(count=1, representation='Exact link-target bytes as regular payloads with symlink-kind metadata; no traversal.'),
    raw_source_integrity='publication/source-integrity.json inside the main archive',
    final_tooling='publication/final-tooling inside the main archive',
    source_binding='publication/source-binding.json inside the main archive',
    final_commit_binding='Pending root publication; only Git reads/hash-object without writes were used.')
closeout = PUBLICATION / 'closeout'
closeout.mkdir()
shutil.copyfile(Path(__file__), closeout / 'final-index.py')
shutil.copyfile(summary_path, closeout / summary_path.name)
shutil.copyfile(ROOT / 'reports/m2/classpath-publication-audit.json', closeout / 'classpath-publication-audit.json')
shutil.copyfile(ROOT / 'docs/m2-jvm-classpath.md', closeout / 'm2-jvm-classpath.md')
compat.write_json(closeout / 'pre-closeout-captures-index.json', captures)
compat.write_json(closeout / 'proposed-source-blobs.json', binding['proposed_files'])
evidence.create(closeout, closeout_archive, [])
captures['closeout_archive'] = dict(path=str(closeout_archive.relative_to(ROOT)),
    sha256=oracle.sha256(closeout_archive), bytes=closeout_archive.stat().st_size,
    qualification='Contains the canonical implementation summary, derivation script, exact proposed blobs, '
                  'audit, results prose and the pre-closeout index; the final index necessarily remains outside its own archive.')
compat.write_json(captures_path, captures)
print(json.dumps(dict(main_archive=summary['archive'], closeout=captures['closeout_archive'],
    implementation_summary_sha256=oracle.sha256(summary_path), captures_index_sha256=oracle.sha256(captures_path),
    source_binding_sha256=oracle.sha256(ROOT / 'reports/m2/classpath-source-binding.json'),
    distinct_python_tests=latest_python + module_python, workspace=workspace, example=example), sort_keys=True))
