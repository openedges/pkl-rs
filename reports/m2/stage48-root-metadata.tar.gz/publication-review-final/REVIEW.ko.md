# Stage48 root3archive 게시 독립 검토

고정 report `76bba1b9…`, selection `c52ba8a5…`, producer actual66228exit0을 기준으로 세 archive의 전 payload28,490개를 읽었다. EVIDENCE/path set·SHA·길이와 모든 선택 원본의 bytes/mode가 일치하며, 기존 독립 raw 감사의22,683개 input에도 연결됐다. 명시한 파일만 읽었고 새 평가/빌드/Java/Node/browser/verifier/Git 실행과 원본 변경은 없다.

archives는 8,098,365 / 1,072,474 / 1,041,385bytes이며 모두100MiB미만이다. 플랫폼·원형/typed bootstrap·tooling의 source 경계와 strict 실패를 유지한다. 두 consumer-source 복사본은 실제 typed helper/test SHA와 일치한다. 예전 C01 logical helper path는 immutable snapshot의 d395cfb1…를 읽었고, 별도 복사본은 선언된 typed 후속ad555537…다. 두 버전을 합치지 않았다.

첫 감사01은 위 logical mapping을 동일 SHA로 강제해 연결 단계에서 실패했다. 원본 archive 문제가 아니며 actual79640exit1, 원소스와 실패 이유를 그대로 봉인했다. 새02 actual16244exit0에서 이 한 가지 선언된 consumer delta를 명시해 검증했다. 숨겨서 제외하거나 archive를 재생성하지 않았다.

mode 복원에는 archive header0644와 별도로selection.json의 실제mode/원본path가 필요하다. root는 최종 closeout archive에 exact selection/report/pack/raw/terminal을 포함하고 descriptor에서 member/SHA를 연결한다고 확인했다. 그 게시조건을 유지하면 새 material issue는 없다. 원래 C01/typed bootstrap strict failure, Java의 두 SPI counter 관찰 범위, 과거 unit source hash-only 및 완전 C01 snapshot의 구분은 바뀌지 않는다.
