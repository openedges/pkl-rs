from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;BASE=ROOT/'target/m2'
GROUPS={
 'platforms':['stage48-c01-platform-control-01'],
 'bootstrap':['stage48-c01-bootstrap-control-01','stage48-c01-bootstrap-typed-control-02','stage48-bootstrap-typed-provider-tests-01'],
 'tooling':['stage48-policy84-installation-01','stage48-policy84-installed-checks-01','stage48-portable-provider-unit-01','stage48-portable-provider-unit-02','stage48-portable-provider-all-unit-01','stage48-portable-provider-all-unit-02','stage48-portable-provider-all-unit-03','stage48-portable-driver-syntax-02','stage48-platform-tooling-01','stage48-inventory-refresh-01','stage48-inventory-refresh-02'],
}
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
selection={'scope':'Closed C01 actual platform/legacy and typed bootstrap runs, Java fixture installation, historical provider unit checks and manifest freshness. Strict failed outcomes are retained. Historical unit source reconstruction is not claimed for hash-only versions; final C01 complete snapshot and typed successor copied helper/test bytes are separate.','groups':GROUPS,'enumeration':'Only explicitly named closed evidence roots; lstat directory/file checks before descent. No build/dependency/workspace roots selected; encountering a cache or symlink is an error, not a silent skip.','startedUtc':datetime.datetime.now(datetime.UTC).isoformat(),'files':[],'commands':[]}
write('selection.json',selection)
for group,names in GROUPS.items():
 stage=OUT/'staging'/group;stage.mkdir(parents=True,exist_ok=False)
 for name in names:
  source=BASE/name
  assert source.is_dir() and not source.is_symlink(),source
  for directory,dirs,files in os.walk(source,topdown=True,followlinks=False):
   here=Path(directory)
   for child in dirs:
    p=here/child;assert stat.S_ISDIR(p.lstat().st_mode),p
    assert child not in ['node_modules','.git','.cache','target'],p
   dirs.sort()
   for filename in sorted(files):
    p=here/filename;mode=p.lstat().st_mode;assert stat.S_ISREG(mode),p
    relative=Path(name)/p.relative_to(source);target=stage/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
    row={'group':group,'path':str(relative),'original':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(mode)};assert sha(target)==row['sha256'];selection['files'].append(row)
 # Consumer-only source after C01, explicitly bind the actual tested bytes.
 if group=='bootstrap':
  for relative in ['tools/platform/bootstrap-session.mjs','tools/platform/module-policy-session.test.mjs']:
   p=ROOT/relative;target=stage/'typed-provider-sources'/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
   selection['files'].append({'group':group,'path':str(target.relative_to(stage)),'original':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)})
write('selection.json',selection)
archives=[]
for group in GROUPS:
 archive=OUT/'archives'/('stage48-'+group+'-captures.tar.gz')
 for action,argv in [('create',[sys.executable,'tools/evidence.py','create',str(OUT/'staging'/group),str(archive)]),('verify',[sys.executable,'tools/evidence.py','verify',str(archive)])]:
  label=group+'-'+action
  with(OUT/(label+'.stdout.bin')).open('wb')as stdout,(OUT/(label+'.stderr.bin')).open('wb')as stderr:process=subprocess.run(argv,cwd=ROOT,stdout=stdout,stderr=stderr)
  selection['commands'].append({'label':label,'argv':argv,'exitCode':process.returncode});write('selection.json',selection);assert process.returncode==0,label
 assert archive.stat().st_size<100*1024*1024,archive
 archives.append({'path':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':sum(row['group']==group for row in selection['files'])})
changes=[row['original']for row in selection['files']if sha(Path(row['original']))!=row['sha256']];assert not changes,changes
write('report.json',{'scope':selection['scope'],'archives':archives,'sourceFiles':len(selection['files']),'originalChanges':changes,'selectionSha256':sha(OUT/'selection.json'),'finishedUtc':datetime.datetime.now(datetime.UTC).isoformat(),'complete':True})
print(json.dumps({'archives':archives,'sourceFiles':len(selection['files']),'originalChanges':changes}),flush=True)
