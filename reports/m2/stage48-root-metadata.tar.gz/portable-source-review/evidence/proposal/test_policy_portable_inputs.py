from pathlib import Path
import json,shutil,tempfile,unittest
from unittest.mock import patch
import policy_portable_inputs as tool
class Provenance(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name);shutil.copyfile(tool.O/'policy-causes.mjs',self.root/'policy-causes.mjs');self.fixture=tool.R/'tests/fixtures/m2-module-admission-policy'
 def test_original_fixture_and_actual_cause_verify_without_evaluation(self):
  r=tool.verify(self.fixture);self.assertEqual((r['javaApiCalls'],r['javaOrderedEvents']),(84,280));self.assertEqual(r['portableEvaluations'],0)
 def test_cause_source_tamper_cannot_be_reblessed(self):
  p=self.root/'policy-causes.mjs';p.write_bytes(p.read_bytes().replace(b'82,',b'83,',1))
  with patch.object(tool,'O',self.root):
   with self.assertRaisesRegex(ValueError,'differs'):tool.verify(self.fixture)
 def test_raw_authority_inventory_forgery_fails_before_payload_read(self):
  a=self.root/'authority';a.mkdir()
  for name in ['report','inventory','closure']:shutil.copyfile(tool.A/(name+'.json'),a/(name+'.json'))
  p=a/'inventory.json';v=json.loads(p.read_bytes());v['files'].pop(next(iter(v['files'])));p.write_text(json.dumps(v))
  with patch.object(tool,'A',a):
   with self.assertRaisesRegex(ValueError,'literal raw cause authority'):tool.construct()
 def test_cause_symlink_is_rejected(self):
  p=self.root/'policy-causes.mjs';p.unlink();p.symlink_to(tool.O/'policy-causes.mjs')
  with patch.object(tool,'O',self.root):
   with self.assertRaisesRegex(ValueError,'regular payload'):tool.verify(self.fixture)
if __name__=='__main__':unittest.main()
