"""Verify original policy84 plus one exact captured raw Host cause. No evaluator."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,stat,sys
sys.dont_write_bytecode=True
O=Path(__file__).parent.resolve();R=O.parents[2];A=O.parent/'stage48-module-admission-oracle-01';sha=lambda b:hashlib.sha256(b).hexdigest()
PINS=('dcaa95e8eab8b1a7efda01d2494758d44e5045abe7c75eb79224e0079d768efc','11f1dbb9c1fc0b57761075c6ef9bf618210462f9f7ecefe32f02402cc7e41b29','40750b468c747e60b09f35ede8839983edd5400883b8731a2a2f85f3d173fcfd')
VERIFIER_SHA='d1f91dc9a44b8d1a9291f4b8b65aa35ea2e295ec74c2fb521a44ecdf89227739';FIXTURE_MANIFEST='6a4d5b2c8d394108c8a0ee98b33bbc5fd20525aa467da7e68e1799b8cea8ab72'
def require(ok,text):
 if not ok:raise ValueError(text)
def regular(root,rel):
 p=Path(rel);require(not p.is_absolute()and'..'not in p.parts and str(p)==rel,'safe relative path');q=root;require(stat.S_ISDIR(q.lstat().st_mode),'regular root')
 for part in p.parts[:-1]:q=q/part;require(stat.S_ISDIR(q.lstat().st_mode),'regular parent')
 q=q/p.name;require(stat.S_ISREG(q.lstat().st_mode),'regular payload');return q.read_bytes()
def construct():
 docs=[regular(A,n+'.json')for n in ['report','inventory','closure']];require(tuple(map(sha,docs))==PINS,'literal raw cause authority pins');report,inventory,closure=map(json.loads,docs);require(closure['sealed']and closure['inventorySha256']==PINS[1]and closure['reportSha256']==PINS[0],'original cause seal');rows=inventory['files'];proof={}
 def payload(rel):
  b=regular(A,rel);row=rows[rel];require(row['kind']=='regular'and sha(b)==row['sha256']and len(b)==row['bytes'],'pinned cause/source payload');proof[rel]={'sha256':sha(b),'bytes':len(b)};return b
 prefix='cases/resolve-denial-retry-catch/0/calls/session-0/denial-0';require(payload(prefix+'.kind.bin')==b'module'and payload(prefix+'.context.bin')==b'pkl:json','actual module resolve cause context');require(payload(prefix+'.message-null.bin')==b'false','actual nonnull raw cause');b=payload(prefix+'.message.bin');u=payload(prefix+'.message.code-units.bin');require(u.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==b,'independent actual Java cause encodings');require(payload(prefix+'.class.bin')==b'org.pkl.core.SecurityManagerException','actual typed cause class')
 source=payload('AdmissionProbe.java');profile=payload('profile.json');require(report['inputHashes'][str(A/'AdmissionProbe.java')]==sha(source)and report['inputHashes'][str(A/'profile.json')]==sha(profile),'helper/runtime report binding')
 value={'profile':'actual-captured-deny-json-module-resolve-v1','kind':'security-manager-exception','uri':'pkl:json','messageNull':False,'messageUnits':[int.from_bytes(u[i:i+2],'big')for i in range(0,len(u),2)],'messageJavaUtf8Hex':b.hex()};mjs=('// Exact original Java Host input; not a formatted Pkl diagnostic.\nexport const policyCauses = Object.freeze('+json.dumps(value,indent=2)+');\n').encode();return mjs,proof

def verify(fixtures):
 verifier=R/'tools/module_admission_policy_fixtures.py';require(sha(verifier.read_bytes())==VERIFIER_SHA,'original verifier byte pin');require(sha(regular(fixtures,'manifest.json'))==FIXTURE_MANIFEST,'original fixture manifest pin');spec=importlib.util.spec_from_file_location('sealed_policy84',verifier);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);result=module.verify(fixtures);mjs,proof=construct();require(regular(O,'policy-causes.mjs')==mjs,'raw cause module differs from pinned Java Host input');return {**result,'causeModuleSha256':sha(mjs),'causeProvenance':{'originalRoot':str(A),'reportInventoryClosurePins':list(PINS),'payloads':proof},'portableEvaluations':0,'fullLifecycleGate':'Still requires all actual primary/repl/factory/path events and original counters; do not synthesize.'}
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--fixtures',type=Path,required=True);p.add_argument('--write-causes',action='store_true');args=p.parse_args()
 if args.write_causes:
  target=O/'policy-causes.mjs';require(not target.exists(),'fresh raw cause module required');target.write_bytes(construct()[0])
 print(json.dumps(verify(args.fixtures),indent=2))
