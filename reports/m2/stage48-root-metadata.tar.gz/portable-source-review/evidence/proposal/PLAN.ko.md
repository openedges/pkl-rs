# Stage48 policy84 실제 portable 제안

1. 영구84 fixture·원래 verifier·fresh Java01 raw SecurityManagerException 입력을 literal hash로 인증합니다. 기존 원문은 바꾸지 않습니다.
2. 기존 SourceSession/resource/defaultmodule helper를 그대로 재사용하고 실제 typed request만 Host wrapper가 처리합니다. Java 이벤트 삽입·URI/cache 재구현·Java fallback은 없습니다.
3. C01 canonical Node/Wasm artifact와 실제 browser binary를 명시적으로 pin합니다. root 검토 전에는 실제 portable 취득을 하지 않습니다.
4. 84 API의 UTF16/JavaUTF8/ownership gate와 전체280 event/counter gate를 분리합니다. supplied-primary 및 observer schema 차이로 full gate는 계속 실패합니다. 전체 strict driver exit1을 성공으로 치환하지 않습니다.
5. 검토 후 승인된 정확한 handoff hash와 새 출력 root로 실제 PID/terminal을 보존하고, 별도 readback audit으로 원시 결과·도구·artifact 변경0을 확인합니다.
