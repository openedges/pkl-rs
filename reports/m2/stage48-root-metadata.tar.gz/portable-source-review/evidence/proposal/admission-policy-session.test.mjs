import test from 'node:test';
import assert from 'node:assert/strict';
import {runAdmissionPolicyCase, compareAdmissionPolicyCase} from './admission-policy-session.mjs';
import {policyCauses} from './policy-causes.mjs';
const module = (kind, uri = 'pkl:json') => ({kind: 'module-request', token: kind + '-token', module: {
  kind, id: kind === 'check-import' ? '1' : '2', originalUri: uri, importUri: uri,
  importerOriginalUri: 'file:///main.pkl', importerResolvedUri: 'file:///real.pkl'}});
const fixture = (mode = 'allow') => ({id: 'protocol-only', repeat: 0, session: 0,
  source: 'stable=7', uri: 'file:///main.pkl', moduleName: 'main', expressions: ['stable'],
  operations: [['main.pkl', 'stable']], readerPlan: [], policyProfile: {mode},
  expected: [{status: 'success', stdoutUnits: [55], stderrUnits: [], stdoutHex: '37', stderrHex: '',
    readsBefore: 0, readsAfter: 0, counterBytesBeforeHex: '00', counterBytesAfterHex: '00'}],
  orderedEvents: [{utf8Hex: '706f6c6963792d7265736f6c76652d6d6f64756c652066696c653a2f2f2f6d61696e2e706b6c'}]});
function api(events, observed, result = true) {
  class Session {
    static forExpressions() { return new Session(); }
    startPath() { this.events = events.map(event => structuredClone(event)); }
    poll() { return this.events.shift() ?? {kind: 'value', value: Uint16Array.of(55)}; }
    collect() { observed.push(['collect']); } close() {} free() {} heapSlots() { return 0; }
    completeDefaultModule(token, now) { observed.push(['default', token, now]); return result; }
    rejectModuleResolution(...args) { observed.push(['reject', ...args]); }
  }
  return {SourceSession: Session};
}
test('actual requests preserve context and explicitly delegate the shared default', () => {
  const observed = [], actual = runAdmissionPolicyCase(api([module('check-import'), module('resolve')], observed), fixture());
  assert.equal(actual.acquisitionError, null);
  assert.deepEqual(actual.moduleRequests.map(row => row.module.importerResolvedUri), ['file:///real.pkl', 'file:///real.pkl']);
  assert.deepEqual(observed.filter(row => row[0] === 'default'), [['default', 'check-import-token', 0], ['default', 'resolve-token', 0]]);
  assert.deepEqual(actual.nativePolicyEvents, ['policy-import file:///real.pkl -> pkl:json', 'policy-resolve-module pkl:json']);
  assert.equal(actual.architecture.terminalSlots, 0);
});
test('deny-json sends exact captured raw UTF16 cause before any default resolve', () => {
  const observed = [], actual = runAdmissionPolicyCase(api([module('check-import'), module('resolve')], observed), fixture('deny-json'));
  assert.equal(actual.acquisitionError, null);
  assert.deepEqual(observed.filter(row => row[0] === 'default'), [['default', 'check-import-token', 0]]);
  assert.deepEqual(observed.find(row => row[0] === 'reject'), ['reject', 'resolve-token', 'security-manager-exception', String.fromCharCode(...policyCauses.messageUnits), 0]);
  assert.deepEqual(actual.moduleRequests[1].completion.messageUnits, policyCauses.messageUnits);
});
test('malformed custom-denial request cannot consume a token', () => {
  const event = module('resolve'); delete event.module.importerResolvedUri;
  const observed = [], actual = runAdmissionPolicyCase(api([event], observed), fixture('deny-json'));
  assert.match(actual.acquisitionError.message, /invalid actual policy request/);
  assert.equal(observed.some(row => ['reject', 'default'].includes(row[0])), false);
});
test('unsupported default completion remains an acquisition failure', () => {
  const actual = runAdmissionPolicyCase(api([module('check-import')], [], false), fixture());
  assert.match(actual.acquisitionError.message, /unsupported actual module request/);
});
test('unexpected singleton resolve is not given an invented raw cause', () => {
  const observed = [], actual = runAdmissionPolicyCase(api([module('resolve', 'pkl:base')], observed), fixture('deny-singletons'));
  assert.match(actual.acquisitionError.message, /no captured raw allowlist-denial/);
  assert.equal(observed.some(row => row[0] === 'reject'), false);
});
test('raw API can pass while missing original full event/counter gate stays failed', () => {
  const f = fixture(), actual = runAdmissionPolicyCase(api([], []), f), result = compareAdmissionPolicyCase(f, actual);
  assert.equal(result.rawApiContractPassed, true);
  assert.equal(result.fullEventBytesEqual, false); assert.equal(result.fullCounterBytesEqual, false);
  assert.equal(result.fullLifecyclePassed, false); assert.equal(result.passed, false);
  assert.deepEqual(actual.nativePolicyEvents, []);
});
test('authored GC operation requests actual native collection without fabricating Java GC event', () => {
  const f = fixture(); f.expressions.push('stable'); f.operations.push('GC', ['main.pkl', 'stable']);
  f.expected.push(structuredClone(f.expected[0]));
  const actual = runAdmissionPolicyCase(api([], []), f);
  assert.deepEqual(actual.nativePolicyEvents, ['native-explicit-collect']);
  assert.equal(actual.architecture.pendingPolicyCollections, 1);
  assert.equal(actual.calls.length, 2);
});
test('unknown policy or operation/query mismatch is rejected before creating a session', () => {
  const never = {SourceSession: {forExpressions() { assert.fail('must validate first'); }}};
  assert.throws(() => runAdmissionPolicyCase(never, fixture('unknown')), /unknown exact policy/);
  const f = fixture(); f.operations[0][1] = 'changed';
  assert.throws(() => runAdmissionPolicyCase(never, f), /operation\/query order differs/);
});
