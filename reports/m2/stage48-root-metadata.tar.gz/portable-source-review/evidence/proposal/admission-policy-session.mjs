// A Host wrapper around existing SourceSession/resource helpers, not an evaluator.
import {runResourceCase, compareResourceCase, javaUtf8Bytes} from './resource-session.mjs';
import {completeDefaultModuleRequest} from './module-policy-session.mjs';
import {policyCauses} from './policy-causes.mjs';
const required = ['originalUri', 'importUri', 'importerOriginalUri', 'importerResolvedUri'];
const permitted = new Set(['kind', 'id', ...required, 'resolvedUri', 'sourceUri']);
function validate(event) {
  const request = event?.module;
  if (event?.kind !== 'module-request' || typeof event.token !== 'string' || !event.token.length
      || typeof request?.id !== 'string' || !/^[0-9]+$/.test(request.id)
      || !['check-import', 'resolve'].includes(request.kind)
      || required.some(name => typeof request[name] !== 'string')
      || Object.keys(request).some(name => !permitted.has(name))
      || request.resolvedUri != null || request.sourceUri != null)
    throw Error('invalid actual policy request context');
  return request;
}
const hex = text => javaUtf8Bytes(Array.from({length: text.length}, (_, i) => text.charCodeAt(i)))
  .map(value => value.toString(16).padStart(2, '0')).join('');
const equal = (a, b) => Array.isArray(a) && Array.isArray(b) && a.length === b.length
  && a.every((entry, index) => entry === b[index]);

export function runAdmissionPolicyCase(api, fixture, budget = 7) {
  const mode = fixture?.policyProfile?.mode;
  if (!['allow', 'deny-json', 'deny-singletons'].includes(mode)) throw Error('unknown exact policy84 mode');
  if (fixture.readerPlan.length !== 0) throw Error('policy84 reader plan must be empty');
  const requests = [], events = [], countersBefore = [], countersAfter = [];
  const gcBefore = new Map(); let expressions = 0;
  for (const operation of fixture.operations) {
    if (operation === 'GC') gcBefore.set(expressions, (gcBefore.get(expressions) ?? 0) + 1);
    else {
      if (!Array.isArray(operation) || operation[0] !== 'main.pkl'
          || operation[1] !== fixture.expressions[expressions]) throw Error('operation/query order differs');
      expressions++;
    }
  }
  if (expressions !== fixture.expressions.length) throw Error('incomplete authored operations');
  let callIndex = -1, imports = 0, resolves = 0, pendingCollections = 0;
  const counter = () => `requests=${requests.length}\nimport=${imports}\nresolve=${resolves}\nevent=${events.length}\n`;
  const wrapped = {SourceSession: {forExpressions(...args) {
    const session = api.SourceSession.forExpressions(...args);
    return new Proxy(session, {get(target, name) {
      if (name === 'startPath') return (index, ...rest) => {
        callIndex = index;
        for (let i = 0; i < (gcBefore.get(index) ?? 0); i++) {
          target.collect(); pendingCollections++;
          events.push('native-explicit-collect');
        }
        countersBefore[index] = counter();
        return target.startPath(index, ...rest);
      };
      if (name === 'poll') return (...args) => {
        const event = target.poll(...args);
        if (event.kind === 'value' || event.kind === 'error') countersAfter[callIndex] = counter();
        if (event.kind !== 'module-request') return event;
        const request = validate(event);
        if (callIndex < 0) throw Error('module request has no active API call');
        const row = {callIndex, token: event.token, module: {...request}};
        requests.push(row);
        if (request.kind === 'check-import') {
          imports++; events.push(`policy-import ${request.importerResolvedUri} -> ${request.importUri}`);
        } else { resolves++; events.push(`policy-resolve-module ${request.importUri}`); }
        target.collect(); pendingCollections++;
        if (mode === 'deny-json' && request.kind === 'resolve' && request.importUri === 'pkl:json') {
          if (request.originalUri !== request.importUri || policyCauses.uri !== request.importUri
              || policyCauses.kind !== 'security-manager-exception') throw Error('unconfigured exact captured policy cause');
          const message = policyCauses.messageNull ? null : String.fromCharCode(...policyCauses.messageUnits);
          row.completion = {kind: policyCauses.kind, messageUnits: [...policyCauses.messageUnits], messageNull: policyCauses.messageNull};
          target.rejectModuleResolution(event.token, 'security-manager-exception', message, 0);
        } else {
          if (mode === 'deny-singletons' && request.kind === 'resolve'
              && ['pkl:base', 'pkl:ref', 'pkl:test'].includes(request.importUri))
            throw Error('unexpected singleton resolve has no captured raw allowlist-denial input');
          const handled = completeDefaultModuleRequest(target, event);
          row.completion = {kind: 'explicit-shared-default', handled};
          if (handled !== true) throw Error('unsupported actual module request; no fallback');
        }
        return {kind: 'yield'};
      };
      const value = Reflect.get(target, name, target);
      return typeof value === 'function' ? value.bind(target) : value;
    }});
  }}};
  const actual = runResourceCase(wrapped, fixture, budget);
  actual.moduleRequests = requests;
  actual.nativePolicyEvents = events;
  actual.nativePolicyEventUtf8Hex = events.map(hex);
  actual.nativeCountersBeforeHex = countersBefore.map(hex);
  actual.nativeCountersAfterHex = countersAfter.map(hex);
  actual.nativeCounterSchema = 'requests/import/resolve/event; different from original Java8-field observer';
  actual.architecture.pendingPolicyCollections = pendingCollections;
  actual.modulePolicy = 'captured-raw-deny-json-first/explicit-shared-default/strict-policy84-v1';
  actual.lifecycleBoundary = 'Provided primary text; no synthetic primary/repl/factory/path/API-outcome events. Full Java280 trace/counter gate remains mandatory.';
  return actual;
}

export function compareAdmissionPolicyCase(fixture, actual) {
  const comparison = compareResourceCase(fixture, actual);
  comparison.rawApiContractPassed = comparison.passed;
  comparison.fullEventBytesEqual = equal(actual.nativePolicyEventUtf8Hex,
    fixture.orderedEvents.map(event => event.utf8Hex));
  comparison.fullCounterBytesEqual = fixture.expected.every((expected, index) =>
    expected.counterBytesBeforeHex === actual.nativeCountersBeforeHex[index]
      && expected.counterBytesAfterHex === actual.nativeCountersAfterHex[index]);
  comparison.fullLifecyclePassed = comparison.fullEventBytesEqual && comparison.fullCounterBytesEqual;
  comparison.passed = comparison.rawApiContractPassed && comparison.fullLifecyclePassed;
  comparison.scope = 'Raw API bytes/ownership and original full trace/counters are separate; known supplied-primary and counter-schema differences remain failed.';
  return comparison;
}
