from pathlib import Path
import json,subprocess,tempfile,unittest
import launch
class Guards(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.file=self.root/'raw-cause.bin';self.file.write_bytes(b'exact');self.declared={str(self.file):{'sha256':launch.sha(b'exact'),'bytes':5}}
 def test_transitive_input_tamper_is_rejected_after_valid_snapshot(self):
  launch.capture_snapshot(self.declared);self.file.write_bytes(b'other')
  with self.assertRaisesRegex(ValueError,'dependency pin'):launch.capture_snapshot(self.declared)
 def test_symlink_cannot_replace_declared_authority(self):
  other=self.root/'other';other.write_bytes(self.file.read_bytes());self.file.unlink();self.file.symlink_to(other)
  with self.assertRaisesRegex(ValueError,'regular declared'):launch.capture_snapshot(self.declared)
 def test_actual_driver_rejects_noncanonical_cli_artifact_before_output_or_addon_load(self):
  config=json.loads((launch.O/'canonical-artifacts.json').read_bytes());out=self.root/'actual';command=[config['node'],str(launch.O/'compare-admission-policy.mjs'),str(out),str(self.root/'wrong-wasm'),config['addon'],config['fixtures'],config['package']];r=subprocess.run(command,capture_output=True,timeout=30)
  self.assertNotEqual(r.returncode,0);self.assertIn(b'differ from reviewed canonical C01 binding',r.stderr);self.assertFalse(out.exists())
if __name__=='__main__':unittest.main()
