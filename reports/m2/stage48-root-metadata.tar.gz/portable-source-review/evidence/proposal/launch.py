"""Reviewed C01-only proposal admission, strict dependency guards and actual process receipts."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,stat,subprocess,sys,traceback
sys.dont_write_bytecode=True
O=Path(__file__).parent.resolve();sha=lambda b:hashlib.sha256(b).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def capture_snapshot(declared):
 actual={}
 for path,expected in declared.items():
  q=Path(path);require(stat.S_ISREG(q.lstat().st_mode),'regular declared input: '+path);b=q.read_bytes();row={'sha256':sha(b),'bytes':len(b)};require(row=={'sha256':expected['sha256'],'bytes':expected['bytes']},'declared dependency pin: '+path);actual[path]=row
 return actual

def main():
 p=argparse.ArgumentParser();p.add_argument('--handoff-sha256',required=True);p.add_argument('--output',type=Path);p.add_argument('--execute',action='store_true');a=p.parse_args();require(sha((O/'handoff.json').read_bytes())==a.handoff_sha256,'explicit reviewed handoff pin');handoff=json.loads((O/'handoff.json').read_bytes());sources={}
 for rel,row in handoff['sourceFiles'].items():
  q=Path(rel);require(not q.is_absolute()and'..'not in q.parts and str(q)==rel,'safe source relative path');sources[str(O/q)]=row
 source_before=capture_snapshot(sources);config=json.loads((O/'canonical-artifacts.json').read_bytes());dependencies_before=capture_snapshot(config['files'])
 spec=importlib.util.spec_from_file_location('reviewed_policy_inputs',O/'policy_portable_inputs.py');inputs=importlib.util.module_from_spec(spec);spec.loader.exec_module(inputs);policy_before=inputs.verify(Path(config['fixtures']))
 if not a.execute:print(json.dumps({'sourcePins':True,'canonicalAndTransitivePolicyPins':True,'policyVerifier':policy_before,'actualPortableEvaluations':0}));return
 require(a.output is not None and not a.output.exists(),'fresh actual output required');record=Path(str(a.output)+'.launch');require(not record.exists(),'fresh process record root');record.mkdir(parents=True)
 cmd=[config['node'],str(O/'compare-admission-policy.mjs'),str(a.output.resolve()),config['wasm'],config['addon'],config['fixtures'],config['package']];row={'command':cmd,'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'handoffSha256':a.handoff_sha256,'sourceBefore':source_before,'dependenciesBefore':dependencies_before,'policyVerificationBefore':policy_before,'environment':{'PYTHONDONTWRITEBYTECODE':'1'}}
 with(record/'stdout.bin').open('wb')as out,(record/'stderr.bin').open('wb')as err:
  child=subprocess.Popen(cmd,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=child.pid;(record/'launch.json').write_text(json.dumps(row,indent=2)+'\n');row['exitCode']=child.wait()
 row['integrityPassed']=False
 try:
  row['sourceAfter']=capture_snapshot(sources);row['dependenciesAfter']=capture_snapshot(config['files']);row['policyVerificationAfter']=inputs.verify(Path(config['fixtures']));row['integrityPassed']=row['sourceBefore']==row['sourceAfter']and row['dependenciesBefore']==row['dependenciesAfter']and row['policyVerificationBefore']==row['policyVerificationAfter']
 except Exception as error:row['postVerificationError']={'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
 row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha((record/'stdout.bin').read_bytes()),stderrSha256=sha((record/'stderr.bin').read_bytes()),liveHandles=[]);row['wrapperExitCode']=row['exitCode']if row['integrityPassed']else 2;(record/'terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2));return row['wrapperExitCode']
if __name__=='__main__':raise SystemExit(main())
