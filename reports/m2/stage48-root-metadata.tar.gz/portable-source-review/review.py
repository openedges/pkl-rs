from pathlib import Path,PurePosixPath
import json,hashlib,stat,re
O=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');P=S/'target/m2/stage48-policy-portable-proposal-02';h=lambda b:hashlib.sha256(b).hexdigest();inputs={}
def read(p):
 p=Path(p);assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();r={'sha256':h(b),'bytes':len(b)};assert inputs.setdefault(str(p),r)==r;return b
def obj(p):return json.loads(read(p))
def copy(p,n):
 b=read(p);q=O/'evidence'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return b
handoff=json.loads(copy(P/'handoff.json','handoff.json'));assert h(read(P/'handoff.json'))=='8ca2934bf04337c8a12a1b84c6b355ad358821a2cf4e820e1a9dcdc3a0c6af01'
closure=json.loads(copy(P/'closure.json','closure.json'));assert h(read(P/'closure.json'))=='f5995e94d3d091c48a5206e081cb8d202d17afd6b83372aea01595f3bb4a2eb2';assert closure['closed'] and not closure['liveHandles'] and closure['actualPortableEvaluations']==0
inv=json.loads(copy(P/'inventory.json','inventory.json'));assert h(read(P/'inventory.json'))==closure['inventorySha256']
for n,r in inv['files'].items():
 p=PurePosixPath(n);assert not p.is_absolute() and '..' not in p.parts;b=copy(P/n,'proposal/'+n);assert h(b)==r['sha256'] and len(b)==r['bytes']
for n,r in handoff['sourceFiles'].items():assert h(read(P/n))==r['sha256'] and len(read(P/n))==r['bytes']
checks=obj(P/'checks-01/report.json');assert h(read(P/'checks-01/report.json'))==handoff['checksReportSha256'] and checks['sourceStable'] and checks['sourceBefore']==checks['sourceAfter'] and not checks['canonicalArtifactChanges']
for c in checks['commands']:
 assert c['exitCode']==0
 # Raw file names are explicit command-group children in the sealed inventory.
 for side in ['stdout','stderr']:assert any(row['sha256']==c[side+'Sha256'] for n,row in inv['files'].items() if n.startswith('checks-01/') and n.endswith(side+'.bin'))
sourceUnmatched=[n for n,r in handoff['sourceFiles'].items()if checks['sourceBefore'].get(n)!=r['sha256']]
assert set(sourceUnmatched)<= {'README.md','PLAN.ko.md','check.py','canonical-artifacts.json','launch.py','test_launch.py','driver-source.json','driver-diff.patch','proposal01-driver-diff.patch','correction-history.json','upstream-tools.json'}
can=obj(P/'canonical-artifacts.json');assert can['candidateReleaseSha256']=='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0' and can['sourceMapSha256']=='9f546b82bd3cfba614c2c0bb1671db14f226466707f99cef3a5ceb5f6dc12a18'
for p,r in can['files'].items():b=read(p);assert h(b)==r['sha256'] and len(b)==r['bytes']
C=S/'target/m2/stage48-implementation-01/admission-candidate-build-01';m=obj(C/'source-after.json')
for n in ['resource-session.mjs','module-policy-session.mjs']:assert read(P/n)==read(C/'sources/tools/platform'/n)
fixtures=Path(can['fixtures']);manifest=obj(fixtures/'manifest.json');assert h(read(fixtures/'manifest.json'))=='6a4d5b2c8d394108c8a0ee98b33bbc5fd20525aa467da7e68e1799b8cea8ab72'
for n,r in manifest['files'].items():b=read(fixtures/n);assert h(b)==r['sha256'] and len(b)==r['bytes']
bundle=obj(fixtures/'fixtures.json');assert len(bundle['fixtures'])==12 and sum(len(f['expected'])for f in bundle['fixtures'])==84 and sum(len(f['orderedEvents'])for f in bundle['fixtures'])==280
assert bundle['javaApiStatusCounts']=={'success':80,'error':4}
for f in bundle['fixtures']:assert f['readerPlan']==[] and f['operations'][-1]!='GC' and all(all(c<128 for c in bytes.fromhex(e['utf8Hex'])) for e in f['orderedEvents'])
A=S/'target/m2/stage48-module-admission-oracle-01';docs=[read(A/(n+'.json'))for n in ['report','inventory','closure']];pins=['dcaa95e8eab8b1a7efda01d2494758d44e5045abe7c75eb79224e0079d768efc','11f1dbb9c1fc0b57761075c6ef9bf618210462f9f7ecefe32f02402cc7e41b29','40750b468c747e60b09f35ede8839983edd5400883b8731a2a2f85f3d173fcfd'];assert list(map(h,docs))==pins
report,inventory,seal=map(json.loads,docs);assert seal['sealed'] and seal['inventorySha256']==pins[1] and seal['reportSha256']==pins[0]
prefix='cases/resolve-denial-retry-catch/0/calls/session-0/denial-0'
def payload(n):
 b=read(A/n);r=inventory['files'][n];assert r['kind']=='regular' and r['sha256']==h(b) and r['bytes']==len(b);return b
assert payload(prefix+'.kind.bin')==b'module' and payload(prefix+'.context.bin')==b'pkl:json' and payload(prefix+'.message-null.bin')==b'false' and payload(prefix+'.class.bin')==b'org.pkl.core.SecurityManagerException'
u=payload(prefix+'.message.code-units.bin');b=payload(prefix+'.message.bin');assert u.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==b
cause={'profile':'actual-captured-deny-json-module-resolve-v1','kind':'security-manager-exception','uri':'pkl:json','messageNull':False,'messageUnits':[int.from_bytes(u[i:i+2],'big')for i in range(0,len(u),2)],'messageJavaUtf8Hex':b.hex()}
assert read(P/'policy-causes.mjs')==('// Exact original Java Host input; not a formatted Pkl diagnostic.\nexport const policyCauses = Object.freeze('+json.dumps(cause,indent=2)+');\n').encode()
for n in ['AdmissionProbe.java','profile.json']:assert report['inputHashes'][str(A/n)]==h(payload(n))
for p,r in inputs.items():assert h(Path(p).read_bytes())==r['sha256']
(O/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
result={'schema':1,'scope':'Read-only portable02 source/provenance review before actual evaluation; no verifier/test/browser/evaluator/build/Git execution.','handoffSha256':h(read(P/'handoff.json')),'closureSha256':h(read(P/'closure.json')),'sourceFiles':len(handoff['sourceFiles']),'sealedPayloadFiles':len(inv['files']),'recordedChecks':{'allExit0':True,'nodeProtocolTests':8,'pythonTests':7,'verifierAndSyntaxCommands':3,'actualProducerHandle':97932,'handoffPathsNotInCheckSourceMap':sourceUnmatched},'canonicalDependencyFilesVerified':len(can['files']),'fixturePayloadFiles':len(manifest['files']),'fixtureScope':{'sessions':12,'apiCalls':84,'success':80,'error':4,'originalOrderedEvents':280,'eventUtf16IndependentCapture':False},'rawCauseAuthority':{'reportInventoryClosurePins':pins,'kind':'security-manager-exception','uri':'pkl:json','fullErrorOutputReplay':False},'assessment':'No pre-execution blocker found for the exact frozen proposal02 and canonical C01 configuration.','preservedBoundaries':['All raw actual CheckImport/Resolve requests retained','Custom raw deny-json cause before explicit shared default, unknown/unsupported completion aborts','No synthetic primary/repl/factory/path/API-outcome events','Full280 original event/counter gate remains strict; raw API flag cannot override it','Existing Resource/module-policy helpers copied byte-identical to C01','HTTP served copied helper reads tracked before200;404 guard/probe and explicit browser executable bound','Launcher source/transitive authority pins and verifier recheck before/after; postcheck failures persist terminal with wrapper exit2'],'runtimePending':True,'reportConsumerQualification':'rawApiContractPassed is the raw channel sub-result; use infrastructure/browser errors, changedInputs and launcher integrityPassed together before treating a run as valid. Full strict failure remains expected even if84 raw APIs pass.','unfinishedScope':['All policy lifecycle callbacks and original8-field counter observer','212 native-unexecuted SPI controls remain separate','Whole M2/API/performance/platform completion'],'originalChanges':[],'recursiveFilesystemTraversal':False}
(O/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'sealedPayloadFiles':len(inv['files']),'fixturePayloadFiles':len(manifest['files']),'canonicalFiles':len(can['files']),'originalChanges':[]}))
