from pathlib import Path
import collections, datetime, hashlib, json, shutil

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48')
MAIN = ROOT.with_name('pkl-rs')
OUT = Path(__file__).resolve().parent
C01 = ROOT / 'target/m2/stage48-implementation-01/admission-candidate-build-01'
ORACLE = ROOT / 'target/m2/stage48-module-admission-oracle-01'
inputs = {}
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path):
    data = path.read_bytes()
    inputs[str(path)] = {'sha256': sha(data), 'bytes': len(data)}
    return data
def obj(path): return json.loads(read(path))
def save(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False); f.write('\n')

source_map = obj(C01 / 'source-after.json')
paths = [
 'references.lock', 'crates/pkl-runtime/src/modules.rs',
 'crates/pkl-runtime/src/vm/modules.rs', 'crates/pkl-runtime/src/vm/uri_resolution.rs',
 'crates/pkl-runtime/src/vm/stdlib_modules.rs', 'crates/pkl-runtime/src/vm.rs',
 'crates/pkl-runtime/src/heap.rs', 'crates/pkl-runtime/src/syntax.rs',
 'crates/pkl-runtime/src/parser.rs', 'crates/pkl-runtime/src/resolver.rs',
 'crates/pkl-runtime/src/probe.rs', 'crates/pkl-runtime/src/evaluation/session.rs',
 'crates/pkl-runtime/src/evaluation/frontend.rs', 'crates/pkl-runtime/src/host/resources.rs',
 'crates/pkl-runtime/examples/support/module_host.rs',
 'crates/pkl-runtime/tests/m2_module_admission.rs',
 'crates/pkl-napi/src/lib.rs', 'crates/pkl-wasm/src/lib.rs',
]
java = 'external/pkl/pkl-core/src/main/java/org/pkl/core/'
paths += [java + p for p in [
 'runtime/ModuleCache.java', 'runtime/ModuleResolver.java', 'runtime/VmLanguage.java',
 'runtime/VmUtils.java', 'EvaluatorImpl.java', 'ModuleSource.java',
 'module/ModuleKey.java', 'module/ModuleKeyFactory.java', 'module/ModuleKeys.java',
 'module/ResolvedModuleKey.java', 'module/ResolvedModuleKeys.java',
 'ast/expression/unary/ImportNode.java', 'ast/builder/AstBuilder.java', 'util/IoUtils.java',
]]
sources = []
for rel in paths:
    data = read(C01 / 'sources' / rel)
    assert sha(data) == source_map[rel]
    dst = OUT / 'sources' / rel
    dst.parent.mkdir(parents=True, exist_ok=True); dst.write_bytes(data)
    sources.append({'path': rel, 'sha256': sha(data), 'bytes': len(data), 'C01_bound': True})

for p in [
 MAIN / 'target/m2/stage47-stdlib-admission-plan-01/implementation-preparation.ko.md',
 MAIN / 'target/m2/stage48-admission-plan-c-review-01/REVIEW.ko.md',
 MAIN / 'target/m2/stage48-admission-source-c-review-03/report.json',
 ROOT / 'target/m2/stage48-module-admission-audit-01/intent-ledger.json',
 ROOT / 'target/m2/stage48-module-admission-audit-02/handoff.json',
 ROOT / 'target/m2/stage48-policy-native-c01-audit-01/handoff.json',
 ROOT / 'target/m2/stage48-policy-native-c01-01/report.json',
]:
    read(p)

consumer = obj(ROOT / 'target/m2/stage48-policy-native-consumer-02/inputs/inputs.json')
selected = {c['id'] for c in consumer['cases'] if not c['runnable']}
report = obj(ORACLE / 'report.json')
assert inputs[str(ORACLE / 'report.json')]['sha256'] == 'dcaa95e8eab8b1a7efda01d2494758d44e5045abe7c75eb79224e0079d768efc'
cases = obj(ORACLE / 'cases.json')
read(ORACLE / 'AdmissionProbe.java'); read(ORACLE / 'profile.json')
read(ORACLE / 'inventory.json'); read(ORACLE / 'closure.json')
controls = []
call_count = event_count = 0
for case in cases:
    if case['id'] not in selected: continue
    for rel in case['inputPaths']: read(Path(case['workspace']) / rel)
    observations = [o for o in report['observations'] if o['case'] == case['id']]
    statuses = collections.Counter()
    summaries = []
    for obs in observations:
        for call in obs['calls']:
            prefix = ORACLE / call['rawPrefix']
            expected = {
             '.status.bin': call['status'].encode(),
             '.stdout.bin': bytes.fromhex(call['stdoutUtf8Hex']),
             '.stdout.code-units.bin': bytes.fromhex(call['stdoutUtf16BEHex']),
             '.stderr.bin': bytes.fromhex(call['stderrUtf8Hex']),
             '.stderr.code-units.bin': bytes.fromhex(call['stderrUtf16BEHex']),
             '.counters-before.bin': call['countersBefore'].encode(),
             '.counters-after.bin': call['countersAfter'].encode(),
            }
            for suffix, data in expected.items(): assert read(Path(str(prefix)+suffix)) == data
            call_count += 1; statuses[call['status']] += 1
            if obs['repeat'] == 0 and call['session'] == 0:
                summaries.append({'index': call['index'], 'expression': call['expression'],
                 'status': call['status'], 'stdoutUtf8Hex': call['stdoutUtf8Hex'],
                 'stderrUtf8Sha256': sha(expected['.stderr.bin']),
                 'rawPrefix': str(prefix), 'countersBefore': call['countersBefore'],
                 'countersAfter': call['countersAfter']})
        for session in obs['sessions']:
            for e in session['events']:
                prefix = ORACLE / e['rawPrefix']
                assert read(Path(str(prefix)+'.bin')) == bytes.fromhex(e['utf8Hex'])
                assert read(Path(str(prefix)+'.code-units.bin')) == bytes.fromhex(e['utf16BEHex'])
                event_count += 1
    controls.append({'id':case['id'], 'source':str(Path(case['workspace'])/case['entry']),
     'scope':case['scope'], 'api_count':sum(statuses.values()), 'statuses':dict(statuses),
     'first_session':summaries})
assert call_count == 212
save('oracle-controls.json', {'profile':'actual Java01, no evaluation in this readback',
 'api_calls':call_count,'ordered_events':event_count,'cases':controls,
 'qualification':'Raw original status/UTF16/JavaUTF8/counters/events were joined to the pinned report. Derived first-session summaries do not replace full raw channels; unexecuted native SPI remains unexecuted.'})
save('source-snapshot.json', {'candidate':str(C01/'release.json'),'files':sources})
save('inputs.json',inputs)
for path, meta in inputs.items(): assert sha(Path(path).read_bytes()) == meta['sha256']
save('readback-report.json', {'exit_code':0,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_files':len(sources),'input_files':len(inputs),'raw_api_calls_checked':call_count,
 'raw_ordered_events_checked':event_count,'input_changes':0,'new_evaluation':False,
 'production_or_Git_changes':False})
print(json.dumps({'source_files':len(sources),'inputs':len(inputs),'apis':call_count,'events':event_count}))
