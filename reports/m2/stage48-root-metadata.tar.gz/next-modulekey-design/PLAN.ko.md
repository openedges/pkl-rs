# 일반 ModuleKey와 공개 평가 진입점의 다음 구현 계획

이 문서는 Stage48 C01 뒤의 **미구현 부분만** 다룬다. 기존 `stage47-stdlib-admission-plan-01/implementation-preparation.ko.md`와 `stage48-admission-plan-c-review-01/REVIEW.ko.md`를 대체하지 않는다. C01의 CheckImport, 성공 site cache, typed 보안 오류, singleton의 key-resolution 우회, 원본/해결 URI cache, 부분 순환 receiver 계약은 유지한다. 아래 API 이름은 설계 표기이며 구현된 API가 아니다. 생산 편집·Git·빌드·새 Java/Rust 평가 없이 C01 불변 소스와 봉인된 Java01/02를 읽었다.

## 이번에 닫아야 하는 차이

C01은 URI로 bundled 여부를 분류하고, 선택된 ModuleKey 객체·factory 호출·`isCached()` 호출을 표현하지 않는다. `SourceSession`은 제공된 primary source를 바로 컴파일하고 고정 query들을 준비한다. 이 때문에 440개의 raw API 일치와 별개로 custom SPI 212개는 미실행이며 전체 공개 lifecycle은 52개 session 모두 미완료다. symlink primary 네 session은 edge importer 자체도 Java의 resolved 파일 URI와 다르다.

다음 구현은 factory 선택과 key 해석, AST 준비와 실행, 실제 공개 평가 진입점을 분리해야 한다. callback 숫자를 맞추는 Host 캐시나 synthetic primary/repl event를 추가하는 방식으로 닫지 않는다. 기존 `import*`, package/external reader, 다른 표준 모듈 및 전체 M2 의무도 제거하지 않는다.

## 고정 Java 계약과 최소 상태

| 단계 | 고정 원문 | 다음 구현의 상태/효과 |
| --- | --- | --- |
| URI 준비 | `AstBuilder.resolveImport:3012`, `IoUtils.resolve:432` | declaration의 **original key**로 URI를 준비한다. custom `resolveUri`는 절대 URI에도 호출될 수 있다. triple-dot의 Capabilities/HasElement 순서와 오류 owner를 유지한다. |
| import 선언 AST | `AstBuilder.visitImportClause:1648` | URI 준비 직후 `SelectKey(ClausePreparation)`를 실행한다. explicit `as`가 있어도 호출한다. 없는 경우 selected key로 이름을 추론한다. 이때 runtime edge/resolve/cache lookup은 하지 않는다. |
| import 실행 | `ImportNode:50` | 성공 site hit → 반환. miss → CheckImport(resolved importer, 준비된 raw target) → **새 SelectKey(RuntimeImport)** → ModuleCache. 선언 준비의 key를 runtime 선택 대신 재사용하지 않는다. |
| key 선택 | `ModuleResolver:76` | normalize한 URI에 등록 factory를 순서대로 호출하고 첫 present에서 중단한다. no-loader/URI syntax/IOException/external-reader 오류를 phase에 맞게 전파한다. factory는 module 존재 확인/source I/O를 하지 않는다. |
| singleton/cache | `ModuleCache:81–160` | 실제 StandardLibrary key만 singleton/catalog 분류. 그 뒤 isCached 조회. true: original hit → key Resolve → resolved hit → load. false: 두 lookup을 생략하고 Resolve → load. |
| 게시/실패 | `ModuleCache:175–193` | receiver는 source 성공 전 비공개. source 성공 뒤 양 URI cache에 부분 receiver 게시, 초기화 실패/소스 실패는 양 cache에 원래 오류 게시. **uncached도 put을 수행한다.** resolved hit는 새 original alias를 seed하지 않는다. |

`SelectKey`의 결과는 URI 문자열 대신 evaluator에 소속된 `ModuleKeyId`와 descriptor다. descriptor는 key의 원본 URI, 종류(`StandardLibrary`, 일반 Host key, supplied-text wrapper, synthetic), Host opaque key handle을 구분한다. 선택한 factory의 ID/순서는 observer 자료이지 URI cache의 key가 아니다. resolved key에는 별도 `ResolvedKeyId`가 필요하다. source 요청은 그 handle을 사용하여 같은 URI의 서로 다른 custom key/resolve 결과를 혼동하지 않는다.

`isCached`를 factory completion에 미리 평가하여 넣지 않는다. singleton은 이를 호출하지 않고, 일반 key도 호출 시점이 factory 뒤다. 별도 `QueryCachePolicy { key }` / bool completion으로 해당 단계에서 실행한다. B helper의 cached 값이 factory 생성 시 snapshot되는 사실과 getter가 나중에 호출되는 사실을 둘 다 유지한다. 일반 SPI의 getter가 항상 순수·불변이라고 가정하지 않는다.

새 공통 효과의 최소 후보는 `SelectKey`, `QueryCachePolicy`, selected key를 받는 `Resolve`, resolved key를 받는 `LoadSource`다. custom declaration URI 해석을 위해 `ResolveImportUri { declaration_key, authored_uri }`도 별도 경계로 필요하다. 기본 File/stdlib의 순수 URI 해석은 공통 엔진 helper로 완료할 수 있지만 custom key override를 무시하지 않는다. capability/getter도 필요할 때만 호출하고, 묶음 completion 때문에 사용하지 않은 getter까지 앞당겨 평가하지 않는다.

StandardLibrary 판정은 `pkl:` 접두사가 아니다. Java01의 custom `pkl:base`는 일반 key이며 tag99 source를 실제로 읽는다. 기본 helper가 만든 StandardLibrary descriptor만 pinned source/catalog로 연결한다. custom provider를 먼저 호출하는 현 계약을 유지한다. 반대로 모든 custom key를 default helper가 받아 pinned stdlib로 바꾸는 동작은 금지한다. raw edge URI, factory-normalized input, factory가 반환한 key URI, resolved URI, diagnostic URI를 각각 보존한다. factory가 key URI를 바꾸는 추가 경계도 별도 검증한다.

URI cache의 동등성은 Java `URI.equals`다. string-key만 유지하거나 모든 URI를 강제로 canonicalize하지 않는다. resource cache에서 이미 검증한 URI key machinery를 재사용할 수 있으나 module/factory URI와 source spelling은 바꾸지 않는다. 아직 module-specific Unicode/scheme/authority/opaque equivalence 관찰이 부족한 부분은 명시적으로 남긴다.

## AST 준비와 frontend 변경

현재 `parser.rs::import`는 alias가 없으면 raw URI에서 member name을 확정한다. Java는 selected key의 URI/fragment-path 특성으로 추론한다(`IoUtils.inferModuleName:299`). 따라서 새 효과를 기존 compile 뒤에 붙이는 것만으로는 충분하지 않다.

`syntax.rs`에 import 선언 여부와 explicit alias를 보존하고, 암묵 이름을 placeholder로 보관한다. 전체 parse는 여전히 전역 오류 장벽이다. 그 뒤 `ModuleBuildContinuation`이 모듈 header/ordered import 선언을 순서대로 준비하고 selected-key 이름을 확정한 다음 scope/member resolution을 진행한다. `resolver.rs::AstPreparation`와 `vm/uri_resolution.rs::PreparationStep`에 clause의 SelectKey phase를 추가한다. 각 단계는 AST source/owner와 continuation 위치를 갖고, 실패하면 이후 factory/Host 효과를 실행하지 않는다. 현재 category 순서·중첩 import·generator 재방문·FailureStep interleaving을 유지한다. 단순 span 정렬이나 전체 import를 미리 선택하는 pass는 사용하지 않는다.

준비 중 받은 clause key는 이름 추론/준비 목적에 한정된다. 런타임 import는 Java처럼 다시 선택한다. query AST는 해당 API가 요청된 시점에만 준비하며, 아직 호출하지 않은 query의 factory/parse 오류가 먼저 나오면 안 된다. no-loader와 factory IOException은 현재 ModuleHostError::NotFound로 뭉개지 않고 factory 전용 오류로 표현한다. 특히 clause factory 호출은 `resolve(uri)`의 optional import node가 없고 expression runtime 호출은 `resolve(uri, this)`이므로 동일 message라도 frame/owner를 일괄 삽입하지 않는다.

qualified Ref의 C01 specialized check도 raw URI가 아니라 **실제로 강제한 imported receiver/key 종류**로 선택해야 한다. custom `pkl:ref`가 builtin Ref의 constraint/external behavior를 잘못 얻어서는 안 된다. type guard의 실제 import-site 강제·초기화 실패 cache를 유지하면서, builtin canonical receiver일 때만 specialized recipe를 쓰고 나머지는 일반 declared member/type 경로를 따른다. 단순 Ref class 이름 비교나 URI 접두사로 대체하지 않는다.

## 공개 primary/repl 진입점

`EvaluatorImpl.doEvaluate:465`는 각 API마다 ModuleSource를 normalize/선택하고 같은 evaluator ModuleCache를 사용한다. 여기에는 import-edge 검사가 없다. `ModuleSource.path/uri`는 실제 key Resolve를 수행하므로 File key는 original check → secure path/symlink 처리 → resolved check를 거친다(`ModuleKeys.File:338`). primary를 source-only로 등록한 뒤 이벤트만 붙이는 방법은 resolved importer를 고치지 못한다.

`ModuleResolver.resolve(ModuleSource):43`의 세 경우를 구분한다.

1. URI/path: factory 선택 → 실제 일반 load/cache 경로.
2. URI + supplied contents: underlying factory를 선택한 뒤 CachedModuleKey wrapper를 만든다. wrapper는 StandardLibrary가 아니며 resolve는 자체 반환, source는 supplied text, 기본 isCached=true다. 원문의 명시 override인 hierarchical/local/globbable/hasElement/listElements만 delegate에 위임한다. `hasFragmentPaths`/`resolveUri` 등 나머지를 무조건 delegate 복사하지 않고 wrapper의 inherited default를 유지한다. delegate의 resolve/security를 실행한 척하면 안 된다.
3. `repl:text` supplied text: synthetic key이며 실제 synthetic resolve 정책을 따른다. 일반 factory를 거친 것으로 기록하지 않는다.

ordinary expression API는 primary load가 끝난 뒤 매 호출 새 synthetic query key를 만들고 resolve/security → source → parse/AST → 실행 순서다(`VmUtils.evaluateExpression:933`). query key는 ModuleCache를 거치지 않는다. 따라서 query 반복을 URI cache나 기존 고정 query executable의 성공 import-site cache로 합치지 않는다. API별 `output.text/value/bytes` fast path가 다르며, 현재 지원하는 expression-string API는 `output.text`만 direct output 경로라는 차이를 유지한다.

기존 supplied-primary `SourceSession`은 개발 profile로 유지하고 새 공개 lifecycle profile/entrypoint를 공통 `evaluation/session.rs`에 명시한다. API operation별 primary 선택과 query 생성 continuation을 둔다. public constructors는 I/O 없이 configuration만 받고 poll에서 typed 효과를 낸다. 다중 ModuleSource를 같은 evaluator로 평가하는 수명과 fixed-query 개발 API를 혼동하지 않는다. 기본 bootstrap/base 초기화는 implicit 사용이지 import edge가 아니며 새 가짜 CheckImport를 만들지 않는다.

## 파일별 작업 및 전달 계약

| 파일/영역 | 변경 |
| --- | --- |
| `src/modules.rs` | key/resolved-key identity, factory/cache-policy/URI-preparation typed 요청·완료·phase별 오류. default completion은 명시 profile + custom-first 우선순위 유지. |
| `src/vm/modules.rs`, `vm.rs`, `heap.rs` | ModuleRun에 선택 key/phase 저장, true/false cache 전이, 원본/해결 cache 키 동등성, 부분 receiver·오류·site cache의 독립 소유권. |
| `src/syntax.rs`, `parser.rs`, `resolver.rs`, `src/vm/uri_resolution.rs` | clause/alias metadata와 멈춤 가능한 ModuleBuildContinuation; 정확한 이름/진단/준비 순서. |
| `src/vm/stdlib_modules.rs`와 type guard 경로 | 실제 StandardLibrary descriptor와 canonical receiver에 의한 stdlib/Ref 선택. custom pkl key에는 일반 source 경로. |
| `src/evaluation/session.rs`, `frontend.rs`, `probe.rs` | 공개 ModuleSource lifecycle와 supplied-source profile 분리. typed request/token routing 및 primary/query source identity. |
| NAPI/Wasm, native File/classpath Host, root 소유 JS providers | 같은 descriptor/opaque handle/typed failure를 운반. default helper false는 token 미소비, 명시 provider denial 우선. JS trust/cache/eager source preload 금지. |

Host factory registry와 opaque key table은 Host I/O 어댑터가 소유하되 semantic site/URI cache는 엔진에만 둔다. factory를 선택하기 위해 module source 파일을 읽지 않는다. B의 고정 module-plan은 사전 구성 자료이며 production factory I/O 허용 근거가 아니다. protocol의 `SelectKey` 요청 한 개와 registry 안에서 실제 호출된 N개의 factory를 구분하여 기록한다. Java observer의 implementation-class labels를 Rust에서 실행한 관찰처럼 합성하지 않는다. full trace/counter gate는 새 구현/관찰 계약으로 실제 확인될 때까지 실패·미실행 상태를 유지한다.

## GC·중단·오류의 보존 조건

key handle은 evaluator epoch/generation에 묶고 pending request/ModuleUnit/모듈 metadata만 필요한 수명 동안 보유한다. 이름 추론이 끝난 임시 clause key를 불필요하게 영구 보관하지 않는다. source/receiver를 opaque handle table에 넣어 user graph를 살리지 않는다. query AST/일회 key는 완료/취소 후 회수하고, 살아 있는 closure·ModuleInfo·진단이 요구하는 executable/source만 보존한다. factory의 `close()` 수명은 key 폐기와 별개다.

각 새 phase에서 wrong completion·wrong key/epoch·stale token은 state/token을 소비하지 않는다. 실제 valid Host failure만 해당 continuation을 종료한다. typed security는 허용된 edge/key resolve/HasElement에서 guest provenance를 유지한다. factory URISyntax/IOException/ExternalReaderProcess와 Source 오류를 raw Host rejection/terminal cancellation으로 잘못 바꾸지 않는다. timeout/close/cancel/재진입·late completion 및 남은 request cleanup을 native/Node/Wasm 동일 경로에서 검증한다. 기존 stack·heap·poll 한도는 유지한다.

uncached load의 receiver와 cached key의 이전 receiver가 동시에 살아 있을 수 있다. 새 uncached source/초기화 실패가 양 URI cache를 덮어도 이미 성공한 site가 잡은 이전 receiver/부분 receiver는 독립적으로 남는다. 반대로 실패한 site에는 값을 게시하지 않는다. alias resolved hit의 original non-seeding, source 실패 전 receiver 비공개, 실패 replay의 원래 frame 누적 계약도 유지한다.

## 기존 실제 관찰과 새로 필요한 관찰

`oracle-controls.json`은 Java01 report `dcaa95e8…`의 아래 212개 API와 ordered events를 원본 파일에 직접 재결합한다. C01 native 미실행 상태는 바꾸지 않는다. Java02의 교정된 cycle/catch는 유지 회귀에 재사용하며, Java01의 lazy-cycle 36건과 query alias lookup 16건을 의도한 경계 통과로 바꾸지 않는다.

| Java01 case | API | 사용 가능한 종료 기준 |
| --- | ---: | --- |
| `custom-resolved-importer` | 24 | custom key의 resolved importer가 edge 신뢰도 기준이며 raw API/이벤트 동일 |
| `resolved-cache-alias-no-original-seed` | 32 | 같은 resolved URI의 새 alias site마다 Resolve, source 재사용, original alias 미게시 |
| `uncached-policy-toggle` | 32 | factory별 cached snapshot, true/false getter 시점, false lookup 우회 + write 유지, site hit 독립 |
| `clause-unused-no-loader` / `expr-unused-no-loader` | 16 / 24 | unused clause는 준비 실패, unused expression은 lazy; 최초 오류/캐시 반복 원문 유지 |
| `clause-unused-factory-throw` / `expr-unused-factory-throw` | 16 / 24 | factory IOException의 준비/실행 phase, raw owner/frame/오류 retry |
| `custom-key-pkl-uri-not-stdlib-kind` | 20 | custom pkl:base 일반 key tag99, singleton 오분류 없음 |
| `resolved-nested-jar-default-trust` | 24 | 실제 custom resolved jar importer의 trust, source/edge 순서 |

이미 있는 정책84와 Java01/02에는 path primary·매 호출 query·File symlink·denial/retry·성공 site/closure 공유·부분 cycle 자료가 있다. 이 자료를 새 public lifecycle 소비기로 다시 비교한다. 현재 440 API pass는 보존하되 전체6300 observer events/counters가 저절로 닫힌다고 세지 않는다. source-derived 구조와 실제 oracle 차이를 계속 구분한다.

다음 경계는 새 실제 Java 관찰이 필요하다. 착수 후 B와 최소 입력을 확정한다.

- factory 반환 key URI가 요청 URI와 다를 때, alias 없는 import 이름/fragment-path/getter 순서와 명시 alias 대조; custom pkl:ref의 qualified type 분기.
- factory 없음/IOException을 앞뒤 AST static 오류·annotation·parent/triple search와 섞은 최초 오류, 그리고 URISyntax/ExternalReaderProcess의 원래 진단.
- isCached=false source/초기화 실패 후 cached key 조회, 이전 성공 site 유지, uncached 순환의 정확한 실패/수명; 현재 toggle32는 성공 load 중심이다.
- 실제 ModuleSource URI+contents/CachedModuleKey, repl:text supplied text, 같은 URI의 다른 contents, primary/query 정책 denial 순서, output fast paths. 기존 path-only oracle로 이 profile을 대신하지 않는다.
- custom resolveUri override(absolute 포함), URI.equals 경계, 순서 있는 factory close/취소/재진입 실패. ModuleKey getter/ResolvedKey identity와 각 플랫폼의 Host handle 해제도 의미 있는 회귀가 필요하다.

## 가장 작은 일관된 구현 순서

1. 새 worktree에서 typed key/factory/cache-policy 상태를 공통 엔진과 모든 바인딩에 함께 추가한다. 기존 C01 supplied-source profile을 명시적으로 유지하고, custom pkl key·alias·toggle·resolved importer의 기존132개 API(24+32+32+20+24)를 먼저 raw 비교한다. URI/Host 캐시로 재현하지 않는다.
2. AST clause/name 준비를 continuation으로 연결하고 남은80개 clause/expression factory API를 비교한다. factory phase 진단과 static-error interleaving 대조군도 닫는다. 212개 raw pass만으로 primary lifecycle 완료를 선언하지 않는다.
3. 공개 ModuleSource + operation 진입점을 연결한다. primary resolved identity와 synthetic query 단계, callback ownership을 실제로 실행하고 policy84 및 Java01/02 전체 ledger를 재대조한다. supplied-source profile 결과와 별도로 보고한다.
4. 새 phase별 GC/close/cancel/reentry/typed failure, 기존 Ref/partial cycle와 native File/classpath, 실제 Node/browser를 확인한다. required Rust5, fresh `m1_platforms.py`, 원본 selected regression과 strict full gate의 남은 실패를 각각 기록한다.

1–3은 하나의 공통 ModuleKey 모델을 완성하는 순서다. 중간 checkpoint는 허용하되 이전 성공을 새 전체 호환으로 확대하지 않는다. root가 범위를 결정하고 새 worktree/소유권을 알린 뒤 구현한다. 현재 C01 생산 소스·artifact와 이번 게시 증거는 변경하지 않는다.
