from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,stat
O=Path(__file__).resolve().parent;P=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-root-publication-proposal-01');h=lambda b:hashlib.sha256(b).hexdigest();inputs={}
def read(p):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode);b=p.read_bytes();r={'sha256':h(b),'bytes':len(b),'mode':stat.S_IMODE(s.st_mode)};assert inputs.setdefault(str(p),r)==r;return b
def obj(p):return json.loads(read(p))
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
r=obj(P/'report.json');assert h(read(P/'report.json'))=='76bba1b92a319e88eb624e41d71b8a1b873d5847a75dcc80cc69e301d5b7c5ee';assert r['complete'] and r['originalChanges']==[]
s=obj(P/'selection.json');assert h(read(P/'selection.json'))==r['selectionSha256']=='c52ba8a5ab713344baccacb5f6c291678e819842eccbec617e070d83ac62bb41'
outer=obj(P/'outer-terminal.json');assert outer['sessionId']==66228 and outer['exitCode']==0;read(P/'pack.py')
assert len(s['files'])==r['sourceFiles']==28490 and len(s['commands'])==6 and all(c['exitCode']==0 for c in s['commands'])
selected={(f['group'],f['path']):f for f in s['files']};assert len(selected)==len(s['files'])
archives=[];readback=[]
for a in r['archives']:
 p=Path(a['path']);assert h(read(p))==a['sha256'] and p.stat().st_size==a['bytes']<100*1024*1024
 group=p.name.removeprefix('stage48-').removesuffix('-captures.tar.gz');expected_rows={f['path']:f for f in s['files']if f['group']==group};assert len(expected_rows)==a['files']
 with tarfile.open(p,'r:gz')as t:
  members=t.getmembers();names=[m.name for m in members];assert len(names)==len(set(names))
  assert all(m.isfile()and m.mode==0o644 for m in members)
  for n in names:q=PurePosixPath(n);assert not q.is_absolute() and '..'not in q.parts
  ev=json.loads(t.extractfile('EVIDENCE.json').read());erows={f['path']:f for f in ev['files']};assert set(erows)==set(expected_rows)==set(names)-{'EVIDENCE.json'}
  for n,f in erows.items():
   b=t.extractfile(n).read();source=expected_rows[n];assert len(b)==f['bytes']==source['bytes'] and h(b)==f['sha256']==source['sha256'];original=read(source['original']);assert original==b and stat.S_IMODE(Path(source['original']).lstat().st_mode)==source['mode']
   readback.append({'group':group,'path':n,'original':source['original'],'sha256':h(b),'bytes':len(b),'actualMode':source['mode'],'tarMode':0o644})
 archives.append({'path':str(p),'sha256':a['sha256'],'bytes':a['bytes'],'payloadFiles':len(erows)})
 for action in ['create','verify']:read(P/(group+'-'+action+'.stdout.bin'));assert read(P/(group+'-'+action+'.stderr.bin'))==b''
# Bind archive payloads to already closed independent raw audits, not a second evaluation.
C=O.parent/'stage48-c01-platform-c-audit-02';T=O.parent/'stage48-c01-bootstrap-typed-c-audit-02'
cr=obj(C/'final-report.json');assert h(read(C/'final-report.json'))=='63fab52713395ef76c6a3850287d5863d65b7c2e2ae780f8f747d271344ec80d'
tr=obj(T/'typed-bootstrap-report.json');assert h(read(T/'typed-bootstrap-report.json'))=='16f1c86e4c666c2ce9be846877c71fce6b0d9cbab7a102804c7113b9fbe01c8b'
ci=obj(C/'inputs-before.json');ti=obj(T/'typed-bootstrap-inputs.json');joined=0
for f in s['files']:
 original=f['original']
 if original in ci:assert ci[original]['sha256']==f['sha256'];joined+=1
 if original in ti:assert ti[original]['sha256']==f['sha256']
helper=next(f for f in s['files']if f['path']=='typed-provider-sources/tools/platform/bootstrap-session.mjs');assert helper['sha256']=='ad5555374d13755e9904d0b05f6e1808463087acda868a27d74f850358e835f0'
test=next(f for f in s['files']if f['path']=='typed-provider-sources/tools/platform/module-policy-session.test.mjs');assert test['sha256']=='b8b1d402214f197556cedf8cc6c273ac7ffab12017289d605d383f302fe9604d'
for p,v in inputs.items():assert h(Path(p).read_bytes())==v['sha256']
save('inputs.json',inputs);save('archive-original-readback.json',readback)
for n in ['report.json','selection.json','outer-terminal.json','pack.py']:(O/('reviewed-'+n)).write_bytes(read(P/n))
save('report.json',{'schema':1,'scope':'Read-only root3 archive integrity and previously reviewed raw outcome binding; no evaluator/build/runtime/oracle/Git reruns.','producerReportSha256':h(read(P/'report.json')),'selectionSha256':r['selectionSha256'],'actualProducerTerminal':outer,'archives':archives,'payloadFiles':len(readback),'alreadyAuditedInputJoins':joined,'allOriginalModeAndContentMatches':True,'tarHeaderMode':0o644,'modeRecoveryMetadata':'Publish selection.json alongside archives/report; actual modes and original paths are external selection fields.','typedSourceFollowupCopiesVerified':True,'historicalQualifications':'Historical early unit versions remain hash-only; current C01 source fully bound separately. Original strict mismatches and original/typed bootstrap source profiles are not relabeled.','materialPublicationIssue':False,'publicationCondition':'Keep selection.json pinned by producer report for path/mode restoration. No archive regeneration required.','originalChanges':[],'recursiveFilesystemTraversal':False})
print(json.dumps({'archives':len(archives),'payloadFiles':len(readback),'auditJoins':joined,'originalChanges':[]}))
