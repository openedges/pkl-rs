from pathlib import Path
import collections, datetime, hashlib, json, re

ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48')
OUT=Path(__file__).resolve().parent
RUN=ROOT/'target/m2/stage48-policy-portable-c01-01'
LAUNCH=RUN.with_name(RUN.name+'.launch')
PROPOSAL=ROOT/'target/m2/stage48-policy-portable-proposal-02'
FIXTURE=ROOT/'tests/fixtures/m2-module-admission-policy'
inputs={};checks=0
def digest(data):return hashlib.sha256(data).hexdigest()
def read(p):
 data=p.read_bytes();meta={'sha256':digest(data),'bytes':len(data)}
 if str(p) in inputs:assert inputs[str(p)]==meta
 inputs[str(p)]=meta;return data
def obj(p):return json.loads(read(p))
def need(v,msg):
 global checks
 checks+=1
 if not v:raise AssertionError(msg)
def put(n,v):
 with (OUT/n).open('x')as f:json.dump(v,f,indent=2);f.write('\n')
def unitbytes(units):
 need(all(type(u)is int and 0<=u<=65535 for u in units),'valid UTF16')
 return b''.join(u.to_bytes(2,'big')for u in units)
def java_utf8(units):
 # Independently implement Java's UTF8 encoder replacement; do not use JS helper.
 chars=[];i=0
 while i<len(units):
  u=units[i];i+=1
  if 0xD800<=u<=0xDBFF and i<len(units)and 0xDC00<=units[i]<=0xDFFF:
   chars.append(chr(0x10000+((u-0xD800)<<10)+units[i]-0xDC00));i+=1
  elif 0xD800<=u<=0xDFFF:chars.append('?')
  else:chars.append(chr(u))
 return ''.join(chars).encode('utf-8')
def verify_files(root,rows):
 for rel,meta in rows.items():
  data=read(root/rel);need(digest(data)==meta['sha256']and len(data)==meta['bytes'],'pinned payload '+rel)

manifest=obj(FIXTURE/'manifest.json')
need(inputs[str(FIXTURE/'manifest.json')]['sha256']=='6a4d5b2c8d394108c8a0ee98b33bbc5fd20525aa467da7e68e1799b8cea8ab72','original fixture pin')
verify_files(FIXTURE,manifest['files'])
bundle=obj(FIXTURE/'fixtures.json');fixtures=bundle['fixtures']
need(read(RUN/'fixtures.json')==read(FIXTURE/'fixtures.json'),'actual fixture exact bytes')
need(len(fixtures)==12 and sum(len(f['expected'])for f in fixtures)==84,'complete fixture denominator')
authority=FIXTURE/'provenance/stage47-renderer-api-oracle-06'
java_report=obj(authority/'report.json')
need(inputs[str(authority/'report.json')]['sha256']=='cba85cf833baeb7655f6a6cdc81fd9ee39fe0ee43f441e43d891a47c0089ebf8','original Java report pin')
calls={(o['case'],o['repeat'],c['session'],int(c['prefix'].split('-')[1])):c for o in java_report['observations']for c in o['calls']}
java_events=0
for f in fixtures:
 for index,e in enumerate(f['expected']):
  c=calls[(f['id'],f['repeat'],f['session'],index)];prefix=authority/c['rawPrefix']
  need(read(Path(str(prefix)+'.status.bin'))==(e['status']+'\n').encode()==c['status'].encode(),'original status')
  need(read(Path(str(prefix)+'.expression.bin'))==f['expressions'][index].encode(),'original expression')
  for ch in ['stdout','stderr']:
   need(read(Path(str(prefix)+f'.{ch}.bin'))==bytes.fromhex(e[ch+'Hex'])==java_utf8(e[ch+'Units']),'original JavaUTF8')
   need(read(Path(str(prefix)+f'.{ch}.code-units.bin'))==unitbytes(e[ch+'Units']),'original UTF16')
  for phase in ['before','after']:
   need(read(Path(str(prefix)+f'.counters-{phase}.bin'))==bytes.fromhex(e['counterBytes'+phase.title()+'Hex']),'original counter raw')
 for event in f['orderedEvents']:
  path=authority/f"cases/{f['id']}/{f['repeat']}/calls/session-{f['session']}/event-{event['index']}.bin"
  need(read(path)==bytes.fromhex(event['utf8Hex']),'original event bytes');java_events+=1
need(java_events==280,'full original event denominator')

handoff=obj(PROPOSAL/'handoff.json');closure=obj(PROPOSAL/'closure.json');inventory=obj(PROPOSAL/'inventory.json')
need(closure['handoffSha256']==digest(read(PROPOSAL/'handoff.json'))=='8ca2934bf04337c8a12a1b84c6b355ad358821a2cf4e820e1a9dcdc3a0c6af01','proposal seal')
need(closure['inventorySha256']==digest(read(PROPOSAL/'inventory.json')),'proposal inventory pin')
verify_files(PROPOSAL,inventory['files'])
for name in ['admission-policy-session.mjs','resource-session.mjs','module-policy-session.mjs','policy-causes.mjs','compare-admission-policy.mjs']:
 need(read(RUN/name)==read(PROPOSAL/name),'executed helper source '+name)
cause_text=read(RUN/'policy-causes.mjs').decode();cause=json.loads(cause_text.split('Object.freeze(',1)[1].rsplit(');',1)[0])
cause_root=ROOT/'target/m2/stage48-module-admission-oracle-01'
cause_prefix=cause_root/'cases/resolve-denial-retry-catch/0/calls/session-0/denial-0'
for suffix,value in [('kind',b'module'),('context',b'pkl:json'),('class',b'org.pkl.core.SecurityManagerException'),('message-null',b'false')]:
 need(read(Path(str(cause_prefix)+'.'+suffix+'.bin'))==value,'actual typed cause '+suffix)
need(read(Path(str(cause_prefix)+'.message.bin'))==bytes.fromhex(cause['messageJavaUtf8Hex'])==java_utf8(cause['messageUnits']),'raw cause UTF8')
need(read(Path(str(cause_prefix)+'.message.code-units.bin'))==unitbytes(cause['messageUnits']),'raw cause UTF16')

launch=obj(LAUNCH/'launch.json');terminal=obj(LAUNCH/'terminal.json');execution=obj(RUN/'execution.json')
need(terminal['exitCode']==terminal['wrapperExitCode']==1 and terminal['integrityPassed'] is True,'actual strict failure/integrity distinction')
need(terminal['pid']==launch['pid'] and terminal['command']==launch['command'],'actual process identity')
need(terminal['liveHandles']==[],'closed launcher')
for phase in ['source','dependencies']:
 need(terminal[phase+'Before']==terminal[phase+'After'],'recorded stable '+phase)
 for path,meta in terminal[phase+'After'].items():
  data=read(Path(path));need(digest(data)==meta['sha256']and len(data)==meta['bytes'],'actual '+phase+' input '+path)
need(terminal['policyVerificationBefore']==terminal['policyVerificationAfter'],'policy input verification stable')
for ch in ['stdout','stderr']:need(digest(read(LAUNCH/(ch+'.bin')))==terminal[ch+'Sha256'],'actual process '+ch)
need(not execution['infrastructureErrors']and not execution['browserErrors']and not execution['changedInputs'],'no acquisition failure')
need(execution['browserLaunchOptions']['executablePath']==execution['browserExecutable'],'explicit actual browser path')
need(execution['playwrightPin']=='1.64.1','pin')

targets={};rows_by_target={}
for target in ['node','browser']:
 rows=obj(RUN/(target+'.raw.json'));rows_by_target[target]=rows
 need(len(rows)==12,'twelve actual sessions '+target)
 counts=collections.Counter();request_counts=collections.Counter();session_results=[]
 for session_index,(f,a)in enumerate(zip(fixtures,rows)):
  directory=RUN/target/str(session_index)
  need(obj(directory/'actual.json')==a,'actual raw/session equality')
  need(obj(directory/'expected.json')==f['expected'],'session expected source')
  comparison=obj(directory/'comparison.json')
  need((a['id'],a['repeat'],a['session'])==(f['id'],f['repeat'],f['session']),'session identity/order')
  need(a['constructorError']is None and a['acquisitionError']is None and len(a['calls'])==7,'all actual completions')
  need(a['readerUris']==[],'no reader effects')
  for index,(c,e)in enumerate(zip(a['calls'],f['expected'])):
   need(c['index']==index and c['expression']==f['expressions'][index],'call identity/order')
   need(c['status']==e['status'],'actual status');counts[c['status']]+=1
   for ch in ['stdout','stderr']:
    need(c[ch+'Units']==e[ch+'Units'],'all actual UTF16 '+ch)
    need(read(directory/f'{index}.{ch}.utf16be.bin')==unitbytes(e[ch+'Units']),'actual UTF16 file '+ch)
    need(read(directory/f'{index}.{ch}.java-utf8.bin')==java_utf8(c[ch+'Units'])==bytes.fromhex(e[ch+'Hex']),'all actual JavaUTF8 '+ch)
   need(c['readsBefore']==c['readsAfter']==e['readsBefore']==e['readsAfter']==0,'read counts')
   need(c['status']=='success'or c['disposition']=='language-error','typed denial ordinary error')
  requests=a['moduleRequests'];need(len(requests)==5,'exact five request sequence')
  observed_events=[];tokens=[]
  expected_requests=[(1,'check-import','pkl:json'),(1,'resolve','pkl:json'),(2,'check-import','pkl:base'),(3,'check-import','pkl:ref'),(4,'check-import','pkl:test')]
  for row,(index,kind,uri) in zip(requests,expected_requests):
   m=row['module'];tokens.append(row['token']);request_counts[kind]+=1
   need(row['callIndex']==index and m['kind']==kind and m['importUri']==m['originalUri']==uri,'exact typed sequence')
   need(m['importerOriginalUri']==m['importerResolvedUri']==f['uri'],'actual supplied-primary context')
   if kind=='resolve'and f['policyProfile']['mode']=='deny-json':
    need(row['completion']=={'kind':'security-manager-exception','messageUnits':cause['messageUnits'],'messageNull':False},'actual captured typed denial');request_counts['typed-denial']+=1
   else:need(row['completion']=={'kind':'explicit-shared-default','handled':True},'explicit default completion')
   observed_events.append(f"policy-import {f['uri']} -> {uri}"if kind=='check-import'else f'policy-resolve-module {uri}')
  need(len(set(tokens))==5,'distinct actual request tokens')
  observed_events.append('native-explicit-collect')
  need(a['nativePolicyEvents']==observed_events,'actual events derived only from actual typed requests and explicit GC')
  need(a['nativePolicyEventUtf8Hex']==[x.encode().hex()for x in observed_events],'actual event encoding')
  full_events=[bytes.fromhex(x['utf8Hex'])for x in f['orderedEvents']]
  event_equal=[x.encode()for x in observed_events]==full_events
  counter_equal=True
  for index,e in enumerate(f['expected']):
   prior=[r for r in requests if r['callIndex']<index];after=[r for r in requests if r['callIndex']<=index]
   for phase,rs in [('Before',prior),('After',after)]:
    gc=int(index>=5);counts_here=collections.Counter(r['module']['kind']for r in rs)
    expected_native=f"requests={len(rs)}\nimport={counts_here['check-import']}\nresolve={counts_here['resolve']}\nevent={len(rs)+gc}\n".encode()
    need(bytes.fromhex(a['nativeCounters'+phase+'Hex'][index])==expected_native,'actual counters recomputed from typed sequence')
    counter_equal &= expected_native==bytes.fromhex(e['counterBytes'+phase+'Hex'])
  need(not event_equal and not counter_equal,'full lifecycle still fails')
  need(comparison['fullEventBytesEqual']==event_equal and comparison['fullCounterBytesEqual']==counter_equal and not comparison['fullLifecyclePassed']and not comparison['passed'],'strict failure not relabeled')
  arch=a['architecture']
  need(arch['terminalSlots']==0 and arch['consumedReaderPlan']is True and arch['ownedResultsStable']is True,'actual cleanup/ownership measurements')
  need(arch['pendingPolicyCollections']==6 and arch['collections']>=8,'pending and explicit collection observations')
  session_results.append({'identity':[a['id'],a['repeat'],a['session']],'raw_calls':7,'requests':5,'java_events':len(full_events),'native_events':len(observed_events),'full_events_equal':event_equal,'full_counters_equal':counter_equal,'architecture':arch})
 need(counts=={'success':80,'error':4},'actual 84 status totals')
 targets[target]={'sessions':session_results,'raw_API_calls':sum(counts.values()),'status_counts':dict(counts),'typed_requests':dict(request_counts),'full_lifecycle_passed_sessions':0,'original_Java_events':sum(s['java_events']for s in session_results),'actual_native_events':sum(s['native_events']for s in session_results)}
need(rows_by_target['node']==rows_by_target['browser'],'all raw structured Node/Chromium results identical')
need(execution['rawApiContractPassed']is True and not execution['fullLifecyclePassed']and not execution['selectedContractPassed']and not execution['fullCompatibilityPassed'],'report retains boundary')
for path,meta in inputs.items():need(digest(Path(path).read_bytes())==meta['sha256'],'input stable '+path)
put('inputs.json',inputs)
put('report.json',{'scope':'Independent compact actual policy84 raw/typed/lifecycle readback; no evaluation or whole C01 source audit.', 'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':0,'checks':checks,'input_files':len(inputs),'targets':targets,'launcher':{'pid':terminal['pid'],'actual_exit_code':terminal['exitCode'],'wrapper_exit_code':terminal['wrapperExitCode'],'integrity_passed':terminal['integrityPassed']},'new_evaluations':0,'input_changes':0,'findings':[],'qualifications':['Full original280 Java event/counter gate fails for all12 sessions per target; 84 raw API matches do not close it.','Java original policy84 event payloads are UTF8-only; independent UTF16 exists for API outputs/errors and fresh actual denial cause.','Native API JavaUTF8 files are independently recomputed from actual UTF16 arrays; same original Java dual-channel expected files are used.','OwnedResultsStable is the actual helper post-free retained-view equality observation, not an offline replay of live views. Helper source calls close→collect→heapSlots→free→retained-view comparison; all7 completions/session and original payload files were checked. GC counts report explicit collect calls; no claim about Java System.gc actually collecting.','Public callback reentry/cancel/timeout and actual primary/repl/factory lifecycle are not exercised by this84 profile; no completion claim.','Full 53236-source audit and archive provenance are separately owned; this audit binds exact proposal02 helpers, actual launch, artifacts/dependencies and permanent fixture bytes only.']})
print(json.dumps({'checks':checks,'input_files':len(inputs),'targets':{k:{'API':v['raw_API_calls'],'typed_requests':v['typed_requests'],'full_lifecycle_passed_sessions':0}for k,v in targets.items()}}))
