"""Additional source-bound callback projection; never a replacement for full raw gate."""
from pathlib import Path
import hashlib,json,re,collections
O=Path(__file__).resolve().parent;B=O.parent;G=B/'stage49-oracle-spi-fixtures-01';N=B/'stage49-oracle-native-public212-build02-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(G/'manifest.json')=='ebd3591361efc0a03e98e38695b120e9c625d9c09d0438fc641de420114aab97'
assert sha(N/'report.json')=='c0e1b4d5b7e7edaf2783df54b44ab1a8ea3eef6afdb155cc373be027ac081b60'
bundle=json.loads((G/'fixtures.json').read_bytes());report=json.loads((N/'report.json').read_bytes());fixtures={f"{f['cohort']}/{f['id']}/{f['repeat']}/{f['session']}":f for f in bundle['fixtures']}
rows=[]
for record in report['records']:
    key=record['process']['key'];f=fixtures[key];raw=N/key/'raw/session-0';java=[];native=[]
    for api,e in enumerate(f['expected']):
        start=e['countersBefore']['event'];end=e['countersAfter']['event']
        for event in f['orderedEvents'][start:end]:
            text=bytes.fromhex(event['utf8Hex']).decode()
            if text.startswith('factory-custom '):java.append([api,'factory-call',text[len('factory-custom '):]])
            elif text.startswith('policy-import '):java.append([api,'import-check',text[len('policy-import '):]])
            elif text.startswith('key-is-cached '):
                uri,value=text[len('key-is-cached '):].rsplit(' ',1);java.append([api,'custom-cache-policy',uri,value])
            elif text.startswith('key-resolve '):java.append([api,'custom-resolve',text[len('key-resolve '):]])
            elif text.startswith('load-source '):
                pair=text[len('load-source '):].rsplit(' load=',1)[0];java.append([api,'custom-source',pair])
    i=0
    while(raw/f'module-{i}.request.bin').is_file():
        prefix=raw/f'module-{i}';text=lambda name:prefix.with_name(prefix.name+'.'+name+'.bin').read_text();request=text('request');api=int(text('api-index'));completion=text('completion')
        if request.startswith('SelectKey '):native.append([api,'factory-call',re.search(r'uri: "([^"]*)"',request)[1]])
        elif request.startswith('CheckImport '):
            original,resolved,target=re.findall(r'"([^"]*)"',request);native.append([api,'import-check',resolved+' -> '+target])
        elif request.startswith('QueryCachePolicy ')and'handle: "custom-key-'in request:
            native.append([api,'custom-cache-policy',re.search(r'uri: "([^"]*)"',request)[1],re.search(r'CachePolicy\(Ok\((true|false)\)\)',completion)[1]])
        elif request.startswith(('Resolve {','ResolveKey {'))and'handle: "custom-key-'in request:
            native.append([api,'custom-resolve',re.search(r'uri: "([^"]*)"',request)[1]])
        elif request.startswith('LoadSource ')and'handle: "custom-resolved-'in request:
            original,remainder=request.split('module: ResolvedModule {',1);uris=re.findall(r'(?:original_uri|resolved_uri|source_uri): "([^"]*)"',remainder);native.append([api,'custom-source',uris[0]+' -> '+uris[1]])
        i+=1
    rows.append({'key':key,'orderedProjectionEqual':java==native,'java':java,'native':native,'javaCounts':dict(collections.Counter(e[1]for e in java)),'nativeCounts':dict(collections.Counter(e[1]for e in native))})
out={'schema':1,'kind':'Read-only diagnostic projection of actual old Java observer and actual native typed request/Host completion records; no new evaluation','nativeReportSha256':sha(N/'report.json'),'fixtureManifestSha256':sha(G/'manifest.json'),'sessions':rows,'projectedPassSessions':sum(r['orderedProjectionEqual']for r in rows),'projectedMismatchSessions':sum(not r['orderedProjectionEqual']for r in rows),'fullOriginalByteGatePassed':False,'qualification':['Projection extracts exact URI/boolean arguments and preserves their order and per-API association; no URI/string normalization.','It does not include private/default registry iteration/class labels, secure-path, actual resolve security callbacks, API outcome/GC labels or other unmatched observer effects.','No projected match is a full event/counter pass; original full gate remains0/36.'],'runtimeRelevantDivergencesInSelectedProjection':[r['key']for r in rows if not r['orderedProjectionEqual']]}
(O/'report.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'projectedPass':out['projectedPassSessions'],'projectedMismatch':out['projectedMismatchSessions'],'reportSha256':sha(O/'report.json')}))
