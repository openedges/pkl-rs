from pathlib import Path
import collections,datetime,hashlib,json,tarfile
R=Path('/Users/cody.ij.hwang/Projects/pkl-rs');O=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
findings=[];checks=0
def check(value,label,detail=None):
 global checks
 checks+=1
 if not value:findings.append({'check':label,'detail':detail})
summary_path=R/'reports/m2/stage46-final-summary.json';summary=json.loads(summary_path.read_bytes())
rawindex=json.loads((R/summary['captures']['path']).read_bytes());closeindex=json.loads((R/summary['publication_closeout']['path']).read_bytes())
inputs=[summary_path,R/'README.md',R/'PLAN.md',R/'reports/m2/README.md',R/'target/m2/stage46-final-publication-01/handoff.json',R/summary['captures']['path'],R/summary['publication_closeout']['path']]
for key in ['audit','source_map','case_changes','status_changes_record','raw_changes']:
 p=R/summary[key]['path'];inputs.append(p);check(sha(p)==summary[key]['sha256'],'summary pointer '+key)
check(sha(summary_path)=='24accd33866c86efb0605fb81454df1fcdb863dc65c32ac49b76a18cc3d13fd0','summary identity')
check(sha(inputs[4])=='73a2dbc58324280c3a1da262abf60ce8921fc42b23b81de5aabb8943cf537fda','handoff identity')
archive_rows=rawindex['archives']+[closeindex['archive']];data={};archive_stats=[]
for row in archive_rows:
 p=R/row['path'];inputs.append(p);check(sha(p)==row['sha256']and p.stat().st_size==row['compressed_bytes'],'archive identity '+p.name)
 with tarfile.open(p,'r:gz')as tar:
  members=tar.getmembers();check(len(members)==len({m.name for m in members}),'unique members '+p.name)
  check(all(m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts for m in members),'safe regular members '+p.name)
  contents={m.name:tar.extractfile(m).read()for m in members};inventory=json.loads(contents.pop('EVIDENCE.json'));rows=inventory['files']
  check(set(contents)=={r['path']for r in rows}and len(rows)==len(contents)==row['payload_files'],'exact payload count '+p.name)
  check(sum(len(v)for v in contents.values())==row['payload_bytes'],'payload byte count '+p.name)
  for r in rows:check(len(contents[r['path']])==r['bytes']and hashlib.sha256(contents[r['path']]).hexdigest()==r['sha256'],'archive member '+r['path'])
  for name,raw in contents.items():
   check(name not in data,'cross archive unique member '+name)
   data[name]=raw
  archive_stats.append({'path':row['path'],'sha256':sha(p),'compressedBytes':p.stat().st_size,'payloads':len(rows)})
 print(json.dumps({'archiveVerified':p.name,'payloads':len(rows)}),flush=True)
before={str(p):sha(p)for p in inputs}
check(sum(r['compressed_bytes']for r in archive_rows)==47864464,'four archive compressed total')
check(sum(r['payload_files']for r in rawindex['archives'])==62169 and closeindex['archive']['payload_files']==35,'three regression plus closeout payload counts')
lang=json.loads(data['language/report.json']);life=json.loads(data['lifecycle/report.json']);audit=json.loads(data['audit/report.json'])
check(hashlib.sha256(data['language/report.json']).hexdigest()==summary['raw_reports']['language'],'language report raw identity')
check(hashlib.sha256(data['lifecycle/report.json']).hexdigest()==summary['raw_reports']['lifecycle'],'lifecycle report raw identity')
for prefix,report in [('language',lang),('lifecycle',life)]:
 for rel,digest in report['evidence_sha256'].items():check(prefix+'/'+rel in data and hashlib.sha256(data[prefix+'/'+rel]).hexdigest()==digest,'producer payload '+prefix+'/'+rel)
check(len(lang['evidence_sha256'])+len(life['evidence_sha256'])==62122,'62122 producer declared payloads')
counts=dict(collections.Counter(x['status']for x in lang['results']));check(counts==summary['status_counts']=={'pass':3650,'mismatch':9,'candidate-unsupported':4,'oracle-error':1},'3650/3664 statuses')
check(len(lang['results'])==lang['selected_count']==summary['selected']==3664,'3664 attempted')
check(len(lang['full_gate_failures'])==summary['full_gate_failure_reasons']==1827,'full failure1827')
check(sum(x['status']!='pass'for x in lang['results'])==len(summary['failures'])==summary['current_nonpass_cases']==14,'14 current nonpass')
check(summary['historical_nonpass_comparison_union']==17 and len(summary['status_changes'])==3 and all(x['before']=='candidate-unsupported'and x['after']=='pass'for x in summary['status_changes']),'union17 and3 unsupported-to-pass transitions')
check({x['id']for x in summary['status_changes']}=={'pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/'+p for p in ['basic/read.pkl','modules/amendModule6.pkl','modules/invalidAmend6.pkl']},'three exact original improved cases')
check(summary['gates']==audit['gates']and summary['gates']['language-verify-full']==1 and summary['gates']['language-verify-development']==1 and summary['gates']['language-verify-subset']==1,'strict gates fail retained')
# Every process capture channel is joined to the exact case directory.
for row in lang['results']:
 if 'java' not in row or 'rust' not in row:
  check(row['adapter']=='language-jvm-classpath-output','known special JVM profile row')
  childraw=data['language/'+row['directory']+'/report.json'];check(hashlib.sha256(childraw).hexdigest()==row['child_report_sha256'],'parent-child report binding')
  child=json.loads(childraw);check(len(child['results'])==2,'JVM profile two original repeats')
  for repeat in [0,1]:
   for channel in ['stdout','stderr']:
    check(data[f'language/jvm-classpath/cases/{repeat}/java/{channel}.bin']==data[f'language/jvm-classpath/cases/{repeat}/rust/{channel}.bin'],'JVM profile original fullraw')
  continue
 folder='language/cases/'+row.get('directory',row['id'])
 for language in ['java','rust']:
  process=row[language]
  for channel in ['stdout','stderr']:
   direct=folder+'/'+language+'.'+channel+'.bin';nested=folder+'/'+language+'/'+channel+'.bin';path=direct if direct in data else nested
   check(path in data and hashlib.sha256(data[path]).hexdigest()==process[channel+'_sha256'],'language case process '+row['id']+'/'+language+'/'+channel)
 if row['status']=='pass':
  check(row['java']['exit_code']==row['rust']['exit_code']and row['java']['stdout_sha256']==row['rust']['stdout_sha256']and row['java']['stderr_sha256']==row['rust']['stderr_sha256'],'passing case full process equality '+row['id'])
check(len(lang['metamorphic_results'])==summary['metamorphic_relations']==summary['metamorphic_matches']==88,'88 metamorphic results')
check(life['schema']==summary['lifecycle_schema']==2 and len(life['cases'])==summary['persistent']['sequences']==334,'schema2 and334 sequence executions')
status_counts={'java':collections.Counter(),'rust':collections.Counter()};call_counts=collections.Counter();class_diffs=0;raw_diffs=0
for case in life['cases']:
 calls=case['observations']['processes'];check(len(calls['java']['calls'])==len(calls['rust']['calls']),'sequence paired call count')
 n=len(calls['java']['calls'])
 for language in ['java','rust']:
  process=case[language];check(process['exit_code']==0 and process['status']=='executed','sequence actual process0')
  prefix='lifecycle/'+case['directory']+'/'+language
  check(data[prefix+'/stdout.bin']==''.join(f'call={i} completed\n'for i in range(n)).encode()+b'closed\n'and data[prefix+'/stderr.bin']==b'','complete ordered protocol')
  for call in calls[language]['calls']:
   call_counts[language]+=1;status_counts[language][call['status']]+=1
   for channel,ident in call['channels'].items():
    raw=data[prefix+f'/{call["index"]}.{channel}.bin'];check(len(raw)==ident['bytes']and hashlib.sha256(raw).hexdigest()==ident['sha256'],'lifecycle exact call channel')
 for i in range(n):
  j='lifecycle/'+case['directory']+f'/java/{i}.';r='lifecycle/'+case['directory']+f'/rust/{i}.'
  raw_diffs+=sum(data[j+channel+'.bin']!=data[r+channel+'.bin']for channel in ['status','stdout','stderr'])
  class_diffs+=data[j+'error-class.bin']!=data[r+'error-class.bin']
check(dict(call_counts)=={'java':2782,'rust':2782}and raw_diffs==0,'2782 calls per language zero declared-channel mismatch')
check(class_diffs==summary['persistent']['error_class_differences_retained_excluded_from_equality']==928,'928 error-class differences retained')
check({k:dict(v)for k,v in status_counts.items()}==summary['persistent']['status_counts'],'persistent status counts')
source_map=json.loads((R/summary['source_map']['path']).read_bytes());source_records=[]
for rel,digest in lang['source_sha256'].items():source_records.append(('language',rel,'language/sources/'+rel,digest,None))
for row in life['sources']:source_records.append(('lifecycle',row['path'],'lifecycle/'+row['snapshot'],row['sha256'],row['bytes']))
check(len(source_records)==4385 and len(source_map)==4177 and set(x[1]for x in source_records)==set(source_map),'4385 source records4177unique')
for scope,rel,path,digest,size in source_records:
 raw=data[path];binding=source_map[rel]
 check(hashlib.sha256(raw).hexdigest()==digest==binding['sha256']and(size is None or len(raw)==size),'source record exact '+scope+'/'+rel)
 check(hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==binding['git_blob'],'captured blob identifier '+scope+'/'+rel)
 check(scope in binding['capture_scopes'],'source scope '+scope+'/'+rel)
controls=['.cargo/config.toml','Cargo.toml','Cargo.lock','rust-toolchain.toml'];check(summary['lifecycle_cargo_controls_directly_captured']==controls,'four Cargo control names')
for rel in controls:check(any(x[0]=='lifecycle'and x[1]==rel for x in source_records)and 'lifecycle/sources/'+rel in data,'schema2 actual control payload '+rel)
terminals={}
for name,session in [('wrapper/outer-terminal.json',84018),('audit-execution/outer-terminal.json',32842),('execution/outer-terminal.json',46150)]:
 t=json.loads(data[name]);check(t['session_id']==session and t['exit_code']==0,'actual wrapper terminal '+str(session));terminals[str(session)]=t
wrapper=json.loads(data['wrapper/process-report.json']);check(wrapper['complete']and wrapper['infrastructureFailures']==[]and len(wrapper['commands'])==8,'original wrapper complete8commands')
publisher=json.loads(data['publisher/report.json']);check(publisher['publication_completed']and publisher['originalChanges']==[]and all(x['exit_code']==0 for x in publisher['commands']),'publisher actual commands0/originalchanges0')
pre=json.loads(data['reviewed-publication/stage46-final-summary.json']);final_without_pointer=dict(summary);final_without_pointer.pop('publication_closeout');check(pre==final_without_pointer,'summary only adds closeout pointer')
docs={p.name if p.name!='README.md'else str(p.relative_to(R)):p.read_text()for p in [R/'README.md',R/'PLAN.md',R/'reports/m2/README.md']}
check('declared channels'in docs['README.md']and'strict full-language gate still fails'in docs['README.md'],'README bounded claims')
check('현재 미통과 14개' in docs['PLAN.md']and'합집합 17개'in docs['PLAN.md']and'1,827개'in docs['PLAN.md']and'선택 회귀 취득의 마감이며'in docs['PLAN.md'],'PLAN correct counts/boundary')
check('928 producer error-class differences'in docs['reports/m2/README.md']and'1,827 failure reasons'in docs['reports/m2/README.md'],'reports README qualifications')
check(not summary['full_m2_complete']and not summary['compatibility_complete']and not summary['performance_target_claimed']and not summary['hosted_ci_claimed'],'no full compatibility/platform/performance/CI completion claim')
after={str(p):sha(p)for p in inputs};check(before==after,'review inputs stable')
report={'schema':1,'scope':'Read-only Stage46 final publication review. Pure archive/JSON/source/raw byte inspection; no Java/native/build/test/Git execution or source mutation.','verdict':'No publication blocker found.'if not findings else'Findings require correction.','findings':findings,'checks':checks,'archives':archive_stats,'compressedBytes':sum(r['compressed_bytes']for r in archive_rows),'language':{'selected':3664,'counts':counts,'currentNonpass':14,'comparisonUnion':17,'transitions':3,'fullFailures':1827},'persistent':{'sequences':334,'callsEachLanguage':dict(call_counts),'rawStatusStdoutStderrDifferences':raw_diffs,'errorClassDifferencesSeparate':class_diffs,'schema':2},'sourceBinding':{'records':4385,'uniquePaths':4177,'allCapturedBytesMatchDeclaredShaAndRecomputedGitBlobId':True,'gitCommitTreeMembership':'Reuse independently captured C mapping; reviewer did not run Git.','directLifecycleCargoControls':controls},'actualTerminals':terminals,'inputHashesBefore':before,'inputHashesAfter':after,'inputChanges':[]if before==after else[k for k in before if before[k]!=after[k]],'originalMutations':0,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
write(O/'report.json',report);print(json.dumps({'findings':findings,'checks':checks,'reportSha256':sha(O/'report.json')},indent=2))
