from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / 'target/m2/stage46-final-publication-b-review-01'
STAGING = OUT / 'review-source'
STAGING.mkdir()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(SOURCE / 'report.json') == '4560e30939d296ce2c040e03ebef3e6038a69f04847bed9d46c589d27ad88058'
assert sha(SOURCE / 'closure.json') == '0c246532b9c9ff85b5dbe674c428cd1b1147197bfeac10b9bdf720c989844ef5'
files = list(sorted(SOURCE.iterdir()))
assert all(path.is_file() and not path.is_symlink() for path in files)
rows = {}
for path in files:
    data = path.read_bytes()
    (STAGING / path.name).write_bytes(data)
    rows[path.name] = {'sha256': sha(path), 'bytes': len(data)}
for name, path in [('archive_review.py', Path(__file__)), ('evidence.py', ROOT / 'tools/evidence.py')]:
    (STAGING / name).write_bytes(path.read_bytes())
(STAGING / 'selection.json').write_text(json.dumps({'files': rows, 'scope': 'Closed independent review, including both initial metadata schema failures and the successful correction; no acquisition payload duplication.'}, indent=2) + '\n')
archive = ROOT / 'reports/m2/stage46-final-independent-review-captures.tar.gz'
commands = []
for name, argv in [('create', [sys.executable, 'tools/evidence.py', 'create', str(STAGING), str(archive)]),
                   ('verify', [sys.executable, 'tools/evidence.py', 'verify', str(archive)])]:
    result = subprocess.run(argv, cwd=ROOT, capture_output=True)
    (OUT / f'review-{name}.stdout.bin').write_bytes(result.stdout)
    (OUT / f'review-{name}.stderr.bin').write_bytes(result.stderr)
    commands.append({'name': name, 'argv': argv, 'exitCode': result.returncode})
    assert result.returncode == 0, result.stderr
    print(f'{name}: exit {result.returncode}', flush=True)
assert all(sha(SOURCE / name) == row['sha256'] for name, row in rows.items())
review = ROOT / 'reports/m2/stage46-final-independent-review.json'
review.write_bytes((SOURCE / 'report.json').read_bytes())
summary_path = ROOT / 'reports/m2/stage46-final-summary.json'
old = summary_path.read_bytes()
assert hashlib.sha256(old).hexdigest() == '24accd33866c86efb0605fb81454df1fcdb863dc65c32ac49b76a18cc3d13fd0'
summary = json.loads(old)
summary['independent_review'] = {
    'path': str(review.relative_to(ROOT)), 'sha256': sha(review),
    'reviewed_summary_sha256': hashlib.sha256(old).hexdigest(),
    'captures': {'path': str(archive.relative_to(ROOT)), 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'payload_files': len(rows) + 3},
    'findings': [],
    'qualification': 'Two initial review-tool schema assumptions failed and are retained. Corrected read-only review completed; no evaluator rerun.'}
summary_path.write_text(json.dumps(summary, indent=2) + '\n')
(OUT / 'review-publication.json').write_text(json.dumps({'commands': commands, 'originalReviewChanges': [], 'summaryAddedOnlyIndependentReview': True, 'independent_review': summary['independent_review'], 'summarySha256': sha(summary_path)}, indent=2) + '\n')
print(json.dumps({'summarySha256': sha(summary_path), 'reviewArchiveBytes': archive.stat().st_size}, indent=2))
