"""Capture Stage 28 Unicode diagnostic locations and failure release on a small stack."""
from pathlib import Path
import datetime,hashlib,json,os,platform,shutil,signal,subprocess,sys,time
root=Path.cwd(); out=root/sys.argv[1]; out.mkdir(parents=True,exist_ok=False)
(out/'runner.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=set()
for folder in ['crates/pkl-runtime/src']:
 paths.update(p for p in (root/folder).rglob('*') if p.is_file() and 'node_modules' not in p.parts and p.suffix in {'.rs','.pkl','.mjs','.json'})
paths.update(root/p for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','crates/pkl-runtime/Cargo.toml','crates/pkl-runtime/tests/m2_unicode_diagnostic_lifecycle.rs'])
before={str(p.relative_to(root)):sha(p) for p in sorted(paths)}
for p in sorted(paths):
 dest=out/'sources'/p.relative_to(root); dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
commands=[]
def execute(name,cmd,timeout):
 start=time.monotonic();p=subprocess.Popen(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);timed_out=False
 try:stdout,stderr=p.communicate(timeout=timeout)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGKILL);stdout,stderr=p.communicate()
 (out/f'{name}.stdout.bin').write_bytes(stdout);(out/f'{name}.stderr.bin').write_bytes(stderr)
 row=dict(name=name,command=[str(x) for x in cmd],exit_code=p.returncode,timed_out=timed_out,timeout_seconds=timeout,elapsed_seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest());commands.append(row)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n'); print(json.dumps(row),flush=True)
 return stdout,p.returncode
execute('git-head',['git','rev-parse','HEAD'],10);execute('git-status',['git','status','--porcelain=v1'],10);execute('rust-version',['rustc','-Vv'],10)
raw,status=execute('build',['cargo','test','-p','pkl-runtime','--locked','--test','m2_unicode_diagnostic_lifecycle','--no-run','--message-format=json'],180)
artifacts=[]
observations=[]
if status==0:
 for line in raw.splitlines():
  obj=json.loads(line)
  if obj.get('reason')=='compiler-artifact' and obj.get('executable') and obj['target']['name']=='m2_unicode_diagnostic_lifecycle':
   p=Path(obj['executable']);dest=out/'artifacts'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest);artifacts.append(dict(path=str(dest.relative_to(out)),build_path=str(p),build_sha256=sha(p),sha256=sha(dest),bytes=dest.stat().st_size))
   test_raw,test_status=execute('native-lifecycle',[str(dest),'--nocapture','--test-threads=1'],180)
   observations.append(dict(exit_success=test_status==0,child_completion_markers=test_raw.count(b'stage28 unicode diagnostic completed:'),parent_summary_present=b'test result: ok. 2 passed; 0 failed; 0 ignored;' in test_raw))
after={str(p.relative_to(root)):sha(p) for p in sorted(paths)}
report=dict(scope='Bounded Unicode diagnostic location/error-order and partial frontend cleanup checks; fresh successful work after parser errors; not retained-evaluator or Host lifecycle evidence, Java equivalence or arbitrary syntax support',host=platform.platform(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),conditions=dict(expected_top_level_tests=2,expected_child_completion_markers=2,expected_harness_passes_including_child_repeats=4,thread_stack_bytes=262144,parent_deadline_seconds_per_test=60,diagnostic_lexical_depths=[24,31],diagnostic_delimiters=['ordinary','hash','multiline'],guarded_lexical_depth=64,guarded_delimiters=['ordinary','hash','multiline'],malformed_multiline_shapes=['missing-opening-newline','missing-closing-newline','incorrect-indentation'],entrypoints=['parse_expression','parse_module with completed deep sibling and Unicode prefix'],error_checks='exact kind, complete message and byte spans; Unicode token semantic/lexical phases and multiline order; newline and zero-width true EOF distinguished',cleanup='partial parse failure drops completed siblings and lexical frames on the same stack; errors are dropped before fresh successful depth31 parse/resolve/compile/eval/release',success_after_errors='fresh evaluator for each recovery call; no retained-evaluator claim across setup errors',host_lifecycle='existing Stage26/27 Host suspension/reentry/retry/GC/terminal tests remain separate and unchanged',known_limits=['Java accepts guarded depth64 inputs; retained bounded rejection remains a compatibility mismatch','No new Host lifecycle test or persistent sequence is claimed','Deep type/class/mixed-body compilation and arbitrary nesting remain separate requirements']),execution_environment={k:os.environ[k] for k in ['RUSTUP_TOOLCHAIN','CARGO_TARGET_DIR','CARGO_BUILD_TARGET','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'] if k in os.environ},source_stability=before==after,source_sha256_before=before,source_sha256_after=after,artifacts=artifacts,observations=observations,commands=commands)
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');(out/'evidence-sha256.json').write_text(json.dumps({str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()},indent=2)+'\n')
raise SystemExit(int(not report['source_stability'] or len(artifacts)!=1 or len(observations)!=1 or any(not x['exit_success'] or x['child_completion_markers']!=2 or not x['parent_summary_present'] for x in observations) or any(x['exit_code']!=0 or x['timed_out'] for x in commands)))
