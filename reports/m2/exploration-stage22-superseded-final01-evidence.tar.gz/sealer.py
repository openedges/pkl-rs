"""Seal bounded Stage22 raw exploration and superseded evidence at original paths."""
from pathlib import Path
import argparse,datetime,fnmatch,hashlib,json,platform,shutil,sys
sys.dont_write_bytecode=True
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tools'));import evidence

def enc(x):return (json.dumps(x,sort_keys=True,indent=2)+'\n').encode()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ident(p):return dict(path=p.relative_to(ROOT).as_posix(),sha256=sha(p),bytes=p.stat().st_size)
def main():
 p=argparse.ArgumentParser();p.add_argument('configuration',type=Path);p.add_argument('staging',type=Path);a=p.parse_args();cfg=json.loads(a.configuration.read_bytes());stage=a.staging.resolve();stage.mkdir(parents=True,exist_ok=False)
 summaries=[]
 for group in cfg['groups']:
  folder=stage/group['name'];folder.mkdir();sourcepaths=set()
  for name in group['paths']:
   source=ROOT/name;assert source.exists(),name;assert not source.is_symlink(),name
   sourcepaths.update([source]if source.is_file()else(q for q in source.rglob('*')if q.is_file()))
  retained=[];excluded=[]
  for source in sorted(sourcepaths):
   assert not source.is_symlink()and source.resolve().is_relative_to(ROOT);relative=source.relative_to(ROOT).as_posix()
   if any(fnmatch.fnmatchcase(relative,pattern)for pattern in group.get('excludes',[])):
    excluded.append(dict(path=relative,bytes=source.stat().st_size));continue
   dest=folder/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest);assert sha(source)==sha(dest),relative;retained.append(ident(source))
  (folder/'ORIGINAL_PATHS.json').write_bytes(enc(dict(schema=1,files=retained,excluded_cache_files=excluded)))
  (folder/'PACKAGE.json').write_bytes(enc(dict(schema=1,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host=platform.platform(),scope=group['scope'],original_paths_preserved=True,captured_artifacts_executed=False,history_dependencies=cfg['history_dependencies'],counts=cfg['counts'],excluded_patterns=group.get('excludes',[]))))
  (folder/'sealer.py').write_bytes(Path(__file__).read_bytes());(folder/'configuration.json').write_bytes(a.configuration.read_bytes())
  archive=ROOT/group['archive'];assert not archive.exists(),archive;evidence.create(folder,archive,group.get('excludes',[]));assert archive.stat().st_size<80_000_000,'split archive over80MB'
  for row in retained:
   original=ROOT/row['path'];assert sha(original)==row['sha256']and original.stat().st_size==row['bytes'],'source changed during seal: '+row['path']
  summaries.append(dict(**ident(archive),inventory_verified=True,original_files=len(retained),excluded_cache_files=len(excluded),scope=group['scope']))
 index=dict(main=summaries[0],additional_archives=summaries[1:],scope=cfg['scope'],counts=cfg['counts'],history_dependencies=cfg['history_dependencies'],limitations=cfg['limitations'],all_original_paths_sizes_and_hashes_verified=True,captured_artifacts_executed=False)
 for dependency in cfg['history_dependencies']:
  source=ROOT/dependency['path'];assert ident(source)==dependency
 dest=ROOT/cfg['index'];assert not dest.exists();dest.write_bytes(enc(index));print(json.dumps(index,indent=2))
if __name__=='__main__':main()
