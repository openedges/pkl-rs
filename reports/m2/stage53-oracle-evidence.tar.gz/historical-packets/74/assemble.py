"""Assemble a compact Java-only review packet without regenerating expected bytes."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
BASE=OUT.parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def copy(p,name):
 q=OUT/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);return dict(path=name,sha256=sha(q),bytes=q.stat().st_size)

def main():
 if (OUT/'manifest.json').exists():raise ValueError('fresh packet required')
 cohorts={};rows=[];boundaries=[];unreached=[]
 for number in ['01','02','03','04','05','06']:
  root=BASE/('stage53-oracle-parameterized-'+number)
  report=json.loads((root/'report.json').read_text())
  cohorts[number]=dict(original_root=str(root),report_sha256=sha(root/'report.json'),cases_sha256=sha(root/'cases.json'),input_files_unchanged=report['input_files_unchanged'],expressions=len(report['observations']),repeats_per_expression=2,java_processes=len(report['observations'])*2)
  for original in report['observations']:
   selected=(number=='03' and not original['id'].startswith('lexical-')) or (number=='04' and (original['id'].startswith('eager-scope-') or original['id'] in ['lexical-00','lexical-01','lexical-02'])) or (number=='05' and original['id']!='read-constraint-02') or number=='06'
   internal=(number=='03' and original['id']in ['dispatch-01','dispatch-09']) or (number=='04'and original['id']in ['lexical-03','lexical-04'])
   if not selected and not internal:
    reached = number in ['01','02'] and original['id'].startswith('dispatch-') or number == '01' and original['id'] in ['arity-05','arity-06','arity-07','arity-08']
    unreached.append(dict(cohort=number,id=original['id'],expression=original['expression'],intended_semantics_reached=reached,classification='superseded-observation' if reached else 'diagnostic-only-unreached-intent',reason='Earlier equivalent dispatch/arity observation is retained; the ordinary selection uses the final pinned source cohort.' if reached else 'Earlier invalid control syntax / reserved identifier, or scalar amendment blocks intended lazy read; full raw capture remains in original cohort.'))
    continue
   source=Path(original['source']);source_copy=copy(source,'inputs/'+number+'/'+source.name)
   row=dict(id='stage53-'+number+'-'+original['id'],source=source_copy['path'],source_sha256=original['source_sha256'],source_uri=source.as_uri(),module_name=source.stem,expression=original['expression'],power_assertions=False,cohort=number,original_id=original['id'],classification='oracle-error'if internal else 'ordinary',java_repeats=2,replay_equal=original['replay_equal'],observations=[])
   row['requires_host'] = source.name == 'read-constraint.pkl'
   row['resources'] = [dict(source='inputs/'+number+'/gate.txt',source_uri=(source.parent/'gate.txt').as_uri(),sha256=sha(source.parent/'gate.txt'))] if row['requires_host'] else []
   first=original['observations'][0]
   if not internal and not original['replay_equal']:raise ValueError('ordinary non-identical repeat')
   for ob in original['observations']:
    original_dir=root/ob['directory'];prefix='raw/'+row['id']+('/repeat-'+str(ob['repeat'])if internal else '')
    channels={}
    for channel in ['stdout','stderr','outcome']:
     channels[channel]=copy(original_dir/('java.'+channel+'.bin'),prefix+'/'+channel+'.bin')
    process=copy(original_dir/'java.process.json','provenance/processes/'+row['id']+'/repeat-'+str(ob['repeat'])+'.json')
    row['observations'].append(dict(repeat=ob['repeat'],process=process,exit_code=ob['process']['exit_code'],timed_out=ob['process']['timed_out'],channels=channels,public_generated_files={},input_tree_unchanged=report['input_files_unchanged']))
   (boundaries if internal else rows).append(row)
  if (root/'inputs/gate.txt').exists():copy(root/'inputs/gate.txt','inputs/'+number+'/gate.txt')
 for name in ['artifacts/java/M2LanguageProbe.class','javac.process.json','javac.stdout.bin','javac.stderr.bin']:
  copy(BASE/'stage53-oracle-parameterized-03'/name,'provenance/'+name)
 copy(BASE/'stage53-oracle-parameterized-03/oracle.json','provenance/oracle.json')
 copy(ROOT/'tools/java/M2LanguageProbe.java','provenance/M2LanguageProbe.java')
 copy(ROOT/'oracle.lock.json','provenance/oracle.lock.json')
 copy(ROOT/'references.lock','provenance/references.lock')
 copy(ROOT/'LICENSE','LICENSE')
 original=BASE/'stage53-oracle-parameterized-03/original-cli'
 for name in ['case.json','report.json','repeat-0/stdout.bin','repeat-0/stderr.bin','repeat-0/process.json','repeat-0/result.json','repeat-1/stdout.bin','repeat-1/stderr.bin','repeat-1/process.json','repeat-1/result.json']:
  copy(original/name,'original-cli/'+name)
 put(OUT/'cases.json',rows)
 put(OUT/'oracle-boundaries.json',boundaries)
 put(OUT/'historical-observations.json',unreached)
 put(OUT/'provenance/cohorts.json',cohorts)
 put(OUT/'summary.json',dict(ordinary_cases=len(rows),ordinary_successes=sum(r['observations'][0]['exit_code']==0 for r in rows),ordinary_language_errors=sum(r['observations'][0]['exit_code']==1 for r in rows),oracle_error_cases=len(boundaries),excluded_historical_rows=len(unreached),unreached_intent_rows=sum(not r['intended_semantics_reached']for r in unreached),superseded_reached_rows=sum(r['intended_semantics_reached']for r in unreached),ordinary_java_processes=len(rows)*2,all_historical_expression_java_processes=sum(c['java_processes']for c in cohorts.values()),original_cli_java_processes=2,compatibility_passes_claimed=0))
 (OUT/'README.md').write_text('''# Parameterized object-body Java observations\n\nThis review packet contains independently acquired Pkl 0.32.0 Java results. It contains no Rust-derived expectations or compatibility verdict. Inputs are project-authored controls; copied project sources retain the repository license. The original upstream CLI input remains separately pinned by its unchanged corpus/source identities.\n\n`cases.json` selects ordinary, reached semantics and complete language diagnostics. Each source has its original absolute URI and module name; consumers must use that URI rather than rewrite diagnostic bytes. Both fresh Java process observations are recorded. Identical ordinary stdout/stderr/outcome payloads are stored once; process records and original cohort hashes preserve both acquisitions. Raw output has no trimming, sorting, or reserialization. `inputs/*/gate.txt` is the exact file resource for the read controls.\n\n`oracle-boundaries.json` retains two PklBugException inputs and two recursive receiver controls that produced Java StackOverflowError before the probe outcome could be written. These are oracle errors, even if a candidate prints the same bytes. Stack-overflow repeats may differ. `historical-observations.json` separates earlier equivalent dispatch/arity observations from syntax, reserved-name, and scalar-amendment controls whose intended behavior was not reached. These historical rows never add selected feature passes. Full original raw captures, source/probe copies, commands, controlled environment and file snapshots remain in the recorded target cohorts.\n\n`original-cli/` records two executions with the original corpus argv/cwd/environment overrides through `m2_module_eval.capture_process`. Both exited zero with empty stdout/stderr and no generated public files. Its all-local functions are not called, so that result alone does not establish Mixin semantics. A minimal input graph was sufficient for this all-local source; this packet is not a full upstream resource-set replay.\n\nThe scalar Java probe prints `evaluateExpressionString` output and a separate exception-class outcome. These API observations have no public file-output operation; the input/resource tree was unchanged before and after every cohort. They do not establish renderer, Host event-order, public API lifecycle, platform, language-wide, or performance compatibility. The controlled process environment and runtime identities are in `provenance/oracle.json`; every exact invocation is in its process record.\n''')
 put(OUT/'manifest.json',dict(schema=1,baseline='Pkl 0.32.0',scope='Java-only selected semantic observations and explicitly separate historical/oracle boundaries',files={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(OUT.rglob('*'))if p.is_file()and p.name!='manifest.json'}))
 print((OUT/'summary.json').read_text())
main()
