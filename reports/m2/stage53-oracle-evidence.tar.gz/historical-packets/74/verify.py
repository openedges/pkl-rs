"""Validate selected raw expectations against independent original Java acquisitions."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 m=json.loads((ROOT/'manifest.json').read_text())
 actual={str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()and p.name!='manifest.json'}
 assert actual==set(m['files'])
 for name,pin in m['files'].items():
  p=ROOT/name;assert not p.is_symlink()and sha(p)==pin['sha256']and p.stat().st_size==pin['bytes'],name
 cohorts=json.loads((ROOT/'provenance/cohorts.json').read_text())
 index={}
 for key,pin in cohorts.items():
  p=Path(pin['original_root']);assert sha(p/'report.json')==pin['report_sha256'];assert sha(p/'cases.json')==pin['cases_sha256']
  report=json.loads((p/'report.json').read_text());assert report['input_files_unchanged']
  index[key]={c['id']:c for c in report['observations']}
 ordinary=json.loads((ROOT/'cases.json').read_text());boundary=json.loads((ROOT/'oracle-boundaries.json').read_text())
 assert len(ordinary)==74 and len(boundary)==4
 for row in ordinary+boundary:
  original=index[row['cohort']][row['original_id']]
  assert row['source_sha256']==sha(ROOT/row['source'])==original['source_sha256']
  assert row['expression']==original['expression']and row['source_uri']==Path(original['source']).as_uri()
  assert row['module_name']==Path(original['source']).stem and row['java_repeats']==2
  internal=row['classification']=='oracle-error'
  assert internal or row['replay_equal']
  for ob,old in zip(row['observations'],original['observations'],strict=True):
   assert ob['exit_code']==old['process']['exit_code']and ob['timed_out']==old['process']['timed_out']
   process=ROOT/ob['process']['path'];assert json.loads(process.read_text())==old['process']
   for channel,ref in ob['channels'].items():
    src=Path(cohorts[row['cohort']]['original_root'])/old['directory']/('java.'+channel+'.bin')
    assert (ROOT/ref['path']).read_bytes()==src.read_bytes()
   outcome=(ROOT/ob['channels']['outcome']['path']).read_bytes()
   if not internal:
    assert not ob['timed_out']
    assert (ob['exit_code']==0 and outcome==b'success\n')or(ob['exit_code']==1 and outcome==b'pkl-exception\torg.pkl.core.PklException\n')
    other='stderr'if ob['exit_code']==0 else 'stdout'
    assert (ROOT/ob['channels'][other]['path']).read_bytes()==b''
  for resource in row.get('resources',[]):assert sha(ROOT/resource['source'])==resource['sha256']
 original=json.loads((ROOT/'original-cli/report.json').read_text())
 assert original['raw_repeat_equal']and all(o['exit_code']==0 and not o['workspace_changes']and not o['files_sha256']for o in original['observations'])
 print(json.dumps(dict(verified=True,ordinary_cases=len(ordinary),oracle_errors=len(boundary),ordinary_fresh_java_processes=148,original_cli_processes=2,compatibility_passes_claimed=0)))
if __name__=='__main__':verify()
