from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'tests/fixtures/m2-parameterized-object-bodies';source=ROOT/'target/m2/stage53-oracle-parameterized-08'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def copy(p,n):
 q=OUT/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);return dict(path=n,sha256=sha(q),bytes=q.stat().st_size)
report=json.loads((source/'report.json').read_text());rows=json.loads((OUT/'oracle-boundaries.json').read_text())
for old in report['observations']:
 p=Path(old['source']);copy(p,'inputs/08/'+p.name)
 row=dict(id='stage53-08-'+old['id'],source='inputs/08/'+p.name,source_sha256=old['source_sha256'],source_uri=p.as_uri(),module_name=p.stem,expression=old['expression'],power_assertions=False,cohort='08',original_id=old['id'],classification='oracle-error',java_repeats=2,replay_equal=old['replay_equal'],observations=[],requires_host=False,resources=[])
 for ob in old['observations']:
  directory=source/ob['directory'];prefix='raw/'+row['id']+'/repeat-'+str(ob['repeat'])
  channels={n:copy(directory/('java.'+n+'.bin'),prefix+'/'+n+'.bin')for n in ['stdout','stderr','outcome']}
  process=copy(directory/'java.process.json','provenance/processes/'+row['id']+'/repeat-'+str(ob['repeat'])+'.json')
  row['observations'].append(dict(repeat=ob['repeat'],process=process,exit_code=ob['process']['exit_code'],timed_out=ob['process']['timed_out'],channels=channels,public_generated_files={},input_tree_unchanged=True))
 rows.append(row)
put(OUT/'oracle-boundaries.json',rows)
for filename,dest in [('report.json','provenance/original-reports/08.json'),('cases.json','provenance/original-cases/08.json'),('capture.py','provenance/capture-sources/08.py')]:copy(source/filename,dest)
cohorts=json.loads((OUT/'provenance/cohorts.json').read_text());cohorts['08']=dict(original_root=str(source),report_sha256=sha(source/'report.json'),cases_sha256=sha(source/'cases.json'),input_files_unchanged=True,expressions=3,repeats_per_expression=2,java_processes=6);put(OUT/'provenance/cohorts.json',cohorts)
summary=json.loads((OUT/'summary.json').read_text());summary.update(oracle_error_cases=7,all_historical_expression_java_processes=446);put(OUT/'summary.json',summary)
p=OUT/'README.md';s=p.read_text().replace('and two recursive receiver controls that produced Java StackOverflowError before the probe outcome could be written.', 'two recursive receiver controls that produced Java StackOverflowError, and three forbidden for/when-body parameter inputs that produced Java MissingResourceException before the probe outcome could be written.');p.write_text(s)
put(OUT/'manifest.json',dict(schema=1,baseline='Pkl 0.32.0',scope='Java-only selected semantic observations and explicitly separate historical/oracle boundaries',files={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(OUT.rglob('*'))if p.is_file()and p.name!='manifest.json'}))
