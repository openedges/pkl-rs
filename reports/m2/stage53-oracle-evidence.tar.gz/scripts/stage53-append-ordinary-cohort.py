"""Append an approved Java-only ordinary cohort without changing existing raw files."""
from pathlib import Path
import hashlib,json,shutil,sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'tests/fixtures/m2-parameterized-object-bodies';number=sys.argv[1];source=ROOT/'target/m2'/('stage53-oracle-parameterized-'+number)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def copy(p,n):
 q=OUT/n;q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert q.read_bytes()==p.read_bytes()
 else:shutil.copyfile(p,q)
 return dict(path=n,sha256=sha(q),bytes=q.stat().st_size)
report=json.loads((source/'report.json').read_text());rows=json.loads((OUT/'cases.json').read_text());assert not any(r['cohort']==number for r in rows)
for old in report['observations']:
 p=Path(old['source']);copy(p,'inputs/'+number+'/'+p.name)
 row=dict(id='stage53-'+number+'-'+old['id'],source='inputs/'+number+'/'+p.name,source_sha256=old['source_sha256'],source_uri=p.as_uri(),module_name=p.stem,expression=old['expression'],power_assertions=False,cohort=number,original_id=old['id'],classification='ordinary',java_repeats=2,replay_equal=old['replay_equal'],observations=[],requires_host=False,resources=[])
 assert row['replay_equal']
 for ob in old['observations']:
  directory=source/ob['directory'];prefix='raw/'+row['id']
  channels={n:copy(directory/('java.'+n+'.bin'),prefix+'/'+n+'.bin')for n in ['stdout','stderr','outcome']}
  process=copy(directory/'java.process.json','provenance/processes/'+row['id']+'/repeat-'+str(ob['repeat'])+'.json')
  row['observations'].append(dict(repeat=ob['repeat'],process=process,exit_code=ob['process']['exit_code'],timed_out=ob['process']['timed_out'],channels=channels,public_generated_files={},input_tree_unchanged=True))
 rows.append(row)
put(OUT/'cases.json',rows)
for filename,dest in [('report.json','provenance/original-reports/'+number+'.json'),('cases.json','provenance/original-cases/'+number+'.json'),('capture.py','provenance/capture-sources/'+number+'.py')]:copy(source/filename,dest)
cohorts=json.loads((OUT/'provenance/cohorts.json').read_text());cohorts[number]=dict(original_root=str(source),report_sha256=sha(source/'report.json'),cases_sha256=sha(source/'cases.json'),input_files_unchanged=True,expressions=len(report['observations']),repeats_per_expression=2,java_processes=2*len(report['observations']));put(OUT/'provenance/cohorts.json',cohorts)
summary=json.loads((OUT/'summary.json').read_text());summary.update(ordinary_cases=len(rows),ordinary_successes=sum(r['observations'][0]['exit_code']==0 for r in rows),ordinary_language_errors=sum(r['observations'][0]['exit_code']==1 for r in rows),ordinary_java_processes=2*len(rows),all_historical_expression_java_processes=sum(c['java_processes']for c in cohorts.values()));put(OUT/'summary.json',summary)
put(OUT/'manifest.json',dict(schema=1,baseline='Pkl 0.32.0',scope='Java-only selected semantic observations and explicitly separate historical/oracle boundaries',files={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(OUT.rglob('*'))if p.is_file()and p.name!='manifest.json'}))
print(json.dumps(summary))
