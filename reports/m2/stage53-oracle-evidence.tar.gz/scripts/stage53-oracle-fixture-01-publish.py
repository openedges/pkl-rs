"""Publish approved independent Java observations; preserve the target review packet."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'target/m2'
SOURCE=BASE/'stage53-oracle-fixture-01'
OUT=ROOT/'tests/fixtures/m2-parameterized-object-bodies'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def copy(p,n):
 q=OUT/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 return dict(path=n,sha256=sha(q),bytes=q.stat().st_size)

shutil.copytree(SOURCE,OUT,ignore=shutil.ignore_patterns('assemble.py','verify.py','manifest.json'))
rows=json.loads((OUT/'cases.json').read_text())
root=BASE/'stage53-oracle-parameterized-07'
report=json.loads((root/'report.json').read_text())
cohorts=json.loads((OUT/'provenance/cohorts.json').read_text())
cohorts['07']=dict(original_root=str(root),report_sha256=sha(root/'report.json'),cases_sha256=sha(root/'cases.json'),input_files_unchanged=report['input_files_unchanged'],expressions=len(report['observations']),repeats_per_expression=2,java_processes=len(report['observations'])*2)
for original in report['observations']:
 source=Path(original['source']);copy(source,'inputs/07/'+source.name)
 row=dict(id='stage53-07-'+original['id'],source='inputs/07/'+source.name,source_sha256=original['source_sha256'],source_uri=source.as_uri(),module_name=source.stem,expression=original['expression'],power_assertions=False,cohort='07',original_id=original['id'],classification='ordinary',java_repeats=2,replay_equal=original['replay_equal'],observations=[],requires_host=False,resources=[])
 assert row['replay_equal']
 for ob in original['observations']:
  raw=root/ob['directory'];prefix='raw/'+row['id']
  channels={n:copy(raw/('java.'+n+'.bin'),prefix+'/'+n+'.bin')for n in ['stdout','stderr','outcome']}
  process=copy(raw/'java.process.json','provenance/processes/'+row['id']+'/repeat-'+str(ob['repeat'])+'.json')
  row['observations'].append(dict(repeat=ob['repeat'],process=process,exit_code=ob['process']['exit_code'],timed_out=ob['process']['timed_out'],channels=channels,public_generated_files={},input_tree_unchanged=report['input_files_unchanged']))
 rows.append(row)
put(OUT/'cases.json',rows);put(OUT/'provenance/cohorts.json',cohorts)
for number in ['03','04','05','06','07']:
 root=BASE/('stage53-oracle-parameterized-'+number)
 copy(root/'report.json','provenance/original-reports/'+number+'.json')
 copy(root/'cases.json','provenance/original-cases/'+number+'.json')
 copy(root/'capture.py','provenance/capture-sources/'+number+'.py')
for name in ['tools/m2_language.py','tools/oracle.py','tools/compat.py']:
 copy(BASE/'stage53-oracle-parameterized-03/sources'/name,'provenance/capture-tools/'+Path(name).name)
copy(ROOT/'tools/m2_module_eval.py','provenance/capture-tools/m2_module_eval.py')
copy(BASE/'stage53-oracle-parameterized-03/original-cli.py','provenance/capture-sources/original-cli.py')
original=json.loads((OUT/'original-cli/case.json').read_text())
copy(BASE/'stage53-oracle-parameterized-03/original-cli/workspace'/original['input'],'original-cli/input.pkl')
for name in ['LICENSE.txt','NOTICE.txt']:
 copy(ROOT/'external/pkl'/name,'original-cli/upstream-'+name)
summary=json.loads((OUT/'summary.json').read_text());summary.update(ordinary_cases=len(rows),ordinary_successes=sum(r['observations'][0]['exit_code']==0 for r in rows),ordinary_language_errors=sum(r['observations'][0]['exit_code']==1 for r in rows),ordinary_java_processes=len(rows)*2,all_historical_expression_java_processes=sum(c['java_processes']for c in cohorts.values()))
put(OUT/'summary.json',summary)
f=OUT/'README.md';s=f.read_text().replace('This review packet','This fixture').replace('Full original raw captures, source/probe copies, commands, controlled environment and file snapshots remain in the recorded target cohorts.', 'Selected original reports, source/probe copies, commands, controlled environment, input identities and full selected raw payloads are preserved here. Earlier excluded acquisition raw files remain in the recorded historical target cohorts; their absence on another host does not alter the explicit unreached/superseded ledger.').replace('The controlled process environment and runtime identities are in `provenance/oracle.json`; every exact invocation is in its process record.', 'The controlled process environment and runtime identities are in `provenance/oracle.json`; every exact invocation is in its process record. The narrow repository verifier independently pins the Java authority reports, probe bytecode/source and runtime metadata. Run `python3 tools/parameterized_object_fixtures.py` to validate this fixture without ignored target directories or installed Java. The separate read cases require exact URI resources from their `resources` arrays. No Java logger/read callback trace was acquired by the plain scalar probe; native event-order/lifecycle tests have a separate scope.')
f.write_text(s)
put(OUT/'manifest.json',dict(schema=1,baseline='Pkl 0.32.0',scope='Java-only selected semantic observations and explicitly separate historical/oracle boundaries',files={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(OUT.rglob('*'))if p.is_file()and p.name!='manifest.json'}))
print(json.dumps(summary,indent=2))
