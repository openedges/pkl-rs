"""Read-only, full Git-object source binding for an explicitly supplied Stage56 B commit."""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "target/m2/stage56-implementation-binding-01"
REPORT = ROOT / "reports/m2/stage56-source-binding.json"
ARCHIVE = ROOT / "reports/m2/stage56-source-binding-evidence.tar.gz"
PINNED = {"external/pkl": "e51fb2f91774265666f94980ec630db794a4db2d",
          "external/pkl-pantry": "904a68184e54da378b0a0e8a911a3fab3956f693"}


def digest(path):
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            h.update(block)
            size += len(block)
    return {"sha256": h.hexdigest(), "bytes": size}


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True) + "\n").encode()


def run(*argv):
    return subprocess.run(argv, cwd=ROOT, check=True, capture_output=True).stdout


def tree(repo, commit):
    raw = run("git", "-C", str(repo), "ls-tree", "-rz", "--full-tree", commit)
    result = {}
    for entry in raw.split(b"\0"):
        if not entry:
            continue
        header, path = entry.split(b"\t", 1)
        mode, kind, oid = header.split(b" ")
        result[path.decode("utf-8", "surrogateescape")] = (mode.decode(), kind.decode(), oid.decode())
    return result


def logical_path(path):
    if path.startswith("external/pkl-pantry/"):
        return "external/pkl-pantry", path[len("external/pkl-pantry/"):]
    if path.startswith("external/pkl/"):
        return "external/pkl", path[len("external/pkl/"):]
    return ".", path


def catalog(label, path, subkey=None):
    source = json.loads(path.read_bytes())
    rows = source[subkey] if subkey else source
    assert isinstance(rows, dict)
    entries = []
    for name, value in rows.items():
        expected = value if isinstance(value, str) else value["sha256"]
        size = None if isinstance(value, str) else value.get("bytes")
        assert re.fullmatch(r"[0-9a-f]{64}", expected), (label, name)
        entries.append((name, expected, size))
    return {"label": label, "manifest_path": path.relative_to(ROOT).as_posix(),
            "manifest_identity": digest(path), "entries": entries}


def blob_audit(repo, oids):
    """SHA1-framed and SHA256-read each distinct Git blob, including symlink targets."""
    proc = subprocess.Popen(["git", "-C", str(repo), "cat-file", "--batch"],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    result = {}
    try:
        for oid in sorted(oids):
            proc.stdin.write((oid + "\n").encode())
            proc.stdin.flush()
            header = proc.stdout.readline().strip().split(b" ")
            assert len(header) == 3 and header[0].decode() == oid and header[1] == b"blob", (oid, header)
            remaining = int(header[2])
            size = remaining
            sha1 = hashlib.sha1(b"blob " + str(size).encode() + b"\0")
            sha256 = hashlib.sha256()
            while remaining:
                block = proc.stdout.read(min(1024 * 1024, remaining))
                assert block, (oid, remaining)
                sha1.update(block)
                sha256.update(block)
                remaining -= len(block)
            assert proc.stdout.read(1) == b"\n"
            assert sha1.hexdigest() == oid, oid
            result[oid] = {"sha256": sha256.hexdigest(), "bytes": size, "git_blob_sha1": oid}
        proc.stdin.close()
        assert proc.wait() == 0, proc.stderr.read()
        return result
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()


def add_logical_catalogs():
    m2 = ROOT / "target/m2"
    result = [catalog("core_freeze_04_files", m2 / "stage56-core-checks-04/core-freeze.json", "files"),
              catalog("core_freeze_04_compile_inputs", m2 / "stage56-core-checks-04/core-freeze.json", "compile_inputs"),
              catalog("comparator_checks_03", m2 / "stage56-comparator-checks-03/sources-after.json"),
              catalog("portable_checks_05", m2 / "stage56-portable-checks-05/sources-after.json"),
              catalog("class_platform_01", m2 / "stage56-class-platform-01/report.json", "sources_before"),
              catalog("metadata_platform_01", m2 / "stage56-metadata-platform-01/report.json", "sources_before"),
              catalog("m1_platforms_01", m2 / "stage56-platforms-01/sources.json"),
              catalog("release_platform_run_01", m2 / "stage56-platform-run-01/sources.json"),
              catalog("original_six_01", m2 / "stage56-original-class-01/sources.json")]
    return result


def main(commit):
    assert re.fullmatch(r"[0-9a-f]{40}", commit), "An explicit 40-hex B commit is required"
    assert run("git", "cat-file", "-t", commit).strip() == b"commit"
    assert not OUT.joinpath("report.json").exists() and not REPORT.exists() and not ARCHIVE.exists()
    OUT.mkdir(parents=True, exist_ok=True)
    repo_paths = {".": ROOT, **{name: ROOT / name for name in PINNED}}
    trees = {".": tree(ROOT, commit), **{name: tree(ROOT / name, pin) for name, pin in PINNED.items()}}
    for name, pin in PINNED.items():
        assert trees["."][name] == ("160000", "commit", pin), (name, trees["."].get(name))
    rust_path = ROOT / "target/m2/stage56-rust-validation-03/sources.json"
    rust_manifest = json.loads(rust_path.read_bytes())
    assert len(rust_manifest) == 165175
    categories = add_logical_catalogs()
    assert any(name == "tools/m1_platforms.py" for name, _, _ in next(c["entries"] for c in categories if c["label"] == "release_platform_run_01"))
    roots = {k: set() for k in repo_paths}
    rows = []
    historical_origin_mismatches = []
    copied = 0
    for name, record in rust_manifest.items():
        repo_name, relative = logical_path(name)
        origin = record["origin"]
        if origin["kind"] == "git-blob":
            assert origin["repository"] == repo_name and origin["path"] == relative
            assert repo_name == "." or origin["commit"] == PINNED[repo_name]
            historical_tree = trees[repo_name] if repo_name != "." else tree_cache_historical(origin["commit"])
            actual = historical_tree.get(relative)
            assert actual == (origin["mode"], "blob", origin["oid"]), (name, actual, origin)
            roots[repo_name].add(origin["oid"])
        else:
            assert origin["kind"] == "captured-file"
            captured_path = rust_path.parent / origin["path"]
            assert digest(captured_path) == {"sha256": record["sha256"], "bytes": record["bytes"]}
            copied += 1
        candidate_tree = trees[repo_name].get(relative)
        if candidate_tree and candidate_tree[1] == "blob":
            roots[repo_name].add(candidate_tree[2])
        rows.append({"category": "rust_validation_03", "path": name, "repository": repo_name,
                     "expected_sha256": record["sha256"], "expected_bytes": record["bytes"],
                     "expected_input_kind": record["input_kind"], "origin_kind": origin["kind"],
                     "origin_oid": origin.get("oid"), "origin_mode": origin.get("mode"),
                     "B_tree": candidate_tree})
    assert copied == 47
    for category in categories:
        for name, expected, size in category["entries"]:
            repo_name, relative = logical_path(name)
            candidate_tree = trees[repo_name].get(relative)
            if candidate_tree and candidate_tree[1] == "blob":
                roots[repo_name].add(candidate_tree[2])
            rows.append({"category": category["label"], "path": name, "repository": repo_name,
                         "expected_sha256": expected, "expected_bytes": size, "B_tree": candidate_tree})
    blob_data = {name: blob_audit(repo_paths[name], roots[name]) for name in roots}
    statuses = defaultdict(Counter)
    exceptions = defaultdict(list)
    row_path = OUT / "rows.jsonl.gz"
    with row_path.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as zipped:
            for row in rows:
                tree_entry = row.pop("B_tree")
                if tree_entry is None:
                    row["status"] = "missing_in_B_tree"
                elif tree_entry[1] != "blob":
                    row["status"] = "nonblob_in_B_tree"
                    row["B_mode"], row["B_type"], row["B_oid"] = tree_entry
                else:
                    mode, kind, oid = tree_entry
                    actual = blob_data[row["repository"]][oid]
                    row.update(B_mode=mode, B_oid=oid, B_sha256=actual["sha256"], B_bytes=actual["bytes"])
                    equal = actual["sha256"] == row["expected_sha256"] and (row["expected_bytes"] is None or actual["bytes"] == row["expected_bytes"])
                    if row["category"] == "rust_validation_03" and row.get("origin_mode") is not None:
                        equal = equal and mode == row["origin_mode"]
                    row["status"] = "matches_B" if equal else "differs_from_B_historical_snapshot"
                statuses[row["category"]][row["status"]] += 1
                if row["status"] != "matches_B":
                    exceptions[row["category"]].append(row)
                zipped.write((json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode())
    assert sum(statuses["rust_validation_03"].values()) == 165175
    assert blob_data["external/pkl"][rust_manifest["external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input-helper/globtest/childlinked"]["origin"]["oid"]]["sha256"] == rust_manifest["external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input-helper/globtest/childlinked"]["sha256"]
    source_manifests = [{"category": c["label"], "path": c["manifest_path"], **c["manifest_identity"], "rows": len(c["entries"])} for c in categories]
    source_manifests.insert(0, {"category": "rust_validation_03", "path": rust_path.relative_to(ROOT).as_posix(), **digest(rust_path), "rows": len(rust_manifest)})
    report = {"schema": 1, "kind": "Actual Git-object source binding for Stage56 implementation B",
              "recorded_utc": datetime.now(timezone.utc).isoformat(), "B_commit": commit,
              "gitlinks": PINNED, "Git_object_method": "Actual B and pinned-submodule tree OIDs, mode, Git blob SHA1 framing, and raw blob SHA256/size; unique blob reads deduplicated, every input row accounted.",
              "manifest_rows": source_manifests, "category_statuses": {k: dict(v) for k, v in statuses.items()},
              "exceptions": dict(exceptions), "unique_blob_objects_read": {k: len(v) for k, v in blob_data.items()},
              "rust_captured_files_verified": copied,
              "rust_symlink_target_mode_120000_verified": True,
              "row_details": {"path": row_path.relative_to(ROOT).as_posix(), **digest(row_path)},
              "artifact_boundaries": {
                  "release_class_helper_sha256": "84548c956e549404967a7ead18be5c93d34988fca51be630a41a9e56ec713a9e",
                  "candidate_archive": digest(ROOT / "reports/m2/stage56-candidate-evidence.tar.gz"),
                  "original_archive": digest(ROOT / "reports/m2/stage56-original-evidence.tar.gz"),
                  "validation_archive": digest(ROOT / "reports/m2/stage56-validation-evidence.tar.gz")},
              "historical_A2_binding": {"path": "target/m2/stage56-metadata-checkpoint-publication-01/source-binding.json",
                                        **digest(ROOT / "target/m2/stage56-metadata-checkpoint-publication-01/source-binding.json")},
              "limitations": ["Historical snapshots that differ from B are listed as differences, never bound as matching B.",
                              "Source/object binding does not rerun guests, builds, tests or establish full Class API, M2 compatibility, browser release coverage, or speed/memory targets."]}
    (OUT / "report.json").write_bytes(encoded(report))
    # Compact sealed archive; existing large capture archives are referenced by SHA256.
    payloads = {"report.json": OUT / "report.json", "rows.jsonl.gz": row_path,
                "binder.py": Path(__file__),
                "A2-source-binding.json": ROOT / "target/m2/stage56-metadata-checkpoint-publication-01/source-binding.json"}
    inventory = {name: digest(path) for name, path in payloads.items()}
    manifest = encoded({"schema": 1, "files": inventory})
    with ARCHIVE.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w|") as tar:
                for name, path in [("manifest.json", None), *sorted(payloads.items())]:
                    data = manifest if path is None else None
                    size = len(data) if data is not None else inventory[name]["bytes"]
                    entry = tarfile.TarInfo(name)
                    entry.mode = 0o644
                    entry.size = size
                    with io.BytesIO(data) if data is not None else path.open("rb") as stream:
                        tar.addfile(entry, stream)
    seen = {}
    with tarfile.open(ARCHIVE, "r:gz") as tar:
        for member in tar:
            assert member.isfile() and member.name not in seen
            h = hashlib.sha256()
            size = 0
            stream = tar.extractfile(member)
            while block := stream.read(1024 * 1024):
                h.update(block)
                size += len(block)
            seen[member.name] = {"sha256": h.hexdigest(), "bytes": size}
    assert seen.pop("manifest.json") == {"sha256": hashlib.sha256(manifest).hexdigest(), "bytes": len(manifest)}
    assert seen == inventory
    assert {name: digest(path) for name, path in payloads.items()} == inventory
    publication = {"schema": 1, "binding_report": report,
                   "evidence_archive": {"path": ARCHIVE.relative_to(ROOT).as_posix(), **digest(ARCHIVE), "members": len(seen) + 1},
                   "archive_full_reread_verified": True, "original_source_stability_verified": True}
    REPORT.write_bytes(encoded(publication))
    print(json.dumps({"B_commit": commit, "category_statuses": publication["binding_report"]["category_statuses"],
                      "archive": publication["evidence_archive"], "report_sha256": digest(REPORT)["sha256"]}, indent=2))


_TREE_CACHE = {}
def tree_cache_historical(commit):
    if commit not in _TREE_CACHE:
        _TREE_CACHE[commit] = tree(ROOT, commit)
    return _TREE_CACHE[commit]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--commit", required=True, help="Actual, explicitly supplied implementation B commit SHA1")
    main(parser.parse_args().commit)
