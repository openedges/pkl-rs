"""Acquire and independently verify exact-commit M1/M2 GitHub CI evidence.

Only target files are written. Captured project verifiers are imported after
their source bytes are checked against the requested commit. Captured binaries
are hashed, never executed. Counts come from those frozen contracts.
"""
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
import argparse
import hashlib
import importlib
import importlib.util
import json
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import shutil
import stat
import subprocess
import sys
import time
import zipfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPOSITORY = HERE.parents[2]
NAMES = {'m1': 'm1-experiment-evidence', 'm2': 'm2-language-evidence'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def relative(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or '..' in path.parts or '\\' in name or PureWindowsPath(name).drive:
        raise ValueError('Unsafe relative evidence path: ' + str(name))
    return path


def safe_extract(archive_path, destination):
    destination.mkdir(parents=True, exist_ok=False)
    names, total = set(), 0
    with zipfile.ZipFile(archive_path) as archive:
        for member in archive.infolist():
            path = relative(member.filename)
            mode = member.external_attr >> 16
            if member.filename in names or stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise ValueError('Duplicate or special ZIP member: ' + member.filename)
            names.add(member.filename)
            total += member.file_size
            if total > 1_073_741_824:
                raise ValueError('Evidence ZIP exceeds 1 GiB uncompressed acquisition bound')
            target = destination / path
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member) as source, target.open('xb') as stream:
                    shutil.copyfileobj(source, stream)
    if not names:
        raise ValueError('Empty evidence ZIP')
    return dict(members=len(names), uncompressed_bytes=total)


class Context:
    def __init__(self, repository, commit, output):
        self.repository, self.commit, self.output = repository, commit, output
        self.overlay = output / 'verified-sources'
        self.index = output / 'committed-path-index'
        self.overlay.mkdir(parents=True, exist_ok=False)
        self.index.mkdir()
        self.snapshot_checks, self.modules, self.snapshot_files = [], {}, {}
        resolved = self.git('rev-parse', '--verify', commit + '^{commit}').decode().strip()
        if not re.fullmatch('[0-9a-f]{40}', commit) or resolved != commit:
            raise ValueError('An exact full Git commit SHA is required')
        self.paths = self.git('ls-tree', '-r', '--name-only', commit).decode().splitlines()
        # Empty placeholders are used solely to enumerate the exact committed
        # path set with the frozen source_paths functions. They are never loaded.
        for name in self.paths:
            if name in ('external/pkl', 'external/pkl-pantry'):
                continue
            destination = self.index / relative(name)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.touch()

    def git(self, *arguments):
        return subprocess.run(['git', *arguments], cwd=self.repository, capture_output=True,
                              check=True, timeout=60).stdout

    @lru_cache(maxsize=None)
    def git_bytes(self, name):
        relative(name)
        if name.startswith('external/pkl/'):
            revision = self.git('rev-parse', self.commit + ':external/pkl').decode().strip()
            return subprocess.run(['git', '-C', str(self.repository / 'external/pkl'), 'show',
                                   revision + ':' + name.removeprefix('external/pkl/')],
                                  check=True, capture_output=True, timeout=60).stdout
        return self.git('show', self.commit + ':' + name)

    def snapshot_identity(self, path, name, digest):
        destination = self.overlay / relative(name)
        data = path.read_bytes()
        if hashlib.sha256(data).hexdigest() != digest or data != self.git_bytes(name):
            raise ValueError('Snapshot differs from exact commit: ' + name)
        if destination.exists() and destination.read_bytes() != data:
            raise ValueError('Conflicting suite snapshots: ' + name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        self.snapshot_files[str(path.resolve())] = name
        self.snapshot_checks.append(name)

    def support(self, name):
        """An explicitly identified committed support file, not a CI snapshot."""
        destination = self.overlay / relative(name)
        data = self.git_bytes(name)
        if destination.exists() and destination.read_bytes() != data:
            raise ValueError('Committed support differs from snapshot: ' + name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)

    def verify_oracle(self, metadata):
        lock_bytes = self.git_bytes('oracle.lock.json')
        lock = json.loads(lock_bytes)
        if (metadata['profile'] != 'reference' or metadata['version'] != lock['version']
                or metadata['lock_sha256'] != hashlib.sha256(lock_bytes).hexdigest()
                or metadata['artifact_sha256'] != lock['artifact']['sha256']
                or metadata['source'] != lock['source']
                or any(metadata['jdk']['properties'].get(key) != value for key, value in lock['jdk']['properties'].items())):
            raise ValueError('Oracle provenance differs from committed pins')
        if self.git('rev-parse', self.commit + ':external/pkl').decode().strip() != metadata['source']['revision']:
            raise ValueError('Oracle source revision differs from committed gitlink')
        environment = metadata['environment']
        if (set(environment) != {'PATH', 'HOME', 'TMPDIR', 'TMP', 'TEMP', 'LC_ALL', 'LANG', 'TZ', 'TERM', 'NO_COLOR', 'COLUMNS'}
                or any(environment[key] != value for key, value in {'LC_ALL':'C', 'LANG':'C', 'TZ':'UTC', 'TERM':'dumb', 'NO_COLOR':'1', 'COLUMNS':'80'}.items())
                or not environment['TMPDIR'] == environment['TMP'] == environment['TEMP']):
            raise ValueError('Oracle controlled environment differs')
        command = [metadata['java'], *lock['jvm_options'], '-Duser.home=' + environment['HOME'],
                   '-Djava.io.tmpdir=' + environment['TMPDIR'], '-cp', metadata['artifact'], 'org.pkl.cli.Main']
        if command != metadata['command']:
            raise ValueError('Oracle JVM options, heap or classpath differ')
        for key in ['executable_sha256', 'runtime_modules_sha256', 'release_sha256']:
            if not re.fullmatch('[0-9a-f]{64}', metadata['jdk'].get(key, '')):
                raise ValueError('Exact JDK identity missing')

    def node_pin(self):
        pins = set(re.findall(r"node-version:\s*['\"]([^'\"]+)['\"]", self.git_bytes('.github/workflows/ci.yml').decode()))
        if len(pins) != 1:
            raise ValueError('Expected one unambiguous committed Node CI pin')
        return pins.pop()

    def frozen_imports(self):
        sys.path.insert(0, str(self.overlay / 'tools'))
        for name in ['m2_language', 'm2_class_lifecycle', 'm2_identifier_tables', 'm1_frontend', 'm1_host', 'm1_runtime', 'm1_lifecycle', 'm1_platforms']:
            module = importlib.import_module(name)
            if Path(module.__file__).resolve() != (self.overlay / 'tools' / (name + '.py')).resolve():
                raise ValueError('Verifier imported outside verified artifact snapshots: ' + name)
            self.modules[name] = module
        for name in ['oracle', 'benchmark', 'm2_manifest', 'm2_generate', 'm1_semantics']:
            module = sys.modules[name]
            if not Path(module.__file__).resolve().is_relative_to(self.overlay.resolve()):
                raise ValueError('Verifier dependency imported outside artifact: ' + name)


def source_maps(m1, m2):
    mappings = []
    for suite, field in [('ci-frontend','source_sha256'), ('ci-host-java','source_sha256'), ('ci-platforms','source_hashes')]:
        report = load(m1 / suite / 'report.json')
        mappings.append((m1 / suite / 'sources', report[field]))
    primitive = load(m1 / 'ci-platforms/oracle-native/report.json')
    mappings.append((m1 / 'ci-platforms/oracle-native/sources', primitive['sources']))
    lifecycle = load(m1 / 'ci-lifecycle/report.json')
    mappings.append((m1 / 'ci-lifecycle/sources', {row['path']:row['sha256'] for row in lifecycle['sources']}))
    runtime = load(m1 / 'ci-runtime/report.json')
    mappings.append((m1 / 'ci-runtime/sources', {row['snapshot'].split('/sources/',1)[1]:row['sha256'] for row in runtime['identities'] if 'snapshot' in row}))
    language = load(m2 / 'ci-language/report.json')
    mappings.append((m2 / 'ci-language/sources', language['source_sha256']))
    class_lifecycle = load(m2 / 'ci-class-lifecycle/report.json')
    mappings.append((m2 / 'ci-class-lifecycle/sources', {row['path']:row['sha256'] for row in class_lifecycle['sources']}))
    identifier = load(m2 / 'ci-identifier/report.json')
    mappings.append((m2 / 'ci-identifier/sources', identifier['sources']))
    return mappings


def exact_source_sets(context, m1, m2):
    index = context.index
    def files(prefix, pattern):
        return {str(path.relative_to(index)) for path in (index / prefix).rglob(pattern) if path.is_file()}
    language = load(m2 / 'ci-language/report.json')
    if set(language['source_sha256']) != set(context.modules['m2_language'].source_paths(index)):
        raise ValueError('M2 snapshot omits/adds exact-commit source paths')
    class_lifecycle = load(m2 / 'ci-class-lifecycle/report.json')
    if {row['path'] for row in class_lifecycle['sources']} != {str(path.relative_to(index)) for path in context.modules['m2_class_lifecycle'].source_paths(index)}:
        raise ValueError('Class lifecycle snapshot omits/adds exact-commit source paths')
    front = load(m1 / 'ci-frontend/report.json')
    front_expected = files('crates/pkl-runtime/src','*.rs') | files('crates/pkl-runtime/src','*.pkl') | {
        'crates/pkl-runtime/tests/frontend.rs','crates/pkl-runtime/Cargo.toml','Cargo.toml','Cargo.lock','rust-toolchain.toml',
        'tools/java/M1FrontendProbe.java','tools/m1_frontend.py'}
    if set(front['source_sha256']) != front_expected:
        raise ValueError('Frontend snapshot source coverage differs')
    lifecycle = context.modules['m1_lifecycle']
    saved = lifecycle.ROOT
    lifecycle.ROOT = index
    expected = {str(path.relative_to(index)) for path in lifecycle.sources()}
    lifecycle.ROOT = saved
    if {row['path'] for row in load(m1/'ci-lifecycle/report.json')['sources']} != expected:
        raise ValueError('Lifecycle source coverage differs')
    runtime = load(m1/'ci-runtime/report.json')
    expected = {'Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','oracle.lock.json','crates/pkl-runtime/Cargo.toml',
                'tools/java/M1RuntimeProbe.java','tools/m1_runtime.py','tools/tests/test_m1_runtime.py'}
    expected |= files('crates/pkl-runtime/src','*.rs') | files('crates/pkl-runtime/src','*.pkl') | files('crates/pkl-runtime/examples','*.rs')
    expected |= {str(path.relative_to(index)) for path in (index/'tests/fixtures/m1/runtime').glob('*.pkl')}
    if {row['snapshot'].split('/sources/',1)[1] for row in runtime['identities'] if 'snapshot'in row} != expected:
        raise ValueError('Runtime source coverage differs')
    platform = load(m1/'ci-platforms/report.json')
    expected = {'Cargo.toml','Cargo.lock','rust-toolchain.toml','tools/m1_platforms.py','tools/m1_semantics.py',
                'tools/java/M1SemanticsProbe.java','tests/fixtures/m1/semantics/cases.json','crates/pkl-runtime/Cargo.toml',
                'crates/pkl-runtime/examples/semantics_probe.rs'}
    for prefix in ['crates/pkl-runtime/src','crates/pkl-wasm','crates/pkl-napi','tools/platform']:
        expected |= {name for name in files(prefix,'*') if Path(name).suffix in {'.rs','.pkl','.toml','.mjs','.json'} and 'node_modules'not in Path(name).parts}
    if set(platform['source_hashes']) != expected:
        raise ValueError('Platform source coverage differs')
    expected = {'Cargo.lock','Cargo.toml','rust-toolchain.toml','crates/pkl-runtime/Cargo.toml',
                'crates/pkl-runtime/examples/semantics_probe.rs','crates/pkl-runtime/src/numeric.rs',
                'crates/pkl-runtime/src/regex.rs','tools/java/M1SemanticsProbe.java','tools/m1_semantics.py',
                'tests/fixtures/m1/semantics/references/fdlibm-s_cbrt.c'}
    expected |= {str(path.relative_to(index)) for path in (index/'tests/fixtures/m1/semantics/references').iterdir() if path.is_file()}
    if set(load(m1/'ci-platforms/oracle-native/report.json')['sources']) != expected:
        raise ValueError('Nested primitive oracle source coverage differs')
    expected = {'tools/java/M1HostProbe.java','tools/m1_host.py'}
    if set(load(m1/'ci-host-java/report.json')['source_sha256']) != expected:
        raise ValueError('Host observation source coverage differs')
    identifier = context.modules['m2_identifier_tables']
    expected = {str(identifier.PROBE),'tools/m2_identifier_tables.py','tools/oracle.py','oracle.lock.json','references.lock',
                'external/pkl/pkl-parser/src/main/java/org/pkl/parser/Lexer.java'}
    if set(load(m2/'ci-identifier/report.json')['sources']) != expected:
        raise ValueError('Identifier generator source coverage differs')


def verify_m2(context, artifact):
    directory = artifact / 'ci-language'
    report = load(directory / 'report.json')
    frozen = context.modules['m2_language']
    original = Path(report['candidate']['build']['command'][-1]).parent
    if not original.is_absolute():
        raise ValueError('Original CI ROOT is not absolute')
    frozen.ROOT = original
    context.verify_oracle(report['oracle'])
    if frozen.check_report(directory) != report or report['candidate']['source_binding'] != 'recorded-build':
        raise ValueError('Language evidence integrity/source binding failed')
    if not frozen.development_passes(report, directory):
        raise ValueError('Selected development contract failed; raw failures retained')
    identifier_dir = artifact / 'ci-identifier'
    identifier = load(identifier_dir/'report.json')
    context.verify_oracle(identifier['oracle'])
    if identifier['exit_code'] != 0 or not identifier['source_stability']:
        raise ValueError('Identifier probe failed or changed during capture')
    observed = {str(path.relative_to(identifier_dir)) for path in identifier_dir.rglob('*') if path.is_file() and path.name!='report.json'}
    if observed != set(identifier['evidence_sha256']):
        raise ValueError('Identifier evidence coverage incomplete')
    for name,digest in identifier['evidence_sha256'].items():
        if sha(identifier_dir/relative(name)) != digest:
            raise ValueError('Identifier raw evidence changed: '+name)
    tool = context.modules['m2_identifier_tables']
    raw = (identifier_dir/'stdout.bin').read_bytes()
    generated = tool.render(raw,identifier['oracle'],identifier['sources'][str(tool.PROBE)])
    if (generated != (identifier_dir/'unicode_identifier.rs').read_bytes()
            or generated != context.git_bytes(str(tool.TARGET)) or (identifier_dir/'stderr.bin').read_bytes()):
        raise ValueError('Identifier raw regeneration differs from committed table')
    counts = {key:len(value) for key,value in tool.intervals(raw).items()}
    if counts != identifier['interval_counts']:
        raise ValueError('Identifier interval count disagrees with raw transport')
    class_directory = artifact / 'ci-class-lifecycle'
    class_tool = context.modules['m2_class_lifecycle']
    class_report = class_tool.check_report(class_directory)
    context.verify_oracle(class_report['oracle'])
    if not class_tool.contract_passes(class_report):
        raise ValueError('Selected persistent class sequence contract failed')
    class_calls = [call for row in class_report['cases'] for call in row['observations']['comparisons']]
    class_result = dict(sequence_executions=len(class_report['cases']), unique_sequences=len({row['id'] for row in class_report['cases']}),
                        call_comparisons=len(class_calls), passing_calls=sum(call['status']=='pass' for call in class_calls),
                        repetitions=class_report['repetitions'], unexecuted_groups=class_report['unexecuted_groups'],
                        compatibility_complete=class_report['compatibility_complete'], selected_contract_passes=True)
    manifest = load(directory/'sources/compatibility/m2-language.json')
    expected = [row for row in manifest['cases'] if row.get('adapter')=='language-api-string']
    return dict(original_ci_root=str(original),selected_count=len(expected),raw_comparisons=report['status_counts'],class_lifecycle=class_result,
                power_profiles=sum(row.get('power_assertions',False) for row in expected),
                metamorphic_relations=len(report['metamorphic_results']),development_contract=True,
                strict_subset_complete=frozen.subset_passes(report),full_m2_complete=not bool(report['full_gate_failures']),
                full_gate_failures=len(report['full_gate_failures']),identifier_intervals=counts,
                language_evidence_files=len(report['evidence_sha256']),identifier_evidence_files=len(identifier['evidence_sha256']))


def metadata(base, kind, commit, run):
    run_file = next(path for path in [base/'run.json',base/'run-final.json'] if path.exists())
    jobs_file = next(path for path in [base/'jobs.json',base/'jobs-final.json'] if path.exists())
    workflow, jobs, artifacts = load(run_file), load(jobs_file), load(base/'artifacts.json')
    if isinstance(jobs,dict):
        if len(jobs['jobs']) != jobs['total_count']:
            raise ValueError('GitHub jobs metadata is paginated/incomplete')
        jobs=jobs['jobs']
    if isinstance(artifacts,dict): artifacts=artifacts['artifacts']
    if (workflow['id']!=run or workflow['head_sha']!=commit or workflow['status']!='completed'
            or workflow['conclusion']!='success' or not jobs or any(row['conclusion']!='success'for row in jobs)):
        raise ValueError('Exact-commit workflow/jobs did not all succeed')
    candidates=[row for row in artifacts if row['name']==NAMES[kind]]
    if len(candidates)!=1:raise ValueError('Missing/duplicate '+kind+' GitHub artifact')
    artifact=candidates[0]
    if artifact['expired'] or artifact['workflow_run']['head_sha']!=commit or artifact['workflow_run']['id']!=run:
        raise ValueError('GitHub artifact origin differs')
    archive=next(path for path in [base/'artifact.zip',base/(NAMES[kind]+'.zip')]if path.exists())
    if artifact['digest']!='sha256:'+sha(archive):raise ValueError('GitHub ZIP digest mismatch: '+kind)
    return dict(run=workflow,jobs=jobs,artifact=artifact,archive=str(archive),zip_sha256=sha(archive))


def verify(args,m1,m2,output):
    output.mkdir(parents=True,exist_ok=False)
    records={kind:metadata(base,kind,args.commit,args.run)for kind,base in [('m1',m1),('m2',m2)]}
    context=Context(args.repository_root,args.commit,output)
    first,second=m1/'artifact',m2/'artifact'
    for snapshot,mapping in source_maps(first,second):
        for name,digest in mapping.items():context.snapshot_identity(snapshot/relative(name),name,digest)
    # The frontend runner retains its fixture contract, but its source snapshot
    # excludes fixture files. Supply these separately from the exact Git commit.
    for name in context.paths:
        if name.startswith('tests/fixtures/m1/frontend/'):context.support(name)
    context.frozen_imports()
    exact_source_sets(context,first,second)
    m2_result=verify_m2(context,second)
    spec=importlib.util.spec_from_file_location('independent_m1_checks',HERE/'m1_checks.py')
    checks=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(checks)
    m1_result=checks.verify(first,context)
    if any(path.name=='__pycache__'for root in [first,second]for path in root.rglob('__pycache__')):
        raise ValueError('Verification mutated an evidence tree with Python bytecode')
    result=dict(schema_version=1,commit=args.commit,run_id=args.run,repository=args.repo,
        scope='Independent exact-commit CI raw evidence verification; remaining language/API/performance scope and recorded mismatches remain incomplete.',
        artifacts={kind:dict(id=row['artifact']['id'],name=row['artifact']['name'],sha256=row['zip_sha256'],github_digest_verified=True)for kind,row in records.items()},
        jobs=[dict(name=row['name'],conclusion=row['conclusion'])for row in records['m2']['jobs']],
        exact_source_snapshot_copies=len(context.snapshot_files),unique_source_files=len(set(context.snapshot_files.values())),
        verifiers={path.name:sha(path)for path in [Path(__file__),HERE/'m1_checks.py']},
        frozen_verifiers={name:dict(path=str(module.__file__),sha256=sha(Path(module.__file__)))for name,module in context.modules.items()},
        m2=m2_result,m1=m1_result)
    write(output/'verification.json',result)
    print(json.dumps(result,sort_keys=True),flush=True)


def api(args,endpoint,path,timeout=180):
    process=subprocess.run(['gh','api',endpoint],cwd=args.repository_root,capture_output=True,timeout=timeout)
    with path.open('xb')as stream:stream.write(process.stdout)
    if process.stderr:path.with_suffix(path.suffix+'.stderr.bin').write_bytes(process.stderr)
    if process.returncode:raise ValueError('GitHub API failed: '+endpoint)
    return path


def acquire(args):
    args.output.mkdir(parents=True,exist_ok=False)
    iteration=0
    while True:
        prefix=f'repos/{args.repo}/actions/runs/{args.run}'
        names=['run','jobs','artifacts']
        endpoints=[prefix,prefix+'/jobs?per_page=100',prefix+'/artifacts?per_page=100']
        with ThreadPoolExecutor(max_workers=3)as pool:
            paths=list(pool.map(lambda pair:api(args,pair[0],args.output/(f'poll-{iteration:03}-'+pair[1]+'.json'),timeout=45),zip(endpoints,names)))
        run,jobs,artifacts=map(load,paths)
        if run['head_sha']!=args.commit:raise ValueError('CI head differs from requested commit')
        failures=[row['name']for row in jobs['jobs']if row['conclusion']in {'failure','cancelled','timed_out','action_required'}]
        print(json.dumps(dict(status=run['status'],conclusion=run['conclusion'],failed_jobs=failures)),flush=True)
        if failures:raise ValueError('CI job failed: '+', '.join(failures))
        if run['status']=='completed':break
        if not args.wait:return 3
        iteration+=1
        time.sleep(30)
    if run['conclusion']!='success':raise ValueError('CI did not succeed')
    for kind,name in NAMES.items():
        base=args.output/kind
        base.mkdir()
        for path,label in zip(paths,names):shutil.copyfile(path,base/(label+'.json'))
        candidates=[row for row in artifacts['artifacts']if row['name']==name]
        if len(candidates)!=1:raise ValueError('Missing/duplicate artifact: '+name)
        artifact=candidates[0]
        archive=api(args,f"repos/{args.repo}/actions/artifacts/{artifact['id']}/zip",base/'artifact.zip')
        if artifact['digest']!='sha256:'+sha(archive):raise ValueError('GitHub artifact ZIP digest mismatch')
        safe_extract(archive,base/'artifact')
    verify(args,args.output/'m1',args.output/'m2',args.output/'verification')
    return 0


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['acquire','verify'])
    parser.add_argument('--commit',required=True)
    parser.add_argument('--run',required=True,type=int)
    parser.add_argument('--repo',default='luuvish/pkl-rs')
    parser.add_argument('--repository-root',type=Path,default=REPOSITORY)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--m1-directory',type=Path)
    parser.add_argument('--m2-directory',type=Path)
    parser.add_argument('--wait',action='store_true',help='poll every30s; each tool caller can yield while this runs')
    args=parser.parse_args()
    args.repository_root=args.repository_root.resolve()
    args.output=args.output.resolve()
    if args.action=='acquire':return acquire(args)
    if not args.m1_directory or not args.m2_directory:parser.error('verify requires both downloaded artifact directories')
    verify(args,args.m1_directory.resolve(),args.m2_directory.resolve(),args.output)
    return 0


if __name__=='__main__':
    try:sys.exit(main())
    except Exception as error:
        print('CI artifact verification failed: '+str(error),file=sys.stderr)
        raise
