"""Target-only regression checks for archive and artifact corruption rejection."""
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import Mock
import unittest
import zipfile

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('stage12_verifier',HERE/'verify.py')
verifier=importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)


class VerificationTests(unittest.TestCase):
    def test_archive_parent_absolute_drive_and_symlink_members_fail(self):
        for name in ['../escape','/absolute','C:/drive','a\\escape','link']:
            with self.subTest(name=name),tempfile.TemporaryDirectory()as temporary:
                base=Path(temporary)
                with zipfile.ZipFile(base/'artifact.zip','w')as archive:
                    info=zipfile.ZipInfo(name)
                    if name=='link':info.external_attr=(stat.S_IFLNK|0o777)<<16
                    archive.writestr(info,b'payload')
                with self.assertRaises(ValueError):verifier.safe_extract(base/'artifact.zip',base/'artifact')

    def test_exact_github_digest_commit_and_complete_jobs_are_required(self):
        with tempfile.TemporaryDirectory()as temporary:
            base=Path(temporary)
            commit='a'*40
            run=dict(id=1,head_sha=commit,status='completed',conclusion='success')
            jobs=dict(total_count=1,jobs=[dict(name='required',conclusion='success')])
            archive=base/'artifact.zip'
            archive.write_bytes(b'raw ZIP transport bytes')
            row=dict(name=verifier.NAMES['m2'],id=1,expired=False,workflow_run=dict(head_sha=commit,id=1),digest='sha256:'+hashlib.sha256(archive.read_bytes()).hexdigest())
            def save():
                for name,value in [('run',run),('jobs',jobs),('artifacts',dict(artifacts=[row]))]:
                    (base/(name+'.json')).write_text(json.dumps(value))
            save()
            verifier.metadata(base,'m2',commit,1)
            archive.write_bytes(b'corrupted')
            with self.assertRaises(ValueError):verifier.metadata(base,'m2',commit,1)
            archive.write_bytes(b'raw ZIP transport bytes')
            run['head_sha']='b'*40
            save()
            with self.assertRaises(ValueError):verifier.metadata(base,'m2',commit,1)
            run['head_sha']=commit
            jobs['total_count']=2
            save()
            with self.assertRaises(ValueError):verifier.metadata(base,'m2',commit,1)
            jobs['total_count']=1
            jobs['jobs'][0]['conclusion']='failure'
            save()
            with self.assertRaises(ValueError):verifier.metadata(base,'m2',commit,1)

    def test_class_sequence_frozen_integrity_and_contract_gate_are_both_required(self):
        with tempfile.TemporaryDirectory() as temporary:
            artifact = Path(temporary)
            language_dir = artifact / 'ci-language'
            (language_dir / 'sources/compatibility').mkdir(parents=True)
            language = dict(candidate=dict(build=dict(command=['build', '/ci/root/Cargo.toml']),
                                            source_binding='recorded-build'), oracle={'suite': 'language'},
                            status_counts={'pass': 2, 'mismatch': 1}, metamorphic_results=[],
                            full_gate_failures=['unimplemented'], evidence_sha256={})
            (language_dir / 'report.json').write_text(json.dumps(language))
            (language_dir / 'sources/compatibility/m2-language.json').write_text(json.dumps(
                dict(cases=[dict(adapter='language-api-string'), dict(adapter='blocked')])) )
            identifier_dir = artifact / 'ci-identifier'
            identifier_dir.mkdir()
            for name, data in [('stdout.bin', b'intervals'), ('stderr.bin', b''),
                               ('unicode_identifier.rs', b'table')]:
                (identifier_dir / name).write_bytes(data)
            identifier = dict(oracle={'suite': 'identifier'}, exit_code=0, source_stability=True,
                              evidence_sha256={name: verifier.sha(identifier_dir / name)
                                  for name in ['stdout.bin', 'stderr.bin', 'unicode_identifier.rs']},
                              sources={'Probe.java': 'pinned-probe'}, interval_counts={'start': 1})
            (identifier_dir / 'report.json').write_text(json.dumps(identifier))
            calls = lambda count: [dict(status='pass') for _ in range(count)]
            classes = dict(oracle={'suite': 'class'}, cases=[
                dict(id='one', observations=dict(comparisons=calls(2))),
                dict(id='one', observations=dict(comparisons=calls(3)))], repetitions=2,
                unexecuted_groups=[dict(group='P11', reason='unsupported annotations')],
                compatibility_complete=False)
            class_tool = SimpleNamespace(check_report=Mock(return_value=classes),
                                         contract_passes=Mock(return_value=True))
            context = SimpleNamespace(verify_oracle=Mock(), git_bytes=Mock(return_value=b'table'),
                modules={'m2_language': SimpleNamespace(check_report=Mock(return_value=language),
                    development_passes=Mock(return_value=True), subset_passes=Mock(return_value=False)),
                    'm2_identifier_tables': SimpleNamespace(PROBE=Path('Probe.java'), TARGET=Path('table.rs'),
                        render=Mock(return_value=b'table'), intervals=Mock(return_value={'start': [(0, 1)]})),
                    'm2_class_lifecycle': class_tool})
            result = verifier.verify_m2(context, artifact)
            class_tool.check_report.assert_called_once_with(artifact / 'ci-class-lifecycle')
            class_tool.contract_passes.assert_called_once_with(classes)
            self.assertEqual(context.verify_oracle.call_args_list[-1].args, ({'suite': 'class'},))
            self.assertEqual(result['class_lifecycle']['sequence_executions'], 2)
            self.assertEqual(result['class_lifecycle']['unique_sequences'], 1)
            self.assertEqual(result['class_lifecycle']['call_comparisons'], 5)
            self.assertEqual(result['class_lifecycle']['passing_calls'], 5)
            self.assertFalse(result['class_lifecycle']['compatibility_complete'])
            self.assertEqual(result['class_lifecycle']['unexecuted_groups'], classes['unexecuted_groups'])
            class_tool.contract_passes.return_value = False
            with self.assertRaisesRegex(ValueError, 'persistent class sequence contract'):
                verifier.verify_m2(context, artifact)
            class_tool.contract_passes.return_value = True
            class_tool.check_report.side_effect = ValueError('changed raw bytes')
            with self.assertRaisesRegex(ValueError, 'changed raw bytes'):
                verifier.verify_m2(context, artifact)


if __name__=='__main__':unittest.main()
