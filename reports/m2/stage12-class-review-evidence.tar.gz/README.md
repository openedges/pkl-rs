# Review-only local-tail oracle error

This read-only probe uses the frozen Stage12 class acquisition artifacts and the same fixed module URI. It is outside the18selected persistent sequences and is not a passing compatibility comparison.

The first call reports the same fixed-override error in both implementations; the second call returns `true`. The third call reads an earlier property whose body refers to a local declared after the failed override. Java0.32.0 raises an internal `PklBugException` (`Couldn't find local variable lateLocal`), while Rust reports a normal missing-property error. Complete statuses, diagnostics and process captures are retained. This remains an unclosed Java-internal-error diagnostic scope, with no development exception or production fix inferred.

`provenance.json` identifies the frozen acquisition report, exact source snapshots, oracle/JDK, copied class/native artifacts and source/input hashes. Copied probe sources and executables allow review without replacing the already verified main class-publication archive. No captured executable must be run to verify this archive's checksum inventory.
