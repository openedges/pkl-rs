from pathlib import Path
import json,hashlib,subprocess,collections,sys
ROOT=Path.cwd();BASE=ROOT.parent/'pkl-rs.stage44/target/m2';OLD=ROOT.parent/'pkl-rs.stage42/target/m2';OUT=ROOT/'target/m2/stage44-final-audit-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
def tree(repo,rev):
 result={}
 for record in subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','-z',rev]).split(b'\0'):
  if not record:continue
  meta,path=record.split(b'\t');mode,kind,oid=meta.decode().split();result[path.decode()]=(mode,kind,oid)
 return result
impl='c9b140a47ab7ddae76233c14ed5d003aa88dfc13';checkout='a19619cad402674bfed2b084e3b638e6f69f9093'
refs={'external/pkl':'e51fb2f91774265666f94980ec630db794a4db2d','external/pkl-pantry':'904a68184e54da378b0a0e8a911a3fab3956f693'}
trees={impl:tree(ROOT,impl),checkout:tree(ROOT,checkout),**{name:tree(ROOT/name,rev) for name,rev in refs.items()}}
langdir=BASE/'stage44-language-final-01';lifedir=BASE/'stage44-class-lifecycle-final-01';lang=load(langdir/'report.json');life=load(lifedir/'report.json')
report={'scope':'Read-only raw/source audit of the completed Stage44 selected language and lifecycle captures; full M2 remains incomplete.','implementation_commit':impl,'recorded_checkout':checkout,'references':refs,'complete':False,'raw':{},'issues':[]}
save('report.json',report)
try:
 for name,root,data in [('language',langdir,lang),('lifecycle',lifedir,life)]:
  rows=data['evidence_sha256']
  for path,digest in rows.items():
   rel=Path(path);assert not rel.is_absolute() and '..' not in rel.parts
   assert 'build' not in rel.parts or not path.startswith('build/'),path
   assert not (root/rel).is_symlink() and sha(root/rel)==digest,path
  report['raw'][name]={'report_sha256':sha(root/'report.json'),'declared_payloads_verified':len(rows)}
  save('report.json',report)
 bindings={}
 captures=[(langdir,path,'sources/'+path,digest) for path,digest in lang['source_sha256'].items()]
 captures +=[(lifedir,row['path'],row['snapshot'],row['sha256']) for row in life['sources']]
 for root,path,snapshot,digest in captures:
  data=(root/snapshot).read_bytes();assert hashlib.sha256(data).hexdigest()==digest
  blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  keys=[name for name in refs if path.startswith(name+'/')]
  if keys:
   ref=keys[0];gitpath=path[len(ref)+1:];expected=trees[ref][gitpath];assert expected[1:] == ('blob',blob),(path,blob,expected)
   owner=refs[ref]
  else:
   for rev in [impl,checkout]:assert trees[rev][path][1:] == ('blob',blob),(rev,path,blob,trees[rev].get(path))
   owner=impl
  if path in bindings:assert bindings[path]['sha256']==digest
  bindings[path]={'sha256':digest,'git_blob':blob,'commit':owner}
 save('source-map.json',bindings)
 report['source_binding']={'captured_records':len(captures),'unique_paths':len(bindings),'source_map_sha256':sha(OUT/'source-map.json'),'all_match':True}
 oldlang=load(OLD/'stage42-language-final-02/report.json'); oldlife=load(OLD/'stage42-class-lifecycle-final-02/report.json')
 newmanifest=load(langdir/'sources/compatibility/m2-language.json'); oldmanifest=load(OLD/'stage42-language-final-02/sources/compatibility/m2-language.json')
 assert newmanifest['cases']==oldmanifest['cases']
 assert lang['selection']==oldlang['selection']
 oldstatuses={r['id']:r['status'] for r in oldlang['results']};newstatuses={r['id']:r['status'] for r in lang['results']};assert oldstatuses.keys()==newstatuses.keys()
 changes=[{'id':i,'old':oldstatuses[i],'new':newstatuses[i]} for i in oldstatuses if oldstatuses[i]!=newstatuses[i]]
 rawchanges={}
 for name,root,data,oldroot,olddata in [('language',langdir,lang,OLD/'stage42-language-final-02',oldlang),('lifecycle',lifedir,life,OLD/'stage42-class-lifecycle-final-02',oldlife)]:
  oldmap=olddata['evidence_sha256'];newmap=data['evidence_sha256']; paths=set(oldmap)&set(newmap)
  changed=[p for p in sorted(paths) if p.endswith(('.bin',)) and oldmap[p]!=newmap[p]]
  rawchanges[name]={'changed_common_bin_paths':changed,'added_bin_paths':[p for p in sorted(set(newmap)-set(oldmap)) if p.endswith('.bin')],'removed_bin_paths':[p for p in sorted(set(oldmap)-set(newmap)) if p.endswith('.bin')],'note':'Exact hash differences only; no path/message normalization or implied compatibility.'}
 save('raw-changes.json',rawchanges)
 totals={language:collections.Counter() for language in ['java','rust']};calls=0
 for row in life['cases']:
  for comp in row['observations']['comparisons']:assert comp['status']=='pass' and comp['raw_equal'] is True;calls+=1
  for language in totals:
   totals[language].update(c['status'] for c in row['observations']['processes'][language]['calls'])
 assert life['comparison_channels']==['status','stdout','stderr']
 assert lang['source_stability'] and lang['artifact_stability'];assert life['source_stability_before_execution'] and life['source_stability_after_execution'];assert life['acquisition_error'] is None
 driver=load(BASE/'stage44-full-regression-continuation-01/process-report.json');assert driver['complete']
 for row in driver['commands']:
  for channel in ['stdout','stderr']:assert sha(BASE/'stage44-full-regression-continuation-01'/row[channel]['path'])==row[channel]['sha256']
 report.update(complete=True,selected=lang['selected_count'],status_counts=lang['status_counts'],full_gate_failure_reasons=len(lang['full_gate_failures']),all_case_definitions_unchanged=len(newmanifest['cases']),status_changes=changes,source_stable=True,artifact_stable=True,persistent_sequence_executions=len(life['cases']),persistent_calls_each_language=calls,persistent_statuses={k:dict(v) for k,v in totals.items()},persistent_comparison_channels=life['comparison_channels'],metamorphic_relations=len(lang['metamorphic_results']),raw_changes_sha256=sha(OUT/'raw-changes.json'),gates={r['label']:r['returncode'] for r in driver['commands']},original_language_acquisition_returncode=None,orchestration_recovery='Original wrapper stopped without terminal capture. Original reports/stdout preserved. Continuation verified completed language evidence without reacquisition, then acquired and verified lifecycle.',full_m2_complete=False)
 save('report.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['issues','raw','references']},indent=2))
except BaseException as error:
 report['issues'].append(repr(error));save('report.json',report);raise
