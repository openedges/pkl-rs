from pathlib import Path
import datetime,hashlib,json,os,platform,subprocess,sys,time
repo=Path.cwd();root=Path(__file__).resolve().parent
language=repo/"target/m2/stage44-language-final-01"
lifecycle=repo/"target/m2/stage44-class-lifecycle-final-01"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,data):(root/name).write_text(json.dumps(data,indent=2)+"\n")
report={"scope":"Full selected Stage44 development regression, not full M2 completion.","cwd":str(repo),"startedUtc":now(),"python":sys.executable,"pythonVersion":sys.version,"platform":platform.platform(),"commands":[],"complete":False,"relevantEnvironment":{k:os.environ.get(k) for k in ["PATH","HOME","TMPDIR","LANG","LC_ALL","CARGO_HOME","RUSTUP_HOME","RUSTUP_TOOLCHAIN","RUSTFLAGS","CARGO_TARGET_DIR","RUSTC","RUSTC_WRAPPER"]}}
save("process-report.json",report)
def run(label,args):
 command=[sys.executable,*args]
 row={"label":label,"command":command,"cwd":str(repo),"startedUtc":now()}
 save("active.json",row);print("START "+label,flush=True);start=time.monotonic()
 out=root/(label+".stdout.bin");err=root/(label+".stderr.bin")
 with out.open("wb") as stdout,err.open("wb") as stderr:
  process=subprocess.Popen(command,cwd=repo,stdout=stdout,stderr=stderr)
  row["pid"]=process.pid;save("active.json",row)
  result=process.wait()
 row.update(returncode=result,seconds=time.monotonic()-start,finishedUtc=now(),stdout={"path":out.name,"bytes":out.stat().st_size,"sha256":sha(out)},stderr={"path":err.name,"bytes":err.stat().st_size,"sha256":sha(err)})
 report["commands"].append(row);save("process-report.json",report);print("FINISH "+label+" "+str(result),flush=True)
 return result

for name in ["report","development","subset","full"]:
 run("language-verify-"+name,["tools/m2_language.py","--verify-"+name,str(language)])
run("lifecycle-acquire",["tools/m2_class_lifecycle.py","--output",str(lifecycle),"--record-only"])
for name in ["report","contract"]:
 run("lifecycle-verify-"+name,["tools/m2_class_lifecycle.py","--verify-"+name,str(lifecycle)])
report["complete"]=True;report["finishedUtc"]=now()
report["returncodeSemantics"]="Acquisition/integrity must succeed; strict compatibility gates retain their actual nonzero failures."
report["toolReports"]={str(p.relative_to(repo)):{"exists":p.is_file(),"sha256":sha(p) if p.is_file() else None} for p in [language/"report.json",lifecycle/"report.json"]}
save("process-report.json",report)
required={"language-verify-report","lifecycle-acquire","lifecycle-verify-report"}
failed=[r["label"] for r in report["commands"] if r["label"] in required and r["returncode"]!=0]
print(json.dumps({"complete":True,"infrastructureFailures":failed,"returncodes":{r["label"]:r["returncode"] for r in report["commands"]}}),flush=True)
raise SystemExit(bool(failed))
