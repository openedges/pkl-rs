"""Pair the frozen ordinary language adapter with preserved original Java runs."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
FIX=ROOT/'tests/fixtures/m2-collection-transforms'
BUILD=ROOT/'target/m2/stage51-candidate03-build'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
assert not (OUT/'report.json').exists()
inputs={}
def pin(p):inputs[str(p)]=sha(p);return p
pin(Path(__file__))
report={'scope':'Original SourceCode regression through the ordinary language adapter at the same physical input as the two preserved Java observations. No whole M2 runner or new Java acquisition claim.',
        'startedUtc':now(),'commands':[],'complete':False}
save('report.json',report)
try:
    verifier=pin(ROOT/'tools/collection_transform_fixtures.py')
    with (OUT/'preflight.stdout.bin').open('wb') as stdout,(OUT/'preflight.stderr.bin').open('wb') as stderr:
        c=subprocess.run([sys.executable,'-B',str(verifier),'--fixtures',str(FIX)],cwd=ROOT,stdout=stdout,stderr=stderr)
    report['preflightExitCode']=c.returncode;assert c.returncode==0
    before=json.loads(pin(BUILD/'report.json').read_bytes());proof=json.loads(pin(BUILD/'build-proof.json').read_bytes())
    assert before['complete'] and before['sourceStable'] and sha(BUILD/'build-proof.json')==before['buildProofSha256']
    for name,digest in proof['sources'].items():assert sha(pin(Path(proof['snapshotRoot'])/name))==digest
    executable=pin(Path(before['languageProbe']['path']));assert sha(executable)==before['languageProbe']['sha256']
    provenance=FIX/'provenance/java01'
    binding=json.loads(pin(provenance/'original-binding.json').read_bytes())
    source=pin(Path(binding['copiedPath']))
    original=pin(ROOT/'tests/fixtures/m2/annotation-stage35-builtin-source-code-union-and-string.pkl')
    assert source.read_bytes()==original.read_bytes() and sha(source)==binding['sha256']
    manifest=json.loads(pin(ROOT/'compatibility/m2-language.json').read_bytes())
    case=next(c for c in manifest['cases'] if c['id']=='annotation-stage35-builtin-source-code-union-and-string')
    assert case['adapter']=='language-api-string' and case['expression']=='result' and case['input_sha256']==sha(source)
    java=json.loads(pin(provenance/'report.json').read_bytes())['originalAdapterProcesses'];assert len(java)==2
    for index,prior in enumerate(java):
        expected=provenance/'original-adapter'/str(index)
        for channel in ['stdout','stderr']:
            assert sha(pin(expected/(channel+'.bin')))==prior[channel+'Sha256']
        assert pin(expected/'outcome.bin').read_bytes()==b'success\n'
        assert prior['exitCode']==0 and not prior['timedOut']
        assert prior['command'][-3:]==['M2LanguageProbe',str(source),'result']
        argv=[str(executable),str(source),'result'];row={'argv':argv,'cwd':prior['cwd'],'environment':prior['environment'],'startedUtc':now()}
        with (OUT/f'rust-{index}.stdout.bin').open('wb') as stdout,(OUT/f'rust-{index}.stderr.bin').open('wb') as stderr:
            child=subprocess.Popen(argv,cwd=prior['cwd'],env=prior['environment'],stdout=stdout,stderr=stderr);row['pid']=child.pid;row['exitCode']=child.wait()
        row['finishedUtc']=now();row['rawMatches']={channel:(OUT/f'rust-{index}.{channel}.bin').read_bytes()==(expected/(channel+'.bin')).read_bytes() for channel in ['stdout','stderr']}
        row['exitMatches']=row['exitCode']==prior['exitCode'];report['commands'].append(row);save('report.json',report)
    report['changedInputs']=[name for name,digest in inputs.items() if sha(Path(name))!=digest]
    report['complete']=True;report['passed']=not report['changedInputs'] and all(r['exitMatches'] and all(r['rawMatches'].values()) for r in report['commands'])
except Exception as error:report['error']=repr(error);report['passed']=False
finally:save('inputs.json',inputs);report['finishedUtc']=now();save('report.json',report);print(json.dumps(report),flush=True)
raise SystemExit(0 if report['passed'] else 1)
