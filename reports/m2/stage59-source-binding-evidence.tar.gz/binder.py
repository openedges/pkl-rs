"""Bind frozen Stage 59 source evidence to an explicitly supplied implementation B commit.

Prepared before B. Execute only after the root agent supplies --commit and GO.
This reads Git objects and recorded evidence; it does not run builds or tests.
Earlier Stage 59 platform wrappers 01/02 and comparison wrapper 01 remain
historical evidence with their recorded failures;
only the final manifests below are compared with B-current source bytes.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'target/m2/stage59-source-binding-02'
PUBLIC = ROOT / 'reports/m2/stage59-source-binding.json'
ARCHIVE = ROOT / 'reports/m2/stage59-source-binding-evidence.tar.gz'
BASE = '6433bcda2ba034f3dd56ce60e1ff45cca059c77b'
HISTORICAL_BASE_DOCS = {'PLAN.md', 'README.md', 'TESTING.md', 'docs/m2-language.md'}
ARCHIVED_TOOL_WRAPPER = 'target/m2/stage59-tool-validation-02/run.py'
PIN = {
    'external/pkl': 'e51fb2f91774265666f94980ec630db794a4db2d',
    'external/pkl-pantry': '904a68184e54da378b0a0e8a911a3fab3956f693',
}
MANIFESTS = {
    'rust_validation': 'target/m2/stage59-rust-validation-01/sources.json',
    'native_build': 'target/m2/stage59-native-build-01/source-before.json',
    'm1_platforms': 'target/m2/stage59-m1-platform-contract-03/sources.json',
    'platform_wrapper': 'target/m2/stage59-platform-validation-03/source-before.json',
    'original_duration': 'target/m2/stage59-original-duration-01/sources.json',
    'comparison_wrapper': 'target/m2/stage59-comparison-validation-02/source-before.json',
    'tool_validation': 'target/m2/stage59-tool-validation-02/source-before.json',
}
SOURCE_COPIES = {
    'native_build': 'target/m2/stage59-native-build-01/sources',
    'm1_platforms': 'target/m2/stage59-m1-platform-contract-03/sources',
    'platform_wrapper': 'target/m2/stage59-platform-validation-03/sources',
    'original_duration': 'target/m2/stage59-original-duration-01/sources',
    'comparison_wrapper': 'target/m2/stage59-comparison-validation-02/sources',
    'tool_validation': 'target/m2/stage59-tool-validation-02/sources',
}
PUBLIC_ARCHIVES = {
    'validation': 'reports/m2/stage59-validation-evidence.tar.gz',
    'native': 'reports/m2/stage59-native-evidence.tar.gz',
    'platform': 'reports/m2/stage59-platform-evidence.tar.gz',
    'closeout': 'reports/m2/stage59-closeout-evidence.tar.gz',
}
ARCHIVED_COPIES = {
    'rust_validation': ('validation', 'target/m2/stage59-rust-validation-01/sources/', 'captured-only'),
    'native_build': ('native', 'target/m2/stage59-native-build-01/sources/', 'all'),
    'm1_platforms': ('platform', 'target/m2/stage59-m1-platform-contract-03/sources/', 'all'),
    'platform_wrapper': ('platform', 'target/m2/stage59-platform-validation-03/sources/', 'all'),
    'original_duration': ('closeout', 'target/m2/stage59-original-duration-01/sources/', 'all'),
    'comparison_wrapper': ('closeout', 'target/m2/stage59-comparison-validation-02/sources/', 'all'),
    'tool_validation': ('closeout', 'target/m2/stage59-tool-validation-02/sources/', 'all'),
}
ARCHIVE_CONTROL_MEMBERS = {
    'validation': ('target/m2/stage59-rust-validation-01/report.json',),
    'native': ('target/m2/stage59-native-build-01/build.json',
               'target/m2/stage59-native-comparison-01/report.json',
               'target/m2/stage59-native-comparison-02/report.json'),
    'platform': ('target/m2/stage59-m1-platform-contract-03/report.json',
                 'target/m2/stage59-platform-validation-03/report.json'),
    'closeout': ('target/m2/stage59-original-duration-01/report.json',
                 'target/m2/stage59-comparison-validation-02/report.json',
                 'target/m2/stage59-tool-validation-02/report.json'),
}


def raw_json(data):
    return (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()


def digest(path):
    h = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            h.update(chunk)
            size += len(chunk)
    return {'sha256': h.hexdigest(), 'bytes': size}


def execute(*argv):
    proc = subprocess.run(argv, cwd=ROOT, capture_output=True)
    assert proc.returncode == 0, (argv, proc.returncode, proc.stderr[-1000:])
    return proc.stdout


def git_tree(repo, commit):
    result = {}
    for record in execute('git', '-C', str(repo), 'ls-tree', '-rz', '--full-tree', commit).split(b'\0'):
        if not record:
            continue
        head, path = record.split(b'\t', 1)
        mode, kind, oid = head.split(b' ')
        name = path.decode('utf-8', 'surrogateescape')
        assert name not in result
        result[name] = (mode.decode(), kind.decode(), oid.decode())
    return result


def logical(name):
    for repo in ('external/pkl-pantry', 'external/pkl'):
        if name.startswith(repo + '/'):
            return repo, name[len(repo) + 1:]
    return '.', name


def git_blobs(repo, oids):
    """Read each unique Git object once and validate its SHA-1 framing."""
    proc = subprocess.Popen(['git', '-C', str(repo), 'cat-file', '--batch'],
                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    result = {}
    try:
        for oid in sorted(oids):
            proc.stdin.write((oid + '\n').encode())
            proc.stdin.flush()
            header = proc.stdout.readline().strip().split(b' ')
            assert len(header) == 3 and header[0].decode() == oid and header[1] == b'blob', (oid, header)
            size = int(header[2])
            remaining = size
            git_hash = hashlib.sha1(b'blob ' + str(size).encode() + b'\0')
            content_hash = hashlib.sha256()
            while remaining:
                chunk = proc.stdout.read(min(1 << 20, remaining))
                assert chunk, (oid, remaining)
                git_hash.update(chunk)
                content_hash.update(chunk)
                remaining -= len(chunk)
            assert proc.stdout.read(1) == b'\n' and git_hash.hexdigest() == oid
            result[oid] = {'sha256': content_hash.hexdigest(), 'bytes': size}
        proc.stdin.close()
        assert proc.wait() == 0, proc.stderr.read()[-1000:]
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait()
    return result


def blob_bytes(repo, oid, expected):
    raw = execute('git', '-C', str(repo), 'cat-file', 'blob', oid)
    assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid
    assert {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} == expected
    return raw


def expected_identity(value):
    if isinstance(value, str):
        return value, None
    assert isinstance(value, dict)
    return value['sha256'], value.get('bytes')


def archive_member_audit(archive_bytes, prefix, source_manifest, captured_only=False):
    seen = 0
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as stream:
        members = stream.getmembers()
        names = [member.name for member in members]
        assert len(names) == len(set(names)), 'duplicate evidence archive member'
        for name, value in source_manifest.items():
            if captured_only and value['origin']['kind'] != 'captured-file':
                continue
            entry = stream.getmember(prefix + name)
            assert entry.isfile() and not entry.issym() and not entry.islnk(), entry.name
            raw = stream.extractfile(entry).read()
            sha, size = expected_identity(value)
            assert hashlib.sha256(raw).hexdigest() == sha and (size is None or len(raw) == size), entry.name
            seen += 1
    return seen


def main(commit, allowed_historical):
    assert ROOT == Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
    assert re.fullmatch('[0-9a-f]{40}', commit), 'explicit implementation B commit required'
    assert not PUBLIC.exists() and not ARCHIVE.exists() and not (OUT / 'report.json').exists()
    assert execute('git', 'cat-file', '-t', commit).strip() == b'commit'
    repositories = {'.': ROOT, **{name: ROOT / name for name in PIN}}
    trees = {'.': git_tree(ROOT, commit),
             **{name: git_tree(ROOT / name, pin) for name, pin in PIN.items()}}
    base_tree = git_tree(ROOT, BASE)
    for name, pin in PIN.items():
        assert trees['.'].get(name) == ('160000', 'commit', pin), (name, trees['.'].get(name))

    manifests = {}
    manifest_ids = {}
    for category, relative in MANIFESTS.items():
        path = ROOT / relative
        manifest_ids[relative] = digest(path)
        values = json.loads(path.read_bytes())
        assert isinstance(values, dict) and values
        manifests[category] = values
    assert manifests['rust_validation'] and len(manifests['rust_validation']) == json.loads(
        (ROOT / 'target/m2/stage59-rust-validation-01/report.json').read_bytes())['source_count']
    assert manifests['native_build'] == json.loads((ROOT / 'target/m2/stage59-native-build-01/source-after.json').read_bytes())
    assert manifests['native_build'] == json.loads((ROOT / 'target/m2/stage59-native-comparison-01/build/source-before.json').read_bytes())
    assert manifests['native_build'] == json.loads((ROOT / 'target/m2/stage59-native-comparison-01/build/source-after.json').read_bytes())
    assert manifests['native_build'] == json.loads((ROOT / 'target/m2/stage59-native-comparison-02/build/source-before.json').read_bytes())
    assert manifests['native_build'] == json.loads((ROOT / 'target/m2/stage59-native-comparison-02/build/source-after.json').read_bytes())
    assert manifests['m1_platforms'] == json.loads((ROOT / 'target/m2/stage59-m1-platform-contract-03/report.json').read_bytes())['source_hashes']
    assert manifests['platform_wrapper'] == json.loads((ROOT / 'target/m2/stage59-platform-validation-03/source-after.json').read_bytes())
    assert manifests['comparison_wrapper'] == json.loads((ROOT / 'target/m2/stage59-comparison-validation-02/source-after.json').read_bytes())
    assert manifests['tool_validation'] == json.loads((ROOT / 'target/m2/stage59-tool-validation-02/source-after.json').read_bytes())
    for report in ('target/m2/stage59-native-build-01/build.json',
                   'target/m2/stage59-m1-platform-contract-03/report.json',
                   'target/m2/stage59-platform-validation-03/report.json',
                   'target/m2/stage59-original-duration-01/report.json',
                   'target/m2/stage59-comparison-validation-02/report.json',
                   'target/m2/stage59-tool-validation-02/report.json'):
        data = json.loads((ROOT / report).read_bytes())
        assert data.get('source_stable', data.get('source_stability')) is True, report

    copied_ids = {}
    rust = manifests['rust_validation']
    origin_counts = Counter()
    required_oids = {name: set() for name in repositories}
    rows = []
    for name, value in rust.items():
        origin = value['origin']
        repo, relative = logical(name)
        if origin['kind'] == 'git-blob':
            assert origin['repository'] == repo and origin['path'] == relative
            expected_commit = BASE if repo == '.' else PIN[repo]
            assert origin['commit'] == expected_commit
            previous = base_tree if repo == '.' else trees[repo]
            assert previous.get(relative) == (origin['mode'], 'blob', origin['oid']), (name, origin)
            required_oids[repo].add(origin['oid'])
            assert value['input_mode'] == origin['mode']
            origin_counts['base_git' if repo == '.' else 'pinned_submodule_git'] += 1
        else:
            assert origin['kind'] == 'captured-file' and repo == '.'
            path = ROOT / 'target/m2/stage59-rust-validation-01' / origin['path']
            assert path.is_file() and not path.is_symlink(), path
            copied_ids[str(path.relative_to(ROOT))] = digest(path)
            assert copied_ids[str(path.relative_to(ROOT))] == {
                'sha256': value['sha256'], 'bytes': value['bytes']}
            origin_counts['captured_file'] += 1
        rows.append(('rust_validation', name, value))
    assert sum(origin_counts.values()) == len(rust)
    assert origin_counts['captured_file'] == json.loads(
        (ROOT / 'target/m2/stage59-rust-validation-01/report.json').read_bytes())['copied_source_files']
    for category, folder in SOURCE_COPIES.items():
        for name, value in manifests[category].items():
            path = ROOT / folder / name
            assert path.is_file() and not path.is_symlink(), path
            expected_sha, expected_size = expected_identity(value)
            identity = digest(path)
            assert identity['sha256'] == expected_sha and (expected_size is None or identity['bytes'] == expected_size), (category, name)
            copied_ids[str(path.relative_to(ROOT))] = identity
    for category, data in manifests.items():
        if category == 'rust_validation':
            continue
        rows.extend((category, name, value) for name, value in data.items())

    archive_ids = {}
    for category, relative in PUBLIC_ARCHIVES.items():
        path = ROOT / relative
        archive_ids[category] = {'path': relative, **digest(path)}
        entry = trees['.'].get(relative)
        assert entry and entry[:2] == ('100644', 'blob'), (relative, entry)
        required_oids['.'].add(entry[2])
    for category, name, value in rows:
        repo, relative = logical(name)
        entry = trees[repo].get(relative)
        if entry and entry[1] == 'blob':
            required_oids[repo].add(entry[2])
    blobs = {name: git_blobs(repo, required_oids[name]) for name, repo in repositories.items()}
    for name, value in rust.items():
        origin = value['origin']
        if origin['kind'] == 'git-blob':
            repo, _ = logical(name)
            assert blobs[repo][origin['oid']] == {'sha256': value['sha256'], 'bytes': value['bytes']}, name
    symlinks = [name for name, value in rust.items() if value['input_mode'] == '120000']
    assert all(rust[name]['origin']['kind'] == 'git-blob' and
               rust[name]['origin']['mode'] == '120000' for name in symlinks)

    archive_bytes = {}
    for category, identity in archive_ids.items():
        entry = trees['.'][identity['path']]
        assert blobs['.'][entry[2]] == {'sha256': identity['sha256'], 'bytes': identity['bytes']}
        archive_bytes[category] = blob_bytes(ROOT, entry[2], {
            'sha256': identity['sha256'], 'bytes': identity['bytes']})
        identity['B_oid'] = entry[2]
    archived_counts = {}
    for category, (archive_name, prefix, mode) in ARCHIVED_COPIES.items():
        archived_counts[category] = archive_member_audit(
            archive_bytes[archive_name], prefix, manifests[category],
            captured_only=(mode == 'captured-only'))
        assert archived_counts[category] == (origin_counts['captured_file'] if mode == 'captured-only'
                                             else len(manifests[category]))
    for archive_name, controls in ARCHIVE_CONTROL_MEMBERS.items():
        with tarfile.open(fileobj=io.BytesIO(archive_bytes[archive_name]), mode='r:gz') as stream:
            for relative in controls:
                member = stream.getmember(relative)
                assert member.isfile() and not member.issym() and not member.islnk(), relative
                raw = stream.extractfile(member).read()
                assert {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)} == digest(ROOT / relative), relative

    allowed = set(allowed_historical)
    used_allowed = set()
    statuses = defaultdict(Counter)
    deviations = defaultdict(list)
    output_rows = OUT / 'rows.jsonl.gz'
    with output_rows.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
            for category, name, value in rows:
                expected_sha, expected_size = expected_identity(value)
                repo, relative = logical(name)
                entry = trees[repo].get(relative)
                row = {'category': category, 'path': name, 'repository': repo,
                       'expected_sha256': expected_sha, 'expected_bytes': expected_size}
                if category == 'rust_validation':
                    row['origin'] = value['origin']
                    row['expected_mode'] = value['input_mode']
                if entry is None:
                    if category == 'tool_validation' and name == ARCHIVED_TOOL_WRAPPER:
                        # This generated, ignored target/ execution script was
                        # copied into the closeout archive and never a B source.
                        status = 'archived_execution_tool_not_B'
                        row['archive'] = PUBLIC_ARCHIVES['closeout']
                        row['archive_member'] = ARCHIVED_COPIES[category][1] + name
                    else:
                        status = 'missing_in_B'
                elif entry[1] != 'blob':
                    status = 'nonblob_in_B'
                    row.update(B_mode=entry[0], B_type=entry[1], B_oid=entry[2])
                else:
                    mode, _, oid = entry
                    current = blobs[repo][oid]
                    row.update(B_mode=mode, B_oid=oid, B_sha256=current['sha256'],
                               B_bytes=current['bytes'])
                    equal = current['sha256'] == expected_sha and (
                        expected_size is None or current['bytes'] == expected_size) and (
                        category != 'rust_validation' or mode == value['input_mode'])
                    status = 'matches_B' if equal else 'differs_from_B'
                    if not equal and category == 'rust_validation' and value['origin']['kind'] == 'git-blob' and repo == '.' and name in HISTORICAL_BASE_DOCS:
                        # The exact older bytes and Git mode were checked against BASE above.
                        status = 'historical_document_from_base'
                    elif not equal and category != 'rust_validation' and category + ':' + name in allowed:
                        # The exact older bytes were checked in B's published archive above.
                        status = 'explicit_historical_archived_source'
                        row['archive'] = PUBLIC_ARCHIVES[ARCHIVED_COPIES[category][0]]
                        row['archive_member'] = ARCHIVED_COPIES[category][1] + name
                        used_allowed.add(category + ':' + name)
                row['status'] = status
                statuses[category][status] += 1
                if status != 'matches_B':
                    deviations[category].append({'path': name, 'status': status,
                                                 'expected_sha256': expected_sha,
                                                 'B_sha256': row.get('B_sha256')})
                zipped.write((json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n').encode())
    assert used_allowed == allowed, {'unused_explicit_historical_exceptions': sorted(allowed - used_allowed)}
    assert sum(sum(counts.values()) for counts in statuses.values()) == sum(map(len, manifests.values()))
    for category, counts in statuses.items():
        unauthorized = set(counts) - {'matches_B', 'historical_document_from_base',
                                      'explicit_historical_archived_source',
                                      'archived_execution_tool_not_B'}
        assert not unauthorized, (category, dict(counts), deviations[category][:10])
    assert statuses['tool_validation']['archived_execution_tool_not_B'] == 1
    assert statuses['rust_validation']['matches_B'] >= origin_counts['captured_file']
    for category, values in manifests.items():
        if category != 'rust_validation':
            assert sum(statuses[category].values()) == len(values)
    assert {relative: digest(ROOT / relative) for relative in manifest_ids} == manifest_ids
    assert {relative: digest(ROOT / relative) for relative in copied_ids} == copied_ids
    assert all(digest(ROOT / identity['path']) == {k: identity[k] for k in ('sha256', 'bytes')}
               for identity in archive_ids.values())

    failed_folder = ROOT / 'target/m2/stage59-source-binding-01'
    failed_names = ('bind.py', 'bind-execution.json', 'bind.stdout.bin',
                    'bind.stderr.bin', 'rows.jsonl.gz')
    failed_files = {name: failed_folder / name for name in failed_names}
    failed_execution = json.loads(failed_files['bind-execution.json'].read_bytes())
    assert failed_execution['observed_exit_code'] == 1
    assert failed_execution['argv'][-2:] == ['--commit', commit]
    for channel in ('stdout', 'stderr'):
        assert failed_execution[channel] == {
            'path': str(failed_files[f'bind.{channel}.bin'].relative_to(ROOT)),
            **digest(failed_files[f'bind.{channel}.bin'])}
    assert ARCHIVED_TOOL_WRAPPER.encode() in failed_files['bind.stderr.bin'].read_bytes()
    failed_ids = {name: digest(path) for name, path in failed_files.items()}

    report = {
        'schema': 1, 'kind': 'actual-Git-object-source-binding-for-Stage59-B',
        'B_commit': commit, 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'recorded_base_commit': BASE, 'gitlinks': PIN,
        'method': 'Actual base, pinned submodule and B tree OIDs/modes; SHA-1-framed Git blob reads and raw SHA-256/size; copied source bytes, required report controls and B archive members reread.',
        'manifests': {category: {'path': relative, **manifest_ids[relative],
                                 'rows': len(manifests[category])}
                      for category, relative in MANIFESTS.items()},
        'category_statuses': {category: dict(counts) for category, counts in statuses.items()},
        'deviations': dict(deviations), 'origin_counts': dict(origin_counts),
        'verified_symlink_sources': symlinks, 'archived_source_member_counts': archived_counts,
        'archived_control_members': {name: list(paths) for name, paths in ARCHIVE_CONTROL_MEMBERS.items()},
        'B_archive_blobs': archive_ids, 'unique_blob_objects_read': {name: len(value) for name, value in blobs.items()},
        'copied_source_files_stable': len(copied_ids),
        'prior_failed_binder': {'path': str(failed_folder.relative_to(ROOT)),
                                'observed_exit_code': 1, 'files': failed_ids},
        'row_details': {'path': str(output_rows.relative_to(ROOT)), **digest(output_rows)},
        'explicit_historical_exceptions': sorted(allowed),
        'limits': ['Only the four named base document rows may retain verified base Git bytes when they differ from B; actual rows are counted and are not B-current source claims.',
                   'Explicit historical source rows retain verified member bytes in a committed B evidence archive and are not B-current source claims.',
                   'The sole ignored target/m2/stage59-tool-validation-02/run.py row is proved by the committed closeout archive and is explicitly absent from B; it is not a production source or B-current claim.',
                   'Stage 59 platform wrappers 01/02 and comparison wrapper 01 remain historical failed-admission evidence; final native/M1/platform/tool manifests are bound separately and no earlier tool source is silently relabeled B-current.',
                   'Source binding does not rerun evaluators, builds or tests and does not establish full API, whole M2 or performance compatibility.'],
    }
    (OUT / 'report.json').write_bytes(raw_json(report))
    payloads = {'report.json': OUT / 'report.json', 'rows.jsonl.gz': output_rows,
                'binder.py': Path(__file__)}
    payloads.update({f'prior-failed-binder-01/{name}': path
                     for name, path in failed_files.items()})
    inventory = {name: {'mode': stat.S_IMODE(path.stat().st_mode), **digest(path)}
                 for name, path in payloads.items()}
    manifest_raw = raw_json({'schema': 1, 'files': inventory})
    with ARCHIVE.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as stream:
                for name, path in [('manifest.json', None), *sorted(payloads.items())]:
                    raw = manifest_raw if path is None else path.read_bytes()
                    entry = tarfile.TarInfo(name)
                    entry.size = len(raw)
                    entry.mode = 0o644 if path is None else inventory[name]['mode']
                    entry.mtime = 0
                    stream.addfile(entry, io.BytesIO(raw))
    assert digest(ARCHIVE)['bytes'] < 90 * 1024 * 1024
    seen = {}
    with tarfile.open(ARCHIVE, 'r:gz') as stream:
        for entry in stream:
            assert entry.isfile() and entry.name not in seen and not entry.name.startswith('/') and '..' not in PurePosixPath(entry.name).parts
            raw = stream.extractfile(entry).read()
            seen[entry.name] = {'sha256': hashlib.sha256(raw).hexdigest(),
                                'bytes': len(raw), 'mode': entry.mode}
    assert seen.pop('manifest.json') == {'sha256': hashlib.sha256(manifest_raw).hexdigest(),
                                         'bytes': len(manifest_raw), 'mode': 0o644}
    assert seen == inventory
    publication = {
        'schema': 1, 'binding_report': report,
        'evidence_archive': {'path': str(ARCHIVE.relative_to(ROOT)), **digest(ARCHIVE),
                             'members': len(seen) + 1},
        'full_archive_reread_verified': True, 'original_sources_stable_before_after': True,
        'whole_M2_complete': False, 'full_public_api_comparison_passed': False,
        'performance_targets_achieved': False,
    }
    PUBLIC.write_bytes(raw_json(publication))
    print(json.dumps({'B_commit': commit, 'category_statuses': report['category_statuses'],
                      'evidence_archive': publication['evidence_archive'],
                      'report': digest(PUBLIC)}, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--commit', required=True,
                        help='Actual root-supplied 40-hex implementation B commit')
    parser.add_argument('--allow-historical', action='append', default=[],
                        metavar='CATEGORY:PATH',
                        help='Explicitly permit an archived prior source after reviewing its B difference')
    args = parser.parse_args()
    main(args.commit, args.allow_historical)
