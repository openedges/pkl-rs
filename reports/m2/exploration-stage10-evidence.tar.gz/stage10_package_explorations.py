from pathlib import Path
import sys,json,shutil,collections,subprocess
sys.path.insert(0,'tools')
import oracle,evidence,m2_language as l
root=Path.cwd();dest=Path(sys.argv[1]);dest.mkdir(exist_ok=False);rows=[]
for n in range(1,5):
 src=Path(f'target/m2/stage10-exploration-{n:02d}')
 for rel,sha in json.loads((src/'evidence-sha256.json').read_bytes()).items():assert oracle.sha256(src/rel)==sha,(src,rel)
 for rel,sha in json.loads((src/'source-identities.json').read_bytes()).items():assert oracle.sha256(src/'sources'/rel)==sha,(src,rel)
 matrix={r['id']:r for r in json.loads((src/'matrix.json').read_bytes())}
 for r in json.loads((src/'results.json').read_bytes()):
  f=src/'cases'/r['id'];p=r['java'];assert oracle.sha256(f/'input.pkl')==r['input_sha256']
  for channel in ('stdout','stderr'):assert oracle.sha256(f/f'java.{channel}.bin')==p[channel+'_sha256']
  assert oracle.sha256(f/'java.outcome.bin')==p['outcome_sha256'];assert not p['timed_out']
  assert(p['exit_code']==0 and not(f/'java.stderr.bin').read_bytes()and(f/'java.outcome.bin').read_bytes()==b'success\n')or(p['exit_code']==1 and not(f/'java.stdout.bin').read_bytes()and l.valid_exception_outcome((f/'java.outcome.bin').read_bytes()))
  rows.append(dict(exploration=src.name,id=r['id'],group=matrix[r['id']]['group'],input_uri=r['input_uri'],input_sha256=r['input_sha256'],expression=matrix[r['id']]['expression'],provisional_expected_outcome=r['expected_outcome'],observed_java_outcome='success'if p['exit_code']==0 else'pkl-exception',expectation_matches=(r['expected_outcome']=='success')==(p['exit_code']==0),selected=False))
 shutil.copytree(src,dest/src.name)
# Recover dependency snapshots from the unchanged pinned git tree. This additional
# identity record does not retroactively turn selected API calls into full suites.
upstream=['pkl-core/src/test/files/LanguageSnippetTests/input/snippetTest.pkl','pkl-core/src/test/files/LanguageSnippetTests/input-helper/errors/ReferencedModule.pkl','pkl-core/src/test/files/LanguageSnippetTests/input-helper/errors/ReferencedModuleWithOutputOverride.pkl']
dependencies={}
for rel in upstream:
 src=Path('external/pkl')/rel;gitdata=subprocess.run(['git','-C','external/pkl','show','e51fb2f91774265666f94980ec630db794a4db2d:'+rel],check=True,capture_output=True).stdout;assert src.read_bytes()==gitdata
 p=dest/'additional-pinned-dependencies'/src;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gitdata);dependencies[str(src)]=oracle.sha256(p)
summary=dict(schema_version=1,scope='Exploratory evaluateExpressionString API captures only. These probes do not execute the full original LanguageSnippetTests/assertion/renderer contract and do not establish full language, reflection, stdlib, public API, lifecycle, or performance compatibility.',calls=len(rows),observed_outcomes=dict(collections.Counter(r['observed_java_outcome']for r in rows)),expectation_drift=[dict(exploration=r['exploration'],id=r['id'],expected=r['provisional_expected_outcome'],observed=r['observed_java_outcome'])for r in rows if not r['expectation_matches']],upstream_selected_expression_calls=sum(r['group']=='upstream-selected-expression'for r in rows),metamorphic_pairs=[['relation-alias-left','relation-alias-right'],['relation-unforced-left','relation-unforced-right'],['relation-render-left','relation-render-right']],additional_pinned_dependencies=dependencies,cases=rows)
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2('target/m2/stage10_package_explorations.py',dest/'stage10_package_explorations.py');evidence.create(dest,Path('reports/m2/exploration-stage10-evidence.tar.gz'),[]);print(json.dumps({k:v for k,v in summary.items()if k!='cases'},indent=2))
