"""Reacquire after the relative-resource adapter correction, preserving candidate01."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
PLATFORMS = ROOT / 'target/m2/stage53-platforms-01'
COMPARISON = ROOT / 'target/m2/stage53-parameterized-final-02'
sys.path.insert(0, str(ROOT / 'tools'))
import m2_source_inputs
import m1_platforms

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

assert not (OUT / 'report.json').exists() and not COMPARISON.exists()
platform_report = json.loads((PLATFORMS / 'report.json').read_bytes())
assert platform_report['source_stability'] and platform_report['experiment_contract_status'] == 'pass'
assert m1_platforms.contract_matches(platform_report['comparisons'])
m1_platforms.check_scenarios(platform_report['execution'])
old_hashes = platform_report['source_hashes']
changed = [name for name, digest in old_hashes.items() if sha(ROOT / name) != digest]
expected_changes = {'tools/platform/parameterized-object-session.mjs', 'tools/platform/parameterized-object-session.test.mjs'}
assert set(changed) == expected_changes, changed
engine_paths = [name for name in old_hashes if name.startswith('crates/') or name in {'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'}]
assert all(sha(ROOT / name) == old_hashes[name] for name in engine_paths)
artifacts = {name: sha(PLATFORMS / name) for name in platform_report['artifacts']}
assert artifacts == platform_report['artifacts']
paths = set(m2_source_inputs.source_paths(ROOT))
paths.update(str(path.relative_to(ROOT)) for path in m1_platforms.source_paths(ROOT))
before = {name: sha(ROOT / name) for name in sorted(paths)}
for name in before:
    dest = OUT / 'sources' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, dest)
(OUT / 'sources.json').write_text(json.dumps(before, indent=2) + '\n')
env = dict(os.environ, CARGO_INCREMENTAL='0', PYTHONDONTWRITEBYTECODE='1')
report = {'scope': 'Same85 Java cases, corrected relative-resource adapter. Existing failed candidate01 preserved. Same engine and frozen M1 NAPI/Wasm artifacts; new native adapter build and portable driver.',
          'cwd': str(ROOT), 'host': platform.platform(), 'startedUtc': utc(), 'wrapperPid': os.getpid(),
          'baseCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
          'environmentOverrides': {'CARGO_INCREMENTAL': '0', 'PYTHONDONTWRITEBYTECODE': '1'},
          'python': sys.version, 'pythonExecutable': sys.executable, 'commands': [], 'complete': False,
          'sourceCount': len(before), 'runnerSha256': sha(Path(__file__)),
          'platformEvidenceReuse': {'report': str(PLATFORMS / 'report.json'), 'sha256': sha(PLATFORMS / 'report.json'),
              'artifacts': artifacts, 'unchangedEngineInputs': engine_paths,
              'changedOverinclusivePlatformCatalogInputs': changed,
              'scope': 'Changed helper and its tests are used by the new parameterized comparison only, not the M1 run.mjs scenario runner or any compiled binding. Prior M1 evidence retains its original source hashes and strict regex failures.'}}

def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def run(name, argv, allowed=(0,)):
    row = {'name': name, 'argv': argv, 'startedUtc': utc()}
    start = time.monotonic()
    stdout, stderr = OUT / (name + '.stdout.bin'), OUT / (name + '.stderr.bin')
    print('START', name, flush=True)
    with stdout.open('wb') as output, stderr.open('wb') as error:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=output, stderr=error)
        row['pid'] = child.pid
        (OUT / 'active.json').write_text(json.dumps(row, indent=2) + '\n')
        row['exitCode'] = child.wait()
    row.update(seconds=time.monotonic() - start, finishedUtc=utc(), stdoutSha256=sha(stdout), stderrSha256=sha(stderr))
    report['commands'].append(row)
    save()
    print('FINISH', name, row['exitCode'], flush=True)
    assert row['exitCode'] in allowed, f'{name}: unexpected exit code; original failure retained'

save()
run('native-expression-build', ['cargo', 'build', '-p', 'pkl-runtime', '--example', 'expression_fixture_probe', '--release', '--locked'])
artifact = ROOT / 'target/release/examples/expression_fixture_probe'
report['nativeBuildArtifact'] = {'path': str(artifact), 'sha256': sha(artifact), 'bytes': artifact.stat().st_size}
save()
run('parameterized-comparison', [sys.executable, 'tools/parameterized_object_compare.py', '--output', str(COMPARISON), '--native', str(artifact), '--wasm', str(PLATFORMS / 'wasm'), '--napi', str(PLATFORMS / 'pkl_napi.node')], (0, 1))
comparison = json.loads((COMPARISON / 'report.json').read_bytes())
report['comparisonVerdict'] = {'status': comparison['status'], 'cases': len(comparison['case_ids']), 'boundaries': len(comparison['oracle_boundaries']), 'targets': {key: {name: value for name, value in row.items() if name != 'results'} for key, row in comparison['targets'].items()}}
report.update(complete=True, finishedUtc=utc(), changedSources=[name for name, digest in before.items() if sha(ROOT / name) != digest])
report['sourceStable'] = not report['changedSources']
report['reusedArtifactsStable'] = all(sha(PLATFORMS / name) == digest for name, digest in artifacts.items())
save()
assert report['sourceStable'] and report['reusedArtifactsStable'], 'Source/artifact changed during capture'
print('COMPLETE', comparison['status'], flush=True)
