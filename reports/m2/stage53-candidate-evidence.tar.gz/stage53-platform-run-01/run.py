"""Build recorded Stage53 native/portable artifacts and compare original Java fixtures."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
PLATFORMS = ROOT / 'target/m2/stage53-platforms-01'
COMPARISON = ROOT / 'target/m2/stage53-parameterized-final-01'
sys.path.insert(0, str(ROOT / 'tools'))
import m2_source_inputs
import m1_platforms

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

assert not (OUT / 'report.json').exists() and not PLATFORMS.exists() and not COMPARISON.exists()
paths = set(m2_source_inputs.source_paths(ROOT))
paths.update(str(path.relative_to(ROOT)) for path in m1_platforms.source_paths(ROOT))
before = {name: sha(ROOT / name) for name in sorted(paths)}
for name in before:
    dest = OUT / 'sources' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, dest)
(OUT / 'sources.json').write_text(json.dumps(before, indent=2) + '\n')
env = dict(os.environ, CARGO_INCREMENTAL='0', PYTHONDONTWRITEBYTECODE='1')
report = {'scope': 'Required shared-engine platform regression and selected arbitrary-expression Java comparison; known regex failures and separate Java internal boundaries remain nonpasses.',
          'cwd': str(ROOT), 'host': platform.platform(), 'startedUtc': utc(), 'wrapperPid': os.getpid(),
          'baseCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
          'environmentOverrides': {'CARGO_INCREMENTAL': '0', 'PYTHONDONTWRITEBYTECODE': '1'},
          'python': sys.version, 'pythonExecutable': sys.executable, 'commands': [], 'complete': False,
          'sourceCount': len(before), 'runnerSha256': sha(Path(__file__))}

def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def run(name, argv, allowed=(0,)):
    row = {'name': name, 'argv': argv, 'startedUtc': utc()}
    start = time.monotonic()
    stdout, stderr = OUT / (name + '.stdout.bin'), OUT / (name + '.stderr.bin')
    print('START', name, flush=True)
    with stdout.open('wb') as output, stderr.open('wb') as error:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=output, stderr=error)
        row['pid'] = child.pid
        (OUT / 'active.json').write_text(json.dumps(row, indent=2) + '\n')
        row['exitCode'] = child.wait()
    row.update(seconds=time.monotonic() - start, finishedUtc=utc(), stdoutSha256=sha(stdout), stderrSha256=sha(stderr))
    report['commands'].append(row)
    save()
    print('FINISH', name, row['exitCode'], flush=True)
    assert row['exitCode'] in allowed, f'{name}: unexpected exit code; original failure retained'

save()
run('m1-platforms', [sys.executable, 'tools/m1_platforms.py', '--output', str(PLATFORMS)], (0, 1))
platform_report = json.loads((PLATFORMS / 'report.json').read_bytes())
assert platform_report['source_stability'] and platform_report['experiment_contract_status'] == 'pass'
assert m1_platforms.contract_matches(platform_report['comparisons'])
m1_platforms.check_scenarios(platform_report['execution'])
report['platformVerdict'] = {key: platform_report[key] for key in ['total', 'oracle_passed', 'shared_engine_passed', 'compatibility_status', 'experiment_contract_status', 'known_gaps']}
save()
run('native-expression-build', ['cargo', 'build', '-p', 'pkl-runtime', '--example', 'expression_fixture_probe', '--release', '--locked'])
artifact = ROOT / 'target/release/examples/expression_fixture_probe'
report['nativeBuildArtifact'] = {'path': str(artifact), 'sha256': sha(artifact), 'bytes': artifact.stat().st_size}
save()
run('parameterized-comparison', [sys.executable, 'tools/parameterized_object_compare.py', '--output', str(COMPARISON), '--native', str(artifact), '--wasm', str(PLATFORMS / 'wasm'), '--napi', str(PLATFORMS / 'pkl_napi.node')], (0, 1))
comparison = json.loads((COMPARISON / 'report.json').read_bytes())
report['comparisonVerdict'] = {'status': comparison['status'], 'cases': len(comparison['case_ids']), 'boundaries': len(comparison['oracle_boundaries']), 'targets': {key: {name: value for name, value in row.items() if name != 'results'} for key, row in comparison['targets'].items()}}
report.update(complete=True, finishedUtc=utc(), changedSources=[name for name, digest in before.items() if sha(ROOT / name) != digest])
report['sourceStable'] = not report['changedSources']
save()
assert report['sourceStable'], 'Source changed during capture'
print('COMPLETE', comparison['status'], flush=True)
