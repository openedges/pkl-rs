from pathlib import Path
import json,hashlib,stat
O=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');D=S/'target/m2/stage48-checkpoint-draft-02/checkpoint.json';MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');h=lambda b:hashlib.sha256(b).hexdigest();inputs={}
def read(p):
 p=Path(p);assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();r={'sha256':h(b),'bytes':len(b)};assert inputs.setdefault(str(p),r)==r;return b
def obj(p):return json.loads(read(p))
def copy(p,n):
 b=read(p);q=O/'evidence'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return b
c=json.loads(copy(D,'checkpoint.json'));assert h(read(D))=='616c43c450b867853d4eaa42482803ec1056f7bc46c088549f82425f0807462a'
assert c['status']=='verified-local-checkpoint-awaiting-publication-and-commit' and not c['fullM2Complete'] and not c['hostedCiClaimed'] and not c['performanceTargetClaimed']
assert c['candidate']['sha256']=='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0' and c['candidateSourceMapSha256']=='9f546b82bd3cfba614c2c0bb1671db14f226466707f99cef3a5ceb5f6dc12a18' and c['candidateFileCount']==53236 and c['candidateSymlinkCount']==11
v=obj(S/'target/m2/stage48-implementation-01/admission-c01-verification-01/report.json');assert len(v['checks'])==6 and len(c['requiredRustChecks'])==5
assert c['requiredRustChecks']==v['checks'][:5] and c['focusedRegression']==v['checks'][5]
for r in c['requiredRustChecks']+[c['focusedRegression']]:assert h(read(Path(r['capture'])/'report.json'))==r['report_sha256'] and r['exit_code']==0 and r['source_stable']
n=obj(S/'target/m2/stage48-policy-native-c01-01/report.json');assert all(c['nativePolicy'][k]==n[k]for k in c['nativePolicy']);assert c['nativePolicy']['rawApiPass']==440 and c['nativePolicy']['explicitUnexecutedApiCalls']==212 and c['nativePolicy']['fullLifecycleFailSessions']==52 and c['nativePolicy']['fullLifecyclePassSessions']==0
ph=obj(S/'target/m2/stage48-policy-portable-c01-audit-01/handoff.json');assert h(read(S/'target/m2/stage48-policy-portable-c01-audit-01/handoff.json'))=='88b535dfcfa81ad4a1c2cc9874f74015627ccd5afa4206c9317441cf2a383632'
pe=obj(Path(ph['portableRoot'])/'execution.json');pt=obj(Path(ph['launchRoot'])/'terminal.json');assert h(read(Path(ph['portableRoot'])/'execution.json'))==ph['executionSha256'] and h(read(Path(ph['launchRoot'])/'terminal.json'))==ph['terminalSha256']
assert c['portablePolicy']['rawApiContractPassed']==pe['rawApiContractPassed']and c['portablePolicy']['fullLifecyclePassed']==pe['fullLifecyclePassed']==False and c['portablePolicy']['strictExitCode']==pt['wrapperExitCode']==1 and pt['integrityPassed']
for t in ['node','browser']:assert c['portablePolicy']['targets'][t]['rawApiCounts']=={'pass':84} and c['portablePolicy']['targets'][t]['sessions']==12 and c['portablePolicy']['targets'][t]['fullLifecycleFailedSessions']==12==ph['targets'][t]['fullLifecycleFailedSessions']
for name,row in c['platforms'].items():
 e=obj(row['report']['path']);assert h(read(row['report']['path']))==row['report']['sha256']
 for t,value in row['targets'].items():assert all(value[k]==e['targets'][t][k]for k in value)
 assert row['infrastructureErrors']==e['infrastructureErrors']==[] and row['browserErrors']==e['browserErrors']==[]
top=obj(S/'target/m2/stage48-c01-platform-control-01/report.json');assert c['primitives']==top['primitiveGate']
for kind,root in [('legacy','stage48-c01-bootstrap-control-01'),('typed','stage48-c01-bootstrap-typed-control-02')]:
 e=obj(S/'target/m2'/root/'execution/execution.json');assert not e['strictJavaCompatibilityPassed']and e['acquisitionPassed']
 for t in ['node','browser']:assert c['bootstrap'][kind][t]==e['targets'][t]['counts']
f=obj(c['inventory']['freshness']['path']);assert h(read(c['inventory']['freshness']['path']))==c['inventory']['freshness']['sha256'];assert c['inventory']['counts']==f['counts'] and len(f['fingerprintChanges'])==c['inventory']['changedExistingSourceLinkFingerprints']==71 and f['allOtherFieldsUnchanged'] and not c['inventory']['caseRequirementStatusMappingAndOrderChanges']
assert c['fullSelectedRegression']['Stage48']=='not acquired for this checkpoint' and c['fullSelectedRegression']['latestPublished']=='Stage46:3650/3664; strict full gate failed' and c['fullSelectedRegression']['separateStage47']=='running from0e13a58; never reused as Stage48 result'
failure=S/'target/m2/stage48-checkpoint-draft-01/failure.json'
if failure.exists():copy(failure,'draft01-failure.json')
for p,r in inputs.items():assert h(Path(p).read_bytes())==r['sha256']
(O/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
result={'schema':1,'scope':'Compact read-only checkpoint draft02 claim review against closed metadata; prior raw/source audits reused, no large payload/source reruns or evaluator/build/Git execution.','reviewedDraftSha256':h(read(D)),'materialClaimIssue':False,'verifiedCounts':['Required Rust5 plus focused1, not six required commands','Native selected440pass and explicit212unexecuted, fullLifecycle0pass/52fail','Portable84perTarget and fullLifecycle12failedsessions each, strict exit1/integritytrue','All8platform report summaries and baseline2regex gaps retained','Bootstrap original274/144/182 and typed402/144/54, bothstrictfalse','Inventory4527/475 ready3664/unimplemented823/unmapped40 and71sha-only changes'],'scopeAssessment':'Stage48 bounded checkpoint, pending its full selected regression, latest published Stage46 and separately running Stage47 are clearly distinguished. Candidate and narrower earlier source maps/comment-only delta, historical gaps and policy/projection limitations are explicit.','clarificationRecommendation':{'field':'nativePolicy.rawApiMismatchOrUnexecuted','current':0,'meaning':'Only selected executed440 APIs; explicitUnexecutedApiCalls212 is a separate population.','suggestion':'Add selectedRawApiScope440 or name the field selectedRawApiMismatchOrUnexecuted in checkpoint prose/metadata. Preserve original B report unchanged.'},'futureVersionNeedsBinding':['Publication archive/member/SHA pointers','Policy fixture/provider unit references','Updated publication/commit status','Actual staged-source audit after root staging'],'originalChanges':[]}
(O/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'reviewedDraftSha256':h(read(D)),'metadataInputs':len(inputs),'materialIssue':False}))
