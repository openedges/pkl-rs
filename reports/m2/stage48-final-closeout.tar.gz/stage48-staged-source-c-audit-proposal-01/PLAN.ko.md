# Stage48 최종 staged-source 감사 실행 준비

현재는 도구 준비와 `ast.parse` 문법 확인만 마쳤다. staging 완료 통보 전 Git/index 읽기나 실제 감사는 실행하지 않는다.

## 실행 조건과 명령

root가 Stage48 staging 완료 및 최종 index 동결을 알린 뒤 새 MAIN target 경로로 실행한다.

```sh
python3 target/m2/stage48-staged-source-c-audit-proposal-01/audit.py --audit --root-staging-complete --output /Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage48-staged-source-c-audit-01
```

실제 실행은 별도 wrapper에서 stdout/stderr/exit 및 부모 tool terminal을 기록한다. 실패 시 원본 출력을 유지하고 수정 도구/새 목적 경로를 사용한다.

## 확인할 계약

- Stage48 HEAD는 C01 base0e13a589…이고, actual index의 stage0 blob과 mode를 직접 읽는다. `git ls-files --stage` 및 filter 없는 read-only `git cat-file --batch`만 사용한다. index raw를 전후 비교하며 Git writes/status refresh/write-tree/checkout은 없다.
- C01의 project regular47,663개를 actual index blob의 raw SHA256 및 Git SHA1·executable mode로 대조한다. runtime/Cargo/fixtures/기존 reports 등은 모두 동일해야 한다.
- external5,573개와11symlink는 닫힌 core 감사d122065f…/ac400022…를 재사용한다. external tree/cache는 다시 탐색하지 않고 actual index의 두160000gitlink 및 unchanged references.lock으로 pinned revisions를 연결한다.
- 허용된 기존 문서 변경은 PLAN.md,TESTING.md,docs/architecture.md,reports/m2/README.md다. 새docs/m2-module-admission.md를 허용한다. rootREADME.md 및 다른 기존 report의 변경/삭제는 허용하지 않는다.
- bootstrap helper와 module-policy test는 닫힌 typed후속의 exactsha ad555537…/b8b1d402…만 허용한다. runtime/C01 artifact 수정으로 재분류하지 않는다.
- compatibility/m2-language.json은 기존71개의 requirements/숫자/implementation/links/숫자/sha256만 달라야 하며 각 새SHA가 실제 index의 해당 source blob과 같아야 한다. 모든 다른 JSON field/case/order/count/status 변경은 거부한다.
- 신규 reports/m2/stage48* 게시 파일만 추가 허용한다. 실제 staged doc bytes/diffs와 신규 publication blob 목록을 남겨 마지막 claim/pointer 검토에 사용한다.

실행 후 source identity 판정과 문서 내용·게시pointer 판정은 구분한다. 이 감사는 evaluator나 M2 compatibility 검사를 재실행하지 않는다.
