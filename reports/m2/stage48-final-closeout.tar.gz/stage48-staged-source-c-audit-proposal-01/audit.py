"""Read actual staged blobs only after root confirms staging; never write Git."""
from pathlib import Path
import argparse,collections,difflib,hashlib,json,os,re,shutil,subprocess,sys
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');STAGE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48')
CAND=STAGE/'target/m2/stage48-implementation-01/admission-candidate-build-01'
BASE='0e13a589d43c4cb1d83f41dd1ec416cac1770fc1'
RELEASE_PIN='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0'
MAP_PIN='9f546b82bd3cfba614c2c0bb1671db14f226466707f99cef3a5ceb5f6dc12a18'
CORE_REVIEW=MAIN/'target/m2/stage48-core-publication-c-review-01'
CORE_REVIEW_PIN='d122065ff306c4b84e53b0c605c0e045fb5c2ac4414b5986c6a637da868e6c7a'
CORE_CLOSURE_PIN='ac400022e679fa005748ebaeaaa3c6ac5b1595457728531ba1016da1dcf5f8cd'
DOCS={'PLAN.md','TESTING.md','docs/architecture.md','docs/m2-module-admission.md','reports/m2/README.md'}
INVENTORY='compatibility/m2-language.json'
CONSUMER={'tools/platform/bootstrap-session.mjs':'ad5555374d13755e9904d0b05f6e1808463087acda868a27d74f850358e835f0','tools/platform/module-policy-session.test.mjs':'b8b1d402214f197556cedf8cc6c273ac7ffab12017289d605d383f302fe9604d'}
GITLINKS={'external/pkl':'e51fb2f91774265666f94980ec630db794a4db2d','external/pkl-pantry':'904a68184e54da378b0a0e8a911a3fab3956f693'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def diffs(a,b,path=()):
 if type(a)is not type(b):return [(path,a,b)]
 if isinstance(a,dict):
  if a.keys()!=b.keys():return [(path,a,b)]
  return [r for k in a for r in diffs(a[k],b[k],path+(k,))]
 if isinstance(a,list):
  if len(a)!=len(b):return [(path,a,b)]
  return [r for i,(x,y)in enumerate(zip(a,b))for r in diffs(x,y,path+(i,))]
 return [] if a==b else [(path,a,b)]
def git(root,args):
 r=subprocess.run(['git','-C',str(root),*args],capture_output=True,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'});assert r.returncode==0,(args,r.stderr.decode(errors='replace'));return r.stdout

def audit(output):
 output.mkdir(exist_ok=False);release_bytes=(CAND/'release.json').read_bytes();assert sha(release_bytes)==RELEASE_PIN
 release=json.loads(release_bytes);rawmap=(CAND/'source-after.json').read_bytes();assert sha(rawmap)==MAP_PIN
 all_sources=json.loads(rawmap);modes=json.loads((CAND/'source-modes.json').read_bytes());project={p:h for p,h in all_sources.items()if not p.startswith('external/')}
 assert sha((CORE_REVIEW/'report.json').read_bytes())==CORE_REVIEW_PIN and sha((CORE_REVIEW/'closure.json').read_bytes())==CORE_CLOSURE_PIN
 core=json.loads((CORE_REVIEW/'report.json').read_bytes());assert core['currentCandidate']['sourceFiles']==len(all_sources)and core['currentCandidate']['historicalHashOnlyInCurrentMap']==0
 head=git(STAGE,['rev-parse','HEAD']).decode().strip();assert head==BASE
 raw=git(STAGE,['ls-files','--stage','-z']);index={}
 for entry in raw.split(b'\0'):
  if not entry:continue
  header,name=entry.split(b'\t',1);mode,oid,stage=header.decode().split(' ');path=os.fsdecode(name);assert stage=='0' and path not in index;index[path]={'mode':mode,'oid':oid}
 assert {n:r['oid']for n,r in index.items()if r['mode']=='160000'}==GITLINKS
 assert all(n in index for n in project),sorted(set(project)-set(index))
 extra=set(index)-set(project)-set(GITLINKS)
 assert all(n=='docs/m2-module-admission.md'or n.startswith('reports/m2/stage48')for n in extra),sorted(extra)
 regular={n:r for n,r in index.items()if r['mode']in ['100644','100755','120000']}
 assert len(regular)+len(GITLINKS)==len(index)
 capture_names=DOCS|{INVENTORY,'references.lock'};capture_oids={index[n]['oid']for n in capture_names if n in index}
 # One persistent read-only cat-file process. Read each object fully, without textconv,
 # filters, worktree checkout, git write-tree, status refresh or object mutations.
 objects={};bodies={};err=output/'git-cat-file.stderr.bin'
 with err.open('wb')as stderr:
  p=subprocess.Popen(['git','-C',str(STAGE),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
  for oid in sorted({r['oid']for r in regular.values()}):
   p.stdin.write((oid+'\n').encode());p.stdin.flush();header=p.stdout.readline();parts=header.decode().strip().split();assert len(parts)==3 and parts[:2]==[oid,'blob'],header
   size=int(parts[2]);remain=size;digest=hashlib.sha256();gitdigest=hashlib.sha1(b'blob '+str(size).encode()+b'\0');body=[] if oid in capture_oids else None
   while remain:
    chunk=p.stdout.read(min(remain,1024*1024));assert chunk;remain-=len(chunk);digest.update(chunk);gitdigest.update(chunk)
    if body is not None:body.append(chunk)
   assert p.stdout.read(1)==b'\n' and gitdigest.hexdigest()==oid
   objects[oid]={'sha256':digest.hexdigest(),'bytes':size}
   if body is not None:bodies[oid]=b''.join(body)
  p.stdin.close();assert p.wait()==0
 assert err.read_bytes()==b''
 source_rows=[];changes=[];allowed=DOCS|{INVENTORY}|set(CONSUMER)
 for n,expected in project.items():
  row=index[n];assert row['mode']in ['100644','100755']
  expected_mode='100755'if modes[n]&0o111 else'100644';assert row['mode']==expected_mode,(n,'mode',row['mode'],expected_mode)
  actual=objects[row['oid']]['sha256'];match=actual==expected
  if not match:assert n in allowed,(n,'undeclared post-C01 change');changes.append({'path':n,'candidateSha256':expected,'stagedSha256':actual,'gitBlob':row['oid'],'mode':row['mode']})
  source_rows.append({'path':n,'candidateSha256':expected,'stagedSha256':actual,'gitBlob':row['oid'],'gitMode':row['mode'],'sameAsC01':match})
 # Exact consumer-only delta pinned to already audited typed follow-up artifacts.
 for n,h in CONSUMER.items():assert objects[index[n]['oid']]['sha256']==h,(n,'typed consumer hash')
 before=json.loads((CAND/'sources'/INVENTORY).read_bytes());after=json.loads(bodies[index[INVENTORY]['oid']]);fingerprints=diffs(before,after)
 assert len(fingerprints)==71,len(fingerprints)
 for path,old,new in fingerprints:
  assert len(path)==6 and path[0]=='requirements'and isinstance(path[1],int)and path[2]=='implementation'and path[3]=='links'and isinstance(path[4],int)and path[5]=='sha256',path
  link=after['requirements'][path[1]]['implementation']['links'][path[4]];assert link['path']in index and new==objects[index[link['path']]['oid']]['sha256'],(path,'fingerprint differs actual index source')
 refs=bodies[index['references.lock']['oid']];assert sha(refs)==all_sources['references.lock']
 lock={line.split('=',1)[0]:line.split('=',1)[1]for line in refs.decode().splitlines()if line and not line.startswith('#')}
 assert GITLINKS[lock['pkl.path']]==lock['pkl.revision']and GITLINKS[lock['pkl-pantry.path']]==lock['pkl-pantry.revision']
 newreports=[]
 for n in sorted(extra):
  row=index[n];assert row['mode']=='100644';newreports.append({'path':n,'gitBlob':row['oid'],**objects[row['oid']]})
 # Preserve staged doc bytes and source diffs for content/claim review, without
 # reading current live docs or rewriting the index.
 for n in sorted(DOCS):
  if n not in index:continue
  data=bodies[index[n]['oid']];q=output/'staged-docs'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
  old=(CAND/'sources'/n).read_text()if n in all_sources else''
  patch=''.join(difflib.unified_diff(old.splitlines(True),data.decode().splitlines(True),fromfile='C01/'+n,tofile='index/'+n));q=output/'doc-diffs'/Path(n+'.diff');q.parent.mkdir(parents=True,exist_ok=True);q.write_text(patch)
 assert git(STAGE,['ls-files','--stage','-z'])==raw and git(STAGE,['rev-parse','HEAD']).decode().strip()==head
 (output/'index-stage.z').write_bytes(raw);dump(output/'project-source-bindings.json',source_rows);dump(output/'allowed-post-c01-changes.json',changes);dump(output/'new-publication-files.json',newreports)
 dump(output/'inventory-fingerprints.json',[{'jsonPath':list(p),'before':a,'after':b}for p,a,b in fingerprints]);dump(output/'git-object-hashes.json',objects)
 dump(output/'report.json',{'schema':1,'scope':'Read-only actual staged Git index blob/mode audit after root staging. No Git/index/source mutation or evaluator/test/build rerun.','head':head,'indexStageSha256':sha(raw),'indexStableBeforeAfter':True,'candidateReleaseSha256':RELEASE_PIN,'candidateSourceMapSha256':MAP_PIN,'candidateProjectFiles':len(project),'unchangedProjectFiles':sum(r['sameAsC01']for r in source_rows),'postCandidateChangedPaths':changes,'newPublicationOrDocFiles':newreports,'actualIndexBlobsRead':len(objects),'pinnedGitlinks':GITLINKS,'externalProofReuse':{'reportPath':str(CORE_REVIEW/'report.json'),'reportSha256':CORE_REVIEW_PIN,'closureSha256':CORE_CLOSURE_PIN,'regularExternalSnapshotFilesNotRewalked':len(all_sources)-len(project),'externalSymlinksAlreadyVerified':11},'inventory':{'existingFingerprintChanges':len(fingerprints),'otherFieldsChanged':False,'eachNewShaMatchesStagedSource':True},'runtimeCargoFixturesUnchanged':True,'allowedConsumerHashes':CONSUMER,'gitModeScope':'Git100644/100755 records executable bit; complete Unix modes remain in original C01 source metadata.','docClaimReview':'Exact staged doc bytes/diffs saved for review; this source audit does not itself claim all prose semantically approved.','originalChanges':[]})
 print(json.dumps({'projectFiles':len(project),'changedPaths':len(changes),'newFiles':len(newreports),'indexStageSha256':sha(raw),'runtimeCargoFixturesUnchanged':True}))

def main():
 p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');p.add_argument('--audit',action='store_true');p.add_argument('--root-staging-complete',action='store_true');p.add_argument('--output',type=Path);a=p.parse_args()
 if a.prepare:
  assert not a.audit
  print(json.dumps({'status':'prepared-not-run','stagingRequired':True,'allowedExistingDocs':sorted(DOCS),'allowedConsumers':CONSUMER,'inventoryShaOnly':71,'newPublicationPrefix':'reports/m2/stage48','gitWrites':False}));return
 assert a.audit and a.root_staging_complete and a.output is not None,'Run only after explicit root staging-complete confirmation, with fresh output.'
 assert a.output.resolve().is_relative_to(MAIN/'target/m2'),'Audit output must be a new MAIN target/m2 root.';audit(a.output.resolve())
if __name__=='__main__':main()
