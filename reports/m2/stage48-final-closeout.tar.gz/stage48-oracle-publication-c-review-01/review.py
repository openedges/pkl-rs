from pathlib import Path,PurePosixPath
import tarfile,json,hashlib,stat,os
O=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');P=S/'target/m2/stage48-oracle-publication-02';h=lambda b:hashlib.sha256(b).hexdigest();inputs={}
def read(p):
 p=Path(p);assert stat.S_ISREG(p.lstat().st_mode);b=p.read_bytes();r={'sha256':h(b),'bytes':len(b),'mode':stat.S_IMODE(p.lstat().st_mode)};assert inputs.setdefault(str(p),r)==r;return b
def obj(p):return json.loads(read(p))
def save(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
handoff=obj(P/'handoff-final.json');assert h(read(P/'handoff-final.json'))=='c3757cfb45e18a702b1ddec99ef9d7cb413445a425a86381388314c0ca11244f'
idx=obj(P/'index.json');report=obj(P/'report.json');summary=obj(P/'summary.json');closure=obj(P/'closure.json')
assert h(read(P/'index.json'))==handoff['indexSha256']=='7735388de2d73c5b581c0de410024f736d8b0eb1158e9972afad0097757136bc'
assert h(read(P/'report.json'))==handoff['reportSha256']=='61c4f1c8ceac58d26a138bba6d83aa7875e405d738c94fcf25dad4d2869d2838'
assert h(read(P/'summary.json'))==handoff['summarySha256']=='adf2cb38b388a6fc69a2303416b00492992eed3c141049fc7ef93c04c8aa649a'
assert h(read(P/'closure.json'))=='286be2f37b0751e995a2c1efaa5c2a746598c90f6bf9273b610ca155cd49515c' and closure['closed'] and closure['originalChanges']==[]
inv=obj(P/'final-closeout-inventory.json');assert h(read(P/'final-closeout-inventory.json'))==closure['inventorySha256']
for n,r in inv['files'].items():b=read(P/n);assert len(b)==r['bytes']and h(b)==r['sha256']
selection=obj(P/'selection.json');refs=obj(P/'references.json');assert h(read(P/'selection.json'))==handoff['selectionSha256']==idx['selectionSha256']and h(read(P/'references.json'))==handoff['referencesSha256']==idx['referencesSha256']
assert selection['rawFiles']==36596==len(selection['files'])and len(selection['roots'])==18 and len(selection['prewalkPrune'])==3 and not selection['unlistedPayload']
rows={(r['group'],r['member']):r for r in selection['files']};assert len(rows)==36596
verified=[];archives=[];actual_links=[]
for a in handoff['archives']:
 path=Path(a['archive']);assert h(read(path))==a['sha256']and path.stat().st_size==a['compressedBytes']<100*1024*1024
 with tarfile.open(path,'r:gz')as t:
  members=t.getmembers();names=[m.name for m in members];assert len(names)==len(set(names))and all(m.isfile()and m.mode==0o644 for m in members)
  for n in names:p=PurePosixPath(n);assert not p.is_absolute()and'..'not in p.parts
  ev=json.loads(t.extractfile('EVIDENCE.json').read());expected={r['path']:r for r in ev['files']};assert set(expected)==set(names)-{'EVIDENCE.json'}and len(expected)==a['payloadFiles']
  if a['group']!='closeout':
   capture=json.loads(t.extractfile('CAPTURE_SELECTION.json').read());assert capture['selectionSha256']==handoff['selectionSha256']and capture['group']==a['group']
   assert t.extractfile('EXTERNAL_REFERENCES.json').read()==read(P/'references.json')
  for n,r in expected.items():
   b=t.extractfile(n).read();assert len(b)==r['bytes']and h(b)==r['sha256']
   if (a['group'],n)in rows:
    f=rows[(a['group'],n)];p=Path(f['source']);st=p.lstat();assert stat.S_IMODE(st.st_mode)==f['mode']
    if f['kind']=='regular':assert stat.S_ISREG(st.st_mode)and read(p)==b
    else:
     assert f['kind']=='symlink'and stat.S_ISLNK(st.st_mode);link=os.fsencode(os.readlink(p));assert link==b==os.fsencode(f['linkTarget'])
     target=p.parent/f['linkTarget'];assert stat.S_ISREG(target.lstat().st_mode)and h(read(target))==f['targetPayloadSha256'];actual_links.append(f)
    assert h(b)==f['sha256']and len(b)==f['bytes'];verified.append({'archive':a['fileName'],'member':n,'source':f['source'],'kind':f['kind'],'mode':f['mode'],'sha256':h(b),'bytes':len(b)})
  archives.append({'name':a['fileName'],'sha256':a['sha256'],'compressedBytes':a['compressedBytes'],'payloadFiles':len(expected)})
assert len(verified)==36596and len(actual_links)==1and sum(a['compressedBytes']for a in archives)==8402980
assert summary['nativeC01']['rawApiByteMatches']==440and summary['nativeC01']['explicitUnexecutedSpiApiCalls']==212and summary['nativeC01']['fullLifecyclePassSessions']==0and summary['nativeC01']['fullLifecycleFailedSessions']==52
assert summary['portableC01']['nodeRawApiByteMatches']==summary['portableC01']['browserRawApiByteMatches']==84and summary['portableC01']['fullLifecycleFailedSessionsPerTarget']==12and summary['portableC01']['driverExitCode']==summary['portableC01']['wrapperExitCode']==1
assert report['dataWorkerActualTerminal']['exitCode']==0and report['dataWorkerActualTerminal']['pid']==48501and all(c['exitCode']==0 for c in report['closeoutCommands'])and report['allCreateAndSeparateVerify0']
term=obj(P/'finalizer-tool-terminal.json');assert h(read(P/'finalizer-tool-terminal.json'))==handoff['finalizerToolTerminalSha256']
for side in ['stdout','stderr']:assert h(read(P/('publisher.'+side+'.bin')))==report['dataWorkerActualTerminal'][side+'Sha256']
fixture=refs['permanentPolicyFixture'];assert len(fixture['files'])==1444
for n,r in fixture['files'].items():b=read(S/n);assert h(b)==r['sha256']and len(b)==r['bytes']
old=refs['priorStage47JavaPolicyOriginal'];b=read(S/old['archiveRepositoryPath']);assert h(b)==old['sha256']and len(b)==old['bytes']
canonical=refs['canonicalNativeAndPlatforms'];c=obj(Path(canonical['nativeBuildRoot'])/'release.json');assert h(read(Path(canonical['nativeBuildRoot'])/'release.json'))==canonical['C01ReleaseSha256']and c['source_map_sha256']==canonical['sourceMapSha256']
# Existing semantic/raw reviews are referenced, not re-executed here.
for root,name,pin in [('stage48-policy-native-c01-audit-01','handoff.json','56d37854a0e3ecd8888534945c1589a16df456988afaf0040ff1156f8eddf45b'),('stage48-policy-portable-c01-audit-01','handoff.json','88b535dfcfa81ad4a1c2cc9874f74015627ccd5afa4206c9317441cf2a383632')]:assert h(read(S/'target/m2'/root/name))==pin
core=obj(S/'target/m2/stage48-core-publication-proposal-01/selected-files.json');root=obj(S/'target/m2/stage48-root-publication-proposal-01/selection.json');corepaths={r['original']for r in core};rootpaths={r['original']for r in root['files']};bpaths={r['source']for r in selection['files']};assert not(bpaths&corepaths)and not(bpaths&rootpaths)
for p,r in inputs.items():assert h(Path(p).read_bytes())==r['sha256']
for r in actual_links:p=Path(r['source']);assert p.is_symlink()and os.readlink(p)==r['linkTarget']and stat.S_IMODE(p.lstat().st_mode)==r['mode']
save('inputs.json',inputs);save('archive-original-joins.json',verified)
save('report.json',{'schema':1,'scope':'Quick independent read-only B final publication archive/source-mode/link/reference review. Earlier semantic/raw audits reused; no evaluator/build/tests/Java/Git reruns or full C01 source traversal.','handoffSha256':h(read(P/'handoff-final.json')),'indexSha256':h(read(P/'index.json')),'reportSha256':h(read(P/'report.json')),'closureSha256':h(read(P/'closure.json')),'archives':archives,'selectedOriginalFiles':len(verified),'sourceRoots':18,'literalSymlinkRepresentations':actual_links,'modeScope':'Tar headers0644; original kind/mode/path/target bytes available in each CAPTURE_SELECTION and final selection. Restore literal symlink explicitly; never execute regular target-byte payload as Pkl source.','externalReferences':{'fixtureFiles':1444,'fixtureFinalGitBinding':'Root staged-source audit still pending.','priorArchiveSha256':old['sha256'],'C01ReleaseSha256':canonical['C01ReleaseSha256'],'snapshotAndBinaryOwnership':'Core/root canonical hash references; no duplicated full source/binaries or ancestor ownership overlap.'},'claims':'Native440 API matches vs212explicitunexecuted and0/52fulltrace; portable84each vs12fullfail each. Raw16queryname errors,36lazycycle intent misses, unsealed metadata, first seal flaw and select.py shadow failure remain qualified.','materialPublicationIssue':False,'originalChanges':[],'recursiveFilesystemTraversal':False})
print(json.dumps({'archives':len(archives),'payloadFiles':sum(a['payloadFiles']for a in archives),'selectedOriginalFiles':len(verified),'literalLinks':len(actual_links),'fixtureReferences':1444,'originalChanges':[]}))
