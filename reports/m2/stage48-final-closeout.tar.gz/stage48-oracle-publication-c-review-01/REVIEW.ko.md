# Stage48 B 최종 게시 독립 검토

고정 handoff-final `c3757cfb…`와 index `7735388d…` / report `61c4f1c8…` / summary `adf2cb38…` / closure `286be2f3…`를 대조했다. actual20481exit0으로5archives의 전 payload36,664개(EVIDENCE 자체 제외),선택원본36,596개의 바이트·길이·kind·mode 및 archive path set을 확인했다. 합8,402,980bytes로 모두100MiB미만이다. 원본변경0,새평가/빌드/테스트/Java/Git실행0이며 기존 raw 의미검토를 재사용했다.

Java workspace symlink1개는regular `.symlink-target.bin`에 literal `actual/main.pkl`15bytes로 보관하고 CAPTURE_SELECTION에원형kind/mode/target payload SHA를기록한다. 실제link와별도로보관된target source도일치한다. 복원자는이metadata로symlink를만들어야하며target-byte파일을Pkl원문으로사용하면안된다. tar header0644와실제mode의구분도명시돼있다.

영구policyfixture1,444files는repo상대경로·SHA·길이참조와현재바이트가일치한다. 이전Stage47정책Javaarchive9ea79ec7…도hash참조로확인했다. C01native/artifact/source는core/root의canonicalrelease04881b69…/map9f546b82…로연결하고복제하지않는다. core 및rootpublication 선택원본과B선택원본의경로교집합은0이다. 영구fixture의최종Git index/commitbinding은root staged-source감사후완료할별도조건으로남아있다.

native440 APIbyte일치와212명시미실행·fullLifecycle0pass52fail,portable대상별84raw일치와12fullfail/strict1을분리했다. 16query-name실패·36lazycycleintentmiss,수정된100API의별도source/URI,initialselfseal문제와권위있는후속readback,closure없던metadata,select.py shadow실패가유지된다. 원래false/unknown상태를seal성공으로재표기하지않는다. 정확3prune는생성Pythoncache와두tests-private이며선택파일만읽어추가cache/tree탐색은하지않았다.

publisher56019/최종화37802의actual0receipt및create/별도verify기록이연결된다. finalmetadata중일부는closeout archive생성뒤쓰였으므로최종inventory·handoff·closure는외부게시파일로함께보존해야한다. Root의정확승격후원형archive명→repository명mapping은최종aggregate가담당한다. 구체적인새게시결함은발견하지못했다.
