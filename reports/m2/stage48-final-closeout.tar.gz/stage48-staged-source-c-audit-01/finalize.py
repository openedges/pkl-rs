from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');M=Path('/Users/cody.ij.hwang/Projects/pkl-rs');sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(O/'index-stage.z').read_bytes();tree={};index={}
for entry in raw.split(b'\0'):
 if not entry:continue
 header,path=entry.split(b'\t',1);mode,oid,stage=header.split(b' ');assert stage==b'0';index[path.decode()]={'mode':mode.decode(),'oid':oid.decode()};parts=path.split(b'/');node=tree
 for directory in parts[:-1]:node=node.setdefault(directory,{})
 node[parts[-1]]=(mode,bytes.fromhex(oid.decode()))
def treeoid(node):
 payload=b''
 for name,value in sorted(node.items(),key=lambda r:r[0]+(b'/'if isinstance(r[1],dict)else b'')):
  mode,oid=(b'40000',treeoid(value))if isinstance(value,dict)else value
  payload+=mode+b' '+name+b'\0'+oid
 return hashlib.sha1(b'tree '+str(len(payload)).encode()+b'\0'+payload).digest()
computed=treeoid(tree).hex();staging=(S/'target/m2/stage48-staging-01/report.json').read_bytes();sr=json.loads(staging);assert computed==sr['tree']=='477cfe7a84f5134526cb610de8eaf212a4bd82f0'and sr['changedFiles']==1550 and sr['exitCode']==0
objects=json.loads((O/'git-object-hashes.json').read_bytes())
cp=S/'reports/m2/stage48-implementation-checkpoint.json';b=cp.read_bytes();assert sha(b)=='eddf08599a03c648fd2237840068eae383934636137d10a85e13a69fa1d820e0'==objects[index['reports/m2/stage48-implementation-checkpoint.json']['oid']]['sha256'];current=json.loads(b)
oldpath=M/'target/m2/stage48-checkpoint-draft-c-review-01/evidence/checkpoint.json';old=json.loads(oldpath.read_bytes());assert sha(oldpath.read_bytes())=='616c43c450b867853d4eaa42482803ec1056f7bc46c088549f82425f0807462a'
for k,v in old.items():
 if k=='status':assert current[k]=='verified-local-checkpoint-awaiting-commit'
 elif k=='nativePolicy':assert {n:a for n,a in current[k].items()if n!='selectedRawApiScope'}==v and current[k]['selectedRawApiScope']==440
 else:assert current[k]==v,k
assert set(current)-set(old)=={'publication','policyFixtureVerification','providerVerification','independentRawPolicyReviews'}
pointers=[]
def checkpath(p):
 assert p in index,p;data=(S/p).read_bytes();r=objects[index[p]['oid']];assert sha(data)==r['sha256'] and len(data)==r['bytes'];pointers.append({'path':p,'gitBlob':index[p]['oid'],**r});return data
for p in current['publication'].values():checkpath(p)
# Check each repository-relative published pointer in the aggregate descriptors.
seen=set()
def walk(x):
 if isinstance(x,dict):
  for k,v in x.items():
   if isinstance(v,str)and v.startswith('reports/m2/')and v in index and v not in seen:seen.add(v);checkpath(v)
   else:walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
for p in current['publication'].values():walk(json.loads((S/p).read_bytes()))
(O/'reviewed-checkpoint.json').write_bytes(b)
summary={'computedIndexTree':computed,'rootStagingReportSha256':sha(staging),'rootStagedChangedFiles':1550,'indexStageSha256':sha(raw),'treeConstruction':'Pure Git tree SHA1 reconstruction from captured actual index modes/names/object IDs, no git write-tree or object/index mutation.','checkpointSha256':sha(b),'draftClaimFieldsUnchangedExceptStatusAndSelectedScope':True,'newCheckpointFields':['publication','policyFixtureVerification','providerVerification','independentRawPolicyReviews'],'publishedPointerBindings':pointers,'stagedDocClaimReview':'Supported scoped semantics and explicit full-policy/full-M2 gaps match earlier frozen source/raw reviews; planning SelectKey remains explicitly unimplemented.','originalChanges':[]}
(O/'final-index-binding.json').write_text(json.dumps(summary,indent=2)+'\n');report=json.loads((O/'report.json').read_bytes());report['finalIndexBinding']={'path':'final-index-binding.json','sha256':sha((O/'final-index-binding.json').read_bytes()),'tree':computed,'checkpointSha256':sha(b)};(O/'final-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'tree':computed,'checkpoint':sha(b),'pointers':len(pointers),'finalReportSha256':sha((O/'final-report.json').read_bytes())}))
