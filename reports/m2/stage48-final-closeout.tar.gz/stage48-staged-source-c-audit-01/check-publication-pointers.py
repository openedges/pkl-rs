from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parent;S=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48');M=Path('/Users/cody.ij.hwang/Projects/pkl-rs');h=lambda b:hashlib.sha256(b).hexdigest();objects=json.loads((O/'git-object-hashes.json').read_bytes());idx={}
for entry in (O/'index-stage.z').read_bytes().split(b'\0'):
 if entry:
  header,p=entry.split(b'\t',1);mode,oid,stage=header.decode().split();idx[p.decode()]={'mode':mode,'oid':oid}
checked=[]
def verify(p,expected=None,size=None):
 assert p in idx;pbytes=(S/p).read_bytes();actual=objects[idx[p]['oid']];assert h(pbytes)==actual['sha256'] and len(pbytes)==actual['bytes']
 if expected is not None:assert actual['sha256']==expected,(p,expected,actual['sha256'])
 if size is not None:assert actual['bytes']==size
 checked.append({'repositoryPath':p,'gitBlob':idx[p]['oid'],**actual})
for review in ['stage48-core-publication-c-review-01','stage48-root-publication-c-review-02','stage48-oracle-publication-c-review-01']:
 r=json.loads((M/'target/m2'/review/'report.json').read_bytes())
 for a in r['archives']:
  name=a.get('name')or Path(a['path']).name;verify('reports/m2/'+name,a['sha256'],a.get('compressedBytes',a.get('bytes')))
# Explicit repositoryPath pairs and root-owned mode-table archive references.
def walk(v):
 if isinstance(v,dict):
  for key in ['repositoryPath','repository_path']:
   p=v.get(key)
   if isinstance(p,str)and p.startswith('reports/m2/'):verify(p,v.get('sha256'),v.get('bytes'))
  for value in v.values():walk(value)
 elif isinstance(v,list):
  for value in v:walk(value)
for n in ['stage48-platform-captures.json','stage48-oracle-promotion.json']:
 p='reports/m2/'+n;verify(p);walk(json.loads((S/p).read_bytes()))
r=json.loads((S/'reports/m2/stage48-root-metadata-publication.json').read_bytes());verify('reports/m2/stage48-root-metadata.tar.gz',r['archive']['sha256'],r['archive']['bytes'])
(O/'publication-index-bindings.json').write_text(json.dumps({'scope':'Actual staged blob hashes joined to already independently reviewed archive hashes and explicit promotion mappings; no archive/evaluator rerun.','bindings':checked,'originalChanges':[]},indent=2)+'\n')
print(json.dumps({'bindings':len(checked),'sha256':h((O/'publication-index-bindings.json').read_bytes())}))
