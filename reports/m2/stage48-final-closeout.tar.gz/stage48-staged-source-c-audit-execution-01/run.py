from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).resolve().parent;M=O.parents[2];script=M/'target/m2/stage48-staged-source-c-audit-proposal-01/audit.py';out=M/'target/m2/stage48-staged-source-c-audit-01';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert h(script)=='55393056fe8a53a51451951501c90d543f836d1b5b2f0e451dc751ff66eb3d56'
cmd=[sys.executable,str(script),'--audit','--root-staging-complete','--output',str(out)];r={'command':cmd,'cwd':str(M),'startedUtc':datetime.datetime.now(datetime.UTC).isoformat(),'parentPid':os.getpid(),'scriptSha256':h(script),'scope':'Read-only actual staged Git index blob audit; no Git/source writes or evaluator execution.'}
with(O/'stdout.bin').open('wb')as stdout,(O/'stderr.bin').open('wb')as stderr:
 c=subprocess.Popen(cmd,cwd=M,env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr);r['pid']=c.pid;(O/'launch.json').write_text(json.dumps(r,indent=2)+'\n');r['exitCode']=c.wait()
r.update(finishedUtc=datetime.datetime.now(datetime.UTC).isoformat(),stdoutSha256=h(O/'stdout.bin'),stderrSha256=h(O/'stderr.bin'));(O/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(r['exitCode'])
