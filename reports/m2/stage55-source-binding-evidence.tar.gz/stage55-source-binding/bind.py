#!/usr/bin/env python3
"""Resolve immutable Stage55 input catalogs against actual committed Git blobs."""
import datetime, hashlib, io, json, pathlib, subprocess, tarfile
from collections import Counter

ROOT = pathlib.Path(__file__).resolve().parents[3]
OUT = pathlib.Path(__file__).resolve().parent
B = 'f82060d395d6c1cb16aef2b94a48a2d8f28440b1'
A = '6cc264eff87ad4a4b4e025309800946e33631e1d'
EXPECTED_AUDIT = '92f6bb75092ba214d66aadab9e70b41827f33331370cb7434342e0d1a02af664'
EXPECTED_RUST = '81349df248ddcc93a5387e662b32ff4fb68789cd9d597b398cc7de04c66a6184'
errors = []

def digest(data): return hashlib.sha256(data).hexdigest()
def raw(rel): return (ROOT / rel).read_bytes()
def read(rel): return json.loads(raw(rel))
def identity(data): return {'sha256':digest(data),'bytes':len(data)}
def write(name, data):
    path=OUT/name
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f: f.write(data)
def js(data): return (json.dumps(data,indent=2,sort_keys=True)+'\n').encode()
def require(condition, message):
    if not condition: errors.append(message)
def git(repo,*args): return subprocess.check_output(['git','-C',str(ROOT/repo),*args])
def tree(repo,commit):
    result={}
    for item in git(repo,'ls-tree','-r','-z',commit).split(b'\0'):
        if not item: continue
        fields,path=item.split(b'\t',1); mode,kind,oid=fields.decode().split()
        result[path.decode()]={'mode':mode,'kind':kind,'oid':oid}
    return result

audit_raw=raw('target/m2/stage55-final-review-01/validation-audit.json')
require(digest(audit_raw)==EXPECTED_AUDIT,'Prior full actual Git-blob audit identity changed')
seal=read('target/m2/stage55-final-review-01/seal.json')
for name,expected in seal['files'].items():
    require(identity(raw('target/m2/stage55-final-review-01/'+name))==expected,'Prior audit seal mismatch: '+name)
require(not json.loads(audit_raw)['blockers'],'Prior byte audit had blockers')
rust_raw=raw('target/m2/stage55-rust-validation-01/sources.json')
require(digest(rust_raw)==EXPECTED_RUST,'Required Rust original manifest changed')
rust=json.loads(rust_raw)
require(len(rust)==163100,'Required Rust original input count changed')

b_tree=tree('.',B); a_tree=tree('.',A)
gitlinks={path:item['oid'] for path,item in b_tree.items() if item['kind']=='commit'}
repo_trees={'.':b_tree}
for repo,commit in gitlinks.items(): repo_trees[repo]=tree(repo,commit)
old_trees={'.':a_tree}
for repo in {v['origin']['repository'] for v in rust.values() if v['origin']['kind']=='git-blob'}- {'.'}:
    commits={v['origin']['commit'] for v in rust.values() if v['origin'].get('repository')==repo}
    require(len(commits)==1,'Ambiguous old external commits: '+repo)
    old_trees[repo]=tree(repo,next(iter(commits)))

def locate(path):
    for repo in sorted(gitlinks,key=len,reverse=True):
        if path.startswith(repo+'/'): return repo,path[len(repo)+1:]
    return '.',path

# Reuse only the exact OID identities whose actual bytes the sealed prior audit read.
verified={}
for path,record in rust.items():
    origin=record['origin']
    if origin['kind']!='git-blob': continue
    repo=origin['repository']; old=old_trees[repo].get(origin['path'])
    require(old is not None and old['kind']=='blob' and old['oid']==origin['oid'],'Original Git A origin mismatch: '+path)
    expected_commit=A if repo=='.' else gitlinks.get(repo)
    require(origin['commit']==expected_commit,'Unexpected original commit: '+path)
    key=(repo,origin['oid']); value=(record['sha256'],record['bytes'])
    require(key not in verified or verified[key]==value,'Conflicting original blob catalog: '+path)
    verified[key]=value

catalog_specs=[
 ('required-rust','target/m2/stage55-rust-validation-01/sources.json',None,163100),
 ('final-frame','target/m2/stage55-frame-final-01/report.json','sources_before',4503),
 ('legacy-regression','target/m2/stage55-legacy-regression-01/sources-before.json',None,4553),
 ('platform-and-native-release','target/m2/stage55-platform-run-02/sources.json',None,242),
 ('m1-platform','target/m2/stage55-platforms-02/sources.json',None,215),
 ('native-debug-build-02','target/m2/stage55-native-build-02/sources.json',None,241),
 ('tooling-validation','target/m2/stage55-tooling-validation-01/sources.json',None,4504),
]
groups=[]; pending=[]
for name,rel,field,count in catalog_specs:
    data=raw(rel); obj=json.loads(data); catalog=obj[field] if field else obj
    require(len(catalog)==count,'Input count changed: '+name)
    if name=='final-frame': require(catalog==obj['sources_after'],'Final frame source before/after mismatch')
    if name=='legacy-regression': require(catalog==read('target/m2/stage55-legacy-regression-01/sources-after.json'),'Legacy source before/after mismatch')
    write('catalogs/'+name+'.json',data)
    info={'group':name,'original_catalog':rel,'original_catalog_identity':identity(data),'field':field,'count':len(catalog),'binding_commit':B}
    groups.append(info)
    for path,value in sorted(catalog.items()):
        expected=value['sha256'] if isinstance(value,dict) else value
        repo,gitpath=locate(path); item=repo_trees[repo].get(gitpath)
        if item is None or item['kind']!='blob':
            errors.append('Missing B tree blob: '+name+':'+path); continue
        key=(repo,item['oid'])
        pending.append((name,path,expected,repo,gitpath,item,key))

# Independently read actual B object bytes for every identity not covered by the
# previous exact OID audit, including changed/captured sources and extra catalogs.
need={key for *_,key in pending if key not in verified}
streamed={}; read_stats={}
for repo in sorted({key[0] for key in need}):
    keys=sorted(key for key in need if key[0]==repo)
    proc=subprocess.Popen(['git','-C',str(ROOT/repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    total=0
    for key in keys:
        oid=key[1]; proc.stdin.write((oid+'\n').encode());proc.stdin.flush()
        header=proc.stdout.readline().decode().strip().split()
        if len(header)!=3 or header[0]!=oid or header[1]!='blob': raise RuntimeError('Unexpected Git object header: '+repr(header))
        size=int(header[2]); remain=size; sha=hashlib.sha256(); framed=hashlib.sha1(('blob '+str(size)+'\0').encode())
        while remain:
            chunk=proc.stdout.read(min(remain,1024*1024))
            if not chunk: raise RuntimeError('Truncated actual Git B blob: '+oid)
            sha.update(chunk);framed.update(chunk);remain-=len(chunk)
        if proc.stdout.read(1)!=b'\n': raise RuntimeError('Missing Git blob terminator')
        require(framed.hexdigest()==oid,'Actual Git B SHA1 framing mismatch: '+oid)
        streamed[key]=(sha.hexdigest(),size);total+=size
    proc.stdin.close();stderr=proc.stderr.read();code=proc.wait()
    require(code==0 and stderr==b'','Git cat-file B process failed: '+repo)
    read_stats[repo]={'unique_blobs':len(keys),'actual_bytes_streamed':total,'exit_code':code,'stderr_sha256':digest(stderr)}

# Re-read the 63 original captured inputs independently; no source payload copies.
captured=0
for path,record in rust.items():
    if record['origin']['kind']!='captured-file': continue
    content=raw('target/m2/stage55-rust-validation-01/'+record['origin']['path'])
    require(identity(content)=={'sha256':record['sha256'],'bytes':record['bytes']},'Captured Rust source changed: '+path)
    captured+=1
require(captured==63,'Original captured Rust source count changed')

methods=Counter(); row_count=0
with (OUT/'bindings.jsonl').open('xb') as rows:
    for name,path,expected,repo,gitpath,item,key in pending:
        method='reused-exact-oid-prior-actual-byte-audit' if key in verified else 'independent-actual-B-blob-byte-read'
        actual=verified[key] if key in verified else streamed[key]
        match=actual[0]==expected
        require(match,'Source SHA256 differs from B: '+name+':'+path)
        if name=='required-rust': require(actual[1]==rust[path]['bytes'],'Rust source byte length differs from B: '+path)
        row={'group':name,'path':path,'source_sha256':expected,'bytes':actual[1],'repository':repo,'commit':B if repo=='.' else gitlinks[repo],'git_path':gitpath,'git_blob':item['oid'],'git_mode':item['mode'],'verification':method,'actual_sha256':actual[0],'matches':match}
        if name=='required-rust': row['original_origin']=rust[path]['origin']
        rows.write((json.dumps(row,separators=(',',':'),sort_keys=True)+'\n').encode());methods[method]+=1;row_count+=1
require(row_count==177358,'B-bound exact total row count changed')

# The Java checkpoint is deliberately a separate A association, not relabelled B.
java_rel='target/m2/stage55-oracle-git-01/source-binding.json'
java_raw=raw(java_rel); original_java=json.loads(java_raw)
java_catalog_rel='target/m2/stage55-oracle-checkpoint-validation-01/sources.json'
java_catalog=read(java_catalog_rel)
require(original_java['commit']==A and original_java['count']==21 and original_java['all_match'],'Java A checkpoint association changed')
require(set(java_catalog)=={x['path'] for x in original_java['checked_inputs']},'Java A catalog name closure differs')
java_rows=[]
for source in original_java['checked_inputs']:
    path=source['path'];item=a_tree.get(path)
    require(item is not None and item['kind']=='blob' and item['oid']==source['git_blob'],'Java A tree mismatch: '+path)
    content=git('.','cat-file','blob',A+':'+path)
    ident=identity(content); framed=hashlib.sha1(('blob '+str(len(content))+'\0').encode()+content).hexdigest()
    match=ident=={'sha256':source['sha256'],'bytes':source['bytes']} and java_catalog[path]==ident and framed==item['oid']
    require(match,'Java A actual source mismatch: '+path)
    java_rows.append({'path':path,**ident,'commit':A,'git_blob':item['oid'],'actual_blob_bytes_verified':True,'matches':match})
write('java-A-original-binding.json',java_raw)
write('java-A-original-catalog.json',raw(java_catalog_rel))
write('java-A-verified.json',js({'commit':A,'original_binding':java_rel,'original_binding_identity':identity(java_raw),'catalog':java_catalog_rel,'catalog_identity':identity(raw(java_catalog_rel)),'count':len(java_rows),'all_match':all(x['matches'] for x in java_rows),'rows':java_rows}))
write('prior-byte-audit.json',audit_raw)
write('prior-byte-audit-seal.json',raw('target/m2/stage55-final-review-01/seal.json'))

report={'schema':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Post-commit source provenance only. No compilation, tests, Java or candidate evaluations. No compatibility status changes.','implementation_commit':B,'original_project_source_commit':A,'gitlinks':gitlinks,'groups':groups,'B_binding_rows':row_count,'B_binding_methods':dict(methods),'independent_B_actual_blob_reads':read_stats,'required_rust_original_captured_files_rechecked':captured,'prior_actual_blob_byte_audit':{'path':'target/m2/stage55-final-review-01/validation-audit.json','sha256':EXPECTED_AUDIT,'seal_path':'target/m2/stage55-final-review-01/seal.json','seal_identity':identity(raw('target/m2/stage55-final-review-01/seal.json')),'original_manifest_sha256':EXPECTED_RUST,'unique_old_blob_objects_verified':len(verified)},'bindings_jsonl':identity((OUT/'bindings.jsonl').read_bytes()),'Java_checkpoint':{'association_commit':A,'source_count':len(java_rows),'independent_actual_A_blob_reads':21,'details':'java-A-verified.json','original_binding_identity':identity(java_raw)},'historical_scope':'Initial native dev01/build01 and earlier platform failures retain their original captured sources. This resolution binds only the seven explicitly listed catalogs to B. It does not assert that initial dev01 sources equal B. Original reports, pending-binding strings and failures remain unchanged.','reconstruction':'Each row identifies an exact Git tree blob and SHA256. Reconstruct project inputs from implementation commit B and submodule inputs from its gitlinks, preserving row paths; Java checkpoint inputs use A. Git objects and the referenced existing source evidence are required. This archive does not duplicate full source payloads. Prior exact-OID byte verification is explicitly reused, rather than represented as newly re-read B bytes.','validation_scope':'Final frame comparison remains strict failed: 246 whole-session passes and 42 preserved nonpasses across three targets. Java-only buffer supplement remains unexecuted by candidates. Required Rust evidence and its separate Wasm retry retain their original outcomes; this adds provenance only.','errors':errors,'all_match':not errors}
write('report.json',js(report))
write('README.md',b'''Stage55 post-commit source binding\n\nThis archive resolves seven immutable source catalogs to implementation commit B and its pinned gitlinks. bindings.jsonl contains every input, original SHA256, exact tree blob, byte count, verification method and match result. The 163,037 original Git-backed required-Rust paths reuse only exact OIDs from the sealed independent actual-byte audit. New or different B identities are independently streamed from actual Git blobs. The 63 captured required-Rust files are re-read against their original catalog.\n\nThe Java 21-source checkpoint is separately verified from actual A blobs. Original captures, historical failures and pending-binding text are unchanged. No guest evaluations or checks were rerun. No compatibility pass is added. The archive omits full source payload duplicates; reconstruct from the named Git commits/gitlinks and verify each row. catalogs/ preserves the exact original manifest/report bytes used. report.json states the reuse and remaining scope.\n''')
# Self-contained metadata integrity closure, including the script, excluding manifest itself.
initial_report=(OUT/'initial-failure/report.json').read_bytes()
initial_archive=(OUT/'initial-failure/stage55-source-binding-evidence.tar.gz').read_bytes()
write('initial-failure.json',js({'scope':'Preserved first target-local binding harness failure, not an evaluator failure. No source or guest rerun.', 'exit_code':1,'session_id':99195,'terminal_chunk':'f0f752','cause':'The Java catalog stores structured {sha256, bytes} records; the initial harness compared each record to a SHA256 string. All 21 actual byte hashes and OIDs agreed. Corrected to structured identity comparison.','original_report':identity(initial_report),'original_archive':identity(initial_archive),'original_errors':json.loads(initial_report)['errors'],'preserved_target_directory':'target/m2/stage55-source-binding-01/initial-failure'}))
files={p.relative_to(OUT).as_posix():identity(p.read_bytes()) for p in sorted(OUT.rglob('*')) if p.is_file() and 'initial-failure' not in p.relative_to(OUT).parts}
write('MANIFEST.json',js({'schema':1,'files':files}))
archive=ROOT/'reports/m2/stage55-source-binding-evidence.tar.gz'
with archive.open('xb') as target:
    with tarfile.open(fileobj=target,mode='w:gz',compresslevel=9) as tar:
        for p in sorted(OUT.rglob('*')):
            if p.is_file() and 'initial-failure' not in p.relative_to(OUT).parts:
                name=p.relative_to(OUT).as_posix();content=p.read_bytes();info=tarfile.TarInfo('stage55-source-binding/'+name);info.size=len(content);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(content))
# Re-read every archived payload and exact member set, reject duplicates and unsafe entries.
seen={};prefix='stage55-source-binding/'
with tarfile.open(archive,'r:gz') as tar:
    for member in tar:
        if not member.isfile() or not member.name.startswith(prefix): raise RuntimeError('Unsafe archive member')
        name=member.name[len(prefix):];parts=pathlib.PurePosixPath(name).parts
        if not name or name in seen or '..' in parts or pathlib.PurePosixPath(name).is_absolute(): raise RuntimeError('Duplicate or unsafe archive path')
        content=tar.extractfile(member).read();seen[name]=identity(content)
        expected=identity((OUT/name).read_bytes())
        if seen[name]!=expected: raise RuntimeError('Archive byte mismatch: '+name)
expected_names=set(files)|{'MANIFEST.json'}
if set(seen)!=expected_names: raise RuntimeError('Archive exact file-set mismatch')
manifest=read(str((OUT/'MANIFEST.json').relative_to(ROOT)))
if {k:v for k,v in seen.items() if k!='MANIFEST.json'}!=manifest['files']: raise RuntimeError('Archive manifest closure mismatch')
public={**report,'evidence_archive':{'path':str(archive.relative_to(ROOT)),**identity(archive.read_bytes()),'payload_files':len(seen),'safe_unique_regular_paths':True,'full_manifest_and_byte_reread_verified':True},'archive_report_identity':identity((OUT/'report.json').read_bytes()),'archive_manifest_identity':identity((OUT/'MANIFEST.json').read_bytes())}
public_path=ROOT/'reports/m2/stage55-source-binding.json'
with public_path.open('xb') as f:f.write(js(public))
print(json.dumps({'all_match':not errors,'errors':errors,'B_rows':row_count,'methods':dict(methods),'independent_B_reads':read_stats,'java_A_rows':len(java_rows),'archive':public['evidence_archive'],'public_report_sha256':digest(public_path.read_bytes())},indent=2))
if errors: raise SystemExit(1)
