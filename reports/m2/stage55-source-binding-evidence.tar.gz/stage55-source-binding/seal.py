#!/usr/bin/env python3
"""Package the independent review without changing any source binding row."""
import hashlib,io,json,pathlib,tarfile
ROOT=pathlib.Path(__file__).resolve().parents[3];OUT=pathlib.Path(__file__).resolve().parent
archive=ROOT/'reports/m2/stage55-source-binding-evidence.tar.gz';public=ROOT/'reports/m2/stage55-source-binding.json'
def ident(data):return {'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
def js(data):return (json.dumps(data,indent=2,sort_keys=True)+'\n').encode()
old_public=json.loads(public.read_bytes());old_manifest=json.loads((OUT/'MANIFEST.json').read_bytes());review=json.loads((OUT/'independent-verification.json').read_bytes())
assert not review['blockers'] and old_public['all_match']
assert review['archive_checked']['sha256']==ident(archive.read_bytes())['sha256']
history=OUT/'publication-history';history.mkdir()
archive.rename(history/archive.name);public.rename(history/public.name);(OUT/'MANIFEST.json').rename(history/'MANIFEST.json')
(OUT/'publication-history.json').write_bytes(js({'scope':'Metadata-only extension after independent row audit. All previous archive payload bytes except MANIFEST.json remain unchanged. Added independent verification, verifier and sealing script; no binding or evaluation rerun.','pre_review_archive':ident((history/archive.name).read_bytes()),'pre_review_public_report':ident((history/public.name).read_bytes()),'pre_review_manifest':ident((history/'MANIFEST.json').read_bytes()),'independent_review_process':{'session_id':57798,'terminal_chunk':'03c947','exit_code':0}}))
exclude={'initial-failure','publication-history'}
files={p.relative_to(OUT).as_posix():ident(p.read_bytes()) for p in sorted(OUT.rglob('*')) if p.is_file() and not (set(p.relative_to(OUT).parts)&exclude)}
for name,expected in old_manifest['files'].items():assert files[name]==expected
(OUT/'MANIFEST.json').write_bytes(js({'schema':1,'files':files}))
with archive.open('xb') as target:
 with tarfile.open(fileobj=target,mode='w:gz',compresslevel=9) as tar:
  for name in sorted(set(files)|{'MANIFEST.json'}):
   data=(OUT/name).read_bytes();info=tarfile.TarInfo('stage55-source-binding/'+name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
seen={}
with tarfile.open(archive,'r:gz') as tar:
 for item in tar:
  assert item.isfile() and item.name.startswith('stage55-source-binding/')
  name=item.name[len('stage55-source-binding/'):];path=pathlib.PurePosixPath(name)
  assert name and name not in seen and not path.is_absolute() and '..' not in path.parts
  seen[name]=ident(tar.extractfile(item).read());assert seen[name]==ident((OUT/name).read_bytes())
assert set(seen)==set(files)|{'MANIFEST.json'}
assert {k:v for k,v in seen.items() if k!='MANIFEST.json'}==files
new_public={**old_public,'evidence_archive':{'path':str(archive.relative_to(ROOT)),**ident(archive.read_bytes()),'payload_files':len(seen),'safe_unique_regular_paths':True,'full_manifest_and_byte_reread_verified':True},'archive_manifest_identity':ident((OUT/'MANIFEST.json').read_bytes()),'implementation_tree':review['implementation_tree'],'gitlink_trees':review['gitlink_trees'],'independent_verification':{'file':'independent-verification.json',**ident((OUT/'independent-verification.json').read_bytes()),'B_rows_checked':review['binding_rows_checked'],'Java_A_rows_checked':review['Java_A_rows_checked'],'blockers':review['blockers'],'prepublication_payload_unchanged':True,'final_package_complete_manifest_reread_verified':True}}
public.write_bytes(js(new_public))
seal={'schema':1,'scope':'Final source-binding publication seal. Source evidence and original histories unchanged. Metadata-only extension is recorded.','implementation_commit':new_public['implementation_commit'],'all_match':new_public['all_match'],'errors':new_public['errors'],'binding_rows':new_public['B_binding_rows'],'Java_A_rows':new_public['Java_checkpoint']['source_count'],'archive':new_public['evidence_archive'],'public_report':{'path':str(public.relative_to(ROOT)),**ident(public.read_bytes())},'archive_manifest':ident((OUT/'MANIFEST.json').read_bytes()),'independent_verification':new_public['independent_verification'],'original_failed_harness_preserved':'initial-failure/','pre_review_publication_preserved':'publication-history/'}
(OUT/'seal.json').write_bytes(js(seal));print(json.dumps(seal,indent=2))
