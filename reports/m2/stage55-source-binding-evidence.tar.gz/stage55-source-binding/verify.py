#!/usr/bin/env python3
"""Independent read-only admission of source-binding archive and full row coverage."""
import collections,hashlib,json,pathlib,subprocess,tarfile
ROOT=pathlib.Path(__file__).resolve().parents[3]
OUT=pathlib.Path(__file__).resolve().parent
B='f82060d395d6c1cb16aef2b94a48a2d8f28440b1'
A='6cc264eff87ad4a4b4e025309800946e33631e1d'
def sha(data):return hashlib.sha256(data).hexdigest()
def ident(data):return {'sha256':sha(data),'bytes':len(data)}
def git(repo,*args):return subprocess.check_output(['git','-C',str(ROOT/repo),*args])
def tree(repo,commit):
 result={}
 for entry in git(repo,'ls-tree','-r','-z',commit).split(b'\0'):
  if entry:
   meta,path=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();result[path.decode()]=(mode,kind,oid)
 return result
archive=ROOT/'reports/m2/stage55-source-binding-evidence.tar.gz'
public=json.loads((ROOT/'reports/m2/stage55-source-binding.json').read_bytes())
assert public['all_match'] and not public['errors']
assert ident(archive.read_bytes())=={k:public['evidence_archive'][k] for k in ('sha256','bytes')}
with tarfile.open(archive,'r:gz') as tar:
 names={};payload={};prefix='stage55-source-binding/'
 for member in tar:
  assert member.isfile() and member.name.startswith(prefix)
  name=member.name[len(prefix):];path=pathlib.PurePosixPath(name)
  assert name and name not in names and not path.is_absolute() and '..' not in path.parts
  content=tar.extractfile(member).read();names[name]=ident(content)
  if name in ('report.json','MANIFEST.json','java-A-verified.json'):payload[name]=content
 manifest=json.loads(payload['MANIFEST.json'])
 assert {k:v for k,v in names.items() if k!='MANIFEST.json'}==manifest['files']
 report=json.loads(payload['report.json']);assert report['implementation_commit']==B
 assert all(public[k]==v for k,v in report.items())
 trees={'.':tree('.',B)}
 for repo,commit in report['gitlinks'].items():
  assert trees['.'][repo]==('160000','commit',commit)
  trees[repo]=tree(repo,commit)
 expected={};catalog_checks=[]
 for group in report['groups']:
  content=tar.extractfile(prefix+'catalogs/'+group['group']+'.json').read()
  assert ident(content)==group['original_catalog_identity']
  assert content==(ROOT/group['original_catalog']).read_bytes()
  data=json.loads(content);data=data[group['field']] if group['field'] else data
  assert len(data)==group['count']
  expected[group['group']]={path:record['sha256'] if isinstance(record,dict) else record for path,record in data.items()}
  catalog_checks.append({'group':group['group'],'count':len(data),'catalog_sha256':sha(content)})
 counts=collections.Counter();methods=collections.Counter();rows=0
 for line in tar.extractfile(prefix+'bindings.jsonl'):
  row=json.loads(line);group=row['group'];path=row['path']
  assert expected[group].pop(path)==row['source_sha256']==row['actual_sha256']
  assert row['matches'] is True
  repo=row['repository'];assert trees[repo][row['git_path']]==(row['git_mode'],'blob',row['git_blob'])
  assert row['commit']==(B if repo=='.' else report['gitlinks'][repo])
  assert path==(row['git_path'] if repo=='.' else repo+'/'+row['git_path'])
  assert type(row['bytes']) is int and row['bytes']>=0
  rows+=1;counts[group]+=1;methods[row['verification']]+=1
 assert rows==177358==report['B_binding_rows'] and not any(expected.values())
 assert dict(methods)==report['B_binding_methods']
 java=json.loads(payload['java-A-verified.json']);assert java['commit']==A and java['count']==21 and java['all_match']
 assert len(java['rows'])==21 and len({x['path'] for x in java['rows']})==21
 a_tree=tree('.',A)
 for row in java['rows']:
  assert row['matches'] is True and row['actual_blob_bytes_verified'] is True
  assert a_tree[row['path']][2]==row['git_blob'] and row['commit']==A
 assert names['bindings.jsonl']==report['bindings_jsonl']
retry_path='target/m2/stage55-wasm-validation-retry-01/report.json'
retry_bytes=(ROOT/retry_path).read_bytes();retry=json.loads(retry_bytes)
assert retry['original_source_manifest_sha256']==report['prior_actual_blob_byte_audit']['original_manifest_sha256']
assert retry['source_count']==163100 and retry['changed_before']==retry['changed_after']==[]
result={'schema':1,'scope':'Independent archive/raw-row admission only; no guest execution or compatibility status changes.','implementation_commit':B,'implementation_tree':git('.','rev-parse',B+'^{tree}').decode().strip(),'gitlink_trees':{repo:{'commit':commit,'tree':git(repo,'rev-parse',commit+'^{tree}').decode().strip()} for repo,commit in report['gitlinks'].items()},'Java_checkpoint_commit':A,'Java_checkpoint_tree':git('.','rev-parse',A+'^{tree}').decode().strip(),'archive_checked':{'path':str(archive.relative_to(ROOT)),**ident(archive.read_bytes()),'payload_files':len(names),'safe_unique_regular_paths':True,'exact_manifest_closure':True,'every_payload_byte_hash_reread':True},'catalogs':catalog_checks,'binding_rows_checked':rows,'group_counts':dict(counts),'row_methods':dict(methods),'every_catalog_path_once':True,'every_row_tree_oid_sha256_and_commit_association_checked':True,'Java_A_rows_checked':21,'wasm_retry_association':{'path':retry_path,**ident(retry_bytes),'original_manifest_sha256':retry['original_source_manifest_sha256'],'source_count':retry['source_count'],'changed_before':retry['changed_before'],'changed_after':retry['changed_after'],'exit_code':retry['exit_code'],'original_failure_preserved':retry['original_failed_check_preserved']},'successful_binding_process':{'session_id':31388,'terminal_chunk':'2db696','exit_code':0},'blockers':[]}
with (OUT/'independent-verification.json').open('x') as f:json.dump(result,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps({'rows':rows,'groups':dict(counts),'archive_files':len(names),'B_tree':result['implementation_tree'],'blockers':[]},indent=2))
