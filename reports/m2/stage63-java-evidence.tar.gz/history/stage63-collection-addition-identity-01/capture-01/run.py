"""Target-only direct Java Vm collection identity supplement."""
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
OUT = HERE / "capture-01"
SOURCES = (
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/binary/AdditionNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmCollection.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmList.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmSet.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmMap.java",
    "oracle.lock.json", "references.lock",
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def main():
    if OUT.exists():
        raise SystemExit("fresh capture required")
    lock = json.loads((ROOT / "oracle.lock.json").read_bytes())
    assert lock["version"] == "0.32.0"
    assert lock["source"]["revision"] == "e51fb2f91774265666f94980ec630db794a4db2d"
    jar = ROOT / ".cache/oracle" / lock["artifact"]["filename"]
    assert sha(jar) == lock["artifact"]["sha256"]
    OUT.mkdir()
    shutil.copyfile(ROOT / "tools/java/CollectionAdditionIdentityOracle.java",
                    OUT / "CollectionAdditionIdentityOracle.java")
    shutil.copyfile(Path(__file__), OUT / "run.py")
    for name in SOURCES:
        target = OUT / "sources" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    java = Path(os.environ.get("PKL_ORACLE_JAVA", "/usr/bin/java")).resolve()
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC",
           "TERM": "dumb", "NO_COLOR": "1", "COLUMNS": "80"}
    identity_command = [str(java), "-XshowSettings:properties", "-version"]
    preflight = subprocess.run(identity_command, cwd=OUT, env=env, capture_output=True, timeout=60)
    (OUT / "java-identity.stdout.bin").write_bytes(preflight.stdout)
    (OUT / "java-identity.stderr.bin").write_bytes(preflight.stderr)
    if preflight.returncode:
        raise RuntimeError("JDK preflight failed; raw retained")
    properties = dict(re.findall(r"^\s+([\w.]+) = (.*)$", preflight.stderr.decode(), re.M))
    assert all(properties.get(k) == v for k, v in lock["jdk"]["properties"].items())
    home = Path(properties["java.home"])
    record = {"schema": 1, "scope": "direct pinned Java Vm wrapper reference identity only",
              "candidate_compatibility_passes_claimed": 0, "host": platform.platform(),
              "environment": env, "reference_revision": lock["source"]["revision"],
              "artifact": str(jar), "artifact_sha256": sha(jar),
              "jdk": {"identity_command": identity_command, "identity_exit_code": preflight.returncode,
                      "identity_stdout_sha256": sha(OUT / "java-identity.stdout.bin"),
                      "identity_stderr_sha256": sha(OUT / "java-identity.stderr.bin"),
                      "properties": properties, "executable": str(java),
                      "executable_sha256": sha(java),
                      "modules_sha256": sha(home / "lib/modules"),
                      "release_sha256": sha(home / "release")},
              "input_before": {name: sha(OUT / name) for name in
                               ("CollectionAdditionIdentityOracle.java", "run.py")},
              "source_before": {name: sha(ROOT / name) for name in SOURCES},
              "source_copies": {name: sha(OUT / "sources" / name) for name in SOURCES},
              "sessions": []}
    save(OUT / "provenance.json", record)
    options = [*lock["jvm_options"], f"-Duser.home={env['HOME']}",
               f"-Djava.io.tmpdir={env['TMPDIR']}"]
    for repeat in range(2):
        command = [str(java), *options, "-cp", str(jar),
                   str(OUT / "CollectionAdditionIdentityOracle.java")]
        started = time.time()
        process = subprocess.run(command, cwd=OUT, env=env, capture_output=True, timeout=180)
        stdout_path = OUT / f"repeat-{repeat}.stdout.bin"
        stderr_path = OUT / f"repeat-{repeat}.stderr.bin"
        stdout_path.write_bytes(process.stdout)
        stderr_path.write_bytes(process.stderr)
        record["sessions"].append({"repeat": repeat, "command": command, "cwd": str(OUT),
            "started_epoch": started, "finished_epoch": time.time(), "exit_code": process.returncode,
            "stdout_sha256": sha(stdout_path), "stderr_sha256": sha(stderr_path)})
        save(OUT / "provenance.json", record)
        if process.returncode:
            raise RuntimeError("Java identity helper failed; raw retained")
    record["input_after"] = {name: sha(OUT / name) for name in
                             ("CollectionAdditionIdentityOracle.java", "run.py")}
    record["source_after"] = {name: sha(ROOT / name) for name in SOURCES}
    record["artifact_after_sha256"] = sha(jar)
    record["raw_equal"] = ((OUT / "repeat-0.stdout.bin").read_bytes() ==
                            (OUT / "repeat-1.stdout.bin").read_bytes() and
                            (OUT / "repeat-0.stderr.bin").read_bytes() ==
                            (OUT / "repeat-1.stderr.bin").read_bytes())
    record["stable"] = (record["input_before"] == record["input_after"]
                        and record["source_before"] == record["source_after"] == record["source_copies"]
                        and record["artifact_sha256"] == record["artifact_after_sha256"])
    lines = (OUT / "repeat-0.stdout.bin").read_text().splitlines()
    assert len(lines) == 15 and lines[-1] == "rows=14"
    assert (OUT / "repeat-0.stderr.bin").read_bytes() == b""
    expected = {
        "list-empty-both": (True, True), "list-nonempty-empty": (True, False),
        "list-empty-nonempty": (False, False), "list-nonempty-nonempty": (False, False),
        "set-empty-both": (True, True), "set-nonempty-empty": (True, False),
        "set-empty-nonempty": (False, False), "set-duplicate-only": (False, False),
        "set-new-element": (False, False), "map-empty-both": (True, True),
        "map-nonempty-empty": (True, False), "map-empty-nonempty": (False, False),
        "map-overwrite-only": (False, False), "map-new-key": (False, False),
    }
    rows = []
    for line in lines[:-1]:
        name, left, right = line.split("\t")
        observed = (left == "true", right == "true")
        assert observed == expected.pop(name)
        rows.append({"id": name, "result_is_left": observed[0], "result_is_right": observed[1]})
    assert not expected and record["raw_equal"] and record["stable"]
    record["complete"] = True
    save(OUT / "provenance.json", record)
    save(OUT / "audit.json", {"schema": 1, "boundary": "internal-Java-runtime-only",
        "rows": rows, "candidate_compatibility_passes_claimed": 0,
        "limits": ["Direct pinned Java Vm reference equality; not public evaluateExpressionString output.",
                   "No Rust, Node, browser, typed export, full M2 or performance pass inferred."]})
    print(json.dumps({"rows": len(rows), "raw_equal": True, "stable": True}))


if __name__ == "__main__":
    main()
