"""Offline raw integrity and authored-status audit of two target-only Java captures."""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CAPTURES = [HERE.parent / "stage63-collection-addition-exploration-01" / "capture-01",
            HERE / "capture-01"]
EXPECTED = [(86, 62, 24), (111, 80, 31)]
ERROR_INDEXES = set(range(72, 86)) | {59, 60, 62, 63, 66, 67, 68, 69, 70, 71}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(capture, expected):
    provenance = json.loads((capture / "provenance.json").read_bytes())
    audit = json.loads((capture / "audit.json").read_bytes())
    cases = json.loads((capture / "cases.json").read_bytes())
    rows = cases["rows"]
    assert len(rows) == expected[0]
    assert provenance["complete"] and provenance["stable"] and provenance["raw_equal"]
    assert provenance["rows"] == len(rows) and audit["rows"] == len(rows)
    assert provenance["statuses"] == audit["statuses"] == {"success": expected[1], "error": expected[2]}
    assert audit["candidate_compatibility_passes_claimed"] == 0
    assert len(provenance["sessions"]) == 2
    assert len({s["pid"] for s in provenance["sessions"]}) == 2
    assert provenance["reference_revision"] == "e51fb2f91774265666f94980ec630db794a4db2d"
    assert sha(Path(provenance["artifact"])) == provenance["artifact_sha256"] == provenance["artifact_after_sha256"]
    assert sha(Path(provenance["jdk"]["executable"])) == provenance["jdk"]["executable_sha256"]
    assert sha(Path(provenance["jdk"]["properties"]["java.home"]) / "lib/modules") == provenance["jdk"]["modules_sha256"]
    assert (capture / "java-identity.stdout.bin").read_bytes() == b""
    assert sha(capture / "java-identity.stdout.bin") == provenance["jdk"]["identity_stdout_sha256"]
    assert sha(capture / "java-identity.stderr.bin") == provenance["jdk"]["identity_stderr_sha256"]
    properties = dict(re.findall(r"^\s+([\w.]+) = (.*)$", (capture / "java-identity.stderr.bin").read_text(), re.M))
    assert properties == provenance["jdk"]["properties"]
    for name, digest in provenance["input_before"].items():
        assert sha(capture / name) == digest == provenance["input_after"][name]
    for name, digest in provenance["source_before"].items():
        assert sha(capture / "sources" / name) == digest == provenance["source_copies"][name] == provenance["source_after"][name]
        assert sha(ROOT / name) == digest
    assert (capture / "queries.tsv").read_text() == "".join(
        f"string\t{r['id']}\t{r['expression']}\n" for r in rows)
    all_files = []
    status_counts = {"success": 0, "error": 0}
    for repeat, session in enumerate(provenance["sessions"]):
        folder = capture / f"repeat-{repeat}"
        assert session["repeat"] == repeat and session["exit_code"] == 0
        assert session["cwd"] == str(capture)
        assert session["command"][-3:] == [str(folder), str(capture), cases["module_uri"]]
        assert session["query_directories"] == len(rows)
        assert (folder / "process.stderr.bin").read_bytes() == b""
        assert sha(folder / "process.stdout.bin") == session["stdout_sha256"]
        assert sha(folder / "process.stderr.bin") == session["stderr_sha256"]
        transcript = [f"session-open mode=string rows={len(rows)}"]
        names = set()
        for i, row in enumerate(rows):
            q = folder / f"{i:03d}-{row['id']}"
            names.add(q.name)
            files = {p.name for p in q.iterdir() if p.is_file()}
            stem = ("mode", "expression", "result.stdout", "result.stderr", "result.error-class",
                    "result.exception-to-string", "result.cause-class", "result.cause-message",
                    "result.cause-to-string", "result.java-type")
            expected_files = {"result.status.bin"} | {n + ".bin" for n in stem} | {
                n + ".code-units.bin" for n in stem}
            assert files == expected_files
            assert (q / "mode.bin").read_bytes() == b"string"
            assert (q / "expression.bin").read_bytes() == row["expression"].encode()
            status = (q / "result.status.bin").read_text().strip()
            assert status in status_counts
            if repeat == 0:
                status_counts[status] += 1
            expected_error = i in ERROR_INDEXES or (len(rows) == 111 and i in range(98, 105))
            assert (status == "error") == expected_error
            assert (q / "result.error-class.bin").read_text() == (
                "org.pkl.core.PklException" if expected_error else "")
            assert (q / "result.stdout.bin").read_bytes() == b"" if expected_error else (
                (q / "result.stderr.bin").read_bytes() == b"")
            for name in stem:
                raw = (q / (name + ".bin")).read_bytes()
                text = raw.decode("utf-8")
                assert (q / (name + ".code-units.bin")).read_bytes() == text.encode("utf-16-be", "surrogatepass")
            call = f"string-{i}-{row['id']}"
            transcript.extend([f"call-enter={call}", f"call-exit={call} status={status}"])
        assert {p.name for p in folder.iterdir() if p.is_dir()} == names
        transcript.append(f"session-closed mode=string rows={len(rows)} public-calls={len(rows)} success={expected[1]} errors={expected[2]}")
        assert (folder / "process.stdout.bin").read_bytes() == ("\n".join(transcript) + "\n").encode()
        files = {str(p.relative_to(folder)): sha(p) for p in folder.rglob("*") if p.is_file()}
        assert len(files) == len(rows) * 21 + 2 == provenance["raw_files_per_session"]
        all_files.append(files)
    assert all_files[0] == all_files[1]
    assert status_counts == provenance["statuses"]
    for i, row in enumerate(audit["observations"]):
        q = capture / "repeat-0" / f"{i:03d}-{row['id']}"
        assert row["expression"] == rows[i]["expression"]
        assert row["status"] == (q / "result.status.bin").read_text().strip()
        assert row["stdout_sha256"] == sha(q / "result.stdout.bin")
        assert row["stderr_sha256"] == sha(q / "result.stderr.bin")
        assert row["stdout"] == (q / "result.stdout.bin").read_text()
    return {"capture": str(capture), "rows": len(rows), "statuses": status_counts,
            "module_uri": cases["module_uri"], "module_sha256": sha(capture / "module.pkl"),
            "queries_sha256": sha(capture / "queries.tsv"), "cases_sha256": sha(capture / "cases.json"),
            "audit_sha256": sha(capture / "audit.json"), "provenance_sha256": sha(capture / "provenance.json"),
            "jar_sha256": provenance["artifact_sha256"], "jdk_executable_sha256": provenance["jdk"]["executable_sha256"],
            "source_copies": len(provenance["source_copies"]), "session_pids": [s["pid"] for s in provenance["sessions"]],
            "raw_files_per_session": len(all_files[0]), "raw_equal": True, "whole_protocol_exact": True,
            "input_source_jar_stable": True, "candidate_compatibility_passes_claimed": 0}


if __name__ == "__main__":
    report = {"schema": 1, "review_script_sha256": sha(Path(__file__)),
              "captures": [verify(p, e) for p, e in zip(CAPTURES, EXPECTED)],
              "limitations": ["Target-only authored Java exploration; no candidate compatibility claim.",
                              "Public string result does not reveal Vm wrapper reference identity."]}
    (HERE / "review.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps(report["captures"], sort_keys=True))
