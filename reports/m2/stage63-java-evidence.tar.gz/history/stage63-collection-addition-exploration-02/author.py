"""Target-only authored Stage63 collection-addition Java exploration inputs."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
URI = "file:///stage63/collection-addition-exploration-02.pkl"
rows = []


def add(group, id, expression):
    assert "\t" not in expression and "\n" not in expression
    rows.append({"mode": "string", "group": group, "id": id, "expression": expression})


for id, expression in [
    ("ll-ordered", "List(1, 2) + List(3, 4)"),
    ("ls-ordered", "List(1, 2) + Set(2, 3)"),
    ("ls-repeat", "List(1, 1) + Set(1, 2)"),
    ("ll-empty-both", "List() + List()"),
    ("ll-empty-right", "List(1, 2) + List()"),
    ("ll-empty-left", "List() + List(1, 2)"),
    ("ls-empty-right", "List(1, 2) + Set()"),
    ("ls-empty-left", "List() + Set(1, 2)"),
    ("ll-chain", "List(1) + List(2) + List(3)"),
    ("ls-chain", "List(1) + Set(2, 1) + List(3)"),
    ("ls-result-class", "(List(1) + Set(2)).getClass()"),
    ("ls-result-first", "(List(1) + Set(2)).first"),
    ("ls-result-last", "(List(1) + Set(2)).last"),
    ("ls-equal-list", "List(1, 2) + Set(3) == List(1, 2, 3)"),
    ("ls-equal-set", "List(1, 2) + Set(3) == Set(1, 2, 3)"),
]: add("list", id, expression)

for id, expression in [
    ("ss-ordered", "Set(1, 2) + Set(2, 3)"),
    ("sl-ordered", "Set(1, 2) + List(2, 3)"),
    ("sl-repeat", "Set(1) + List(2, 1, 2, 3, 1)"),
    ("ss-empty-both", "Set() + Set()"),
    ("ss-empty-right", "Set(1, 2) + Set()"),
    ("ss-empty-left", "Set() + Set(1, 2)"),
    ("sl-empty-right", "Set(1, 2) + List()"),
    ("sl-empty-left", "Set() + List(1, 2)"),
    ("ss-chain", "Set(1, 2) + Set(3) + Set(1, 4)"),
    ("sl-chain", "Set(1) + List(2, 1) + Set(3, 2)"),
    ("sl-result-class", "(Set(1) + List(2)).getClass()"),
    ("sl-result-first", "(Set(1) + List(2)).first"),
    ("sl-result-last", "(Set(1) + List(2)).last"),
    ("sl-equal-set", "Set(1, 2) + List(3) == Set(3, 2, 1)"),
    ("sl-equal-list", "Set(1, 2) + List(3) == List(1, 2, 3)"),
]: add("set", id, expression)

for id, expression in [
    ("mm-ordered", 'Map("a", 1, "b", 2) + Map("c", 3, "d", 4)'),
    ("mm-overwrite-first", 'Map("a", 1, "b", 2) + Map("a", 9, "c", 3)'),
    ("mm-overwrite-last", 'Map("a", 1, "b", 2) + Map("c", 3, "b", 9)'),
    ("mm-overwrite-both", 'Map("a", 1, "b", 2) + Map("b", 9, "a", 8)'),
    ("mm-empty-both", "Map() + Map()"),
    ("mm-empty-right", 'Map("a", 1) + Map()'),
    ("mm-empty-left", 'Map() + Map("a", 1)'),
    ("mm-chain", 'Map("a", 1) + Map("b", 2, "a", 3) + Map("b", 4, "c", 5)'),
    ("mm-result-class", '(Map("a", 1) + Map("b", 2)).getClass()'),
    ("mm-equal-reordered", 'Map("a", 1, "b", 2) + Map("c", 3) == Map("c", 3, "b", 2, "a", 1)'),
    ("mm-overwrite-lookup", '(Map("a", 1) + Map("a", 9))["a"]'),
    ("mm-overwrite-length", '(Map("a", 1) + Map("a", 9)).length'),
]: add("map", id, expression)

for id, expression in [
    ("set-int-float", "Set(1) + Set(1.0)"),
    ("set-int-float-reversed", "Set(1.0) + Set(1)"),
    ("set-float-signed-zeros", "Set(0.0) + Set(-0.0)"),
    ("set-nan", "Set(0.0 / 0.0) + Set(0.0 / 0.0)"),
    ("set-string-hash-collision", 'Set("Aa") + Set("BB")'),
    ("set-string-hash-collision-duplicate", 'Set("Aa", "BB") + Set("Aa")'),
    ("set-nested-list", "Set(List(1)) + Set(List(1), List(2))"),
    ("set-nested-object", 'Set(new Dynamic { value = 1 }) + Set(new Dynamic { value = 1 })'),
    ("map-int-float", 'Map(1, "int") + Map(1.0, "float")'),
    ("map-int-float-reversed", 'Map(1.0, "float") + Map(1, "int")'),
    ("map-float-signed-zeros", 'Map(0.0, "pos") + Map(-0.0, "neg")'),
    ("map-nan-overwrite", 'Map(0.0 / 0.0, 1) + Map(0.0 / 0.0, 2)'),
    ("map-string-hash-collision", 'Map("Aa", 1) + Map("BB", 2)'),
    ("map-string-hash-collision-duplicate", 'Map("Aa", 1, "BB", 2) + Map("Aa", 3)'),
    ("map-nested-list-key", 'Map(List(1), "old") + Map(List(1), "new")'),
    ("map-nested-object-key", 'Map(new Dynamic { value = 1 }, "old") + Map(new Dynamic { value = 1 }, "new")'),
]: add("hash", id, expression)

for id, expression in [
    ("list-lazy-length", '(List(new Dynamic { value = throw("lazy-left") }) + List(new Dynamic { value = throw("lazy-right") })).length'),
    ("list-lazy-first-read", '(List(new Dynamic { value = throw("lazy-left") }) + List(new Dynamic { value = throw("lazy-right") }))[0].value'),
    ("list-lazy-second-read", '(List(new Dynamic { value = throw("lazy-left") }) + List(new Dynamic { value = throw("lazy-right") }))[1].value'),
    ("map-lazy-length", '(Map("a", new Dynamic { value = throw("lazy-left") }) + Map("b", new Dynamic { value = throw("lazy-right") })).length'),
    ("map-lazy-first-read", '(Map("a", new Dynamic { value = throw("lazy-left") }) + Map("b", new Dynamic { value = throw("lazy-right") }))["a"].value'),
    ("map-lazy-second-read", '(Map("a", new Dynamic { value = throw("lazy-left") }) + Map("b", new Dynamic { value = throw("lazy-right") }))["b"].value'),
    ("map-lazy-overwrite-length", '(Map("a", new Dynamic { value = throw("discarded") }) + Map("a", new Dynamic { value = 2 })).length'),
    ("map-lazy-overwrite-read", '(Map("a", new Dynamic { value = throw("discarded") }) + Map("a", new Dynamic { value = 2 }))["a"].value'),
    ("set-hash-left-first", 'Set(new Dynamic { value = throw("hash-left") }) + Set(new Dynamic { value = throw("hash-right") })'),
    ("set-hash-right-only", 'Set(1) + Set(new Dynamic { value = throw("hash-right") })'),
    ("map-key-left-first", 'Map(new Dynamic { value = throw("key-left") }, 1) + Map(new Dynamic { value = throw("key-right") }, 2)'),
    ("map-key-right-only", 'Map(1, 1) + Map(new Dynamic { value = throw("key-right") }, 2)'),
    ("strict-left-before-right", 'throw("left") + throw("right")'),
    ("strict-right-after-left", 'List(1) + throw("right")'),
]: add("force", id, expression)

for id, expression in [
    ("bad-list-map", "List(1) + Map(1, 2)"),
    ("bad-map-list", "Map(1, 2) + List(1)"),
    ("bad-set-map", "Set(1) + Map(1, 2)"),
    ("bad-map-set", "Map(1, 2) + Set(1)"),
    ("bad-list-int", "List(1) + 1"),
    ("bad-int-list", "1 + List(1)"),
    ("bad-set-null", "Set(1) + null"),
    ("bad-null-map", "null + Map(1, 2)"),
    ("bad-dynamic-dynamic", "new Dynamic {} + new Dynamic {}"),
    ("bad-listing-listing", "new Listing { 1 } + new Listing { 2 }"),
    ("bad-mapping-mapping", 'new Mapping { ["a"] = 1 } + new Mapping { ["b"] = 2 }'),
    ("bad-list-subtract", "List(1) - List(2)"),
    ("bad-map-subtract", "Map(1, 2) - Map(3, 4)"),
    ("bad-set-subtract", "Set(1) - Set(2)"),
]: add("error", id, expression)

for id, expression in [
    ("map-duration-representative-left", 'Map(1.min, "old") + Map(60.s, "new")'),
    ("map-duration-representative-right", 'Map(60.s, "old") + Map(1.min, "new")'),
    ("map-duration-left-unit", '(Map(1.min, "old") + Map(60.s, "new")).keys.toList()[0].unit'),
    ("map-duration-right-unit", '(Map(60.s, "old") + Map(1.min, "new")).keys.toList()[0].unit'),
    ("map-duration-overwrite-order", 'Map(1.min, "old", 2.s, "second") + Map(60.s, "new", 3.s, "third")'),
    ("set-duration-representative-left", "Set(1.min) + Set(60.s)"),
    ("set-duration-representative-right", "Set(60.s) + Set(1.min)"),
    ("set-duration-left-unit", "(Set(1.min) + Set(60.s)).first.unit"),
    ("set-duration-right-unit", "(Set(60.s) + Set(1.min)).first.unit"),
    ("map-same-object-key", 'let (key = new Dynamic { value = 1 }) Map(key, "old") + Map(key, "new")'),
    ("set-same-object-element", 'let (key = new Dynamic { value = 1 }) Set(key) + Set(key)'),
    ("map-warmed-key-cache", 'let (key = new Dynamic { value = 1 }) (Map(key, "old") + Map(key, "new"))[key]'),
    ("bad-list-function", "List(1) + ((x) -> x)"),
    ("bad-function-list", "((x) -> x) + List(1)"),
    ("bad-map-class", "Map(1, 2) + List"),
    ("bad-class-map", "List + Map(1, 2)"),
    ("bad-set-function", "Set(1) + ((x) -> x)"),
    ("bad-map-int", "Map(1, 2) + 1"),
    ("bad-set-int", "Set(1) + 1"),
]: add("additional", id, expression)

def integer_map(length):
    return "Map(" + ", ".join(f"{i}, {i}" for i in range(length)) + ")"

def integer_set(length):
    return "Set(" + ", ".join(str(i) for i in range(length)) + ")"

for id, expression in [
    ("map-slot-sixteen", f"{integer_map(15)} + Map(15, 15)"),
    ("map-slot-seventeen", f"{integer_map(16)} + Map(16, 16)"),
    ("map-slot-seventeen-overwrite", f"{integer_map(16)} + Map(0, 99, 16, 16)"),
    ("set-slot-sixteen", f"{integer_set(15)} + Set(15)"),
    ("set-slot-seventeen", f"{integer_set(16)} + Set(16)"),
    ("set-slot-seventeen-duplicate", f"{integer_set(16)} + List(0, 16, 0)"),
]: add("threshold", id, expression)

(ROOT / "module.pkl").write_text('tag = "stage63-collection-addition-exploration"\n')
(ROOT / "queries.tsv").write_text("".join(f"{r['mode']}\t{r['id']}\t{r['expression']}\n" for r in rows))
(ROOT / "cases.json").write_text(json.dumps({"schema": 1, "baseline": "Pkl 0.32.0", "module_uri": URI,
    "boundary": "string", "repetitions": 2, "rows": rows}, indent=2, sort_keys=True) + "\n")
print(len(rows))
