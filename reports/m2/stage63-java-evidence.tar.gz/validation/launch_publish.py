"""Capture the actual Stage63 Java A publication process and bind its result."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
VALIDATION = Path(__file__).resolve().parent
OUT = ROOT / "target/m2/stage63-java-publication-execution-01"
PUB = ROOT / "target/m2/stage63-java-publication-01"
CHECKPOINT = ROOT / "reports/m2/stage63-java-checkpoint.json"
ARCHIVE = ROOT / "reports/m2/stage63-java-evidence.tar.gz"
EXPECTED_HEAD = "c8fa86dac5cf908ab16533229845206e4ff9c56d"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity(path):
    path = Path(path)
    return {"bytes": path.stat().st_size, "sha256": sha(path)}


def head():
    return subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                          capture_output=True, check=True).stdout.decode().strip()


def save(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def main():
    if OUT.exists() or PUB.exists() or CHECKPOINT.exists() or ARCHIVE.exists():
        raise ValueError("fresh publication execution required")
    if head() != EXPECTED_HEAD:
        raise ValueError("baseline HEAD differs")
    validation = json.loads((VALIDATION / "validation.json").read_bytes())
    if validation["complete"] is not True:
        raise ValueError("Java A validation incomplete")
    observed = [VALIDATION / "publish.py", VALIDATION / "launch_publish.py",
                VALIDATION / "validation.json",
                ROOT / "tests/fixtures/m2-collection-addition/oracle-evidence.tar.gz",
                ROOT / "target/m2/stage63-collection-addition-oracle-04/provenance.json",
                ROOT / "target/m2/stage63-collection-addition-identity-01/capture-02/provenance.json"]
    before = {str(p.relative_to(ROOT)): identity(p) for p in observed}
    OUT.mkdir(parents=True, exist_ok=False)
    env = validation["environment"]
    argv = [validation["python"]["executable"], str(VALIDATION / "publish.py")]
    started = time.time()
    process = subprocess.Popen(argv, cwd=ROOT, env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        stdout, stderr = process.communicate(timeout=600)
    except subprocess.TimeoutExpired:
        process.kill()
        stdout, stderr = process.communicate()
        (OUT / "stdout.bin").write_bytes(stdout)
        (OUT / "stderr.bin").write_bytes(stderr)
        raise RuntimeError("publication timed out; raw retained")
    (OUT / "stdout.bin").write_bytes(stdout)
    (OUT / "stderr.bin").write_bytes(stderr)
    after = {str(p.relative_to(ROOT)): identity(p) for p in observed}
    report = {"schema": 1, "kind": "stage63-java-a-publication-execution",
              "argv": argv, "cwd": str(ROOT), "environment": env, "pid": process.pid,
              "started_epoch": started, "finished_epoch": time.time(),
              "exit_code": process.returncode,
              "stdout": identity(OUT / "stdout.bin"), "stderr": identity(OUT / "stderr.bin"),
              "input_before": before, "input_after": after,
              "source_stable": before == after, "baseline_head_before_after": head() == EXPECTED_HEAD,
              "candidate_compatibility_passes_claimed": 0}
    save(OUT / "process.json", report)
    if process.returncode or before != after or head() != EXPECTED_HEAD:
        raise RuntimeError("publication failed or changed inputs; raw retained")
    if not (PUB / "draft.json").is_file() or not ARCHIVE.is_file():
        raise RuntimeError("publication output missing; raw retained")
    draft = json.loads((PUB / "draft.json").read_bytes())
    if draft["publication"]["identity"] != identity(ARCHIVE):
        raise RuntimeError("publication archive identity differs")
    draft["publication_execution"] = {"path": (OUT / "process.json").relative_to(ROOT).as_posix(),
                                      "identity": identity(OUT / "process.json"),
                                      "argv": argv, "exit_code": process.returncode,
                                      "stdout": report["stdout"], "stderr": report["stderr"],
                                      "source_stable": True}
    save(CHECKPOINT, draft)
    save(OUT / "result.json", {"schema": 1, "checkpoint": identity(CHECKPOINT),
                               "archive": identity(ARCHIVE),
                               "original_publication_raw_captured": True,
                               "candidate_compatibility_passes_claimed": 0})
    print(json.dumps({"checkpoint": identity(CHECKPOINT), "archive": identity(ARCHIVE),
                      "execution": identity(OUT / "process.json")}, sort_keys=True))


if __name__ == "__main__":
    main()
