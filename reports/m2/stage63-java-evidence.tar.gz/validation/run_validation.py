"""Record fresh Stage63 Java authority and shared profile validation."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent
EXPECTED_HEAD = "c8fa86dac5cf908ab16533229845206e4ff9c56d"
OWN = ("run_validation.py", "verify_identity.py", "publish.py", "launch_publish.py")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def identity(path):
    path = Path(path)
    return {"bytes": path.stat().st_size, "sha256": sha(path)}


def save(value):
    (OUTPUT / "validation.json").write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")


def source_names():
    tools = {p.relative_to(ROOT).as_posix() for p in (ROOT / "tools").rglob("*")
             if p.is_file() and p.suffix in {".py", ".mjs", ".java", ".json"}
             and "__pycache__" not in p.parts and "node_modules" not in p.parts}
    fixture = {p.relative_to(ROOT).as_posix() for p in
               (ROOT / "tests/fixtures/m2-collection-addition").iterdir() if p.is_file()}
    from_root = {"compatibility/collection-conversion-profiles.json",
                 "oracle.lock.json", "references.lock"}
    from_target = {str((OUTPUT / name).relative_to(ROOT)) for name in OWN}
    sys.path.insert(0, str(ROOT / "tools"))
    from collection_addition_oracle import SOURCES
    return sorted(tools | fixture | from_root | from_target | set(SOURCES))


def run(name, argv, env):
    folder = OUTPUT / "checks" / name
    folder.mkdir(parents=True, exist_ok=False)
    started = time.time()
    process = subprocess.Popen(argv, cwd=ROOT, env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        stdout, stderr = process.communicate(timeout=300)
    except subprocess.TimeoutExpired:
        process.kill()
        stdout, stderr = process.communicate()
        (folder / "stdout.bin").write_bytes(stdout)
        (folder / "stderr.bin").write_bytes(stderr)
        raise RuntimeError(f"{name} timed out; raw retained")
    (folder / "stdout.bin").write_bytes(stdout)
    (folder / "stderr.bin").write_bytes(stderr)
    entry = {"name": name, "argv": argv, "cwd": str(ROOT), "environment": env,
             "pid": process.pid, "started_epoch": started, "finished_epoch": time.time(),
             "exit_code": process.returncode,
             "stdout": identity(folder / "stdout.bin"), "stderr": identity(folder / "stderr.bin")}
    (folder / "process.json").write_text(json.dumps(entry, sort_keys=True, indent=2) + "\n")
    print(f"{name}: exit={process.returncode}", flush=True)
    return entry


def main():
    if (OUTPUT / "validation.json").exists() or (OUTPUT / "sources").exists():
        raise ValueError("fresh Stage63 Java validation output required")
    head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                          capture_output=True, check=True).stdout.decode().strip()
    if head != EXPECTED_HEAD:
        raise ValueError("Stage63 Java A baseline HEAD differs")
    names = source_names()
    before = {name: sha(ROOT / name) for name in names}
    for name in names:
        destination = OUTPUT / "sources" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, destination)
    python = sys.executable
    node = shutil.which("node")
    if node is None:
        raise ValueError("Node executable missing")
    node = str(Path(node).resolve())
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC",
           "TERM": "dumb", "NO_COLOR": "1", "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONHASHSEED": "0"}
    report = {"schema": 1, "kind": "stage63-collection-addition-java-authority-validation",
              "scope": "Java authority, profile tooling and source inventory only; no Rust candidate pass",
              "baseline_head": head, "host": platform.uname()._asdict(),
              "python": {"executable": python, "identity": identity(python), "version": sys.version},
              "node": {"executable": node, "identity": identity(node)},
              "source_names": names, "source_before": before, "environment": env,
              "checks": [], "complete": False, "source_stable": False,
              "candidate_compatibility_passes_claimed": 0,
              "manifest_freshness_pass_claimed": False,
              "deferred_final_integration": ["M2 manifest refresh and freshness after concurrent Rust source freeze"]}
    save(report)
    checks = (
        ("fixture-verifier", [python, "tools/collection_addition_fixtures.py"]),
        ("fixture-verifier-O", [python, "-O", "tools/collection_addition_fixtures.py"]),
        ("fixture-tests", [python, "-m", "unittest", "tools.tests.test_collection_addition_fixtures", "-v"]),
        ("fixture-tests-O", [python, "-O", "-m", "unittest", "tools.tests.test_collection_addition_fixtures", "-v"]),
        ("shared-profile-tests", [python, "-m", "unittest", "tools.tests.test_collection_conversions_compare",
                                  "tools.tests.test_collection_conversions_portable_compare", "-v"]),
        ("shared-profile-tests-O", [python, "-O", "-m", "unittest", "tools.tests.test_collection_conversions_compare",
                                    "tools.tests.test_collection_conversions_portable_compare", "-v"]),
        ("platform-profile-tests", [node, "--test", "tools/platform/capture-collection-conversions.test.mjs"]),
        ("identity-supplement", [python, str(OUTPUT / "verify_identity.py")]),
        ("source-inventory", [python, "tools/inventory.py", "--check"]),
    )
    for name, argv in checks:
        report["checks"].append(run(name, argv, env))
        save(report)
    after = {name: sha(ROOT / name) for name in names}
    report["source_after"] = after
    report["source_stable"] = before == after
    report["snapshot_matches"] = before == {name: sha(OUTPUT / "sources" / name) for name in names}
    report["complete"] = (report["source_stable"] and report["snapshot_matches"]
                          and len(report["checks"]) == len(checks)
                          and all(check["exit_code"] == 0 for check in report["checks"]))
    save(report)
    if not report["complete"]:
        raise ValueError("Stage63 Java validation incomplete; raw failures retained")


if __name__ == "__main__":
    main()
