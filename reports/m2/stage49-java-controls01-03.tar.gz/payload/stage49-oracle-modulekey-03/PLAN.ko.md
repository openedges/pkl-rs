# Stage49 독립 실패 identity 관찰

원래01/교정02는 변경하지 않는다. 부모 P1→U 초기화 실패 E1를 cache한 뒤 uncached U가 별도 초기화 실패 E2를 게시한다. 이후 cached P1의 E1 재전파와 U의 E2 조회를 번갈아 실행하고 GC 요청 뒤 반복한다. 같은 URI의 서로 다른 실패 객체와 부모/자식 cache 소유권을 실제 Java로 관찰한다. 기존 helper의 SOURCE init1/init2 입력 기능을 그대로 사용하며 새 helper 기능은 없다. 예정40 API(10×2 evaluator×2 fresh JVM), 전체 진단 UTF16/JavaUTF8 및 이벤트/카운터를 보존한다.
