from pathlib import Path
import json, shutil, hashlib
O=Path(__file__).resolve().parent;P=O.parent/'stage49-oracle-modulekey-01'
assert json.loads((P/'outer-terminal.json').read_bytes())['exitCode']==0
for n in ['AdmissionProbe.java','TrustProbe.java','run.py','launch.py','trust-uris.txt']:shutil.copyfile(P/n,O/n)
name='parent-cached-e1-uncached-u-e2-independent-errors';w=O/'workspace'/name;w.mkdir(parents=True)
files={'main.pkl':'function parent() = import("memo:/parent.pkl")\nfunction uncached() = import("memo:/u.pkl")\nfunction cached() = import("memo:/u.pkl")\nstable = 7\n','parent.pkl':'import "memo:/u.pkl" as u\np: u.Absent? = null\ntag = "parent"\n','state-init1.pkl':'p: MissingOne = 1\ntag = "first"\n','state-init2.pkl':'p: MissingTwo = 1\ntag = "second"\n','module-plan.tsv':'memo:/parent.pkl\tmemo:/parent.pkl\tmemo:/resolved/parent.pkl\tparent.pkl\ttrue\tfalse\nmemo:/u.pkl\tmemo:/u.pkl\tmemo:/resolved/u.pkl\t$state\tdynamic\tfalse\n','source-profiles.tsv':''}
files['source-inputs.txt']=''.join(n+'\n' for n in files if n.endswith('.pkl'))
ops=[('evaluate','stable'),('source','init1'),('evaluate','parent().tag'),('cache','off'),('source','init2'),('evaluate','uncached().tag'),('cache','on'),('evaluate','parent().tag'),('evaluate','cached().tag'),('evaluate','parent().tag'),('evaluate','cached().tag'),('gc',''),('evaluate','parent().tag'),('evaluate','cached().tag'),('evaluate','stable')]
operations=[{'kind':k,'source':'main.pkl','expression':v} if k=='evaluate' else {'kind':k,'value':v} for k,v in ops]
files['operations.tsv']=''.join(('main.pkl\t'+v if k=='evaluate' else 'GC' if k=='gc' else k.upper()+'\t'+v)+'\n' for k,v in ops)
for n,b in files.items():(w/n).write_text(b)
c={'id':name,'workspace':str(w),'entry':'main.pkl','sourceUri':(w/'main.pkl').as_uri(),'mode':'allow','operations':operations,'inputPaths':list(files),'scope':'Actual separate Java exception identities: parent P1 and U first initialization failure E1; uncached U E2 overwrite; cached parent E1 rethrow must not overwrite cached U E2. No Rust-derived expectation.'}
(O/'cases.json').write_text(json.dumps([c],indent=2)+'\n');(O/'input-paths.json').write_text(json.dumps({name:list(files)},indent=2)+'\n')
(O/'PLAN.ko.md').write_text('# Stage49 독립 실패 identity 관찰\n\n원래01/교정02는 변경하지 않는다. 부모 P1→U 초기화 실패 E1를 cache한 뒤 uncached U가 별도 초기화 실패 E2를 게시한다. 이후 cached P1의 E1 재전파와 U의 E2 조회를 번갈아 실행하고 GC 요청 뒤 반복한다. 같은 URI의 서로 다른 실패 객체와 부모/자식 cache 소유권을 실제 Java로 관찰한다. 기존 helper의 SOURCE init1/init2 입력 기능을 그대로 사용하며 새 helper 기능은 없다. 예정40 API(10×2 evaluator×2 fresh JVM), 전체 진단 UTF16/JavaUTF8 및 이벤트/카운터를 보존한다.\n')
(O/'predecessor.json').write_text(json.dumps({'root':str(P),'helperSha256':hashlib.sha256((O/'AdmissionProbe.java').read_bytes()).hexdigest(),'helperUnchanged':True,'newScope':'Parent cached E1 vs uncached U E2 independent failures'},indent=2)+'\n')
print(json.dumps({'cases':1,'plannedApis':sum(k=='evaluate' for k,v in ops)*4}))
