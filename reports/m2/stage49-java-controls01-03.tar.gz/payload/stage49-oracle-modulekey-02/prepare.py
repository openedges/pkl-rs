from pathlib import Path
import hashlib, json, shutil
O=Path(__file__).resolve().parent
P=O.parent/'stage49-oracle-modulekey-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((P/'outer-terminal.json').read_bytes())['exitCode']==0
assert sha(P/'report.json')=='0127e3236b629abbc11eb90f8b6e9226e6eb390ed954593d4b7972519a135e9f'
for name in ['AdmissionProbe.java','TrustProbe.java','run.py','launch.py','trust-uris.txt']:
    shutil.copyfile(P/name,O/name)
cases=[]
for original in json.loads((P/'cases.json').read_bytes()):
    if not original['id'].startswith('inference-') and original['id']!='custom-ref-qualified-types':
        continue
    c=dict(original);work=O/'workspace'/c['id'];work.mkdir(parents=True)
    for rel in c['inputPaths']:
        p=work/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Path(c['workspace'])/rel,p)
    source=(work/'main.pkl').read_text()
    if c['id'].startswith('inference-'):
        alias=c['operations'][1]['expression'].split('.')[0]
        source += 'function marker() = '+alias+'.Marker.toString()\nfunction tagValue() = '+alias+'.tag\n'
        exprs=['stable','marker()','tagValue()','marker()','stable']
        c['operations']=[{'kind':'evaluate','source':'main.pkl','expression':e} for e in exprs]
    else:
        source+='function refLabel() = ref.label\n'
        c['operations']=[{**op,'expression':'refLabel()' if op.get('expression')=='ref.label' else op.get('expression')} for op in c['operations']]
    (work/'main.pkl').write_text(source)
    (work/'operations.tsv').write_text(''.join(op['source']+'\t'+op['expression']+'\n' for op in c['operations']))
    c.update(workspace=str(work),sourceUri=(work/'main.pkl').as_uri(),scope=c['scope']+' Corrected query visibility via authored main module functions; original01 query-local alias errors remain preserved and are not name/load coverage.')
    cases.append(c)
for name,obj in [('cases.json',cases),('input-paths.json',{c['id']:c['inputPaths'] for c in cases}),('predecessor.json',{'root':str(P),'reportSha256':sha(P/'report.json'),'originalQueriesUnchanged':True,'correctedSources':'Only import-local query visibility changed in fresh02; helper bytes unchanged.','helperSha256':sha(O/'AdmissionProbe.java')})]:
    (O/name).write_text(json.dumps(obj,indent=2)+'\n')
(O/'PLAN.ko.md').write_text('# Stage49 교정된 import-local 조회 관찰\n\n원래01의 query-local alias 오류를 그대로 보존한다. 새02의 main 모듈 함수로 import 값을 노출하여 반환 key URI의 이름 추론과 class/module 이름, custom ref label을 실제 강제한다. helper와 JVM 설정은 동일하며 source/URI/기댓값은 별도다. 새 9개 case에서 예정188개 API를 두 fresh JVM과 각 두 evaluator로 취득한다. 기존 SPI212개와01의 다른 정상 관찰은 재실행하지 않는다.\n')
print(json.dumps({'cases':len(cases),'plannedApis':sum(len(c['operations'])for c in cases)*4,'helperSha256':sha(O/'AdmissionProbe.java')}))
