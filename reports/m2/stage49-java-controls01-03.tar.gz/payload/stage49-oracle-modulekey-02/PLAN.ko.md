# Stage49 교정된 import-local 조회 관찰

원래01의 query-local alias 오류를 그대로 보존한다. 새02의 main 모듈 함수로 import 값을 노출하여 반환 key URI의 이름 추론과 class/module 이름, custom ref label을 실제 강제한다. helper와 JVM 설정은 동일하며 source/URI/기댓값은 별도다. 새 9개 case에서 예정188개 API를 두 fresh JVM과 각 두 evaluator로 취득한다. 기존 SPI212개와01의 다른 정상 관찰은 재실행하지 않는다.
