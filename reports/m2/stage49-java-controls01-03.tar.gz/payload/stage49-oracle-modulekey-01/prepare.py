from pathlib import Path
import hashlib, json

O = Path(__file__).resolve().parent
PREV = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-module-admission-oracle-02')
def write(name, value):
    p = O / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(value)
def doc(name, value):
    write(name, json.dumps(value, indent=2) + '\n')
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
old = (PREV / 'AdmissionProbe.java').read_text()
assert sha(PREV / 'AdmissionProbe.java') == '7509222bebfbbea487ae20548671d827a68bff364a7f10e5df30bb9dcd6a6346'
new = old.replace('static boolean cacheMode=true;', 'static boolean cacheMode=true,customMode=true;static String sourceState="good";static int keyInstances,keyUriGets,fragmentGets,originalGets;')
new = new.replace('record Plan(URI original,URI resolved,String text,String cache){}', 'record Plan(URI requested,URI original,URI resolved,String source,String cache,boolean fragments){}\n static final Map<String,String> texts=new LinkedHashMap<>();\n static final Map<String,ModuleSource> supplied=new LinkedHashMap<>();')
new = new.replace('\\nevent="+events', '\\nkeyGetUri="+keyUriGets+"\\nfragmentPaths="+fragmentGets+"\\nresolvedGetOriginal="+originalGets+"\\nevent="+events')
new = new.replace('policyMode.equals("deny-json")?List.of(Pattern.compile("(?!pkl:json$).*")):all', 'policyMode.equals("deny-json")?List.of(Pattern.compile("(?!pkl:json$).*")):policyMode.equals("deny-repl")?List.of(Pattern.compile("(?!repl:.*).*")):policyMode.equals("deny-supplied")?List.of(Pattern.compile("(?!memo:/supplied.pkl$).*")):all')
start = new.index(' static final class PlannedKey')
end = new.index(' static void capture(', start)
new = new[:start] + ''' static final class PlannedKey implements ModuleKey {
  final Plan plan;final boolean cached;final int id;
  PlannedKey(Plan plan){this.plan=plan;this.cached=plan.cache.equals("dynamic")?cacheMode:plan.cache.equals("true");this.id=keyInstances++;event("key-created id="+id+" requested="+plan.requested+" selected="+plan.original+" cached-snapshot="+cached);}
  public URI getUri(){keyUriGets++;event("key-get-uri id="+id+" "+plan.original);return plan.original;}
  public boolean hasFragmentPaths(){fragmentGets++;event("key-fragment-paths id="+id+" "+plan.fragments);return plan.fragments;}
  public boolean hasHierarchicalUris(){event("key-hierarchical id="+id+" true");return true;}
  public boolean isGlobbable(){return false;}
  public boolean isLocal(){return true;}
  public boolean isCached(){cacheQueries++;event("key-is-cached id="+id+" "+plan.original+" "+cached);return cached;}
  public ResolvedModuleKey resolve(org.pkl.core.SecurityManager security)throws SecurityManagerException{
   keyResolves++;event("key-resolve id="+id+" "+plan.original);security.checkResolveModule(plan.original);event("key-resolved id="+id+" "+plan.original+" -> "+plan.resolved);
   return new ResolvedModuleKey(){
    public ModuleKey getOriginal(){originalGets++;event("resolved-get-original id="+id+" "+plan.original);return PlannedKey.this;}
    public URI getUri(){event("resolved-get-uri id="+id+" "+plan.resolved);return plan.resolved;}
    public String loadSource()throws IOException{
     int index=sourceLoads++;String source=plan.source.equals("$state")?"state-"+sourceState+".pkl":plan.source;
     event("load-source id="+id+" "+plan.original+" -> "+plan.resolved+" load="+index+" state="+sourceState);
     text("load-"+index+".original-uri.bin",plan.original.toString());text("load-"+index+".resolved-uri.bin",plan.resolved.toString());
     if(plan.source.equals("$state")&&sourceState.equals("io")){text("load-"+index+".failure.bin","stage49-source-io");throw new IOException("stage49-source-io");}
     String value=texts.get(source);if(value==null)throw new IllegalStateException("undeclared source "+source);
     text("load-"+index+".source.bin",value);units("load-"+index+".source.code-units.bin",value);return value;
    }
   };
  }
 }
''' + new[end:]
new = new.replace('static void capture(Evaluator evaluator,Path source,int index,String expression)', 'static void capture(Evaluator evaluator,String sourceId,int index,String expression)')
new = new.replace('work.relativize(source).toString()', 'sourceId')
new = new.replace('String value=evaluator.evaluateExpressionString(ModuleSource.path(source),expression);', 'ModuleSource source=supplied.get(sourceId);if(source==null)source=ModuleSource.path(work.resolve(sourceId));String value=evaluator.evaluateExpressionString(source,expression);')
oldload = 'for(String line:Files.readAllLines(work.resolve("module-plan.tsv"))){if(line.isEmpty())continue;String[]f=line.split("\\t",-1);URI original=URI.create(f[0]);plans.put(original,new Plan(original,URI.create(f[1]),Files.readString(work.resolve(f[2])),f[3]));}'
assert oldload in new
new = new.replace(oldload, '''for(String name:Files.readAllLines(work.resolve("source-inputs.txt"))){if(!name.isEmpty())texts.put(name,Files.readString(work.resolve(name)));}
  for(String line:Files.readAllLines(work.resolve("module-plan.tsv"))){if(line.isEmpty())continue;String[]f=line.split("\\t",-1);URI request=URI.create(f[0]);plans.put(request,new Plan(request,URI.create(f[1]),URI.create(f[2]),f[3],f[4],Boolean.parseBoolean(f[5])));}
  for(String line:Files.readAllLines(work.resolve("source-profiles.tsv"))){if(line.isEmpty())continue;String[]f=line.split("\\t",-1);supplied.put(f[0],f[1].equals("uri")?ModuleSource.uri(f[2]):f[1].equals("repl")?ModuleSource.text(texts.get(f[3])):ModuleSource.create(URI.create(f[2]),texts.get(f[3])));}''')
new = new.replace('policyMode=startPolicy;cacheMode=true;', 'policyMode=startPolicy;cacheMode=true;customMode=true;sourceState="good";keyInstances=keyUriGets=fragmentGets=originalGets=0;')
new = new.replace('Plan p=plans.get(uri);', 'Plan p=customMode?plans.get(uri):null;')
new = new.replace('if(operation.startsWith("CACHE\\t"))', 'if(operation.startsWith("SOURCE\\t")){sourceState=operation.substring(7);event("source-profile "+sourceState);continue;}\n     if(operation.startsWith("FACTORY\\t")){customMode=operation.substring(8).equals("custom");event("factory-profile "+customMode);continue;}\n     if(operation.startsWith("CACHE\\t"))')
new = new.replace('capture(evaluator,work.resolve(fields[0]),index++,fields[1]);', 'capture(evaluator,fields[0],index++,fields[1]);')
assert new != old and 'plan.text' not in new
write('AdmissionProbe.java', new)
write('TrustProbe.java', (PREV / 'TrustProbe.java').read_text())

cases = []
def case(name, source, ops, plans=(), files=None, profiles=(), mode='allow', scope=''):
    w = O / 'workspace' / name
    contents = {'main.pkl': source, **(files or {})}
    contents['module-plan.tsv'] = ''.join('\t'.join(map(str,p)) + '\n' for p in plans)
    contents['source-profiles.tsv'] = ''.join('\t'.join(p) + '\n' for p in profiles)
    source_names = [p for p in contents if p.endswith('.pkl')]
    contents['source-inputs.txt'] = ''.join(p + '\n' for p in source_names)
    operations = []
    lines = []
    for item in ops:
        if isinstance(item, tuple):
            source_id, expr = item
            operations.append({'kind': 'evaluate', 'source': source_id, 'expression': expr})
            lines.append(source_id + '\t' + expr)
        elif item == 'GC':
            operations.append({'kind': 'gc'});lines.append(item)
        else:
            key, value = item.split('\t', 1)
            operations.append({'kind': key.lower(), 'value': value});lines.append(item)
    contents['operations.tsv'] = '\n'.join(lines) + '\n'
    for rel, text in contents.items():
        write(str((w / rel).relative_to(O)), text)
    cases.append({'id': name, 'workspace': str(w), 'entry': 'main.pkl', 'sourceUri': (w/'main.pkl').as_uri(), 'mode': mode, 'operations': operations, 'scope': scope, 'inputPaths': list(contents)})

def evaluate(*expressions):
    return [('main.pkl', x) for x in expressions]
for name, selected, fragments, binding in [
    ('basename', 'memo:/different/selected.pkl', 'false', 'selected'),
    ('opaque-version', 'memo:org.example.Widget:1.2', 'false', 'Widget'),
    ('fragment', 'memo:/outer.pkl#/inside/fragmentName.pkl', 'true', 'fragmentName'),
    ('jar', 'jar:file:/stage49/archive.jar!/inside/jarName.pkl', 'true', 'jarName'),
]:
    request = 'memo:/request-' + name + '.pkl'
    selected_plan = [(request, selected, 'memo:/resolved/' + name + '.pkl', 'child.pkl', 'true', fragments)]
    for explicit in [False, True]:
        alias = 'named' if explicit else binding
        case('inference-' + name + ('-explicit' if explicit else '-implicit'), 'import "' + request + '"' + (' as named' if explicit else '') + '\nstable = 7\n', evaluate('stable', alias+'.Marker.toString()', alias+'.tag', alias+'.Marker.toString()', 'stable'), selected_plan, {'child.pkl': 'class Marker {}\ntag = "selected-source"\n'}, scope='Factory request URI differs from selected key URI and resolved URI. Actual getter trace distinguishes clause inference and module name inference; no archive I/O for jar URI.')

refsource = 'open class Reference { tag = 99 }\nopen class Domain { tag = 77 }\nlabel = "custom-ref"\n'
case('custom-ref-qualified-types', 'import "pkl:ref" as ref\nx: ref.Reference? = null\ny: ref.Domain? = null\nstable = 7\n', evaluate('stable', 'x == null', 'y == null', '(new ref.Reference {}).tag', '(new ref.Domain {}).tag', 'ref.label', 'stable'), [('pkl:ref','pkl:ref','memo:/resolved/custom-ref.pkl','custom-ref.pkl','true','false')], {'custom-ref.pkl': refsource}, scope='Actual custom key pkl:ref has ordinary authored Reference/Domain classes; no builtin external specialization.')

for kind in ['ref', 'json']:
    for direction in ['custom-first', 'builtin-first']:
        expr = 'one().label' if kind == 'ref' else 'one().label'
        builtin = 'two().Reference.toString()' if kind == 'ref' else 'two().Property.toString()'
        ops = evaluate('stable')
        if direction == 'custom-first':
            ops += evaluate(expr) + ['FACTORY\tbuiltin'] + evaluate(builtin, 'import("pkl:'+kind+'").toString()') + ['FACTORY\tcustom'] + evaluate('one().label', 'three().label', 'stable')
        else:
            ops += ['FACTORY\tbuiltin'] + evaluate(builtin) + ['FACTORY\tcustom'] + evaluate(expr, 'three().label') + ['FACTORY\tbuiltin'] + evaluate(builtin, 'stable')
        case('selection-'+kind+'-'+direction, 'function one() = import("pkl:'+kind+'")\nfunction two() = import("pkl:'+kind+'")\nfunction three() = import("pkl:'+kind+'")\nstable = 7\n', ops, [('pkl:'+kind,'pkl:'+kind,'memo:/resolved/'+kind+'.pkl','custom.pkl','true','false')], {'custom.pkl': refsource if kind=='ref' else 'label = "custom-json"\n'}, scope='Switch actual custom factory presence at later import sites; singleton ref versus ordinary json URI cache. Existing successful site remains independent. Some deliberate missing-member errors are observations, not intent failures.')

for failure in ['io', 'init']:
    case('uncached-'+failure+'-then-cached', 'function old() = import("memo:/toggle.pkl")\nfunction fail() = import("memo:/toggle.pkl")\nfunction later() = import("memo:/toggle.pkl")\nfunction recovered() = import("memo:/toggle.pkl")\nstable = 7\n', evaluate('stable','old().tag') + ['CACHE\toff','SOURCE\t'+failure] + evaluate('fail().tag','old().tag') + ['CACHE\ton','SOURCE\tgood'] + evaluate('later().tag','old().tag','later().tag') + ['CACHE\toff'] + evaluate('recovered().tag') + ['CACHE\ton','GC'] + evaluate('import("memo:/toggle.pkl").tag','old().tag','stable'), [('memo:/toggle.pkl','memo:/toggle.pkl','memo:/resolved/toggle.pkl','$state','dynamic','false')], {'state-good.pkl': 'tag = "good"\n', 'state-init.pkl': 'p: Missing = 1\ntag = "init"\n'}, scope='Prior successful site retains receiver while uncached source/init failure overwrites URI caches; later cached lookup replays failure, uncached successful reload recovers. Actual Java decides eager init reach.')

supplied_files = {'one.pkl':'tag = "one"\noutput { text = "ONE" }\n', 'two.pkl':'tag = "two"\noutput { text = "TWO" }\n', 'underlying.pkl':'tag = "underlying"\noutput { text = "UNDERLYING" }\n'}
profiles = [('supplied1','contents','memo:/supplied.pkl','one.pkl'),('supplied2','contents','memo:/supplied.pkl','two.pkl'),('uri','uri','memo:/supplied.pkl',''),('repl1','repl','repl:text','one.pkl'),('repl2','repl','repl:text','two.pkl')]
case('module-source-contents-and-repl', 'stable = 7\n', [(s,e) for s,e in [('supplied1','tag'),('supplied2','tag'),('supplied2','output.text'),('uri','tag'),('repl1','tag'),('repl2','tag'),('repl1','output.text'),('repl2','output.text'),('supplied1','tag')]], [('memo:/supplied.pkl','memo:/supplied.pkl','memo:/resolved/underlying.pkl','underlying.pkl','false','true')], supplied_files, profiles, scope='Actual ModuleSource.create(uri,contents), uri-only and text(repl:text) in same evaluator; wrapper caching/delegation and direct output.text path versus synthetic query.')
case('module-source-primary-query-denial', 'stable = 7\n', ['POLICY\tdeny-supplied',('supplied1','tag'),'POLICY\tallow',('supplied1','tag'),'POLICY\tdeny-repl',('supplied1','tag'),('supplied1','output.text'),('repl1','tag'),'POLICY\tallow',('repl1','tag'),('supplied1','tag')], [('memo:/supplied.pkl','memo:/supplied.pkl','memo:/resolved/underlying.pkl','underlying.pkl','true','false')], supplied_files, profiles, scope='Primary supplied-wrapper resolve denial versus synthetic query/repl denial, retry and direct output.text fast path. Exact actual policy order preserved.')
doc('cases.json', cases)
doc('input-paths.json', {c['id']:c['inputPaths'] for c in cases})
write('trust-uris.txt', '')
run = (PREV / 'run.py').read_text()
run = run.replace("R=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48')", "R=Path('/Users/cody.ij.hwang/Projects/pkl-rs')")
run = run.replace("'worktreeHeadDeclaredByRoot':'0e13a589d43c4cb1d83f41dd1ec416cac1770fc1'", "'worktreeHeadDeclaredByRoot':'5e68c4b (root declaration; no B Git command)'")
run = run.replace("'pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ImportNode.java'", "'pkl-core/src/main/java/org/pkl/core/ModuleSource.java','pkl-core/src/main/java/org/pkl/core/util/IoUtils.java','pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ImportNode.java'")
run = run.replace('FreshpinnedoriginalJavaAPI module-admission controls only', 'Fresh pinned original Java API Stage49 key URI, cache failure and supplied-source controls only')
run = run.replace('OriginalpublicEvaluator.evaluateExpressionString+actualStandardSecurityManager;preconfigured/cache=null/colorfalse/emptyenvprops/powertrue.', 'Original public Evaluator.evaluateExpressionString with path, uri, create(uri,contents), text(repl:text), and actual StandardSecurityManager; preconfigured/cache=null/colorfalse/emptyenvprops/powertrue.')
write('run.py', run)
doc('predecessor.json', {'sourceRoot': str(PREV), 'helperSha256': sha(PREV/'AdmissionProbe.java'), 'runnerSha256':sha(PREV/'run.py'), 'newHelperSha256':sha(O/'AdmissionProbe.java'), 'newRunnerSha256':sha(O/'run.py'), 'profileChanges':['selected key URI distinct from requested URI','observable getter calls and selected key instance ids','source state and custom factory presence operations','ModuleSource URI+contents/text profiles','additional standard policy modes'], 'newAcquisitionOnly':True})
print(json.dumps({'root':str(O),'cases':len(cases),'plannedEvaluatorApiCalls':sum(sum(op['kind']=='evaluate' for op in c['operations']) for c in cases)*4,'helperSha256':sha(O/'AdmissionProbe.java')}))
