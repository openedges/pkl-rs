# Stage49 새 ModuleKey 경계 Java 관찰

기존 212개 SPI 관찰은 재실행하지 않는다. 새 17개 source case를 두 fresh JVM repeat와 각 두 evaluator로 취득한다(예정 444 API). 반환 key URI/별도 resolved URI, implicit/explicit alias와 이름 추론 getter 호출, custom ref 일반 타입과 builtin/custom 전환, uncached source/init 실패 뒤 URI cache/이전 성공 site, 실제 ModuleSource URI+contents 및 repl:text 순서를 다룬다.

표준 preconfigured Evaluator와 실제 StandardSecurityManager를 사용한다. custom factory는 사전 선언한 source를 외부에서 읽어 둔 뒤 key만 만든다. getter 로그는 실제 메서드 호출에서만 생성한다. 모든 status/오류 UTF16BE 및 Java UTF8, 순서 이벤트와 카운터를 보존한다. 공통 모듈 캐시 결과/이름/오류는 helper가 구현하지 않는다. jar URI는 custom key의 이름 추론/보안 URI이며 jar/network I/O는 없다.

Java 기본 계측은 power assertions enabled 한 설정이다. GC는 System.gc 요청일 뿐 실제 수거 완료 증거가 아니다. 새 API 결과는 source-derived 기대와 구분한다. 초기 취득 실패나 의도 미도달은 원문을 보존하고 별도 후속 root로만 교정한다. 원래 Stage48/47 자료·생산·Git·reference checkout에는 쓰지 않는다.
