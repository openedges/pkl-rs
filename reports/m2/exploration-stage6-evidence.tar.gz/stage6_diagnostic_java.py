from pathlib import Path
import sys, json, concurrent.futures
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out = Path('target/m2/stage6-diagnostic-java-01').resolve()
out.mkdir(exist_ok=False)
metadata = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts'; artifacts.mkdir(); classes=artifacts/'java'; classes.mkdir()
lang.capture([str(Path(metadata['java']).with_name('javac')), '-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment'])
cases=[]
def add(id, source, power=False):
    cases.append(dict(id=id,source=source+'\n',family='member-predicate-diagnostics',expected_outcome='observation',expression='result',power_assertions=power))
add('predicate-owner-cache', 'base = new Dynamic { marker = 1; ["k"] = marker }\nchild = (base) { marker = 2 }\nscanned = (child) { [[false]] = 0 }\nresult = let (ignored = scanned["k"]) base["k"]')
add('predicate-owner-cache-before', 'base = new Dynamic { marker = 1; ["k"] = marker }\nchild = (base) { marker = 2 }\nscanned = (child) { [[false]] = 0 }\nresult = let (ignored = base["k"]) scanned["k"]')
add('predicate-owner-cache-two-children', 'base = new Dynamic { marker = 1; ["k"] = marker }\na = (base) { marker = 2 }\nb = (base) { marker = 3 }\nsa = (a) { [[false]] = 0 }\nsb = (b) { [[false]] = 0 }\nresult = let (ignored = sa["k"]) sb["k"]')
add('predicate-unselected-body-lazy','base = new Listing { 1; 2 }\nvalues = (base) { [[false]] = throw("body") }\nresult = values[0]')
add('predicate-selected-body-lazy','base = new Listing { 1; 2 }\nvalues = (base) { [[true]] = throw("body") }\nresult = values.length')
add('predicate-selected-body-error','base = new Listing { 1; 2 }\nvalues = (base) { [[true]] = throw("body") }\nresult = values[0]')
add('predicate-nested-this-restore','base = new Listing { 1; 2 }\nvalues = (base) { [[let (nested = (new Listing { 9 }) { [[this == 9]] = 0 }) nested[0] == 0 && this == 2]] = 42 }\nresult = values[0] + values[1]')
add('predicate-nested-this-restore-let','base = new Listing { 1; 2 }\nvalues = (base) { [[let (original = this) let (nested = (new Listing { 9 }) { [[this == 9]] = 0 }) nested[0] == 0 && this == original && original == 2]] = 42 }\nresult = values[0] + values[1]')
add('predicate-replacement-environment','marker = 42\nbase = new Listing { new { marker = 1 } }\nvalues = (base) { [[marker == 1]] = marker }\nresult = values[0]')
add('predicate-wrapper-raw-selection','raw = new Listing { "bad" }\ntyped: Listing<Int> = raw\nvalues = (typed) { [[this is String]] = 42 }\nresult = values[0]')
add('predicate-parent-before-body','base = new Listing { 1; throw("tail") }\nvalues = (base) { [[true]] = throw("body") }\nresult = values[0]')
add('predicate-error-before-tail','base = new Listing { 1; throw("tail") }\nvalues = (base) { [[throw("predicate")]] = 0 }\nresult = values[0]')
for power in [False,True]:
 suffix='-power' if power else '-plain'
 add('predicate-cached-result'+suffix,'base = new Listing { 1; 2 }\nvalues = (base) { [[this > 1]] = 42 }\nresult: Int(values[1] == 3) = 0',power)
 add('predicate-type-test'+suffix,'base = new Listing { 1; -2 }\nvalues = (base) { [[this is Int(this > 0)]] = 42 }\nresult: Int(values[0] == 3) = 0',power)
(out/'matrix.json').write_bytes(contract.encoded(cases))
(out/'source-identities.json').write_bytes(contract.encoded({str(p):oracle.sha256(contract.ROOT/p) for p in ['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']}))
def run(case):
    folder=out/'cases'/case['id']; folder.mkdir(parents=True)
    source=folder/'input.pkl'; source.write_text(case['source'])
    row=lang.capture_java(metadata, artifacts/'language_probe',case['id'],source,case['expression'],folder,case.get('power_assertions',False))
    stdout=(folder/'java.stdout.bin').read_bytes(); stderr=(folder/'java.stderr.bin').read_bytes()
    return dict(id=case['id'],family=case['family'],expected_outcome=case['expected_outcome'],java=row,stdout=stdout.decode(),stderr=stderr.decode(),outcome=(folder/'java.outcome.bin').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
for row in results:
    print(row['id'], row['java']['exit_code'], repr(row['stdout']), repr(row['stderr'][:150]),flush=True)
