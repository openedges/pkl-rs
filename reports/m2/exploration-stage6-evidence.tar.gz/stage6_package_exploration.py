from pathlib import Path
import sys,json,shutil,hashlib
from collections import Counter
sys.path.insert(0,'tools');import evidence,m2_manifest as contract,oracle
base=Path('target/m2');out=base/sys.argv[1];assert not out.exists()
names=sorted(p.name for p in base.glob('stage6-*') if p.is_dir() and 'exploration-package' not in p.name)
files=sorted(p for p in base.glob('stage6*') if p.is_file() and (p.suffix in {'.py','.json','.rs'}))
out.mkdir()
for name in names:shutil.copytree(base/name,out/name)
for path in files:shutil.copyfile(path,out/path.name)
promotion=json.loads((base/'stage6-member-predicate-promotion.json').read_bytes())
baseline=json.loads((base/'stage6-selection-baseline-01/cases.json').read_bytes())
selected=json.loads((contract.ROOT/contract.SELECTION).read_bytes())
assert selected['cases'][:560]==baseline['cases']
identities=json.loads((base/'stage6-selection-baseline-01/identities.json').read_bytes())
assert all(oracle.sha256(contract.ROOT/row['input'])==identities[row['id']]['input_sha256'] for row in baseline['cases'])
index=dict(schema_version=1,baseline='Pkl 0.32.0; pinned oracle/JDK/artifact/environment metadata retained in every Java acquisition oracle.json',scope='Stage 6 member-predicate exploratory Java acquisitions, raw provisional Rust replays, actual fixture URI Java baselines, platform Java captures, and immutable original selection identities. Failed, invalid, corrected, unexpected upstream error, and adapter-limited observations remain in this package. This archive is separate from the final full selected build-bound report and release gates.',selection=dict(original_count=560,added_count=promotion['selected_count'],selected_count=len(selected['cases']),definitions_and_bytes_of_original_560_preserved=True),directories=names,scripts=[p.name for p in files],held=promotion['held'],superseded=promotion['superseded'],provisional_replays={str(p.parent.name):dict(Counter(row['status'] for row in json.loads(p.read_bytes()))) for p in sorted(out.glob('stage6*replay*/results.json'))},provenance_limits=['All exploratory Java input URIs, commands, error bytes, outcome sidecars, source hashes and original runtime metadata are preserved. Selected cases have separate fresh Java captures at actual checked-in fixture URIs. No path normalization is applied.','Provisional replays freeze their candidate binaries and retain their SHA-256, captures, and source identities. These builds were produced during concurrent implementation work and are explicitly unbound to a final recorded source tree. They are not the final compatibility report.','Four accidental self-referential amendment inputs in stage6-member-predicates-java-01 produce uncaught JVM NoClassDefFoundError during stack overflow handling and empty outcome sidecars; corrected super.x amendments were captured separately in stage6-member-predicates-java-02.','The frontend condition-captured-function input produces an unexpected upstream NullPointerException, preserved as an unselected mismatch. It is not a passing language case.','The main matrix Dynamic hidden object modifier and malformed nested-generator input retain their initial raw Java errors; the corrected supported sources were separately captured and selected. Hidden module modifier support and unrelated external-class/module/Listing diagnostic gaps remain unselected observations.','The original selected development failures and unmapped/unimplemented whole-language requirements remain unchanged. No new development exceptions are introduced.'])
selected_replay=json.loads((base/'stage6-selected-replay-01/results.json').read_bytes())
assert len(selected_replay)==promotion['selected_count'] and all(row['status']=='pass' for row in selected_replay)
index['exploration_accounting']=dict(language_captures=127,curated_inputs=121,promoted=113,held=8,superseded_inputs_preserved=6,platform_java_captures=6)
index['final_promoted_comparison']=dict(selected_additions=promotion['selected_count'],actual_fixture_uri_java_cases=promotion['selected_count'],raw_matches=len(selected_replay),java='stage6-selected-java-01',replay='stage6-selected-replay-01',scope='All new selected fixtures match this provisional frozen artifact at actual fixture URIs. Root separately acquires final full selection, recorded build binding, and strict/development gates.')
(out/'INDEX.json').write_bytes(contract.encoded(index))
archive=Path('reports/m2/exploration-stage6-evidence.tar.gz');assert not archive.exists()
evidence.create(out,archive,[])
print('Archive sha256',hashlib.sha256(archive.read_bytes()).hexdigest())
