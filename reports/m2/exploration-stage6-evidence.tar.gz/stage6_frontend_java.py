from pathlib import Path
import sys
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle

out = Path(sys.argv[1]).resolve()
out.mkdir(exist_ok=False)
meta = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(meta))
art = out/'artifacts'; (art/'java').mkdir(parents=True)
row = lang.capture([str(Path(meta['java']).with_name('javac')), '-encoding', 'UTF-8', '-cp', meta['artifact'], '-d', str(art/'java'), str(contract.ROOT/'tools/java/M2LanguageProbe.java')], out, 'javac', meta['environment'])
assert row['exit_code'] == 0
cases = []
def add(id, source):
    cases.append(dict(id=id, source=source+'\n', expression='result'))
add('typed-parent-precedes-condition', 'class C { x = 1 }\np = new C {}\nq = (p) { [[throw("condition")]] = throw("replacement") }\nresult = q.x')
add('inferred-parent-rejected', 'p = new Listing { new { x = 1 } }\nq = (p) { [[true]] = new {} }\nresult = q[0].x')
add('inferred-parent-let-rejected', 'p = new Listing { new { x = 1 } }\nq = (p) { [[true]] = let (x = 1) new {} }\nresult = q[0].x')
add('const-eager-lexical', 'x = 1\nconst p = new Listing { 1 }\nconst q = (p) { [[x == 1]] = 2 }\nresult = q[0]')
add('const-eager-explicit-outer', 'x = 1\nconst p = new Listing { 1 }\nconst q = (p) { [[outer.x == 1]] = 2 }\nresult = q[0]')
add('const-eager-lambda-lexical', 'x = 1\nconst p = new Listing { 1 }\nconst q = (p) { [[(() -> x == 1).apply()]] = 2 }\nresult = q[0]')
add('replacement-this-target', 'p = new Listing { 1 }\nq = (p) { local label = 7; [[true]] = this.label }\nresult = q[0]')
add('replacement-closure-this-target', 'p = new Listing { 1 }\nq = (p) { local label = 7; [[true]] = () -> this.label }\nresult = q[0].apply()')
add('condition-outer-skips-holder', 'threshold = 2\nholder = new { threshold = 1; p = new Listing { 1; 2 }; q = (p) { [[this == outer.threshold]] = 9 } }\nresult = holder.q[0] * 10 + holder.q[1]')
add('condition-lambda-outer-holder', 'threshold = 2\nholder = new { threshold = 1; p = new Listing { 1; 2 }; q = (p) { [[(() -> this == outer.threshold).apply()]] = 9 } }\nresult = holder.q[0] * 10 + holder.q[1]')
add('condition-captured-function', 'function check(p) = (p) { for (i in List(1)) { [[let (copy = this) (() -> copy == i).apply()]] = i + 8 } }\nresult = check(new Listing { 1 })[0]')
add('nested-custom-restoration', 'p = new Listing { 1; 2 }\nq = (p) { [[let (copy = this) (p) { [[this == 1]] = 7 }[0] == 7 && this == copy && this == 2]] = 9 }\nresult = q[0] * 10 + q[1]')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths = ['references.lock', 'oracle.lock.json', 'tools/java/M2LanguageProbe.java', 'tools/m2_language.py', 'crates/pkl-runtime/src/parser.rs', 'crates/pkl-runtime/src/resolver.rs', 'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/builder/AstBuilder.java', 'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/generator/GeneratorPredicateMemberNode.java']
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
    dest = out/'sources'/p; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((contract.ROOT/p).read_bytes())
results=[]
for case in cases:
    directory=out/'cases'/case['id'];directory.mkdir(parents=True)
    source=directory/'input.pkl';source.write_text(case['source'])
    java=lang.capture_java(meta,art/'language_probe',case['id'],source,case['expression'],directory)
    result=dict(id=case['id'],java=java,input_sha256=oracle.sha256(source),stdout=(directory/'java.stdout.bin').read_bytes().decode(),stderr=(directory/'java.stderr.bin').read_bytes().decode(),outcome=(directory/'java.outcome.bin').read_bytes().decode())
    results.append(result)
    print(case['id'],java['exit_code'],repr(result['stdout']),repr(result['stderr'][:250]),flush=True)
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
