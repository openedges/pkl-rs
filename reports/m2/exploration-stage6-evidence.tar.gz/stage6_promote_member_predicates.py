from pathlib import Path
import sys,json
sys.path.insert(0,'tools');import m2_manifest as contract,oracle
baseline=Path('target/m2/stage6-selection-baseline-01')
selection=contract.ROOT/contract.SELECTION
original=json.loads((baseline/'cases.json').read_bytes())
current=json.loads(selection.read_bytes())
assert current['cases'][:560]==original['cases']
assert len(original['cases'])==560
identities=json.loads((baseline/'identities.json').read_bytes())
for row in original['cases']:
 assert identities[row['id']]['definition']==row
 assert oracle.sha256(contract.ROOT/row['input'])==identities[row['id']]['input_sha256']
held={
 'unsupported-null':'Null amendment evaluates to a compound Dynamic value; full compound-value stringification is outside the scalar API-string adapter.',
 'outer-object-scope':'Missing-property-on-module diagnostic predates member predicates; corrected lexical scope probe has a defined outer module property.',
 'hidden-parent-properties-omitted':'Hidden module modifiers are outside the bounded member-predicate implementation.',
 'const-eager-explicit-outer':'Top-level outer-scope diagnostic is an existing unselected gap.',
 'replacement-this-target':'Listing missing-property diagnostic is an existing unselected gap; selected replacement environment tests cover successful bindings.',
 'replacement-closure-this-target':'Listing missing-property diagnostic is an existing unselected gap; selected replacement environment tests cover successful bindings.',
 'condition-captured-function':'Pinned Java reports an unexpected NullPointerException; retained with complete raw error bytes, not treated as language success.',
 'predicate-replacement-environment':'Compound-value stringification is outside the scalar API-string adapter; refined scalar lexical probes replace it.',
}
directories=['stage6-member-predicates-java-01','stage6-member-predicates-java-02','stage6-member-predicates-java-03','stage6-frontend-java-01','stage6-diagnostic-java-01','stage6-diagnostic-java-02']
curated={};superseded=[];deferred=[]
for dirname in directories:
 directory=Path('target/m2')/dirname
 for case in json.loads((directory/'matrix.json').read_bytes()):
  if case['id'] in curated:
   superseded.append(dict(id=case['id'],exploration=curated[case['id']][1],reason='Corrected exploratory input retained unchanged; later fresh Java capture supplies the selected source.'))
  curated[case['id']]=(case,dirname)
additional=[]
for case,dirname in curated.values():
 directory=Path('target/m2')/dirname
 if case['id'] in held:
  deferred.append(dict(id=case['id'],exploration=dirname,reason=held[case['id']]))
  continue
 identifier='member-predicate-'+case['id'];file=Path('tests/fixtures/m2')/(identifier+'.pkl')
 requirements=['semantic:objects','semantic:generators','semantic:collections','semantic:lazy-evaluation']
 family=case.get('family','')
 if family in {'scope','generator','inheritance'} or any(part in case['id'] for part in ['lexical','outer','this','capture','cache','environment']):requirements.append('semantic:name-resolution')
 if family in {'amendment','inheritance'} or 'amendment' in case['id']:requirements.append('semantic:amendment')
 if family=='types' or 'type-test' in case['id']:requirements.extend(['semantic:types','semantic:generics'])
 if family=='modifiers' or 'const' in case['id']:requirements.append('semantic:modifiers')
 if case.get('power_assertions'):requirements.append('semantic:constraints')
 process=json.loads((directory/'cases'/case['id']/'java.process.json').read_bytes())
 outcome=(directory/'cases'/case['id']/'java.outcome.bin').read_bytes()
 expected='success' if process['exit_code']==0 else 'failure'
 assert not process['timed_out']
 assert outcome==b'success\n' if expected=='success' else outcome.startswith(b'pkl-exception\t')
 if expected=='failure':requirements.append('semantic:diagnostics')
 row=dict(id=identifier,input=str(file),expression=case['expression'],requirements=requirements,expected_outcome=expected)
 if case.get('power_assertions'):row['power_assertions']=True
 additional.append((row,case['source'].encode(),dirname,case['id']))
for family,domain in [('select','Selected Int entry replacement equals explicit index replacement for two fixed bounded Int values.'),('none','False predicate leaves the same two fixed Int entries as an empty amendment.'),('for','Captured for-generator predicates equal two explicit index replacements for fixed Int values 1 and 2.')]:
 ids=['member-predicate-listing-'+family,'member-predicate-listing-'+family+'-direct']
 relation=dict(kind='equal-stdout',case_ids=ids,domain=domain)
 for row,_,_,_ in additional:
  if row['id'] in ids:
   row['metamorphic_relation']=relation;row['requirements'].append('semantic:generated-verification')
out=Path(sys.argv[1]);assert not out.exists()
if '--write' in sys.argv:
 assert len(current['cases'])==560
 for row,source,_,_ in additional:
  path=contract.ROOT/row['input'];assert not path.exists();path.write_bytes(source)
 current['cases'].extend(row for row,_,_,_ in additional)
 selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
out.write_bytes(contract.encoded(dict(selected_count=len(additional),held=deferred,superseded=superseded,provenance=[dict(id=row['id'],exploration='target/m2/'+dirname,exploratory_case_id=identifier,input_sha256=contract.digest(source)) for row,source,dirname,identifier in additional])))
print('Promoted' if '--write' in sys.argv else 'Proposed',len(additional),'held',len(deferred),'superseded',len(superseded))
