from pathlib import Path
import sys, concurrent.futures, json
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
r=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert r['exit_code']==0
cases=[
 dict(id='listing-select-direct',source='p = new Listing { 1; 2 }\nq = (p) { [1] = 9 }\nresult = q[0] * 10 + q[1]\n',family='metamorphic',expression='result'),
 dict(id='listing-none-direct',source='p = new Listing { 1; 2 }\nq = (p) { }\nresult = q[0] * 10 + q[1]\n',family='metamorphic',expression='result'),
 dict(id='listing-for-direct',source='p = new Listing { 1; 2 }\nq = (p) { [0] = 8; [1] = 9 }\nresult = q[0] * 10 + q[1]\n',family='metamorphic',expression='result'),
]
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 q=out/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 folder=out/'cases'/c['id'];folder.mkdir(parents=True);source=folder/'input.pkl';source.write_bytes(c['source'].encode())
 row=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],folder,c.get('power_assertions',False))
 return dict(id=c['id'],family=c['family'],java=row,input_sha256=oracle.sha256(source),stdout=(folder/'java.stdout.bin').read_bytes().decode(),stderr=(folder/'java.stderr.bin').read_bytes().decode(),outcome=(folder/'java.outcome.bin').read_bytes().decode())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
for r in results:print(r['id'],r['java']['exit_code'],repr(r['stdout']),repr(r['stderr'][:150]),flush=True)
