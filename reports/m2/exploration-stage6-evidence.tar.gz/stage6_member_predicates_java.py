from pathlib import Path
import sys, concurrent.futures
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle

out = Path(sys.argv[1]).resolve()
out.mkdir(exist_ok=False)
meta = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(meta))
art = out/'artifacts'; (art/'java').mkdir(parents=True)
compiled = lang.capture([str(Path(meta['java']).with_name('javac')), '-encoding', 'UTF-8', '-cp', meta['artifact'], '-d', str(art/'java'), str(contract.ROOT/'tools/java/M2LanguageProbe.java')], out, 'javac', meta['environment'])
assert compiled['exit_code'] == 0
cases=[]
def add(id, source, family='selection', power=False):
    cases.append(dict(id=id, source=source+'\n', family=family, expression='result', power_assertions=power))
for kind, constructor, body, first, second, append in [
    ('listing', 'Listing', '1; 2', '0', '1', '3'),
    ('mapping', 'Mapping', '["a"] = 1; ["b"] = 2', '"a"', '"b"', '["c"] = 3'),
    ('dynamic-elements', 'Dynamic', '1; 2', '0', '1', '3'),
    ('dynamic-entries', 'Dynamic', '["a"] = 1; ["b"] = 2', '"a"', '"b"', '["c"] = 3')]:
    base=f'p = new {constructor} {{ {body} }}\n'
    read=f'result = q[{first}] * 10 + q[{second}]'
    for name, predicate, replacement in [('select', 'this == 2', '9'), ('all', 'true', '9'), ('none', 'false', 'missing')]:
        add(kind+'-'+name, base+f'q = (p) {{ [[{predicate}]] = {replacement} }}\n'+read)
    objbody=body.replace('1', 'new { x = 1 }').replace('2', 'new { x = 2 }')
    add(kind+'-amendment', f'p = new {constructor} {{ {objbody} }}\nq = (p) {{ [[x == 2]] {{ x = x + 7 }} }}\nresult = q[{second}].x', 'amendment')
    add(kind+'-same-block-excluded',base+f'q = (p) {{ {append}; [[this == 3]] = 9 }}\nresult = q['+('2' if 'elements' in kind or kind=='listing' else '"c"')+']','inheritance')
    add(kind+'-later-inherited',base+f'q = (p) {{ {append} }}\nr = (q) {{ [[this == 3]] = 9 }}\nresult = r['+('2' if 'elements' in kind or kind=='listing' else '"c"')+']','inheritance')
    add(kind+'-lambda-this',base+'q = (p) { [[(() -> this == 2).apply()]] = 9 }\n'+read,'scope')
    add(kind+'-let-this',base+'q = (p) { [[let (value = this) value == 2]] = 9 }\n'+read,'scope')
    add(kind+'-lexical', 'threshold = 2\n'+base+'q = (p) { [[this == threshold]] = threshold + 7 }\n'+read,'scope')
    add(kind+'-for',base+'q = (p) { for (selected in List(1, 2)) { [[this == selected]] = selected + 7 } }\n'+read,'generator')
    add(kind+'-when',base+'q = (p) { when (false) { [[missing]] = missing }; when (true) { [[this == 2]] = 9 } }\n'+read,'generator')
    add(kind+'-duplicate-predicates',base+'q = (p) { [[true]] = 9; [[this == 2]] = 8 }\n'+read,'duplicate')
    add(kind+'-duplicate-direct-first',base+f'q = (p) {{ [{second}] = 9; [[this == 2]] = 8 }}\n'+read,'duplicate')
    add(kind+'-duplicate-direct-last',base+f'q = (p) {{ [[this == 2]] = 8; [{second}] = 9 }}\n'+read,'duplicate')
    add(kind+'-non-bool',base+'q = (p) { [[this]] = 9 }\n'+read,'diagnostic')

add('listing-forces-parent-on-false','p = new Listing { missing }\nq = (p) { [[false]] = 9 }\nresult = q.length','forcing')
add('mapping-forces-parent-on-false','p = new Mapping { ["a"] = missing }\nq = (p) { [[false]] = 9 }\nresult = q.length','forcing')
add('predicate-before-later-parent-error','p = new Listing { 1; missing }\nq = (p) { [[1 ~/ 0 == this]] = 9 }\nresult = q.length','forcing')
add('parent-before-predicate-error','p = new Listing { missing; 1 }\nq = (p) { [[1 ~/ 0 == this]] = 9 }\nresult = q.length','forcing')
add('own-before-inherited-error','p = new Mapping { ["a"] = missing }\nx = (p) { ["b"] = 1 }\nq = (x) { [[1 ~/ 0 == this]] = 9 }\nresult = q.length','forcing')
add('inherited-override-dedup','p = new Mapping { ["a"] = missing; ["b"] = 2 }\nx = (p) { ["a"] = 1 }\nq = (x) { [[this == 1]] = 9 }\nresult = q["a"] * 10 + q["b"]','inheritance')
add('dynamic-properties-omitted','p = new Dynamic { x = missing; local y = missing; hidden z = missing; 1 }\nq = (p) { [[true]] = 9 }\nresult = q[0]','modifiers')
add('dynamic-property-name-key-dedup','p = new Dynamic { x = missing; ["x"] = 1 }\nq = (p) { [[true]] = 9 }\nresult = q["x"]','modifiers')
add('mapping-default-omitted','p = new Mapping { default = (key) -> missing; ["a"] = 1 }\nq = (p) { [[true]] = 9 }\nresult = q["a"]','modifiers')
add('listing-local-omitted','p = new Listing { local x = missing; 1 }\nq = (p) { [[true]] = 9 }\nresult = q[0]','modifiers')
for constructor in ['Listing','Mapping','Dynamic']:
    add('empty-'+constructor.lower(),f'q = new {constructor} {{ [[missing]] = missing }}\nresult = q.length' if constructor!='Dynamic' else 'q = new Dynamic { [[missing]] = missing; x = 42 }\nresult = q.x','empty')
for name, base, result in [
    ('typed-object','class C { x = 1 }\np = new C {}','q.x'),
    ('list','p = List(1, 2)','q.length'),
    ('int','p = 1','q'),
    ('null','p = null','q')]:
    add('unsupported-'+name,base+'\nq = (p) { [[true]] = 9 }\nresult = '+result,'diagnostic')
add('outer-object-scope','holder = new { threshold = 2; p = new Listing { 1; 2 }; q = (p) { [[this == outer.threshold]] = 9 } }\nresult = holder.q[1]','scope')
add('lexical-shadows-custom-property','x = 2\np = new Listing { new { x = 1 } }\nq = (p) { [[x == 2]] = 9 }\nresult = q[0]','scope')
add('nested-generators-capture','p = new Listing { 1; 2 }\nq = (p) { for (a in List(1, 2)) { for (b in List(7)) { when (a == 2) { [[this == a]] = a + b } } }\nresult = q[0] * 10 + q[1]','generator')
add('typed-listing-value','p: Listing<Int> = new Listing { 1; "bad" }\nq = (p) { [[false]] = 9 }\nresult = q.length','types')
add('typed-mapping-key','p: Mapping<String, Int> = new Mapping { [1] = missing }\nq = (p) { [[false]] = 9 }\nresult = q.length','types')
add('typed-listing-override','p: Listing<Int> = new Listing { 1 }\nq = (p) { [[true]] = "ok" }\nresult = q[0]','types')

(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/generator/GeneratorPredicateMemberNode.java','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/generator/GeneratorMemberNode.java']
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
    q=out/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
    folder=out/'cases'/c['id'];folder.mkdir(parents=True);source=folder/'input.pkl';source.write_bytes(c['source'].encode())
    row=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],folder,c['power_assertions'])
    return dict(id=c['id'],family=c['family'],java=row,input_sha256=oracle.sha256(source),stdout=(folder/'java.stdout.bin').read_bytes().decode(),stderr=(folder/'java.stderr.bin').read_bytes().decode(),outcome=(folder/'java.outcome.bin').read_bytes().decode())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
for r in results: print(r['id'],r['java']['exit_code'],repr(r['stdout']),repr(r['stderr'][:120]),flush=True)
