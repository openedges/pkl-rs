# Superseded Stage12 acquisitions

These original captures preceded the required partial-class missing-member diagnostic corrections. The language run was interrupted after the new sequential comparisons exposed the mismatch. Its complete per-case process pairs remain observations, not a complete language report. Node failed on the same full diagnostic difference. Initial workspace checks and M1 regressions are superseded by the final acquisition. See `summary.json` and the interruption receipt for exact scope.
