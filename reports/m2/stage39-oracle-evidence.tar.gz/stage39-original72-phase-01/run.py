import json,sys,subprocess,hashlib,os
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-original72-phase-01';ORIGIN=ROOT/'target/m2/stage39-original72-java-01'
sys.path.insert(0,str(ROOT/'tools'));import oracle
p=json.loads((ORIGIN/'profile.json').read_text());rows=json.loads((ORIGIN/'original72.json').read_text());work=Path(p['workspace']);env=dict(p['environment'])
for key,name in [('HOME','home'),('TMPDIR','tmp'),('TMP','tmp'),('TEMP','tmp')]:
 path=OUT/name;path.mkdir(exist_ok=True);env[key]=str(path)
java=p['java'] if 'java' in p else p['jdk']['executable'];javac=str(Path(p['jdk']['properties']['java.home'])/'bin/javac');identity=subprocess.run([javac,'-version'],capture_output=True,env=env,cwd=ROOT);(OUT/'javac-version.stdout.bin').write_bytes(identity.stdout);(OUT/'javac-version.stderr.bin').write_bytes(identity.stderr)
commands=[]
def run(command,name):
 result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=60);(OUT/(name+'.stdout.bin')).write_bytes(result.stdout);(OUT/(name+'.stderr.bin')).write_bytes(result.stderr);commands.append({'name':name,'command':command,'cwd':str(ROOT),'environment':env,'exit_code':result.returncode});assert result.returncode==0,(name,result.stderr)
run([javac,'-cp',p['artifact'],'-d',str(OUT),str(OUT/'PhaseProbe.java')],'compile')
lock=json.loads((ROOT/'oracle.lock.json').read_text());run([java,*lock['jvm_options'],f'-Duser.home={env["HOME"]}',f'-Djava.io.tmpdir={env["TMPDIR"]}','-cp',os.pathsep.join([str(OUT),p['artifact']]),'PhaseProbe',str(OUT/'cases'),*[str(work/r['input']) for r in rows]],'probe')
records=[]
for i,row in enumerate(rows):
 case=OUT/'cases'/f'{i:02d}';outcome=(case/'outcome.txt').read_text();stack=(case/'stack.bin').read_bytes() if (case/'stack.bin').exists() else b''
 records.append({'id':row['id'],'input':row['input'],'inputSha256':oracle.sha256(work/row['input']),'moduleUri':(work/row['input']).as_uri(),'outcome':outcome,'span':list(map(int,(case/'span.txt').read_text().splitlines())) if (case/'span.txt').exists() else None,'throwSite':next((line for line in stack.decode().splitlines() if line.startswith('\tat ')),None)})
report={'kind':'supplemental actual pinned parser phase observation, not original CLI replacement or compatibility pass','caseCount':len(records),'originalCliRoot':str(ORIGIN),'originalCliProfileSha256':oracle.sha256(ORIGIN/'profile.json'),'jdk':p['jdk'],'javac':javac,'javacSha256':oracle.sha256(javac),'artifactSha256':oracle.sha256(Path(p['artifact'])),'commands':commands,'sourceSha256':oracle.sha256(OUT/'PhaseProbe.java'),'classSha256':oracle.sha256(OUT/'PhaseProbe.class'),'records':records}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'cases':len(records),'outcomes':{o:sum(r['outcome']==o for r in records) for o in {r['outcome'] for r in records}}}))
