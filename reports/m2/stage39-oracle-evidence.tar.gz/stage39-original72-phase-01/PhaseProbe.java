import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import org.pkl.parser.Parser;
import org.pkl.parser.ParserError;
public final class PhaseProbe {
  static void units(Path path, String text) throws Exception {
    try (var out=new DataOutputStream(Files.newOutputStream(path))) {
      for(int i=0;i<text.length();i++) out.writeChar(text.charAt(i));
    }
  }
  public static void main(String[] args) throws Exception {
    Path output=Path.of(args[0]);
    for(int i=1;i<args.length;i++) {
      Path source=Path.of(args[i]); Path destination=output.resolve(String.format("%02d",i-1));
      Files.createDirectories(destination);
      Files.writeString(destination.resolve("source-uri.txt"),source.toUri().toString(),StandardCharsets.UTF_8);
      try {
        new Parser().parseModule(Files.readString(source,StandardCharsets.UTF_8));
        Files.writeString(destination.resolve("outcome.txt"),"parsed",StandardCharsets.UTF_8);
      } catch(ParserError error) {
        Files.writeString(destination.resolve("outcome.txt"),error.getClass().getName(),StandardCharsets.UTF_8);
        Files.writeString(destination.resolve("message.bin"),error.getMessage(),StandardCharsets.UTF_8);
        units(destination.resolve("message.code-units.bin"),error.getMessage());
        Files.writeString(destination.resolve("span.txt"),error.span().charIndex()+"\n"+error.span().length()+"\n",StandardCharsets.UTF_8);
        var bytes=new ByteArrayOutputStream();
        try(var stream=new PrintStream(bytes,true,StandardCharsets.UTF_8)){error.printStackTrace(stream);}
        Files.write(destination.resolve("stack.bin"),bytes.toByteArray());
      }
    }
  }
}
