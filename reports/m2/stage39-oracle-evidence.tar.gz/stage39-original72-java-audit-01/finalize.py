import json,hashlib,sys,collections
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-original72-java-audit-01';JAVA=ROOT/'target/m2/stage39-original72-java-01';PHASE=ROOT/'target/m2/stage39-original72-phase-01'
sys.path.insert(0,str(ROOT/'tools'));import compat,oracle

def sha(p):return oracle.sha256(p)
def load(p):return json.loads(p.read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def inventory(root):
 return [{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(root.rglob('*')) if p.is_file() and p.name not in ['inventory.json','closure.json']]
if (JAVA/'closure.json').exists():raise RuntimeError('Already closed')
report=load(JAVA/'report.json');rows=load(JAVA/'original72.json');profile=load(JAVA/'profile.json');baseline=load(JAVA/'workspace-baseline.json');phases=load(PHASE/'report.json');corpus=load(ROOT/'compatibility/corpus.json');current={r['id']:r for r in corpus['cases']}
assert report['processCount']==144 and report['caseCount']==72 and not report['repeatDifferences']
assert report['artifactStable'] and report['helperSourcesStable'] and report['workspaceRestored']
verified=[]
for i,row in enumerate(rows):
 assert row['upstream_case']==current[row['id']]
 assert sha(ROOT/row['input'])==row['input_sha256']==sha(JAVA/'inputs'/row['input'])
 phase=phases['records'][i];assert phase['id']==row['id'] and phase['inputSha256']==row['input_sha256']
 directory=compat.case_directory(row['id'])
 for repeat in [0,1]:
  path=JAVA/'cases'/directory/str(repeat);process=load(path/'process.json');result=compat.load_capture(path)
  assert process in report['records'] and process['result']==load(path/'result.json')
  assert process['sourceSha256']==row['input_sha256']
  assert process['moduleUri']==(Path(profile['workspace'])/row['input']).as_uri()==phase['moduleUri']
  assert process['cwd']==str(Path(profile['workspace'])/row['upstream_case']['cwd']) or process['cwd']==str(Path(profile['workspace'])) and row['upstream_case']['cwd']=='.'
  state=Path(profile['workspace'])/'.state'/directory;home=state/'home';tmp=state/'tmp'
  prefix=[f'-Duser.home={home}' if arg.startswith('-Duser.home=') else f'-Djava.io.tmpdir={tmp}' if arg.startswith('-Djava.io.tmpdir=') else arg for arg in profile['command']]
  assert process['command']==prefix+row['upstream_case']['command']
  env={**profile['environment'],**row['upstream_case']['environment'],'HOME':str(home),'TMPDIR':str(tmp),'TMP':str(tmp),'TEMP':str(tmp)}
  assert process['fullAllowlistedEnvironment']==env
  assert process['workspaceBeforeSha256']==compat.digest(compat.encoded(baseline))
  after=dict(baseline)
  for name,change in result['workspace_changes'].items():
   assert change['before']==baseline.get(name)
   if change['after'] is None:after.pop(name,None)
   else:after[name]=change['after']
  assert process['workspaceAfterSha256']==compat.digest(compat.encoded(after))
  private=compat.output_files(path/'private-state');assert {n:compat.digest(b) for n,b in private.items()}=={n:x['sha256'] for n,x in process['privateStateFiles'].items()}
  assert not result['timed_out'] and result['exit_code']==1 and result['stderr'].startswith('–– Pkl Error ––\n'.encode())
  assert not result['stdout'] and not result['files'] and not result['workspace_changes']
  assert (PHASE/'cases'/f'{i:02d}'/'message.bin').read_bytes() in result['stderr']
  frames=[line for line in result['stderr'].splitlines() if line.startswith(b'at ')]
  assert len(frames)==1 and process['moduleUri'].encode()+b', line ' in frames[0]
  assert result['stderr'].endswith(b'\n')
  verified.append({'id':row['id'],'repeat':repeat,'stderrSha256':process['result']['sha256']['stderr'],'phase':phase['throwSite'],'privateFiles':process['privateStateFiles'],'frame':frames[0].decode()})
link={'reportPath':str(PHASE/'report.json'),'reportSha256':sha(PHASE/'report.json'),'closurePath':str(PHASE/'closure.json'),'closureSha256':sha(PHASE/'closure.json'),'inventoryPath':str(PHASE/'inventory.json'),'inventorySha256':sha(PHASE/'inventory.json'),'scope':'Supplemental actual Parser phase, not replacement of original CLI or raw compatibility channels.'};write(JAVA/'phase-link.json',link)
write(JAVA/'terminal.json',{'firstSession':90486,'firstExitCode':0,'remainingSession':17610,'remainingExitCode':0,'processCount':144,'noFurtherWrites':True,'helperSha256':sha(JAVA/'acquire.py')})
inv=inventory(JAVA);write(JAVA/'inventory.json',{'files':inv});write(JAVA/'closure.json',{'status':'closed','files':len(inv),'reportSha256':sha(JAVA/'report.json'),'inventorySha256':sha(JAVA/'inventory.json'),'scope':'Fresh original72 pinned CLI eval processes twice, all ordinary language errors, raw full channels; no Rust execution/compatibility claim.'})
audit={'status':'pass','cases':72,'processes':144,'counts':report['counts'],'rawRepeatDifferences':report['repeatDifferences'],'originalContractsPreserved':True,'wholeStdoutStderrExitFilesVerified':True,'unknownPublicWrites':0,'privateStateFilesRetained':sum(len(x['privateFiles']) for x in verified),'defaultCliFrameObservation':'Every error has one file frame with the actual physical staged URI plus , line N; no REPL frame.','phaseScope':'All72 actual ParserError; raw ParserError messages present unchanged in complete CLI diagnostics. Supplemental phase independently11 Lexer/61 ParserImpl.','javaReportSha256':sha(JAVA/'report.json'),'javaClosureSha256':sha(JAVA/'closure.json'),'phaseReportSha256':sha(PHASE/'report.json'),'verified':verified};write(OUT/'report.json',audit)
inv=inventory(OUT);write(OUT/'inventory.json',{'files':inv});write(OUT/'closure.json',{'status':'closed','files':len(inv),'reportSha256':sha(OUT/'report.json'),'inventorySha256':sha(OUT/'inventory.json')})
print(json.dumps({'javaReportSha256':sha(JAVA/'report.json'),'javaClosureSha256':sha(JAVA/'closure.json'),'auditReportSha256':sha(OUT/'report.json'),'auditClosureSha256':sha(OUT/'closure.json'),'files':len(inv)}))
