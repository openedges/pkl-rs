"""Seal closed original Java observations and bind inputs to pinned Git blobs."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = '200b42200f05b46378eb630be94ecc576e6c6bc6'
PIN = 'e51fb2f91774265666f94980ec630db794a4db2d'
REPORT = ROOT / 'reports/m2/stage39-oracle-captures.json'
ARCHIVE = ROOT / 'reports/m2/stage39-oracle-evidence.tar.gz'
ORIGINS = [
    ROOT / 'target/m2/stage39-original72-java-01',
    ROOT / 'target/m2/stage39-original72-phase-01',
    ROOT / 'target/m2/stage39-original72-java-audit-01',
    ROOT.parent / 'pkl-rs.stage38/target/m2/stage38-frontend-phase-preflight-01',
]

def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert not REPORT.exists() and not ARCHIVE.exists(), 'refuse to overwrite evidence'
gitlink = subprocess.check_output(['git', 'ls-tree', BASE, 'external/pkl'], cwd=ROOT)
assert gitlink == f'160000 commit {PIN}\texternal/pkl\n'.encode()
submodule_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / 'external/pkl').decode().strip()
assert submodule_head == PIN
java_root = ORIGINS[0]
original = json.loads((java_root / 'original72.json').read_bytes())
paths = [row['input'].removeprefix('external/pkl/') for row in original]
tree = subprocess.check_output(['git', 'ls-tree', '-rz', PIN, '--', *paths], cwd=ROOT / 'external/pkl')
blobs = {}
for record in tree.split(b'\0'):
    if not record:
        continue
    attributes, path = record.split(b'\t', 1)
    mode, kind, identifier = attributes.decode().split()
    assert kind == 'blob'
    blobs[path.decode()] = dict(mode=mode, git_blob=identifier)
bindings = []
assert len(original) == len(blobs) == 72
for row, path in zip(original, paths):
    captured = (java_root / 'inputs' / row['input']).read_bytes()
    assert captured == (ROOT / row['input']).read_bytes()
    assert sha(captured) == row['input_sha256']
    blob = hashlib.sha1(b'blob ' + str(len(captured)).encode() + b'\0' + captured).hexdigest()
    assert blob == blobs[path]['git_blob']
    bindings.append(dict(id=row['id'], path=row['input'], input_sha256=sha(captured),
                         bytes=len(captured), **blobs[path]))
binding = dict(parent_commit=BASE, gitlink_path='external/pkl', gitlink_revision=PIN,
               scope='All 72 original CLI input snapshots match exact blobs in the pinned submodule tree.',
               cases=bindings)
(OUT / 'input-source-binding.json').write_bytes(encoded(binding))
(OUT / 'gitlink.stdout.bin').write_bytes(gitlink)
(OUT / 'input-tree.stdout.bin').write_bytes(tree)

payloads = {}
entries = []
roots = []
for origin in ORIGINS:
    assert origin.is_dir()
    files = sorted(path for path in origin.rglob('*') if not path.is_dir())
    roots.append(dict(path=str(origin), archive_prefix=origin.name, files=len(files)))
    for path in files:
        assert path.is_file() and not path.is_symlink(), str(path)
        name = origin.name + '/' + path.relative_to(origin).as_posix()
        assert name not in payloads
        data = path.read_bytes()
        payloads[name] = data
        entries.append(dict(path=name, origin=str(path), bytes=len(data), sha256=sha(data)))
for name in ['seal.py', 'input-source-binding.json', 'gitlink.stdout.bin', 'input-tree.stdout.bin']:
    path = OUT / name
    data = path.read_bytes()
    member = OUT.name + '/' + name
    payloads[member] = data
    entries.append(dict(path=member, origin=str(path), bytes=len(data), sha256=sha(data)))
inventory = encoded(dict(schema=1, scope='Immutable original Java observations; no candidate compatibility claim.',
                         roots=roots, files=entries, excluded=[]))
payloads['inventory.json'] = inventory
ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
with tarfile.open(ARCHIVE, 'w:gz') as archive:
    for name, data in payloads.items():
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    assert archive.getnames() == list(payloads)
    for member in archive:
        assert member.isfile()
        assert archive.extractfile(member).read() == payloads[member.name]
for entry in entries:
    assert sha(Path(entry['origin']).read_bytes()) == entry['sha256'], entry['origin']
report = dict(schema=1, scope='Closed Stage39 original Java CLI and parser phase evidence, prior frontend phase audit, and independent pinned-input Git binding. Not a Rust compatibility result.',
              archive=ARCHIVE.relative_to(ROOT).as_posix(), archive_bytes=ARCHIVE.stat().st_size,
              archive_sha256=sha(ARCHIVE.read_bytes()), inventory_sha256=sha(inventory),
              original_files=len(entries), archive_members=len(payloads),
              uncompressed_bytes=sum(len(data) for data in payloads.values()), roots=roots,
              input_source_binding=dict(path='stage39-oracle-seal-01/input-source-binding.json',
                                        sha256=sha(encoded(binding)), cases=len(bindings),
                                        parent_commit=BASE, submodule_revision=PIN),
              exact_membership_verified=True, every_payload_byte_verified=True,
              original_stability_verified=True, no_exclusions=True,
              java_cli_cases=72, java_cli_processes=144,
              parser_phase_cases=72, candidate_executions=0,
              compatibility_complete=False)
REPORT.write_bytes(encoded(report))
(OUT / 'report.json').write_bytes(encoded(report))
print(json.dumps(report, sort_keys=True))
