from pathlib import Path
import collections
import datetime
import hashlib
import json
import re

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage38')
MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
OUT = ROOT / 'target/m2/stage38-frontend-phase-preflight-01'
OLD = ROOT / 'target/m2/stage38-upstream-error-adapter-design-01'
FREEZE = ROOT / 'target/m2/stage38-core-order-validation-02/freeze.json'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
# Explicit roots only. No target/cache/source-tree traversal.
frontend = ['crates/pkl-runtime/src/parser.rs', 'crates/pkl-runtime/src/resolver.rs']
frontend += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'crates/pkl-runtime/src/parser').glob('*.rs'))]
frontend += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'crates/pkl-runtime/src/resolver').glob('*.rs'))]
other = [
 'crates/pkl-runtime/src/diagnostic.rs', 'crates/pkl-runtime/src/evaluation.rs',
 'crates/pkl-runtime/src/evaluation/session.rs', 'crates/pkl-runtime/src/probe.rs',
 'crates/pkl-runtime/tests/frontend.rs', 'crates/pkl-runtime/src/source.rs',
 'external/pkl/pkl-parser/src/main/java/org/pkl/parser/ParserImpl.java',
 'external/pkl/pkl-parser/src/main/java/org/pkl/parser/Lexer.java',
 'external/pkl/pkl-parser/src/main/resources/org/pkl/parser/errorMessages.properties',
 'external/pkl/pkl-core/src/main/java/org/pkl/core/ast/builder/AstBuilder.java',
 'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmLanguage.java',
 'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmUtils.java',
 'external/pkl/pkl-core/src/main/resources/org/pkl/core/errorMessages.properties',
 'AGENTS.md', 'INTENT.md', 'PLAN.md', 'TESTING.md', 'docs/architecture.md', 'references.lock',
]
paths = sorted(set(frontend + other))
before = {p: sha(ROOT/p) for p in paths}
write('sources-before.json', before)

# These are source-based design classifications, NOT results from executing inputs.
classifications = {
 ('parser.rs',250): ('Lexer','split_lexical_rules','Original invalidCharacter ^ is ordinary rejection; other ASCII paths need pinned lexical-rule classification. Do not label unsupported merely from old kind.'),
 ('parser.rs',569): ('Parser','language_rejected','Reserved keyword in identifier position is ordinary parse rejection; current message still needs raw comparison.'),
 ('parser.rs',679): ('Parser','unsupported_capability','Unmatched UTF-16 surrogate module parent URI transport is explicitly unimplemented.'),
 ('parser.rs',742): ('Parser','unsupported_capability','Glob module import declaration is valid upstream syntax; capability remains missing.'),
 ('parser.rs',753): ('Parser','unsupported_capability','Unmatched UTF-16 surrogate import URI transport is explicitly unimplemented.'),
 ('parser.rs',1054): ('Parser','limit_exceeded','Recursive expression-scope limit 32 is a Rust resource bound, not a Java syntax error.'),
 ('parser.rs',1068): ('Parser','limit_exceeded','Shared expression-scope limit 32 is a Rust resource bound.'),
 ('parser.rs',1081): ('Parser','limit_exceeded','Expression work limit 65536 is a Rust resource bound.'),
 ('parser.rs',1486): ('Parser','split_amendment_forms','Original bare bar amendment is ordinary rejection. Upstream also allows NewExpr/AmendsExpr, so do not bulk retag the source-prefix guard as correct syntax validation.'),
 ('parser.rs',2250): ('Parser','split_keyword_forms','Valid import expression capability and invalid expression keywords share one legacy fallback. Tag by actual token/grammar rule.'),
 ('parser.rs',2260): ('Parser','language_rejected','Standalone expression [ is not a pinned expression atom; do not conflate valid object entry/subscript syntax.'),
 ('string_lexer.rs',67): ('Lexer','limit_exceeded','Interpolation nesting limit 32 must bypass ordinary lexical recovery.'),
 ('string_lexer.rs',453): ('Lexer','legacy_kind_consumer','Unicode lookahead uses Unsupported to identify & lexical fallback; migrate to explicit lexical rule without changing error order.'),
 ('string_lexer.rs',456): ('Lexer','legacy_kind_consumer','Unicode lookahead uses Unsupported to identify ~ lexical fallback; migrate to explicit lexical rule without changing error order.'),
 ('string_lexer.rs',698): ('Lexer','unsupported_capability','Out-of-range Unicode escape has a known Java internal-error boundary; preserve explicit gap and independent oracle-error classification.'),
 ('type_parser.rs',85): ('Parser','limit_exceeded','Type nesting limit is an implementation resource bound.'),
 ('resolver.rs',975): ('Resolver','unsupported_capability','Base-method resolution in custom-this scopes remains explicitly unimplemented.'),
 ('resolver.rs',1261): ('Resolver','unsupported_capability','Derived const modifier diagnostics remain explicitly unimplemented.'),
 ('resolver.rs',1473): ('Resolver','unsupported_capability','Base-property static resolution remains explicitly unimplemented for this path.'),
 ('resolver.rs',1556): ('Resolver','unsupported_capability','Derived external modifier semantics remain explicitly unimplemented.'),
 ('resolver.rs',1562): ('Resolver','language_rejected','Explicit external in a nonstdlib module is pinned cannotDefineExternalMember validation, distinct from derived flags.'),
 ('resolver.rs',1587): ('Resolver','unsupported_capability','Derived modifier diagnostics remain explicitly unimplemented.'),
}
kind_sites = []
unsupported_sites = []
for p in frontend:
    lines = (ROOT/p).read_text().splitlines()
    for i,line in enumerate(lines, 1):
        match = re.search(r'DiagnosticKind::(\w+)',line)
        if not match:
            continue
        row = {'path':p, 'line':i, 'current_kind':match.group(1),
               'context_start_line':max(1,i-3),
               'context':'\n'.join(lines[max(0,i-4):min(len(lines),i+7)]),
               'evidence':'read-only frozen source; no execution'}
        kind_sites.append(row)
        if match.group(1) == 'Unsupported':
            origin, disposition, explanation = classifications[(Path(p).name,i)]
            unsupported_sites.append({**row,'proposed_origin':origin,
                'design_disposition':disposition,'reason':explanation})
assert len(unsupported_sites) == len(classifications)
write('kind-sites.json',kind_sites)
write('unsupported-sites.json',unsupported_sites)

boundaries = [
 {'path':'crates/pkl-runtime/src/parser.rs','line':2325,'finding':'parse_module pending integer validation runs only after syntactic module parse; origin DeferredAstValidation, operation ParseModule.'},
 {'path':'crates/pkl-runtime/src/parser/string_parser.rs','line':104,'finding':'Nested interpolation pending diagnostics transfer to enclosing parser; typed metadata must survive without reordered emission.'},
 {'path':'crates/pkl-runtime/src/resolver.rs','line':1172,'finding':'Diagnostic kind mutates to DuplicateMember; topic change must not erase operation/origin/disposition.'},
 {'path':'crates/pkl-runtime/src/resolver.rs','line':1603,'finding':'Owner replay compares entire diagnostic after removing member; new typed metadata must remain deterministic.'},
 {'path':'crates/pkl-runtime/src/evaluation.rs','line':159,'finding':'compile_program renders parse failure directly to String and loses structured kind/origin. Typed helper required before rendering.'},
 {'path':'crates/pkl-runtime/src/evaluation.rs','line':183,'finding':'Resolver failure also renders directly to String; Syntax does not establish parser origin.'},
 {'path':'crates/pkl-runtime/src/evaluation.rs','line':205,'finding':'Compiler failure is routed through expression-string runtime renderer; original eval cannot acquire a REPL boundary by reuse.'},
 {'path':'crates/pkl-runtime/src/evaluation.rs','line':105,'finding':'Property-path restriction is adapter capability failure, unrelated to original module grammar.'},
 {'path':'crates/pkl-runtime/src/evaluation.rs','line':138,'finding':'Compound-value conversion returns a formatted error String without ErrorKind; String must not be reverse-classified.'},
 {'path':'crates/pkl-runtime/src/evaluation.rs','line':221,'finding':'No Host log delivery path is a capability failure.'},
 {'path':'crates/pkl-runtime/src/evaluation.rs','line':230,'finding':'Probe instruction budget is currently ErrorKind::Unsupported; it is a separate limit, not language rejection.'},
 {'path':'crates/pkl-runtime/src/evaluation/session.rs','line':54,'finding':'SourceSession compile API inherits rendered String loss; keep public wrapper while introducing shared typed internal result.'},
 {'path':'crates/pkl-runtime/src/probe.rs','line':46,'finding':'Legacy evaluate_member stringifies parse/resolve/compile failures; not a source of typed original eval outcomes.'},
]
write('boundary-audit.json',boundaries)

rows = json.loads((OLD/'original72.json').read_text())
analyses = {r['id']:r for r in json.loads((OLD/'case-analysis.json').read_text())}
assert len(rows)==72 and len({r['id'] for r in rows})==72
(OUT/'original72.json').write_bytes((OLD/'original72.json').read_bytes())
notes = {
 'invalidCharacter.pkl':'Direct source-derived risk: ^ reaches ASCII Unsupported fallback; pinned invalid-character rule is ordinary language rejection. No current parser execution performed.',
 'amendsRequiresParens.pkl':'Direct source-derived risk: bare bar { ... } reaches amendment Unsupported guard; pinned rejection is ordinary. Guard also needs valid NewExpr/AmendsExpr boundary review.',
 'spacesBetweenDocComments.pkl':'Current // lexer branch drops ///; missing grammar may cause preparation success. Prepared must not imply eval success.',
 'wrongDocComment.pkl':'Current // lexer branch drops /// before import; typed errors cannot substitute for missing documentation-header grammar.',
 'constantStringInterpolation.pkl':'Import constant-string rule should be ordinary rejection; current expected-string fallback may have different bytes. Do not classify valid import expression gaps as this rule.',
 'typeAnnotationInAmends.pkl':'Pinned ParserImpl rejects typed property object body before AstBuilder; do not infer current Rust phase or pass without running original contract.',
}
case_rows=[]
for r in rows:
    p=ROOT/r['input']; actual=sha(p)
    assert actual==r['input_sha256']
    for resource in r['upstream_case']['resources']:
        assert sha(ROOT/resource['path'])==resource['sha256']
    case_rows.append({'id':r['id'],'input':r['input'],'input_sha256':actual,
      'group':analyses[r['id']]['group'],
      'original_contract_sha256':hashlib.sha256(json.dumps(r,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
      'execution':'unexecuted','rust_kind_observed':None,'rust_phase_observed':None,
      'assessment':notes.get(p.name,'Original full-module first-error raw contract remains required; no current Rust kind/phase/outcome inferred from legacy taxonomy.'),
      'golden_use':'upstream-normalized provenance only, not acquired raw expected'})
write('original72-preflight.json',case_rows)

freeze=json.loads(FREEZE.read_text())
freeze_checks=[]
for p,expected in freeze['sources'].items():
    a,b=sha(ROOT/p),sha(MAIN/p)
    freeze_checks.append({'path':p,'expected_sha256':expected,'worktree_sha256':a,
                          'main_sha256':b,'match':expected==a==b})
assert len(freeze_checks)==117 and all(r['match'] for r in freeze_checks)
write('frozen-runtime-binding.json',freeze_checks)
after={p:sha(ROOT/p) for p in paths}
assert before==after
write('sources-after.json',after)
report={
 'scope':'Read-only Stage39 typed frontend-phase/outcome preflight. Separate from the frozen Stage38 final archive selection.',
 'started_utc':started,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'builds':0,'java_runs':0,'rust_evaluations':0,'executed_original_cases':0,'tracked_edits':0,
 'original_cases':72,'groups':dict(collections.Counter(r['group'] for r in case_rows)),
 'original_identity_and_resource_hashes_verified':True,
 'frontend_kind_reference_count':len(kind_sites),
 'frontend_kind_reference_counts':dict(collections.Counter(r['current_kind'] for r in kind_sites)),
 'unsupported_reference_count':len(unsupported_sites),
 'unsupported_design_dispositions':dict(collections.Counter(r['design_disposition'] for r in unsupported_sites)),
 'classification_basis':'Source-based proposed migration at explicit sites; not executions or compatibility results.',
 'source_count':len(paths),'source_stability':True,
 'stage38_corrected_freeze_sha256':sha(FREEZE),
 'runtime_sources_matching_worktree_main_and_freeze':len(freeze_checks),
 'prior_design_report_sha256':sha(OLD/'report.json'),
 'prior_design_plan_sha256':sha(OLD/'PLAN.ko.md'),
 'superseded_design_statement':'Prior PLAN.ko.md line 70 must not be read as DiagnosticKind::Unsupported => unimplemented. Use explicit origin/disposition at construction sites.',
 'key_findings':[
  'Legacy Unsupported conflates ordinary lexical/grammar/validation errors, genuine feature gaps, resource bounds and unresolved Java-internal-error boundaries.',
  'Original invalidCharacter and amendsRequiresParens expose the conflation directly by source inspection; no original input was executed.',
  'Keyword-expression and amendment fallbacks require branch-specific semantic classification; blanket retagging is unsafe.',
  'Syntax kind occurs in resolver; operation and origin cannot be recovered from kind or rendered String.',
  'First-error, deferred integer checks, interpolation recovery and resolver owner replay must preserve typed metadata without changing ordering.',
  'Prepared is not eval success. Keep output API gap explicit and retain all72 original four-channel contracts.',
  'LanguageRejected is a Rust outcome, not a compatibility verdict. Only fresh pinned raw comparison can establish equality.'
 ],
 'planning_sha256':sha(OUT/'PLAN.ko.md'),
 'script_sha256':sha(OUT/'audit.py'),
 'assessed_compatibility':False,
 'unexecuted_next_steps':['Implement typed shared preparation boundary and grammar corrections when authorized.','Acquire original72 pinned CLI raw contracts with unchanged command/environment/resources.','Run all72 and explicit unsupported/resource/first-error controls; compare all four raw channels.']
}
write('report.json',report)
payload={p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='closure.json'}
write('closure.json',{'scope':'Read-only source audit/design artifact closure; no language compatibility claim.',
 'files':payload,'report_sha256':sha(OUT/'report.json'),'immutable':True})
print(json.dumps({'root':str(OUT),'report_sha256':sha(OUT/'report.json'),
 'plan_sha256':sha(OUT/'PLAN.ko.md'),'closure_sha256':sha(OUT/'closure.json'),
 'kind_references':len(kind_sites),'unsupported_references':len(unsupported_sites),
 'source_count':len(paths),'frozen_runtime_matches':len(freeze_checks)},indent=2))
