# Stage39 frontend 단계·실패 분류 사전 점검

이 문서는 Stage38 동결 소스의 읽기 전용 검토다. 원본 72개를 실행하거나 Rust/Java를 빌드하지 않았다. 구현·호환성 결과가 아니며, Stage38 최종 archive에 포함된 증거를 수정하지 않는다. `../stage38-upstream-error-adapter-design-01/PLAN.ko.md:70`의 `DiagnosticKind::Unsupported` 구분 제안은 아래의 **발생 지점별 명시적 분류**로 보완해야 한다. 기존 문서는 그대로 보존한다.

## 결론

`DiagnosticKind`만으로 ordinary language error와 미구현을 나눌 수 없다. `Unsupported`에는 일반 언어 거부, 아직 구현하지 않은 유효 언어 기능, 잘못된 진단의 미구현, Rust 자원 한계, Java 내부 오류와 관련된 보류 경계가 함께 들어 있다. `Syntax`도 lexer/parser 단계만 뜻하지 않는다. resolver가 modifier·const 규칙 위반에 사용한다. 진단의 기존 kind, 실제 발견 단계, 실패 성격, raw compatibility 판정을 각각 보존해야 한다.

새 어댑터에서 `Unsupported => unimplemented`, `Syntax => compatible language error` 같은 변환을 두지 않는다. 메시지의 `M1`, `unsupported`, `not implemented` 문자열을 검사해서도 안 된다. 생성 지점에서 의미를 부여하고, 기존 출력 바이트의 일치 여부는 이후 Java 원본 계약과 별도로 비교한다.

## 동결 소스에서 확인한 반례

| 발생 지점 | 현재 상태 | 필요한 구분 |
| --- | --- | --- |
| `parser.rs:250` | ASCII 미인식 문자에 `Unsupported` | 원본 `invalidCharacter.pkl`의 `^`는 pinned Lexer의 ordinary invalid identifier다. `&`/`~`도 pinned lexer의 일반 오류다. 전체 fallback에 유효 토큰 누락이 없는지 확인한 뒤 어휘 규칙별로 분리한다. 현재 메시지는 Java와 다를 수 있다. |
| `parser.rs:569` | 예약어를 identifier로 쓰면 `Unsupported`; `read?`만 `Syntax` | pinned `parseIdentifier`의 ordinary keyword rejection. kind 차이는 언어의 미구현 여부를 뜻하지 않는다. |
| `parser.rs:1486` | source가 `(`로 시작하지 않는 amendment에 `Unsupported` | 원본 `amendsRequiresParens.pkl`의 `bar { ... }`는 일반 오류다. 그러나 pinned parser는 `NewExpr`·`AmendsExpr`도 허용하므로 이 guard 전체를 무조건 언어 오류로 바꾸면 안 된다. AST 모양으로 올바른 문법 조건을 구현하고 허용 형식의 누락은 별도 gap으로 남긴다. |
| `parser.rs:2250` | primary의 남은 keyword/`_`가 모두 `Unsupported` | **혼합 경로**다. 유효 `import(...)`/`import*(...)`는 pinned expression이며 현재 기능 부족이다. 부적절한 keyword/underscore expression은 ordinary parse error다. token/grammar별 분리가 필요하다. |
| `parser.rs:2260` | expression 위치의 `[`에 `Unsupported` | pinned `parseExprAtom`에는 standalone bracket literal이 없다. expression 위치에서는 ordinary unexpected token이다. object entry/subscript의 유효 `[` 지원과 구분한다. |
| `resolver.rs:1562` | 비표준 모듈의 명시적 `external`에 `Unsupported` | pinned AstBuilder의 `cannotDefineExternalMember` ordinary validation error다. 선언 modifier 합산에서 파생된 external을 처리하지 못하는 인접 경로 `1556`은 계속 명시적 gap이다. |
| `parser.rs:679,742,753`, resolver의 base/derived 경로 | UTF-16 URI, glob import, base lookup, 파생 modifier 진단 미구현 | 지원하지 않는 capability의 명시적 실패로 유지한다. 단순히 헤더를 Java 오류처럼 꾸며 language error로 승격하지 않는다. |
| expression/type/interpolation budget | `Unsupported` | Rust 제한에 도달한 결과다. Java syntax error도 Java timeout도 아니다. `LimitExceeded`로 별도 기록한다. |
| `string_lexer.rs:698` | 범위를 넘는 Unicode escape에 `Unsupported` | Java 내부 오류와 관련된 미해결 경계다. Java 예외 stack을 합성하거나 ordinary error로 간주하지 않는다. Rust는 명시적 capability gap, Java는 실제 관찰 결과를 독립적으로 기록한다. |

`kind-sites.json`은 감사 대상 frontend 파일의 모든 `DiagnosticKind::...` 참조를 기록한다. `unsupported-sites.json`은 생성 지점과 소비 지점의 상세 분류를 담는다. 기존 `Syntax`/`DuplicateMember`/`IntegerRange`가 language-rule 계열이라는 소스 판단은 각 메시지·위치·우선순위가 이미 정확하다는 뜻이 아니다.

## 제안하는 최소 공통 타입

다음은 설계용 API이며 현재 구현된 API가 아니다. 이름은 구현 시 조정할 수 있지만 세 축은 합치지 않는다.

```rust
enum PreparationOperation {
    ParseModule, ResolveModule, CompileModule,
}

enum DiagnosticOrigin {
    Lexer, Parser, DeferredAstValidation, Resolver, Compiler,
}

enum FailureDisposition {
    LanguageRejected { rule: LanguageRule },
    UnsupportedCapability { capability: Capability },
    LimitExceeded { resource: FrontendResource, limit: usize },
    InternalFailure,
}

struct FrontendFailure {
    operation: PreparationOperation,
    origin: DiagnosticOrigin,
    disposition: FailureDisposition,
    diagnostic: Diagnostic,
}

enum PreparationOutcome<T> {
    Prepared(T),
    Failed(FrontendFailure),
}
```

- `operation`은 어떤 공통 API를 실행하다 실패했는지 나타낸다. `origin`은 실제 lexer/parser/deferred validation/resolver 발생 지점이다. upstream과 Rust의 소스 파일 배치가 다르다고 upstream phase를 실행했다고 보고하지 않는다.
- `LanguageRejected`는 구현이 특정 언어 규칙을 적용해 거부했다는 의미다. stderr가 틀리면 **ordinary language-error mismatch**로 남는다. compatible이라는 의미가 아니다.
- `UnsupportedCapability`는 실행 불가능한 기능 또는 아직 구현하지 못한 진단/의미론을 식별한다. valid import expression과 파생 modifier diagnostic을 같은 `Syntax`로 숨기지 않는다.
- 자원 제한은 제한 종류·값을 기록한다. 예: expression work 65,536, recursive scope/interpolation 32. 제한 발생을 Java 문법 오류나 전체 evaluator timeout과 같은 결과로 바꾸지 않는다.
- `InternalFailure`는 실제 Rust 내부 실패/잘못된 상태의 유형이다. Java `PklBugException` 관찰은 oracle 결과 축에 기록하며 Rust가 같은 내부 오류를 만들 필요가 없다.
- `DiagnosticKind`는 즉시 제거할 필요가 없다. 기존 API/테스트/formatter의 호환을 위해 legacy field로 남겨도 되지만 어댑터의 결과 분류에는 사용하지 않는다.

생성 지점까지 타입을 옮기는 가장 작은 경로는 `Diagnostic`에 위 origin/disposition metadata를 추가하고 `language(...)`, `unsupported(...)`, `limit(...)` 생성자를 두는 방식이다. public `parse_module`/`resolve_module`의 `Result<_, Diagnostic>` 형태를 유지할 수 있다. `FrontendFailure`는 공통 preparation 경계에서 operation을 붙인다. 모든 신규 지원 경로는 명시적 생성자를 사용한다. 기존 `new(kind,...)`에 default를 둘 경우 `UnclassifiedLegacy`라는 임시 별도 실패를 쓰고 Stage39 연결 경로에서는 하나라도 남으면 audit 실패로 다룬다. **legacy Unsupported를 일괄 Unclassified로 바꾸고 원본72를 unimplemented 처리하는 것으로 완료하지 않는다.**

공통 `evaluation` 내부에서 구조화된 preparation helper를 먼저 만들고 기존 scalar/source-session 경계가 그 결과를 기존 방식으로 format하게 한다. public String 반환 API를 갑자기 바꾸거나 formatter를 플랫폼마다 복제할 필요는 없다. 새 original-eval adapter는 String 결과를 역분석하지 않고 typed outcome을 직접 받는다. compiler/runtime의 `ErrorKind` 전면 개편은 이72의 parse rejection prefix에 필수는 아니다. 이후 단계에 진입하면 그 단계의 typed failure 또는 명시적 capability gap을 반환하며 frontend 성공을 전체 eval 성공으로 바꾸지 않는다.

## 첫 오류와 단계 전환을 보존하는 방법

1. `parse_module`은 현재처럼 source 순서대로 전체 module을 파싱한다. lexer를 먼저 EOF까지 돌려 invalid token을 수집하면 앞선 grammar error보다 뒤의 lexer error가 먼저 나올 수 있다. first-error 순서를 변경하지 않는다.
2. 정상 구문 경로만 EOF까지 완주한다. 첫 오류에서 멈추는 것은 부분 입력만 검사한다는 뜻이 아니다. property `result`만 골라 파싱하거나 fixture의 잘못된 줄만 떼어내지 않는다.
3. `parse_module:2325`의 integer pending error는 syntax 성공 뒤에 반환된다. 실제 operation은 ParseModule이지만 origin은 DeferredAstValidation이다. 선언 이름/member 경로를 그대로 유지한다. integer overflow를 발견하자마자 반환하면 뒤의 syntax error와 순서가 바뀐다.
4. string scan은 interpolation 오류를 지연·재생한다. metadata도 `pending`, `string_errors`, clone/move와 함께 보존한다. 현재 `string_lexer:453,456`이 legacy Unsupported를 보고 `&`/`~`를 다시 포맷하는 곳은 typed lexical rule을 소비하도록 변경한다. 모든 Unsupported를 recoverable syntax로 취급하지 않는다. nesting/work limit은 기존처럼 탈출해야 한다.
5. resolver `1172`의 kind 변경은 duplicate-member라는 진단 주제를 바꿀 뿐 failure disposition은 언어 거부다. `1603` 이후 diagnostic-owner replay는 소유 정보 외 모든 필드 동일성을 확인하므로 새 metadata도 결정적으로 동일해야 한다.
6. 새 metadata를 얻기 위해 파서 또는 resolver를 별도 횟수로 실행하지 않는다. 기존 owner replay의 의미는 보존하고 새 classifier용 재실행은 넣지 않는다.
7. `Prepared`가 나온 뒤 module initialization/output bytes를 지원하지 못하면 해당 단계의 `UnsupportedCapability`를 반환한다. `Prepared => exit 0, stdout empty` 또는 `ToString` 대체는 금지한다. 실제 `evaluateOutputBytes`는 여전히 별도 의무다.

## 원본72에 대한 영향

72 ID와 입력 해시, 전체 command/environment/resources/channel 계약은 그대로 유지한다. `original72-preflight.json`에 기존 identity와 이 검토의 정적 주의점을 기록했다. 모두 `execution = unexecuted`다. golden `.err`는 upstream이 정규화한 provenance이므로 이번 검토에서 raw expected로 사용하지 않았다.

- 46 delimiter + 20 numbered parser + 6 parser-directory 입력을 모두 유지한다. 현재 parser가 어느 kind를 반환할지는 전체72를 실행하지 않았으므로 결과표로 예측하지 않는다.
- `invalidCharacter.pkl`: ASCII fallback을 ordinary invalid identifier로 구현해야 한다. 단순 metadata만 수정해도 현재 `M1 token ...` 바이트는 호환되지 않는다.
- `amendsRequiresParens.pkl`: 실제 bar amendment 오류는 ordinary parse rejection이다. 허용된 new/amends 체인을 함께 확인해야 guard의 잘못된 확장을 막을 수 있다.
- `spacesBetweenDocComments.pkl`, `wrongDocComment.pkl`: 현재 Lexer는 `///`를 `//`와 같이 버린다. typed outcome만으로 누락된 문법을 고칠 수 없다. 주석/header 문법을 구현하고 parse-first 오류를 실제로 얻어야 한다. 준비 성공 뒤 frontend adapter가 성공값을 만들면 오류를 은폐한다.
- `constantStringInterpolation.pkl`: import의 string-constant 규칙은 일반 문법 오류다. 현재 `Kind::String` 요구에서 반환하는 다른 ordinary 메시지를 pass로 해석하지 않는다. 유효 import expression/glob 미구현과 구분한다.
- `typeAnnotationInAmends.pkl`: pinned ParserImpl에서 거부되는 규칙이다. Rust resolver/compiler까지 도달하더라도 그 실행 단계는 정직하게 기록하고 정확한 parser rejection 구현으로 고친다.
- 나머지 원본도 message/underlining/frame/default CLI profile/first-error가 다르면 mismatch다. 현재 kind가 Syntax라는 이유로 ready/pass를 선결하지 않는다.

## 어댑터·검증 도구의 결과 축

기존 raw `stdout`, `stderr`, `exit_code`, `files` 채널을 그대로 캡처한다. typed provenance는 별도의 sidecar/protocol에 기록하여 사용자 stderr 바이트에 JSON/진단태그를 섞지 않는다. Rust ordinary language failure와 explicit unsupported가 같은 process exit 1이어도 sidecar가 구분한다. tagged payload를 보내는 개발 protocol과 실제 CLI 관찰 채널은 별개로 보존한다.

최소 보고서 필드는 `adapter_execution`, `actual_phase`, `rust_outcome`, `oracle_outcome`, `raw_channel_comparison`, `compatibility`다. ordinary syntax error이면 raw 비교를 수행하지만 동일성 확인 전에는 pass가 아니다. unsupported/limit/internal이면 그 raw 결과를 보관하고 unresolved로 남긴다. 같은 오류 헤더/exit 또는 양쪽 모두 실패라는 이유로 pass를 만들지 않는다. Java 내부 오류·timeout·설정 실패는 별도 결과다.

`ready`는 원래 계약을 실제 실행하는 adapter 연결 상태이고 `pass`는 실행 후 raw 비교 결과다. 원본72를 동적으로 pass한 행만 ready로 골라내지 않는다. 지원 prefix를 벗어나는 행은 원래 입력·명령 그대로 시도한 explicit gap을 기록하고 전체 M2 의무에 남긴다. 출력 API 전체 미구현을 frontend 성공으로 대체하지 않는다.

## 구현 소유권과 필요한 검증

- core/diagnostic 담당: typed metadata/생성자, 공통 preparation helper, 기존 scalar/session 포맷 경계의 비손실 연결. resolver owner replay 안정성과 source ownership을 확인한다.
- frontend 담당: lexer/parser 발생 지점 분리, keyword·ASCII·amendment·constant-string·doc/header 일반 규칙. original72 이름을 production 분기에 사용하지 않는다.
- adapter/도구 담당: 원래 eval command/profile, structured sidecar, 4채널 raw 캡처와 offline verifier, ready와 결과 판정의 분리. 원본 입력이나 upstream goldens를 수정하지 않는다.
- 독립 oracle 담당: 새 단계에서 실제 pinned CLI 원본72를 취득한다. 이번 읽기 검토는 Java 실행을 대신하지 않는다.

필수 회귀는 (a) 원본72 전부, (b) keyword/invalid ASCII/standalone bracket ordinary rejection, (c) 유효 import expression/glob 및 UTF-16 URI가 명시적 unsupported로 남음, (d) ordinary error 뒤의 unsupported와 반대 순서에서 first-error, (e) deferred integer 오류 대 syntax 오류, (f) interpolation recovery 대 hard resource limit, (g) prepared 성공 후 unsupported output prefix, (h) explicit nonstdlib external 대 파생 modifier gap, (i) owner replay 동일성이다. 보충 사례는 원본72를 대체하지 않는다.

이번 검토에서는 위 테스트·빌드·평가를 실행하지 않았다. `report.json`은 읽은 소스·기존72 identity·동결117 소스와 MAIN 일치를 검증한 결과만 보고한다.
