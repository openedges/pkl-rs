# Stage39 원본 frontend 오류 eval 어댑터 설계

## 결정과 증거 경계

다음 구현 단위는 원본 `language-snippet` 72개의 **모듈 eval에서 발생하는 frontend 실패 경계**다. 원래 명령을 받아 공통 parser가 실제로 반환한 첫 오류를 CLI 진단 설정으로 출력하는 개발 어댑터를 만든다. 성공 모듈의 `output.bytes` 평가·PCF 렌더링은 별도 미구현 경계로 명시한다. 구문 분석 성공을 eval 성공으로 반환하거나 `module.toString()`으로 대신하지 않는다.

이 문서는 소스 읽기와 hash 검증만 수행했다. Rust 실행, 빌드, Java 재취득, 추적 파일 수정은 0회다. 아래 72개는 예상 통과 수가 아니다. 정확한 원래 행 전체는 `original72.json`, 개별 명령·입력·자원·채널·정적 단계 판단은 `case-analysis.json`에 있다. 기존 전체 M2 gate와 나머지 원본 의무를 변경하지 않는다.

원본 72개는 delimiter 46개, 번호 parser 20개, parser 폴더 오류 6개다. `parser13.pkl`을 추가하지 않으며 다른 parser 성공 입력을 제외한 결과로 전체 parser 지원을 주장하지 않는다. 72개 모두 같은 명령 prefix를 사용한다.

```text
eval --no-cache --no-project --settings pkl:settings
  --property name1=value1 --property name2=value2 --property /foo/bar=foobar
  --env-var NAME1=value1 --env-var NAME2=value2 --env-var /foo/bar=foobar
  --env-var "foo bar=foo bar" --env-var file:///foo/bar=file:///foo/bar
  <원래 input 경로>
```

원래 `cwd: .`, `LANG=C.UTF-8`, `LC_ALL=C.UTF-8`, `NO_COLOR=1`, `TERM=dumb`, `TZ=UTC` 및 `stdout/stderr/exit_code/files` 네 채널을 보존한다. `expected_exit: [0,1]`, `expected_outcome: observe`는 탐색 선언이지 pass 기준이 아니다. 새 pinned Java의 실제 정확한 종료 코드·원시 채널이 기대값이다.

## Pinned 실행 순서와 현재 구현의 차이

1. `EvalCommand.kt:82`의 power assertion 기본값은 true다. 원본 명령에 `--expression`, 출력 경로, 출력 형식, `--test-mode`는 없다.
2. `CliCommand.run/doRun`은 settings와 builder를 준비한다. 명시된 `pkl:settings`는 사용자 홈의 settings를 대신하며 `--no-project`는 프로젝트 탐색을 막는다. properties/env는 전달된 map이고 `--no-cache`는 module cache directory를 끈다.
3. `CliEvaluator.kt:145,193`은 expression이 없으면 `evaluateOutputBytes(ModuleSource.uri(...))`를 호출한다. `EvaluatorImpl.java:166,465`는 module load를 먼저 하고 나서 실제 `ModuleOutput.bytes`를 읽는다.
4. `VmLanguage.java:91`은 파일 원문 전체를 parser에 전달한다. `ParserImpl.parseModule`은 lexer와 함께 순차적으로 문법을 읽고 최초 `ParserError`에서 중단한다. 성공한 전체 module AST만 AstBuilder에 넘기며 그 뒤에 module body를 실행한다. parse가 실패하면 `VmUtils.toVmException`은 오류 span과 **파일에서 추론한 module name**으로 진단을 만든다. 일반 parser 오류에 REPL frame이나 property 실행 frame을 붙이지 않는다.
5. `CliCommand`는 `PklException.message`를 `CliException`으로 전달한다. `CliMain`은 그 문자열을 stderr에 그대로 쓰고 마지막 newline이 없을 때만 추가한다. 일반 오류 기본 exit는 1이다. 버그 wrapper는 별도 결과이며 일반 언어 오류와 섞지 않는다.

이 72개는 pinned Lexer/ParserImpl에서 실패하는 것으로 소스상 분류된다. 이름이 AST 검증처럼 보이는 `parser/typeAnnotationInAmends.pkl`도 `ParserImpl.java:463`에서 `{`를 보자마자 `typeAnnotationInAmends` 오류를 낸다. 문자열 indentation/continuation은 `parseMultiLineStringLiteralExpr`/lexer가 검사한다. constant import interpolation, 잘못된 import header, dangling doc comment도 ParserImpl 검사다. **fresh CLI 실행 전에는 이 소스 판단을 실제 취득 결과로 선언하지 않는다.**

현재 재사용 지점은 `parser::parse_module`, `Diagnostic`, `SourceMap/Source`, `diagnostic::RenderFrame/render_error`다. `evaluation.rs:151`의 private `compile_program`은 이미 전체 source를 parse→resolve→compile하며 parse/resolve 오류를 공통 renderer로 출력한다. 그러나 인자로 expression을 받고 compiler/runtime 실패를 expression-string 경계에 연결하므로 CLI eval용으로 이름만 바꿔 재사용하면 안 된다. `SourceSession::compile`도 property path entry에 `ToString`과 `repl:text`를 만든다. 기존 `examples/support/scalar_probe.rs`는 path+expression 프로토콜이며 이 원본 계약을 실행할 수 없다.

### 반드시 구현할 CLI frame 설정

원본 catalog 명령은 upstream native snippet engine의 명령과 다르다. `LanguageSnippetTestsEngine.kt:260`의 native engine은 `--test-mode`를 추가하지만 이 72행의 실제 `command`에는 없다. 따라서 그대로 실행한 CLI는 empty transformer가 아니다.

`StackFrameTransformers.createDefault`는 기본 transformer 뒤에 `settings.editor.urlScheme`을 적용한다. pinned `stdlib/settings.pkl`의 `System.urlScheme`은 `%{url}, line %{line}`다. 따라서 file frame의 표시 URI에는 소스상 `, line N`이 붙을 것으로 판단된다. 이것은 fresh 원본 CLI에서 확인할 사항이다. upstream `.err`의 `file:///$snippetsDir/...`를 그대로 예상하거나 `--test-mode`를 몰래 추가하지 않는다.

구현은 원래 URI와 표시 URI를 분리한다. logical frame의 source/span에서 line/column/end 좌표를 계산한 뒤 공통 frame transform을 적용하고, 마지막에 기존 renderer를 호출한다. 완성된 stderr 문자열에서 경로나 줄 번호를 치환하지 않는다. resource resolver의 module URI를 display URI로 덮어쓰지 않는다. API의 기존 identity/default frame 동작은 유지한다. 표준 library/패키지/사용자 transformer는 아직 도달하지 않는 경우에도 전체 지원으로 기록하지 않는다.

## 최소 공유 API와 개발 어댑터

권고 구성은 `evaluation/frontend.rs`의 작은 공유 준비/진단 경계와 별도의 `examples/module_eval_probe.rs`다. 이름과 타입은 구현 때 조정하되 아래 책임은 유지한다.

```rust
// 설계용 서명이며 현재 구현된 API가 아니다.
struct ModuleSourceInput<'a> {
    text: &'a str,
    uri: &'a str,             // 실제 읽은 source identity
    inferred_name: &'a str,
}
struct FrontendFailure {
    phase: FrontendPhase,     // LexOrParse / AstValidation; Unsupported 별도
    diagnostic: Diagnostic,
}
enum ModulePreparation {
    Parsed(Module),
    Rejected(FrontendFailure),
}
enum DiagnosticProfile {
    ApiIdentity,
    CliBundledSettings,       // pinned pkl:settings의 명시 지원 profile
}
fn prepare_module(input: ModuleSourceInput<'_>) -> ModulePreparation;
fn render_frontend_failure(input: ModuleSourceInput<'_>, failure: &FrontendFailure,
                           profile: DiagnosticProfile) -> String;
```

- `prepare_module`은 기존 `parse_module`을 호출한다. ID, 파일명, 예상 오류 문자열, golden을 읽지 않는다. 72개 전용 오류 테이블이나 입력 변환은 만들지 않는다.
- 일반 syntax 실패와 구현 자체의 `DiagnosticKind::Unsupported`를 구분한다. unsupported를 ordinary language failure나 성공으로 재분류하지 않는다.
- `Parsed`는 output 성공이 아니다. 현재 prefix 어댑터는 이 지점 이후가 미구현이면 명확한 `unsupported-output-evaluation` outcome을 기록하고 실패한다. stdout은 값/toString/가짜 PCF를 출력하지 않는다. 향후 실제 `prepare→initialize→ModuleOutput.bytes`의 준비 결과로 확장할 수 있다.
- resolver/compiler의 기존 AST 검증을 옮겨야 한다면 parse 성공 뒤 별도 단계로 둔다. 구문 오류를 이기도록 eager name resolution/type checking을 새로 넣지 않는다. 이번 72개에서는 일반 output/renderer 구현이 prerequisite이 아니다.
- structured failure는 source identity와 span을 보존한다. 현재 `compile_program`의 parse/resolve 오류 rendering 중복을 이 helper로 통합하고 기존 scalar/SourceSession raw regression을 유지한다. 오류를 module eval에서 formatting할 때 expression이나 `repl:text`를 생성하지 않는다.

`module_eval_probe`는 원래 `eval` argv를 받아야 한다. 파일은 실제 argv/cwd로 해석하고 원문을 읽는다. 같은 원본 상대 경로를 동일한 staged workspace에서 Java/Rust에 전달하면 양쪽 실제 물리 URI가 같아진다. 그 URI를 기록하며 checkout 경로에서 실행한 것처럼 표시하지 않는다. symlink/경로 정규화는 고정 ASCII corpus에서 쓰이지 않는 부분도 추후 generic 입력으로 확인하고, 현재 scalar의 무조건 canonicalize를 근거 없이 복사하지 않는다.

지원할 초기 CLI option profile은 원래 72행에 필요한 `eval`, 단일 file module, `--no-cache`, `--no-project`, `--settings pkl:settings`, 반복 `--property KEY=VALUE`, `--env-var KEY=VALUE`, 무색 stderr, 기본 power=true다. map은 첫 `=`에서만 나누고 공백·슬래시·colon을 포함한 key를 보존한다. option을 수집한 뒤 버리는 wrapper를 만들지 않는다. source initialization으로 진행하지 않더라도 config 객체에 보존하고 profile의 유효성/순서를 테스트한다.

`pkl:settings`는 pinned bundled default 설정 profile을 공통 코드로 명시 지원할 수 있다. 그 설정의 editor/System 및 nullable HTTP 기본값과 transformer를 실제 값으로 표현한다. 이는 임의 settings module loader 지원이 아니다. 다른 settings URI, 사용자 editor/project/HTTP override를 조용히 무시하지 말고 초기 단계에서 unsupported로 기록한다. 원본 Java에서 settings 초기화가 target source 오류보다 먼저 실패한다면 해당 계약은 이 prefix 범위로 닫을 수 없다. 지원 범위를 source-backed default profile로 한정하는 결정은 implementation docs에 명시한다.

Native CLI만 파일을 읽고 stdout/stderr/exit를 전달한다. Wasm/NAPI는 Host가 준 같은 원문·source URI·옵션 profile을 공통 함수에 전달하고 UTF-16 또는 명시한 byte 배열로 결과를 운반한다. 브라우저에 native process exit/files 실행을 한 것처럼 표시하지 않는다. native 원래 CLI 계약과 portable 공통 frontend/diagnostic 결과는 별도 실행 증거다.

## Parser 작업과 첫 오류 규칙

어댑터만 추가해서 72개가 통과한다고 예상하면 안 된다. 현재 소스에서 확인되는 실제 작업은 다음과 같다.

- `Lexer::next_token`은 모든 `//`를 버리므로 `///`의 결합·줄바꿈 경계·header 부착 여부를 잃는다. `parser14.pkl`, `spacesBetweenDocComments.pkl`, `wrongDocComment.pkl`이 이 경로를 요구한다. DOC_COMMENT를 일반 line comment와 구분해 parseMemberHeader와 import 금지 규칙을 공통 구현해야 한다. 원래 doc text/span/newline count를 보존한다.
- constant import 문자열에서 interpolation은 평가하거나 module loading으로 넘어가기 전에 금지한다. 현재 `Parser::import`의 `Kind::String` 검사만으로 pinned 메시지/span이 나오는지는 미검증이며 `StringTemplate`의 ordinary unexpected-token 처리로 퉁치면 안 된다.
- typed property amendment는 `{`에서 pinned 전용 메시지·힌트를 내야 한다. Rust resolver의 다른 object-property 타입 오류나 VM amendment 오류로 대체하지 않는다.
- delimiter 오류는 EOF 또는 다음 줄의 token을 만났을 때 실제 예상 token·직전 token 끝 위치·delimiter 종류를 보존한다. pinned `expect`는 EOF/줄바꿈 경계에서 previous stopSpan+1을 쓰며, 모든 오류를 offending-token span으로 표시하지 않는다. `] ]`와 `]]`도 원문 간격을 잃지 않는다.
- numeric separator, escape continuation, multiline indentation, raw delimiter는 해당 lexer/parser 단계의 오류 순서를 보존한다. multiline 문자열 내부 interpolation 검증은 이미 Rust heap-backed scanner가 있으므로 전체를 단순 정규식으로 대체하지 않는다.

"전체 module parsing"은 전체 원문을 전달하고 성공한 구문 tree가 있어야 다음 단계로 간다는 뜻이다. 첫 문법 오류 뒤의 나머지 파일을 사전 lexing하여 더 늦은 lexical 오류를 먼저 내는 방식이 아니다. `parse_module` 첫 실패를 반환하고 AST 검증/unknown-name/type/module initialization을 선행시키지 않는다. 현재 deferred integer 검사처럼 순서상 나중 단계인 검증만 구문 성공 뒤에 처리한다. 서로 다른 오류가 있는 추가 control은 source-backed Java로 순서를 고정한다.

보완 controls: 앞선 lazy `throw`/unknown name와 뒤 문법 오류, 앞 문법 오류와 뒤 잘못된 identifier, import interpolation과 뒤 undefined name, 여러 문법 오류, 명시 module 이름 이후 syntax 오류, 동일 body의 LF/CRLF/CR, supplementary scalar와 EOF zero-width span, doc comment+blank/comment/import/header 조합. 보완 source는 원본72를 대체하지 않는다.

## 원본 계약 취득과 tooling 연결

`tools/m2_language.py`는 현재 `language-api-string`만 선택하고 식·power flag·Java M2LanguageProbe·REPL outcome에 고정되어 있다. `tools/m2_manifest.py`는 모든 upstream snippet을 `adapter=None/state=unimplemented`로 생성한다. 이 두 지점을 함께 확장해야 원본 ID가 실제 실행된다.

권고 adapter tag는 `language-module-eval`이며 별도 whitelist에 원본 ID와 지원 profile만 지정한다. `expression`을 추가하지 않는다. `upstream_case`의 command/cwd/environment/channels/resources를 그대로 운반한다. subset은 error basename이나 `.err` 유무를 실행 중에 추측하여 결정하지 말고 reviewed original ID manifest로 고정한다.

`tools/compat.py`에 이미 원래 명령 실행에 필요한 `prepare_workspace`, `case_execution`, `capture`, `store_capture`, `load_capture`, `differences` 계열과 generated files/workspace mutation 검증이 있다. 이를 재사용하는 공통 CLI acquisition helper를 만들거나 M2 runner가 이 모듈에 위임한다. `m2_language.capture`는 cwd=ROOT와 stdout/stderr 두 채널에 고정되어 있어 그대로 사용할 수 없다. Java prefix는 실제 pinned CLI entrypoint이며 `M2LanguageProbe`로 바꾸지 않는다.

1. pin/입력/resources/options를 hash 검증한다. fresh 관리 workspace에 원래 상대 tree를 보존한다. 같은 절대 workspace에서 Java와 Rust를 순차 취득하거나 정확히 같은 URI identity가 되도록 원래 계약의 workspace 경계를 설계한다. 서로 다른 workspace 경로를 사후 치환하는 비교는 금지한다.
2. Java CLI 원래72를 두 fresh process/evaluator로 실행한다. 예상 stderr/header/exit를 Rust로 만들지 않는다. upstream `.err`는 path/line/website/stdlib SHA가 가공된 provenance로만 보존한다. 일반 언어 오류·Java 내부 오류·timeout·설정 오류를 구분한다. 필요하면 별도의 source-phase 관찰을 추가하되 실제 CLI raw capture를 대신하지 않는다.
3. Rust도 같은72 명령을 실행해 exact stdout/stderr/exit/files를 저장한다. 빈 stdout과 빈 generated files도 실제 관측이다. cache·tmp 등 harness-private 기록은 분리하며 원래 workspace의 예상하지 않은 쓰기/삭제/추가도 기록하고 비교한다. source/reference를 수정하지 않는다.
4. verifier는 입력/명령/옵션/환경/cwd/실제URI/종료코드/모든 파일 path·bytes/runner source·binary/toolchain을 재계산한다. 성공 여부만 기록하거나 `trim`, stderr path 치환, 파일명 정렬 후 내용 재생성은 하지 않는다. path 집합 비교 자체의 정렬은 표시·집합 확인일 뿐 파일 바이트 비교를 바꾸지 않는다.
5. 기존 scalar 행과 검증 규칙은 그대로 유지한다. adapter별 command verifier와 raw channel comparator를 분리하고 full gate에 둘의 실제 결과를 함께 넣는다. 알려진 실패나 미실행 원본은 계속 full-gate 실패다.

## ready/pass와 종료 조건

`ready`는 **원래 계약을 실행하는 지원된 adapter가 연결됨**을 뜻한다. diagnostic 바이트가 틀린 실행 가능한 행은 ready이면서 mismatch일 수 있다. pass만 골라 ready로 옮겨 실패 행을 숨기지 않는다. 반대로 parse 성공 이후 output API가 필요하여 adapter가 explicit Unsupported를 반환한 행을 frontend 완료로 보지 않는다. 그런 원래 의무는 지원 범위 사유와 실제 실패 capture를 남긴다.

이72의 ready 전환 조건은 원래 ID/input/resources/profile 불변, 실제 parse rejection 경계 제공, no-REPL CLI 진단, 전체4채널 runner+offline verifier 구현, source-bound 기록 실행이다. compatibility pass는 그 뒤 fresh Java 원래 계약과 모든 byte/exit/files가 동일해야 한다. requirement mapping은 기존 semantic/grammar 항목에 partial로 연결하며 parser 전체 지원을 선언하지 않는다.

처음 실행에서72개를 전부 포함하고 각 결과를 보존한다. 72개의 지원 prefix가 실제로 조기 오류를 낸다는 fresh 관찰이 확보된 후에만 그 이유로 PCF 성공 renderer를 이 단계의 선행 조건에서 제외할 수 있다. ModuleOutput/renderer에 도달한 행은 다른 식으로 바꾸지 않고 별도 의존성으로 남긴다. 960/40 등 C 계획의 수치는 그 snapshot의 값이며 현재 전체 진행률로 재사용하지 않는다.

## 구현 분리와 권고 순서

- 공통 runtime 담당: `evaluation/frontend.rs`, 기존 evaluation 진단 중복 정리, 공통 frame profile/renderer, parser·string/docheader 필요 수정. 먼저 API/phase metadata를 고정한다.
- adapter/tool 담당: 새 native module_eval_probe, original-ID adapter registry, m2_manifest/m2_language 또는 공통 compat 확장, 원래4채널 verifier와 변조 회귀. parser 예상 오류를 도구에서 생성하지 않는다.
- 독립 검증 담당: pinned Java 원래72 source/cmd 취득, parser phase/CLI default 관찰, raw differential, Node/browser 공통 결과와 native 계약 경계 분리, source/artifact/파일 mutation 감사.

서로 겹치는 파일 소유권은 다음 Stage39 checkout 개설 후 root가 정한다. Stage38는 동결 상태로 둔다. 먼저 원래72 fresh Java와 고정 옵션 profile을 확인하고, 최소 adapter로 기존 Rust 결과를 그대로 취득해 actual gap을 남긴 뒤 parser/diagnostic을 수정한다. 그 후 원래72 전체 재취득, 기존 scalar/Host/trace 회귀, workspace checks와 실제 portable 검증을 수행한다. 소스 단계 추측이나 adapter build 성공만으로 원본을 닫지 않는다.
