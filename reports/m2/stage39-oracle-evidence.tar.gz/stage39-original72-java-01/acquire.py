#!/usr/bin/env python3
import sys, os, json, shutil, subprocess, platform, time
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39')
OUT=ROOT/'target/m2/stage39-original72-java-01'
WORK=ROOT/'target/m2/stage39-original72-workspace-01/workspace'
sys.path.insert(0,str(ROOT/'tools'))
import compat,oracle

def write(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def load(path):return json.loads(path.read_text())
def sha(path):return oracle.sha256(path)
def phase(data):
 if b'PklBugException' in data or b'An unexpected error has occurred' in data:return 'internal-error'
 if '–– Pkl Error ––'.encode() in data:return 'ordinary-language-error'
 return 'unclassified-error'
def prepare():
 if (OUT/'profile.json').exists():raise RuntimeError('Preparation already exists')
 original=load(ROOT.parent/'pkl-rs.stage38/target/m2/stage38-upstream-error-adapter-design-01/original72.json')
 catalog=load(ROOT/'compatibility/m2-language.json');byid={r['id']:r for r in catalog['cases']}
 corpus=load(ROOT/'compatibility/corpus.json');upstream={r['id']:r for r in corpus['cases']}
 assert len(original)==72 and len({r['id'] for r in original})==72
 for row in original:
  assert row==byid[row['id']],row['id']
  assert row['upstream_case']==upstream[row['id']],row['id']
  assert sha(ROOT/row['input'])==row['input_sha256']
  assert '--test-mode' not in row['upstream_case']['command']
 manifest={k:corpus[k] for k in ('baseline','sources')};manifest['cases']=[r['upstream_case'] for r in original]
 write(OUT/'original72.json',original);write(OUT/'manifest.json',manifest)
 for path in ['tools/compat.py','tools/oracle.py','oracle.lock.json','references.lock','rust-toolchain.toml','AGENTS.md']:
  dst=OUT/'sources'/path;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/path,dst)
 for name in ['PLAN.ko.md','case-analysis.json','closure.json']:
  src=ROOT.parent/'pkl-rs.stage38/target/m2/stage38-upstream-error-adapter-design-01'/name
  dst=OUT/'design-inputs'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
 for row in original:
  dst=OUT/'inputs'/row['input'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/row['input'],dst)
 lock=load(ROOT/'oracle.lock.json');oracle.verify_sources(ROOT,lock)
 artifact=ROOT/'.cache/oracle'/lock['artifact']['filename'];release=oracle.verify_artifact(artifact,lock)
 home=OUT/'identity-profile/home';tmp=OUT/'identity-profile/tmp';home.mkdir(parents=True);tmp.mkdir()
 env={'PATH':os.defpath,'HOME':str(home),'TMPDIR':str(tmp),'TMP':str(tmp),'TEMP':str(tmp),'LC_ALL':'C','LANG':'C','TZ':'UTC','TERM':'dumb','NO_COLOR':'1','COLUMNS':'80'}
 java=Path(os.environ.get('PKL_ORACLE_JAVA') or shutil.which('java')).resolve()
 identity=oracle.verify_java(java,lock,env)
 prefix=[str(java),*lock['jvm_options'],f'-Duser.home={home}',f'-Djava.io.tmpdir={tmp}','-cp',str(artifact),'org.pkl.cli.Main']
 version=subprocess.run([*prefix,'--version'],cwd=ROOT,env=env,capture_output=True,timeout=60)
 (OUT/'version.stdout.bin').write_bytes(version.stdout);(OUT/'version.stderr.bin').write_bytes(version.stderr)
 assert version.returncode==0 and not version.stderr and version.stdout.startswith(b'Pkl 0.32.0 (')
 write(OUT/'profile.json',{'schema':1,'root':str(ROOT),'workspace':str(WORK),'sourceRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),'reference':lock['source'],'lockSha256':sha(ROOT/'oracle.lock.json'),'jdk':identity,'artifact':str(artifact),'artifactResolved':str(artifact.resolve()),'artifactSha256':sha(artifact),'release':release,'command':prefix,'environment':env,'version':{'command':[*prefix,'--version'],'cwd':str(ROOT),'exit_code':version.returncode,'stdoutSha256':sha(OUT/'version.stdout.bin'),'stderrSha256':sha(OUT/'version.stderr.bin')},'compiler':'not invoked; original CLI executes pinned compiled JAR','host':platform.platform(),'protocol':{'repeats':2,'concurrency':1,'timeoutSeconds':60,'testMode':False,'goldens':'provenance only; never expected raw output'},'sourceSnapshots':{p.relative_to(OUT/'sources').as_posix():sha(p) for p in (OUT/'sources').rglob('*') if p.is_file()}})
 compat.prepare_workspace(ROOT,WORK)
 validation=compat.validate_inputs(ROOT,manifest,WORK);write(OUT/'input-validation.json',validation)
 baseline=compat.snapshot(WORK);write(OUT/'workspace-baseline.json',baseline)
 write(OUT/'staging.json',{'workspace':str(WORK),'method':'compat.prepare_workspace; pkl + pkl-pantry tracked resources and tests/fixtures','resourceSets':[{k:s[k] for k in ('repository','revision','resource_set_sha256')} for s in corpus['sources']],'filesValidated':validation,'workspaceSnapshotSha256':sha(OUT/'workspace-baseline.json'),'entries':len(baseline),'original72MatchesCatalog':True,'original72UpstreamCasesMatchCorpus':True})

def run_one(index,repeat):
 original=load(OUT/'original72.json');row=original[index];case=row['upstream_case'];profile=load(OUT/'profile.json');baseline=load(OUT/'workspace-baseline.json')
 directory=OUT/'cases'/compat.case_directory(row['id'])/str(repeat)
 if (directory/'process.json').exists():raise RuntimeError(f'Refusing overwrite {directory}')
 command,env,generated,recorded=compat.case_execution(case,profile['command'],profile['environment'],WORK)
 before=compat.snapshot(WORK);assert before==baseline,'workspace drift before process'
 cwd=compat.contained(WORK,case.get('cwd','.'));started=time.time_ns()
 try:result=compat.capture(command,cwd,env,60,generated)
 except compat.CaptureTimeout as error:result=error.result
 after=compat.snapshot(WORK);changes,secondary=compat.restore_changes(ROOT,WORK,before,after)
 assert compat.snapshot(WORK)==before,'workspace restoration failure'
 result['workspace_changes']=changes;result['files']={f'generated/{k}':v for k,v in result['files'].items()};result['files'].update(secondary)
 metadata=compat.store_capture(directory,result)
 # Preserve private HOME/tmp side effects separately, before repeat resets same state path.
 state=WORK/'.state'/compat.case_directory(row['id']);private={}
 for p in sorted(state.rglob('*')):
  if p.is_file() or p.is_symlink():
   rel=p.relative_to(state).as_posix();data=compat.resource_bytes(p);dst=directory/'private-state'/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);private[rel]={'kind':'symlink' if p.is_symlink() else 'file','sha256':compat.digest(data)}
 outcome='timeout' if result['timed_out'] else 'value' if result['exit_code']==0 else phase(result['stderr'])
 process={'id':row['id'],'index':index,'repeat':repeat,'source':row['input'],'sourceSha256':row['input_sha256'],'moduleUri':(WORK/row['input']).as_uri(),'command':command,'originalArguments':case['command'],'cwd':str(cwd),'environment':recorded,'fullAllowlistedEnvironment':env,'startedUnixNs':started,'finishedUnixNs':time.time_ns(),'result':metadata,'outcome':outcome,'phase':'unattributed; CLI diagnostic retained verbatim','workspaceBeforeSha256':compat.digest(compat.encoded(before)),'workspaceAfterSha256':compat.digest(compat.encoded(after)),'privateStateFiles':private}
 write(directory/'process.json',process)
 print(json.dumps({'index':index,'repeat':repeat,'id':row['id'],'outcome':outcome,'exit':result['exit_code'],'stderrBytes':len(result['stderr']),'files':len(result['files']),'changes':len(changes)}),flush=True)
 return process

def finish():
 rows=load(OUT/'original72.json');records=[];diffs=[]
 for i,row in enumerate(rows):
  path=OUT/'cases'/compat.case_directory(row['id']);a=compat.load_capture(path/'0');b=compat.load_capture(path/'1');changed=compat.differences(a,b);diffs.append({'id':row['id'],'channels':changed})
  records.extend([load(path/str(n)/'process.json') for n in range(2)])
 profile=load(OUT/'profile.json');source_stable=all(sha(ROOT/p)==v for p,v in profile['sourceSnapshots'].items())
 # Inputs and original commands remain authoritative even if separate owners change catalog execution metadata.
 manifest=load(OUT/'manifest.json');validation=compat.validate_inputs(ROOT,manifest,WORK)
 counts={kind:sum(r['outcome']==kind for r in records) for kind in sorted({r['outcome'] for r in records})}
 write(OUT/'report.json',{'schema':1,'kind':'fresh pinned Java original CLI oracle acquisition; not Rust compatibility','caseCount':72,'processCount':len(records),'counts':counts,'repeatDifferences':[r for r in diffs if r['channels']],'allOriginalInputsValidated':validation,'workspaceRestored':compat.snapshot(WORK)==load(OUT/'workspace-baseline.json'),'helperSourcesStable':source_stable,'artifactStable':sha(Path(profile['artifact']))==profile['artifactSha256'],'profilePath':'profile.json','records':records,'phaseScope':'Whole CLI outcome acquired. Lexical/parse attribution is separately source-backed; no API execution phase inferred from expected errors.','sourceBindingScope':'Pinned upstream sources/resources and helper source snapshots; ongoing unrelated Rust production implementation is not a candidate here.'})

if __name__=='__main__':
 if sys.argv[1]=='first':prepare();run_one(0,0)
 elif sys.argv[1]=='rest':
  run_one(0,1)
  for i in range(1,72):
   for repeat in range(2):run_one(i,repeat)
  finish()
 else:raise RuntimeError('first or rest')
