# Stage46 전체 회귀 마감 감사 실행 준비

현재는 **도구 초안만 작성**했다. `audit.py`를 import/실행하지 않았으며 `--prepare`도 실행하지 않았다. AST 구문 확인만 수행했다. Stage46 wrapper 84018은 root가 관리하며 현재 결과를 읽어 통과나 마감을 주장하지 않는다.

대상 구현은 `a3eb3634558cef6f36189320498fe7e013296c48`이다. Stage47 renderer/identity live 구현, 후속 supplemental platform, 성능/CI 결과를 이 회귀에 합치지 않는다.

## 입력과 조건

- predecessor는 real Stage45 `target/m2/stage45-final-audit-01/audit.py`다. baseline은 MAIN의 게시된 `stage45-final-{summary,raw-changes,source-map,regression-captures}.json`과 index가 가리키는 archive 6개다. 그 원본은 변경하지 않는다.
- 새 대상은 real Stage46 `stage46-language-final-01`, `stage46-class-lifecycle-final-01`, `stage46-full-regression-01`이다.
- 감사는 wrapper의 complete, 정확한 8개 명령/argv, integrity 명령0·strict 명령0/1, root의 실제 terminal receipt를 모두 요구한다. receipt는 `session_id:84018`, `exit_code:0`, 최종 `process_report_sha256`을 포함해야 한다. 기록된 child acquisition0만으로 wrapper 실제0을 추정하지 않는다.
- baseline의 case/selected ID와 순서·정의·요구상태·기존 import1b JVM profile mapping을 유지한다. Stage45에서 이미 적용된 mapping을 새 변경으로 세지 않는다. requirements의 SHA256 링크 갱신과 의미 변경은 구분한다.
- 새 pass/nonpass·full gate·persistent 수치는 실제 보고서와 원시 기록에서 산출한다. 현재 nonpass와 old/new historical union을 서로 다른 필드로 기록한다. 미래 통과 수치나 “남은 몇 개 해결”을 미리 넣지 않는다.

## 감사 범위

1. 게시 Stage45 pointer와 archive 자체의 EVIDENCE/hash/path/size를 대조한다.
2. Stage46 case별 CLI stdout/stderr/exit/files 또는 API stdout/stderr/outcome을 원문에서 재분류한다. 실패·oracle-error·Unsupported·timeout 등을 보존한다. metamorphic 관계와 full failure reasons도 실제 값으로 재계산한다.
3. import1b의 동일 case 단일 계수, 원래 CLI 계약, JVM 반복2개, pinned profile/oracle, parent recorded-build→child supplied-artifact 연결, 원래 workspace/input/resource/classpath/command를 확인한다. child native build를 허용하지 않는다.
4. lifecycle은 schema2를 요구한다. `.cargo/config.toml`, Cargo.toml/Cargo.lock/rust-toolchain.toml을 **직접** sources에 캡처했는지 확인한다. Stage45 schema1의 `.cargo` 누락을 이 결과로 소급 수정하지 않는다.
5. persistent fixture의 원래 sequence/repetition/호출 순서와 실제 실행 프로토콜을 대조한다. status/stdout/stderr만 equality 계약이고 error-class 차이는 원문을 보존해 별도 집계한다. 누락·oracle-error는 pass가 아니다.
6. 모든 캡처 source를 actual implementation Git blob 및 그 commit의 reference gitlink tree에 결합한다. native/JVM artifact·빌드 명령·oracle/JDK identity 및 전체 source/artifact stability를 대조한다.
7. evidence map에 선언된 exact payload만 직접 읽는다. 디렉터리 walk/rglob는 하지 않는다. exact `language/build`, `language/jvm-classpath/build`, `lifecycle/build`는 map에도 들어오면 거부하며 열거하지 않는다. `build`라는 일반 basename 제외나 alias 하강은 없다. 이 감사의 선언 payload 검증과 producer의 actual path coverage 검사는 구분한다.
8. 종료 시 선언 payload 전체와 report hash를 다시 읽어 감사 도중 변경을 거부한다. 출력은 이 proposal 디렉터리 안에만 작성한다. 원본·production·Git은 쓰지 않는다.

development gate의 예외 의미는 source-blob 결합 이후 캡처된 read-only predicate 두 개로 확인한다. 일반 raw status 및 strict subset/full 이유 재구성은 별도로 수행한다. 이 predicate는 development-only 예외이며 호환 통과를 뜻하지 않는다.

## 실행 권한 이후의 명령

root가 84018의 실제 종료를 확인하고 별도 실행을 허용한 뒤에만 실행한다. 아래 명령은 현재 실행하지 않았다.

```sh
python3 target/m2/stage46-final-audit-proposal-01/audit.py --prepare
python3 target/m2/stage46-final-audit-proposal-01/audit.py --audit \
  --wrapper-terminal /Users/cody.ij.hwang/Projects/pkl-rs.stage46/target/m2/stage46-full-regression-01/outer-terminal.json
```

`--prepare`는 게시 baseline·기대 commit manifest·wrapper source를 고정한다. `--audit`는 기존 report를 덮어쓰지 않는다. 초기 감사 실패가 나면 원래 stdout/stderr/출력을 보존하고 필요한 교정은 새 실행 기록으로 분리한다. 이 도구는 아직 실행 검증되지 않은 초안이며 root의 최종 실행과 독립 결과 검토가 남아 있다. publication archive/index/최종 summary와 문서 주장은 그 뒤 별도로 검증한다.
