from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
OUT=Path(__file__).parent
AUDIT=MAIN/'target/m2/stage46-final-audit-proposal-01/audit.py'
RECEIPT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46/target/m2/stage46-full-regression-01/outer-terminal.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
report={'schema':1,'scope':'Authorized terminal-only Stage46 independent audit execution; no acquisition/build/evaluator/test rerun.','startedUtc':now(),'wrapperPid':os.getpid(),'python':sys.executable,'pythonSha256':sha(Path(sys.executable)),'auditSourceSha256':sha(AUDIT),'rootTerminalReceiptSha256':sha(RECEIPT),'commands':[],'complete':False}
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for name,args in [('prepare',['--prepare']),('audit',['--audit','--wrapper-terminal',str(RECEIPT)])]:
 argv=[sys.executable,str(AUDIT),*args]
 with (OUT/(name+'.stdout.bin')).open('wb')as stdout,(OUT/(name+'.stderr.bin')).open('wb')as stderr:
  process=subprocess.Popen(argv,cwd=MAIN,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr)
  (OUT/'active.json').write_text(json.dumps({'command':name,'pid':process.pid,'argv':argv},indent=2)+'\n')
  code=process.wait()
 row={'name':name,'argv':argv,'pid':process.pid,'exitCode':code,'finishedUtc':now(),'stdoutSha256':sha(OUT/(name+'.stdout.bin')),'stderrSha256':sha(OUT/(name+'.stderr.bin'))}
 report['commands'].append(row);save();print(name,'exit',code,flush=True)
 if code:
  report.update(finishedUtc=now(),exitCode=code);save();raise SystemExit(code)
assert sha(AUDIT)==report['auditSourceSha256'] and sha(RECEIPT)==report['rootTerminalReceiptSha256']
report.update(complete=True,finishedUtc=now(),exitCode=0);save();(OUT/'active.json').write_text(json.dumps({'terminal':True,'exitCode':0})+'\n');print('AUDIT WRAPPER COMPLETE',flush=True)
