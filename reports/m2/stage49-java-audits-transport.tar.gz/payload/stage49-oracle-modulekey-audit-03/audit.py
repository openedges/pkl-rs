"""Independent readback and one-time inventory seal for completed Stage49 Java captures."""
from pathlib import Path
import collections, datetime, hashlib, json, os, stat
O=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def check(ok,msg):
    if not ok:raise ValueError(msg)
summaries=[]
for name,tool in [('stage49-oracle-modulekey-05',29155)]:
    root=O.parent/name
    terminal=json.loads((root/'outer-terminal.json').read_bytes());report=json.loads((root/'report.json').read_bytes())
    check(terminal['exitCode']==0 and terminal['liveHandles']==[] and terminal['sourceBefore']==terminal['sourceAfter'],'actual closed stable outer process')
    check(not report['inputChanges'] and report['workspacesUnchanged'] and report['jarStable'],'original producer input stability')
    check(all(not r['rawPathDifferences'] for r in report['repeatDifferences']),'fresh-JVM raw repeat equality')
    for path,h in report['inputHashes'].items():check(sha(Path(path).read_bytes())==h,'post-capture exact declared input '+path)
    allowed={'inputs-after.json','run.py','outer.stdout.bin','TrustProbe.java','report.json','identity','classes','trust-uris.txt','workspace','cases','runtime-private','input-paths.json','AdmissionProbe.java','workspaces-after.json','inputs-before.json','launch.py','javac','cases.json','PLAN.ko.md','outer.stderr.bin','progress.json','tool-sources','outer-launch.json','workspaces-before.json','jdk-identity','outer-terminal.json','prepare.py','profile.json','upstream','predecessor.json'}
    check(set(p.name for p in root.iterdir())<=allowed,'exact authored capture-root boundary before descent')
    inventory={};payloads={}
    for current,dirs,files in os.walk(root,followlinks=False):
        for n in dirs:check(stat.S_ISDIR((Path(current)/n).lstat().st_mode),'regular capture directory')
        for n in files:
            p=Path(current)/n;check(stat.S_ISREG(p.lstat().st_mode),'regular capture payload');rel=str(p.relative_to(root));b=p.read_bytes();payloads[rel]=b;inventory[rel]={'kind':'regular','sha256':sha(b),'bytes':len(b),'mode':stat.S_IMODE(p.stat().st_mode)}
    counts=collections.Counter();events=0;cause_count=0;checks=0
    for obs in report['observations']:
        base=f"cases/{obs['case']}/{obs['repeat']}/";combined=b''
        record=next(r for r in report['records'] if r['case']==obs['case'] and r['repeat']==obs['repeat'])
        check(record['exitCode']==0 and not record['timedOut'],'actual Java process terminal')
        proc=json.loads(payloads[base+'terminal.json']);check(proc['pid']==record['pid'] and proc['exitCode']==0,'reported actual Java PID/terminal')
        for call in obs['calls']:
            p=call['rawPrefix'];check(not call['missingFields'],'API reached capture boundary')
            check(payloads[p+'.status.bin'].decode()==call['status'] and call['status'] in ['success\n','error\n'],'exact raw status');counts[call['status']]+=1
            for channel in ['stdout','stderr']:
                b=payloads[p+'.'+channel+'.bin'];u=payloads[p+'.'+channel+'.code-units.bin']
                check(b.hex()==call[channel+'Utf8Hex'] and u.hex()==call[channel+'Utf16BEHex'],'report/channel exact bytes')
                check(len(u)%2==0 and u.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==b,'independent actual Java string encodings')
            for when in ['Before','After']:check(payloads[p+'.counters-'+when.lower()+'.bin'].decode()==call['counters'+when],'raw/report counter bytes')
            checks+=7
        for session in obs['sessions']:
            check(int(dict(line.split('=',1) for line in session['counters'].splitlines())['event'])==len(session['events']),'session exact event count')
            uri_count=int(dict(line.split('=',1)for line in session['counters'].splitlines())['resolveImportUri'])
            check(uri_count==(2 if obs['case'].endswith('-uri')else 0),'actual override invocation count versus wrapper bypass')
            for ui in range(uri_count):
                prefix=base+f"calls/session-{session['session']}/uri-call-{ui}"
                for field in ['key-uri','operand','result']:
                    b=payloads[prefix+'.'+field+'.bin'];u=payloads[prefix+'.'+field+'.code-units.bin']
                    check(u.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==b,'actual override argument/result independent encodings')
                operand=payloads[prefix+'.operand.bin'].decode();target=payloads[prefix+'.result.bin'].decode()
                check((operand,target)in[('./child.pkl','memo:/override-relative.pkl'),('memo:/authored-absolute.pkl','memo:/override-absolute.pkl')],'actual configured override input/result observed')
                check(payloads[prefix+'.key-uri.bin']==b'memo:/selected/holder.pkl','actual declaration selected key URI')

            for e in session['events']:
                p=e['rawPrefix'];b=payloads[p+'.bin'];u=payloads[p+'.code-units.bin'];check(b.hex()==e['utf8Hex'] and u.hex()==e['utf16BEHex'],'raw/report actual ordered events');combined+=b+b'\n';events+=1;checks+=2
                if b.startswith(b'actual-') and b'-denied ' in b:cause_count+=1
        check(payloads[base+'stdout.bin']==combined,'complete process stdout is actual ordered session event stream')
        check(sha(payloads[base+'stdout.bin'])==record['stdoutSha256'] and sha(payloads[base+'stderr.bin'])==record['stderrSha256'],'reported process stream bytes')
    check(sum(counts.values())==report['evaluatorApiCalls'] and dict(counts)==report['evaluatorStatusCounts'],'exact API accounting')
    intent=['Actual custom resolveUri override is invoked for relative and absolute operands with URI-only primary; CachedModuleKey contents wrapper bypasses that delegate override. All48 actual APIs succeed; no prior212 or01-04 rerun.']
    write(root/'inventory.json',{'schema':1,'files':inventory})
    summary={'root':str(root),'reportSha256':sha((root/'report.json').read_bytes()),'inventorySha256':sha((root/'inventory.json').read_bytes()),'outerTerminalSha256':sha((root/'outer-terminal.json').read_bytes()),'actualToolHandle':tool,'toolTerminalExit':0,'actualDriverPid':terminal['pid'],'actualParentPid':terminal['parentPid'],'apiCalls':sum(counts.values()),'statuses':dict(counts),'orderedEvents':events,'rawTypedDenials':cause_count,'jvmProcesses':len(report['records']),'checks':checks,'files':len(inventory),'bytes':sum(r['bytes']for r in inventory.values()),'repeatDifferences':0,'inputChanges':0,'intentLedger':intent,'gc':'System.gc requests only; no actual GC completion proof','nativeCompatibilityClaim':False}
    summaries.append(summary)
write(O/'report.json',{'schema':1,'kind':'Independent readback of existing completed actual Java captures; no evaluation','captures':summaries,'newEvaluations':0,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
for summary in summaries:
    root=Path(summary['root']);write(root/'closure.json',{'sealed':True,'reportSha256':summary['reportSha256'],'inventorySha256':summary['inventorySha256'],'outerTerminalSha256':summary['outerTerminalSha256'],'auditRoot':str(O),'auditReportSha256':sha((O/'report.json').read_bytes()),'liveHandles':[]})
write(O/'handoff.json',{'schema':1,'auditReportSha256':sha((O/'report.json').read_bytes()),'captures':[{**s,'closureSha256':sha((Path(s['root'])/'closure.json').read_bytes())}for s in summaries],'scriptSha256':sha(Path(__file__).read_bytes()),'scope':'New Java controls only; no existing212 reexecution. Custom override actual arguments/results and wrapper default contrast; all prior observations unchanged.'})
print(json.dumps(json.loads((O/'handoff.json').read_bytes()),indent=2))
