# Stage49 추가 native 관찰 adapter 계약 제안

이 문서는 아직 구현된 CLI가 아니다. 원래 5-column MODULE_PLAN과 2-column operation은 유지한다. A는 기존212 supplied/public 비교용 build02를 먼저 봉인하고, 아래 additive profile을 별도 artifact로 구현한다. 예상 결과는 봉인된 Java report/raw에서만 읽는다.

## 설정 파일

MODULE_PLAN의 legacy 행은 기존대로 `requestedURI\tselectedURI\tresolvedURI\tabsoluteSourcePath\tcacheMode`이다. 새 tagged 설정은 별도 profile에서만 허용하며 plain URI/path 필드에는 tab/newline을 허용하지 않는다. source 본문은 파일에서 UTF-8로 사전 로드하고 factory 안에서 읽지 않는다.

| 행 | 정확한 필드 순서 |
| --- | --- |
| `KEY` | tag, requestedURI, selectedURI, resolvedURI, sourceId, cacheMode, fragmentPaths, sourceMode, keyKind |
| `SOURCE` | tag, sourceId, resultKind(`text` 또는 `io`), absolutePayloadPath 또는 JavaUTF16BEHexMessage |
| `PROFILE` | tag, profileId, sourceKind(`uri`, `contents`, `repl`), uri, sourceId 또는 빈 문자열 |
| `OVERRIDE` | tag, selectedDeclarationURI, authoredOperandURI, returnedAbsoluteURI |
| `CAPS` | tag, selectedURI, local, hierarchical, fragmentPaths (bool strings) |
| `ELEMENT` | tag, selectedURI, candidateURI, exists (bool string) |

`KEY.cacheMode`는 `true|false|dynamic`이고 항상 factory 생성 시 bool snapshot을 취한다. 나중 QueryCachePolicy getter에서 그 snapshot을 돌려준다. `fragmentPaths`는 실제 Java Plan 입력의 bool이다. `sourceMode`는 아래 세 가지다.

- `fixed`: KEY.sourceId의 사전 구성 source를 사용한다.
- `state-at-load`: 현재 SOURCE operation 상태를 LoadSource 시 조회한다. Java01–05의 `$state` PlannedKey가 이 계약이다. init/io/good 및 init1/init2 상태의 실제 입력을 보존한다.
- `state-at-factory`: 현재 SOURCE 상태의 source text를 factory가 key를 만들 때 snapshot한다. 실제 `ModuleKeys.synthetic(...sourceText,isCached)`를 반환하는 후속 Java06에 필요하다. 로드 시점의 다른 상태로 바꾸지 않는다.

`keyKind`는 `host|synthetic`이다. 실제 custom factory가 반환한 Synthetic와 내부 `repl:text` synthetic key를 URI 문자열만으로 합치지 않는다. supplied-text wrapper는 public API의 `contents` 인자로 공통 엔진이 만든다. Host가 wrapper key를 만들어 semantic 처리를 우회하지 않는다. Synthetic의 hierarchical/local 등 기본 getter 값은 원래 class의 source-derived metadata와 실제 관찰 가능 범위를 구분한다.

`SOURCE.resultKind=io`는 **source load**의 ModuleHostError::Io completion이다. factory `throwing:` IOException과 다른 phase이며 진단도 다르다. 현재 관찰의 메시지는 `stage49-source-io`이다. sourceId는 `good`, `io`, `init`, `init1`, `init2` 등 authored SOURCE 상태명과 연결한다. 정의되지 않은 상태는 명시적 acquisition failure이고 다른 source로 fallback하지 않는다.

## operation 파일

기존 `evaluate\tEXPRESSION_UTF8_HEX`, `cache\tVALUE_UTF8_HEX`, `policy\tVALUE_UTF8_HEX`, `gc\t`를 유지한다. 추가 행은 모두 2-column이며 payload를 먼저 Java 원문 UTF-8로 만들고 hex로 인코딩한다.

| kind | hex decode 후 payload |
| --- | --- |
| `source` | source state 이름 |
| `factory` | `custom` 또는 `builtin` |
| `evaluate-source` | `PROFILE_ID_UTF8_HEX:EXPRESSION_UTF8_HEX` (두 필드 자체가 hex이고 delimiter는 colon) |

`factory=builtin`은 custom registry만 비활성화한다. 기본 File/stdlib registry는 유지하며 Host URI/module cache는 추가하지 않는다. `evaluate-source`는 같은 public module evaluator에 PROFILE.uri 및 `None`/`Some(preloadedText)`를 넘긴다. URI-only는 None이고 contents/repl은 Some이다. operation의 원래 source ID가 서로 다른데 하나의 primary URI/text로 합치지 않는다.

`OVERRIDE`는 actual Java custom key의 `resolveUri(URI)` override 입력이다. key id/handle을 먼저 확인하고 일치하는 selectedDeclarationURI+raw authoredOperandURI일 때만 구성된 URI를 complete_import_uri로 반환한다. inherited default는 공통 Rust helper에 명시 위임한다. wrapper가 delegate override를 호출한 척하거나 Java event를 합성하지 않는다.

## 결과와 범위

기존 raw status/UTF16BE/JavaUTF8/API-index/counter 파일을 유지한다. 새 operation/selected key/resolved key/source snapshot의 실제 typed request 및 completion을 모두 기록한다. raw API gate, Java 예외 class/internal boundary, intended feature 도달 여부, 전체 event/counter gate를 분리한다. Java01의 query-local alias100건 및 invalid-fragment PklBugException8건을 raw에서 삭제하거나 보통 feature pass로 세지 않는다. 새 공통 API가 없어 실행할 수 없는 profile은 명시 미실행으로 남긴다.

`CAPS`/`ELEMENT`는 요청된07 triple-dot provider를 위한 additive 제안이다. actual provider의 set-membership 입력만 운반하고 URI 후보/검색 순서를 Host가 만들지 않는다. wrapper의 descriptor/delegate 경계와 fragment 기본값은 공통 엔진이 적용한다.07이 아직 봉인되지 않았다면 해당 입력은 manifest에 미취득으로 명시한다.
