from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent;B=O.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
def row(*f):
    assert all('\t'not in str(x)and'\n'not in str(x)for x in f)
    return '\t'.join(map(str,f))+'\n'
index=[]
for number in range(1,7):
    oracle=B/f'stage49-oracle-modulekey-{number:02d}'
    closure=json.loads((oracle/'closure.json').read_bytes());report=json.loads((oracle/'report.json').read_bytes());inventory=json.loads((oracle/'inventory.json').read_bytes())['files']
    assert closure['sealed']and closure['reportSha256']==sha(oracle/'report.json')and closure['inventorySha256']==sha(oracle/'inventory.json')
    assert not report['inputChanges']and report['workspacesUnchanged']and not any(r['rawPathDifferences']for r in report['repeatDifferences'])
    for case in json.loads((oracle/'cases.json').read_bytes()):
        work=Path(case['workspace']);out=O/'tables'/f'java{number:02d}'/case['id'];out.mkdir(parents=True)
        declared={}
        for rel in case['inputPaths']:
            p=work/rel;r=inventory[str(p.relative_to(oracle))];assert sha(p)==r['sha256'];declared[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
        source_rows=[]
        for rel in (work/'source-inputs.txt').read_text().splitlines():
            if not rel:continue
            source_rows.append(row('SOURCE',rel,'text',work/rel))
            if rel.startswith('state-')and rel.endswith('.pkl'):
                source_rows.append(row('SOURCE',rel[6:-4],'text',work/rel))
        if any(op['kind']=='source'and op.get('value')=='io'for op in case['operations']):
            failures=[oracle/rel for rel in inventory if rel.startswith(f"cases/{case['id']}/0/calls/session-0/")and rel.endswith('.failure.bin')]
            assert failures and all(p.read_bytes()==failures[0].read_bytes()for p in failures)
            message=failures[0].read_bytes().decode();source_rows.append(row('SOURCE','io','io',message.encode('utf-16-be').hex()))
        config=source_rows
        for line in (work/'module-plan.tsv').read_text().splitlines():
            f=line.split('\t');kind=f[6]if len(f)>6 else'host';mode='fixed'if f[3]!='$state'else'state-at-factory'if kind=='synthetic'else'state-at-load'
            config.append(row('KEY',f[0],f[1],f[2],f[3],f[4],f[5],mode,kind))
            config.append(row('CAPS',f[1],'true','false'if kind=='synthetic'else'true',f[5]))
        profiles={'main.pkl':{'kind':'uri','uri':case['sourceUri'],'source':''}}
        for line in (work/'source-profiles.tsv').read_text().splitlines():
            f=line.split('\t');profiles[f[0]]={'kind':f[1],'uri':f[2],'source':f[3]}
        for name,p in profiles.items():config.append(row('PROFILE',name,p['kind'],p['uri'],p['source']))
        if(work/'uri-overrides.tsv').is_file():
            for line in(work/'uri-overrides.tsv').read_text().splitlines():config.append(row('OVERRIDE',*line.split('\t')))
        operations=[]
        for op in case['operations']:
            if op['kind']=='evaluate':
                payload=op['source'].encode().hex()+':'+op['expression'].encode().hex();operations.append(row('evaluate-source',payload.encode().hex()))
            else:operations.append(row(op['kind'],op.get('value','').encode().hex()))
        (out/'config.tsv').write_text(''.join(config));(out/'operations.tsv').write_text(''.join(operations))
        provided=all(op['kind']!='evaluate'or op['source']=='main.pkl'for op in case['operations'])
        if provided:
            (out/'operations.provided.tsv').write_text(''.join(row(op['kind'],(op['expression']if op['kind']=='evaluate'else op.get('value','')).encode().hex())for op in case['operations']))
        index.append({'oracleRoot':str(oracle),'oracleReportSha256':sha(oracle/'report.json'),'oracleClosureSha256':sha(oracle/'closure.json'),'id':case['id'],'moduleSourceProfile':'public-explicit-per-operation','providedPrimaryEligible':provided,'initialPolicy':case['mode'],'initialSourceState':'good','mainSource':str(work/'main.pkl'),'mainUri':case['sourceUri'],'config':str(out/'config.tsv'),'operations':str(out/'operations.tsv'),'providedOperations':str(out/'operations.provided.tsv')if provided else None,'files':{str(p):sha(p)for p in out.iterdir()},'authoredSources':declared,'apiCalls':sum(len(obs['calls'])for obs in report['observations']if obs['case']==case['id']),'scope':case['scope']})
write(O/'index.json',{'schema':1,'kind':'Concrete additive Host configuration/operation tables from sealed Java inputs; no expectations or evaluator execution','cases':index,'acquiredApiCalls':sum(c['apiCalls']for c in index),'schemaSha256':sha(O/'SCHEMA.ko.md'),'pending':'Java07 wrapper triple-dot input and actual provider trace not acquired yet; no implied coverage.','scope':['Source data preloaded; no factory I/O or Host semantic cache.','SOURCE io raw cause uses actual captured loader failure input, not formatted expected Pkl diagnostic.','Java06 Synthetic constructor source snapshots are state-at-factory; internal getter callbacks were not observed.']})
print(json.dumps({'cases':len(index),'acquiredApis':sum(c['apiCalls']for c in index),'indexSha256':sha(O/'index.json')}))
