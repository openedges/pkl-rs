from pathlib import Path
import sys,concurrent.futures,json
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
inputs=[Path('target/m2/stage5-collection-types-java-01').resolve(),Path('target/m2/stage5-collection-types-java-02').resolve(),Path('target/m2/stage5-collection-types-java-03').resolve(),Path('target/m2/stage5-diagnostic-java-01').resolve()]
(out/'source-identities-before.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in lang.source_paths()}))
if len(sys.argv)>2:
 candidate=Path(sys.argv[2]).resolve()
else:
 row=lang.capture(['cargo','build','-p','pkl-runtime','--example','language_probe','--release','--locked'],out,'build',timeout=300);assert row['exit_code']==0
 candidate=contract.ROOT/'target/release/examples/language_probe'
frozen=out/'language_probe';frozen.write_bytes(candidate.read_bytes());frozen.chmod(0o755)
(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(candidate),sha256=oracle.sha256(frozen),binding='provisional-not-final-build')))
cases=[]
for source in inputs:
 for case in json.loads((source/'matrix.json').read_bytes()):cases.append((source,case))
def run(item):
 source,c=item;folder=out/'cases'/c['id'];folder.mkdir(parents=True)
 baseline=source/'cases'/c['id'];meta=json.loads((source/'oracle.json').read_bytes());j=json.loads((baseline/'java.process.json').read_bytes())
 c=dict(c)
 if c['expected_outcome']=='observation': c['expected_outcome']='success' if j['exit_code']==0 else 'failure'
 row=lang.capture([str(frozen),*lang.expression_arguments(baseline/'input.pkl',c['expression'],c.get('power_assertions',False))],folder,'rust',meta['environment'])
 status=lang.status(c,j,row,*[(baseline/f'java.{ch}.bin').read_bytes() for ch in ('stdout','stderr')],*[(folder/f'rust.{ch}.bin').read_bytes() for ch in ('stdout','stderr')],(baseline/'java.outcome.bin').read_bytes())
 return dict(id=c['id'],status=status,baseline=str(baseline),rust=row)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'results.json').write_bytes(contract.encoded(results))
(out/'source-identities-after.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in lang.source_paths()}))
from collections import Counter
print(dict(Counter(r['status'] for r in results)))
for r in results:
 if r['status']!='pass':
  j=Path(r['baseline'])/'java.stderr.bin';s=out/'cases'/r['id']/'rust.stderr.bin'
  print(r['id'],r['status'],repr(s.read_text()[:180]),flush=True)
