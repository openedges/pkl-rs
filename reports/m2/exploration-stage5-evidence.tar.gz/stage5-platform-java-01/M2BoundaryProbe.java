import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
import org.pkl.core.PklException;
public final class M2BoundaryProbe {
  public static void main(String[] args) throws Exception {
    try (var evaluator = EvaluatorBuilder.preconfigured().setModuleCacheDir(null)
        .setPowerAssertionsEnabled(Boolean.parseBoolean(args[2])).setColor(false)
        .setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      try {
        var module = ModuleSource.create(URI.create(args[1]), Files.readString(Path.of(args[0])));
        var result = evaluator.evaluateExpressionString(module, "result");
        System.out.write(result.getBytes(StandardCharsets.UTF_8));
      } catch (PklException error) {
        System.err.write(error.getMessage().getBytes(StandardCharsets.UTF_8));
        System.exit(1);
      }
    }
  }
}
