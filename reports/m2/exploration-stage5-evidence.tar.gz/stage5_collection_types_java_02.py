from pathlib import Path
import sys, concurrent.futures
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path('target/m2/stage5-collection-types-java-02').resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
compile=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert compile['exit_code']==0
cases=[]
def add(id,source,family='basic',expected='success',expr='result'):
 cases.append(dict(id=id,source=source+'\n',family=family,expected_outcome=expected,expression=expr))
add('listing-cache-steal-pass','source = new Listing { 42 }\nx: Listing<Int(this > 0)> = source\nresult = if (source[0] == 42) x[0] else 0','cache')
add('listing-cache-steal-fail','source = new Listing { 1 }\nx: Listing<Int(this > 10)> = source\nresult = if (source[0] == 1) x[0] else 0','cache','failure')
add('mapping-cache-steal-fail','source = new Mapping { ["k"] = 1 }\nx: Mapping<String, Int(this > 10)> = source\nresult = if (source["k"] == 1) x["k"] else 0','cache','failure')
add('listing-cache-amended-receiver','source = new Listing { this.length }\nx: Listing<Int(this > 0)> = source\ny = (x) { 42 }\nresult = if (source[0] == 1) x[0] * 10 + y[0] else 0','cache')
add('listing-cache-empty-amendment','source = new Listing { this.length }\nx: Listing<Int(this > 0)> = source\ny = (x) {}\nresult = if (source[0] == 1) y[0] else 0','cache')
add('listing-cache-owner','open class C { minimum = 0; values: Listing<Int(this > minimum)> = new Listing { 1 } }\nbase = new C {}\nchild = (base) { minimum = 2 }\nresult = if (base.values[0] == 1) child.values[0] else 0','cache','failure')
add('listing-samecast-dedupe','x = new Listing<Int> { "bad" }\ny: Listing<Int> = x\nresult = y[0]','dedupe','failure')
add('listing-samecast-alias','typealias Items = Listing<Int>\nx: Items = new Listing { "bad" }\ny: Listing<Int> = x\nresult = y[0]','dedupe','failure')
add('listing-recast-amendment','x: Listing<Int> = new Listing { 1 }\ny = (x) { "bad" }\nz: Listing<Int> = y\nresult = z[1]','dedupe','failure')
add('listing-sameconstraint-dedupe','x = new Listing<Int(this > 0)> { -1 }\ny: Listing<Int(this > 0)> = x\nresult = y[0]','dedupe','failure')
add('listing-any-no-wrapper','x: Listing<Int(this > 0)> = new Listing { -1 }\ny: Listing<Any> = x\nresult = y[0]','dedupe','failure')
add('mapping-samecast-dedupe','x = new Mapping<String, Int> { ["k"] = "bad" }\ny: Mapping<String, Int> = x\nresult = y["k"]','dedupe','failure')
add('mapping-key-parent-order','base = new Mapping { [1] = missing }\nchild = (base) { ["ok"] = 2 }\nx: Mapping<String, Int> = child\nresult = x.length','inherited-key','failure')
add('mapping-key-child-before-parent','base = new Mapping { [1] = missing }\nchild = (base) { [false] = missing }\nx: Mapping<String, Int> = child\nresult = x.length','inherited-key','failure')
add('mapping-key-overridden-header','base = new Mapping { [1] = missing }\nchild = (base) { [1] = 42 }\nx: Mapping<String, Int> = child\nresult = x.length','inherited-key','failure')
add('mapping-is-overridden-value','base = new Mapping { ["k"] = "bad" }\nchild = (base) { ["k"] = 42 }\nresult = child is Mapping<String, Int>','inherited-key')
add('listing-is-overridden-value','base = new Listing { "bad" }\nchild = (base) { [0] = 42 }\nresult = child is Listing<Int>','inherited-key')
add('listing-wrapper-property-cache','source = new Listing { 42 }\nx: Listing<Int> = source\nresult = if (source.length == 1) x.length else 0','cache')
add('listing-wrapper-local-cache','source = new Listing { local wrong = "bad"; wrong.length }\nx: Listing<Int> = source\nresult = x[0]','cache')
add('listing-stolen-inner-wrapper','source = new Listing { new Listing { "bad" } }\nx: Listing<Listing<Int>> = source\nresult = if (source[0].length == 1) x[0][0] else 0','cache','failure')
add('listing-default-value-referent','class C { x = 42 }\nx: Listing<C>\ny = (x) { new {} }\nresult = y[0].x','default')
add('mapping-default-value-referent','class C { x = 42 }\nx: Mapping<String, C>\ny = (x) { ["k"] {} }\nresult = y["k"].x','default')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/type/TypeNode.java','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmListing.java','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmMapping.java']
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 q=out/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 folder=out/'cases'/c['id'];folder.mkdir(parents=True);source=folder/'input.pkl';source.write_bytes(c['source'].encode())
 row=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],folder)
 return dict(id=c['id'],family=c['family'],expected_outcome=c['expected_outcome'],java=row,input_sha256=oracle.sha256(source),stdout=(folder/'java.stdout.bin').read_bytes().decode(),stderr=(folder/'java.stderr.bin').read_bytes().decode(),outcome=(folder/'java.outcome.bin').read_bytes().decode())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
for r in results:print(r['id'],r['java']['exit_code'],repr(r['stdout']),repr(r['stderr'][:110]),flush=True)
