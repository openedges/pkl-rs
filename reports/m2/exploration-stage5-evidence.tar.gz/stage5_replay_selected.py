from pathlib import Path
import sys,json,concurrent.futures
sys.path.insert(0,'tools');import m2_language as lang,m2_manifest as contract,oracle
baseline=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();candidate=Path(sys.argv[3]).resolve();out.mkdir(exist_ok=False)
frozen=out/'language_probe';frozen.write_bytes(candidate.read_bytes());frozen.chmod(0o755)
(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(candidate),sha256=oracle.sha256(frozen),binding='provisional frozen replay, see original build source identities')))
meta=json.loads((baseline/'oracle.json').read_bytes());cases=json.loads((baseline/'cases.json').read_bytes())
def run(c):
 b=baseline/'cases'/c['id'];folder=out/'cases'/c['id'];folder.mkdir(parents=True)
 j=json.loads((b/'java.process.json').read_bytes());source=contract.ROOT/c['input'];assert source.read_bytes()==(b/'input.pkl').read_bytes()
 r=lang.capture([str(frozen),*lang.expression_arguments(source,c['expression'],c.get('power_assertions',False))],folder,'rust',meta['environment'])
 status=lang.status(c,j,r,*[(b/f'java.{ch}.bin').read_bytes() for ch in ('stdout','stderr')],*[(folder/f'rust.{ch}.bin').read_bytes() for ch in ('stdout','stderr')],(b/'java.outcome.bin').read_bytes())
 return dict(id=c['id'],status=status,rust=r)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'results.json').write_bytes(contract.encoded(results))
from collections import Counter
print(dict(Counter(r['status'] for r in results)))
for r in results:
 if r['status']!='pass':print(r['id'],r['status'])
