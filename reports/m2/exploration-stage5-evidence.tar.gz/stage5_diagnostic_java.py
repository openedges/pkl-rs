from pathlib import Path
import sys, json, concurrent.futures
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out = Path('target/m2/stage5-diagnostic-java-01').resolve()
out.mkdir(exist_ok=False)
metadata = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts'; artifacts.mkdir(); classes=artifacts/'java'; classes.mkdir()
lang.capture([str(Path(metadata['java']).with_name('javac')), '-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment'])
cases=[]
def add(id, source, power=False):
    cases.append(dict(id=id,source=source+'\n',family='collection-type-diagnostics',expected_outcome='observation',expression='result',power_assertions=power))
for power in [False,True]:
    suffix='-power' if power else '-plain'
    add('wrapper-cached-parent-invalid'+suffix,'raw = new Listing { "bad" }\ntyped: Listing<Int> = raw\nresult: Int(typed.length > 10) = let (ignored = raw[0]) 42',power)
    add('wrapper-cached-parent-valid'+suffix,'raw = new Listing { 1; 2 }\ntyped: Listing<Int> = raw\nresult: Int(typed.length > 10) = let (ignored = raw[0]) 42',power)
    add('wrapper-constraint-value-cached'+suffix,'raw = new Listing { 1; 2 }\nresult: Listing<Int>(false) = let (ignored = raw[0]) raw',power)
    add('wrapper-constraint-invalid-cached'+suffix,'raw = new Listing { "bad"; 2 }\nresult: Listing<Int>(false) = let (ignored = raw[0]) raw',power)
    add('nested-list-wrapper-cached'+suffix,'raw = new Listing { 1; 2 }\nwrapped: List<Listing<Int>> = List(raw)\nresult: Int(wrapped.length > 10) = let (ignored = raw[0]) 42',power)
    add('mapping-wrapper-cached'+suffix,'raw = new Mapping { ["k"] = 1; ["v"] = 2 }\ntyped: Mapping<String,Int> = raw\nresult: Int(typed.length > 10) = let (ignored = raw["k"]) 42',power)
add('wrapper-noop-preserves-cache','raw = new Listing { 1; 2 }\nresult: Listing<Any>(false) = let (ignored = raw[0]) raw')
add('wrapper-alias-error','typealias Items<T> = Listing<T>\nraw = new Listing { "bad" }\ntyped: Items<Int> = raw\nresult = typed[0]',True)
add('wrapper-nested-error','typed: List<Listing<Int>> = List(new Listing { "bad" })\nresult = typed[0][0]',True)
(out/'matrix.json').write_bytes(contract.encoded(cases))
(out/'source-identities.json').write_bytes(contract.encoded({str(p):oracle.sha256(contract.ROOT/p) for p in ['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']}))
def run(case):
    folder=out/'cases'/case['id']; folder.mkdir(parents=True)
    source=folder/'input.pkl'; source.write_text(case['source'])
    row=lang.capture_java(metadata, artifacts/'language_probe',case['id'],source,case['expression'],folder,case.get('power_assertions',False))
    stdout=(folder/'java.stdout.bin').read_bytes(); stderr=(folder/'java.stderr.bin').read_bytes()
    return dict(id=case['id'],family=case['family'],expected_outcome=case['expected_outcome'],java=row,stdout=stdout.decode(),stderr=stderr.decode(),outcome=(folder/'java.outcome.bin').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
for row in results:
    print(row['id'], row['java']['exit_code'], repr(row['stdout']), repr(row['stderr'][:150]),flush=True)
