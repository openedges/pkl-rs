from pathlib import Path
import json,sys
sys.path.insert(0,'tools')
import m2_manifest as contract,oracle
selection=contract.ROOT/contract.SELECTION
original=json.loads(selection.read_bytes())
baseline=json.loads(Path('target/m2/stage5-selection-baseline-01/cases.json').read_bytes())
assert original==baseline
held={'listing-constraint-receiver':'Preexisting top-level outer-scope diagnostic gap; probe itself does not isolate generic collection behavior.','listing-wrapper-local-cache':'String.length is outside the bounded collection type scope.','listing-default-element':'Class-valued default referent and inferred member construction are deferred.','mapping-default-element':'Class-valued default referent and inferred member construction are deferred.','listing-default-value-referent':'Class-valued default referent and inferred member construction are deferred.','mapping-default-value-referent':'Class-valued default referent and inferred member construction are deferred.'}
additional=[];deferred=[]
for dirname in ['stage5-collection-types-java-01','stage5-collection-types-java-02','stage5-collection-types-java-03','stage5-diagnostic-java-01']:
 directory=Path('target/m2')/dirname
 for case in json.loads((directory/'matrix.json').read_bytes()):
  if case['id'] in held:
   deferred.append(dict(id=case['id'],source=str(directory/'cases'/case['id']/'input.pkl'),reason=held[case['id']]))
   continue
  id='collection-type-'+case['id'];file=Path('tests/fixtures/m2')/(id+'.pkl')
  requirements=['semantic:collections','semantic:types','semantic:generics','semantic:lazy-evaluation']
  family=case['family']
  if family in {'alias','dedupe'} or 'alias' in id: requirements.append('semantic:type-aliases')
  if family=='union':requirements.append('semantic:unions')
  if family in {'cast','is'}:requirements.append('semantic:type-tests-casts')
  if family=='function':requirements.append('semantic:functions')
  if family=='amendment' or 'amend' in id:requirements.append('semantic:amendment')
  if family in {'constraint','collection-type-diagnostics'} or 'constraint' in id:requirements.append('semantic:constraints')
  if family in {'identity','cache','inherited-key'}:requirements.append('semantic:name-resolution')
  process=json.loads((directory/'cases'/case['id']/'java.process.json').read_bytes())
  outcome='success' if process['exit_code']==0 else 'failure'
  if outcome=='failure':requirements.append('semantic:diagnostics')
  row=dict(id=id,input=str(file),expression=case['expression'],requirements=requirements,expected_outcome=outcome)
  if case.get('power_assertions'):row['power_assertions']=True
  additional.append((row,case['source'].encode(),dirname,case['id']))
assert len(additional)==129
if '--write' in sys.argv:
 for row,source,_,_ in additional:
  file=contract.ROOT/row['input'];assert not file.exists();file.write_bytes(source)
 original['cases'].extend(row for row,_,_,_ in additional)
 selection.write_bytes((json.dumps(original,ensure_ascii=False,indent=2)+'\n').encode())
meta=dict(selected_count=len(additional),held=deferred,provenance=[dict(id=row['id'],exploration='target/m2/'+dirname,exploratory_case_id=id,input_sha256=contract.digest(source)) for row,source,dirname,id in additional])
out=Path('target/m2/stage5-collection-type-promotion.json');assert not out.exists();out.write_bytes(contract.encoded(meta))
print('Promoted' if '--write' in sys.argv else 'Proposed',len(additional),'held',len(deferred))
