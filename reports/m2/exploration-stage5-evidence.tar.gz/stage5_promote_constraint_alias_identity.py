from pathlib import Path
import json,sys
sys.path.insert(0,'tools');import m2_manifest as contract
selection=contract.ROOT/contract.SELECTION;data=json.loads(selection.read_bytes());assert len(data['cases'])==553
source=Path('target/m2/stage5-collection-types-java-04/cases/constraint-alias-node-identity/input.pkl');id='collection-type-constraint-alias-node-identity';target=Path('tests/fixtures/m2')/(id+'.pkl');assert not target.exists();target.write_bytes(source.read_bytes())
data['cases'].append(dict(id=id,input=str(target),expression='result',requirements=['semantic:collections','semantic:types','semantic:generics','semantic:type-aliases','semantic:constraints','semantic:diagnostics'],expected_outcome='failure'))
selection.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
Path('target/m2/stage5-collection-type-promotion-04.json').write_bytes(contract.encoded(dict(selected_count=1,origin=str(source),input_sha256=contract.digest(source.read_bytes()),scope='Different inlined generic constraint arguments must not be deduplicated based only on shared declaration spans.')))
print('Promoted generic constraint alias node-identity counterexample; selected',len(data['cases']))
