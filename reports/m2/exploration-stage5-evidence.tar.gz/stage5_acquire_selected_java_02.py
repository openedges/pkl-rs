from pathlib import Path
import sys,json,concurrent.futures
sys.path.insert(0,'tools');import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
metadata=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts';artifacts.mkdir();classes=artifacts/'java';classes.mkdir()
r=lang.capture([str(Path(metadata['java']).with_name('javac')),'-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment']);assert r['exit_code']==0
selection=json.loads((contract.ROOT/contract.SELECTION).read_bytes());cases=selection['cases'][int(sys.argv[2]) if len(sys.argv)>2 else 415:]
(out/'cases.json').write_bytes(contract.encoded(cases));(out/'manifest.json').write_bytes(contract.encoded(contract.current_manifest()))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py',str(contract.SELECTION)]
(out/'source-identities.json').write_bytes(contract.encoded({str(p):oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 q=out/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((contract.ROOT/p).read_bytes())
def run(case):
 folder=out/'cases'/case['id'];folder.mkdir(parents=True)
 source=contract.ROOT/case['input'];(folder/'input.pkl').write_bytes(source.read_bytes())
 java=lang.capture_java(metadata,artifacts/'language_probe',case['id'],source,case['expression'],folder,case.get('power_assertions',False))
 expected=0 if case['expected_outcome']=='success' else 1
 outcome=(folder/'java.outcome.bin').read_bytes()
 assert not java['timed_out'] and java['exit_code']==expected,(case['id'],java)
 assert outcome==b'success\n' if expected==0 else lang.valid_exception_outcome(outcome),(case['id'],outcome)
 return dict(id=case['id'],java=java,input_sha256=oracle.sha256(source))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'results.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
print('Captured pinned Java at actual fixture URIs:',len(results))
