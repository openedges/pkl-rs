from pathlib import Path
import json,sys
sys.path.insert(0,'tools');import m2_manifest as contract
selection=contract.ROOT/contract.SELECTION;data=json.loads(selection.read_bytes());assert len(data['cases'])==544
items=[
 ('union-direct-single','collection-types-union-alias-stage5/direct','success',['semantic:unions']),
 ('union-plain-alias-single','collection-types-union-alias-stage5/plain-alias','success',['semantic:unions','semantic:type-aliases']),
 ('union-generic-alias-eager','collection-types-union-alias-stage5/generic-alias','failure',['semantic:unions','semantic:type-aliases','semantic:diagnostics']),
 ('cast-same-site-different-receiver','collection-types-cast-identity-stage5/same-site-different-receiver','success',['semantic:functions','semantic:constraints','semantic:name-resolution']),
 ('cast-different-sites','collection-types-cast-identity-stage5/different-site-same-text','failure',['semantic:functions','semantic:constraints','semantic:name-resolution','semantic:diagnostics']),
]
provenance=[]
for name,origin,outcome,requirements in items:
 id='collection-type-'+name;source=Path('target/m2')/origin/'input.pkl';target=Path('tests/fixtures/m2')/(id+'.pkl');assert not target.exists();target.write_bytes(source.read_bytes())
 data['cases'].append(dict(id=id,input=str(target),expression='result',requirements=['semantic:collections','semantic:types','semantic:generics','semantic:lazy-evaluation',*requirements],expected_outcome=outcome))
 provenance.append(dict(id=id,origin=str(source),input_sha256=contract.digest(source.read_bytes())))
selection.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
Path('target/m2/stage5-collection-type-promotion-02.json').write_bytes(contract.encoded(dict(selected_count=5,provenance=provenance,limitations='Original frontend Java captures used the pinned JVM without the M2 outcome sidecar and used exploratory source URIs. Separate fresh Java capture at actual selected fixture URIs binds success or caught error outcome and bytes.')))
print('Promoted5 frontend probes, selected',len(data['cases']))
