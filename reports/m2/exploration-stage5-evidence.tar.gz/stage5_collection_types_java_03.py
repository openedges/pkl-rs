from pathlib import Path
import sys, concurrent.futures
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path('target/m2/stage5-collection-types-java-03').resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
compile=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert compile['exit_code']==0
cases=[]
def add(id,source,family='basic',expected='success',expr='result'):
 cases.append(dict(id=id,source=source+'\n',family=family,expected_outcome=expected,expression=expr))
add('listing-return-force','function make(): Listing<Int> = new Listing { "bad" }\nresult = make()[0]','function','failure')
add('mapping-return-force','function make(): Mapping<String, Int> = new Mapping { ["k"] = "bad" }\nresult = make()["k"]','function','failure')
add('listing-arg-return-force','function use(x: Listing<Int>): Listing<Int> = x\nresult = use(new Listing { "bad" })[0]','function','failure')
add('listing-lambda-return-lazy','f = (x: Listing<Int>) -> x\nresult = f.apply(new Listing { "bad" }).length','function')
add('listing-lambda-return-force','f = (x: Listing<Int>) -> x\nresult = f.apply(new Listing { "bad" })[0]','function','failure')
add('listing-method-local-cast','function check() = let (x = new Listing { 1 }) (x as Listing<Int(this > 0)>)[0]\nresult = check()','function')
add('listing-nothing-empty','x: Listing<nothing> = new Listing {}\nresult = x.length','type')
add('listing-nothing-bad','x: Listing<nothing> = new Listing { 1 }\nresult = x[0]','type','failure')
add('listing-nullable','x: Listing<Int?> = new Listing { null; 42 }\nresult = x[0] == null && x[1] == 42','type')
add('listing-nullability-before-wrapper','x: Listing<Int>? = null\nresult = x == null','type')
add('listing-as-noncollection','x = 42 as Listing<Int>\nresult = x.length','cast','failure')
add('listing-is-noncollection','result = 42 is Listing<Int>','is')
add('listing-is-first-mismatch','x = new Listing { "bad"; missing }\nresult = x is Listing<Int>','is')
add('listing-is-first-runtime','x = new Listing { missing; "bad" }\nresult = x is Listing<Int>','is','failure')
add('mapping-is-key-before-value','x = new Mapping { [1] = missing }\nresult = x is Mapping<String, Int>','is')
add('mapping-is-value-before-later-key','x = new Mapping { ["k"] = missing; [1] = 2 }\nresult = x is Mapping<String, Int>','is','failure')
add('listing-union-nested-one-lazy','x: Listing<Listing<Int>>|String = new Listing { new Listing { "bad" } }\nresult = x[0].length','union')
add('listing-union-nested-two-eager','x: Listing<Listing<Int>>|Listing<Listing<String>> = new Listing { new Listing { 1; "bad" } }\nresult = x.length','union','failure')
add('listing-constrained-outer-eager','x: Listing<Int>(this[0] > 0) = new Listing { 1; "bad" }\nresult = x.length','constraint')
add('listing-constrained-inner-alias','typealias Positive = Int(this > 0)\ntypealias Items<T> = Listing<T>\nx: Items<Positive> = new Listing { -1 }\nresult = x[0]','alias','failure')
add('listing-alias-default','typealias Items<T> = Listing<T>\nx: Items<Int>\nresult = x.length','default')
add('list-alias-element-default','typealias Items<T> = List<T>\nx: Items<Int>\nresult = x.length','default')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','external/pkl/pkl-core/src/main/java/org/pkl/core/ast/type/TypeNode.java','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmListing.java','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmMapping.java']
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 q=out/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 folder=out/'cases'/c['id'];folder.mkdir(parents=True);source=folder/'input.pkl';source.write_bytes(c['source'].encode())
 row=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],folder)
 return dict(id=c['id'],family=c['family'],expected_outcome=c['expected_outcome'],java=row,input_sha256=oracle.sha256(source),stdout=(folder/'java.stdout.bin').read_bytes().decode(),stderr=(folder/'java.stderr.bin').read_bytes().decode(),outcome=(folder/'java.outcome.bin').read_bytes().decode())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
for r in results:print(r['id'],r['java']['exit_code'],repr(r['stdout']),repr(r['stderr'][:110]),flush=True)
