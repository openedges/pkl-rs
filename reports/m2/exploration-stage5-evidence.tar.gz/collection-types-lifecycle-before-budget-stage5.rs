//! Wrapper continuation roots and Host lifecycle, separate from Java resource semantics.
use std::sync::Arc;

use pkl_runtime::host::{HostPoll, HostSession};
use pkl_runtime::parser::parse_module;
use pkl_runtime::resolver::resolve_module;
use pkl_runtime::value::{ErrorKind, RuntimeError, Value};
use pkl_runtime::vm::{Instruction as I, compile_module};

fn session() -> (HostSession, Value, usize, usize) {
    // Each method returns a wrapper that outlives its checking frame. Its
    // temporary class receiver supplies the predicate's lexical properties.
    // The nested List additionally has to retain the newly wrapped element.
    let parsed = parse_module(
        r#"
        class Check {
          text = "unset"
          uri = "unset"
          function listing(): Listing<String(read(uri) == text && this == text)> =
            new Listing { text }
          function mapping(): List<Mapping<String, String(read(uri) == text && this == text)>> =
            List(new Mapping { ["key"] = text })
        }
        outerResult = new Check { text = "outer"; uri = "mem:outer" }.listing()[0]
        innerResult = new Check { text = "inner"; uri = "mem:inner" }.mapping()[0]["key"]
        "#,
    )
    .unwrap();
    let mut program = (*compile_module(&resolve_module(&parsed).unwrap()).unwrap()).clone();
    let module_entry = program.entry;
    let mut entries = Vec::new();
    for member in ["outerResult", "innerResult"] {
        entries.push(program.blocks.len());
        program.blocks.push(vec![
            I::Input(0),
            I::GetMember(Arc::from(member)),
            I::Return,
        ]);
    }
    let mut session = HostSession::new(Arc::new(program));
    session.start(module_entry, vec![], 0, None).unwrap();
    let root = ready(&mut session, 0).unwrap();
    (session, root, entries[0], entries[1])
}

fn next_event(session: &mut HostSession, now: u64) -> HostPoll {
    loop {
        match session.poll(now, 2) {
            HostPoll::Yielded => {
                session.collect(&[]);
            }
            event => return event,
        }
    }
}

fn request(session: &mut HostSession, now: u64, expected_uri: &str) -> String {
    match next_event(session, now) {
        HostPoll::Read { token, uri } => {
            assert_eq!(&*uri, expected_uri);
            token
        }
        event => panic!("expected {expected_uri}, got {event:?}"),
    }
}

fn ready(session: &mut HostSession, now: u64) -> Result<Value, RuntimeError> {
    match next_event(session, now) {
        HostPoll::Ready(result) => result,
        event => panic!("expected completed context, got {event:?}"),
    }
}

#[test]
fn nested_wrappers_keep_temporary_check_receivers_across_gc_and_reentry() {
    let (mut session, root, outer_entry, inner_entry) = session();
    session
        .start(outer_entry, vec![root.clone()], 1, None)
        .unwrap();
    let outer = request(&mut session, 1, "mem:outer");
    assert!(session.collect(&[]).live > 0);
    session
        .reenter(&outer, inner_entry, vec![root], 2, None)
        .unwrap();
    let inner = request(&mut session, 2, "mem:inner");
    assert!(session.collect(&[]).live > 0);
    session
        .resume(&inner, Ok(Value::string("inner")), 3)
        .unwrap();
    assert_eq!(ready(&mut session, 3), Ok(Value::string("inner")));
    assert_eq!(session.context_depth(), 1);
    assert_eq!(request(&mut session, 3, "mem:outer"), outer);
    session.collect(&[]);
    session
        .resume(&outer, Ok(Value::string("outer")), 4)
        .unwrap();
    assert_eq!(ready(&mut session, 4), Ok(Value::string("outer")));
    assert_eq!(session.context_depth(), 0);
    assert_eq!(session.collect(&[]).live, 0);
    assert!(session.drain_cancelled_reads().is_empty());
}

#[test]
fn failed_wrapper_predicate_retries_without_publishing_a_successful_member() {
    let (mut session, root, outer_entry, inner_entry) = session();
    session
        .start(outer_entry, vec![root.clone()], 1, None)
        .unwrap();
    let outer = request(&mut session, 1, "mem:outer");
    session
        .reenter(&outer, inner_entry, vec![root.clone()], 2, None)
        .unwrap();
    let failed = request(&mut session, 2, "mem:inner");
    let original = RuntimeError::new(ErrorKind::Host, "wrapper read failure\0\r\n🙂");
    session.resume(&failed, Err(original.clone()), 2).unwrap();
    let error = ready(&mut session, 2).unwrap_err();
    assert_eq!(
        (error.kind, error.message),
        (original.kind, original.message)
    );
    assert_eq!(request(&mut session, 2, "mem:outer"), outer);
    session.collect(&[]);
    session
        .reenter(&outer, inner_entry, vec![root], 3, None)
        .unwrap();
    let retried = request(&mut session, 3, "mem:inner");
    assert_ne!(retried, failed);
    assert_eq!(
        session
            .resume(&failed, Ok(Value::Null), 3)
            .unwrap_err()
            .kind,
        ErrorKind::Host
    );
    session
        .resume(&retried, Ok(Value::string("inner")), 3)
        .unwrap();
    assert_eq!(ready(&mut session, 3), Ok(Value::string("inner")));
    session
        .resume(&outer, Ok(Value::string("outer")), 4)
        .unwrap();
    assert_eq!(ready(&mut session, 4), Ok(Value::string("outer")));
    assert_eq!(session.collect(&[]).live, 0);
}

#[derive(Clone, Copy, Debug)]
enum Termination {
    Close,
    Cancel,
    AncestorTimeout,
    ChildTimeoutOnResume,
}

#[test]
fn terminal_reentry_releases_wrapper_checks_and_cancels_both_pending_reads() {
    for termination in [
        Termination::Close,
        Termination::Cancel,
        Termination::AncestorTimeout,
        Termination::ChildTimeoutOnResume,
    ] {
        let (mut session, root, outer_entry, inner_entry) = session();
        let deadline = matches!(termination, Termination::AncestorTimeout).then_some(9);
        session
            .start(outer_entry, vec![root.clone()], 1, deadline)
            .unwrap();
        let outer = request(&mut session, 1, "mem:outer");
        let child_deadline = matches!(termination, Termination::ChildTimeoutOnResume).then_some(5);
        session
            .reenter(&outer, inner_entry, vec![root.clone()], 2, child_deadline)
            .unwrap();
        let inner = request(&mut session, 2, "mem:inner");
        assert_eq!(session.context_depth(), 2);
        assert!(session.collect(&[]).live > 0);
        let (now, kind) = match termination {
            Termination::Close => {
                session.close();
                (3, ErrorKind::Closed)
            }
            Termination::Cancel => {
                session.cancel();
                (3, ErrorKind::Cancelled)
            }
            Termination::AncestorTimeout => (10, ErrorKind::Timeout),
            Termination::ChildTimeoutOnResume => {
                assert_eq!(
                    session
                        .resume(&inner, Ok(Value::string("late")), 7)
                        .unwrap_err()
                        .kind,
                    ErrorKind::Timeout
                );
                (7, ErrorKind::Timeout)
            }
        };
        let error = ready(&mut session, now).unwrap_err();
        assert_eq!(error.kind, kind, "{termination:?}");
        assert!(session.is_closed());
        assert_eq!(session.context_depth(), 0);
        assert_eq!(session.heap_stats().live, 0);
        assert_eq!(session.heap_stats().slots, 0);
        assert_eq!(
            session.drain_cancelled_reads(),
            [outer.clone(), inner.clone()]
        );
        for token in [&outer, &inner] {
            assert_eq!(
                session
                    .resume(token, Ok(Value::Null), now + 1)
                    .unwrap_err()
                    .kind,
                ErrorKind::Closed
            );
        }
        assert_eq!(
            session
                .start(outer_entry, vec![root], now + 1, None)
                .unwrap_err()
                .kind,
            ErrorKind::Closed
        );
        session.close();
        session.cancel();
        assert_eq!(ready(&mut session, now + 1).unwrap_err(), error);
        assert!(session.drain_cancelled_reads().is_empty());
    }
}
