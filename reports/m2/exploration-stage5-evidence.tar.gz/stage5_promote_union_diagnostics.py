from pathlib import Path
import json,sys
sys.path.insert(0,'tools');import m2_manifest as contract
selection=contract.ROOT/contract.SELECTION;data=json.loads(selection.read_bytes());assert len(data['cases'])==554
origin=Path('target/m2/stage5-union-java-01');cases=json.loads((origin/'matrix.json').read_bytes());assert len(cases)==6
provenance=[]
for c in cases:
 process=json.loads((origin/'cases'/c['id']/'java.process.json').read_bytes());assert process['exit_code']==1
 id='collection-type-'+c['id'];target=Path('tests/fixtures/m2')/(id+'.pkl');assert not target.exists();target.write_bytes(c['source'].encode())
 requirements=['semantic:types','semantic:unions','semantic:diagnostics']
 if 'typealias' in c['source']:requirements.append('semantic:type-aliases')
 if 'Listing<' in c['source']:requirements.extend(['semantic:collections','semantic:generics','semantic:lazy-evaluation'])
 if 'this >' in c['source']:requirements.append('semantic:constraints')
 data['cases'].append(dict(id=id,input=str(target),expression=c['expression'],requirements=requirements,expected_outcome='failure'))
 provenance.append(dict(id=id,origin=str(origin/'cases'/c['id']/'input.pkl'),input_sha256=contract.digest(target.read_bytes())))
selection.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())
Path('target/m2/stage5-collection-type-promotion-05.json').write_bytes(contract.encoded(dict(selected_count=6,provenance=provenance,scope='Union branch diagnostic labels retain authored alias and generic argument display names. Root exploratory Java/Rust raw comparison has six passes.')))
print('Promoted six union diagnostic probes; selected',len(data['cases']))
