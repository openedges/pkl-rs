from pathlib import Path
import json,sys
sys.path.insert(0,'tools');import m2_manifest as contract
p=contract.ROOT/contract.SELECTION;data=json.loads(p.read_bytes());assert len(data['cases'])==549
wanted={'listing-default-element','mapping-default-element','listing-default-value-referent','mapping-default-value-referent'};provenance=[]
for dirname in ['stage5-collection-types-java-01','stage5-collection-types-java-02']:
 directory=Path('target/m2')/dirname
 for c in json.loads((directory/'matrix.json').read_bytes()):
  if c['id'] not in wanted:continue
  id='collection-type-'+c['id'];f=Path('tests/fixtures/m2')/(id+'.pkl');assert not f.exists();f.write_bytes(c['source'].encode())
  data['cases'].append(dict(id=id,input=str(f),expression=c['expression'],requirements=['semantic:collections','semantic:types','semantic:generics','semantic:classes','semantic:amendment'],expected_outcome='success'))
  provenance.append(dict(id=id,origin=str(directory/'cases'/c['id']/'input.pkl'),input_sha256=contract.digest(f.read_bytes())))
assert len(provenance)==4
p.write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode());Path('target/m2/stage5-collection-type-promotion-03.json').write_bytes(contract.encoded(dict(selected_count=4,provenance=provenance,scope='Class-valued and inherited collection type defaults; custom default functions remain unimplemented.')))
print('Promoted four default referent probes; selected',len(data['cases']))
