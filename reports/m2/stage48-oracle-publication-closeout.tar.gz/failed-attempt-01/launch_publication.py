from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).parent.resolve();row={'command':[sys.executable,'-B',str(O/'publish.py')],'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourcePins':{n:hashlib.sha256((O/n).read_bytes()).hexdigest()for n in ['publish.py','select.py','selection.json','groups.json','references.json']},'environment':{'PYTHONDONTWRITEBYTECODE':'1'}}
with(O/'publisher.stdout.bin').open('wb')as out,(O/'publisher.stderr.bin').open('wb')as err:
 p=subprocess.Popen(row['command'],cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=p.pid;(O/'publisher-launch.json').write_text(json.dumps(row,indent=2)+'\n');row['exitCode']=p.wait()
row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=hashlib.sha256((O/'publisher.stdout.bin').read_bytes()).hexdigest(),stderrSha256=hashlib.sha256((O/'publisher.stderr.bin').read_bytes()).hexdigest(),liveHandles=[]);(O/'publisher-terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2));raise SystemExit(row['exitCode'])
