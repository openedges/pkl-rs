from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,subprocess,sys,tarfile
O=Path(__file__).parent.resolve();R=O.parents[2];sha=lambda b:hashlib.sha256(b).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
selection=json.loads((O/'selection.json').read_bytes());groups=json.loads((O/'groups.json').read_bytes());references=json.loads((O/'references.json').read_bytes());tool=O/'tool-sources/evidence.py';tool.parent.mkdir();shutil.copyfile(R/'tools/evidence.py',tool);assert tool.read_bytes()==(R/'tools/evidence.py').read_bytes();tool_sha=sha(tool.read_bytes());commands=[];receipts=[]
def original(row):
 p=Path(row['source']);s=p.lstat();assert stat.S_IMODE(s.st_mode)==row['mode'],str(p)
 if row['kind']=='symlink':
  assert stat.S_ISLNK(s.st_mode)and os.readlink(p)==row['linkTarget'];data=os.fsencode(os.readlink(p));assert sha(p.read_bytes())==row['targetPayloadSha256']
 else:assert stat.S_ISREG(s.st_mode);data=p.read_bytes()
 assert sha(data)==row['sha256']and len(data)==row['bytes'],str(p);return data

def run(label,cmd):
 d=O/'commands'/label;d.mkdir(parents=True);row={'command':cmd,'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'PYTHONDONTWRITEBYTECODE':'1'}}
 with(d/'stdout.bin').open('wb')as out,(d/'stderr.bin').open('wb')as err:
  p=subprocess.Popen(cmd,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=p.pid;write(d/'launch.json',row);row['exitCode']=p.wait()
 row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha((d/'stdout.bin').read_bytes()),stderrSha256=sha((d/'stderr.bin').read_bytes()));write(d/'terminal.json',row);commands.append(row);assert row['exitCode']==0,label

filenames={'java-controls':'stage48-java-admission-controls.tar.gz','tooling-history':'stage48-admission-tooling-history.tar.gz','native-c01':'stage48-admission-native-c01.tar.gz','portable-c01':'stage48-admission-portable-c01.tar.gz'}
for group,meta in groups.items():
 clean=O/'gathered'/group;clean.mkdir(parents=True);selected=[r for r in selection['files']if r['group']==group]
 for row in selected:
  data=original(row);p=clean/row['member'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);assert sha(p.read_bytes())==row['sha256']
 capture={'schema':1,'group':group,'selectionSha256':sha((O/'selection.json').read_bytes()),'roots':[r for r in selection['roots']if r['group']==group],'files':selected,'prewalkPrune':selection['prewalkPrune'],'qualification':'All source records preserved as bytes; archive-normalized regular modes are not original source modes. One original symlink is safe regular link-target bytes plus full metadata.'};write(clean/'CAPTURE_SELECTION.json',capture);write(clean/'EXTERNAL_REFERENCES.json',references);write(clean/'GROUP_SCOPE.json',{'group':group,'rawSelection':meta,'sourceEvidenceStates':'Original closure absence, original invalid self-output seal and intent-not-reached records remain explicit in CAPTURE_SELECTION.','scope':'Raw Java observations, native440 and portable84perTarget are distinct from strict full lifecycle failures and 212unexecuted SPI APIs; no fullM2completion.'})
 archive=O/'archives'/filenames[group];run(group+'-create',[sys.executable,'-B',str(tool),'create',str(clean),str(archive)]);run(group+'-verify',[sys.executable,'-B',str(tool),'verify',str(archive)]);assert archive.stat().st_size<100*1024*1024
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();lookup={m.name:m for m in members};assert len(lookup)==len(members)and all(m.isfile()and not Path(m.name).is_absolute()and'..'not in Path(m.name).parts for m in members);inventory=json.load(tar.extractfile(lookup['EVIDENCE.json']));assert {r['path']for r in inventory['files']}==set(lookup)-{'EVIDENCE.json'}
  restored=O/'restored'/group;restored.mkdir(parents=True)
  for record in inventory['files']:
   name=record['path'];data=tar.extractfile(lookup[name]).read();assert sha(data)==record['sha256']and len(data)==record['bytes'];assert data==(clean/name).read_bytes();p=restored/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  source_members=0
  for row in selected:
   data=tar.extractfile(lookup[row['member']]).read();assert data==original(row);source_members+=1
  assert json.load(tar.extractfile(lookup['CAPTURE_SELECTION.json']))==capture
 receipt={'group':group,'archive':str(archive),'fileName':archive.name,'compressedBytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'payloadFiles':len(inventory['files']),'selectedSourceFiles':len(selected),'selectedRawBytes':sum(x['bytes']for x in selected),'regularArchiveMembersIncludingEvidence':len(members),'everyRawMemberReadBack':True,'everyGatheredAndOriginalSourceByteEqual':True,'restoredPayloadFiles':len(inventory['files']),'below100MiB':True};receipts.append(receipt);write(O/'progress.json',{'completedGroups':len(receipts),'lastGroup':group,'receipt':receipt});print(json.dumps(receipt),flush=True)
changes=[]
for row in selection['files']:
 try:original(row)
 except Exception as error:changes.append({'path':row['source'],'error':str(error)})
assert not changes
index={'schema':1,'archives':receipts,'selectionSha256':sha((O/'selection.json').read_bytes()),'referencesSha256':sha((O/'references.json').read_bytes()),'evidenceToolSha256':tool_sha,'sourceRoots':len(selection['roots']),'sourceFiles':len(selection['files']),'sourceRawBytes':selection['rawBytes'],'symlinkRepresentations':selection['symlinks'],'originalChanges':changes,'rawEvidenceScope':'Java568Evaluator+392directSecurityManagerAPI;native440rawpass/212unexecuted/fullLifecycle0of52;portableNode84/browser84rawpass/fullLifecycle0of12each. Intentfailure16+36 and earlier tool/seal failures preserved.','allCreateAndSeparateVerifyCommands0':True};write(O/'index-data.json',index);write(O/'report-data.json',{'startedSourceSelectionSha256':sha((O/'selection.json').read_bytes()),'archives':len(receipts),'compressedBytes':sum(r['compressedBytes']for r in receipts),'allCommands0':all(c['exitCode']==0 for c in commands),'commands':commands,'originalChanges':changes,'noEvaluatorOrGitExecuted':True,'liveHandles':[]});print(json.dumps({'archives':len(receipts),'compressedBytes':sum(r['compressedBytes']for r in receipts),'originalChanges':changes},indent=2))
