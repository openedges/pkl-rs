from pathlib import Path
import collections,hashlib,json,os,stat
O=Path(__file__).parent.resolve();B=O.parent;R=O.parents[2];sha=lambda b:hashlib.sha256(b).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
ROOTS=[
 ('policy-tools','stage48-policy84-tools-01','tooling-history','own'),
 ('java01','stage48-module-admission-oracle-01','java-controls','own'),('java02','stage48-module-admission-oracle-02','java-controls','own'),
 ('java-audit01','stage48-module-admission-audit-01','java-controls','direct'),('java-audit02','stage48-module-admission-audit-02','java-controls','direct'),
 ('native-tools01','stage48-policy-native-consumer-01','tooling-history','consumer-authority'),('native-tools01-audit','stage48-policy-native-consumer-audit-01','tooling-history','own'),
 ('native-tools02','stage48-policy-native-consumer-02','tooling-history','own'),('installed-review','stage48-policy84-installed-review-01','tooling-history','own'),
 ('native01','stage48-policy-native-c01-01','native-c01','native-authority'),('native-launch','stage48-policy-native-c01-launch-01','native-c01','native-launch-authority'),('native-preflight','stage48-policy-native-c01-preflight-01','native-c01','direct'),('native-audit','stage48-policy-native-c01-audit-01','native-c01','own'),
 ('portable-tools01','stage48-policy-portable-proposal-01','portable-c01','own'),('portable-tools02','stage48-policy-portable-proposal-02','portable-c01','own'),('portable01','stage48-policy-portable-c01-01','portable-c01','portable-authority'),('portable-launch','stage48-policy-portable-c01-01.launch','portable-c01','portable-launch-authority'),('portable-audit','stage48-policy-portable-c01-audit-01','portable-c01','own')]
PRUNE=[B/'stage48-policy84-tools-01/__pycache__',B/'stage48-policy-native-consumer-01/tests-private',B/'stage48-policy-native-consumer-02/tests-private']
pruned=[]
for p in PRUNE:
 entry={'path':str(p),'role':'Generated Python bytecode cache, not sealed evidence'if p.name=='__pycache__'else'Cleaned temporary fixture/stub-source clones; explicit producer exclusion','walked':False,'exists':p.exists()}
 if p.exists():s=p.lstat();entry.update(kind='directory'if stat.S_ISDIR(s.st_mode)else'other',mode=stat.S_IMODE(s.st_mode),mtimeNs=s.st_mtime_ns)
 pruned.append(entry)
rows=[];root_records=[];unlisted=[]
def load(path):return json.loads(path.read_bytes())
def own(root):
 inv=load(root/'inventory.json');raw=inv['files'];result={x['path']:x for x in raw}if isinstance(raw,list)else dict(raw);return result,set(inv.get('directories',[]))|set(inv.get('emptyDirectories',[]))
def external(path):
 inv=load(path);raw=inv['files'];return ({x['path']:x for x in raw}if isinstance(raw,list)else dict(raw)),set(inv.get('directories',[]))
for id,name,group,kind in ROOTS:
 root=B/name;assert root.is_dir();closure=load(root/'closure.json')if(root/'closure.json').is_file()else None;record={'id':id,'root':str(root),'group':group,'selector':kind,'originalClosurePresent':closure is not None,'originalClosureSha256':sha((root/'closure.json').read_bytes())if closure else None,'originalSealQualification':None,'selectionAuthority':None}
 if kind=='own':
  expected,extra_dirs=own(root);record['selectionAuthority']={'path':str(root/'inventory.json'),'sha256':sha((root/'inventory.json').read_bytes())}
  if closure:assert closure.get('inventorySha256')==record['selectionAuthority']['sha256']
  for n in ['inventory.json','closure.json']:
   if(root/n).is_file():expected[n]={'sha256':sha((root/n).read_bytes()),'bytes':(root/n).stat().st_size}
 elif kind=='consumer-authority':
  path=B/'stage48-policy-native-consumer-audit-01/source-payload-inventory.json';expected,extra_dirs=external(path);h=load(B/'stage48-policy-native-consumer-audit-01/handoff.json');assert sha(path.read_bytes())==h['sourcePayloadInventorySha256'];record['selectionAuthority']={'path':str(path),'sha256':sha(path.read_bytes()),'handoffSha256':'be0ad70f4f9a3a4e0835dbe1763a6dd45e7142f074b48d2c1905efad8ef9f9ba'};record['originalSealQualification']='Initial seal invalid after redirected seal.stdout grew; exact failed seal/data preserved, later readback inventory is authoritative.'
 elif kind in ['native-authority','native-launch-authority','portable-authority','portable-launch-authority']:
  prefix='native'if kind.startswith('native')else'portable';audit=B/f'stage48-policy-{prefix}-c01-audit-01';file=('launcher'if'launch'in kind else prefix)+'-payload-inventory.json';path=audit/file;expected,extra_dirs=external(path);record['selectionAuthority']={'path':str(path),'sha256':sha(path.read_bytes()),'auditHandoffSha256':sha((audit/'handoff.json').read_bytes())};record['originalSealQualification']='Terminal capture tree lacks in-place closure; separately sealed independent audit inventory binds all captured bytes.'
 else:
  expected={};extra_dirs=set()
  for entry in os.scandir(root):
   p=Path(entry.path);assert p.is_file()and not p.is_symlink(),p;expected[p.name]={'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
  record['originalSealQualification']='Unsealed metadata root preserved as observed; current selection hashes do not retroactively declare an original producer seal.'
 allowed_dirs={str(p)for rel in expected for p in Path(rel).parents}|extra_dirs
 # Metadata-only pathset walk, pruning exact known generated paths before descent.
 def walk(d):
  for entry in os.scandir(d):
   p=Path(entry.path)
   if p in PRUNE:continue
   rel=str(p.relative_to(root));s=p.lstat()
   if stat.S_ISDIR(s.st_mode):
    if rel not in allowed_dirs:unlisted.append({'root':name,'directory':rel,'reason':'Not represented by producer inventory; include if payload, never assume empty.'})
    walk(p)
   elif rel not in expected:unlisted.append({'root':name,'path':rel,'kind':'symlink'if stat.S_ISLNK(s.st_mode)else'regular','reason':'Unlisted producer payload; must be selected separately or justified.'})
 walk(root)
 for rel,old in sorted(expected.items()):
  p=root/rel;s=p.lstat();mode=stat.S_IMODE(s.st_mode)
  if stat.S_ISLNK(s.st_mode):
   target=os.readlink(p);data=os.fsencode(target);assert old.get('kind')=='symlink'and old['target']==target and sha(data)==old['sha256'];assert sha(p.read_bytes())==old['targetPayloadSha256'];member=f'payload/{id}/{rel}.symlink-target.bin';row={'group':group,'rootId':id,'root':str(root),'relative':rel,'source':str(p),'kind':'symlink','linkTarget':target,'targetPayloadSha256':old['targetPayloadSha256'],'sha256':sha(data),'bytes':len(data),'mode':mode,'member':member,'representation':'Regular payload contains original link target bytes; metadata retains original kind/mode/target payload hash, no archive symlink.'}
  else:
   assert stat.S_ISREG(s.st_mode),p;data=p.read_bytes();assert sha(data)==old['sha256']and len(data)==old['bytes'],p
   if'mode'in old:assert mode==old['mode'],p
   row={'group':group,'rootId':id,'root':str(root),'relative':rel,'source':str(p),'kind':'regular','sha256':sha(data),'bytes':len(data),'mode':mode,'member':f'payload/{id}/{rel}'}
  rows.append(row)
 record['files']=sum(x['rootId']==id for x in rows);record['rawBytes']=sum(x['bytes']for x in rows if x['rootId']==id);root_records.append(record)
assert not unlisted,unlisted
assert len({r['member']for r in rows})==len(rows)
# External references remain explicit: no compiled Rust/platform duplicates or full permanent fixture tree.
fixture=R/'tests/fixtures/m2-module-admission-policy';fm=load(fixture/'manifest.json');fixture_refs={str(Path('tests/fixtures/m2-module-admission-policy')/rel):row for rel,row in fm['files'].items()};fixture_refs['tests/fixtures/m2-module-admission-policy/manifest.json']={'sha256':sha((fixture/'manifest.json').read_bytes()),'bytes':(fixture/'manifest.json').stat().st_size}
old_archive=R/'reports/m2/stage47-renderer-c06-oracles-tools.tar.gz';references={'permanentPolicyFixture':{'repositoryRelativeRoot':'tests/fixtures/m2-module-admission-policy','manifestSha256':'6a4d5b2c8d394108c8a0ee98b33bbc5fd20525aa467da7e68e1799b8cea8ab72','files':fixture_refs,'status':'Exact workingtree bytes verified/promotion owned by root; final Git blob/commit binding is root-owned and not fabricated here.','duplicatedArchiveTree':False},'priorStage47JavaPolicyOriginal':{'archiveRepositoryPath':'reports/m2/stage47-renderer-c06-oracles-tools.tar.gz','sha256':sha(old_archive.read_bytes()),'bytes':old_archive.stat().st_size,'publishedBaseCommitDeclared':'0e13a589d43c4cb1d83f41dd1ec416cac1770fc1','duplicatedArchive':False},'canonicalNativeAndPlatforms':{'C01ReleaseSha256':'04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0','sourceMapSha256':'9f546b82bd3cfba614c2c0bb1671db14f226466707f99cef3a5ceb5f6dc12a18','nativeBuildRoot':str(B/'stage48-implementation-01/admission-candidate-build-01'),'platformRoot':str(B/'stage48-c01-platform-control-01'),'scope':'A/root published core/platform archives own compiled Rust/native/NAPI/Wasm/snapshot bytes. B preserves exact hash references in preflight/canonical bindings, not duplicate binaries.'}}
write(O/'selection.json',{'schema':1,'roots':root_records,'files':rows,'prewalkPrune':pruned,'unlistedPayload':unlisted,'rawFiles':len(rows),'rawBytes':sum(x['bytes']for x in rows),'symlinks':sum(x['kind']=='symlink'for x in rows),'permanentFixtureNotPacked':True});write(O/'references.json',references)
groups={}
for r in rows:
 g=groups.setdefault(r['group'],{'files':0,'rawBytes':0,'roots':[]});g['files']+=1;g['rawBytes']+=r['bytes'];
 if r['rootId']not in g['roots']:g['roots'].append(r['rootId'])
write(O/'groups.json',groups);print(json.dumps({'roots':len(root_records),'rawFiles':len(rows),'rawBytes':sum(x['bytes']for x in rows),'symlinks':sum(x['kind']=='symlink'for x in rows),'groups':groups,'unlistedPayload':unlisted,'selectionSha256':sha((O/'selection.json').read_bytes())},indent=2))
