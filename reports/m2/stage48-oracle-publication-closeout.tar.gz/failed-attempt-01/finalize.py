from pathlib import Path
import datetime,hashlib,json,os,stat,subprocess,sys,tarfile
O=Path(__file__).parent.resolve();sha=lambda b:hashlib.sha256(b).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
terminal=json.loads((O/'publisher-terminal.json').read_bytes());assert terminal['exitCode']==0 and not terminal['liveHandles'];index=json.loads((O/'index-data.json').read_bytes());selection=json.loads((O/'selection.json').read_bytes());assert index['originalChanges']==[]
# Recheck exact selected pathsets after the worker; no generic build/cache exclusions.
prune={Path(r['path'])for r in selection['prewalkPrune']};pathset_issues=[]
for root in selection['roots']:
 path=Path(root['root']);expected={r['relative']for r in selection['files']if r['rootId']==root['id']};dirs={str(p)for rel in expected for p in Path(rel).parents};authority=root.get('selectionAuthority')
 if authority:
  data=json.loads(Path(authority['path']).read_bytes());dirs|=set(data.get('directories',[]))|set(data.get('emptyDirectories',[]))
 def inspect(d):
  for e in os.scandir(d):
   p=Path(e.path)
   if p in prune:continue
   rel=str(p.relative_to(path));s=p.lstat()
   if stat.S_ISDIR(s.st_mode):
    if rel not in dirs:pathset_issues.append({'root':root['id'],'directory':rel})
    inspect(p)
   elif rel not in expected:pathset_issues.append({'root':root['id'],'unlisted':rel})
 inspect(path)
assert not pathset_issues,pathset_issues
clean=O/'closeout-gathered';clean.mkdir();explicit=['select.py','publish.py','launch_publication.py','finalize.py','selection.json','groups.json','references.json','index-data.json','report-data.json','publisher-launch.json','publisher-terminal.json','publisher.stdout.bin','publisher.stderr.bin','progress.json','tool-sources/evidence.py'];metadata={}
for rel in explicit:
 p=O/rel;assert p.is_file()and not p.is_symlink();b=p.read_bytes();q=clean/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);metadata[rel]={'sha256':sha(b),'bytes':len(b)}
for directory in sorted((O/'commands').iterdir()):
 assert directory.is_dir()and not directory.is_symlink()
 for p in sorted(directory.iterdir()):
  assert p.is_file()and not p.is_symlink();rel=str(p.relative_to(O));b=p.read_bytes();q=clean/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);metadata[rel]={'sha256':sha(b),'bytes':len(b)}
write(clean/'CLOSEOUT_SELECTION.json',{'files':metadata,'rawDataArchives':index['archives'],'qualification':'This finite metadata archive contains dataarchive producer/verify receipts and its actual outerterminal. Its own create/verify receipt is in final external report/index, not recursively inside itself.','pathsetIssues':pathset_issues})
archive=O/'archives/stage48-oracle-publication-closeout.tar.gz';tool=O/'tool-sources/evidence.py';commands=[]
for label,cmd in [('closeout-create',[sys.executable,'-B',str(tool),'create',str(clean),str(archive)]),('closeout-verify',[sys.executable,'-B',str(tool),'verify',str(archive)])]:
 d=O/'commands'/label;d.mkdir();row={'command':cmd,'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with(d/'stdout.bin').open('wb')as out,(d/'stderr.bin').open('wb')as err:
  p=subprocess.Popen(cmd,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=p.pid;write(d/'launch.json',row);row['exitCode']=p.wait()
 row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha((d/'stdout.bin').read_bytes()),stderrSha256=sha((d/'stderr.bin').read_bytes()));write(d/'terminal.json',row);assert row['exitCode']==0;commands.append(row)
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();lookup={m.name:m for m in members};assert len(lookup)==len(members)and all(m.isfile()for m in members);inventory=json.load(tar.extractfile(lookup['EVIDENCE.json']));assert {r['path']for r in inventory['files']}==set(lookup)-{'EVIDENCE.json'}
 for row in inventory['files']:
  b=tar.extractfile(lookup[row['path']]).read();assert sha(b)==row['sha256']and len(b)==row['bytes']and b==(clean/row['path']).read_bytes()
for row in selection['files']:
 p=Path(row['source']);s=p.lstat();assert stat.S_IMODE(s.st_mode)==row['mode'];b=os.fsencode(os.readlink(p))if row['kind']=='symlink'else p.read_bytes();assert sha(b)==row['sha256']and len(b)==row['bytes']
receipt={'group':'closeout','archive':str(archive),'fileName':archive.name,'sha256':sha(archive.read_bytes()),'compressedBytes':archive.stat().st_size,'payloadFiles':len(inventory['files']),'everyRawMemberReadBack':True,'below100MiB':archive.stat().st_size<100*1024*1024};assert receipt['below100MiB'];index['archives'].append(receipt);index['allArchives']=len(index['archives']);index['totalCompressedBytes']=sum(r['compressedBytes']for r in index['archives']);index['postWorkerPathsetIssues']=pathset_issues;write(O/'index.json',index)
report={'dataWorkerActualTerminal':terminal,'closeoutCommands':commands,'allArchives':len(index['archives']),'compressedBytes':index['totalCompressedBytes'],'selectedSourceRoots':18,'selectedSourceFiles':36596,'selectedRawBytes':65264715,'everyDataAndCloseoutRawMemberReadBack':True,'allCreateAndSeparateVerify0':True,'originalByteKindModePathsetChanges':[],'sourceExclusions':selection['prewalkPrune'],'noEvaluatorOrGitExecuted':True,'scope':'Java568Evaluator+392directpolicyAPI;native440rawpass/212unexecuted/fullLifecycle0of52;portable84Node+84browserrawpass/fullLifecycle0of12each;original16querynamefailures+36lazycycleintentmiss+historicaltool/selfsealflaw retained.','liveHandles':[]};write(O/'report.json',report)
write(O/'handoff.json',{'index':str(O/'index.json'),'indexSha256':sha((O/'index.json').read_bytes()),'reportSha256':sha((O/'report.json').read_bytes()),'selectionSha256':sha((O/'selection.json').read_bytes()),'referencesSha256':sha((O/'references.json').read_bytes()),'archives':index['archives'],'originalChanges':[],'mainReportsGitWrites':False,'nextStep':'Rootreviewandbyte-identicalpromotion/commit; finalGitblobmappingofpermanentfixtureisroot-owned.','liveHandles':[]});print(json.dumps({'archives':len(index['archives']),'compressedBytes':index['totalCompressedBytes'],'handoffSha256':sha((O/'handoff.json').read_bytes()),'indexSha256':sha((O/'index.json').read_bytes()),'reportSha256':sha((O/'report.json').read_bytes())},indent=2))
