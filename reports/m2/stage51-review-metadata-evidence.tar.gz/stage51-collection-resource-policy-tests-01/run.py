from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys
base=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51'); out=Path(__file__).resolve().parent
names=['tools/platform/collection-transform-session.mjs','tools/platform/collection-transform-session.test.mjs','tools/platform/module-policy-session.mjs','tools/platform/resource-session.mjs','tools/platform/compare-collection-transforms.mjs','external/pkl/pkl-core/src/main/java/org/pkl/core/SecurityManagers.java','external/pkl/pkl-core/src/main/resources/org/pkl/core/errorMessages.properties','target/m2/stage51-collection-oracle-07/CollectionProbe.java']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
node=Path(shutil.which('node')).resolve()
inputs={n:{'sha256':sha(base/n),'bytes':(base/n).stat().st_size} for n in names}
(out/'source-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
for n in names:
 p=out/'sources'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((base/n).read_bytes())
started=datetime.datetime.now(datetime.timezone.utc).isoformat(); cmds=[[str(node),'--test','tools/platform/collection-transform-session.test.mjs'],[str(node),'--check','tools/platform/collection-transform-session.mjs']];rows=[]
for i,cmd in enumerate(cmds):
 p=subprocess.run(cmd,cwd=base,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 for channel in ['stdout','stderr']:(out/(str(i)+'.'+channel+'.bin')).write_bytes(getattr(p,channel))
 rows.append({'argv':cmd,'cwd':str(base),'exitCode':p.returncode,'stdout':str(i)+'.stdout.bin','stderr':str(i)+'.stderr.bin'})
after={n:{'sha256':sha(base/n),'bytes':(base/n).stat().st_size} for n in names};(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');changes=[n for n in names if inputs[n]!=after[n]]
report={'schema':1,'startedUtc':started,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'commands':rows,'runtime':{'node':str(node),'sha256':sha(node)},'sourceChanges':changes,'scope':'Protocol mock tests and syntax only; no Java/native/browser evaluator runs. Policy requests are separate portable transport provenance, not synthetic Java events.','driverLedgerRetention':'compare-collection-transforms.mjs saves entire rows in target.raw.json and actual.json before comparison; no field filtering.'}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));sys.exit(0 if not changes and all(r['exitCode']==0 for r in rows) else 1)
