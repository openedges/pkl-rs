from pathlib import Path
import collections,datetime,hashlib,json,stat
b=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51'); out=Path(__file__).resolve().parent; native=b/'target/m2/stage51-native-candidate04-01'; portable=b/'target/m2/stage51-portable-candidate04-01'; build=b/'target/m2/stage51-candidate04-build'; fixtureRoot=b/'tests/fixtures/m2-collection-transforms'
load=lambda p:json.loads(Path(p).read_text()); sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); cache={}; originalGuards={}
def checked(path,wanted=None,size=None,mode=None):
 path=Path(path);s=path.lstat();assert stat.S_ISREG(s.st_mode),str(path)
 if mode is not None:assert stat.S_IMODE(s.st_mode)==mode,str(path)
 if str(path) not in cache:cache[str(path)]=sha(path)
 if wanted is not None:assert cache[str(path)]==wanted,str(path)
 if size is not None:assert s.st_size==size,str(path)
 return cache[str(path)]
def record(path):originalGuards[str(path)]=checked(path)
def enc(values):return b''.join(v.to_bytes(2,'big') for v in values)
def utf8(values):return enc(values).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
def expected_effect(effect):
 result={'callIndex':effect['callIndex'],'kind':effect['kind']}
 if effect['kind']=='read':return dict(result,uri=effect['uri'],attempt=effect['attempt'],result=effect['result'])
 def units(record):assert utf8(record['units']).hex()==record['javaUtf8Hex'];return record['units']
 frame=effect['frame'];actualFrame={'moduleUri':units(frame['moduleUri']),'memberName':None if frame['memberNameNull'] else units(frame['memberName']),'sourceLines':[units(v) for v in frame['sourceLines']]}
 actualFrame.update({n:frame[n] for n in ['startLine','startColumn','endLine','endColumn']});return dict(result,level=effect['level'],message=units(effect['message']),frame=actualFrame)
proof=load(build/'build-proof.json');checked(build/'build-proof.json','3f483d613b334b453b96866e6b036c2afd1b1fbca83632d6959142330cde5286');assert proof['status']=='CLOSED' and proof['sourceStable'] is True
before=load(build/'sources-before.json');after=load(build/'sources-after.json');assert before==after==proof['sources'];assert len(before)==437
for name,digest in before.items():checked(Path(proof['snapshotRoot'])/name,digest)
core=load(b/'target/m2/stage51-collection-core-diagnostic-freeze-04/sources.json');nativeExample='crates/pkl-runtime/examples/stage51_collection_probe.rs';deltas=[]
for row in core:
 if before[row['path']]!=row['sha256']:deltas.append({'path':row['path'],'before':row['sha256'],'after':before[row['path']]})
assert deltas==[]
artifacts={name:{**row,'verifiedSha256':checked(row['path'],row['sha256'])} for name,row in proof['artifacts'].items()}
nreport=load(native/'report.json'); pexec=load(portable/'execution.json'); nterminal=load(b/'target/m2/stage51-candidate04-launches-01/native/terminal.json');pterminal=load(b/'target/m2/stage51-candidate04-launches-01/portable/terminal.json');assert nterminal['exitCode']==0 and pterminal['exitCode']==1
for terminal in [nterminal,pterminal]:assert terminal['buildProofSha256']==sha(build/'build-proof.json')
buildreport=load(build/'report.json');assert buildreport['complete'] and buildreport['sourceStable'] and buildreport['buildProofSha256']==sha(build/'build-proof.json');assert all(c['exitCode']==0 for c in buildreport['commands'])
assert buildreport['authorizedCoreFreezeDeltas']==[];assert nreport['complete'] and not nreport['changedInputs'];assert not pexec['changedInputs'] and not pexec['infrastructureErrors'] and not pexec['browserErrors']
nbefore=load(native/'inputs-before.json');nfinal=load(native/'inputs-final.json');assert all(nfinal.get(k)==v for k,v in nbefore.items());assert set(nfinal)-set(nbefore)=={str(native/'actual.json')}
for path,digest in nfinal.items():checked(path,digest)
for path,digest in pexec['artifactAndInputHashes'].items():
 metadata=pexec['inputFileMetadata'][path];assert metadata['kind']=='regular';checked(path,digest,mode=metadata['mode'])
checked(pexec['browserExecutable'],pexec['browserExecutableSha256']);assert pexec['browserLaunchOptions']['executablePath']==pexec['browserExecutable'];checked(pexec['node']['executable'],pexec['node']['sha256']);assert pexec['missingAssetProbe']=={'status':404,'bodyHex':''}
npayload=load(native/'payloads.json');checked(native/'payloads.json',nreport['payloadManifestSha256'])
for name,row in npayload['files'].items():checked(native/name,row['sha256'],row['bytes'])
ppayload=load(portable/'output-inventory.json');checked(portable/'output-inventory.json',pexec['outputInventory']['sha256'])
for name,row in ppayload['files'].items():checked(portable/name,row['sha256'],row['bytes'],row['mode'])
nativeFolders={tuple(p['oracleCaseRepeat']):Path(p['argv'][-1]) for p in nreport['processes'] if p['name'].startswith('native-')};assert len(nativeFolders)==76
fixtures=load(portable/'fixtures.json')['fixtures'];assert fixtures==load(native/'fixtures.json');actuals={'native':load(native/'actual.json'),'node':load(portable/'node.raw.json'),'browser':load(portable/'browser.raw.json')};results={};failures=[];denials=[];policyTotals={}
for target,sessions in actuals.items():
 counts=collections.Counter();bad=[];policyCount=0;denialCount=0;assert len(sessions)==len(fixtures)==152
 for position,(fixture,session) in enumerate(zip(fixtures,sessions)):
  assert fixture['id']==session['id'] and session['acquisitionError'] is None and not session['cleanupErrors'];assert session['architecture']['terminalSlots']==0 and session['architecture']['ownedResultsStable'] and session['architecture']['providerEntriesReleased'];assert len(session['calls'])==len(fixture['expected'])
  assert session['effects']==[expected_effect(e) for e in fixture['expectedEffects']]
  if target=='native':folder=nativeFolders[(fixture['oracle'],fixture['caseId'],fixture['repeat'])]/('session-'+str(fixture['session']))
  for expected,call in zip(fixture['expected'],session['calls']):
   assert call['index']==expected['index'] and call['expression']==expected['expression'];counts['calls']+=1
   raw=call['status']==expected['status'] and all(call[c+'Units']==expected[c+'Units'] and utf8(call[c+'Units']).hex()==expected[c+'Hex'] for c in ['stdout','stderr'])
   counts['rawMatches']+=int(raw);counts[expected['scope']]+=1;counts[expected['scope']+'RawMatches']+=int(raw)
   countmatch=all(call[k]==expected[k] for k in ['readsBefore','readsAfter','logsBefore','logsAfter']);assert countmatch
   ordinaryDisposition=(call['status']=='success' and call['disposition'] is None) or (call['status']=='error' and call['disposition']=='language-error')
   if call['status']=='error':assert call['disposition'] in ['language-error','unsupported','limit-exceeded','internal-failure']
   elif call['status']=='success':assert call['disposition'] is None
   ordinary=expected['scope']=='ordinary' and ordinaryDisposition and raw;counts['ordinaryCompatible']+=int(ordinary)
   if expected['scope']=='ordinary' and not ordinary:
    assert fixture['oracle']=='java06' and fixture['caseId'] in ['empty-list-reference-matrix','empty-set-reference-matrix'] and call['index'] in [2,14];bad.append([fixture['caseId'],fixture['repeat'],fixture['session'],call['index']]);failures.append({'target':target,'id':fixture['id'],'index':call['index'],'disposition':call['disposition'],'phase':call['phase'],'rawMatch':raw,'countsMatch':countmatch})
   if target=='native':
    prefix='call-'+str(call['index']);assert (folder/(prefix+'.status.bin')).read_bytes()==(call['status']+'\n').encode();assert (folder/(prefix+'.expression.utf16be.bin')).read_bytes().decode('utf-16-be','surrogatepass')==call['expression']
    for channel in ['stdout','stderr']:assert (folder/(prefix+'.'+channel+'.bin')).read_bytes()==utf8(call[channel+'Units']) and (folder/(prefix+'.'+channel+'.utf16be.bin')).read_bytes()==enc(call[channel+'Units'])
    for key,suffix in [('disposition','disposition'),('phase','phase')]:assert (folder/(prefix+'.'+suffix+'.bin')).read_bytes()==(call[key] or '').encode()
    for key,suffix in [('readsBefore','reads-before'),('readsAfter','reads-after'),('logsBefore','logs-before'),('logsAfter','logs-after')]:assert int((folder/(prefix+'.'+suffix+'.bin')).read_bytes())==call[key]
  allowed=[]
  for i,policy in enumerate(session['resourcePolicyRequests']):
   policyCount+=1;uri=policy['uri'];permit=uri.startswith('ct:');message='' if permit else 'Refusing to read resource `'+uri+'` because it does not match any entry in the resource allowlist (`--allowed-resources`).';assert policy['allowed']==permit and policy['message']==message and isinstance(policy['token'],str)
   call=session['calls'][policy['callIndex']]
   if permit:allowed.append((policy['callIndex'],uri))
   else:
    denialCount+=1;assert fixture['oracle']=='java07' and fixture['caseId']=='duration-type-render' and call['index']==9 and uri=='prop:pkl.outputFormat';assert call['readsBefore']==call['readsAfter']==0;assert not [e for e in session['effects'] if e['callIndex']==call['index']];assert call['stderrUnits']==fixture['expected'][9]['stderrUnits'];denials.append({'target':target,'id':fixture['id'],'policy':policy,'call':call})
   if target=='native':
    prefix='resource-policy-'+str(i)
    for suffix,text in [('uri',uri),('message',message),('token',policy['token']),('allowed',str(permit).lower())]:assert (folder/(prefix+'.'+suffix+'.bin')).read_bytes()==text.encode('utf-8')
  assert allowed==[(e['callIndex'],e['uri']) for e in session['effects'] if e['kind']=='read']
 assert len(bad)==0 and counts['calls']==2108 and counts['ordinaryCompatible']==2000 and counts['rawMatches']==2096 and counts['intent-not-reachedRawMatches']==96 and denialCount==4
 results[target]=dict(counts);policyTotals[target]={'requests':policyCount,'denied':denialCount,'readerSideEffectOnDenied':0}
for root in [native,portable,build]:
 for name in (['report.json','comparison.json','inputs-before.json','inputs-final.json','payloads.json'] if root==native else ['execution.json','output-inventory.json'] if root==portable else ['report.json','build-proof.json','sources-before.json','sources-after.json']):record(root/name)
for path,digest in originalGuards.items():assert sha(path)==digest
(out/'input-and-payload-binding.json').write_text(json.dumps({'checkedDistinctRegularFiles':len(cache),'nativeInputs':len(nfinal),'nativePayloads':len(npayload['files']),'portablePayloads':len(ppayload['files']),'source437Stable':True,'freeze04CoreMatches':225,'authorizedExampleDelta':deltas,'artifacts':artifacts,'originalGuards':originalGuards},indent=2)+'\n')
(out/'failures.json').write_text(json.dumps(failures,indent=2)+'\n');(out/'resource-policy-denials.json').write_text(json.dumps(denials,indent=2)+'\n')

# Independently preserve the actual receiver correction across all three targets.
priorRoots={'native':b/'target/m2/stage51-native-candidate03-01/actual.json','node':b/'target/m2/stage51-portable-candidate03-01/node.raw.json','browser':b/'target/m2/stage51-portable-candidate03-01/browser.raw.json'}
transitions=[]
for target,sessions in actuals.items():
 oldSessions=load(priorRoots[target]);fixed=0;otherRawChanges=[]
 for fixture,oldSession,session in zip(fixtures,oldSessions,sessions):
  assert oldSession['id']==session['id'];assert oldSession['effects']==session['effects']
  for expected,oldCall,call in zip(fixture['expected'],oldSession['calls'],session['calls']):
   changed=any(oldCall[k]!=call[k] for k in ['status','stdoutUnits','stderrUnits'])
   if expected['scope']=='ordinary' and changed:
    assert fixture['oracle']=='java06' and fixture['caseId'] in ['empty-list-reference-matrix','empty-set-reference-matrix'] and call['index'] in [2,14]
    assert oldCall['disposition']=='internal-failure' and call['disposition']=='language-error';fixed+=1;transitions.append({'target':target,'id':fixture['id'],'index':call['index'],'beforeDisposition':oldCall['disposition'],'afterDisposition':call['disposition'],'javaFullRawMatched':True})
   elif changed:otherRawChanges.append({'id':fixture['id'],'index':call['index'],'scope':expected['scope']})
 assert fixed==16;assert not otherRawChanges
(out/'candidate03-to04-transitions.json').write_text(json.dumps(transitions,indent=2)+'\n')
# Original SourceCode expression adapter: retain exact old physical source/cwd/env.
original=b/'target/m2/stage51-original-adapter-candidate04-01';orig=load(original/'report.json');origInputs=load(original/'inputs.json');assert orig['complete'] and orig['passed'] and orig['preflightExitCode']==0 and not orig['changedInputs']
for path,digest in origInputs.items():checked(path,digest)
javaRoot=fixtureRoot/'provenance/java01';java=load(javaRoot/'report.json')['originalAdapterProcesses'];binding=load(javaRoot/'original-binding.json');assert len(java)==len(orig['commands'])==2
for i,(j,rust) in enumerate(zip(java,orig['commands'])):
 assert rust['cwd']==j['cwd'] and rust['environment']==j['environment'] and rust['exitCode']==j['exitCode']==0 and not j['timedOut']
 assert rust['argv'][0]==buildreport['languageProbe']['path'];assert rust['argv'][1:]==j['command'][-2:]==[binding['copiedPath'],'result']
 for c in ['stdout','stderr']:
  p=javaRoot/'original-adapter'/str(i)/(c+'.bin');checked(p,j[c+'Sha256']);assert (original/('rust-'+str(i)+'.'+c+'.bin')).read_bytes()==p.read_bytes()
checked(buildreport['languageProbe']['path'],buildreport['languageProbe']['sha256']);checked(binding['copiedPath'],binding['sha256'])
assert Path(binding['copiedPath']).read_bytes()==(b/'tests/fixtures/m2/annotation-stage35-builtin-source-code-union-and-string.pkl').read_bytes()
# Required Rust5: parsed raw stdout totals retain explicit ignored test.
import re
required=b/'target/m2/stage51-required-checks-candidate04-01';req=load(required/'report.json');rb=load(required/'sources-before.json');ra=load(required/'sources-after.json');assert rb==ra and all(rb[k]==v for k,v in proof['sources'].items());assert len(rb)==439
assert req['complete'] and req['sourceStable'] and req['passed'] and req['buildProofSha256']==sha(build/'build-proof.json')
requiredNames={'verify','fmt','clippy','test','wasm-check'};assert requiredNames<={c['name'] for c in req['commands']}
for c in req['commands']:
 assert c['exitCode']==0
 for channel in ['stdout','stderr']:checked(required/(c['name']+'.'+channel+'.bin'),c[channel+'Sha256'])
groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (required/'test.stdout.bin').read_text());totals=tuple(sum(int(g[i]) for g in groups) for i in range(3));assert totals==(864,0,1)
ignored=[line for line in (required/'test.stdout.bin').read_text().splitlines() if 'ignored' in line and not line.startswith('test result')];assert ignored==['test frontend_probe ... ignored, invoked explicitly by the M1 differential evidence runner']
for mode in ['original','native','portable']:
 receipt=load(b/('target/m2/stage51-candidate04-launches-01/'+mode+'/terminal.json'));assert receipt['exitCode']==(1 if mode=='portable' else 0) and receipt['buildProofSha256']==sha(build/'build-proof.json')
(out/'original-and-required-checks.json').write_text(json.dumps({'originalAdapterCalls':2,'fullRawCwdEnvironmentExitMatch':True,'physicalSource':binding['copiedPath'],'requiredCommands':[c['argv'] for c in req['commands'] if c['name'] in requiredNames],'allRequiredFiveExitZero':True,'requiredSourceCount':439,'requiredExtraInputs':{k:rb[k] for k in rb.keys()-proof['sources'].keys()},'testSummary':{'passed':totals[0],'failed':totals[1],'ignored':totals[2],'ignoredLines':ignored},'M1Excluded':'Still-running M1 source/report/launcher directory is not selected or inferred.'},indent=2)+'\n')
report={'schema':1,'status':'CLOSED_CANDIDATE04_RAW_PROVENANCE_AUDIT','recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':'Stage51 candidate04 only','producerTerminals':{'native':{'session':89242,'exitCode':0,'chunk':'92ae9c','pid':nterminal['pid']},'portable':{'session':8909,'exitCode':1,'chunk':'3162da','pid':pterminal['pid']}},'results':results,'policy':policyTotals,'allOrderedEffectsMatch':True,'acquisitionIntegrityPassed':True,'ordinaryContractPassed':True,'fullJavaEventsCountersPassed':False,'fullCompatibilityPassed':False,'sourceChanges':[],'payloadChanges':[],'newEvaluatorRuns':0,'qualifications':['Current live Rust never used as candidate identity; source binding uses437captured source files and225matching freeze04paths with no post-freeze core delta','Build proof establishes captured source/command/artifact provenance, not independent binary decompilation or embedded-source identity proof','Explicit browser launch path/hash and HTTP served-input binding retained; browser OS PID is not recorded','Original Java fixture authority reused from pinned hermetic fixture verification; all fixture files also explicitly rehashed through declared native input map','Native acquisition wrapper0 is separate from ordinary compatibility false;12post-close raw failures remain separate from2000matching ordinary calls','Java full administrative lifecycle and whole M2/performance remain open']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
