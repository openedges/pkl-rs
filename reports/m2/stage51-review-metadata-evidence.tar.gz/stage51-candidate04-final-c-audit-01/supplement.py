from pathlib import Path
import json,hashlib
b=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51');out=Path(__file__).resolve().parent;n=b/'target/m2/stage51-native-candidate04-01';build=b/'target/m2/stage51-candidate04-build';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda p:json.loads(Path(p).read_text())
a=load(n/'actual.json');fs=load(n/'fixtures.json');report=load(n/'report.json');folders={tuple(v['oracleCaseRepeat']):Path(v['argv'][-1]) for v in report['processes'] if v['name'].startswith('native-')};assert len(folders)==76
counts={'sessions':0,'retainedOutputs':0,'moduleRequests':0}
for f,s in zip(fs,a):
 folder=folders[(f['oracle'],f['caseId'],f['repeat'])]/('session-'+str(f['session']));retained=0
 for call in s['calls']:
  if call['status']=='api-error':continue
  channel='stdout' if call['status']=='success' else 'stderr';expected=b''.join(u.to_bytes(2,'big') for u in call[channel+'Units']);assert (folder/('retained-'+str(retained)+'.utf16be.bin')).read_bytes()==expected;retained+=1
 assert int((folder/'retained-output-buffers.bin').read_bytes())==retained
 for i,v in enumerate(s['moduleRequests']):
  assert v['index']==i
  for field,name in [('requestRawHex','request'),('tokenRawHex','token')]:assert (folder/('module-'+str(i)+'.'+name+'.bin')).read_bytes().hex()==v[field]
 assert int((folder/'module-requests.bin').read_bytes())==len(s['moduleRequests']);assert int((folder/'terminal-slots.bin').read_bytes())==0 and int((folder/'provider-entries.bin').read_bytes())==0
 counts['sessions']+=1;counts['retainedOutputs']+=retained;counts['moduleRequests']+=len(s['moduleRequests'])
proof=load(build/'build-proof.json');controls=['.cargo/config.toml','Cargo.toml','Cargo.lock','rust-toolchain.toml'];assert all(v in proof['sources'] for v in controls)
buildreport=load(build/'report.json')
for command in buildreport['commands']:
 for channel in ['stdout','stderr']:assert sha(build/(command['name']+'.'+channel+'.bin'))==command[channel+'Sha256']
oldN=b/'target/m2/stage51-native-candidate03-01';oldP=b/'target/m2/stage51-portable-candidate03-01';oldPayload=load(oldN/'payloads.json');assert sha(oldN/'actual.json')==oldPayload['files']['actual.json']['sha256'];oldInventory=load(oldP/'output-inventory.json')
for name in ['node.raw.json','browser.raw.json']:assert sha(oldP/name)==oldInventory['files'][name]['sha256']
authorities={}
for number in range(1,9):
 root=b/'tests/fixtures/m2-collection-transforms/provenance'/('java'+str(number).zfill(2));authorities[str(number)]={'report':str(root/'report.json'),'reportSha256':sha(root/'report.json')}
result={'nativeRawJoins':counts,'allTerminalSlotsAndProviderEntriesZero':True,'ownedOutputsExactAfterClose':True,'moduleRequestTokenBytesExact':True,'buildCommandRawLogsMatch':True,'directCargoControls':{v:proof['sources'][v] for v in controls},'oldCandidate03RawIdentityVerified':True,'originalJavaAuthorities':authorities,'scope':'Static/read-only raw and build-record joins; no evaluator, Java, M1 or performance rerun.'};(out/'supplement.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
