from pathlib import Path
import hashlib,json,collections,datetime
b=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51'); out=Path(__file__).resolve().parent; root=b/'target/m2/stage51-portable-candidate03-01'; fixtureRoot=b/'tests/fixtures/m2-collection-transforms'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=[root/n for n in ['fixtures.json','node.raw.json','browser.raw.json','execution.json']]+[b/'target/m2/stage51-candidate03-launches-01/portable/terminal.json',b/'target/m2/stage51-candidate03-build/build-proof.json']
before={str(p):sha(p) for p in files};(out/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n')
bundle=json.loads(files[0].read_text()); execution=json.loads((root/'execution.json').read_text());terminal=json.loads(files[4].read_text());assert terminal['exitCode']==1 and terminal['buildProofSha256']==sha(files[5]);assert execution['buildProofSha256']==terminal['buildProofSha256']
units=lambda values:b''.join(v.to_bytes(2,'big') for v in values)
utf8=lambda values:units(values).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
rows=[];sessionEvidence=[];counts={};allRaw={};unique=set()
for target in ['node','browser']:
 actuals=json.loads((root/(target+'.raw.json')).read_text());assert len(actuals)==len(bundle['fixtures']);failures=0;rawMatches=0;rawByScope=collections.Counter()
 for position,(fixture,actual) in enumerate(zip(bundle['fixtures'],actuals)):
  assert fixture['id']==actual['id'] and len(actual['calls'])==len(fixture['expected'])
  selected=fixture['oracle']=='java06' and fixture['caseId'] in ['empty-list-reference-matrix','empty-set-reference-matrix']
  if selected:sessionEvidence.append({'target':target,'id':fixture['id'],'moduleRequests':actual['moduleRequests'],'effects':actual['effects'],'resourcePolicyRequests':actual['resourcePolicyRequests'],'observations':actual['observations'],'architecture':actual['architecture'],'acquisitionError':actual['acquisitionError'],'cleanupErrors':actual['cleanupErrors']})
  for expected,call in zip(fixture['expected'],actual['calls']):
   assert expected['index']==call['index'] and expected['expression']==call['expression']
   raw=call['status']==expected['status'] and all(call[c+'Units']==expected[c+'Units'] and utf8(call[c+'Units']).hex()==expected[c+'Hex'] for c in ['stdout','stderr']);rawMatches+=int(raw)
   if raw:rawByScope[expected['scope']]+=1
   if not (selected and call['index'] in [2,14]):continue
   assert not raw and call['status']==expected['status']=='error' and call['stdoutUnits']==expected['stdoutUnits']==[]
   assert call['disposition']=='internal-failure' and call['phase']=='module-output';assert 'invalid object scope' in units(call['stderrUnits']).decode('utf-16-be')
   countmatch=all(call[k]==expected[k] for k in ['readsBefore','readsAfter','logsBefore','logsAfter']);assert countmatch
   effects=[v for v in actual['effects'] if v['callIndex']==call['index']];expectedEffects=[v for v in fixture['expectedEffects'] if v['callIndex']==call['index']];assert effects==expectedEffects==[]
   rawSources={}
   for channel in ['stdout','stderr']:
    p=fixtureRoot/(expected['rawPrefix']+'.'+channel+'.bin');data=p.read_bytes();assert data.hex()==expected[channel+'Hex']
    origin=b/'target/m2/stage51-collection-oracle-06'/expected['rawPrefix'].removeprefix('provenance/java06/');original=Path(str(origin)+'.'+channel+'.bin');assert original.read_bytes()==data
    p16=fixtureRoot/(expected['rawPrefix']+'.'+channel+'.utf16be.bin');assert p16.read_bytes()==units(expected[channel+'Units'])
    runtime=root/target/str(position)/(str(call['index'])+'.'+channel+'.utf16be.bin');runtime8=root/target/str(position)/(str(call['index'])+'.'+channel+'.java-utf8.bin');assert runtime.read_bytes()==units(call[channel+'Units']) and runtime8.read_bytes()==utf8(call[channel+'Units'])
    rawSources[channel]={'javaInstalled':str(p),'javaOriginal':str(original),'javaSha256':sha(p),'runtimeUTF16':str(runtime),'runtimeUTF16Sha256':sha(runtime),'runtimeJavaUTF8':str(runtime8),'runtimeJavaUTF8Sha256':sha(runtime8)}
   unique.add((fixture['caseId'],call['index'],call['expression']));rows.append({'target':target,'id':fixture['id'],'caseId':fixture['caseId'],'repeat':fixture['repeat'],'session':fixture['session'],'index':call['index'],'expression':call['expression'],'expected':expected,'actual':call,'countsMatch':countmatch,'effects':effects,'expectedEffects':expectedEffects,'rawSources':rawSources});failures+=1
 counts[target]=failures;allRaw[target]={'calls':sum(len(v['calls']) for v in actuals),'rawMatches':rawMatches,'byScope':dict(rawByScope)}
 assert failures==16 and rawMatches==execution['targets'][target]['rawByteMatches']
assert len(unique)==4 and len(rows)==32
(out/'correspondence.json').write_text(json.dumps({'uniqueCalls':sorted(unique),'rows':rows},indent=2)+'\n');(out/'session-context.json').write_text(json.dumps(sessionEvidence,indent=2)+'\n')
for p in files[3:5]:(out/p.name).write_bytes(p.read_bytes())
after={str(p):sha(p) for p in files};assert before==after;(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
report={'schema':1,'status':'CLOSED_NARROW_RAW_FAILURE_AUDIT','recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producerActualSession':77146,'producerActualExit':1,'producerActualChunk':'e3ad57','producerChildPid':terminal['pid'],'uniqueCalls':len(unique),'mismatchesByTarget':counts,'allRawRecomputed':allRaw,'selectedFailureChannels':{'statusMatch':True,'stdoutMatch':True,'stderrMatch':False,'countsMatch':True,'effectsMatch':True,'actualDisposition':'internal-failure','actualPhase':'module-output'},'producerGates':{k:execution[k] for k in ['acquisitionIntegrityPassed','rawApiPassed','ordinaryCompatibilityPassed','orderedEffectsPassed','ordinaryContractPassed','selectedContractPassed','fullJavaEventsCountersPassed','fullCompatibilityPassed']},'producerErrors':{k:execution[k] for k in ['changedInputs','infrastructureErrors','browserErrors']},'inputChanges':[],'scope':'Exact Java06 four unique receiver identity calls/32 target-repeat rows and complete raw-channel count recomputation only; not full artifact/browser/source/inventory audit. Session moduleRequests lack callIndex and are preserved without invented per-call attribution. Native/required checks are outside this report. No evaluator reruns.'};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
