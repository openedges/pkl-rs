# 빈 collection 변환의 관찰 가능한 identity 경계

이 입력은 **소스에 근거한 예상 재현이며 실행하지 않았습니다**. Java와 Rust의 heap 배치가 같아야 한다는 주장은 하지 않습니다.

`empty-conversion-observer.pkl`의 `renderer.renderDocument(original)`를 직접 평가합니다. Java `VmSet.toList()`는 `VmList.create(elementOrder)`를 호출하고, 빈 입력은 `VmList.EMPTY`를 반환합니다. 원래 `List()`도 같은 EMPTY입니다. PCF document는 List를 최상위 값으로 허용하지 않으므로 `PcfRenderer.visitDocument`에서 오류가 납니다. `AbstractRenderer.renderDocument`는 변환 전후의 Java reference가 다를 때만 conversion hint를 추가합니다. `invalidPcfTopLevelValue`에는 이를 덮는 template hint가 없습니다. 따라서 이 입력의 Java 오류에는 conversion hint가 없어야 한다는 소스 예측입니다.

현재 Rust projection은 빈 결과에도 새 builder ObjectId를 만들며 renderer는 ObjectId의 reference를 비교하므로, 원래 빈 List와 다른 결과로 판단하여 hint를 추가할 가능성이 있습니다. 실제 Java/native 원문 대조 전에는 호환성 실패로 집계하지 않습니다.

같은 관찰을 다음에 적용할 수 있습니다.

- `Set()`에 `[Set] = (value) -> List().toSet()`.
- `Set()`에 `[Set] = (value) -> Map().keys`.
- `List()`에 `[List] = (value) -> Map().values`.
- 대조군: `(value) -> value`, `List.toList()` 또는 `Set.toSet()`은 receiver를 그대로 반환합니다.
- 다른 대조군: 서로 다른 AST 위치의 `List(1)`을 변환 전후에 사용합니다. 내용 동등성으로 모든 hint를 없애는 구현을 방지하기 위한 source-backed 제안이며, 이 역시 실제 관찰 전에는 기대 결과로 봉인하지 않습니다.

근거는 pinned `VmList.java:60`, `VmSet.java:277`, `VmMap.java:185`, `AbstractRenderer.java:88`, `base/PcfRenderer.java:150`, `errorMessages.properties:737`와 동결02의 `collection_transforms.rs:325`입니다. module/API/오류/frame 원문·UTF16·JavaUTF8를 보존하고 실제 결과가 예상과 다르면 그 차이를 기록합니다. root가 B의 독립 Java06 취득을 별도로 승인했으며 C는 새 evaluator를 실행하지 않았습니다.
