from pathlib import Path
import subprocess,sys,json,datetime,hashlib,os
r=Path(__file__).resolve().parent;script=r/'audit.py';start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (r/'stdout.bin').open('wb') as out,(r/'stderr.bin').open('wb') as err:
 child=subprocess.Popen([sys.executable,str(script)],stdout=out,stderr=err);code=child.wait()
record={'schema':1,'startedUtc':start,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'childPid':child.pid,'exitCode':code,'scriptSha256':hashlib.sha256(script.read_bytes()).hexdigest(),'scope':'Read-only audit; no evaluator reruns'};(r/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(code)
