from pathlib import Path
import collections,datetime,hashlib,json,stat
b=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51'); out=Path(__file__).resolve().parent; native=b/'target/m2/stage51-native-candidate03-01'; portable=b/'target/m2/stage51-portable-candidate03-01'; build=b/'target/m2/stage51-candidate03-build'; fixtureRoot=b/'tests/fixtures/m2-collection-transforms'
load=lambda p:json.loads(Path(p).read_text()); sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest(); cache={}; originalGuards={}
def checked(path,wanted=None,size=None,mode=None):
 path=Path(path);s=path.lstat();assert stat.S_ISREG(s.st_mode),str(path)
 if mode is not None:assert stat.S_IMODE(s.st_mode)==mode,str(path)
 if str(path) not in cache:cache[str(path)]=sha(path)
 if wanted is not None:assert cache[str(path)]==wanted,str(path)
 if size is not None:assert s.st_size==size,str(path)
 return cache[str(path)]
def record(path):originalGuards[str(path)]=checked(path)
def enc(values):return b''.join(v.to_bytes(2,'big') for v in values)
def utf8(values):return enc(values).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
def expected_effect(effect):
 result={'callIndex':effect['callIndex'],'kind':effect['kind']}
 if effect['kind']=='read':return dict(result,uri=effect['uri'],attempt=effect['attempt'],result=effect['result'])
 def units(record):assert utf8(record['units']).hex()==record['javaUtf8Hex'];return record['units']
 frame=effect['frame'];actualFrame={'moduleUri':units(frame['moduleUri']),'memberName':None if frame['memberNameNull'] else units(frame['memberName']),'sourceLines':[units(v) for v in frame['sourceLines']]}
 actualFrame.update({n:frame[n] for n in ['startLine','startColumn','endLine','endColumn']});return dict(result,level=effect['level'],message=units(effect['message']),frame=actualFrame)
proof=load(build/'build-proof.json');checked(build/'build-proof.json','1c53ebe4ab3221688389c5740c4946b2ad787e208fe03009aade3a155f4e3787');assert proof['status']=='CLOSED' and proof['sourceStable'] is True
before=load(build/'sources-before.json');after=load(build/'sources-after.json');assert before==after==proof['sources'];assert len(before)==430
for name,digest in before.items():checked(Path(proof['snapshotRoot'])/name,digest)
core=load(b/'target/m2/stage51-collection-core-diagnostic-freeze-03/sources.json');nativeExample='crates/pkl-runtime/examples/stage51_collection_probe.rs';deltas=[]
for row in core:
 if before[row['path']]!=row['sha256']:deltas.append({'path':row['path'],'before':row['sha256'],'after':before[row['path']]})
assert deltas==[{'path':nativeExample,'before':'8d24d2614faeaf4e15f36889c43c1d9eeaa85bafb25f918c231ab5392569a98b','after':'ffa2bd0ab740f701abc58d948f98518ea2fba7679d28a4b5e638de5e40836316'}]
artifacts={name:{**row,'verifiedSha256':checked(row['path'],row['sha256'])} for name,row in proof['artifacts'].items()}
nreport=load(native/'report.json'); pexec=load(portable/'execution.json'); nterminal=load(b/'target/m2/stage51-candidate03-launches-01/native/terminal.json');pterminal=load(b/'target/m2/stage51-candidate03-launches-01/portable/terminal.json');assert nterminal['exitCode']==0 and pterminal['exitCode']==1
for terminal in [nterminal,pterminal]:assert terminal['buildProofSha256']==sha(build/'build-proof.json')
buildreport=load(build/'report.json');assert buildreport['complete'] and buildreport['sourceStable'] and buildreport['buildProofSha256']==sha(build/'build-proof.json');assert all(c['exitCode']==0 for c in buildreport['commands'])
assert buildreport['authorizedCoreFreezeDeltas'][0]['after']==deltas[0]['after'];assert nreport['complete'] and not nreport['changedInputs'];assert not pexec['changedInputs'] and not pexec['infrastructureErrors'] and not pexec['browserErrors']
nbefore=load(native/'inputs-before.json');nfinal=load(native/'inputs-final.json');assert all(nfinal.get(k)==v for k,v in nbefore.items());assert set(nfinal)-set(nbefore)=={str(native/'actual.json')}
for path,digest in nfinal.items():checked(path,digest)
for path,digest in pexec['artifactAndInputHashes'].items():
 metadata=pexec['inputFileMetadata'][path];assert metadata['kind']=='regular';checked(path,digest,mode=metadata['mode'])
checked(pexec['browserExecutable'],pexec['browserExecutableSha256']);assert pexec['browserLaunchOptions']['executablePath']==pexec['browserExecutable'];checked(pexec['node']['executable'],pexec['node']['sha256']);assert pexec['missingAssetProbe']=={'status':404,'bodyHex':''}
npayload=load(native/'payloads.json');checked(native/'payloads.json',nreport['payloadManifestSha256'])
for name,row in npayload['files'].items():checked(native/name,row['sha256'],row['bytes'])
ppayload=load(portable/'output-inventory.json');checked(portable/'output-inventory.json',pexec['outputInventory']['sha256'])
for name,row in ppayload['files'].items():checked(portable/name,row['sha256'],row['bytes'],row['mode'])
nativeFolders={tuple(p['oracleCaseRepeat']):Path(p['argv'][-1]) for p in nreport['processes'] if p['name'].startswith('native-')};assert len(nativeFolders)==76
fixtures=load(portable/'fixtures.json')['fixtures'];assert fixtures==load(native/'fixtures.json');actuals={'native':load(native/'actual.json'),'node':load(portable/'node.raw.json'),'browser':load(portable/'browser.raw.json')};results={};failures=[];denials=[];policyTotals={}
for target,sessions in actuals.items():
 counts=collections.Counter();bad=[];policyCount=0;denialCount=0;assert len(sessions)==len(fixtures)==152
 for position,(fixture,session) in enumerate(zip(fixtures,sessions)):
  assert fixture['id']==session['id'] and session['acquisitionError'] is None and not session['cleanupErrors'];assert session['architecture']['terminalSlots']==0 and session['architecture']['ownedResultsStable'] and session['architecture']['providerEntriesReleased'];assert len(session['calls'])==len(fixture['expected'])
  assert session['effects']==[expected_effect(e) for e in fixture['expectedEffects']]
  if target=='native':folder=nativeFolders[(fixture['oracle'],fixture['caseId'],fixture['repeat'])]/('session-'+str(fixture['session']))
  for expected,call in zip(fixture['expected'],session['calls']):
   assert call['index']==expected['index'] and call['expression']==expected['expression'];counts['calls']+=1
   raw=call['status']==expected['status'] and all(call[c+'Units']==expected[c+'Units'] and utf8(call[c+'Units']).hex()==expected[c+'Hex'] for c in ['stdout','stderr'])
   counts['rawMatches']+=int(raw);counts[expected['scope']]+=1;counts[expected['scope']+'RawMatches']+=int(raw)
   countmatch=all(call[k]==expected[k] for k in ['readsBefore','readsAfter','logsBefore','logsAfter']);assert countmatch
   ordinaryDisposition=(call['status']=='success' and call['disposition'] is None) or (call['status']=='error' and call['disposition']=='language-error')
   if call['status']=='error':assert call['disposition'] in ['language-error','unsupported','limit-exceeded','internal-failure']
   elif call['status']=='success':assert call['disposition'] is None
   ordinary=expected['scope']=='ordinary' and ordinaryDisposition and raw;counts['ordinaryCompatible']+=int(ordinary)
   if expected['scope']=='ordinary' and not ordinary:
    assert fixture['oracle']=='java06' and fixture['caseId'] in ['empty-list-reference-matrix','empty-set-reference-matrix'] and call['index'] in [2,14];bad.append([fixture['caseId'],fixture['repeat'],fixture['session'],call['index']]);failures.append({'target':target,'id':fixture['id'],'index':call['index'],'disposition':call['disposition'],'phase':call['phase'],'rawMatch':raw,'countsMatch':countmatch})
   if target=='native':
    prefix='call-'+str(call['index']);assert (folder/(prefix+'.status.bin')).read_bytes()==(call['status']+'\n').encode();assert (folder/(prefix+'.expression.utf16be.bin')).read_bytes().decode('utf-16-be','surrogatepass')==call['expression']
    for channel in ['stdout','stderr']:assert (folder/(prefix+'.'+channel+'.bin')).read_bytes()==utf8(call[channel+'Units']) and (folder/(prefix+'.'+channel+'.utf16be.bin')).read_bytes()==enc(call[channel+'Units'])
    for key,suffix in [('disposition','disposition'),('phase','phase')]:assert (folder/(prefix+'.'+suffix+'.bin')).read_bytes()==(call[key] or '').encode()
    for key,suffix in [('readsBefore','reads-before'),('readsAfter','reads-after'),('logsBefore','logs-before'),('logsAfter','logs-after')]:assert int((folder/(prefix+'.'+suffix+'.bin')).read_bytes())==call[key]
  allowed=[]
  for i,policy in enumerate(session['resourcePolicyRequests']):
   policyCount+=1;uri=policy['uri'];permit=uri.startswith('ct:');message='' if permit else 'Refusing to read resource `'+uri+'` because it does not match any entry in the resource allowlist (`--allowed-resources`).';assert policy['allowed']==permit and policy['message']==message and isinstance(policy['token'],str)
   call=session['calls'][policy['callIndex']]
   if permit:allowed.append((policy['callIndex'],uri))
   else:
    denialCount+=1;assert fixture['oracle']=='java07' and fixture['caseId']=='duration-type-render' and call['index']==9 and uri=='prop:pkl.outputFormat';assert call['readsBefore']==call['readsAfter']==0;assert not [e for e in session['effects'] if e['callIndex']==call['index']];assert call['stderrUnits']==fixture['expected'][9]['stderrUnits'];denials.append({'target':target,'id':fixture['id'],'policy':policy,'call':call})
   if target=='native':
    prefix='resource-policy-'+str(i)
    for suffix,text in [('uri',uri),('message',message),('token',policy['token']),('allowed',str(permit).lower())]:assert (folder/(prefix+'.'+suffix+'.bin')).read_bytes()==text.encode('utf-8')
  assert allowed==[(e['callIndex'],e['uri']) for e in session['effects'] if e['kind']=='read']
 assert len(bad)==16 and counts['calls']==2108 and counts['ordinaryCompatible']==1984 and counts['rawMatches']==2080 and counts['intent-not-reachedRawMatches']==96 and denialCount==4
 results[target]=dict(counts);policyTotals[target]={'requests':policyCount,'denied':denialCount,'readerSideEffectOnDenied':0}
for root in [native,portable,build]:
 for name in (['report.json','comparison.json','inputs-before.json','inputs-final.json','payloads.json'] if root==native else ['execution.json','output-inventory.json'] if root==portable else ['report.json','build-proof.json','sources-before.json','sources-after.json']):record(root/name)
for path,digest in originalGuards.items():assert sha(path)==digest
(out/'input-and-payload-binding.json').write_text(json.dumps({'checkedDistinctRegularFiles':len(cache),'nativeInputs':len(nfinal),'nativePayloads':len(npayload['files']),'portablePayloads':len(ppayload['files']),'source430Stable':True,'freeze03CoreMatches':223,'authorizedExampleDelta':deltas,'artifacts':artifacts,'originalGuards':originalGuards},indent=2)+'\n')
(out/'failures.json').write_text(json.dumps(failures,indent=2)+'\n');(out/'resource-policy-denials.json').write_text(json.dumps(denials,indent=2)+'\n')
report={'schema':1,'status':'CLOSED_CANDIDATE03_RAW_PROVENANCE_AUDIT','recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':'Stage51 candidate03 only','producerTerminals':{'native':{'session':5809,'exitCode':0,'chunk':'f94da5','pid':nterminal['pid']},'portable':{'session':77146,'exitCode':1,'chunk':'e3ad57','pid':pterminal['pid']}},'results':results,'policy':policyTotals,'allOrderedEffectsMatch':True,'acquisitionIntegrityPassed':True,'ordinaryContractPassed':False,'fullJavaEventsCountersPassed':False,'fullCompatibilityPassed':False,'sourceChanges':[],'payloadChanges':[],'newEvaluatorRuns':0,'qualifications':['Live Rust successor never compared; source binding uses frozen430-byte inputs and223unchanged core paths plus declared new example delta','Build proof establishes captured source/command/artifact provenance, not independent binary decompilation or embedded-source identity proof','Explicit browser launch path/hash and HTTP served-input binding retained; browser OS PID is not recorded','Original Java fixture authority reused from pinned hermetic fixture verification; all fixture files also explicitly rehashed through declared native input map','Native acquisition wrapper0 is separate from ordinary compatibility false;12post-close raw failures remain separate from16ordinary failures','Java full administrative lifecycle and whole M2/performance remain open']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
