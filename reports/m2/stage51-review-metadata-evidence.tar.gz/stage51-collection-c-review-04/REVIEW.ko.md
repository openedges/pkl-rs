# freeze03 독립 소스 검토

이 기록은 freeze03의 원문 224개와 freeze02 대비 변경 20개를 검토한 소스 감사다. 새 evaluator·Java·Rust 검사를 실행하지 않았다. candidate03 전체 build·required5·실제 native/Node/Chromium 결과나 전체 M2의 완료 판정은 아니다.

최초 review03의 광범위 current hash 단언은 이미 승인된 native example 수정 한 개를 만나 실패했다. 원문 check와 실제 tool exit1은 그대로 두었다. review04는 고정 example의 candidate02 원문(동일 SHA)을 재사용하고 나머지 223개 core 원문을 일치 확인했다. 현재 example의 다른 SHA는 source-after에 별도로 기록하며 그 새 버전의 검사 결과로 승계하지 않는다.

## 검토 결과

- Duration.unit: enum별 OnceLock PklString 7개를 Clone한다. Java DurationNodes.unit/DurationUnit.getSymbol과 같이 같은 unit의 reference를 보존한다. 일반 사용자 문자열은 intern하지 않는다. Java08 same-enum-symbol의 첫/반복/GC 뒤 호출은 conversion hint가 없고, 같은 내용의 authored string converter에는 hint가 있으며 unit.toString 반환은 hint가 없다. 이 원시 관찰과 수정된 경로가 일치하는 설계다. 아직 새 Rust 차등 결과는 아니다.
- Literal/nullable: Member와 NullableMember가 같은 literal folding을 먼저 수행하고 나머지 nullable는 기존 continuation으로 간다. Java AstBuilder의 literal 검사 뒤 isNullable 순서와 같다. 같은 closure의 literal constant는 wrapper token을 보존하고, dynamic numeric getter·runtime Negate는 새 token을 발급한다. Java07의 literal/nullable 대 dynamic converter hint 관찰을 raw ledger에 연결했다. 이전 두 source finding은 수정된 것으로 분류한다.
- 값/동등성/hash: 실제 Duration은 f64 value+unit+token이고 clone/cache는 token을 보존한다. 정규화 nanos ==와 reference shortcut, NaN wrapper별 atom, signed zero equality 정규화와 독립 Java hash bits를 구분한다. Java07 NaN/zero/overflow/대표 key·마지막 value의 실제 결과를 보존한다. `.value`/표시는 유한 정수에 포화 i64 cast, `.isPositive`는 >=0이므로 -0 true/NaN false다. Number/Object의 가짜 값으로 처리하지 않는다. getClass·타입·PCF/JSON 거부·공통 진단이 같은 값 경로를 사용한다.
- EMPTY: strict constructor/end/transform, generic empty defaults와 Reference empty path에서 kind별 neutral empty 객체를 공유한다. parent/cast를 가진 wrapper는 합치지 않고 nonempty payload equality도 identity로 쓰지 않는다. weak cache는 generation-checked heap.get으로 확인하며 자체 GC root가 아니다. 실제 보유 root가 있으면 같은 object가 재사용되고, producer·callback 환경은 neutral empty에 저장되지 않는다. Java06 empty와 nonempty distinct-equal-content hint 관찰을 구분한다. weak cache 수거 방식 자체를 Java heap layout과 동일하다고 주장하지 않는다.
- GC 회귀: collect를 모든 poll 전후로 실행한다. 반환된 실제 값, 취소/오류 후 Rust caller가 재사용할 모듈, nested reentry 반환물을 caller가 보유하는 짧은 경계만 명시적 root로 추가한다. 전달/소비된 callback payload는 추가 root로 남기지 않는다. 40회 empty/producer 회수는 StaleHandle과 close slots0을 검사한다. 예전 yield-only helper의 약화는 최종 snapshot에 남지 않았다. 관찰된 개발 검사나 heap slots는 전체 RSS·성능의 증명이 아니다.
- Function amendment: parameterless amendment wrapper는 Java AmendFunctionNode SimpleRootNode처럼 실제 인자 전체를 원 function으로 전달하고 원 function이 arity를 검사한다. captured environment 길이 뒤의 실제 인자만 전달하므로 부족한 인자를 임의로 채우지 않는다. 명시적 object parameter body는 기존 Unsupported 경계이며 새 지원으로 세지 않는다. FunctionN property 진단은 실제 arity helper를 공유한다. 기존 Java04 Duration union 및 Java05 amendment 오류 전체 바이트 회귀는 별도 developer 검사에 연결되어 있다.

## 실제 근거와 한계

기존 Java06/07/08의 총 228/404/204 API를 report와 각각 status/stdout/stderr 및 UTF16 원시 파일 5개로 직접 연결했다(총 836 API/4180 payload). Java07 중 4 output.text는 prop:pkl.outputFormat 정책 거부로 renderer에 도달하지 않은 진단-only이며 Duration rendering 통과로 세지 않는다. Java08의 명시적 output renderer 관찰은 별도로 보존한다. 이 작업은 기존 Java 원문 readback일 뿐 Rust 비교가 아니다.

A의 실제31694 검사 report에는 fmt/clippy/collection+Duration20개가 0이고 230개 입력 전후가 동일하다. 224개 freeze03 원문은 그 입력의 정확한 부분집합이다. 전체 Rust5나 플랫폼 통과로 확대하지 않는다. source review에서 새 blocking concrete discrepancy는 찾지 않았다. Duration arithmetic/order/conversion/ISO/DataSize, 전체 alias/reflection/member 진단, 직접 quantity object transport와 full Java observer/기존 post-close/전체 inventory·성능은 계속 열린 의무다.
