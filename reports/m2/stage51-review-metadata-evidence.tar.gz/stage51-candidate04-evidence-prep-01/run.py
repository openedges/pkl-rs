"""Preserve the closed candidate04 executions without changing compatibility gates."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")

assert not (OUT / "report.json").exists()
(OUT / "archives").mkdir()
roots = {
    "build": "stage51-candidate04-build",
    "native": "stage51-native-candidate04-01",
    "portable": "stage51-portable-candidate04-01",
    "original": "stage51-original-adapter-candidate04-01",
    "required": "stage51-required-checks-candidate04-01",
    "m1": "stage51-m1-platforms-candidate04-01",
    "launches": "stage51-candidate04-launches-01",
    "receipts": "stage51-root-terminal-receipts-01",
}
assert json.loads((ROOT / "target/m2/stage51-native-candidate04-01/report.json").read_bytes())["complete"]
assert json.loads((ROOT / "target/m2/stage51-required-checks-candidate04-01/report.json").read_bytes())["complete"]
assert json.loads((ROOT / "target/m2/stage51-original-adapter-candidate04-01/report.json").read_bytes())["complete"]
assert all((ROOT / "target/m2/stage51-candidate04-launches-01" / mode / "terminal.json").is_file()
           for mode in ["native", "portable", "original", "m1"])
tool = ROOT / "tools/evidence.py"
tool_sha = sha(tool)
(OUT / "evidence.py").write_bytes(tool.read_bytes())
def inventory(source):
    files, directories = {}, {}
    for directory, children, names in os.walk(source, topdown=True, followlinks=False):
        p = Path(directory)
        assert stat.S_ISDIR(p.lstat().st_mode) and not p.is_symlink(), str(p)
        directories[str(p.relative_to(source))] = stat.S_IMODE(p.stat().st_mode)
        children.sort()
        for name in sorted(names):
            path = p / name
            info = path.lstat()
            assert stat.S_ISREG(info.st_mode), str(path)
            files[str(path.relative_to(source))] = {"sha256": sha(path), "bytes": info.st_size,
                                                    "mode": stat.S_IMODE(info.st_mode)}
    return {"files": files, "directories": directories}

before = {unit: inventory(ROOT / "target/m2" / name) for unit, name in roots.items()}
save("selection.json", {"roots": roots, "inventories": before, "exclusions": []})
report = {"schema": 1, "scope": "Closed candidate04 development evidence. Ordinary compatibility passes; post-close and regex failures remain failed. No full M2/product/performance claim.",
          "startedUtc": now(), "runnerSha256": sha(Path(__file__)), "evidenceToolSha256": tool_sha,
          "commands": [], "archives": [], "complete": False}
save("report.json", report)
def execute(label, argv):
    row = {"label": label, "argv": list(map(str, argv)), "startedUtc": now()}
    with (OUT / (label + ".stdout.bin")).open("wb") as stdout, (OUT / (label + ".stderr.bin")).open("wb") as stderr:
        child = subprocess.Popen(row["argv"], stdout=stdout, stderr=stderr)
        row["pid"] = child.pid
        save("active.json", row)
        print("START", label, child.pid, flush=True)
        row["exitCode"] = child.wait()
    row.update(finishedUtc=now(), stdoutSha256=sha(OUT / (label + ".stdout.bin")), stderrSha256=sha(OUT / (label + ".stderr.bin")))
    report["commands"].append(row)
    save("report.json", report)
    assert row["exitCode"] == 0, label

try:
    for unit, name in roots.items():
        source = ROOT / "target/m2" / name
        archive = OUT / "archives" / ("stage51-candidate04-" + unit + ".tar.gz")
        execute(unit + "-create", [sys.executable, "-B", OUT / "evidence.py", "create", source, archive])
        execute(unit + "-verify", [sys.executable, "-B", OUT / "evidence.py", "verify", archive])
        assert archive.stat().st_size < 100_000_000
        report["archives"].append({"unit": unit, "path": str(archive), "sha256": sha(archive),
                                   "bytes": archive.stat().st_size, "sourceFiles": len(before[unit]["files"]),
                                   "scope": "Original closed source tree retained in full; no exclusions or deduplication."})
        save("report.json", report)
    after = {unit: inventory(ROOT / "target/m2" / name) for unit, name in roots.items()}
    save("selection-after.json", {"roots": roots, "inventories": after, "exclusions": []})
    report["originalsStable"] = before == after
    report["toolStable"] = sha(tool) == tool_sha
    assert report["originalsStable"] and report["toolStable"]
    report["complete"] = True
except Exception as error:
    report["error"] = repr(error)
finally:
    report["finishedUtc"] = now()
    save("report.json", report)
    print(json.dumps({k: report.get(k) for k in ["complete", "originalsStable", "toolStable", "error"]}), flush=True)
raise SystemExit(0 if report["complete"] else 1)
