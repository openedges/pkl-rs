from pathlib import Path
import json,hashlib,datetime,subprocess,shutil,os,sys
base=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51'); out=Path(__file__).resolve().parent
names=['tools/platform/compare-collection-transforms.mjs','tools/platform/compare-collection-transforms.test.mjs','tools/platform/collection-transform-session.mjs','tools/platform/module-policy-session.mjs','tools/platform/resource-session.mjs','tools/collection_transform_fixtures.py']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
node=Path(shutil.which('node')).resolve();before={n:{'sha256':sha(base/n),'bytes':(base/n).stat().st_size} for n in names};before['NODE']={'path':str(node),'sha256':sha(node)}
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
for n in names:
 p=out/'sources'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((base/n).read_bytes())
start=datetime.datetime.now(datetime.timezone.utc).isoformat();cmd=[str(node),'--test','tools/platform/compare-collection-transforms.test.mjs'];p=subprocess.run(cmd,cwd=base,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
for c in ['stdout','stderr']:(out/(c+'.bin')).write_bytes(getattr(p,c))
after={n:{'sha256':sha(base/n),'bytes':(base/n).stat().st_size} for n in names};after['NODE']={'path':str(node),'sha256':sha(node)};(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n');changes=[n for n in before if before[n]!=after[n]]
report={'schema':1,'scope':'Portable driver mock regression only; no repeated helper tests or actual evaluator/browser runs','startedUtc':start,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'argv':cmd,'cwd':str(base),'exitCode':p.returncode,'sourceChanges':changes,'node':before['NODE']};(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));sys.exit(0 if p.returncode==0 and not changes else 1)
