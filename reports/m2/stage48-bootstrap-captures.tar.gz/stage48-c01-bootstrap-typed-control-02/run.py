from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
PLATFORMS=ROOT/'target/m2/stage48-c01-platform-control-01/primitives'
ORACLE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42/target/m2/stage45-bootstrap-oracle-02')
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
release=ROOT/'target/m2/stage48-implementation-01/admission-candidate-build-01/release.json';assert sha(release)=='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0'
r=json.loads(release.read_bytes());mapping=json.loads(Path(r['source_map']).read_bytes());scripts=['tools/platform/compare-bootstrap.mjs','tools/platform/bootstrap-session.mjs','tools/platform/module-policy-session.mjs','tools/platform/package.json','tools/platform/package-lock.json']
allowed={'tools/platform/bootstrap-session.mjs':'ad5555374d13755e9904d0b05f6e1808463087acda868a27d74f850358e835f0'}
assert all(sha(ROOT/p)==allowed.get(p,mapping[p])for p in scripts)
write('consumer-source-delta.json',{'baseReleaseSha256':sha(release),'sourceOnlyConsumerChanges':{p:{'candidateSha256':mapping[p],'currentSha256':h}for p,h in allowed.items()},'reason':'Typed Resource text completions exercise the shared successful-read cache; original legacy respondString run remains preserved.','runtimeArtifactsUnchanged':True})
inputs=[*(ROOT/p for p in scripts),PLATFORMS/'pkl_napi.node',*(PLATFORMS/'wasm').iterdir(),ORACLE/'report.json',ORACLE/'closure.json',ORACLE/'inventory.json',ORACLE/'cases.json']
before={str(p):sha(p)for p in inputs if p.is_file()}
command=['node',str(ROOT/'tools/platform/compare-bootstrap.mjs'),str(OUT/'execution'),str(PLATFORMS/'wasm'),str(PLATFORMS/'pkl_napi.node'),str(ORACLE),str(ROOT/'tools/platform/package.json')]
row={'scope':'Actual C01 Node/Chromium bootstrap raw comparison. Known unsupported/mismatch outcomes are retained. Platform build/source binding is separately recorded by stage48-c01-platform-control-01.','command':command,'cwd':str(ROOT),'startedUtc':datetime.datetime.now(datetime.UTC).isoformat(),'releaseSha256':sha(release),'inputHashesBefore':before,'parentPid':os.getpid()}
with(OUT/'stdout.bin').open('wb')as stdout,(OUT/'stderr.bin').open('wb')as stderr:
 p=subprocess.Popen(command,cwd=ROOT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=stdout,stderr=stderr);row['pid']=p.pid;write('launch.json',row);row['exitCode']=p.wait()
row.update(finishedUtc=datetime.datetime.now(datetime.UTC).isoformat(),inputHashesAfter={p:sha(Path(p))for p in before},stdoutSha256=sha(OUT/'stdout.bin'),stderrSha256=sha(OUT/'stderr.bin'),liveHandles=[])
write('terminal.json',row)
print(json.dumps({'exitCode':row['exitCode'],'inputsStable':before==row['inputHashesAfter']}),flush=True)
raise SystemExit(row['exitCode'] if before==row['inputHashesAfter'] else 2)
