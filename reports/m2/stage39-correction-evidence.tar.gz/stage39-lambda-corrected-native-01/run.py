"""Compare a supplied frozen native adapter to closed Java controls, without resetting original workspaces."""
from pathlib import Path
import hashlib,json,sys,shutil,time
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-lambda-corrected-native-01'
sys.path.insert(0,str(ROOT/'tools'));import compat,m1_platforms
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(compat.encoded(x))
def tree(root):return {p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def verified_origin(name):
 origin=ROOT/'target/m2'/name;cl=json.loads((origin/'closure.json').read_text());inv=json.loads((origin/'inventory.json').read_text())
 assert cl['inventorySha256']==sha(origin/'inventory.json') and cl['reportSha256']==sha(origin/'report.json')
 for row in inv['files']:assert sha(origin/row['path'])==row['sha256'],row['path']
 return origin,json.loads((origin/'report.json').read_text()),{'path':str(origin),'closureSha256':sha(origin/'closure.json'),'inventorySha256':sha(origin/'inventory.json'),'reportSha256':sha(origin/'report.json'),'allFilesBefore':tree(origin)}
def main():
 if len(sys.argv)!=2:raise SystemExit('usage: run.py FROZEN_MODULE_EVAL_PROBE')
 candidate=Path(sys.argv[1]).resolve();assert candidate.is_file();assert not (OUT/'report.json').exists();binary=OUT/'artifacts/module_eval_probe';binary.parent.mkdir();shutil.copy2(candidate,binary)
 source_paths=list(m1_platforms.source_paths())+[ROOT/'crates/pkl-runtime/examples/module_eval_probe.rs',ROOT/'tools/compat.py',ROOT/'tools/platform/module-eval-session.mjs',ROOT/'tools/platform/compare-module-eval.mjs',ROOT/'tools/platform/module-eval-session.test.mjs'];sources={str(p.relative_to(ROOT)):sha(p) for p in dict.fromkeys(source_paths)}
 for path in sources:
  dest=OUT/'sources'/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/path,dest)
 write(OUT/'sources-before.json',sources)
 candidate_root=candidate.parent.parent;build_process=candidate_root/'build.process.json';build=json.loads(build_process.read_text());assert build['exit_code']==0 and not build.get('timed_out',False)
 candidate_sources={p.relative_to(candidate_root/'sources').as_posix():sha(p) for p in (candidate_root/'sources').rglob('*') if p.is_file()}
 for p in ['crates/pkl-runtime/src/parser.rs','crates/pkl-runtime/src/evaluation/frontend.rs','crates/pkl-runtime/examples/module_eval_probe.rs']:assert p in candidate_sources,p
 for p,h in candidate_sources.items():assert sha(ROOT/p)==h,p
 write(OUT/'candidate-source-binding.json',{'buildProcessPath':str(build_process),'buildProcessSha256':sha(build_process),'candidateOrigin':str(candidate),'candidateSha256':sha(candidate),'candidateSourceSnapshotHashes':candidate_sources,'allCandidateSnapshotsMatchCurrentSources':True})
 origins=[verified_origin(n) for n in ['stage39-lambda-keyword-review-01','stage39-lambda-declaration-oracle-01','stage39-lambda-commit-oracle-01']]
 profile_path=ROOT/'target/m2/stage39-original72-java-01/profile.json';profile=json.loads(profile_path.read_text());bindings=[]
 for origin,report,binding in origins:
  observations=[r for r in report['records'] if r.get('runtime','java')=='java']
  for record in observations:
   old=next(p for p in origin.glob('cases/**/process.json') if json.loads(p.read_text())==record)
   java=compat.load_capture(old.parent);assert java['exit_code'] in (0,1) and not java['timed_out'] and not java['files'] and not java['workspace_changes']
   source=Path(record['cwd'])/record['command'][-1];assert source.as_uri()==record['sourceUri'] and sha(source)==record['sourceSha256']
   prefix=record['command'][:len(profile['command'])]
   for a,b in zip(prefix,profile['command'],strict=True):assert a==b or a.startswith('-Duser.home=') and b.startswith('-Duser.home=') or a.startswith('-Djava.io.tmpdir=') and b.startswith('-Djava.io.tmpdir=')
   args=record['command'][len(profile['command']):];assert args[0]=='eval' and '--test-mode' not in args
   bindings.append((origin,record,old,java,source,args))
 write(OUT/'input-bindings.json',{'origins':[b for _,_,b in origins],'candidateOrigin':str(candidate),'candidateSha256':sha(candidate),'profilePath':str(profile_path),'profileSha256':sha(profile_path),'scope':'20 exact original authored/physical source paths, Java repeats2 each. Original .state/generated paths are reused without deletion/reset; only native is executed.'})
 results=[]
 for origin,record,old,java,source,args in bindings:
  cwd=Path(record['cwd']);before=compat.snapshot(cwd);env={**profile['environment'],**record['environment']};command=[str(binary),*args];generated=cwd/'generated'/compat.case_directory(record['id']);started=time.time_ns()
  try:result=compat.capture(command,cwd,env,60,generated)
  except compat.CaptureTimeout as error:result=error.result
  after=compat.snapshot(cwd);changes={n:{'before':before.get(n),'after':after.get(n)} for n in before.keys()|after.keys() if before.get(n)!=after.get(n)};result['workspace_changes']=changes;result['files']={f'generated/{n}':b for n,b in result['files'].items()}
  for n in changes:
   p=cwd/n
   if p.is_file() or p.is_symlink():result['files']['workspace/'+n]=compat.resource_bytes(p)
  dest=OUT/'cases'/record['id']/str(record['repeat']);meta=compat.store_capture(dest/'rust',result)
  for n in ['stdout.bin','stderr.bin','result.json','process.json']:p=dest/'java'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old.parent/n,p)
  for runtime,capture in [('java',java),('rust',result)]:
   (dest/runtime/'exit-code.bin').write_bytes((str(capture['exit_code'])+'\n').encode());write(dest/runtime/'files.json',{n:compat.digest(b) for n,b in capture['files'].items()})
  differences=compat.differences(java,result);status='pass' if java['exit_code']==1 and not differences and result['exit_code']==1 else 'unsupported' if java['exit_code']==0 and result['exit_code']==2 and not result['stdout'] and not result['files'] and not result['workspace_changes'] and not result['timed_out'] else 'mismatch'
  process={'command':command,'cwd':str(cwd),'environment':record['environment'],'startedUnixNs':started,'finishedUnixNs':time.time_ns(),'sourceUri':record['sourceUri'],'sourceSha256':sha(source),'candidateSha256':sha(binary),'javaCapturePath':str(old.parent),'javaProcessSha256':sha(old),'result':meta};write(dest/'rust/process.json',process)
  comparison={'id':record['id'],'repeat':record['repeat'],'status':status,'rawMatch':not differences,'differences':differences,'javaExitCode':java['exit_code'],'candidateExitCode':result['exit_code'],'sourceUri':record['sourceUri'],'sourceSha256':record['sourceSha256']};write(dest/'comparison.json',comparison);results.append(comparison);print(json.dumps(comparison),flush=True)
  assert not changes,'Unexpected writes retained; stop without restoring immutable inputs'
 after_sources={p:sha(ROOT/p) for p in sources};origin_stability={b['path']:tree(Path(b['path']))==b['allFilesBefore'] for _,_,b in origins}
 report={'scope':'Actual corrected-native CLI adapter comparison; ordinary rejection passes require full stdout/stderr/exit/files equality. Java-success/Rust-output-Unsupported remains unsupported and never passes. No Java run or rebuild.','candidateOrigin':str(candidate),'candidateSha256':sha(binary),'candidateArtifactStable':sha(candidate)==sha(binary),'sourceStability':sources==after_sources,'originStability':origin_stability,'sourceHashesBefore':sources,'sourceHashesAfter':after_sources,'caseCount':20,'processCount':len(results),'statusCounts':{k:sum(x['status']==k for x in results) for k in ['pass','unsupported','mismatch']},'results':results};write(OUT/'report.json',report)
 assert report['sourceStability'] and report['candidateArtifactStable'] and all(origin_stability.values())
 rows=[{'path':p.relative_to(OUT).as_posix(),'size':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.rglob('*')) if p.is_file() and p.relative_to(OUT).as_posix() not in ('inventory.json','closure.json','stdout.log','stderr.log')];write(OUT/'inventory.json',{'files':rows,'scope':'All regular files excluding only root inventory/closure and terminal-wrapper stdout.log/stderr.log, not evidence authority.'});write(OUT/'closure.json',{'inventorySha256':sha(OUT/'inventory.json'),'reportSha256':sha(OUT/'report.json'),'fileCount':len(rows),'frozen':True})
 return 1 if report['statusCounts']['mismatch'] else 0
if __name__=='__main__':raise SystemExit(main())
