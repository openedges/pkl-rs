import json,sys,hashlib
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-lambda-declaration-oracle-01';WORK=OUT/'workspace';JAVA=ROOT/'target/m2/stage39-original72-java-01'
sys.path.insert(0,str(ROOT/'tools'));import compat
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(compat.encoded(x))
profile=json.loads((JAVA/'profile.json').read_text());base=json.loads((JAVA/'original72.json').read_text())[0]['upstream_case'];WORK.mkdir()
cases=[('identifier','local f = (x, y) -> x\nresult = 7\n'),('quoted','local f = (`true`, y) -> `true`\nresult = 7\n'),('underscore','local f = (_) -> 7\nresult = 7\n'),('empty','local f = () -> 7\nresult = 7\n'),('false-group','result = (false)\n'),('null-group','result = (null)\n')]
for name,source in cases:(WORK/(name+'.pkl')).write_bytes(source.encode())
baseline=compat.snapshot(WORK);write(OUT/'workspace-baseline.json',baseline)
write(OUT/'profile.json',{'oracleProfile':str(JAVA/'profile.json'),'oracleProfileSha256':sha(JAVA/'profile.json'),'jarSha256':sha(Path(profile['artifact'])),'profile':profile,'scope':'Supplemental valid declaration/group controls; Java-only original CLI, no native source/binary/build claim.'})
records=[]
for name,source in cases:
 original={**base,'id':'stage39-lambda-declaration-'+name,'command':base['command'][:-1]+[name+'.pkl']}
 for repeat in [0,1]:
  cmd,env,generated,recorded=compat.case_execution(original,profile['command'],profile['environment'],WORK);before=compat.snapshot(WORK);assert before==baseline
  try:result=compat.capture(cmd,WORK,env,60,generated)
  except compat.CaptureTimeout as e:result=e.result
  after=compat.snapshot(WORK);changes={n:{'before':before.get(n),'after':after.get(n)} for n in before.keys()|after.keys() if before.get(n)!=after.get(n)}
  result['workspace_changes']=changes;result['files']={f'generated/{k}':v for k,v in result['files'].items()}
  for n in changes:
   p=WORK/n
   if p.is_file() or p.is_symlink():result['files']['workspace/'+n]=compat.resource_bytes(p)
  dest=OUT/'cases'/name/str(repeat);meta=compat.store_capture(dest,result);private=compat.output_files(WORK/'.state'/compat.case_directory(original['id']))
  for n,b in private.items():p=dest/'private-state'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  record={'id':original['id'],'repeat':repeat,'command':cmd,'cwd':str(WORK),'environment':recorded,'sourceUri':(WORK/(name+'.pkl')).as_uri(),'sourceSha256':sha(WORK/(name+'.pkl')),'result':meta,'privateFiles':{n:compat.digest(b) for n,b in private.items()}}
  write(dest/'process.json',record);records.append(record);print(json.dumps({'name':name,'repeat':repeat,'exit':result['exit_code'],'stdout':result['stdout'].decode(),'stderr':result['stderr'].decode()}),flush=True);assert not changes
assert sha(Path(profile['artifact']))==json.loads((OUT/'profile.json').read_text())['jarSha256']
write(OUT/'report.json',{'scope':'Fresh pinned Java CLI acceptance controls only. No Rust compatibility claim. Distinct from the original9 immediate-call errors.','caseCount':len(cases),'processCount':len(records),'records':records,'sourceBaselineStable':compat.snapshot(WORK)==baseline,'jarStable':True,'reviewProseCorrection':'Closed independent-code-review-01 FINDINGS uses illustrative lambda_or_expression name; actual reviewed location is parser.rs expression-machine branch line1456, whose exact preserved snapshot and hash are authoritative.'})
rows=[{'path':p.relative_to(OUT).as_posix(),'sha256':sha(p),'size':p.stat().st_size} for p in sorted(OUT.rglob('*')) if p.is_file() and p.relative_to(OUT).as_posix() not in ('inventory.json','closure.json','stdout.log','stderr.log')]
write(OUT/'inventory.json',{'files':rows,'scope':'All regular files excluding only root inventory/closure and live wrapper stdout.log/stderr.log; wrapper logs are not evidence authority.'})
write(OUT/'closure.json',{'inventorySha256':sha(OUT/'inventory.json'),'reportSha256':sha(OUT/'report.json'),'fileCount':len(rows),'frozen':True})
