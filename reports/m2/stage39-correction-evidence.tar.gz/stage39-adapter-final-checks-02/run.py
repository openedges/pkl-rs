from pathlib import Path
import subprocess,json,hashlib,time
ROOT=Path.cwd(); OUT=ROOT/'target/m2/stage39-adapter-final-checks-02'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def enc(d):return (json.dumps(d,indent=2,sort_keys=True)+'\n').encode()
previous=json.loads((ROOT/'target/m2/stage39-adapter-final-checks-01/source-freeze.json').read_bytes())
paths=list(previous['sources'])
before={n:sha(ROOT/n) for n in paths}
results=[]
for name,cmd in [('module-tool',['python3','-m','unittest','tools/tests/test_m2_module_eval.py']),('language-tool',['python3','-m','unittest','tools/tests/test_m2_language.py']),('manifest',['python3','tools/m2_manifest.py','--check'])]:
 t=time.time();r=subprocess.run(cmd,cwd=ROOT,capture_output=True)
 for channel,data in [('stdout',r.stdout),('stderr',r.stderr)]: (OUT/f'{name}.{channel}.bin').write_bytes(data)
 row={'name':name,'command':cmd,'cwd':str(ROOT),'exit_code':r.returncode,'elapsed_seconds':time.time()-t,'stdout_sha256':sha(OUT/f'{name}.stdout.bin'),'stderr_sha256':sha(OUT/f'{name}.stderr.bin')}
 (OUT/f'{name}.process.json').write_bytes(enc(row));results.append(row);print(name,r.returncode,flush=True)
after={n:sha(ROOT/n) for n in paths}
report={'checks':results,'source_stability':before==after,'sources':after,'A_freeze_sha256':sha(ROOT/'target/m2/stage39-core-keyword-validation-02/freeze.json'),'manifest_refresh_report_sha256':sha(ROOT/'target/m2/stage39-manifest-refresh-02/report.json')}
(OUT/'report.json').write_bytes(enc(report))
freeze={'frozen':True,'sources':after,'scope':'B adapter/tool source unchanged; generated manifest link SHA only refreshed after A narrow parser correction. No planned edits absent findings.','A_freeze_sha256':report['A_freeze_sha256'],'checks_report_sha256':sha(OUT/'report.json')}
(OUT/'source-freeze.json').write_bytes(enc(freeze))
print(json.dumps({'source_stability':report['source_stability'],'freeze_sha256':sha(OUT/'source-freeze.json'),'report_sha256':sha(OUT/'report.json')}),flush=True)
raise SystemExit(0 if before==after and all(r['exit_code']==0 for r in results) else 1)
