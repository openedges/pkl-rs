import json,sys,shutil,hashlib,time
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-lambda-keyword-review-01';WORK=OUT/'workspace';JAVA=ROOT/'target/m2/stage39-original72-java-01';NATIVE=ROOT/'target/m2/stage39-module-eval-corrected-01'
sys.path.insert(0,str(ROOT/'tools'));import compat,oracle
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(compat.encoded(x))
profile=json.loads((JAVA/'profile.json').read_text());base=json.loads((JAVA/'original72.json').read_text())[0]['upstream_case'];WORK.mkdir();(OUT/'artifacts').mkdir();binary=OUT/'artifacts/module_eval_probe';shutil.copy2(NATIVE/'artifacts/module_eval_probe',binary)
source_paths=['crates/pkl-runtime/src/parser.rs','crates/pkl-runtime/src/parser/string_lexer.rs','crates/pkl-runtime/src/parser/type_parser.rs','crates/pkl-runtime/src/evaluation/frontend.rs','crates/pkl-runtime/src/evaluation/frontend/arguments.rs','crates/pkl-runtime/src/diagnostic.rs','crates/pkl-runtime/examples/module_eval_probe.rs'];source_hashes={p:sha(ROOT/p) for p in source_paths}
for p in source_paths:
 snapshot=NATIVE/'sources'/p;assert snapshot.is_file() and sha(snapshot)==source_hashes[p],p
 dst=OUT/'sources'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,dst)
write(OUT/'profile.json',{'javaProfilePath':str(JAVA/'profile.json'),'javaProfileSha256':sha(JAVA/'profile.json'),'javaArtifactSha256':sha(Path(profile['artifact'])),'nativeOrigin':str(NATIVE/'artifacts/module_eval_probe'),'nativeBuildProcessPath':str(NATIVE/'build.process.json'),'nativeBuildProcessSha256':sha(NATIVE/'build.process.json'),'nativeArtifactSha256':sha(binary),'sourceHashesBefore':source_hashes,'scope':'Fresh original-authored generic controls, no original72 substitution or source rebuild.'})
cases=[('true-comma','result = (true, 1)\n','keyword-error'),('false-colon','result = (false: Int)\n','keyword-error'),('null-comma','result = (null, 1)\n','keyword-error'),('this-comma','result = (this, 1)\n','keyword-error'),('identifier-lambda','result = ((x, y) -> x)(1, 2)\n','accepted-lambda'),('quoted-lambda','result = ((`true`, y) -> `true`)(1, 2)\n','accepted-lambda'),('underscore-lambda','result = ((_) -> 7)(1)\n','accepted-lambda'),('empty-lambda','result = (() -> 7)()\n','accepted-lambda'),('true-group','result = (true)\n','accepted-group')]
for name,source,_ in cases:(WORK/(name+'.pkl')).write_bytes(source.encode())
baseline=compat.snapshot(WORK);write(OUT/'workspace-baseline.json',baseline);records=[]
for name,source,kind in cases:
 original={**base,'id':'stage39-lambda-'+name,'command':base['command'][:-1]+[name+'.pkl']}
 for repeat in [0,1]:
  results={}
  for runtime,prefix in [('java',profile['command']),('rust',[str(binary)])]:
   command,env,generated,recorded=compat.case_execution(original,prefix,profile['environment'],WORK);before=compat.snapshot(WORK);assert before==baseline
   try:result=compat.capture(command,WORK,env,60,generated)
   except compat.CaptureTimeout as e:result=e.result
   after=compat.snapshot(WORK);changes={n:{'before':before.get(n),'after':after.get(n)} for n in before.keys()|after.keys() if before.get(n)!=after.get(n)}
   result['workspace_changes']=changes;result['files']={f'generated/{k}':v for k,v in result['files'].items()}
   for n,change in changes.items():
    p=WORK/n
    if p.is_file() or p.is_symlink():result['files']['workspace/'+n]=compat.resource_bytes(p)
   directory=OUT/'cases'/name/str(repeat)/runtime;metadata=compat.store_capture(directory,result)
   private=compat.output_files(WORK/'.state'/compat.case_directory(original['id']))
   for n,b in private.items():
    p=directory/'private-state'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
   process={'id':original['id'],'kind':kind,'runtime':runtime,'repeat':repeat,'command':command,'cwd':str(WORK),'environment':recorded,'sourceSha256':sha(WORK/(name+'.pkl')),'sourceUri':(WORK/(name+'.pkl')).as_uri(),'result':metadata,'privateFiles':{n:compat.digest(b) for n,b in private.items()}}
   write(directory/'process.json',process);results[runtime]=result;records.append(process);assert not changes,'Unexpected public writes preserved; do not reset'
  differences=compat.differences(results['java'],results['rust']);print(json.dumps({'case':name,'repeat':repeat,'javaExit':results['java']['exit_code'],'rustExit':results['rust']['exit_code'],'differences':differences,'javaStderrHead':results['java']['stderr'].decode().splitlines()[:3],'rustStderrHead':results['rust']['stderr'].decode().splitlines()[:3]}),flush=True)
comparisons=[]
for name,source,kind in cases:
 for repeat in [0,1]:
  directory=OUT/'cases'/name/str(repeat);java=compat.load_capture(directory/'java');rust=compat.load_capture(directory/'rust');comparisons.append({'id':'stage39-lambda-'+name,'kind':kind,'repeat':repeat,'javaExit':java['exit_code'],'rustExit':rust['exit_code'],'differences':compat.differences(java,rust),'status':'mismatch' if kind=='keyword-error' else 'unsupported-output' if rust['exit_code']==2 else 'inspect'})
source_after={p:sha(ROOT/p) for p in source_paths};assert source_after==source_hashes and sha(binary)==sha(NATIVE/'artifacts/module_eval_probe')
write(OUT/'report.json',{'scope':'Confirmed generic lambda keyword lookahead regression using pinned CLI and existing frozen native binary; no source/build changes. Accepted lambdas/groups retain output Unsupported, not compatibility passes.','caseCount':len(cases),'processCount':len(records),'records':records,'comparisons':comparisons,'sourceHashesBefore':source_hashes,'sourceHashesAfter':source_after,'sourceStability':source_after==source_hashes,'nativeArtifactStable':True,'nativeArtifactSha256':sha(binary)})
