The four keyword controls reproduce a parser first-error regression in both repeats. Java rejects the comma/colon after true, false, null, or this and expects `)`. Rust speculatively commits a lambda and rejects the keyword itself. Stdout and exit 1 agree; complete stderr differs.

The four sources labeled `accepted-lambda` in the original acquisition script actually use invalid immediate invocation syntax. Both CLIs reject them with byte-identical ordinary errors. The label describes initial intent and is not acceptance evidence. `(true)` succeeds in Java and is explicitly unsupported at the Rust module-output boundary. None of these successful Java outputs is reported as Rust compatibility.

All 36 processes are terminal; source and binary identities stayed stable for this acquisition. Source fixes authorized later do not alter this pre-fix evidence.
