# Stage40 실제 모듈 출력 구현 설계

## 결정과 범위

Stage40의 구현 단위는 실제 `output.bytes` 평가, `ModuleOutput` 기본 객체 그래프, `PcfRenderer` 및 이를 실행하는 얕은 강제 평가다. 기존 원본 입력의 `eval` 명령을 그대로 실행하는 첫 출력 경로를 만든다. 파서가 허용한 모듈을 성공으로 반환하거나 `module.toString()`을 문서 출력으로 바꾸지 않는다. 전체 M2 범위와 남은 원본 ID는 유지한다. 이 문서는 읽기 전용 설계이며 구현·호환성 결과가 아니다.

앞선 `stage39-next-scope-design-01`의 30개 원본 계약을 그대로 복사해 추적한다. 첫 출력 묶음 A는 10개이며 아래에 모두 적었다. B의 로컬·내장 모듈 로더와 `pkl:test`, C의 Mixin/reflection/추가 renderer는 명시적 후속 구현이다. M3/M4라는 분류를 이유로 원본 M2 eval의 실제 의존성을 무기한 미루지 않는다.

Stage39 오류 72개는 전체 모듈 파싱·최초 오류·원시 CLI 진단 계약으로 유지한다. Java ParserImpl와 Rust Lexer 사이의 producer phase 차이는 그대로 기록한다. Stage39 람다 lookahead의 별도 회귀 검토가 진행 중이므로 이 설계의 소스 해시는 그 검토 당시의 상태만 뜻한다.

## 실제 호출 경로와 최소 API

Pinned `EvaluatorImpl.evaluateOutputBytes`는 모듈을 초기화한 뒤 `VmUtils.readModuleOutput`으로 `output`을 읽고 정확한 `ModuleOutput` 클래스인지 확인한 다음 `bytes`를 읽는다. 모듈 전체를 먼저 깊게 force하지 않는다. CLI는 이 완료 바이트를 출력하고, 실패한 renderer의 부분 builder를 stdout으로 내보내지 않는다.

공통 runtime의 제안 경계는 다음과 같다. 명칭은 구현 전 B와 확정하되 동작 경계는 고정한다.

- 내부 `PreparedModule`: source, inferred/declared module identity, parsed/resolved/compiled Program, typed preparation failure를 보유한다. `evaluation/frontend.rs`의 오류 준비 경로와 실제 평가가 같은 준비 함수를 사용한다. 이미 만들어진 Diagnostic을 String으로 바꾼 뒤 원인을 재분류하지 않는다.
- 내부 `EvaluationOperation::OutputBytes`를 추가한다. 기존 SourceSession의 표현식 문자열 operation은 별도로 유지한다. 공통 module/bootstrap/cache/Host 수명 관리 코드를 공유하며 두 번째 lifecycle 구현을 복제하지 않는다.
- 출력 entry는 실제 module 입력 → `output` 읽기 → 정확한 ModuleOutput identity 검사 → `bytes` 읽기 → Bytes 반환이다. `ToString`과 `repl:text` metadata가 없다. builtin property/method와 사용자 property의 실제 논리 프레임을 사용한다.
- 시작은 기존 `HostSession::start_then(module_entry, ..., output_entry, now, timeout)`을 사용한다. setup 성공 중간 module을 root로 보유하고, setup 실패와 output 실패를 구분한다. setup의 logger callback이 close하더라도 이미 시작한 출력 operation은 같은 context/deadline에서 완료될 수 있어야 한다. 이후 새 start/reentry는 계속 거부한다.
- 완료 payload는 기존 `Value::Bytes(Arc<[u8]>)`의 소유 바이트다. native는 그대로 stdout에 쓰고 Wasm/N-API는 byte array를 반환한다. 플랫폼에서 객체를 순회하거나 PCF를 재직렬화하지 않는다. exported bytes는 close/GC 뒤에도 안정적이어야 한다.
- 개발 adapter 상태는 ordinary language failure, explicit capability gap, limit, internal failure를 구분한다. 실제 실행 실패에는 execution phase를 추가하되 기존 Rust producer metadata를 Java의 내부 구조에 맞추어 위장하지 않는다.

현재 `SourceSession::compile`은 property path마다 `ToString`과 REPL frame을 붙이므로 그 entry를 그대로 재사용할 수 없다. `HostPoll`은 이미 generic Value completion과 Read/Log/Yielded를 지원하므로 출력 바이트만을 위해 별도 Host I/O 요청 종류를 추가할 필요는 없다.

## 변경 표면과 구현 순서

| 순서 | 공통 파일/새 모듈 제안 | 필요한 변경 |
| --- | --- | --- |
| 1 | `evaluation.rs`, `evaluation/frontend.rs`, `evaluation/session.rs` | typed preparation 추출, operation별 entry, output byte completion, CLI runtime frame profile. 기존 scalar와 source-session raw bytes 유지 |
| 2 | `vm.rs`, `vm/reference.rs`, 새 `vm/builtins.rs` 또는 `vm/output.rs`, `heap.rs` | builtin identity/parent/abstract/open registry, 실제 Module prototype, lazy output definitions, ModuleOutput exact-class 검사 |
| 3 | `vm/forcing.rs`, `vm.rs`의 Frame/GC/failure cleanup | recurse/allowUndefined를 분리한 ForceMode, 얕은 member force와 caller continuation, 기존 trace/hash/object-string 동작 유지 |
| 4 | 새 `vm/rendering.rs`, converter/path 모듈 | Pcf document/value continuation, 옵션·converter·member 방문 순서, key hash/equality, undefined 및 conversion hint |
| 5 | 새 공통 PCF string formatter, `pkl_string.rs`/`vm/strings.rs`의 필요한 공유 primitive | UTF-16 PCF 포맷, custom delimiters/multiline, UTF-8 encodeToBytes의 실제 언어 경로 |
| 6 | `host/resources.rs`, 평가 설정 | ordered property/env 옵션의 실제 소비, nullable absence, 기본 output format. 기존 URI/policy 오류의 정상 resume 경로 유지 |
| 7 | B 소유 native/Wasm/N-API 및 원본 adapter | 동일 operation/options, raw bytes와 stderr logs/오류 전달, 입력·argv·cwd·파일 계약 유지 |

기존 `annotations.rs::builtin_members`의 실제 base.pkl span을 가진 ordinary lazy block 생성 방식과 `strings.rs::repeat_block`의 정상 메서드 frame 방식을 재사용할 수 있다. 표의 2번은 모든 builtin을 한 번에 재작성하라는 뜻이 아니다. 다만 annotation 전용 ID/name 조건을 출력 이름 조건으로 더 복제하지 말고 해당 클래스의 정의를 같은 identity registry로 확장한다.

`Module`, `FileOutput`, `ModuleOutput`, `BaseValueRenderer`, `ValueRenderer`, `BytesRenderer`, `PcfRenderer`의 identity·상속·abstract/final/open 플래그와 member 타입은 실재해야 한다. 사용자 선언의 같은 이름을 전역 문자열 비교로 가로채지 않는다. 현재 module 객체는 parent 없이 만들어지고 `getClass()`가 module class를 합성하므로, 실제 Module prototype을 부모로 연결하면서 자체 ModuleClass identity를 보존해야 한다. 여러 모듈 identity까지 완료했다는 뜻은 아니다.

`Module.output`은 inherited hidden property로 제공한다. 사용자 모듈 AST에 `output` 소스를 주입하거나 무조건 own property를 추가하지 않는다. `value = outer`, renderer/text/bytes의 lazy default, output amendment, 사용자 text/bytes override, ModuleOutput.files nullable 선언을 정상 property 평가로 처리한다. 파일 출력 API 실행은 후속 범위라도 숨겨진 files를 잘못 force해서 단일 출력에 영향을 주어서는 안 된다.

## evaluator 상태 머신

출력 operation의 상태는 `Prepare → InitializeModule → ReadOutput → CheckOutputClass → ReadBytes → CompleteBytes`다. InitializeModule 성공만 중간 publication으로 기록한다. ReadOutput 이후의 오류를 module setup failure로 캐시하지 않는다. 기존 completed lazy value와 nested callback publication은 외부 시도가 실패해도 유지한다.

`PcfRenderer.renderDocument/renderValue`는 정상 method dispatch/type/arity 검사를 거쳐 builtin 구현에 진입한다. 새 renderer run은 다음 상태와 명시적 await reason을 가진다.

1. `ReadOptions`: indent → omitNullProperties → useCustomStringDelimiters 순서. getter의 throw/read/log를 그대로 실행한다.
2. `ReadConverterMappings`: converters → convertPropertyTransformers를 읽고, pinned PklConverter 순서대로 얕게 force하여 type/path/transformer tables를 만든다.
3. `ConvertTop`: top-level path marker에서 변환한다. 변환 함수는 VM callable로 실행하며 반환값·오류·Host suspension을 같은 scheduler가 처리한다.
4. `Visit`: 값 종류에 따라 scalar emit, strict collection traversal, object shallow force, directive, unsupported value error로 이동한다.
5. `ForceObjectShallow`: 해당 receiver의 visible immediate members만 child-owner→parent-owner 순서로 읽는다. 성공 뒤 renderer의 parent-first descriptor 순회로 넘어간다.
6. `NextMember`: descriptor 방문 시점에 key hash/equality/visited 검사를 수행한다. receiver cache 값을 사용하고 local/hidden/class/alias 등 pinned 필터를 적용한다. key들을 미리 전부 force하거나 전역 hidden-name 집합으로 제거하지 않는다.
7. `ConvertProperty`와 `ConvertValue`: class property의 inherited annotation 순서, transformer 적용, name/value Pair 변환 뒤 일반 value converter를 실행한다. 변환된 key는 값의 path에 반영하고 key 자체 converter는 빈 path에서 실행한다.
8. `Emit/Close`: PCF grammar에 맞게 separator/indent/braces/마지막 LF를 기록한다. document와 value 모드는 같은 방문 엔진을 사용하되 최상위 허용 타입·braces·LF 정책이 다르다.
9. `CompleteString`: 정상 String 반환이 text property를 완료한다. 이후 encodeToBytes와 bytes property가 정상 lazy cache를 완료한다.

Await reason은 property read, shallow force, converter call, annotation-transformer call, key hash, key equality로 나눈다. 각 대기에는 stack 위치/결과 destination/현재 path 및 객체 owner를 보관한다. 하위 정상 VM frame이 완료될 때 해당 renderer state만 재개한다. renderer 자체가 별도의 Rust 재귀 stack이나 별도 untraced evaluator를 갖지 않는다.

GC roots에는 renderer receiver, top-level original/converted value, 현재 receiver/owner, key/value pair, converter function 및 mappings, property annotations, transformer 결과, strict collection cursor와 pending task의 모든 Value를 포함한다. UTF-16 builder와 path 문자열은 Rust 소유 메모리이며 size budget과 주기적 scheduler yield를 적용한다. 모든 suspended context의 roots와 cancellation cleanup에 새 state를 연결한다.

## 얕은 force의 정확한 경계

현재 ForceRun은 object-string/trace의 recurse=true, allowUndefined=true 및 hash/equality의 recurse=true, allowUndefined=false를 다룬다. Stage40은 `ForceMode { recurse, allow_undefined }`로 일반화하되 기존 세 호출 경로의 동작을 바꾸지 않는다. shallow(false,false)는 immediate member 완료 후 `Task::Value`로 재귀 진입하지 않으며 새로운 persistent forced=true를 세우지 않는다. 이미 forced=true면 Java와 같이 빠르게 반환한다.

중요한 미확정 경계가 있다. pinned `VmObject.force`는 shallow 호출에서도 실패 catch에서 forced=false를 쓴다. 따라서 shallow가 Host에서 대기하는 동안 callback이 같은 객체를 깊게 force하여 완료한 뒤 외부 shallow가 실패하면, 단순히 '내가 세운 mark만 지운다'는 새 규칙이 Java와 같다고 단정할 수 없다. 실제 source의 reentry/throw/cancel 제어 실험을 먼저 확보한다. 완료 member cache publication 소유권과 persistent force bit는 별개로 다룬다. 추측으로 기존 guard를 전역 해제하지 않는다.

undefined는 출력에서 `?`로 대체하지 않는다. 실제 member-read에서 발생한 undefined의 receiver와 render path/top-level 정보를 유지해 pinned hint를 구성한다. key hashing 또는 converter의 오류를 다른 member undefined로 삼키지 않는다. renderer를 위해 모든 자식 값을 먼저 깊게 force하면 converter가 가릴 수 있던 오류와 Host 순서가 달라지므로 금지한다.

## PCF/변환 완성 조건

`diagnostic_values::RenderRun`은 Pkl value 표현기이며 PCF 문서 renderer가 아니다. 숫자·identifier·기존 key primitive는 공유할 수 있으나 문서 구두점, 타입 label 유무, multiline 문자열, custom hash delimiters는 pinned `PcfRenderer`와 `ValueFormatter`대로 구현한다. UTF-16을 String loss conversion 없이 유지하고 마지막 UTF-8 bytes 경계에서 Java 인코딩 동작을 검증한다. raw bytes 경로에 임의의 LF를 추가하지 않는다.

Pcf 옵션을 선언만 하고 무시하지 않는다. converters의 path 우선순위, 정의 순서, 가장 구체적인 class 선택, 값당 최대 한 converter 적용을 구현한다. ConvertProperty의 inherited annotation 순서와 Pair 반환, Mixin transformer 호출에는 실제 Pair/Mixin 실행 의존성이 있다. 단계적으로 개발할 때 미구현 경로는 명시적 Unsupported이며 해당 원본 사례도 실패 상태다. 비어 있지 않은 mapping을 비어 있는 것처럼 처리하거나 결과만 기본 PCF로 출력하지 않는다.

문서 renderer 전체 지원을 주장하려면 RenderDirective/PcfRenderDirective와 실제로 허용되는 collection/value 종류, unrenderable Class/TypeAlias/Function/Reference 오류 및 source/hint를 검증해야 한다. 아직 구현되지 않은 Duration/DataSize/IntSeq/Mixin 등 값을 조용히 문자열화해서 그 주장을 만들지 않는다. 최초 출력 커널 체크포인트와 완전한 PcfRenderer 호환성은 별개 상태로 기록한다.

## 원본 실행 묶음

다음 ID는 모두 접두사 `pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/`에 상대 입력을 붙인 원본 ID다. 전체 argv/cwd/env/resources/hash/채널은 `original-contracts.json`에 이전 설계에서 그대로 복사했다.

| A 상대 입력 | 출력 외 실제 확인할 의존성 |
| --- | --- |
| basic/comments.pkl | 모듈 visible property와 함수 비출력, comment 처리 |
| basic/semicolon.pkl | inferred object, nested PCF document |
| basic/imported.pkl | 같은 모듈 lazy property 참조; 이름이 imported라도 이 입력 자체는 import 없음 |
| parser/methodTrailingCommas.pkl | module/class method 및 call trailing comma, 타입/호출 실행 |
| parser/constraintsTrailingComma.pkl | Int predicate constraint 실행과 오류 순서 |
| parser/trailingCommas.pkl | typed Mapping 및 !isEmpty constraint |
| parser/spread.pkl | nested amendment/super/spread 값 생성 순서 |
| api/pcfRenderer1.pkl | 혼합 Dynamic property/element, nested/multiline 문자열, 실제 renderer 선택 |
| errors/undefinedProperty1.pkl | typed required property의 출력 force 오류 |
| errors/undefinedProperty4.pkl | 깊은 object-key/hash undefined의 path/source hint |

이 목록은 예상 통과 목록이 아니다. 수정하지 않은 전체 입력의 실제 추가 의존성이 드러나면 같은 사례를 계속 실패로 보존하면서 구현한다. 원본 명령에 --expression이나 result wrapper를 추가하지 않는다. Stage39의 accepted boundary 네 입력도 Java의 실제 `result = 1\n` 문서 계약으로 승격해 검증하되 원본 72개를 대신하지 않는다.

A 다음 B는 기존 14개 import/module inheritance/recursive/shared identity/space·Unicode path/pkl:test 계약이다. 특히 `snippetTest.pkl → pkl:test` loader와 guest `catch` 구현이 필요하다. `api/moduleOutput.pkl`은 output.text override를 쓰더라도 원래 amends를 제거할 수 없다. C의 6개 path converter/property transformer/Mixin/reflection/JsonRenderer 계약도 유지한다. 이 설계는 30개 외 나머지 upstream 의무를 제외하지 않는다.

## 검증 요구

- 전체 입력 파싱 우선, 기존 72개의 stdout/stderr/exit/files와 원시 source frame 유지. 기존 3,527 scalar 및 persistent/trace/Host 계약의 회귀 검증은 최종 freeze 후 수행한다.
- default output, explicit text/bytes/value/renderer override, 잘못된 output class, hidden output exclusion, empty document, inherited hidden owner, local/class/alias 제외, public shadow와 cached receiver 값.
- renderer 옵션 getter의 최초 오류 순서, converter mapping 초기화와 member force 순서, 변환으로 lazy child 오류를 가리는 경우, path/type 우선순위, annotation 순서, converter 실패 힌트.
- shallow child→parent force와 parent→child render 순서, duplicate/equal/colliding object keys, cached undefined/deep-force bit 상호작용, failed outer 시도 뒤 성공한 callback cache 유지.
- actual-source Host read/log 대기 및 reentry, 모든 yield/read/call 경계 GC, nested callbackclose, stale/wrong-kind token 거부, timeout/cancel 중 renderer roots 회수, completed bytes의 close 이후 안정성.
- PCF 단일/다중행 문자열, CR/LF/CRLF, 따옴표/backslash/# delimiters, quoted/Unicode identifiers, lone UTF-16 surrogate, 음수0/Infinity/NaN와 수치 형식, 들여쓰기, omitNull 적용 위치, 정확한 마지막 LF.
- 실제 native/Node/Chromium 동일 engine/artifact source binding, 원본 물리 cwd/URI/argv/options 및 생성 파일 목록·내용. compile-only/parse-only success를 actual eval pass로 세지 않는다.

## 즉시 후속 로더 작업

Stage40의 출력 구현 뒤 첫 후속은 source loader와 evaluator-owned module cache다. resource Read와 다른 typed module request, canonical identity와 display URI 분리, empty module 선공개 및 실패 cache, 여러 Program/source의 class/type/block ID 충돌 방지, extends/amends와 bundled pkl:test가 필요하다. 현재 Program의 단일 module_name/template 및 source-offset 기반 식별을 여러 모듈에 그대로 재사용하지 않는다.

allowed file resource I/O, UTF-16 URI, custom Host nullable absence, resource cache, HTTP/package/project/glob/modulepath, output.files/다중모듈 CLI separator는 각각 남은 원본 계약으로 추적한다. 여기서 default configured env/property map을 연결했다고 이 전체 M4 경로를 완료했다고 말하지 않는다. 로더 도입 시 기존 URI normalization/권한/원시 진단과 Stage38 남은 실패를 함께 다시 검증한다.

## 실행 소유권 제안

A는 공통 builtin registry/VM shallow force/renderer/converter/UTF-16 formatter와 의미론 회귀를 소유한다. B는 공유 operation/session API 합의 뒤 native/Wasm/N-API의 bytes 전달과 원본 tool 등록을 소유한다. C는 pinned actual CLI 및 renderer/force/Host oracle, unchanged original inputs의 독립 raw comparison을 소유한다. root가 별도 구현 checkout과 최종 소유권을 승인하기 전에는 production 파일을 바꾸지 않는다.

첫 공통 checkpoint에서 PreparedModule/operation/result type과 builtin ID 계약을 먼저 공개한다. shallow mode와 renderer state는 함께 설계하고, B adapter가 fake PCF 성공으로 먼저 닫히는 순서를 피한다. 최종 closeout은 변경/실제 checks/미실행/실패를 각각 기록한다. M2 전체 gate는 이 Stage40 출력 slice 통과만으로 완료되지 않는다.
