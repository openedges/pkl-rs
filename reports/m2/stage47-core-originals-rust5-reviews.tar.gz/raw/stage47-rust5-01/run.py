from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
IMPL=ROOT/'target/m2/stage47-implementation-01'
CHECK=IMPL/'check.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
commands=[
 ('final-xtask-01',['cargo','xtask','verify']),
 ('final-fmt-01',['cargo','fmt','--all','--','--check']),
 ('final-clippy-01',['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings']),
 ('final-workspace-01',['cargo','test','--workspace','--locked']),
 ('final-wasm-check-01',['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked']),
]
records=[]
save('launch.json',dict(pid=os.getpid(),started_utc=started,argv=sys.argv,cwd=str(Path.cwd()),check_script=str(CHECK),check_script_sha256=sha(CHECK),commands=commands))
for label,command in commands:
 argv=[sys.executable,str(CHECK),label,*command]
 with (OUT/(label+'.stdout.bin')).open('xb') as stdout,(OUT/(label+'.stderr.bin')).open('xb') as stderr:
  child=subprocess.Popen(argv,cwd=ROOT,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  save(label+'.launch.json',dict(pid=child.pid,argv=argv,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  code=child.wait()
 report=IMPL/label/'report.json'
 record=dict(label=label,command=command,pid=child.pid,exit_code=code,report=str(report),report_sha256=sha(report) if report.exists() else None)
 records.append(record);save('progress.json',records);print(label,code,flush=True)
reports=[json.loads(Path(row['report']).read_text()) for row in records if row['report_sha256']]
stable=len(reports)==5 and all(row['source_stable'] for row in reports) and len({row['source_before_sha256'] for row in reports})==1
passed=all(row['exit_code']==0 for row in records) and stable
save('report.json',dict(started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,all_source_stable_and_identical=stable,passed=passed,scope='Required local Rust checks only; raw Java/native/portable compatibility and remaining M2 requirements are separate.'))
sys.exit(0 if passed else 1)
