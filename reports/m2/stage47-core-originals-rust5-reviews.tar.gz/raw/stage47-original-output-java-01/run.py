"""Acquire two pinned original output cases using their unchanged CLI contracts."""
from pathlib import Path
import collections
import json
import sys
import time
ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
OUT = Path(__file__).resolve().parent
WORKSPACE = ROOT / 'target/m2/stage47-original-output-workspace-01/workspace'
TOOLROOT=ROOT
sys.dont_write_bytecode=True
sys.path.insert(0, str(TOOLROOT/'tools'))
import compat
import m2_module_eval as module
import oracle


def main():
    started = time.monotonic()
    names = ['tools/compat.py','tools/m2_module_eval.py','tools/oracle.py','oracle.lock.json','references.lock','compatibility/corpus.json','compatibility/m2-module-eval.json']
    before = {name:oracle.sha256(ROOT/name) for name in names}
    for name in names:
        target=OUT/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((ROOT/name).read_bytes())
    # Verify pinned inputs/JDK independently; all new identity HOME/tmp stays local.
    lock=json.loads((ROOT/'oracle.lock.json').read_text())
    oracle.verify_sources(ROOT,lock)
    profile=json.loads((Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46/target/m2/stage46-original-read-java-01/profile.json')).read_text())
    old_artifact=profile['artifact']
    profile['artifact']=str(ROOT/'.cache/oracle'/lock['artifact']['filename'])
    profile['command']=[profile['artifact'] if arg==old_artifact else arg for arg in profile['command']]
    profile['environment']=oracle.deterministic_environment(OUT/'identity')
    profile['jdk']=oracle.verify_java(Path(profile['java']),lock,profile['environment'])
    profile['release']=oracle.verify_artifact(Path(profile['artifact']),lock)
    profile['command']=[f"-Duser.home={profile['environment']['HOME']}" if a.startswith('-Duser.home=') else f"-Djava.io.tmpdir={profile['environment']['TMPDIR']}" if a.startswith('-Djava.io.tmpdir=') else a for a in profile['command']]
    version=compat.capture(profile['command']+['--version'],ROOT,profile['environment'],60,OUT/'identity-generated')
    compat.store_capture(OUT/'version',version)
    assert version['exit_code']==0 and not version['stderr'] and version['stdout'].startswith(b'Pkl 0.32.0 (')
    profile['version_stdout_hex']=version['stdout'].hex();profile['version_stderr_hex']=version['stderr'].hex()
    (OUT/'profile.json').write_bytes(compat.encoded(profile))
    corpus = json.loads((ROOT/'compatibility/corpus.json').read_bytes())
    registry = json.loads((ROOT/'compatibility/m2-module-eval.json').read_bytes())
    registered = module.registry_cases(ROOT,corpus,registry)
    wanted=['api/moduleOutput2.pkl','api/pcfRenderer9.pkl']
    prefix='pkl-core/src/test/files/LanguageSnippetTests/input/'
    originals=[next(row for row in corpus['cases'] if row['suite']=='language-snippet' and row['source']['path']==prefix+name) for name in wanted]
    (OUT/'selected-originals.json').write_bytes(compat.encoded(originals))
    assert len(originals)==2 and all(row['id'] in registered for row in originals)
    cases = [dict(id=row['id'],adapter=module.ADAPTER,input='external/pkl/'+row['source']['path'],input_sha256=row['source']['sha256'],upstream_case=row) for row in originals]
    (OUT/'cases.json').write_bytes(compat.encoded(cases))
    if WORKSPACE.exists():raise ValueError('Use a fresh exclusive workspace')
    compat.prepare_workspace(ROOT,WORKSPACE)
    verified = compat.validate_inputs(ROOT,dict(sources=corpus['sources'],cases=originals),WORKSPACE)
    baseline = compat.snapshot(WORKSPACE)
    module.validate_resource_set(baseline,corpus['sources'])
    (OUT/'validated-inputs.json').write_bytes(compat.encoded(verified))
    (OUT/'workspace-baseline.json').write_bytes(compat.encoded(baseline))
    records=[];repeat_differences=[]
    for index,case in enumerate(cases):
        copied=OUT/'inputs'/case['input'];copied.parent.mkdir(parents=True,exist_ok=True);copied.write_bytes((WORKSPACE/case['input']).read_bytes())
        assert oracle.sha256(copied)==case['input_sha256']
        first=None
        for repetition in range(2):
            if compat.snapshot(WORKSPACE)!=baseline:raise ValueError('Workspace drift before case')
            destination=OUT/'cases'/compat.case_directory(case['id'])/str(repetition)
            process,capture=module.capture_process(ROOT,WORKSPACE,case,profile['command'],profile['environment'],destination)
            if process['timed_out'] or process['exit_code'] not in (0,1):
                status='oracle-error'
            elif process['exit_code']==1 and not capture['stderr'].startswith('–– Pkl Error ––\n'.encode()):
                status='oracle-error'
            elif process['exit_code'] not in case['upstream_case']['expected_exit']:
                status='oracle-contract-mismatch'
            elif capture['workspace_changes']:
                status='oracle-environment-error'
            else:
                status='success' if process['exit_code']==0 else 'ordinary-error'
            record=dict(index=index,id=case['id'],repetition=repetition,directory=str(destination.relative_to(OUT)),status=status,process=process)
            records.append(record)
            if first is None:first=capture
            else:
                differences=compat.differences(first,capture)
                if differences:repeat_differences.append(dict(id=case['id'],differences=differences))
            (OUT/'progress.json').write_bytes(compat.encoded(dict(executed=len(records),expected=2*len(cases),last=case['id'],repetition=repetition,status=status)))
            print(len(records),status,case['input'],flush=True)
    after={name:oracle.sha256(ROOT/name) for name in names}
    report=dict(schema=1,scope='Actual Java CLI acquisition of the two untouched Stage47 moduleOutput2.pkl and pcfRenderer9.pkl original contracts in fixed selection order, twice at identical physical paths and original argv/environment/resources. Full raw stdout/stderr/exit/files retained; no Rust or portable compatibility claim.',case_count=len(cases),process_count=len(records),counts=dict(collections.Counter(row['status'] for row in records)),records=records,repeat_differences=repeat_differences,workspace=str(WORKSPACE),workspace_restored=compat.snapshot(WORKSPACE)==baseline,sources_before=before,sources_after=after,source_stable=before==after,oracle_artifact_stable=oracle.sha256(Path(profile['artifact']))==profile['artifact_sha256'],elapsed_seconds=time.monotonic()-started,compatibility_complete=False)
    (OUT/'report.json').write_bytes(compat.encoded(report))
    assert report['source_stable'] and report['workspace_restored'] and report['oracle_artifact_stable']
    print(json.dumps({'case_count':len(cases),'process_count':len(records),'counts':report['counts'],'repeat_differences':len(repeat_differences)}),flush=True)

if __name__=='__main__':main()
