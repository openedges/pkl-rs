from pathlib import Path
import datetime,hashlib,json,sys,time,os
sys.dont_write_bytecode=True
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47');OUT=Path(__file__).resolve().parent
JAVA=ROOT/'target/m2/stage47-original-output-java-01'
RELEASE=ROOT/'target/m2/stage47-implementation-01/renderer-candidate-build-03/release.json'
r=json.loads(RELEASE.read_text());SOURCE=Path(r['source_snapshot']);BINARY=Path(r['artifact'])
sys.path.insert(0,str(SOURCE/'tools'))
import compat,m2_module_eval as module
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data):(OUT/name).write_bytes(compat.encoded(data))
def main():
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
 save('launch.json',dict(pid=os.getpid(),startedUtc=start,argv=sys.argv,cwd=str(Path.cwd())))
 assert sha(JAVA/'report.json')=='0b5b143ac5bfb33b6f5930511b0343e84361fc0320277da594c178a3867e4ae9'
 java=json.loads((JAVA/'report.json').read_text());assert java['source_stable'] and java['workspace_restored'] and java['counts']=={'success':4}
 workspace=Path(java['workspace']);baseline=json.loads((JAVA/'workspace-baseline.json').read_text());assert compat.snapshot(workspace)==baseline
 assert sha(BINARY)==r['artifact_sha256']
 source_map=json.loads(Path(r['source_map']).read_text());assert sha(Path(r['source_map']))==r['source_map_sha256']
 for name,digest in source_map.items():assert sha(SOURCE/name)==digest,name
 cases=json.loads((JAVA/'cases.json').read_text());profile=json.loads((JAVA/'profile.json').read_text());records=[]
 save('inputs.json',dict(release=str(RELEASE),release_sha256=sha(RELEASE),java_report=str(JAVA/'report.json'),java_report_sha256=sha(JAVA/'report.json'),source_map=r['source_map'],source_map_sha256=r['source_map_sha256'],artifact=str(BINARY),artifact_sha256=sha(BINARY),case_contracts=cases,workspace=str(workspace),consumer_tool_inputs={name:sha(SOURCE/name) for name in ['tools/compat.py','tools/m2_module_eval.py','tools/oracle.py']}))
 for index,case in enumerate(cases):
  for rep in range(2):
   j=next(x for x in java['records'] if x['repetition']==rep and x['id']==case['id'])
   expected=compat.load_capture(JAVA/j['directory']);process,actual=module.capture_process(SOURCE,workspace,case,[str(BINARY)],profile['environment'],OUT/'cases'/compat.case_directory(case['id'])/str(rep))
   status=module.status(j['process'],process,expected,actual,case['upstream_case']['expected_exit'])
   records.append(dict(index=index,id=case['id'],repetition=rep,status=status,differences=compat.differences(expected,actual),java_directory=j['directory'],process=process));print(index,rep,status,flush=True)
   save('progress.json',dict(executed=len(records),expected=4,last=records[-1]))
 assert sha(BINARY)==r['artifact_sha256'];assert compat.snapshot(workspace)==baseline
 for name,digest in source_map.items():assert sha(SOURCE/name)==digest,name
 assert sha(JAVA/'report.json')=='0b5b143ac5bfb33b6f5930511b0343e84361fc0320277da594c178a3867e4ae9'
 result=dict(scope='C03 immutable artifact on the two untouched original moduleOutput2.pkl and pcfRenderer9.pkl CLI contracts, each repeated twice against sealed Java at the identical physical workspace. Full stdout/stderr/status/generated files comparison. New JSON API and portable/lifecycle comparisons remain separate.',started_utc=start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,records=records,all_pass=all(x['status']=='pass' for x in records),workspace_stable=True,artifact_stable=True,source_snapshot_count=len(source_map),source_snapshot_verified_before_and_after=True)
 save('report.json',result);print(json.dumps(dict(all_pass=result['all_pass'],records=len(records),report=str(OUT/'report.json'),report_sha256=sha(OUT/'report.json')),indent=2));return 0 if result['all_pass'] else 1
if __name__=='__main__':sys.exit(main())
