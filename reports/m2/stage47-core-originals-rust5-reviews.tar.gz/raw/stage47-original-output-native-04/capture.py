from pathlib import Path
import subprocess,sys,json,datetime,hashlib,os
out=Path(__file__).resolve().parent
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
command=[sys.executable,str(out/'run.py')]
with (out/'driver.stdout.bin').open('xb') as stdout,(out/'driver.stderr.bin').open('xb') as stderr:
 p=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 (out/'driver-launch.json').write_text(json.dumps(dict(argv=command,pid=p.pid,started_utc=started),indent=2)+'\n')
 code=p.wait()
(out/'outer-terminal.json').write_text(json.dumps(dict(exit_code=code,pid=p.pid,started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=hashlib.sha256((out/'driver.stdout.bin').read_bytes()).hexdigest(),stderr_sha256=hashlib.sha256((out/'driver.stderr.bin').read_bytes()).hexdigest()),indent=2)+'\n')
print(out,code,flush=True)
print((out/'driver.stdout.bin').read_text()[-4000:]);print((out/'driver.stderr.bin').read_text()[-4000:])
sys.exit(code)
