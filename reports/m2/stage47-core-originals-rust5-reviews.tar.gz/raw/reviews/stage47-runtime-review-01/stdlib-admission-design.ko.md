# Bundled stdlib admission 후속 의무

이 문서는 C01과 `property-source-proposal-01`의 읽기 전용 검토입니다. 구현·새 Java 취득·native 실행 결과가 아닙니다. `pkl:json.Property` 지원은 현재 기본 허용 정책 범위이며, 전체 stdlib 정책 호환성을 완료한 것으로 세지 않습니다.

## Caller까지 확인한 정정

`ModuleKeys.StandardLibrary.resolve`(293–296행)는 `checkResolveModule(uri)`를 호출합니다. 그러나 `ModuleCache.getOrLoad`(81–128행)는 그보다 앞서 `base`, `ref`, `test`를 포함한 static singleton 모듈을 직접 반환합니다. 따라서 이 세 모듈에 일괄 resolve/security 효과를 추가하면 Java와 달라집니다. 최초 검토 메시지에서 이 caller 분기를 확인하기 전에 세 모듈도 동일한 admission 누락으로 일반화한 판단은 정정합니다.

`json`은 이 switch에 없습니다. 유효한 일반 stdlib URI는 original-cache hit를 먼저 확인하고(143–151행), miss에서 resolve/security를 수행한 뒤 resolved-cache를 확인합니다(153–160행). resolve/security 실패는 `doLoad` 이전이므로 캐시되지 않고 재시도됩니다. source/initialization 실패는 `doLoad`(170–193행)에서 캐시합니다. cached success 뒤 매 import마다 새 보안 검사를 추가하는 것도 Java와 다릅니다.

## 공통 연결 경로 제안

1. `vm/stdlib_modules.rs`의 모듈 선택을 source 제공과 cache/admission 분류로 분리합니다. pinned catalog와 Java singleton 분기를 공통 descriptor로 관리합니다. JSON만 별도 보안 분기로 추가하지 않습니다. 미구현 모듈은 계속 미구현 의무이며, 이 분류가 구현 완료 주장이 되지 않습니다.
2. `vm/modules.rs::begin_import`의 현재 선행 `import_stdlib()` 단축을 분류에 따라 나눕니다. base/ref/test의 기존 singleton 대응 경로는 정책 효과를 억지로 추가하지 않습니다. evaluator-owned stdlib는 original-cache miss에서 기존 typed `ModuleRequestKind::Resolve`를 거치도록 `ModuleRun`에 bundled-source continuation을 보존하는 설계가 가능합니다.
3. 기존 `ModuleCompletion::Resolved`가 성공하면 bundled ModuleKey의 original/resolved identity를 검증하고 pinned source를 같은 VM/arena에 연결합니다. bundled source를 외부 `LoadSource`로 요청하거나 Host가 전달한 임의 source text로 대체하지 않습니다. display/source provenance와 cache URI는 계속 구분합니다. resolved-cache hit도 일반 경로와 동일한 위치에서 처리해야 합니다.
4. denial은 기존 `ModuleHostError::SecurityManagerException`의 resolve-stage 경로를 사용합니다. raw `Denied`나 임의 Host 오류를 guest exception으로 바꾸지 않습니다. 거부 후 캐시를 게시하지 않고 import operand/owner를 유지하며, stale/wrong completion이 request token을 소비하지 않는 계약도 유지합니다. cancel/close/timeout·logger 실패는 별도 terminal/bypass 의무입니다.

## Source impact와 기본 Host

`evaluation/frontend.rs`의 순수 `evaluate_module_output`은 현재 `unsupported_completion`을 기본 closure로 사용합니다(389행). 모든 bundled import가 새 Resolve 효과를 내도록만 바꾸면, 기존 Host 없는 stdlib 평가가 실패합니다. 새 기본 bundled-admission completion을 명시적으로 제공하고 외부 I/O의 기존 Unsupported와 분리해야 합니다. 기존 public `unsupported_completion`을 조용히 허용 함수로 바꾸면 안 됩니다.

development `examples/support/module_host.rs`의 resolve는 file URI 전용이고, JVM classpath Host도 자신의 scheme만 지원합니다. 이 기본 adapter들은 공통 bundled admission 결과로 위임할 수 있어야 합니다. 사용자 `evaluate_module_output_with_host` closure는 request를 먼저 관찰/거부할 수 있어야 하며, 그 앞에서 unconditional allow로 단축하면 같은 결함이 남습니다.

기존 typed request/completion transport를 재사용하면 새 enum/ABI 없이 연결할 가능성이 있지만, 기존 pure/default callback·SourceProbe·N-API·Wasm·portable fixture provider의 효과 수/처리 계약은 변경됩니다. `LoadSource`와 혼동하지 않는 shared helper와 default policy 계약이 필요합니다. 이 때문에 renderer의 출력 동작 교정과 묶기보다 별도 **필수** checkpoint로 분리하는 편을 권고합니다. 단, renderer checkpoint 문서에 기본 정책 한계를 명시하고 M2 전체 종료 의무에서는 제거하지 않습니다.

## Java/공유 엔진 대조군 제안 — 아직 실행하지 않음

- 같은 preconfigured evaluator에서 `pkl:json`만 거부하는 실제 Standard policy, 기본 허용, 허용 뒤 동일 original key cache hit, 첫 resolve 거부 뒤 재시도와 stable followup을 분리합니다. `import "pkl:json"; p = (new json.Property { name = "x" }).name`의 `p`를 강제하면 JSON parser 구현이 없어도 admission에 도달합니다.
- denied import를 사용하는 guest catch/catchOrNull과 일반 오류를 같은 evaluator에서 반복합니다. 실제 cause의 null/UTF16 단위·전체 오류/프레임·정책 검사 횟수를 보존합니다.
- base/ref/test를 같은 거부 정책으로 비교해 pinned singleton 우회 동작을 실제로 확인합니다. implicit prelude 사용과 명시적 stdlib import도 구분합니다. 세 모듈의 JVM-global singleton/cache identity는 별도 기존 호환성 의무이며, 이번 admission 설계가 이를 구현했다고 주장하지 않습니다.
- wrong original/resolved identity completion, close/timeout 후 지연 completion, denial 중 GC, 같은 evaluator의 cache hit/miss 및 ordinary file/modulepath load와의 회귀를 검사합니다. SourceSession/Node/browser에서도 동일한 engine 단계와 typed completion을 사용합니다.
- canonical URI 외 spelling/잘못된 모듈명은 ModuleResolver normalization과 `ModuleCache`의 singleton/유효 URI 판정 순서를 따라 별도 원본으로 보존합니다. 아직 관찰하지 않은 URI별 결과나 SPI 횟수를 추정해 기대값으로 쓰지 않습니다.
