# 표준 모듈 admission 필수 checkpoint 구현 준비

이 문서는 구현·새 oracle 취득·검사 실행 결과가 아니다. MAIN `674d3cabdd0e9c421a2cb9b820a22f2456755629`와 불변 Stage47 C03만 읽었다. 현재 A의 identity carrier live 구현은 입력이 아니다. 원본 Java06의 정책 84개 호출을 기존 raw에서 연결했으며, Rust의 정책 호환 통과로 세지 않는다. 이전 `stdlib-admission-design.ko.md`의 최소 Resolve 재사용안보다 아래 단계 구분을 우선한다.

## 반드시 분리할 두 보안 단계

`ImportNode.java:50–65`는 노드의 `importedModule`이 없을 때 `checkImportModule(currentModule.getUri(), importUri)`를 먼저 호출하고, ModuleResolver를 거쳐 ModuleCache를 호출한다. 이 검사는 import **edge의 신뢰도 검사**다. `currentModule`은 ResolvedModuleKey이므로 importer의 resolved URI가 기준이며 diagnostic/source URI와 바꾸면 안 된다. 성공한 ImportNode는 값을 보관하므로 이후 같은 노드는 이 검사를 반복하지 않는다.

`ModuleCache.java:81–160`은 별도 key 단계다. singleton이면 `ModuleKey.resolve`에 도달하지 않고 반환한다. 일반 모듈은 original URI cache hit가 resolve보다 먼저이며, miss에서 `module.resolve(securityManager)`를 수행한 다음 resolved URI cache를 본다. `ModuleKeys.java:293–296`의 StandardLibrary.resolve는 `checkResolveModule(uri)`를 호출한다. 이 단계가 **모듈 허용목록 검사**다. `SecurityManagers.java:148–170`에서 두 검사의 의미가 실제로 다르다.

따라서 base/ref/test에 key resolve 허용목록 검사를 추가하면 Java와 다르고, singleton이라는 이유로 edge 검사를 생략해도 Java와 다르다. JSON도 URI cache hit 전에 매번 key 검사를 넣으면 틀린다. 현재 Rust의 `begin_import`는 stdlib 단축과 URI cache 조회를 먼저 수행하므로, 기존 Resolve 하나를 임의로 앞당기는 수정만으로는 이 순서를 표현할 수 없다.

## 고정 분류와 캐시 순서

공통 catalog descriptor를 source 제공 여부와 분리한다. Java ModuleCache switch의 정확한 16개 이름은 `analyze`, `base`, `Benchmark`, `Command`, `jsonnet`, `math`, `pklbinary`, `platform`, `project`, `ref`, `reflect`, `release`, `semver`, `settings`, `test`, `xml`이다. 이 중 Rust MAIN은 base/ref/test만 제한적으로 구현했고 C03은 evaluator-owned json을 추가했다. 이 분류가 나머지 모듈 구현이나 JVM-global singleton identity를 완료시키지 않는다.

`modules.txt`만으로 singleton 분류를 만들지 않는다. 예를 들어 Java switch의 `project`와 catalog의 `Project`는 원문이 다르다. case/spelling 별 실제 결과를 새로 관찰하지 않은 상태에서 case-fold, wildcard `pkl:*` 허용, spelling 수정으로 일반화하지 않는다. `json`은 singleton switch에 없고 유효 catalog에 있다. 잘못된 stdlib 이름은 Java에서 edge 검사 뒤, key resolve 보안 검사 전에 ModuleCache의 오류가 된다.

구현 순서는 다음과 같다.

1. import AST site의 성공 값 cache를 확인한다. hit이면 그 노드의 기존 값을 반환한다. Java의 이 cache는 URI cache와 다르다. 새 `ImportSiteId` 또는 실행 가능한 code owner + instruction site를 사용하고 activation별 stack index/URI만으로 합치지 않는다. cached receiver는 GC root로 유지한다.
2. site miss이면 typed import-edge admission을 요청한다. importer resolved URI와 이미 준비된 import URI를 전달한다. denial은 이 단계에서 끝나고 노드 성공 값·모듈 실패 cache를 새로 게시하지 않는다.
3. ModuleKey 종류를 판별한다. singleton은 key resolve를 요청하지 않고 pinned singleton 대응 경로로 간다. catalog 밖 stdlib는 원래 오류로 끝낸다. 일반 evaluator-owned stdlib는 original URI cache를 조회한다. 이 cache에 저장된 실패도 여기서 재생한다.
4. 일반 key cache miss이면 기존 typed Resolve를 요청한다. stdlib의 original/resolved/source identity는 pinned descriptor에 결합한다. 성공했다고 Host가 전달한 임의 파일 URI나 source를 stdlib의 대체 구현으로 받아들이지 않는다.
5. resolved URI cache hit이면 값을 재사용한다. miss이면 pinned bundled source를 내부에서 얻는다. 외부 LoadSource를 요청하지 않는다. Java doLoad와 같이 empty receiver를 만들고 source 획득 뒤 original/resolved cache에 게시한 다음 일반 초기화를 진행한다.
6. source/초기화 구간 실패는 기존 구조화 오류와 양쪽 URI cache를 보존한다. Resolve 또는 import-edge 거부는 doLoad 이전이므로 새 모듈 실패 cache로 넣지 않는다. 초기화가 성공해 반환한 값만 해당 import site 성공 cache에 연결한다. 순환 초기화에서 부분 receiver가 반환되는 경로는 Java node/module cache와 함께 따로 검증한다.

`base`의 implicit prelude 사용은 explicit ImportNode가 아니다. 이를 위해 존재하지 않는 edge 요청을 만들지 않는다. 기존 per-evaluator Rust의 base/ref/test identity와 Java static singleton 수명 차이는 별도 의무로 남긴다.

## 제안 API 경로 — 아직 구현되지 않음

새 이름은 설계 표기이며 현재 제공 API로 문서화하면 안 된다. 기존 enum에 단계가 명시된 `ModuleRequestKind::CheckImport { importer, import_uri }`와 `ModuleCompletion::ImportChecked(Result<(), ModuleHostError>)`를 추가하는 방식을 권고한다. 기존 Resolve는 key resolution/allowlist 단계로 유지한다. 불리언 필드 하나로 두 단계의 cache 위치를 합치거나, Host에서 받지도 않은 두 번째 검사를 시행한 것으로 기록하지 않는다.

| 경계 | 실제 연결 위치 | 필요한 변경과 금지사항 |
| --- | --- | --- |
| 공통 VM | `src/vm/modules.rs:125`, `ModuleRun`, `resolved_module`, `loaded_module`; `src/vm/stdlib_modules.rs:9` | stdlib source 선택과 admission/cache 분류 분리. ModuleRun을 단계별 continuation으로 만들고 bundled source는 Resolve 뒤 내부 설치. URI cache 앞 edge와 cache 뒤 key를 구분. 실패 초기화의 guard/cache를 유지. |
| 공통 값/GC | `src/vm.rs`의 Frame.module_load, heap root 수집, 모듈 실패 unwind | 새 site cache와 대기 continuation receiver를 root로 수집. close/cancel/timeout 시 request 폐기, retained code만으로 receiver를 살려두지 않음. A identity 작업의 슬롯/stack 변경과 의미를 섞지 않고 후속 불변 snapshot에서 통합. |
| typed Host | `src/modules.rs`, `src/host.rs:339` | CheckImport completion만 해당 token에서 허용. nullable lossless UTF16 SecurityManagerException을 guest-provenance 오류로 유지하고 raw Denied/Unsupported/terminal을 catchable 오류로 바꾸지 않음. 잘못된 단계/stale token은 기존 request를 소비하지 않음. bundled identity 잘못된 completion의 수락·실패·token 계약은 구현 전에 명시하고 회귀로 고정. |
| pure frontend 기본 API | `src/evaluation/frontend.rs:389,432,474` | `unsupported_completion`의 뜻은 바꾸지 않음. 명시적 default bundled-policy adapter를 이 기본 API에만 연결. 허용된 bundled key의 admission만 완료하고 외부 I/O는 계속 Unsupported. 사용자 with_host callback보다 먼저 실행하는 unconditional fallback 금지. |
| native 개발 Host | `examples/support/module_host.rs:9`, `classpath_host.rs:24` | file/classpath source I/O와 policy를 분리. default bundled helper는 명시적 default profile에서만 사용. file-only resolver에 pkl URI를 canonicalize시키지 않음. DirectoryClassPath는 modulepath 처리 뒤 일반 Host에 위임하므로 양쪽에서 이중 admission 금지. 사용자 custom policy rejection 우선순위를 유지. |
| SourceSession / SourceProbe | `evaluation/session.rs:124,321,634`; `probe.rs:240,681–787` | 컴파일/등록은 정책 허용이 아님. 새 요청을 기존 poll/token/complete_module로 전달하고 임의 자동승인하지 않음. SourceModuleRequest의 kind/fields 및 explicit complete/reject 메서드 추가. primary/repl admission은 아래 별도 경계. |
| N-API / Wasm | `crates/pkl-napi/src/lib.rs:538–656`; `crates/pkl-wasm/src/lib.rs:588–699` | 두 바인딩이 같은 CheckImport request/complete/reject semantics를 노출. message의 null과 UTF16 단위를 유지. 새로운 플랫폼 정책 엔진이나 Java fallback을 넣지 않음. |
| JS provider | `tools/platform/module-preparation-session.mjs:5,87–132` | requestFields/requestKey/completion/complete에 새 kind를 명시. unordered provider input facts와 actual ordered observable events를 분리. 예상하지 않은 새 요청을 default allow하거나 provider가 없는 효과를 원래 event처럼 합성하면 안 됨. 기존 renderer의 resource-only helper는 module request를 현재 오류로 처리하므로 새 checkpoint의 runner/provider를 별도로 연결. |

default helper는 제품 전체 기본 SecurityManager 구현 완료와 다르다. 구현된 bundled descriptor, pinned 기본 정책 및 그 호출 profile만 지원한다. custom Host의 허용목록·trust mapping을 건너뛰는 “pkl이면 허용” helper로 만들지 않는다. `ModuleKey::hasElement`/capability는 stdlib import admission을 대신하지 않으며 이번 수정으로 새 불필요한 탐색 호출을 추가하지 않는다.

## Java06 정책 84개와 연결

`java06-policy84-mapping.json`은 고정 report/inventory/closure를 인증한 뒤 선택된 원본 raw를 명시경로로 읽어 만들었다. 3개 case × 2개 fresh JVM 반복 × 2개 evaluator session × 7개 API = 84개다. 결과는 80 success와 4 ordinary error이며, 84개 모두 Rust pass라는 뜻이 아니다. 각 호출의 양쪽 출력 원문/UTF16 경로·해시, report와 직접 결합된 전체 counters, ordered events 및 admission subset을 기록했다. 12개 session의 280개 full event는 원래 process stdout과도 결합했다. raw 출력은 정규화하지 않았다.

| 원본 case / profile | 28개 호출의 실제 결과 | admission에서 확인되는 것 | 아직 확인되지 않은 것 |
| --- | --- | --- | --- |
| `stdlib-admission-allow` / allow | 28 success | jsonClass 첫 강제에 `policy-import … -> pkl:json` 뒤 `policy-resolve-module pkl:json`. base/ref/test 첫 강제에는 edge만 있고 해당 pkl key resolve 없음. | 같은 site의 반복 강제·별도 site URI cache hit를 이 7개 순서만으로 증명하지 못함. |
| `stdlib-admission-deny-json` / 실제 Standard exclusion | jsonClass 4 ordinary error, 나머지 24 success | json edge 뒤 json resolve에서 actual-module-denied. 그 뒤 singleton과 stable은 계속 성공. | json을 같은 session에서 다시 강제하지 않으므로 denial retry/실패 cache 부재를 실제 raw로 증명하지 못함. catch/catchOrNull도 이 case에는 없음. |
| `stdlib-admission-deny-singletons` / 실제 Standard allowlist에서 base/ref/test 제외 | 28 success | singleton의 edge는 실제로 존재하나 key resolve가 없어 허용목록 exclusion이 발동하지 않음. denied counter는 0. | custom trust policy가 singleton edge를 거부하는 경우는 실행하지 않았음. “singleton은 모든 정책을 우회”하는 근거가 아님. |

세 case는 동일 본문을 사용한다. `stable`, `jsonClass`, `baseClass`, `refClass`, `testMessage`, GC 요청, `stable`, `stable` 순서다. 각 session 처음 stable까지 primary file에 대한 resolve 2개·secure-path 1개·repl:text resolve 1개가 있고, 이후 API마다 repl:text resolve가 추가된다. 첫 json 접근만 bundled key resolve가 하나 더 있다. full event/counter는 이 전부를 포함한다.

현재 SourceSession은 제공된 primary source를 compile/register하고 expression용 `repl:text` code를 준비하므로, Java EvaluatorImpl의 primary/synthetic module key resolve lifecycle와 같지 않다. stdlib 두 단계 구현만으로 전체 84개의 counters/events 일치를 주장하면 안 된다. 우선 전체 raw API 결과와 명시적 admission subset을 따로 보고하고, full lifecycle event 일치는 독립 gap으로 남긴다. full trace를 맞춘 것처럼 보이려고 provider에서 primary/repl event를 조건 없이 삽입하거나 원문 기대 event를 필터링해 full pass로 표시하지 않는다.

기존 MAIN renderer fixture는 이 84개를 Java-only/unselected로 명시하고 860개 기본 profile만 선택한다. 이를 조용히 바꾸지 말고, source-backed 정책 fixture의 별도 manifest/profile와 native/Node/browser 소비기를 작성해야 한다. 성공·오류의 UTF16/JavaUTF8 양쪽 원문, exact URI 및 단계별 이벤트, provider 입력과 실제 요청의 결합을 보존한다.

## 구현 순서와 종료 조건

1. A의 identity carrier 수정은 독립 후보로 마감한다. 이 문서 때문에 live stack/frame/slot에 admission 변경을 섞지 않는다. 후속 worktree/checkpoint에서 pinned descriptor·typed edge effect·key Resolve continuation을 먼저 구현한다.
2. 기본 pure API/native Host/SourceSession transport를 함께 연결한다. 기본 bundled import 회귀와 명시적 deny가 둘 다 가능해야 하며, 사용자 Host 앞의 autoallow로 기본 회귀를 숨기지 않는다.
3. Java06의 84개 raw와 단계 관찰을 새 고정 profile로 소비한다. full primary/repl 관찰은 구현 여부를 분리한다. 같은 site cache, 다른 site URI cache, denied retry/catch, trust denial, invalid/spelling 및 source-failure cache의 새 Java 관찰은 아직 필요하며 이번 문서는 취득하지 않았다.
4. 새 typed effect의 token/reentry/close/timeout/GC, 원래 file/modulepath load, strict platform/whole-selected 회귀를 새 frozen artifact로 실행한다. Java source 기반 예상 구조만으로 pass를 만들지 않는다.
5. 명시 gap ledger를 닫을 때 원본 raw와 실제 source/artifact를 결합한다. default json policy 범위를 full stdlib/module/security 호환 완료로 올리지 않는다. JVM-global singleton identity와 다른 미구현 표준 모듈 의무도 유지한다.

이 checkpoint는 JSON만 예외 허용하는 임시 패치가 아니라 공통 module admission 위치를 복원하는 필수 후속이다. 현재 문서 작성 시 구현·새 검증·완료 주장은 없다.
