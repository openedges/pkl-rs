from pathlib import Path
from collections import Counter
import hashlib
import json

MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
STAGE = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
OUT = Path(__file__).parent
ORACLE = STAGE / 'target/m2/stage47-renderer-api-oracle-06'
CANDIDATE = STAGE / 'target/m2/stage47-implementation-01/renderer-candidate-build-03'
read_inputs = {}

def read(path):
    data = path.read_bytes()
    row = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    previous = read_inputs.setdefault(str(path), row)
    assert previous == row, path
    return data

def load(path):
    return json.loads(read(path))

pins = {
    'report.json': 'cba85cf833baeb7655f6a6cdc81fd9ee39fe0ee43f441e43d891a47c0089ebf8',
    'inventory.json': 'b9f1243b213906d010998f87807388bee1dc2607ffb447f937a6fb9a3eb4cbc5',
    'closure.json': '8a10197b44469e40af433399d3caa2833a75be9fac957a262047ff33979ed2db',
}
metadata = {}
for name, digest in pins.items():
    metadata[name] = load(ORACLE / name)
    assert read_inputs[str(ORACLE / name)]['sha256'] == digest
assert metadata['closure.json']['closed'] is True
assert metadata['closure.json']['allPayloadHashesVerified'] is True
assert metadata['closure.json']['liveHandles'] == []
inventory = {row['path']: row for row in metadata['inventory.json']['files']}

def payload(relative):
    row = inventory[relative]
    data = read(ORACLE / relative)
    assert len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    return data

def counters(text):
    return {key: int(value) for key, value in (line.split('=', 1) for line in text.splitlines())}

for relative in ['RendererProbe.java', 'run.py', 'cases.json', 'profile.json']:
    payload(relative)
cases = json.loads(payload('cases.json'))
selected = {case['id']: case for case in cases if case['id'].startswith('stdlib-admission-')}
assert len(selected) == 3
for name in selected:
    for suffix in ['main.pkl', 'operations.tsv', 'reader.tsv']:
        payload(f'workspace/{name}/{suffix}')

calls, summaries, full_sessions = [], [], []
for observation in metadata['report.json']['observations']:
    name = observation['case']
    if name not in selected:
        continue
    process_events = []
    for session in [0, 1]:
        selected_calls = [call for call in observation['calls'] if call['session'] == session]
        event_count = counters(selected_calls[-1]['countersAfter'])['event']
        events = []
        for i in range(event_count):
            relative = f"cases/{name}/{observation['repeat']}/calls/session-{session}/event-{i}.bin"
            text = payload(relative).decode()
            events.append({'path': str(ORACLE / relative), 'text': text})
            process_events.append(text)
        full_sessions.append({'case': name, 'repeat': observation['repeat'], 'session': session,
                              'fullOrderedEvents': events})
    process_prefix = f"cases/{name}/{observation['repeat']}"
    assert payload(process_prefix + '/stdout.bin') == ''.join(event + '\n' for event in process_events).encode()
    payload(process_prefix + '/stderr.bin')
    for call in observation['calls']:
        prefix = call['rawPrefix']
        expected = {}
        channels = {}
        for channel in ['stdout', 'stderr']:
            raw = payload(prefix + f'.{channel}.bin')
            units = payload(prefix + f'.{channel}.code-units.bin')
            assert len(units) % 2 == 0
            assert units.decode('utf-16-be', 'surrogatepass').encode('utf-8', 'replace') == raw
            channels[channel] = {
                'rawPath': str(ORACLE / (prefix + f'.{channel}.bin')),
                'rawSha256': hashlib.sha256(raw).hexdigest(),
                'utf16Path': str(ORACLE / (prefix + f'.{channel}.code-units.bin')),
                'utf16Sha256': hashlib.sha256(units).hexdigest(),
                'rawBytes': len(raw), 'utf16Bytes': len(units),
            }
        status = payload(prefix + '.status.bin').decode()
        assert status == call['status'] and status in ['success\n', 'error\n']
        assert payload(prefix + '.expression.bin').decode() == call['expression']
        for side in ['Before', 'After']:
            text = payload(prefix + f'.counters-{side.lower()}.bin').decode()
            assert text == call['counters' + side]
            expected[side] = counters(text)
        assert expected['Before']['read'] == expected['After']['read'] == 0
        events = []
        for i in range(expected['Before']['event'], expected['After']['event']):
            rel = str(Path(prefix).parent / f'event-{i}.bin')
            text = payload(rel).decode()
            events.append({'path': str(ORACLE / rel), 'text': text})
        admission = [event for event in events if event['text'].startswith('policy-import ') or event['text'].startswith('policy-resolve-module pkl:') or event['text'].startswith('actual-module-denied ')]
        calls.append({
            'case': name, 'mode': selected[name]['mode'], 'repeat': observation['repeat'],
            'session': call['session'], 'prefix': prefix, 'expression': call['expression'],
            'status': status, 'channels': channels, 'countersBefore': expected['Before'],
            'countersAfter': expected['After'], 'fullOrderedEventsDuringCall': events,
            'stdlibAdmissionSubset': admission,
            'qualification': '전체 raw 채널은 그대로 보존한다. admission subset은 계획상 단계 연결용이며 전체 Java event/counter 일치나 실제 Rust 실행을 뜻하지 않는다.',
        })
for name in selected:
    group = [call for call in calls if call['case'] == name]
    assert len(group) == 28
    representatives = [call for call in group if call['repeat'] == 0 and call['session'] == 0]
    assert len(representatives) == 7
    summaries.append({'case': name, 'mode': selected[name]['mode'], 'calls': len(group),
                      'statuses': dict(Counter(call['status'].strip() for call in group)),
                      'representativeSequence': [{'expression': call['expression'], 'status': call['status'],
                                                  'stdlibAdmissionEvents': [event['text'] for event in call['stdlibAdmissionSubset']]}
                                                 for call in representatives]})
assert len(calls) == 84
assert Counter(call['status'] for call in calls) == {'success\n': 80, 'error\n': 4}
mapping = {'schema': 1, 'scope': '봉인 Java06의 정책 API84개를 기존 raw에서 읽어 연결한 구현 준비 자료. 새 취득/실행/호환 통과가 아니다.',
           'pins': pins, 'cases': summaries, 'calls': calls, 'fullSessionEvents': full_sessions,
           'notCovered': ['동일 import 노드 성공 후 재호출', '동일 evaluator의 별도 import 노드 URI cache hit',
                          '거부 후 같은 import 재시도', 'custom trust 거부', '다른 stdlib/URI spelling',
                          'primary/repl 정책 경로의 Rust 구현', '정책84의 실제 native/Node/browser 비교']}
(OUT / 'java06-policy84-mapping.json').write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + '\n')

main_paths = [
    'crates/pkl-runtime/src/modules.rs', 'crates/pkl-runtime/src/vm/modules.rs',
    'crates/pkl-runtime/src/vm/stdlib_modules.rs', 'crates/pkl-runtime/src/vm.rs',
    'crates/pkl-runtime/src/stdlib_sources.rs', 'crates/pkl-runtime/src/stdlib/modules.txt',
    'crates/pkl-runtime/src/evaluation/frontend.rs', 'crates/pkl-runtime/src/evaluation/session.rs',
    'crates/pkl-runtime/src/host.rs', 'crates/pkl-runtime/src/probe.rs',
    'crates/pkl-runtime/examples/support/module_host.rs', 'crates/pkl-runtime/examples/support/classpath_host.rs',
    'crates/pkl-runtime/tests/m2_module_transport.rs', 'crates/pkl-napi/src/lib.rs', 'crates/pkl-wasm/src/lib.rs',
    'tools/platform/module-preparation-session.mjs', 'tools/platform/resource-session.mjs',
    'tools/renderer_fixtures.py', 'references.lock',
    'target/m2/stage47-runtime-review-01/stdlib-admission-design.ko.md',
]
for relative in main_paths:
    read(MAIN / relative)
for relative in main_paths[:16]:
    if relative.startswith('target/'):
        continue
    read(CANDIDATE / 'sources' / relative)
for relative in ['release.json', 'source-after.json', 'source-modes.json']:
    read(CANDIDATE / relative)
for relative in [
    'pkl-core/src/main/java/org/pkl/core/runtime/ModuleCache.java',
    'pkl-core/src/main/java/org/pkl/core/runtime/ModuleResolver.java',
    'pkl-core/src/main/java/org/pkl/core/runtime/VmLanguage.java',
    'pkl-core/src/main/java/org/pkl/core/module/ModuleKeys.java',
    'pkl-core/src/main/java/org/pkl/core/module/ModuleKeyFactories.java',
    'pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ImportNode.java',
    'pkl-core/src/main/java/org/pkl/core/ast/expression/unary/AbstractImportNode.java',
    'pkl-core/src/main/java/org/pkl/core/SecurityManagers.java', 'stdlib/json.pkl',
]:
    read(MAIN / 'external/pkl' / relative)

source_inputs = {'schema': 1, 'mainCommitObserved': '674d3cabdd0e9c421a2cb9b820a22f2456755629',
                 'candidate': str(CANDIDATE), 'candidateReleaseSha256': read_inputs[str(CANDIDATE / 'release.json')]['sha256'],
                 'scope': '명시경로로만 읽었다. target/Cargo/cache 디렉터리를 재귀 열거하지 않았다. Stage47 live 구현은 입력이 아니다.',
                 'files': read_inputs}
(OUT / 'input-manifest.json').write_text(json.dumps(source_inputs, ensure_ascii=False, indent=2) + '\n')
changes = [path for path, row in read_inputs.items() if hashlib.sha256(Path(path).read_bytes()).hexdigest() != row['sha256']]
assert not changes, changes
(OUT / 'readback.json').write_text(json.dumps({'schema': 1, 'explicitInputs': len(read_inputs), 'inputChanges': changes,
                                             'javaCallsMapped': len(calls), 'javaStatuses': {'success': 80, 'error': 4},
                                             'newAcquisitions': 0, 'newTests': 0}, indent=2) + '\n')
print(json.dumps({'explicitInputs': len(read_inputs), 'javaCallsMapped': 84, 'inputChanges': changes}))
