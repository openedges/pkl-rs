"""Read explicit frozen source/evidence paths; execute no evaluator or tests."""
from pathlib import Path
import ast
import collections
import difflib
import hashlib
import json
import stat
import struct
import zipfile

OUT = Path(__file__).resolve().parent
MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
STAGE = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
IMPL = STAGE / 'target/m2/stage47-implementation-01'
C04 = IMPL / 'renderer-candidate-build-04'
C05 = IMPL / 'renderer-candidate-build-05'
JAVA = STAGE / 'target/m2/stage47-renderer-api-oracle-10'
JAR = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42/.cache/oracle/pkl-tools-0.32.0.jar')
PIN = {
    C04/'release.json': '603954ff79e6401aa8648f8e69c118d07065897e0e451ed59b250970e0e3801a',
    C04/'source-after.json': '72a73c83065bebcc02824724c6b2e577cb79d7a171557baaf1fe695a419f5e50',
    C05/'release.json': '93439249df0358843498ff16f62e80616a9916aa0c2faad257ad464fe1f55221',
    C05/'source-after.json': '24e362fcbd1610e8ce9710178b3ac39464c26656014822c85e649bd99d8840d8',
    JAVA/'report.json': '20a00c5fb207d8fe80308b849103a6a4bc2a153f1459201a749c62466f84d425',
    JAVA/'inventory.json': 'bc7a79974a4fd727a1e395221c0e7f91b2a9083d4a0d79083fe10427a8729084',
    JAVA/'closure.json': '0dac930649a021e43b2ecb382a731bf3ab293a2747225298a9b65e20a533940f',
    JAR: 'c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059',
}
inputs = {}
def read(path):
    assert stat.S_ISREG(path.lstat().st_mode), path
    data = path.read_bytes()
    row = {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
    if path in PIN: assert row['sha256'] == PIN[path], path
    old = inputs.setdefault(str(path), row)
    assert old == row, path
    return data
def obj(path): return json.loads(read(path))
def save(name, data):
    (OUT/name).write_text(json.dumps(data, indent=2, ensure_ascii=True)+'\n')

oldmap, newmap = obj(C04/'source-after.json'), obj(C05/'source-after.json')
oldrelease, release = obj(C04/'release.json'), obj(C05/'release.json')
for root, rel in [(C04, oldrelease), (C05, release)]:
    for key in ['source_modes', 'build_report', 'environment']:
        assert hashlib.sha256(read(Path(rel[key]))).hexdigest() == rel[key+'_sha256']
delta = []
diff = []
for name in sorted(oldmap.keys() | newmap.keys()):
    if oldmap.get(name) == newmap.get(name): continue
    row = {'path':name,'beforeSha256':oldmap.get(name),'afterSha256':newmap.get(name)}
    delta.append(row)
    before = read(C04/'sources'/name) if name in oldmap else b''
    after = read(C05/'sources'/name) if name in newmap else b''
    if before: assert hashlib.sha256(before).hexdigest() == oldmap[name]
    if after: assert hashlib.sha256(after).hexdigest() == newmap[name]
    diff.extend(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                                     fromfile='C04/'+name,tofile='C05/'+name))
save('source-delta.json',delta)
(OUT/'changes.diff').write_text(''.join(diff))
rust_inputs = [
 'src/value.rs','src/value_identity.rs','src/heap.rs','src/pkl_string.rs','src/vm.rs',
 'src/vm/identity.rs','src/vm/collections.rs','src/vm/forcing.rs','src/vm/typecheck.rs',
 'src/vm/modules.rs','src/vm/compiler_expressions.rs','src/vm/primitives.rs',
 'src/vm/strings.rs','src/vm/rendering.rs','tests/m2_string_drop_last.rs',
]
for name in rust_inputs:
    relative='crates/pkl-runtime/'+name
    assert hashlib.sha256(read(C05/'sources'/relative)).hexdigest() == newmap[relative]
java_sources = [
 'runtime/VmUtils.java','ast/builder/SymbolTable.java','ast/builder/AstBuilder.java',
 'ast/expression/generator/GeneratorForNode.java',
 'ast/expression/generator/RestoreForBindingsNode.java',
 'ast/expression/primary/WithCustomThisExpression.java',
 'ast/expression/literal/FunctionLiteralNode.java',
 'ast/member/ObjectMember.java','ast/ConstantValueNode.java','stdlib/base/StringNodes.java',
]
for name in java_sources:
    relative='external/pkl/pkl-core/src/main/java/org/pkl/core/'+name
    assert hashlib.sha256(read(C05/'sources'/relative)).hexdigest() == newmap[relative]

# Reuse the already reviewed binary parser as a function only; its module's
# output-producing top-level body is never executed.
parser_path=MAIN/'target/m2/stage47-boxing-identity-design-01/read_inputs.py'
parser_source=read(parser_path).decode()
node=next(n for n in ast.parse(parser_source).body if isinstance(n,ast.FunctionDef) and n.name=='class_methods')
parser_function=ast.get_source_segment(parser_source,node)
filter_text="if ref and any(k in ref for k in ['java/lang/', 'evalInt', 'evalFloat', 'evalBoolean', 'evalGeneric', 'getValue', 'getLong', 'getDouble', 'getBoolean', 'getObject']):"
assert filter_text in parser_function
parser_function=parser_function.replace(filter_text,'if ref:')
namespace={'struct':struct}
exec(compile(parser_function,str(parser_path),'exec'),namespace)
jar_link=str(JAR.readlink()) if JAR.is_symlink() else None
jar_resolved=JAR.resolve(strict=True)
PIN[jar_resolved]=PIN[JAR]
jar_bytes=read(jar_resolved)
save('jar-location.json',{'advertisedPath':str(JAR),'literalLink':jar_link,
                         'resolvedPath':str(jar_resolved),'sha256':hashlib.sha256(jar_bytes).hexdigest()})
classes={}
with zipfile.ZipFile(JAR) as archive:
    for name in ['com/oracle/truffle/api/impl/FrameWithoutBoxing',
                 'org/pkl/core/runtime/VmUtils',
                 'org/pkl/core/ast/expression/generator/GeneratorForNode',
                 'org/pkl/core/ast/expression/generator/RestoreForBindingsNode']:
        data=archive.read(name+'.class')
        selected=namespace['class_methods'](data)
        if name.endswith('FrameWithoutBoxing'):
            selected=[m for m in selected if m['name'] in ['getValue','getObject','materialize']]
        elif name.endswith('VmUtils'):
            selected=[m for m in selected if m['name']=='copyLocals']
        else:
            selected=[m for m in selected if m['name'] in ['execute','executeGeneric','executeIteration']]
        classes[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'methods':selected}
    data=archive.read('com/oracle/truffle/api/impl/FrameWithoutBoxing.class')
    offset=8
    def u2():
        global offset
        value=struct.unpack_from('>H',data,offset)[0]; offset+=2; return value
    cp=[None]*u2(); k=1
    while k<len(cp):
        tag=data[offset];offset+=1
        if tag==1:
            size=u2();cp[k]=data[offset:offset+size].decode('utf-8','replace');offset+=size
        elif tag in (7,8,16,19,20):cp[k]=u2()
        elif tag in (3,4,9,10,11,12,17,18):offset+=4
        elif tag in (5,6):offset+=8;k+=1
        elif tag==15:offset+=3
        else:raise AssertionError(tag)
        k+=1
    offset+=6
    interfaces=[cp[cp[u2()]] for _ in range(u2())]
    classes['com/oracle/truffle/api/impl/FrameWithoutBoxing']['interfaces']=interfaces
    assert 'com/oracle/truffle/api/frame/MaterializedFrame' in interfaces
save('pinned-jar-boundaries.json',classes)

report, inventory, closure = obj(JAVA/'report.json'), obj(JAVA/'inventory.json'), obj(JAVA/'closure.json')
assert closure['closed'] and closure['reportSha256']==PIN[JAVA/'report.json']
assert closure['inventorySha256']==PIN[JAVA/'inventory.json'] and not closure['liveHandles']
declared={}
for row in inventory['files']:
    relative=Path(row['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    assert str(relative) not in declared
    data=read(JAVA/relative)
    assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],relative
    declared[str(relative)]=row
assert len(declared)==closure['files']
counts=collections.Counter(); rows=[]
for group in report['observations']:
    for call in group['calls']:
        prefix=JAVA/call['rawPrefix']
        raw={suffix:read(Path(str(prefix)+'.'+suffix+'.bin')) for suffix in [
            'status','error-class','source','expression','stdout','stderr',
            'stdout.code-units','stderr.code-units','counters-before','counters-after',
            'reads-before','reads-after','message-null']}
        assert raw['status'].decode()==call['status']
        assert raw['error-class'].decode()==call['errorClass']
        assert raw['source'].decode()==call['source']
        assert raw['expression'].decode()==call['expression']
        assert raw['counters-before'].decode()==call['countersBefore']
        assert raw['counters-after'].decode()==call['countersAfter']
        channel='stdout' if call['status']=='success\n' else 'stderr'
        assert hashlib.sha256(raw[channel]).hexdigest()==call['utf8Sha256']
        assert hashlib.sha256(raw[channel+'.code-units']).hexdigest()==call['utf16BESha256']
        assert raw[channel].hex()==call['utf8Hex']
        assert raw[channel+'.code-units'].hex()==call['utf16BEHex']
        for ch in ['stdout','stderr']:
            text=raw[ch+'.code-units'].decode('utf-16-be','surrogatepass')
            assert text.encode('utf-8','replace')==raw[ch],call['rawPrefix']
        counts[call['status']]+=1
        rows.append({'case':group['case'],'repeat':group['repeat'],'session':call['session'],
            'prefix':call['rawPrefix'],'expression':call['expression'],'status':call['status'],
            'rawHashes':{k:hashlib.sha256(v).hexdigest() for k,v in raw.items()},
            'conversionHintObserved':b'This value was converted during rendering.' in raw['stderr']})
assert len(rows)==report['apiCalls'] and counts==report['counts']
assert not report['inputChanges'] and report['workspacesUnchanged'] and report['jarStable']
for path, expected in report['inputHashes'].items():
    input_path=jar_resolved if Path(path)==JAR else Path(path)
    assert hashlib.sha256(read(input_path)).hexdigest()==expected,path
for row in report['records']:
    assert row['result']['exit_code']==0 and not row['result']['timed_out']
    prefix=JAVA/'cases'/row['case']/str(row['repeat'])
    for channel in ['stdout','stderr']:
        assert hashlib.sha256(read(prefix/(channel+'.bin'))).hexdigest()==row['result']['sha256'][channel]
repeat_paths=0
for relative in declared:
    parts=Path(relative).parts
    if len(parts)>3 and parts[0]=='cases' and parts[2]=='0' and parts[3]=='calls':
        other=Path(parts[0],parts[1],'1',*parts[3:])
        assert str(other) in declared
        assert read(JAVA/relative)==read(JAVA/other),relative
        repeat_paths+=1
save('java10-raw-bindings.json',{'reportSha256':PIN[JAVA/'report.json'],
 'inventorySha256':PIN[JAVA/'inventory.json'],'closureSha256':PIN[JAVA/'closure.json'],
 'declaredPayloadsVerified':len(declared),'calls':len(rows),'counts':dict(counts),
 'freshJvmRecords':len(report['records']),'repeatCallPayloadPairsEqual':repeat_paths,
 'rows':rows,'qualification':'Public raw results only; hint substring records an observation, never replaces full raw channel binding. No frame instrumentation or native run.'})
save('inputs-before.json',inputs)
changes=[]
for path,row in inputs.items():
    p=Path(path);data=p.read_bytes()
    after={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    if after!=row:changes.append({'path':path,'before':row,'after':after})
assert (str(JAR.readlink()) if JAR.is_symlink() else None)==jar_link
assert JAR.resolve(strict=True)==jar_resolved
assert not changes,changes
save('source-stability.json',{'explicitInputs':len(inputs),'changes':changes,
 'sourceMapComparison':{'C04':len(oldmap),'C05':len(newmap),'changedOrAdded':len(delta),
                       'added':sum(x['beforeSha256'] is None for x in delta),
                       'deleted':sum(x['afterSha256'] is None for x in delta)},
 'qualification':'All enumerated review inputs rehashed. Other immutable snapshot payloads are map-compared, not reread or claimed independently rehashed. No tree traversal.'})
print(json.dumps({'sourceDelta':len(delta),'explicitInputs':len(inputs),'java10Calls':len(rows),
                  'java10Counts':dict(counts),'changes':changes}))
