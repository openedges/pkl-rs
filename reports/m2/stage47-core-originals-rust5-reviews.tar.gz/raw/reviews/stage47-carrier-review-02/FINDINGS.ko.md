# Stage47 C05 identity 후속 소스 검토

검토 범위에서 새 차단 결함은 찾지 못했다. 이는 불변 C05의 제한된 소스 검토 결과이며, 전체 언어·identity 호환 통과나 최종 Stage47 완료 판정이 아니다. 새 Java/native/Rust/build/test 실행은 하지 않았다.

## 입력과 범위

- C04 release `603954ff79e6401aa8648f8e69c118d07065897e0e451ed59b250970e0e3801a`와 C05 release `93439249df0358843498ff16f62e80616a9916aa0c2faad257ad464fe1f55221`를 고정했다.
- C05 source map은 `24e362fcbd1610e8ce9710178b3ac39464c26656014822c85e649bd99d8840d8`, 47,909개 경로이다. C04 대비 14개 변경과 새 `m2_string_drop_last.rs` 1개이며 삭제는 없다. 변경 15개 및 명시된 추가 검토 입력만 바이트를 직접 읽었다. 나머지 동일 snapshot 경로를 모두 재해시했다고 주장하지 않는다.
- 이미 끝난 small-stack 3파일 검토는 `../stage47-stack-correction-review-01/report.json`을 재사용한다. C05의 `vm.rs`에는 generator/Observe 변경도 있으므로 그 추가분을 별도 읽었다. parser 한도·테스트 depth 변경을 이번 교정에 새로 포함하지 않았다.
- Java10 report `20a00c5fb207d8fe80308b849103a6a4bc2a153f1459201a749c62466f84d425`, inventory `bc7a79974a4fd727a1e395221c0e7f91b2a9083d4a0d79083fe10427a8729084`, closure `0dac930649a021e43b2ecb382a731bf3ab293a2747225298a9b65e20a533940f`를 고정했다. 명시 inventory 7,171개 payload를 직접 읽고 full raw status/stdout/stderr/UTF16BE/JavaUTF8/counter를 436개 API 보고서에 연결했다. 264 success와 172 ordinary error이며 raw 반복 비교도 일치했다. 이는 Java 관찰을 재검증한 것이며 C05 native 비교를 실행한 것이 아니다.

## String.dropLast

C05 `crates/pkl-runtime/src/pkl_string.rs:103`은 뒤에서 UTF16 unit를 순회하고 인접 high/low surrogate pair를 한 code point로 센다. 고립 surrogate를 제거 전 다른 값으로 변환하지 않는다. `count == 0`은 receiver token을 보존하고, 양수로 전체를 제거하면 canonical empty token 260을 사용하며, 남는 proper substring은 새 token을 얻는다. Host가 제공한 empty String의 allocation과 source empty literal을 일괄 합치지 않는다(`source_literal`, 27행). reserved Long/Boolean/null token과 fresh 시작값 261도 겹치지 않는다(`value_identity.rs:17`).

이는 pinned `StringNodes.java:504`의 `checkPositive` → `codePointOffsetFromEndToCharOffset` → `substring(0, charIndex)` 경로와 일치하는 소스 설계다. Java `VmUtils.java:553`은 음수만 거절하고, 684행의 역방향 surrogate 처리도 대응한다. C05 `vm/primitives.rs:264`은 Int type check 후 음수 MessageFormat 숫자 표기를 사용한다. 큰 양수는 문자열 길이만큼만 순회한다.

Java10의 228개 Unicode/count API와 36개 document reference API는 별도 raw 관찰이다. 같은 문자열의 dropLast(0)는 conversion hint가 없고, 다른 String을 거쳐 내용만 복구한 결과는 hint가 있다. 새 Rust 테스트는 pending receiver/count 중 collect와 close 후 owned UTF16 결과를 확인하는 회귀 소스이다. 이번 검토가 그 테스트를 새 실행한 것은 아니다.

## Observe와 constant numeric property

C05 `vm.rs:5594`의 `box_constant_result`는 Observe만 제외한 실행 본문이 정확히 단일 Constant일 때만 해당 declaration result를 한 번 boxing한다. Observe 자체를 지우지 않고 일반 표현식/함수 결과를 상수로 승격하지 않는다. 기존 AST constant 조건과 local typed 예외도 유지한다(`vm.rs:5935`, `vm/compiler_expressions.rs:655`). 이 경로는 receiver마다 상수 숫자를 새 boxing하던 C04의 알려진 누락을 좁게 교정한다.

검증 한계: Java10의 `numeric-constant-property-two-instances` 52개 API에서 `new C {}`/`new F {}`는 서로 다른 instance라는 보장이 없다. empty body가 prototype을 재사용할 수 있으므로 이 사례만으로 independent-instance identity가 검증됐다고 쓰면 안 된다. `../stage47-carrier-review-01/constant-property-control-unexecuted.pkl`의 서로 다른 필수 `tag` 값을 가진 대조군은 여전히 미실행 제안이다. 일반 constant collection identity와 다른 producer의 완성도도 이 수정으로 닫히지 않는다.

## GeneratorFor / RestoreForBindings

Pinned `GeneratorForNode.java:34,164`는 하나의 AST-owned descriptor와 iteration마다 새 physical frame을 구분한다. `RestoreForBindingsNode.java:31`은 parameter slots와 for-generator slots를 합쳐 복사한다. `SymbolTable.java:309`의 parameter slots에는 method/lambda parameter뿐 아니라 let/object-body parameter도 포함된다. 따라서 이를 'for 변수만 복사'라고 설명하면 부정확하다.

C05 `vm/identity.rs:149,177`은 source owner/slot의 kind를 읽고 별도의 target descriptor에 저장한다. `Environment.copy_locals`는 현재 lexical frame의 parameter/let/for binding 집합을 보유하며 enclosing closure capture 전체를 무조건 복사하지 않는다. `invoke_function`은 새 호출의 copy 집합만 초기화하고 captured physical 값은 유지한다(`vm.rs:3333`). generator binding의 descriptor는 generator execution site로 분리하며, iteration마다 outer physical locals/owners를 저장·교체했다가 복원한다. Generated member는 forcing 시 해당 member target descriptor로 복사하고 restore flag를 해제한다(`vm.rs:2449`).

Object로 승격된 descriptor에 old primitive physical 값이 남은 경우 `copy_captured_locals`의 boxing이 필요한 근거도 확인했다. `VmUtils.java:438`은 MaterializedFrame이면 `getValue`를 사용한다. 실제 pinned JAR의 `FrameWithoutBoxing` class header가 VirtualFrame과 MaterializedFrame을 함께 구현하고, `getValue`의 primitive branch는 Long/Double/Boolean.valueOf를 호출한다. 소스의 인터페이스 분기만 보고 pinned 실행의 copy를 `getObject`라고 단정하지 않았다. 직접 읽은 class hash/호출 PC는 `pinned-jar-boundaries.json`에 남겼다. 이 설명은 bytecode 근거이며 Java frame instrumentation 결과가 아니다.

GC 쪽으로 C05 `GeneratorScope::roots`는 저장한 outer physical 값과 source owner, generator descriptor를 모두 root로 제공한다(`vm/identity.rs:55`). `vm.rs:1642`는 current/suspended context 양쪽의 frame에서 이를 수집한다. 기존 heap Environment trace의 local owner roots도 유지한다. 새 복사 과정에서 collect를 호출하거나 Host I/O를 추가하지 않는다. 타입 준비는 기존 compiler가 iterable 앞에 배치하는 경로를 유지하며, 타입 검사는 binding 시 수행한다. 실패 unwind의 frame/환경 소유권을 이 추가분이 별도 우회하지 않는다.

Java10 ordinary/union generator 합계 120개 API의 실제 결과는 old/fresh closure 값, repeated rendering, GC 요청 뒤 결과를 포함한다. 특히 `pOld.renderDocument(cachedA)`와 `pOld.renderDocument(old.apply(0))`의 conversion hint 차이를 raw 채널 그대로 보존했다. 이를 Java physical frame을 직접 계측했다는 증거나 모든 nested generator/constraint/custom-this 조합의 통과로 확대하지 않는다.

## 유지되는 미완료와 실패

- C05 원래 860 + supplement 424 + Java10 436 native 비교 및 original CLI 검사는 B/A의 별도 actual 기록 대상이다. 이 검토에는 새 native 결과를 섞지 않았다.
- 최종 Rust5·실제 platform 검증 완료 주장은 없다. C04 workspace/small-stack 실패, C05 시점의 fixed-heap/poll 가정 실패 및 후속 test-only 교정은 그대로 별도 범위다. A의 live heap test 변경은 읽어 signoff하지 않았다.
- 전체 scalar/String/collection producer identity, 전체 GC/Host retry 조합, stdlib admission 및 JVM-global singleton lifetime 의무는 남는다.
- readback-01/02는 검토 스크립트가 기존 oracle JAR symlink를 regular file로만 취급해 실패한 자체 수집기 오류이다. 그대로 보존했고 readback-03은 literal symlink와 resolved pinned JAR hash를 별도 기록해 actual exit 0으로 끝났다. 원본 evaluator 실패로 분류하지 않는다.

`source-stability.json`의 명시 입력 7,226개 전후 해시 변화는 0개이다. 입력 tree나 cache의 광역 walk, 원본 수정, production/Git 변경은 하지 않았다.
