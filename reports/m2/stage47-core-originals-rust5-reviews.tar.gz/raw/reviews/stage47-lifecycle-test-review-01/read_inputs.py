"""Inspect only explicitly named frozen test/evidence inputs; run no tests."""
from pathlib import Path
import hashlib
import json
import difflib
import re
import stat

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2/stage47-implementation-01')
C05=ROOT/'renderer-candidate-build-05'
NAMES=['identity-class-heap-tests-01','identity-type-heap-tests-03','identity-graph-heap-tests-01']
inputs={}
def read(p):
    assert stat.S_ISREG(p.lstat().st_mode),p
    d=p.read_bytes();row={'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
    assert inputs.setdefault(str(p),row)==row,p
    return d
def obj(p):return json.loads(read(p))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
cm=obj(C05/'source-after.json')
assert hashlib.sha256(read(C05/'release.json')).hexdigest()=='93439249df0358843498ff16f62e80616a9916aa0c2faad257ad464fe1f55221'
roots=[];maps={};deltas={}
for name in NAMES:
    q=ROOT/name;r=obj(q/'report.json');before=obj(q/'source-before.json');after=obj(q/'source-after.json');d=obj(q/'source-delta.json')
    assert before==after and r['source_stable']
    for n in ['before','after']:
        assert hashlib.sha256(read(q/('source-'+n+'.json'))).hexdigest()==r['source_'+n+'_sha256']
    for ch in ['stdout','stderr']:
        assert hashlib.sha256(read(q/(ch+'.bin'))).hexdigest()==r[ch+'_sha256']
    assert hashlib.sha256(read(Path(d['baseline_release']))).hexdigest()==d['baseline_release_sha256']
    prod=[p for p in sorted(cm.keys()|before.keys()) if p.startswith('crates/') and '/src/' in p and cm.get(p)!=before.get(p)]
    assert not prod,prod
    maps[name]=before;deltas[name]=d
    roots.append({'root':str(q),'reportSha256':hashlib.sha256(read(q/'report.json')).hexdigest(),
        'sourceMapSha256':r['source_before_sha256'],'actualExitCode':r['exit_code'],
        'productionCratesSourceMapDifferencesFromC05':prod,'command':r['command']})
graph='identity-graph-heap-tests-01';gm=maps[graph];gd=deltas[graph]
tests=[p for p in sorted(gm) if p.startswith('crates/pkl-runtime/tests/') and p.endswith('.rs') and cm.get(p)!=gm[p]]
rows=[];diff=[]
def source(name,p):
    d=deltas[name]
    q=ROOT/name/'source-delta'/p if p in d['changed'] else Path(d['baseline_snapshot'])/p
    data=read(q)
    assert hashlib.sha256(data).hexdigest()==maps[name][p]
    return data
for p in tests:
    old=read(C05/'sources'/p) if p in cm else b''
    if old:assert hashlib.sha256(old).hexdigest()==cm[p]
    new=source(graph,p)
    diff.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='C05/'+p,tofile=graph+'/'+p))
    old_tests=re.findall(r'#\[test\]\s*fn\s+(\w+)',old.decode())
    new_tests=re.findall(r'#\[test\]\s*fn\s+(\w+)',new.decode())
    assert old_tests==new_tests,p
    versions={}
    for name in NAMES:
        if p in maps[name]:
            data=source(name,p);versions[name]=hashlib.sha256(data).hexdigest()
    rows.append({'path':p,'beforeSha256':cm.get(p),'graph01Sha256':gm[p],
        'unchangedTestFunctionNames':new_tests,'frozenVersions':versions})
(OUT/'test-changes.diff').write_text(''.join(diff))
parent_test='crates/pkl-runtime/src/vm/output/tests.rs'
assert hashlib.sha256(read(C05/'sources'/parent_test)).hexdigest()==cm[parent_test]
for name in NAMES:assert maps[name][parent_test]==cm[parent_test]
save('frozen-bindings.json',{'roots':roots,'reviewedTestInputs':rows,
 'parentIdentityRegression':{'path':str(C05/'sources'/parent_test),'sha256':cm[parent_test],
 'unchangedAcrossSelectedRoots':True},
 'qualification':'Crates production identity is source-map comparison only. Explicit test/source/evidence paths are reread; no tree/cache traversal or new test execution.'})
save('inputs-before.json',inputs)
changes=[]
for p,row in inputs.items():
    data=Path(p).read_bytes();after={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    if row!=after:changes.append({'path':p,'before':row,'after':after})
assert not changes
save('source-stability.json',{'explicitInputs':len(inputs),'changes':changes})
print(json.dumps({'frozenRoots':len(roots),'reviewedTestFiles':len(rows),'explicitInputs':len(inputs),'changes':changes}))
