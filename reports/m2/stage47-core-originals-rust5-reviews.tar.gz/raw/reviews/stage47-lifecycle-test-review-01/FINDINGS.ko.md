# 초기화된 base graph 기준 lifecycle 테스트 교정 검토

완료된 불변 class01/type03/graph01의 제한된 테스트 변경에서 검증을 약화하는 새 차단 결함은 찾지 못했다. 이 판정은 8개 test/helper 소스에 한정한다. live wrapper/runtime/constraint 후속, 전체 workspace, Rust5, Java 의미 호환 판정이 아니다. 새 테스트를 실행하지 않았다.

## 고정한 실제 기록

- `identity-class-heap-tests-01`: source map `2bc9c86ab8fc7dd64e7fc4e5aa8c4bf0ffec494a8ba48d47bf611f9bcdbe8da0`, actual exit 0, class 8개 통과.
- `identity-type-heap-tests-03`: source map `4072849404fc4c5fcf05a032e34faf744d46c5646648ae62a31ff0af1fd718ca`, actual exit 101. recursive 3개와 resolution 7개 통과, metadata는 4개 통과/2개 실패였다. 실패 원문을 통과로 세지 않았다.
- `identity-graph-heap-tests-01`: source map `ecbac12de3358235f1701572dd3c4af4e769471dc89f38d6be91d3d5d2b9710d`, actual exit 0. collections 3개, predicates 2개, predicate-scope 2개, metadata 6개 통과.

각 producer report가 가리키는 before/after map과 stdout/stderr hash를 직접 대조했다. 각 map의 `crates/**/src/**`는 C05 production map과 차이가 없다. 이는 map 비교이며 모든 production payload를 새 재해시한 주장과 다르다. 8개 변경 test/helper는 frozen source-delta 또는 baseline snapshot에서 직접 읽고 C05 테스트와 diff했다. 기존 `#[test]` 함수명 집합/순서는 모두 유지됐다. 명시 입력 50개 전후 hash 변화는 0이다.

## 객체 수와 descriptor 수 분리

`support/eager_base.rs`의 `Baseline::added_values`는 먼저 `executable_live == initialized.executable_live + added_executables`를 exact 비교한다. 그 후 live에서 executable을 뺀 user value/custom-this node의 증감을 반환한다. descriptor를 허용 객체 누수 속에 섞거나 임의 `>=`로 바꾸지 않았다. class 파일의 `assert_retained`도 같은 두 exact 조건을 별도로 검사한다.

초기화 시점에는 user module과 evaluator-owned base graph가 있다. 따라서 non-rooted user module을 버린 경우 값 delta -1은 canonical Module parent까지 제거하라는 뜻이 아니다. collections/predicates의 과거 `live == 0`은 exact descriptor delta 6/2/5와 값 delta -1로 바뀌었고, 보관한 user module을 다시 start할 때 `StaleHandle`이어야 한다는 검사를 추가했다. close 후 slots 0도 추가했다. 도중 임시 객체·builder가 남으면 exact delta가 달라져 실패한다.

## parent identity·수거·종료 의무

C05부터 유지된 `src/vm/output/tests.rs:136`은 단순히 '남은 객체 수가 적다'는 검사가 아니다. base와 user module의 parent handle이 동일한지, scalar 완료 후 user module이 실제 StaleHandle인지, replacement module은 새 handle이지만 동일 parent를 사용하는지 확인한다. close 후 live/slots 0과 module/parent/base/replacement 모든 handle의 StaleHandle도 검사한다. 선택한 후속 세 snapshot에서 이 파일의 hash는 변하지 않았다.

class test의 partial singleton identity, cached prefix, transient object의 reclaimed/stale 검사와 ordinary failure 재시도는 유지됐다. Alias/type-resolution에서도 missing-type 첫 오류 내용, Unevaluated 상태, alias identity, stale resume token, parent read cursor가 유지된다. Cancel/close/timeout별 기대 ErrorKind와 deadline/now 값, cancelled-read 목록, context depth 0 및 terminal live/slots 0도 삭제하거나 완화하지 않았다. 기존 poll 반복수/step limit을 바꾸는 diff도 없다.

## metadata 두 실패의 후속 교정

type03의 첫 실패는 module result annotation이 이미 만든 Answer alias를 baseline 뒤 새 객체로 다시 센 오류였다. graph01은 baseline 시점의 alias를 중복 계산하지 않고 이후 captured object/temporary/transient를 각각 exact +1/+2/+3으로 센다. transient 수거 뒤 reclaimed와 StaleHandle 검사는 유지된다.

두 번째 실패는 callback.apply가 처음 실행될 때 추가되는 parameter-slot descriptor 1개였다. graph01은 기존 exact descriptor 기대를 11에서 12로 바꾸되 object 값은 여전히 suspended보다 감소해야 한다. 이 변경은 executable과 user graph를 함께 넓히는 방식이 아니다. graph01의 실제 metadata 6개 통과 기록은 type03의 2개 실패 원문을 대체하거나 지우지 않는다.

## 경계

- 이 baseline은 private evaluator-owned source-backed base의 현재 Rust architecture 회귀 기준이다. JVM heap node 수나 JVM-global singleton lifetime과 같다는 주장이 아니다.
- baseline 시점 자체의 모든 base node 구성을 이 helper가 독립 입증하는 것은 아니다. 해당 source-backed 초기화 근거와 canonical-parent 테스트는 별도 보존해야 한다.
- 이후 A의 live 수정, wrapper/runtime/constraint 검사와 workspace 재실행은 검토 대상 밖이다. 실제 source-stable snapshot 및 terminal을 받으면 별도로 대조해야 한다.
