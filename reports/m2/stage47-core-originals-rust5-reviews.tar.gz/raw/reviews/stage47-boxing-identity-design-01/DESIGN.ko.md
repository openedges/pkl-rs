# 공유 VM의 Java 참조·boxing provenance 설계

## 상태와 근거

이것은 C02 불변 소스와 pinned Java/JAR/JDK 자료의 읽기 전용 설계 검토다. 새 Java·native·브라우저 실행이나 production/Git 변경은 없다. 현재의 일부 `Unsupported`는 잘못된 hint를 성공으로 표시하지 않기 위한 임시 경계이며, M2 전체 종료에서는 아래 공통 메커니즘과 실제 차등 검증이 필요하다.

`AbstractRenderer.renderDocument` 88–110행의 `converted != value`는 Java 객체 참조 비교다. Pkl 값 동등성, float 비트 동등성, converter 호출 여부, 함수 본문 모양은 대체 조건이 아니다. `renderValue`에는 이 document catch가 없다. 옵션/매핑 생성과 최상위 `converter.convert` 자체 실패는 catch 밖이며, catch는 변환된 값을 방문하다 생긴 오류만 처리한다.

원문·JAR class·설치 JDK source 항목과 SHA는 `source-inputs.json`에 있다. Pinned JAR의 `ReadFrameSlotNodeGen.executeGeneric` bytecode는 pc33 `Long.valueOf`, pc79 `Double.valueOf`, pc126 `Boolean.valueOf`를 실제 호출한다. Int/Float literal의 generic 실행과 `getValue`도 각각 `valueOf`를 호출한다. Java는 실행하지 않고 classfile을 읽어 instruction boundary와 호출 대상을 파싱했다.

기록된 Temurin 21.0.12.1 runtime의 home/release/modules 해시를 기존 oracle profile과 대조했다. 같은 설치의 `src.zip`은 Long.valueOf 1202–1207행에서 -128…127 캐시/그 밖의 새 wrapper, Double.valueOf 772–773행에서 새 wrapper, Boolean.valueOf 178–179행에서 TRUE/FALSE를 반환한다. Pkl Float는 Double이고 Java Float32를 추가할 필요가 있다는 뜻은 아니다. 설치 source와 runtime image의 인접성만으로 모든 JDK bytecode를 검증했다고 주장하지 않는다. 이 source provenance 한계와 새 source archive 해시를 함께 남겼다.

## 참조가 보존되거나 사라지는 실행 경계

| 경계 | pinned 동작 | 필요한 VM 동작 |
| --- | --- | --- |
| `PklConverter.doConvert` 309–321행 / `VmFunction.apply` 72행 | converter가 없으면 입력 Object 그대로, 있으면 같은 Object argument로 call target 호출 | 값과 참조 provenance를 함께 전달한다. 호출했다는 이유만으로 새 identity를 만들지 않는다. |
| `FunctionNode.executeImpl` 129–139행 | Object argument를 parameter type node의 executeAndSet으로 저장하고 body.executeGeneric, return-type execute를 수행 | parameter 저장, body 결과, return type check를 구분한다. |
| Unknown/Any, `TypeNode` 295–322행 | type check가 no-op이어도 WriteFrameSlotNode가 숫자/Boolean을 primitive slot에 저장할 수 있다 | no-op type check와 no-op storage를 혼동하지 않는다. |
| `WriteFrameSlotNode` 41–66행 | Long/Double/Boolean primitive storage, 다른 타입/부적합 kind에서는 Object로 승격해 기존 reference 저장 | compiled descriptor 상태와 activation의 실제 slot representation을 기록한다. |
| `ReadFrameSlotNode` 37–64행 | primitive read를 Object 결과로 내보낼 때 boxing, Object read는 저장 reference 반환, fallback은 getValue | generic read마다 실제 boxing 규칙을 적용한다. property read와 같은 처리로 합치지 않는다. |
| `TypeNode.NumberTypeNode` 3073–3092행 | Long/Double 이력이 달라지면 descriptor를 Object로 승격하고 원래 boxed argument 보존 | 같은 함수의 이전 호출 종류가 이후 identity에 영향을 준다. |
| `VmUtils.copyLocals` 408–448행 | descriptor가 이미 Object라도 이전 materialized activation의 실제 slot은 primitive일 수 있어 getValue 사용 | descriptor kind 하나만으로 capture/copy identity를 결정하지 않는다. |
| `ReadLocalPropertyNode` 68–85행 / `VmUtils.readMemberOrNull` 313–326행 | cached Object를 그대로 반환 | property/cache/capture의 reference를 보존한다. 읽을 때 새로 box하지 않는다. |
| `ObjectMember.initConstantValue` 45–54행 | ConstantNode.getValue를 한 번 취해 Object로 보존 | literal generic 실행의 boxing과 이미 materialized된 constant object를 구분한다. |
| `TypeCastNode` 43–59행 / `PropertyTypeNode` 64행 | Object 입력을 typeNode.execute로 검사; primitive 타입 executeLazily는 대개 동일 Object 반환 | 검사만으로 새 reference를 만들지 않는다. lazy collection wrapper처럼 실제 다른 값을 반환하는 producer는 새 identity다. |

동일한 `(v) -> v`도 Unknown/Any slot이 primitive인 초기 호출과, 앞선 다른 타입 호출 때문에 Object로 승격된 뒤의 호출은 다른 결과를 낼 수 있다. 반대로 captured property를 반환하면 parameter slot을 다시 읽지 않고 기존 cached box를 반환할 수 있다. 같은 함수의 반복/다형성/재귀/capture 이력을 관찰해야 한다. 공백이나 lambda AST 패턴을 보고 identity를 판정하는 방식은 사용할 수 없다.

## 제안하는 공통 표현

1. 내부 평가 값에 payload와 별도 **semantic reference provenance**를 둔다. 예를 들어 `EvaluatedValue { value, representation }`에서 representation은 Java Object reference token 또는 unboxed primitive 상태다. public `Value`의 Pkl equality/hash/typecheck 결과는 그대로 두고, document reference 판단은 별도 연산으로 한다.
2. Object token은 generation/owner를 포함한 heap identity 또는 명시적인 allocation token이다. scalar generic boxing은 실행 시 발생시키며 Long.valueOf 범위와 Boolean은 해당 canonical token, Double boxing은 매번 새 token이다. 이미 Object로 전달된 값은 작은 정수/빈 문자열이라는 이유만으로 다시 canonicalize하지 않는다.
3. 문자열·Bytes의 token은 Rust buffer 주소와 반드시 같은 것이 아니다. clone/view/intern/empty 최적화나 두 Resource가 같은 Arc payload를 공유하는 일이 Java wrapper 재사용과 1:1이라는 producer 계약이 없으면 Arc 포인터만으로 전체 identity를 보장할 수 없다. buffer를 공유해도 새 Java wrapper인 producer에는 새 token이 필요하다. immutable payload 공유와 관찰 가능한 wrapper identity를 분리한다.
4. 함수별 descriptor 상태는 실행 가능한 code owner/slot을 key로 유지한다. activation별 slot은 `PrimitiveLong/Double/Boolean` 또는 `Object(EvaluatedValue)`로 따로 보존한다. recursive/materialized frame이 이전 physical slot kind를 유지할 수 있어 두 층이 필요하다. 같은 문자열의 함수명이나 span만을 key로 삼지 않는다.
5. parameter type recipe에서 저장 규칙을 결정한다. Int/Float/Boolean 고정 slot, String/객체 slot, Unknown/Any adaptive slot, Number adaptive slot을 구분한다. alias/constraint/lazy wrapper는 type check가 끝난 실제 결과를 저장하며, 실패한 검사 전에 descriptor나 provenance를 성공 상태로 바꾸지 않는다.
6. compiler/VM의 producer를 명시적으로 구분한다. generic numeric literal/arithmetic의 box 결과, cached Object constant, property cache read, primitive slot read, Object slot read, type-check passthrough, 실제 allocation, Host completion은 각각 transfer 규칙을 갖는다. 이것은 텍스트 패턴 추측이 아니라 실행되는 instruction/storage 계약이다. 기존 Constant/fusion 최적화가 해당 계약을 지우면 metadata 또는 instruction 구분을 보존해야 한다.

`Value` wrapper 또는 별도 sidecar는 구현 선택이다. sidecar라면 stack/input/local/environment/cache/constraint/module continuation의 모든 push/pop/clone/return에서 alignment를 보장해야 한다. renderer 한 곳에 임시 lookup 표를 넣어 현재 결과만 맞추는 구조는 captured cache와 deferred error를 처리하지 못한다.

구체적으로 `ResourceManager` 54–57행은 각 Resource의 bytes property를 `new VmBytes(resource.bytes())`로 만든다. C02 `vm/resources.rs` 188행은 같은 backing Arc를 clone한다. 서로 다른 URI의 Resource 두 개에 같은 backing byte[]/Arc를 주면 Java wrapper는 다르지만 Rust Arc 포인터는 같을 수 있다. Resource별 첫 bytes 강제와 그 cached value에 별도의 semantic token을 부여해야 한다. 이 control의 실제 Java/native 결과는 아직 취득하지 않았으므로 source-backed 요구사항으로 남긴다.

## Host·GC·오류 캐시

- provenance는 source forcing이나 Host callback을 새로 수행하지 않는다. reference 비교 때문에 값을 deep-force하거나 renderer로 재문자열화하지 않는다.
- callback 결과는 값과 identity ownership을 함께 받는 계약이 필요하다. 동일 URI Resource cache hit는 첫 완료의 reference를 유지하고 오류 retry는 실제 새 완료를 처리한다. 같은 내용의 서로 다른 URI 결과나 공유 payload는 identity가 같다는 증거가 아니다. 기존 opaque/raw completion과 새 typed completion의 provenance 경계를 명시한다.
- 프런트엔드 설정/기본 reader가 Java에서 같은 String Object를 재사용하는지 새 Object를 만드는지 fixture/profile 사실이 필요할 수 있다. raw UTF16만으로 이 차이를 추정하지 않는다. Node/Wasm binding은 내부 reference token을 임의로 위조할 수 있게 노출하지 않고, 명시적 소유 handle/기본 생성 규칙으로 연결해야 한다.
- token은 GC 객체를 대신하는 root가 아니다. document original/converted payload, slot/환경/캐시/보류 Host에 남은 값, 오류가 아직 formatting에 사용하는 program value를 계속 root로 추적한다. ObjectId 재사용과 token ABA를 막고 session close 후 token을 재활용하지 않는다.
- converter 반환 시 reference 비교 관찰을 고정한다. cached exception을 나중에 재생할 때 값 동등성으로 다시 판정하거나 다시 box하지 않는다. Java hintBuilder가 참조를 잡아 이후 nonforcing formatter에서 읽는 경계도 남아 있으므로, cache/catch 이후의 uncaught 재생까지 독립 검증한다. message-only catch 성공을 이후 hint 호환성으로 확대하지 않는다.
- per-evaluator executable descriptor와 JVM-static stdlib executable/cache는 별도 ownership 범위다. 기존 JVM-global singleton 차이를 이 설계가 자동으로 해결했다고 주장하지 않는다. fresh evaluator/same JVM/fresh JVM 이력을 구분한다.

## Identity 판단과 최종 hint 선택은 별도다

`VmExceptionRenderer` 99–107행은 external error template의 첫 빈 줄 이후를 hint로 분리한다. `StackTraceRenderer` 101–116행은 template hint를 dynamic hintBuilder보다 먼저 사용한다. 따라서 dynamic conversion hint가 raw에 없다고 same-reference라고 결론 낼 수 없다.

- JSON nonfinite 오류의 `cannotRenderValue`는 template hint가 없어 Double 관찰 경로다.
- PCF top-level scalar의 `invalidPcfTopLevelValue`도 template hint가 없어 작은/큰 Long, Boolean, 문자열·Bytes wrapper 관찰에 쓸 수 있다.
- JSON Bytes/Duration의 `cannotRenderTypeAddConverter`에는 template hint가 있어 conversion hint를 가린다. 이 경로는 identity와 별개인 hint precedence control이다.
- top converter 자체가 throw하면 document visit catch 이전이므로 conversion hint가 없어야 한다. nested document catch가 여러 개라면 Java unwind 순서와 template 우선순위를 모두 보존한다.

## 필수 구현·검증 checkpoint

1. 위 producer/slot transfer 계약과 storage ownership을 구현한다. callback/property/error cache까지 token을 보존하고 Pkl equality/hash와 분리한다. 초기 Unknown/Unsupported를 최종 예외 목록으로 옮겨 요구사항을 지우지 않는다.
2. B의 실제 Java profile에서 full stdout/stderr/UTF16·Java UTF8/status/frames를 얻는다. no-template-hint observer, Long -129/-128/127/128, nonfinite/-0/NaN, fresh/persistent polymorphic slot, typed/unknown/Number/alias/cast, captured cached property, materialized closure frame, same/new Bytes·String storage와 template precedence를 분리한다. 아직 실행하지 않은 조합은 미실행이다.
3. 같은 raw fixture를 native와 실제 Node/Chromium의 shared engine에 연결한다. 보류 Host 중 GC·취소·close·timeout·stale completion, 반복 실패/catch/uncaught cache replay, callback 횟수와 첫 오류 순서를 비교한다. token 자체를 기대 결과로 삼는 내부 모사 테스트만으로 호환성을 주장하지 않는다.
4. Rust 필수 검사·영향 있는 tooling/freshness·플랫폼 계약과 원본 두 프로그램/넓은 selected 회귀를 별도 고정 후보에서 실행한다. 기존 정규식·미구현·oracle 실패는 유지한다. 성능·메모리 목표는 대표 workload별로 별도 측정하며 metadata 비용을 숨기지 않는다.

단계적 구현은 가능하지만 전체 M2 종료 조건은 참조 identity가 실제로 관찰되는 경로의 일치다. 현재 renderer 후보의 임시 Unsupported는 이 필수 checkpoint가 남아 있다는 표시다.

## 이미 취득된 Java04와의 대조

이 문서 작성 중 B가 봉인한 `stage47-renderer-api-oracle-04`를 읽기 전용으로 확인했다. 새 Java 실행은 없었다. 782개 선언 payload 해시, 44회 API의 전체 상태·UTF16/Java UTF8·직접 counter 파일을 report와 대조했으며, 근거는 `java04-observation.json`이다. 동일한 identity closure를 r/p의 정확한 Float/Int/String/Bytes converter key에서 공유한다. 처음 Infinity document 오류에는 conversion hint가 있고, 같은 closure를 String으로 호출한 뒤에는 Infinity document 오류에 그 hint가 없으며 이후 반복과 명시적인 GC 요청 뒤에도 유지된다. warmed PCF1000에도 conversion hint가 없다. 이는 같은 AST의 참조 결과가 실제 slot type history에 의존한다는 관찰이다. Java GC 요청이 실제 물리적 collection을 증명하지는 않는다.

이 자료는 Java 관찰이며 native 통과율이 아니다. 독립 C02 검토 뒤 추가로 읽은 해당 raw 오류의 숫자 argument는 `∞`이고 hint의 ProgramValue는 `Infinity`다. C02는 오류 본문에도 double-to-string을 사용해 이 차이가 남는다. 기존 C02 보고서는 보존하고 `stage47-runtime-review-02/nonfinite-oracle-addendum.json`으로 연결했다. A가 C03에서 교정했다고 알렸으나, 이 문서는 그 후보를 검증하지 않았다.
