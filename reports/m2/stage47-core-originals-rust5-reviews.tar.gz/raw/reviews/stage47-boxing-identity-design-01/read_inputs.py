"""Read pinned source/JAR/JDK inputs without executing Java or guest code."""
from pathlib import Path
import hashlib
import json
import struct
import zipfile

OUT = Path(__file__).resolve().parent
STAGE = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
SOURCE = STAGE / 'target/m2/stage47-implementation-01/renderer-candidate-build-02/sources'
PROFILE = STAGE / 'target/m2/stage47-original-output-java-01/profile.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
profile = json.loads(PROFILE.read_bytes())
home = Path(profile['jdk']['properties']['java.home'])
jar, src = Path(profile['artifact']), home / 'lib/src.zip'
assert sha(jar) == profile['artifact_sha256']
assert sha(home / 'release') == profile['jdk']['release_sha256']
assert sha(home / 'lib/modules') == profile['jdk']['runtime_modules_sha256']
paths = [
 'ast/frame/WriteFrameSlotNode.java', 'ast/frame/ReadFrameSlotNode.java',
 'ast/type/TypeNode.java', 'ast/type/TypeCastNode.java', 'ast/member/FunctionNode.java',
 'ast/member/PropertyTypeNode.java', 'ast/lambda/ApplyVmFunction1Node.java',
 'ast/expression/member/ReadPropertyNode.java', 'ast/expression/member/ReadLocalPropertyNode.java',
 'ast/expression/literal/IntLiteralNode.java', 'ast/expression/literal/FloatLiteralNode.java',
 'ast/expression/literal/InterpolatedStringLiteralNode.java', 'ast/ConstantValueNode.java',
 'ast/ExpressionNode.java', 'ast/builder/AstBuilder.java', 'ast/member/ObjectMember.java',
 'runtime/VmUtils.java', 'runtime/VmFunction.java', 'stdlib/PklConverter.java', 'stdlib/AbstractRenderer.java',
]
input_hashes = {}
for relative in paths:
    name = 'external/pkl/pkl-core/src/main/java/org/pkl/core/' + relative
    path = SOURCE / name
    input_hashes[name] = sha(path)
for name in ['crates/pkl-runtime/src/value.rs', 'crates/pkl-runtime/src/pkl_string.rs',
             'crates/pkl-runtime/src/vm.rs', 'crates/pkl-runtime/src/heap.rs']:
    input_hashes[name] = sha(SOURCE / name)


def class_methods(data):
    offset = 8
    def u1():
        nonlocal offset
        v = data[offset]; offset += 1; return v
    def u2():
        nonlocal offset
        v = struct.unpack_from('>H', data, offset)[0]; offset += 2; return v
    def u4():
        nonlocal offset
        v = struct.unpack_from('>I', data, offset)[0]; offset += 4; return v
    count = u2(); cp = [None] * count; i = 1
    while i < count:
        tag = u1()
        if tag == 1:
            n = u2(); cp[i] = ('utf', data[offset:offset+n].decode('utf-8', 'replace')); offset += n
        elif tag in [3, 4]: offset += 4
        elif tag in [5, 6]: offset += 8; i += 1
        elif tag in [7, 8, 16, 19, 20]: cp[i] = (tag, u2())
        elif tag in [9, 10, 11, 12, 17, 18]: cp[i] = (tag, u2(), u2())
        elif tag == 15: cp[i] = (tag, u1(), u2())
        else: raise AssertionError(tag)
        i += 1
    def text(i): return cp[i][1]
    def method_ref(i):
        kind, owner, signature = cp[i]
        if kind not in [10, 11]: return None
        _, n, descriptor = cp[signature]
        return text(cp[owner][1]) + '.' + text(n) + text(descriptor)
    offset += 6
    interfaces = u2()
    offset += 2 * interfaces
    def attributes():
        nonlocal offset
        result = []
        for _ in range(u2()):
            name, size = text(u2()), u4(); payload = data[offset:offset+size]; offset += size
            result.append((name, payload))
        return result
    for _ in range(u2()):
        offset += 6; attributes()
    methods = []
    for _ in range(u2()):
        access, name, descriptor = u2(), text(u2()), text(u2())
        calls = []
        for attr, payload in attributes():
            if attr != 'Code': continue
            length = struct.unpack_from('>I', payload, 4)[0]; code = payload[8:8+length]; pc = 0
            while pc < len(code):
                op = code[pc]
                if op in [182, 183, 184, 185]:
                    ref = method_ref(struct.unpack_from('>H', code, pc + 1)[0])
                    if ref and any(k in ref for k in ['java/lang/', 'evalInt', 'evalFloat', 'evalBoolean', 'evalGeneric', 'getValue', 'getLong', 'getDouble', 'getBoolean', 'getObject']):
                        calls.append({'pc': pc, 'target': ref})
                if op in [170, 171]:
                    aligned = (pc + 4) & ~3
                    if op == 170:
                        low, high = struct.unpack_from('>ii', code, aligned + 4)
                        size = aligned - pc + 12 + 4 * (high - low + 1)
                    else:
                        n = struct.unpack_from('>i', code, aligned + 4)[0]
                        size = aligned - pc + 8 + 8 * n
                elif op == 196: size = 6 if code[pc+1] == 132 else 4
                elif op in [185, 186, 200, 201]: size = 5
                elif op == 197: size = 4
                elif op in [17, 19, 20, 132, 187, 189, 192, 193, 198, 199] or 153 <= op <= 168 or 178 <= op <= 184: size = 3
                elif op in [16, 18, 169, 188] or 21 <= op <= 25 or 54 <= op <= 58: size = 2
                else: size = 1
                pc += size
            assert pc == len(code)
        if calls: methods.append({'name': name, 'descriptor': descriptor, 'calls': calls})
    return methods


classes = {}
with zipfile.ZipFile(jar) as archive:
    for name in ['ast/frame/ReadFrameSlotNodeGen', 'ast/frame/WriteFrameSlotNodeGen',
                 'ast/expression/literal/IntLiteralNode', 'ast/expression/literal/FloatLiteralNode', 'ast/ConstantValueNode']:
        entry = 'org/pkl/core/' + name + '.class'; data = archive.read(entry)
        destination = OUT / 'jar-classes' / (name.replace('/', '__') + '.class'); destination.parent.mkdir(exist_ok=True); destination.write_bytes(data)
        classes[entry] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'methods': class_methods(data)}
jdk = {}
with zipfile.ZipFile(src) as archive:
    for name in ['Long', 'Double', 'Boolean', 'Float', 'String']:
        entry = 'java.base/java/lang/' + name + '.java'; data = archive.read(entry)
        target = OUT / 'jdk-source' / (name + '.java'); target.parent.mkdir(exist_ok=True); target.write_bytes(data)
        jdk[entry] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
result = {'scope': 'Source and already pinned binary input reading only. No JVM/evaluator/native/build/test execution.',
          'profileSha256': sha(PROFILE), 'jdkProfile': profile['jdk']['properties'],
          'jdkReleaseSha256': sha(home / 'release'), 'runtimeModulesSha256': sha(home / 'lib/modules'),
          'installedJdkSourceArchive': str(src), 'installedJdkSourceArchiveSha256': sha(src),
          'jdkSourceBindingQualification': 'The installed source archive is adjacent to the exact profile-bound release/runtime image. Its bytes are newly recorded; source adjacency alone is not a proof of every runtime bytecode. Pinned Pkl JAR classes below are read directly and their generic boxing call targets are independently parsed.',
          'jarSha256': sha(jar), 'pinnedInputHashes': input_hashes, 'jdkSources': jdk, 'pinnedJarClasses': classes}
(OUT / 'source-inputs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'inputSha256': sha(OUT / 'source-inputs.json'), 'pinnedSources': len(input_hashes), 'jarClasses': len(classes)}))
