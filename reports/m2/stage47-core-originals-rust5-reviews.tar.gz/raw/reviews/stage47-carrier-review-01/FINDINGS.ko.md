# C04 carrier/슬롯/GC 불변 소스 검토

검토 대상은 release SHA `603954ff79e6401aa8648f8e69c118d07065897e0e451ed59b250970e0e3801a`, source map SHA `72a73c83065bebcc02824724c6b2e577cb79d7a171557baaf1fe695a419f5e50`인 C04다. live 파일이나 후속 교정을 섞지 않았다. C03→C04 handoff의 정확한 77개 변경 경로는 양쪽 snapshot hash에 대조했다. 의미 검토는 아래 carrier/slot/boxing/bootstrap/GC 경계에 집중했으며, 모든 producer의 완전한 의미 검증을 주장하지 않는다. 새 Rust/Java/test 실행은 없다.

## 미완료 finding: power assertions가 constant numeric identity를 바꿈

`vm.rs:5888–5899` 및 `vm/compiler_expressions.rs:654–667`은 constant member 판정과 선boxing을 bytecode가 정확히 `[Constant(_)]`일 때만 한다. 하지만 `compiler_expressions.rs:142–144`의 power-assert 계측은 literal 뒤에 `Observe`를 삽입한다. 이 경우 같은 숫자 literal 속성도 constant_member가 false이고, 각 receiver가 처음 강제할 때 OperandStack.push가 별도 reference token을 만든다. 계측이 없으면 선언의 Constant Value에 선boxing한 token이 공유된다.

pinned Java `VmUtils.createObjectProperty:767–774`는 local typed 예외를 제외하고 ConstantNode를 ObjectMember.initConstantValue로 게시한다. `ObjectMember.java:45–53`은 node.getValue를 한 번 취해 wrapper를 보관한다. Java의 이 분류는 Rust의 Observe 명령 유무로 달라지지 않는다.

`constant-property-control-unexecuted.pkl`은 다른 tag를 가진 두 C instance에서 같은 선언의 `n=1000`을 교차 converter로 관찰하도록 작성한 **미실행** 입력이다. PCF 외부 Any 슬롯의 Object 이력을 사용하므로 JSON Float 외부 boxing과 구분한다. `r.renderDocument(a.n)`을 power assertions 양쪽 profile에서 관찰하는 대조가 필요하다. Java nohint/Rust hint 가능성은 소스 추론이며 실제 raw mismatch로 기록하지 않았다. A/root에 전달했다.

교정은 constant producer의 AST 의미 또는 계측을 제외한 명령 분류를 사용해야 한다. trace 명령 자체를 지워서 결과를 맞추거나 함수 body의 모든 숫자 literal을 선boxing하면 안 된다. ordinary literal 실행의 fresh boxing과 property constant의 선언별 shared wrapper는 별도다. constant collection identity라는 기존 공개 gap에 이 numeric/instrumentation 문제를 숨기지 않는다.

## 소스에서 확인한 구조

- `value_identity.rs`의 저장 Token은 NonZeroU64다. heap ObjectId를 포함하는 Reference enum은 관찰할 때만 만든다. reserved Long cache(1–256), Boolean(257/258), null(259)와 fresh token(261부터)을 구분한다. clone은 token을 보존하며 새 Bytes wrapper는 같은 Arc payload여도 새 token을 받는다. scalar token은 payload allocation이나 heap GC handle이 아니다.
- Number/Bytes/PklString의 Eq/Ord는 payload를 비교한다. `vm/equality.rs`의 atom/hash도 실제 숫자·문자·byte 값을 사용한다. renderer reference 관찰만 별도 Reference를 비교한다. backing Arc pointer나 payload equality로 Java wrapper identity를 대체하지 않는다.
- OperandStack.push/extend는 숫자를 boxed carrier로 만든다. physical local은 Number.reference=None으로 unboxed 상태를 보관할 수 있다. generic LoadLocal은 stack push에서 다시 boxing한다. 공개 mutable Vec 상속 경로의 실제 사용도 확인했으며 발견한 직접 대입은 기존 boxed 값/Null 처리다. 모든 미래 producer가 이 경계를 지킨다는 보장은 별도 의무다.
- `vm/identity.rs::bind_local`은 executable owner와 (block,instruction site)를 descriptor key로 사용한다. 서로 다른 let site를 단순 Vec index로 합치지 않는다. typed Int/Float는 fixed physical slot이고 Any/unknown/nullable/Number/일반 union은 adaptive다. Object로 promotion된 descriptor와 이미 materialize된 primitive activation을 구분한다. 일반 function capture 생성에서는 physical 값을 그대로 복사하며 무조건 Object로 변환하지 않는다.
- external renderer method body는 `output.rs:149–157`의 LoadLocal→BindLocal(Any)→LoadLocal을 거친다. 따라서 Java09에서 확인한 renderer 외부 parameter와 converter parameter의 서로 다른 boxing 경계를 표현한다. Java04의 공유 converter warm 결과와 Java09의 cached Float 반환 결과를 같은 단일 타입 규칙으로 합치지 않는다. 실제 Java09 전체 native 결과는 B의 별도 증거다.
- `vm/stdlib_modules.rs`는 같은 VM의 일반 module initializer/forcing continuation으로 base와 output을 강제한다. compiled unit0의 LoadBaseModule은 user entry 전에 실행된다. 새 VM을 재귀 생성하는 코드는 검토한 경로에 없다. 그러나 poll에서 append_definition의 parse/resolve/compile을 동기 호출하는 경로는 남아 있어 small-stack 안전성과는 별도다.
- canonical Module prototype는 plain module에서 builtin_class(Module)로 얻는다. 새 base 초기화가 이 parent를 유지하므로 user만 수거될 때 parent도 함께 사라진다는 이전 기대는 현재 graph와 다르다. 수정된 테스트는 무조건 `>=`로 완화하지 않고, 정확한 user handle 수거·base.parent 동일성·다음 user의 parent 재사용·close 뒤 모든 stale handle/live0/slots0을 검사한다. JVM-global singleton 수명이나 Java heap slot 총량과 같다는 주장은 하지 않는다.
- Environment.local_owners의 executable owner는 현재/suspended VM frame과 heap에 저장된 captured environment 양쪽 GC root에 포함된다. 기존 scopes/this/outer/locals/function-owner/renderer의 before·after 값 root도 유지한다. close는 캐시·executable roots와 heap을 해제한다. scalar token 자체에는 heap 참조가 없으므로 별도 tracing으로 의미를 만들지 않는다.

## 기존 실제 검사와 실패를 분리

`identity-history-tests-04`는 exit0/source-stable이며 library93·JSON8·join2·Java04 회귀1개(내부 raw44호출)를 실행했다. 이 source map과 C04를 비교하면 변경된 77개 경로 중 docs/m2-json-rendering.md만 다르고 production/test 파일은 같다. 이 제한을 actual focused test binding으로 기록했다. 새로 이 검사를 실행하지 않았다.

초기 `identity-external-method-tests-01` 및 `identity-library-stack-diagnosis-01`은 실제101이다. C04에서 manual Program의 256KiB/depth2000 테스트 한도는 그대로 유지되며 focused library에서 통과했다. 이것은 source-backed pipeline의 stack 안전성을 증명하지 않는다.

`identity-workspace-tests-01`과 `-02`는 같은 C04 source map에서 실제101이다. -02 원시 stderr는 전체 26개 target 실패를 보존하며, 그중 frontend/generic constructor/generic metadata/lexical/Set/Map/string/unicode의 8개 target에서 stack overflow abort를 기록한다. 나머지 heap 총량 관련 실패와 합쳐 전체 workspace 성공으로 세지 않는다. exact 실패 목록은 `existing-checks.json` 및 원본 raw binding에 남겼다.

동기 base compile call chain이 원인인지는 A의 좁은 phase 조사와 새 불변 교정으로 확인해야 한다. stack limit/depth나 raw expected 값을 바꿔 피하지 않는다. 이 검토는 C04의 최종 승인이나 compatibility pass가 아니다.

## 다음 경계

numeric constant/Observe 문제와 source-backed small-stack 실패의 교정 후 source diff를 다시 검토해야 한다. generator copyLocals/RestoreForBindings, constant collection object identity, 전체 producer identity, JVM-global stdlib lifetime, stdlib admission은 release에 명시된 필수 미완료 의무다. B의 860/424 native raw 비교, A의 원본 CLI 및 전체 Rust5/workspace 결과는 각자 실제 artifact/source identity로 결합하며 이 소스 검토에서 미리 통과로 표시하지 않는다.
