"""Read immutable two-file layout correction and existing actual outcomes only."""
from pathlib import Path
import hashlib
import json
import difflib
import stat

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2/stage47-implementation-01')
OLD=ROOT/'identity-reference-graph-tests-02'
NEW=ROOT/'identity-diagnostic-layout-tests-01'
C05=ROOT/'renderer-candidate-build-05'
inputs={}
def read(p):
 assert stat.S_ISREG(p.lstat().st_mode),p
 data=p.read_bytes();row={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert inputs.setdefault(str(p),row)==row,p
 return data
def obj(p):return json.loads(read(p))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
old=obj(OLD/'source-before.json');new=obj(NEW/'source-before.json');d=obj(NEW/'source-delta.json')
assert hashlib.sha256(read(NEW/'source-before.json')).hexdigest()=='9fc975ffc379c14d1f5dbb8213647b57d7f10c4be9736fdcf20457a117cf7437'
assert new==obj(NEW/'source-after.json')
changed=[p for p in sorted(old.keys()|new.keys()) if p.startswith('crates/') and '/src/'in p and old.get(p)!=new.get(p)]
assert changed==['crates/pkl-runtime/src/diagnostic.rs','crates/pkl-runtime/src/value.rs']
diff=[]
for p in changed:
 before=read(C05/'sources'/p);after=read(NEW/'source-delta'/p)
 assert hashlib.sha256(before).hexdigest()==old[p] and hashlib.sha256(after).hexdigest()==new[p]
 diff.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='C05/'+p,tofile='24533/'+p))
(OUT/'changes.diff').write_text(''.join(diff))
callbacks=['crates/pkl-runtime/src/vm.rs','crates/pkl-runtime/src/evaluation.rs',
 'crates/pkl-runtime/src/evaluation/frontend.rs','crates/pkl-runtime/src/evaluation/session.rs',
 'crates/pkl-runtime/src/diagnostic/frames.rs','crates/pkl-runtime/src/diagnostic/highlight.rs',
 'crates/pkl-runtime/src/parser.rs','crates/pkl-runtime/src/parser/string_lexer.rs']
for p in callbacks:
 assert old[p]==new[p]
 assert hashlib.sha256(read(C05/'sources'/p)).hexdigest()==new[p]
records=[]
for name in ['identity-diagnostic-layout-tests-01','identity-clippy-tests-01','identity-clippy-tests-02','identity-clippy-tests-03','identity-clippy-tests-04']:
 root=ROOT/name;r=obj(root/'report.json');before=obj(root/'source-before.json');after=obj(root/'source-after.json');delta=obj(root/'source-delta.json')
 assert before==after and r['source_stable']
 for side in ['before','after']:assert hashlib.sha256(read(root/('source-'+side+'.json'))).hexdigest()==r['source_'+side+'_sha256']
 for channel in ['stdout','stderr']:assert hashlib.sha256(read(root/(channel+'.bin'))).hexdigest()==r[channel+'_sha256']
 records.append({'root':str(root),'reportSha256':hashlib.sha256(read(root/'report.json')).hexdigest(),
 'actualExitCode':r['exit_code'],'sourceMapSha256':r['source_before_sha256'],'command':r['command']})
assert obj(ROOT/'identity-clippy-tests-04/source-before.json')==new
save('bindings.json',{'productionChangedFromCoherent21003':changed,'unchangedCallbacks':callbacks,'actualRecords':records,
 'qualification':'Focused tests and clippy04 bind this new source map. C05 platform and older native evidence are not retroactively rebound.'})
save('inputs-before.json',inputs)
changes=[]
for p,row in inputs.items():
 data=Path(p).read_bytes();after={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 if row!=after:changes.append({'path':p,'before':row,'after':after})
assert not changes
save('source-stability.json',{'explicitInputs':len(inputs),'changes':changes,'liveSourceRead':False,'newTestsOrEvaluation':False})
print(json.dumps({'changedProduction':changed,'explicitInputs':len(inputs),'actualExits':[r['actualExitCode']for r in records],'changes':changes}))
