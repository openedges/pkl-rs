# RuntimeError / Diagnostic cold metadata layout 검토

24533 불변 snapshot의 좁은 교정에서 새 차단 결함은 찾지 못했다. 새 evaluator/test/build/clippy 실행 없이 소스와 기존 actual 기록만 읽었다. Source map은 `9fc975ffc379c14d1f5dbb8213647b57d7f10c4be9736fdcf20457a117cf7437`이며 before/after가 같다.

Coherent21003 map 대비 production 변경은 정확히 `src/value.rs`, `src/diagnostic.rs` 두 파일이다. 전체 map의 나머지 차이는 permanent consumer의 hex decoder 한 군데이며 아래에 별도로 기록한다. Cargo/Clippy 설정이나 lint allow를 더한 변경은 없다.

## RuntimeError

`hint: Option<PklString>`을 outer RuntimeError에서 기존 `Option<Box<RuntimeErrorDetails>>`로 옮겼다. `Deref`는 carrier가 없으면 hint None과 기존 provenance default를 반환하고, `DerefMut`는 필요할 때만 기존 details carrier를 만든다. `set_template_hint`는 여전히 hint를 설정한 뒤 `hint_from_template=true`로 표시한다. Template 우선 여부를 판단하는 VM 경로, cached error/unwind·evaluation callback은 바뀌지 않았다.

`Clone`은 Box를 복제하므로 한 오류의 hint를 교체해도 clone의 hint/priority metadata가 바뀌지 않는다. PklString의 NUL·고립 surrogate를 UTF8로 우회하지 않는다. 새 회귀는 absent hint 할당, template marker, `[D800,0000,DC00]` exact units, clone 분리를 검사한다.

`hint=None`을 대입하면 빈 carrier가 생길 수 있으므로 derive Eq 대신 논리 payload Eq를 사용한다. undefined provenance, kind, message, span, frames와 dereferenced Details 전체를 비교한다. Hint와 template/Host/unavailable-origin/cached-module/spread/type-diagnostic metadata를 비교에서 빠뜨리지 않았다. 없던 carrier와 default-only carrier의 allocation 차이만 중립화한다. PklString의 payload equality와 semantic reference token 구분은 이 수정으로 바꾸지 않는다.

Hint만 필요한 오류에는 details Box가 새로 필요할 수 있다. 이를 모든 오류 경로에서 allocation이 줄거나 동일하다는 성능 결과로 해석하지 않는다. ErrorKind/message/frames/Display 전달 규칙을 바꿔 lint를 피하는 방식도 아니다.

## Diagnostic

`highlight_length_utf16: Option<usize>`을 항상 존재하던 boxed DiagnosticProvenance로 옮긴다. Constructor는 같은 None으로 초기화하고 기존 Box를 재사용하므로 underline width만 위한 추가 allocation이 없다. Deref/DerefMut로 parser의 width 설정과 evaluation의 Copy 읽기를 이어 준다.

EOF와 lossless string parser의 synthetic width는 계속 UTF16 단위이며 source span byte 길이로 재해석하지 않는다. Frame으로 폭을 전달하는 `evaluation.rs`, `evaluation/frontend.rs`와 실제 underline 렌더러는 변경되지 않았다. Diagnostic의 전체 Eq/Clone은 같은 logical provenance/width/message/span/member/module/frames/details를 유지한다. 이 검토는 Rust의 물리 struct layout/Debug 표기 자체가 동일하다는 주장이 아니다.

## Consumer의 별도 한 줄 교정

`m2_renderer_frame_identity_oracle.rs`에서 `.chunks_exact(2)`를 `.as_chunks::<2>().0.iter()`로 바꿨다. 그 앞의 even-length assert가 그대로 있어 leftover byte를 새로 허용하지 않으며 같은 모든 두-byte 묶음을 hex decode한다. 240 기대 행, 두 Rust Observe 설정, status/UTF16/JavaUTF8 비교와 close/slots 0은 바꾸지 않았다. 정확한 old/new hash와 diff는 `consumer-decoder-source-addendum.json`에 남겼다.

## 기존 actual 기록과 경계

- `identity-diagnostic-layout-tests-01` report `10448d347b21f9f764b8d14c6bbd1fdf30717841b1c849d339c541a563064ddb`: actual24533 exit0/source stable. Lib94, JSON·diagnostic·lossless focused targets, 기존 Java44 소비자와 frame identity480 assertion이 이 source에 묶인다.
- clippy01/02/03은 각각 actual exit101이며 당시 source map/원문을 그대로 유지한다.
- clippy04는 이 동일한 `9fc975ff…` map에서 actual exit0/source stable이다. `--workspace --all-targets --locked -- -D warnings` 명령과 stderr hash를 직접 대조했다.

명시 입력 43개와 decoder의 추가 두 소스는 전후 hash 변화 0이다. Live 소스를 final로 읽거나 original evidence/production/Git을 수정하지 않았다. Exact struct byte size·heap/performance 수치나 전체 compatibility 결과를 새로 측정하지 않았다.

이것은 두-file layout 및 기존 focused 검사에 대한 검토다. C05 platform/source 결과를 새 map에 소급 바인딩하지 않는다. 최종 full workspace/Rust5·native/portable 검사는 새 source/artifact provenance로 따로 닫아야 한다.
