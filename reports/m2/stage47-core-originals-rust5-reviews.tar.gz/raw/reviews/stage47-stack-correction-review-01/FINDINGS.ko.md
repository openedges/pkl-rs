# C04 이후 small-stack 교정의 좁은 소스 검토

대상은 `identity-stack-type-flow-tests-02`의 불변 source-before/after map과 source-delta다. 두 map은 SHA `a3075db8389039eec44e271e21438104410d8b0f3c722262e4fa784cd7b12828`로 동일하다. C04의 전체 47,908개 경로 map과 대조하면 변경은 `vm.rs`, `parser.rs`, `parser/string_parser.rs` 세 파일뿐이다. live generator/slot/dropLast/Observe 작업은 읽지 않았고 이 판정에 섞지 않았다.

새 실행은 없다. 아래 판단은 코드 이동의 의미 검토와 이미 끝난 검사 원문 대조다. 이 세 파일의 교정 범위에서 추가 blocker를 발견하지 못했으나, renderer/identity compatibility나 전체 workspace 성공으로 표시하지 않는다.

## VM bundled-load dispatcher

기존 `step`의 continuation 우선순위, instruction fetch, pc 증가, EndFunctionAmendment 처리와 `resolve_instruction_types` 순서는 같다. 그 뒤 LoadBaseModule/LoadRefModule만 큰 `step_instruction` 진입 전에 `import_stdlib`를 호출한다. 큰 matcher의 두 arm은 unreachable로 바뀌었다. 같은 URI, 같은 현재 frame, 같은 error Result를 반환하고, 공통 prepared-hash cleanup도 같은 위치에서 실행된다.

기존 arm은 `import_stdlib(...)?;`였고 새 arm은 `import_stdlib(...).map(|_| ())`다. 이 두 고정 URI에 대한 bool 결과를 무시하는 의미도 같다. stdlib source 설치·ordinary module initializer·bootstrap forcing continuation은 수정하지 않았다. Host 효과나 initializer를 Program construction/SourceSession compile 시점으로 앞당기지 않았다. 새 VM을 재귀 생성하지 않는다.

전체 map 비교와 diff는 임시 Program preparation 이동 및 stdlib trace 변경이 최종 교정에 없음을 확인한다. 특히 `vm/stdlib_modules.rs`는 C04의 SHA `dc35ef8cb40310566353f9e80315dd27ad49386db240372cf215df409961b3f0`와 같다. C04의 동기 bundled compile 자체는 유지하고 native stack에 큰 일반 dispatcher frame을 남기지 않는 교정이다.

## parser `is`/`as`와 `new` continuation

`is`/`as`는 기존과 같은 precedence 조건에서 cast 여부를 읽고 같은 `advance()`를 먼저 수행한다. 기존 큰 step 안에서 하던 type_expression 호출과 TypeCast/TypeCheck AST 생성을 outer machine match의 TypeOperand로 옮겼다. left는 machine.current에 보관한 뒤 같은 위치에서 꺼내고, span은 같은 `left.start..type.end`다. 타입 parsing이 실패하면 같은 error가 바깥의 기존 interpolation/parser 복원 경로로 전파된다.

`new`도 keyword advance를 먼저 수행한다. New continuation이 기존과 동일하게 `{` 여부를 확인하고, 필요하면 `type_expression_expected(Some("{"))`를 호출한 뒤 같은 missing_delimiter/start_object 인자로 object_build를 만든다. start는 keyword의 원래 span.start다. type parsing을 object body 이후로 미루거나 `new` 오류의 기대 delimiter를 바꾸지 않는다.

두 이동 모두 type/constraint expression의 recursive parser 진입 전에 큰 expression_machine_step frame을 반환한다. 다음 machine iteration으로 넘어가기 전 동일 작업을 완료하므로 새 expression step/scope/workguard 호출이 생기지 않는다. minimum/current/object_root/finish_expression과 interpolation frame 복원 규칙도 그대로다. lexical advance, type parse, AST 구성, object body 시작 순서에 새 Host나 평가 동작을 끼우지 않았다.

원래 parser/type_parser.rs와 여덟 stress target의 테스트 source는 C04 map과 동일하다. depth/workguard 상수·256KiB stack·기존 stress depth를 바꾼 교정이 아니다. 원래 compile/error timing의 전체 언어 호환은 이 소스 대조만으로 증명하지 않는다.

## 실제 기록의 범위

- `identity-stack-type-flow-tests-02`: 원래 frontend/lexical/string/Unicode 4개 target 명령이 실제 exit0/source-stable다. raw stdout/stderr hash가 report와 일치한다. 자식 격리 stress의 `test result`를 별도 API나 중복 pass 분모로 합산하지 않는다.
- `identity-stack-remaining-tests-01`: 같은 source map에서 실제 exit101/source-stable다. generic constructor/generic metadata/Set/strict Map의 small-stack completion 줄은 존재하고 stderr에 stack overflow는 없다. 전체 명령은 heap 총량 assertion 실패를 보존하므로 pass로 세지 않는다.
- `identity-stack-preparation-tests-01`: 실제101/source-stable이며 실패한 preparation 이동 실험 원문을 유지한다.
- `identity-stack-type-flow-tests-01`: 실제101/source-stable이며 Unicode의 추가 실패 원문을 유지한다.
- OS backtrace01/02/03의 복사된 `.ips`는 각 source.json의 SHA와 일치한다. 세 기록에 expression_machine_step/type_expression_expected/interpolated_expression_machine/append_definition frame 이름이 남아 있다. 새 debugger나 crash 재현을 실행하지 않았다. OS source record는 당시 실패의 증거이고 최종 교정 실행 결과로 바꾸지 않는다.

과거 C04의 manual Program(Input→ToString→Return), 256KiB/depth2000 통과와 이번 source-backed parser/bundled-load 경로는 다른 분모다. 이번 성공으로 과거 stack overflow 기록이나 overall101을 지우지 않는다.

남은 heap assertion 교정, constant numeric/Observe finding, generator copy/전체 producer identity 및 전체 native/platform/CLI/Rust5 검증은 각각 후속 불변 source와 실제 결과로 확인해야 한다. 이 보고서는 좁은 stack frame 교정의 source-only 검토이며 semantic pass나 M2 완료가 아니다.
