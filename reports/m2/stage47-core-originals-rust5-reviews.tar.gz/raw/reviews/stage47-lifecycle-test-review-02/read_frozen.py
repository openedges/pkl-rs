"""Inspect immutable lifecycle/tests/Java-raw inputs; execute no tests/evaluator."""
from pathlib import Path
import hashlib
import json
import collections
import difflib
import re
import stat

OUT=Path(__file__).resolve().parent
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
STAGE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
IMPL=STAGE/'target/m2/stage47-implementation-01'
C05=IMPL/'renderer-candidate-build-05'
FINAL=IMPL/'identity-reference-graph-tests-02'
inputs={}
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):
 assert stat.S_ISREG(p.lstat().st_mode),p
 data=p.read_bytes();record={'sha256':sha(data),'bytes':len(data)}
 assert inputs.setdefault(str(p),record)==record,p
 return data
def obj(p):return json.loads(read(p))
def save(n,d):(OUT/n).write_text(json.dumps(d,indent=2)+'\n')
cm=obj(C05/'source-after.json')
names=['identity-reference-graph-tests-02','identity-reference-graph-tests-01','identity-wrapper-heap-tests-01','identity-remaining-heap-tests-01']
bindings=[];maps={};deltas={}
for name in names:
 q=IMPL/name;r=obj(q/'report.json');before=obj(q/'source-before.json');after=obj(q/'source-after.json');d=obj(q/'source-delta.json')
 assert before==after and r['source_stable']
 for side in ['before','after']:assert sha(read(q/('source-'+side+'.json')))==r['source_'+side+'_sha256']
 for channel in ['stdout','stderr']:assert sha(read(q/(channel+'.bin')))==r[channel+'_sha256']
 differences=[p for p in cm.keys()|before.keys() if p.startswith('crates/') and '/src/'in p and cm.get(p)!=before.get(p)]
 assert not differences,differences
 assert sha(read(Path(d['baseline_release'])))==d['baseline_release_sha256']
 maps[name]=before;deltas[name]=d
 bindings.append({'root':str(q),'reportSha256':sha(read(q/'report.json')),'sourceMapSha256':r['source_before_sha256'],
 'actualExitCode':r['exit_code'],'command':r['command'],'productionMapDifferencesFromC05':differences})
fm=maps[names[0]];fd=deltas[names[0]]
def source(name,p):
 d=deltas[name];root=IMPL/name/'source-delta' if p in d['changed'] else Path(d['baseline_snapshot'])
 data=read(root/p);assert sha(data)==maps[name][p];return data
def frozen(p):return source(names[0],p)
tests=[p for p in sorted(fm) if p.startswith('crates/pkl-runtime/tests/') and p.endswith('.rs') and cm.get(p)!=fm[p]]
test_rows=[];diff=[]
guard=re.compile(r'stack_size|MAX_POLLS_PER_EVENT|const DEPTH|GC_CADENCE|Duration::from_|then_some\(|set_limits|with_limits')
for p in tests:
 old=read(C05/'sources'/p) if p in cm else b'';new=frozen(p)
 diff.extend(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='C05/'+p,tofile='capture21003/'+p))
 old_names=re.findall(r'#\[test\]\s*fn\s+(\w+)',old.decode());new_names=re.findall(r'#\[test\]\s*fn\s+(\w+)',new.decode())
 if old:assert old_names==new_names,p
 old_guards=[line for line in old.decode().splitlines() if guard.search(line)]
 new_guards=[line for line in new.decode().splitlines() if guard.search(line)]
 if old:assert old_guards==new_guards,p
 test_rows.append({'path':p,'beforeSha256':cm.get(p),'frozenSha256':fm[p],
 'oldTestNames':old_names,'newTestNames':new_names,'namedStackDepthDeadlineGuardsPreserved':old_guards==new_guards if old else None})
(OUT/'test-changes.diff').write_text(''.join(diff))

root3=MAIN/'target/m2/stage47-collection-lifecycle-correction-01'
for n in ['starting-point.json','after.json','rationale.json','correction-02.json']:obj(root3/n)
for f in ['m2_map_lifecycle.rs','m2_set_lifecycle.rs','m2_strict_map_lifecycle.rs']:
 p='crates/pkl-runtime/tests/'+f
 assert read(root3/'before'/f)==read(C05/'sources'/p)
 after=root3/('after-02' if f=='m2_set_lifecycle.rs' else'after')/f
 assert read(after)==frozen(p)
 read(root3/(f+'.diff'))

fixture='tests/fixtures/m2-renderer-frame-identity'
manifest=obj(FINAL/'source-delta'/fixture/'manifest.json')
assert sha(frozen(fixture+'/manifest.json'))=='d7027df9ed28462aa04f32b8c97d453d602e8142ab22f75d2e907629f0b1dc5f'
export=STAGE/'target/m2/stage47-renderer-identity-regression-fixtures-02'
for p,record in manifest['files'].items():
 data=frozen(fixture+'/'+p)
 assert sha(data)==record['sha256'] and len(data)==record['bytes']
 assert read(export/p)==data
assert read(export/'manifest.json')==frozen(fixture+'/manifest.json')
pins={10:('20a00c5fb207d8fe80308b849103a6a4bc2a153f1459201a749c62466f84d425','bc7a79974a4fd727a1e395221c0e7f91b2a9083d4a0d79083fe10427a8729084','0dac930649a021e43b2ecb382a731bf3ab293a2747225298a9b65e20a533940f'),
11:('dd1f3cbbfc4730cdac90bc6fb6c494fa1596d88d3fdb6080d5602d12b676c8ba','2058b500c6421eedd9e343907c79473b9ccbc91e9b111ff765b4a375a90bfdd7','e78663a96efeaca77464b757dad841e829018ff7f376c3a867aed1ee10bbe62e')}
for group,pin in pins.items():
 prefix=fixture+f'/provenance/stage47-renderer-api-oracle-{group:02}'
 for n,h in zip(['report','inventory','closure'],pin):assert sha(frozen(prefix+'/'+n+'.json'))==h
 inv=json.loads(frozen(prefix+'/inventory.json'));by_path={r['path']:r for r in inv['files']}
 for local,proof in manifest['sourceProvenance'].items():
  if not local.startswith(f'provenance/stage47-renderer-api-oracle-{group:02}/'):continue
  row=by_path[proof['originalRelativePath']];data=frozen(fixture+'/'+local)
  assert sha(data)==row['sha256']==proof['sha256'] and len(data)==row['bytes']==proof['bytes']

cases=[line.split('\t')for line in frozen(fixture+'/cases.tsv').decode().splitlines()]
rows=[line.split('\t')for line in frozen(fixture+'/expected.tsv').decode().splitlines()]
assert len(cases)==3 and len(rows)==240 and all(len(row)==12 for row in rows)
assert len({case[0]for case in cases})==3
case_lookup={case[0]:case for case in cases};counts=collections.Counter();row_bindings=[];seen=set()
for row in rows:
 id,repeat,session,index,expression,status,stdout16,stderr16,stdout8,stderr8,before,after=row
 identity=(id,repeat,session,index);assert identity not in seen;seen.add(identity)
 group,case=id.split('/');prefix=fixture+'/provenance/'+group+'/cases/'+case+'/'+repeat+'/calls/session-'+session+'/outer-'+index
 data=lambda suffix:frozen(prefix+'.'+suffix+'.bin')
 assert data('expression')==bytes.fromhex(expression) and data('status')==(status+'\n').encode()
 assert status in ['success','error']
 for ch,u8,u16 in [('stdout',stdout8,stdout16),('stderr',stderr8,stderr16)]:
  raw=data(ch);units=data(ch+'.code-units')
  assert raw==bytes.fromhex(u8) and units==bytes.fromhex(u16)
  assert units.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==raw
 for side,num in [('before',before),('after',after)]:
  counters=dict(line.split('=',1) for line in data('counters-'+side).decode().splitlines())
  assert int(num)==int(counters['read'])==0 and data('reads-'+side)==num.encode()
 uri=case_lookup[id][2]
 authored=json.loads(frozen(fixture+'/provenance/'+group+'/cases.json'))
 c=next(c for c in authored if c['id']==case);assert c['sourceUri']==uri
 assert bytes.fromhex(expression).decode()==[op[1] for op in c['operations'] if op!='GC'][int(index)]
 counts[status]+=1;row_bindings.append({'identity':identity,'rawPrefix':prefix,'status':status,
 'stdoutJavaUtf8Sha256':sha(data('stdout')),'stderrJavaUtf8Sha256':sha(data('stderr'))})
for case in cases:
 id,relative,uri,module_name=case;assert module_name=='main'
 source_data=frozen(fixture+'/'+relative)
 group,name=id.split('/');report=json.loads(frozen(fixture+'/provenance/'+group+'/report.json'))
 original=str(STAGE/'target/m2'/group/'workspace'/name/'main.pkl')
 assert sha(source_data)==report['inputHashes'][original]
for p in ['tools/renderer_identity_fixtures.py','tools/tests/test_renderer_identity_fixtures.py']:
 frozen(p)

promotion=MAIN/'target/m2/stage47-frame-identity-promotion-01'
installed=MAIN/'target/m2/stage47-frame-identity-installed-checks-01'
pr=obj(promotion/'report.json');pt=obj(promotion/'outer-terminal.json')
ir=obj(installed/'report.json');it=obj(installed/'outer-terminal.json')
assert pt['exitCode']==it['exitCode']==0
assert pt['reportSha256']==sha(read(promotion/'report.json')) and it['reportSha256']==sha(read(installed/'report.json'))
assert ir['sourceBefore']==ir['sourceAfter'] and ir['sourceStable']
for p,h in ir['sourceBefore'].items():assert sha(frozen(p))==h
for command in ir['commands']:
 assert command['exitCode']==0
 for ch in ['stdout','stderr']:assert sha(read(installed/(command['name']+'.'+ch+'.bin')))==command[ch+'Sha256']
assert b'Ran 7 tests' in read(installed/'tests.stderr.bin') and read(installed/'tests.stderr.bin').endswith(b'OK\n')
handoff=STAGE/'target/m2/stage47-renderer-identity-regression-export-01/handoff.json'
assert sha(read(handoff))=='7df2259529844778a47cd23c75512feffb68640654c109110d2337924bfa690c'
save('bindings.json',{'focusedProducers':bindings,'testSources':test_rows,'fixturePayloadFiles':len(manifest['files']),
 'fixtureTotalRegularFiles':len(manifest['files'])+1,'javaRows':len(rows),'javaRawStatusCounts':dict(counts),'javaRowBindings':row_bindings,
 'promotionTerminal':pt,'installedChecksTerminal':it,'sourceBoundToCoherent21003Map':True,
 'qualification':'Rust test480 compares are assertions within one actual test, not480 independently captured native process files. Both Rust instrumentation modes share one Java powerAssertions=true expected set.'})
save('inputs-before.json',inputs)
changes=[]
for p,record in inputs.items():
 data=Path(p).read_bytes();after={'sha256':sha(data),'bytes':len(data)}
 if after!=record:changes.append({'path':p,'before':record,'after':after})
assert not changes
save('source-stability.json',{'explicitInputs':len(inputs),'changes':changes,'liveProductionRead':False,'newTestOrEvaluatorExecution':False})
print(json.dumps({'focusedRoots':len(bindings),'testFiles':len(test_rows),'fixtureFiles':len(manifest['files'])+1,'javaRows':len(rows),'counts':dict(counts),'inputs':len(inputs),'changes':changes}))
