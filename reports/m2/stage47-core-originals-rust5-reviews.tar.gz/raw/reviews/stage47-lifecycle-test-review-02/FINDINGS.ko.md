# Coherent lifecycle 교정과 permanent frame identity 검토

완료된 불변 capture 21003의 테스트·compact fixture·verifier에서 새 차단 결함은 찾지 못했다. 검토는 해당 historical source map에 한정한다. 새 evaluator/Java/Rust/test를 실행하지 않았으며, 이후 live RuntimeError/diagnostic layout 교정을 이 결과에 섞지 않았다.

## 고정 소스와 actual 결과

`identity-reference-graph-tests-02` report는 `a4625805a4f317853842cd09d5813293d179cea2eca6a1c6bbdfb1446c206f9f`, before/after map은 동일한 `017f49632a4a07f25d476b9c975823206bae100eda0f53b62aefbbac1a85f3ba`이다. C05 대비 `crates/**/src/**` map 차이는 0이다. 변경 test/helper 23개 중 기존 파일의 test 함수명·순서를 유지했고 permanent identity test 하나를 추가했다.

Actual producer report와 stdout/stderr를 직접 대조하고 다음 target 소스가 coherent map과 동일함을 확인했다(`focused-target-source-binding.json`).

- 21003: fixed 3개와 reference 4개 통과, overall exit 0.
- 23769 / `identity-reference-graph-tests-01`: Set 8개와 permanent identity test 1개 통과. 해당 test 안의 Java240 × Rust2 = 480 full raw assertion을 포함한다. 같은 명령의 fixed/reference 기존 5개 실패로 overall exit 101인 원문은 보존한다.
- 24713 / `identity-remaining-heap-tests-01`: collection-type, constraints, equality, generic constructors/defaults/nodes, Map, strictMap의 8개 target은 통과했다. fixed/reference/Set 당시 실패로 overall exit 101인 기록과 분리한다.
- `identity-wrapper-heap-tests-01`: collection-types 6개, constraint-slots 6개, runtime 41개 통과, overall exit 0.

이는 해당 focused target의 소스 연결이다. 하나의 최종 full workspace/Rust5 명령이 통과했다는 주장은 아니다. 이전 좁은 class/type/graph 검토는 `../stage47-lifecycle-test-review-01/report.json`을 재사용하며 당시 type03 metadata 2개 실패도 그대로 남는다.

## 수거·상태·한도

`support/eager_base.rs`는 먼저 executable/type-node의 exact 추가 수를 확인하고, live에서 executable을 뺀 user value/custom-this 수의 delta를 따로 센다. base baseline을 포함한 허용 총량을 임의 `>=`로 바꾸지 않는다. 단, 기존 generic constructor/default/node 사례 중 일부는 executable 양수와 반복 plateau 검사를 사용한다. 그 기존 계약은 유지됐으며 이를 새 exact descriptor bound라고 과장하지 않는다.

수거가 끝나는 Map/Set/strictMap/equality/wrapper 사례는 exact user delta -1을 유지하면서 보관한 user module을 start할 때 실제 StaleHandle이어야 한다는 검사를 추가한다. 기존 stale token/다른 evaluator handle 거부, Host 오류 내용과 예상 값, read 순서, retry/cancel/deadline 분기, terminal context/live/slots 0은 유지한다. C05의 canonical Module parent 재사용·replacement module 새 identity·close 후 모든 handle stale 회귀도 production hash 동일로 유지된다.

Root의 3개 Map/Set/strictMap 변경은 원래 256KiB stack, depth, GC cadence, 최대 poll 반복수, wall-clock deadline을 바꾸지 않았다. 다른 기존 테스트의 명시된 stack/depth/deadline guard line도 직접 비교했다.

**초기화 polling 예외는 명시한다.** `m2_runtime.rs`의 두 module setup과 `m2_constraints_lifecycle.rs`의 한 setup은 단일 `poll(0,1000)` Ready 기대에서 `poll(0,1)`을 최대 100,000회 반복하고 yield마다 collect하는 helper로 바뀐다. 따라서 '모든 polling 조건이 동일하다'고 쓰면 틀리다. 이는 eager private base 초기화의 yield를 허용하는 setup 변경이다. 이어지는 실제 nested Host/constraint workload의 read/resume budget, deadline, 실패·토큰 계약은 바뀌지 않았다. 새 helper는 예상하지 않은 read/error를 성공으로 넘기지 않는다.

## lazy class/alias와 exact delta의 근거·한계

Set의 `Check` class/prototype, cached Set/Listing은 초기 module 뒤 추가되는 4개 user value이고 `Items` alias를 거치는 경로에는 alias 1개가 더해져 +5이다. executable 추가 수도 각각 +5/+7로 별도 확인한다. empty `new Check {}`를 별도 instance로 무조건 세지 않는다. Root의 after-02 Set와 after Map/strictMap 원본은 coherent snapshot의 바이트와 같다.

Collection/generic annotation이 module 초기화 중 이미 만든 class/alias는 baseline에 포함된다. 이후 생기는 Grow alias나 일회성 callback parameter descriptor는 delta로 분리한다. 이 때문에 기존 총량 literal에서 base 초기화 상태를 빼야 하며, 임시 collection/wrapper/amendment 환경의 반복 수거·plateau 검사는 여전히 필요하다.

Fixed/reference +12/+9/+8/+15 값과 별도 executable +0/+1/+4는 원래 소스와 retry/cache 경로를 유지한 채 exact 검사한다. 기존 `identity-reference-graph-tests-01/stdout.bin`은 초기/최종 live/executable 진단과 실패를 보존하고 21003은 같은 source-specific closure를 새 baseline으로 검사한다. Base가 이미 보유하는 annotation class/constraint roots, renderReference의 첫 parameter descriptor, ref constraint의 type/constraint owner를 구분하는 소스 해석이다. **개별 heap node dump는 확보되지 않았다.** 이 검토가 모든 수치를 node별로 독립 계측·열거했다거나 JVM heap과 동일하다고 주장하지 않는다.

## Java240 / Rust480과 fixture 무결성

고정 fixture manifest는 `d7027df9ed28462aa04f32b8c97d453d602e8142ab22f75d2e907629f0b1dc5f`이다. 3,806 payload + manifest 1 = regular file 3,807개이다. Java10의 ordinary/typed-union generator 두 프로그램 120 API와 Java11의 tagged numeric constant 프로그램 120 API, 합계 12 evaluator session/240 API를 보존한다. 모든 frozen fixture 파일이 sealed export와 같은 바이트이고, report/inventory/closure 독립 pin 및 copied raw inventory 연결도 확인했다.

`expected.tsv` 240행의 expression·status·양쪽 full UTF16BE·JavaUTF8·전후 read count를 copied Java raw에 직접 연결했다. raw success 136개, ordinary error 104개이다. Java11은 nonempty tag 1/2를 주므로 이전 Java10의 empty `new C {}`가 distinct instance를 입증하지 못하던 한계를 별도 actual control로 보완한다. 다른 initializer AST의 같은 숫자와 같은 declaration의 상수 숫자를 혼동하지 않는다.

Rust consumer는 동일한 원문 기대값을 `instrument=false`와 `true`에서 사용한다. 두 mode마다 2 repeat × 2 session을 새 SourceProbe에서 실행하고 모든 expected expression을 비교한다. 비교 중 read/module request 또는 다른 미완료 event가 나오면 실패하며, 모든 poll 뒤 collect, 각 session의 close/slots 0도 검사한다. 이 사례들의 Java read count는 실제 raw에서 0임을 검증했다. **480은 actual Rust test 하나 안의 assertion 수이며 독립 native process capture 파일 480개라는 뜻은 아니다.** Java는 powerAssertions=true 한 설정으로 취득됐고 Java off/on 비교로 표기하지 않는다.

Verifier는 고정 Java10/11 report·inventory·closure를 먼저 인증하고, root/parent lstat와 regular leaf 확인 뒤 읽는다. 원본에서 복원한 허용 경로의 parent directory만 walk하므로 unknown directory는 하강 전에 거절한다. TSV·source URI·raw counter를 outer manifest 재해시만으로 바꿀 수 없고, exact 파일 집합도 유지한다. Installed 7개 Python test와 CLI actual22838 exit0, promotion83422 exit0의 원문/hash를 coherent map의 tool/fixture hash에 연결했다. B의 원래 export 5 tests와 installed 7 tests는 구별한다. Process CWD 자체가 report에 명시되지 않아, worktree 연결은 promotion destination과 frozen source hash를 근거로 하며 더 강한 per-instruction/process trace를 주장하지 않는다.

## 남은 검증

이 검토의 명시 입력 7,708개 전후 hash 변화는 0이다. source/cache tree의 광역 traversal나 원본·production·Git 수정은 없다.

Coherent map에 대한 clippy01 actual101 및 후속 clippy02/03 실패는 보존 대상이다. 이후 value.rs/diagnostic.rs layout 교정과 clippy04는 다른 source map에 속하며 별도 검토해야 한다. Final full workspace/Rust5·새 production delta에 묶인 native/portable 검증은 이 결과로 통과 처리하지 않는다. C05 platform은 계속 C05 intermediate result이다.
