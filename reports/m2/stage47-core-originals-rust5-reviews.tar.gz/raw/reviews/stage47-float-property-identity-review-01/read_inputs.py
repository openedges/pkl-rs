"""Read existing sealed Java09 and pinned class bytes; never execute Java."""
from pathlib import Path
import ast
import hashlib
import json
import struct
import zipfile

MAIN = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
STAGE = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
OUT = Path(__file__).parent
ROOT = STAGE / 'target/m2/stage47-renderer-api-oracle-09'
inputs = {}

def read(path):
    data = path.read_bytes()
    record = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    assert inputs.setdefault(str(path), record) == record
    return data

def load(path):
    return json.loads(read(path))

pins = {'report.json': '57b692efd09565269d933172be8d959a8fa9588ca0adcc473e34da886bb941ce',
        'inventory.json': 'bd85db30f36fb5e3e254731b2db4ca3f93bb49d0e710e596dc84409bda68e1ee',
        'closure.json': '0d3e0272ed0403d391e7f43ba52ecbcf7974108bc78471b12b305918d6f71154'}
docs = {}
for name, digest in pins.items():
    docs[name] = load(ROOT / name)
    assert inputs[str(ROOT / name)]['sha256'] == digest
assert docs['closure.json']['closed'] is True and docs['closure.json']['allPayloadHashesVerified'] is True
assert docs['closure.json']['liveHandles'] == []
inventory = {row['path']: row for row in docs['inventory.json']['files']}

def payload(relative):
    data = read(ROOT / relative)
    assert len(data) == inventory[relative]['bytes']
    assert hashlib.sha256(data).hexdigest() == inventory[relative]['sha256']
    return data

for relative in ['RendererProbe.java', 'run.py', 'profile.json', 'cases.json',
                 'workspace/cached-property-and-old-physical-captures/main.pkl',
                 'workspace/cached-property-and-old-physical-captures/operations.tsv',
                 'workspace/cached-property-and-old-physical-captures/reader.tsv']:
    payload(relative)
profile = json.loads(payload('profile.json'))
jar = Path(profile['jar'])
assert hashlib.sha256(read(jar)).hexdigest() == profile['jarSha256']

observations = []
for observation in docs['report.json']['observations']:
    if observation['case'] != 'cached-property-and-old-physical-captures':
        continue
    for call in observation['calls']:
        prefix = call['rawPrefix']
        status = payload(prefix + '.status.bin')
        assert status.decode() == call['status']
        channels = {}
        for channel in ['stdout', 'stderr']:
            raw = payload(prefix + f'.{channel}.bin')
            units = payload(prefix + f'.{channel}.code-units.bin')
            assert units.decode('utf-16-be', 'surrogatepass').encode('utf-8', 'replace') == raw
            channels[channel] = {'rawPath': str(ROOT / (prefix + f'.{channel}.bin')),
                                 'rawSha256': hashlib.sha256(raw).hexdigest(),
                                 'utf16Path': str(ROOT / (prefix + f'.{channel}.code-units.bin')),
                                 'utf16Sha256': hashlib.sha256(units).hexdigest()}
        assert payload(prefix + '.expression.bin').decode() == call['expression']
        for side in ['Before', 'After']:
            assert payload(prefix + f'.counters-{side.lower()}.bin').decode() == call['counters' + side]
        hint = b'This value was converted during rendering.' in payload(prefix + '.stderr.bin')
        observations.append({'repeat': observation['repeat'], 'session': call['session'], 'prefix': prefix,
                             'expression': call['expression'], 'status': status.decode(),
                             'hasConversionHint': hint, 'channels': channels})
assert len(observations) == 72
for index in range(18):
    rows = [row for row in observations if row['prefix'].endswith(f'/outer-{index}')]
    assert len(rows) == 4
    assert len({(row['status'], row['hasConversionHint']) for row in rows}) == 1

source_names = [
    'ast/ExpressionNode.java', 'ast/ConstantValueNode.java', 'ast/builder/AstBuilder.java',
    'ast/member/ClassMethod.java', 'ast/member/UnresolvedMethodNode.java', 'ast/member/FunctionNode.java',
    'ast/type/TypeNode.java', 'ast/frame/ReadExactFrameSlotNode.java', 'ast/frame/ReadFrameSlotNode.java',
    'ast/frame/WriteFrameSlotNode.java', 'ast/expression/member/ReadPropertyNode.java',
    'ast/expression/member/ReadLocalPropertyNode.java',
    'stdlib/registry/ExternalMemberRegistry.java', 'stdlib/ExternalMethod1Node.java',
    'stdlib/base/JsonRendererNodes.java', 'stdlib/base/PcfRendererNodes.java',
    'stdlib/AbstractRenderer.java', 'stdlib/PklConverter.java', 'runtime/VmValueConverter.java',
    'runtime/VmUtils.java', 'runtime/VmObject.java', 'runtime/StdLibModule.java', 'runtime/BaseModule.java',
]
for name in source_names:
    read(MAIN / 'external/pkl/pkl-core/src/main/java/org/pkl/core' / name)
read(MAIN / 'external/pkl/stdlib/base.pkl')
read(MAIN / 'references.lock')

# Reuse the earlier read-only class parser but retain all invocation targets.
# The only executed code is this Python parser, not the target classes.
old_parser = MAIN / 'target/m2/stage47-boxing-identity-design-01/read_inputs.py'
text = read(old_parser).decode()
node = next(node for node in ast.parse(text).body if isinstance(node, ast.FunctionDef) and node.name == 'class_methods')
function = ast.get_source_segment(text, node)
old_filter = "if ref and any(k in ref for k in ['java/lang/', 'evalInt', 'evalFloat', 'evalBoolean', 'evalGeneric', 'getValue', 'getLong', 'getDouble', 'getBoolean', 'getObject']):"
assert old_filter in function
function = function.replace(old_filter, 'if ref:')
namespace = {'struct': struct}
exec(compile(function, '<class-byte-parser>', 'exec'), namespace)
classes = {}
names = [
    'ast/frame/ReadExactFrameSlotNodeGen', 'ast/frame/WriteFrameSlotNodeGen',
    'ast/member/FunctionNode', 'ast/type/TypeNode$WriteFrameSlotTypeNode',
    'ast/type/TypeNode$AnyTypeNode', 'stdlib/registry/ExternalMemberRegistry',
    'stdlib/base/JsonRendererNodesFactory$renderDocumentNodeGen',
    'stdlib/base/PcfRendererNodesFactory$renderDocumentNodeGen',
    'stdlib/base/JsonRendererNodes$renderDocument', 'stdlib/base/PcfRendererNodes$renderDocument',
    'stdlib/AbstractRenderer', 'stdlib/PklConverter', 'runtime/VmValueConverter',
    'runtime/StdLibModule', 'runtime/VmUtils', 'ast/expression/member/ReadPropertyNode',
]
(OUT / 'jar-classes').mkdir()
with zipfile.ZipFile(jar) as archive:
    for name in names:
        entry = 'org/pkl/core/' + name + '.class'
        data = archive.read(entry)
        (OUT / 'jar-classes' / (name.replace('/', '__') + '.class')).write_bytes(data)
        classes[entry] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                          'methods': namespace['class_methods'](data)}
    bundled_base = archive.read('org/pkl/core/stdlib/base.pkl')
    assert bundled_base == read(MAIN / 'external/pkl/stdlib/base.pkl')
    (OUT / 'jar-base.pkl').write_bytes(bundled_base)

old_design = MAIN / 'target/m2/stage47-boxing-identity-design-01'
for name in ['java04-observation.json', 'jdk-source/Long.java', 'jdk-source/Double.java']:
    read(old_design / name)
for name in ['main.pkl', 'operations.tsv']:
    read(STAGE / 'target/m2/stage47-renderer-api-oracle-04/workspace/primitive-polymorphic-function-history' / name)
result = {'scope': 'Existing Java09 public raw and pinned source/class byte reading only; no JVM/frame instrumentation or new evaluator execution.',
          'java09Pins': pins, 'wholeJava09Calls': 320, 'focusedCalls': 72,
          'focusedObservations': observations, 'jarSha256': profile['jarSha256'],
          'bundledBaseMatchesPinnedSource': True, 'pinnedJarClasses': classes,
          'qualification': 'Static method invocation targets identify boxing code paths. Actual public raw outcomes establish the observable difference; frame descriptor histories are source-backed deductions, not instrumented frame observations.'}
(OUT / 'source-and-bytecode.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'input-manifest.json').write_text(json.dumps({'files': inputs}, indent=2) + '\n')
changes = [path for path, row in inputs.items() if hashlib.sha256(Path(path).read_bytes()).hexdigest() != row['sha256']]
assert not changes
(OUT / 'readback.json').write_text(json.dumps({'explicitInputs': len(inputs), 'inputChanges': changes,
                                             'focusedJavaCallsRead': 72, 'jarClassesRead': len(classes),
                                             'newJavaExecutions': 0, 'newRustExecutions': 0}, indent=2) + '\n')
print(json.dumps({'explicitInputs': len(inputs), 'focusedJavaCallsRead': 72, 'jarClassesRead': len(classes), 'inputChanges': changes}))
