# Java09 cached Float/Int 차이의 source 및 bytecode 검토

새 JVM·Rust·테스트를 실행하지 않았다. 봉인 Java09의 `cached-property-and-old-physical-captures` 72개 호출(2 JVM × 2 evaluator × 18 API), pinned Java source 및 실제 oracle JAR의 16개 class를 읽었다. Java09 전체 320개를 새로 검증하거나 native 호환 통과로 주장하지 않는다. A의 현재 identity live source는 이 검토 입력이 아니다.

## 실제 관찰

네 session에서 다음 결과가 모두 같다. `raw` 오류 전체와 UTF16/JavaUTF8는 `source-and-bytecode.json`에 원본 경로·해시로 연결했다. hint 유무는 이 원문에 대한 관찰 요약이며 raw 비교를 대체하지 않는다.

| 호출 | 실제 conversion hint |
| --- | --- |
| `pCached.renderDocument(cachedInt)` | 없음 |
| `jCached.renderDocument(cachedFloat)` | 있음 |
| `pTyped.renderDocument(cachedInt)` / `jTyped.renderDocument(cachedFloat)` | 모두 있음 |
| `pOld.renderDocument(cachedInt)` / `jOld.renderDocument(cachedFloat)` | warm 전후 및 GC 요청 뒤 모두 있음 |
| `pNew.renderDocument(cachedInt)` | 없음; GC 요청 뒤도 같음 |
| `jNew.renderDocument(cachedFloat)` | 있음; GC 요청 뒤도 같음 |

`cachedInt=1000`, `cachedFloat=Infinity`다. `newInt/newFloat`는 capture factory에 String 인자를 보낸 뒤 만들어진다. 이 입력 의도와 실제 hint가 관찰된 것이며 Java physical frame을 계측한 결과는 아니다.

## 일반 속성 cache에서 Float만 재boxing하는 근거는 없음

`AstBuilder.java:701–706`은 일반 lexical property를 `ReadPropertyNodeGen`으로 만든다. `ReadPropertyNode.java:105–113`은 `VmUtils.readMemberOrNull`의 Object를 그대로 반환한다. `VmUtils.java:313–320`은 cachedValue가 있으면 그것을 반환한다. 실제 JAR에도 ReadPropertyNode.evalObject의 pc24에서 이 helper 호출, VmUtils 해당 overload의 pc48에서 `getCachedValue` 호출이 있다. 일반 cache 반환에 Double.valueOf를 추가하는 것은 이 경로를 잘못 바꾼다.

`VmValueConverter.convert`도 Double/Long wrapper를 downcast해 해당 convert 메서드로 전달한다. `PklConverter.doConvert`는 VmFunction.apply로 넘긴다. 이 두 경로만 읽으면 호출자가 준 wrapper가 renderer 내부 original value라고 생각하기 쉽지만, 그보다 앞의 외부 메서드 인자 슬롯이 빠져 있다.

## renderer 외부 메서드도 슬롯을 거침

base.pkl의 PcfRenderer/JsonRenderer `renderDocument(value: Any)`는 외부 함수다. `AstBuilder.java:1979–2012` → `UnresolvedMethodNode.execute` → `FunctionNode.executeImpl:111–116`의 일반 함수 경로를 거친다. Any는 타입 검사가 no-op이어도 저장은 no-op이 아니다. `TypeNode.WriteFrameSlotTypeNode:317–320`은 adaptive WriteFrameSlotNode를 호출한다.

`ExternalMemberRegistry.java:112–119`는 외부 1인자 body에 `ReadExactFrameSlotNodeGen(slot=0)`를 넣는다. Double physical slot을 generic Object로 읽을 때 Double.valueOf가 일어난다. 이 경계는 renderer converter lambda 자체의 슬롯과 별개다.

실제 pinned JAR `c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059`에서 확인한 호출 위치는 다음과 같다.

| 실제 class/method | bytecode 호출 |
| --- | --- |
| FunctionNode.executeImpl | pc59 TypeNode.executeAndSet, pc74 body ExpressionNode.executeGeneric |
| TypeNode$WriteFrameSlotTypeNode.executeAndSet | pc13 WriteFrameSlotNode.executeWithValue |
| ExternalMemberRegistry.getFunction1Body | pc33 ReadExactFrameSlotNodeGen.create |
| JsonRenderer/PcfRenderer generated renderDocument.executeGeneric | pc10 receiver.executeGeneric, pc19 arg1.executeGeneric, pc52 renderer eval |
| ReadExactFrameSlotNodeGen.executeGeneric | pc21 evalInt → pc24 Long.valueOf; pc66 evalFloat → pc69 Double.valueOf; pc159 evalObject |
| ReadExactFrameSlotNodeGen.executeAndSpecialize | pc89 evalFloat → pc92 Double.valueOf; pc215 evalObject |

Long.valueOf는 고정 작은 정수 cache가 있지만 1000은 그 범위 밖이다. Double.valueOf는 새 wrapper를 만드는 JDK 경로다. 이전 identity 설계에서 읽은 인접 pinned JDK source를 이번 입력에도 연결했다. 이 문서는 JDK source의 인접성을 runtime image의 모든 bytecode와 동일하다는 증명으로 확대하지 않는다. 위 Pkl generated class bytes는 실제 사용 JAR에서 직접 추출했다.

## PCF가 먼저 Object 슬롯을 갖는 source 경로

`BaseModule.java:25–29`는 static instance를 StdLibModule.loadModule로 초기화한다. `StdLibModule.java:40–83`은 별도 기본 context의 빈 property map을 사용해 base를 로드한 뒤, base의 hidden output을 명시적으로 읽고 `output.force(false,true)`한다. base.pkl:103–135의 기본 output renderer는 `read?("prop:pkl.outputFormat") ?? "pcf"`로 PCF이며 value는 base module Object다. 따라서 이 함수 경로의 첫 인자가 Object다.

이 흐름은 실제 JAR의 StdLibModule.lambda$doLoad$0에서도 pc138 instance.force, pc146 VmUtils.readModuleOutput, pc155 output.force 호출로 확인된다. 번들 JAR 안의 base.pkl은 pinned checkout의 base.pkl과 바이트 동일하다.

Any의 adaptive WriteFrameSlotNode는 descriptor가 Object가 되면 primitive guard를 다시 만족하지 않고 Object로 저장한다. ClassMethod가 보유한 FunctionNode/call target은 renderer instance마다 새로 만들지 않는다. 이 source 흐름으로 PCF renderDocument의 Object 선행 이력이 설명된다. 같은 default branch는 JSON renderDocument를 호출하지 않는다. Java09 해당 case는 fresh JVM에서 별도 실행되며 첫 JSON document 인자는 Float다.

이는 source와 bytecode에서 따라간 descriptor 이력의 결론이다. oracle raw의 72개 공개 호출은 결과를 확인하지만, 프레임 descriptor를 계측하지는 않았다. JVM 최적화 내부의 allocation count/주소나 물리 GC 횟수는 주장하지 않는다.

## 왜 실제 결과와 맞는가

- PCF 외부 슬롯이 Object이면 caller의 cachedInt wrapper L0가 renderer 내부의 `value`다. cachedInt를 다시 읽는 converter도 L0를 반환한다. AbstractRenderer.java:96의 reference inequality가 false여서 hint가 없다.
- JSON의 Float physical 슬롯은 원래 cachedFloat wrapper F0를 unbox하고 ReadExactFrameSlot에서 F1로 box한다. renderer의 원래 `value`는 F1이다. cachedFloat를 읽거나 Object capture에서 반환하는 converter는 F0를 주므로 hint가 생긴다. `jNew`가 Float capture factory를 Object로 바꾼 뒤에도 hint인 이유다. 그 factory와 JSON 외부 메서드의 descriptor는 서로 다르다.
- typed Int/Float converter는 자신의 primitive parameter 슬롯을 또 거친다. PCF의 외부 인자 보존과 typed converter의 재boxing은 독립이다. 따라서 pTyped도 hint다.
- old capture는 factory descriptor가 이후 Object로 바뀌어도 기존 activation의 physical Long/Double이 Object로 저절로 바뀌지 않는다. old Int의 generic read가 1000을 다시 box하면 hint다. new Int Object capture는 L0를 보존하므로 PCF에서 hint가 없다.

동일 숫자 payload의 equality, Float인지 Int인지, lambda AST 모양만으로 이 결정을 대신할 수 없다. 경계별 wrapper token/physical slot/descriptor 이력을 공통 carrier가 보존해야 한다.

## Java04의 String warm과 모순되지 않음

Java04 `primitive-polymorphic-function-history`는 하나의 `identity=(v)->v`를 JSON/PCF converter가 공유한다. warm 호출은 **`r.renderValue("warm")`**다. renderDocument와 renderValue는 별도 외부 메서드이므로 이 호출이 JSON renderDocument 슬롯을 직접 Object로 만들었다고 주장할 수 없다.

String이 공유 converter의 adaptive 슬롯을 Object로 바꾸면, 이후 JSON renderDocument가 Float를 F1으로 다시 box하더라도 converter가 그 입력 F1을 그대로 반환한다. 그러면 hint는 없다. Java09의 cached-property closure는 F1 대신 cached F0를 반환하므로 여전히 hint다. 따라서 Java04의 44개 raw 통과는 외부 renderer 메서드 boxing을 생략해도 된다는 근거가 아니다. 09가 그 누락을 드러내는 대조군이다.

## A 구현에 필요한 구체 경계

공통 슬롯 carrier를 외부 stdlib 메서드의 실제 executable owner에도 적용해야 한다. converter 함수 descriptor, renderer 외부 메서드 descriptor, closure activation의 physical storage를 합치지 않는다. AbstractRenderer의 before value는 호출자의 최초 인자가 아니라 외부 메서드의 인자 읽기를 통과해 renderer eval에 도달한 wrapper여야 한다.

PCF만 type-based 예외로 identity를 보존하거나 Float property 읽기에 임의 reboxing을 넣지 않는다. 실제 source-backed bootstrap을 반영할 경우 새 VM 생성/동기 재귀를 유발하지 않는 공유 evaluator 초기화 순서가 필요하다. 이번 검토는 그 bootstrap 실행 안전성을 검증한 것이 아니며, 새 library stack overflow는 별도 원본 실패와 후속 원인 조사로 보존한다. stack limit 변경이나 Java hint 기대값 수정으로 피하지 않는다.

새 immutable carrier 후보에서 Java04뿐 아니라 Java09와 기존 860개를 각각 실제 raw로 비교해야 한다. 이번 검토 시 그 전체 native 비교는 미실행이다.
