"""Explicit Stage50 A–F evidence selection, clean gather and checked publication."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,stat,subprocess,sys,tarfile,time
O=Path(__file__).resolve().parent; B=O.parent; R=B.parent.parent
P=B/'stage50-publication-plan-01'; MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def load(p):return json.loads(p.read_bytes())
def filemeta(p):
 s=p.lstat(); mode=stat.S_IMODE(s.st_mode)
 if stat.S_ISLNK(s.st_mode):b=os.fsencode(os.readlink(p));return {'kind':'symlink','mode':mode,'bytes':len(b),'sha256':sha(b),'target':os.readlink(p)}
 assert stat.S_ISREG(s.st_mode),p
 b=p.read_bytes();return {'kind':'regular','mode':mode,'bytes':len(b),'sha256':sha(b)}
units={'A-fixture-tooling':[],'B-helper-reviews':[],'C-old05-controls':[],'D-storage-candidates':[],'E-required-freshness':[],'F-native-controls':[]}
x=load(P/'existing-roots.json')
lookup={'fixture-tooling-history':'A-fixture-tooling','helper-pipeline-reviews':'B-helper-reviews','old05-actual-controls':'C-old05-controls','storage-discovery-and-candidate01':'D-storage-candidates','required01-and-manifest':'E-required-freshness','native-orchestrator-preflights':'F-native-controls','environment-metadata':'B-helper-reviews','optional-next-language-planning':'B-helper-reviews'}
for group,names in x['groups'].items():units[lookup[group]] += [B/n for n in names]
units['A-fixture-tooling'].append(P)
units['D-storage-candidates'].append(B/'stage50-storage-build02')
units['E-required-freshness'] += [B/'stage50-required-rust-02',B/'stage50-manifest-freshness-02']
units['F-native-controls'] += [B/n for n in ['stage50-native-controls-build02-launch-01','stage50-native-controls-build02-preflight-01','stage50-native-controls-build02-01','stage50-native-build02-c-audit-01','stage50-native-build02-c-audit-02']]
prunes={Path(row['path']) for row in load(P/'prewalk-prunes.json')['exactPaths']}
fixture=R/'tests/fixtures/m2-modulekey-extended'; fm=load(fixture/'manifest.json')
fixtures={rel:{**v,'kind':'regular'} for rel,v in fm['files'].items()}
fixtures['manifest.json']={**filemeta(fixture/'manifest.json')}
archives=load(P/'fixture-reuse.json')['publishedArchives']
for row in archives.values():assert sha(Path(row['path']).read_bytes())==row['sha256']
# Exact fixture copies are reconstructed from installed tracked bytes or canonical old archive members.
fixture_hashes={(v['sha256'],v['bytes']):rel for rel,v in fixtures.items() if rel in ['fixtures.json','host-metadata.json','provenance-map.json','manifest.json']}
def ref(rel):
 v=fixtures[rel];parts=Path(rel).parts
 if parts[0] in ['original','provenance']:
  num=int(parts[1][-2:]);suf='01-03' if num<=3 else '04-07';return {'kind':'published-archive-member','archive':archives[suf],'member':f'payload/stage49-oracle-modulekey-{num:02d}/'+('/'.join(parts[2:])),'sha256':v['sha256'],'bytes':v['bytes']}
 return {'kind':'pending-tracked-fixture-byte-reference','repositoryRelativePath':'tests/fixtures/m2-modulekey-extended/'+rel,'sha256':v['sha256'],'bytes':v['bytes'],'qualification':'Exact actual source bytes. Future Git commit/blob binding is root-owned and pending.'}
fixture_refs={rel:ref(rel) for rel in fixtures}

def walk(root):
 # Only explicitly chosen roots. Exclude exact temporary paths before scandir.
 todo=[root]
 while todo:
  p=todo.pop()
  if p in prunes:continue
  if p.is_symlink() or p.is_file():yield p;continue
  assert p.is_dir(),p
  with os.scandir(p) as it:
   children=sorted([Path(e.path) for e in it],reverse=True)
  todo.extend(children)

def authenticate(root):
 checks=[]
 inv=root/'inventory.json'; clo=root/'closure.json'
 if inv.is_file():
  raw=inv.read_bytes();j=json.loads(raw)
  if clo.is_file():
   c=load(clo)
   if c.get('inventorySha256'):assert sha(raw)==c['inventorySha256'],inv
  rows=j.get('files',{})
  if isinstance(rows,dict):rows=[{'path':k,**v} for k,v in rows.items()]
  for row in rows:
   p=root/row['path'];assert p.is_relative_to(root) and '..' not in Path(row['path']).parts
   m=filemeta(p);assert m['sha256']==row['sha256'] and m['bytes']==row['bytes'],p
  checks.append({'inventory':str(inv),'sha256':sha(raw),'directRowsVerified':len(rows)})
 if clo.is_file():
  c=load(clo);rows=c.get('payloads',c.get('files',[]))
  if isinstance(rows,dict):rows=[{'path':k,**v} for k,v in rows.items()]
  for row in rows:
   if 'path' not in row or 'sha256' not in row:continue
   rel=Path(row['path']);assert not rel.is_absolute() and '..' not in rel.parts,rel
   m=filemeta(root/rel);assert m['sha256']==row['sha256'] and m['bytes']==row['bytes'],root/rel
  checks.append({'closure':str(clo),'sha256':sha(clo.read_bytes()),'directRowsVerified':len(rows),'historicSeal':c.get('sealed',None)})
 return checks

def select():
 rows=[];auth=[];roots=[]
 for unit,rs in units.items():
  for root in rs:
   assert root.is_dir() and not root.is_symlink();roots.append({'unit':unit,'path':str(root),'historicClosurePresent':(root/'closure.json').is_file()});auth.extend(authenticate(root))
   for p in walk(root):
    m=filemeta(p);rel=p.relative_to(root).as_posix();r={'source':str(p),'unit':unit,'root':str(root),'relative':rel,**m}
    if root.name=='stage50-modulekey-extended-export-02' and rel.startswith('fixtures/'):
     frel=rel[len('fixtures/'):];v=fixtures[frel];assert m['sha256']==v['sha256'] and m['bytes']==v['bytes'];r['reuse']=fixture_refs[frel]
    elif (m['sha256'],m['bytes']) in fixture_hashes and p.name in ['fixtures.json','host-metadata.json','provenance-map.json','manifest.json']:
     frel=fixture_hashes[(m['sha256'],m['bytes'])];r['reuse']=fixture_refs[frel]
    else:r['member']='payload/'+root.name+'/'+rel+('.link.json' if m['kind']=='symlink' else '')
    rows.append(r)
 p=B/'stage50-modulekey-extended-driver-tail.txt';rows.append({'source':str(p),'unit':'A-fixture-tooling','root':str(B),'relative':p.name,'member':'payload/'+p.name,**filemeta(p)})
 # Installed fixture is referenced, not rearchived, but every actual referenced file is guarded.
 for rel,v in fixtures.items():
  p=fixture/rel;m=filemeta(p);assert m['sha256']==v['sha256'] and m['bytes']==v['bytes'];rows.append({'source':str(p),'unit':'A-fixture-tooling','root':str(fixture),'relative':rel,'reuse':fixture_refs[rel],**m})
 write(O/'selection.json',{'schema':1,'units':{k:[str(p) for p in v] for k,v in units.items()},'roots':roots,'exactPrewalkPrunes':[str(p) for p in sorted(prunes)],'files':rows,'authentication':auth,'excludedRootOwnerG':'root owns new M1/platform integration and final source/Git/docs/aggregate','fixtureReferences':fixture_refs,'historicMissingClosureRemainsUnknown':True})
 counts={u:{'originalFiles':sum(r['unit']==u for r in rows),'payloadFiles':sum(r['unit']==u and 'member'in r for r in rows),'payloadRawBytes':sum(r['bytes'] for r in rows if r['unit']==u and 'member'in r),'referenceFiles':sum(r['unit']==u and 'reuse'in r for r in rows)} for u in units}
 write(O/'selection-summary.json',{'roots':len(roots),'originalFiles':len(rows),'originalBytes':sum(r['bytes'] for r in rows),'units':counts,'archivesCreated':0})
 print(json.dumps(load(O/'selection-summary.json')),flush=True)

def run(command,label):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.Popen(command,cwd=R,stdout=(O/(label+'.stdout.bin')).open('wb'),stderr=(O/(label+'.stderr.bin')).open('wb'));code=p.wait()
 row={'command':command,'pid':p.pid,'cwd':str(R),'startedUtc':start,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':code}
 write(O/(label+'.terminal.json'),row);assert code==0,row;return row

def publish():
 s=load(O/'selection.json');rows=s['files'];commands=[];index=[];reportdir=R/'reports/m2';reportdir.mkdir(parents=True,exist_ok=True)
 for unit in units:
  gather=O/'gathered'/unit;gather.mkdir(parents=True,exist_ok=False)
  ur=[r for r in rows if r['unit']==unit]
  write(gather/'CAPTURE_SELECTION.json',{'schema':1,'unit':unit,'files':ur,'fixtureReferenceAuthority':s['fixtureReferences'] if unit=='A-fixture-tooling' else 'See A archive CAPTURE_SELECTION and installed exact fixture manifest.','scope':'Native full Java trace false; extended936 raw=836ordinary+100 diagnostic-only,8internal mismatch. Old05 portable controls are not Stage50 runtime results. All failures retained.'})
  for row in ur:
   if 'member' not in row:continue
   p=Path(row['source']);assert filemeta(p)=={k:row[k] for k in ['kind','mode','bytes','sha256']+(['target'] if row['kind']=='symlink' else [])},p
   out=gather/row['member'];out.parent.mkdir(parents=True,exist_ok=True)
   if row['kind']=='symlink':write(out,{'originalSource':str(p),'originalKind':'symlink','target':row['target'],'targetBytesHex':os.fsencode(row['target']).hex(),'mode':row['mode'],'sha256':row['sha256']})
   else:shutil.copyfile(p,out)
  dest=reportdir/('stage50-'+unit.lower()+'.tar.gz');assert not dest.exists(),dest
  commands.append(run([sys.executable,'-B',str(R/'tools/evidence.py'),'create',str(gather),str(dest)],unit+'-create'))
  assert dest.stat().st_size<100_000_000,dest
  commands.append(run([sys.executable,'-B',str(R/'tools/evidence.py'),'verify',str(dest)],unit+'-verify'))
  # Separate every-member inventory + original payload byte readback, independent of evidence.verify.
  with tarfile.open(dest,'r:gz') as t:
   members={m.name:m for m in t.getmembers()};inv=json.load(t.extractfile(members['EVIDENCE.json']));expected={r['path']:r for r in inv['files']};assert set(members)==set(expected)|{'EVIDENCE.json'}
   for name,v in expected.items():
    data=t.extractfile(members[name]).read();assert len(data)==v['bytes'] and sha(data)==v['sha256'];assert data==(gather/name).read_bytes()
   for row in ur:
    if 'member' in row and row['kind']=='regular':data=t.extractfile(members[row['member']]).read();assert sha(data)==row['sha256'] and len(data)==row['bytes']
  entry={'unit':unit,'path':str(dest),'repositoryRelativePath':str(dest.relative_to(R)),'sha256':sha(dest.read_bytes()),'compressedBytes':dest.stat().st_size,'archiveInventoryFiles':len(expected),'originalPayloadFiles':sum('member'in r for r in ur),'originalPayloadBytes':sum(r['bytes'] for r in ur if 'member'in r),'references':sum('reuse'in r for r in ur),'separateVerifyPassed':True,'everyMemberReadbackPassed':True};index.append(entry);write(O/'progress.json',{'completedArchives':index});print('archive '+json.dumps(entry),flush=True)
 # Original files guard: original path/kind/mode/hash/target unchanged, root pathsets unchanged.
 changes=[]
 for row in rows:
  try:m=filemeta(Path(row['source']));old={k:row[k] for k in ['kind','mode','bytes','sha256']+(['target']if row['kind']=='symlink' else [])}
  except OSError as e:changes.append({'path':row['source'],'error':str(e)});continue
  if m!=old:changes.append({'path':row['source'],'before':old,'after':m})
 for rr in s['roots']:
  actual={str(p) for p in walk(Path(rr['path']))};expected={r['source'] for r in rows if r['root']==rr['path']};
  if actual!=expected:changes.append({'root':rr['path'],'added':sorted(actual-expected),'missing':sorted(expected-actual)})
 write(O/'original-guard.json',{'filesChecked':len(rows),'changes':changes,'exactRootPathsetsChecked':len(s['roots']),'sourceKindModeTargetHashesChecked':True});assert not changes,changes[:3]
 result={'schema':1,'archives':index,'totalCompressedBytes':sum(r['compressedBytes'] for r in index),'archivesBelow100000000Bytes':True,'originalChanges':0,'commands':commands,'scope':{'provided212RawMatches':212,'public212RawMatches':212,'extended944RawMatches':936,'ordinaryCompatible':836,'diagnosticOnly':100,'internalMismatch':8,'fullJavaEventCounterGatePassed':False},'GExcluded':True,'fixtureReferences':{'manifestSha256':sha((fixture/'manifest.json').read_bytes()),'oldArchiveOriginalFiles':32964,'derivedTrackedFiles':4},'publicationGitBindingPendingRoot':True}
 write(O/'report.json',result);write(reportdir/'stage50-native-tooling-captures.json',result)
 print('publication complete '+str(len(index)),flush=True)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('action',choices=['select','publish']);args=a.parse_args();select() if args.action=='select' else publish()
