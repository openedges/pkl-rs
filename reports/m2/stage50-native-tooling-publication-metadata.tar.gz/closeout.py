"""Archive only closed publisher originals; leave final receipt outside its own archive."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,tarfile
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def run(cmd,label):
 t={'command':cmd,'cwd':str(R),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (O/(label+'.stdout.bin')).open('wb') as out,(O/(label+'.stderr.bin')).open('wb') as err:
  p=subprocess.Popen(cmd,cwd=R,stdout=out,stderr=err);t['pid']=p.pid;code=p.wait()
 t.update(exitCode=code,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());write(O/(label+'.terminal.json'),t);assert code==0;return t
term=json.loads((O/'publish.terminal.json').read_bytes());assert term['exitCode']==0
report=json.loads((O/'report.json').read_bytes());s=json.loads((O/'selection.json').read_bytes())
assert not json.loads((O/'original-guard.json').read_bytes())['changes']
# Reauthenticate referenced archives and actual packaging tool after payload creation.
refs=json.loads((R/'target/m2/stage50-publication-plan-01/fixture-reuse.json').read_bytes())['publishedArchives']
for v in refs.values():assert sha(Path(v['path']))==v['sha256']
assert sha(R/'tools/evidence.py')==term['evidenceToolSha256']
fixture=R/'tests/fixtures/m2-modulekey-extended'
expected=set(json.loads((fixture/'manifest.json').read_bytes())['files'])|{'manifest.json'}
allowed_dirs={Path(rel).parent.as_posix() for rel in expected}
for rel in list(allowed_dirs):allowed_dirs.update(p.as_posix() for p in Path(rel).parents)
actual=set();todo=[fixture]
while todo:
 current=todo.pop()
 for child in current.iterdir():
  rel=child.relative_to(fixture).as_posix()
  assert not child.is_symlink(),child
  if child.is_dir():assert rel in allowed_dirs,child;todo.append(child)
  else:assert child.is_file() and rel in expected,child;actual.add(rel)
assert actual==expected
write(O/'dependency-final-guard.json',{'publishedArchives':refs,'unchanged':True,'installedFixtureExactPathset':len(actual),'unlistedDirectoriesRejectedBeforeDescent':True,'evidenceToolSha256':sha(R/'tools/evidence.py'),'qualification':'Canonical archive whole-file hashes are authenticated references; no claim of new old-archive all-member readback.'})
write(O/'outer-terminal.json',{'publicationToolSessionId':77077,'publicationChildPid':term['pid'],'publicationExitCode':0,'selectionToolSessionId':51273,'selectionExitCode':0,'qualification':'Session IDs are actual tool handles; OS child PID and process UTC are in publish.terminal.json.'})
write(O/'scope-summary.json',{'sourceRoots':len(s['roots']),'rootsWithoutHistoricProducerClosure':[r['path'] for r in s['roots'] if not r['historicClosurePresent']],'historicQualification':'Publisher inventory does not add or invent missing historic producer closures/terminals. Raw failure and qualification files preserved.','originalFiles':len(s['files']),'rawOriginalBytes':sum(r['bytes'] for r in s['files']),'payloadFiles':sum('member'in r for r in s['files']),'referencePaths':sum('reuse'in r for r in s['files']),'fixtureUniqueOriginalArchiveMembers':32964,'fixtureUniqueDerivedFiles':4,'fullJavaEventCounterGatePassed':False,'old05ControlsAreStage50EngineResults':False,'noNewEngineOrJavaExecution':True,'GrootOwner':'root','futureGitBlobBindingOwner':'root'})
g=O/'metadata-gather';g.mkdir(exist_ok=False)
# Exact direct files only, never descend into gathered/ or any cache.
paths=[p for p in sorted(O.iterdir()) if p.is_file() and p.name not in ['closeout.stdout.bin','closeout.stderr.bin']]
rows={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in paths}
for p in paths:shutil.copyfile(p,g/p.name)
shutil.copyfile(R/'tools/evidence.py',g/'evidence.py')
write(g/'CAPTURE_SELECTION.json',{'sourceFiles':rows,'evidence.py':{'path':str(R/'tools/evidence.py'),'sha256':sha(R/'tools/evidence.py')},'scope':'Closed selection/gather/create/separate verify/raw member readback/original guard tool originals. Subsequent metadata archive create/verify final receipts live in final handoff, avoiding self-reference.'})
dest=R/'reports/m2/stage50-native-tooling-publication-metadata.tar.gz';assert not dest.exists()
cmds=[run([sys.executable,'-B',str(R/'tools/evidence.py'),'create',str(g),str(dest)],'metadata-create'),run([sys.executable,'-B',str(R/'tools/evidence.py'),'verify',str(dest)],'metadata-verify')]
assert dest.stat().st_size<100_000_000
with tarfile.open(dest,'r:gz') as t:
 members={m.name:m for m in t.getmembers()};inv=json.load(t.extractfile(members['EVIDENCE.json']));assert set(members)=={r['path'] for r in inv['files']}|{'EVIDENCE.json'}
 for r in inv['files']:
  data=t.extractfile(members[r['path']]).read();assert data==(g/r['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==r['sha256'] and len(data)==r['bytes']
for name,row in rows.items():assert sha(O/name)==row['sha256']
metadata={'unit':'publisher-originals','repositoryRelativePath':str(dest.relative_to(R)),'sha256':sha(dest),'compressedBytes':dest.stat().st_size,'archiveInventoryFiles':len(inv['files']),'separateVerifyPassed':True,'everyMemberReadbackPassed':True}
index={'schema':1,'archives':report['archives']+[metadata],'totalCompressedBytes':report['totalCompressedBytes']+metadata['compressedBytes'],'allBelow100000000Bytes':True,'payloadOriginalGuard':{'path':'target/m2/stage50-evidence-publication-01/original-guard.json','sha256':sha(O/'original-guard.json'),'changes':0},'publisherSourceGuardChanges':0,'sourceRootCount':len(s['roots']),'sourceFileCount':len(s['files']),'selectedOriginalBytes':sum(r['bytes'] for r in s['files']),'actualPublicationTool':77077,'actualPublicationChildPid':term['pid'],'actualPublicationExitCode':0,'metadataCommands':cmds,'scopeSummary':json.loads((O/'scope-summary.json').read_bytes()),'rootGExcluded':True,'futureGitBlobBindingPending':True}
write(O/'final-index.json',index);write(R/'reports/m2/stage50-native-tooling-index.json',index)
h={'schema':1,'status':'CLOSED-published-A-through-F-raw-evidence','publicationRoot':str(O),'finalIndexSha256':sha(O/'final-index.json'),'indexRepositoryPath':'reports/m2/stage50-native-tooling-index.json','archives':index['archives'],'actualPublicationExitCode':0,'originalChanges':0,'allArchiveSeparateVerifyAndMemberReadbackPassed':True,'knownScope':'provided/public212 raw pass each; extended944936 raw=836ordinary+100diagnostic-only;8internal mismatch; fullJavaevents false; old05 adapter controls explicitly intermediate; G/root aggregate and Git binding separate.'}
write(O/'handoff.json',h)
files={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(O.iterdir()) if p.is_file() and p.name not in ['closure.json','closeout.stdout.bin','closeout.stderr.bin']}
write(O/'closure.json',{'schema':1,'files':files,'handoffSha256':sha(O/'handoff.json'),'liveEvaluatorHandles':[],'qualification':'Final outer closeout tool terminal is supplied after tool returns; no engine ran.'})
print(json.dumps({'archives':len(index['archives']),'compressedBytes':index['totalCompressedBytes'],'handoffSha256':sha(O/'handoff.json'),'closureSha256':sha(O/'closure.json'),'originalChanges':0}),flush=True)
