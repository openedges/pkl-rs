from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
r=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cmd=[sys.executable,'-B',str(r/'publish.py'),'publish']
row={'command':cmd,'cwd':str(r.parents[2]),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':sha(r/'publish.py'),'selectionSha256':sha(r/'selection.json'),'evidenceToolSha256':sha(r.parents[2]/'tools/evidence.py')}
(r/'publish.launch.json').write_text(json.dumps(row,indent=2)+'\n')
with (r/'publish.stdout.bin').open('wb') as out,(r/'publish.stderr.bin').open('wb') as err:
 p=subprocess.Popen(cmd,cwd=r.parents[2],stdout=out,stderr=err);row['pid']=p.pid
 (r/'publish.launch.json').write_text(json.dumps(row,indent=2)+'\n');code=p.wait()
row.update(exitCode=code,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceAfterSha256=sha(r/'publish.py'),selectionAfterSha256=sha(r/'selection.json'),stdoutSha256=sha(r/'publish.stdout.bin'),stderrSha256=sha(r/'publish.stderr.bin'))
(r/'publish.terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);sys.exit(code)
