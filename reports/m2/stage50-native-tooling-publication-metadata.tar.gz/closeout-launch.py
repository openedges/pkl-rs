from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
r=Path(__file__).resolve().parent
cmd=[sys.executable,'-B',str(r/'closeout.py')]
row={'command':cmd,'cwd':str(r.parents[2]),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':hashlib.sha256((r/'closeout.py').read_bytes()).hexdigest()}
with (r/'closeout.stdout.bin').open('wb') as out,(r/'closeout.stderr.bin').open('wb') as err:
 p=subprocess.Popen(cmd,cwd=r.parents[2],stdout=out,stderr=err);row['pid']=p.pid
 (r/'closeout.launch.json').write_text(json.dumps(row,indent=2)+'\n');code=p.wait()
row.update(exitCode=code,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceAfterSha256=hashlib.sha256((r/'closeout.py').read_bytes()).hexdigest())
(r/'closeout.terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);sys.exit(code)
