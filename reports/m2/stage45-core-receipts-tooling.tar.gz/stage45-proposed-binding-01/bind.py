import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
out = root / "target/m2/stage45-proposed-binding-01"
def git(*args, cwd=root):
    return subprocess.check_output(["git",*args],cwd=cwd)
def sha(data):
    return hashlib.sha256(data).hexdigest()
paths = sorted(set(git("ls-files","--modified","--others","--exclude-standard","-z").decode().split("\0"))-{''})
assert not any(p.startswith(("external/","target/")) for p in paths)
(out/"staged-paths.txt").write_bytes(b"\0".join(p.encode()for p in paths)+b"\0")
subprocess.run(["git","add","--pathspec-from-file="+str(out/"staged-paths.txt"),"--pathspec-file-nul"],cwd=root,check=True)
index = {}
for record in git("ls-files","--stage","-z").decode().split("\0"):
    if record:
        metadata,name = record.split("\t",1)
        mode,oid,stage = metadata.split()
        assert stage == "0"
        index[name]=(mode,oid)
references = {}
for name in ["pkl","pkl-pantry"]:
    reference = root/"external"/name
    pin = git("rev-parse","HEAD",cwd=reference).decode().strip()
    assert index["external/"+name] == ("160000",pin)
    references["external/"+name] = pin
    for record in git("ls-tree","-rz","HEAD",cwd=reference).decode().split("\0"):
        if record:
            metadata,path = record.split("\t",1)
            mode,kind,oid = metadata.split()
            if kind=="blob":index["external/"+name+"/"+path]=(mode,oid)
source_map = root/"target/m2/stage45-native-final-01/source-after.json"
captured = json.loads(source_map.read_text())
rows = {}
for name,expected in captured.items():
    path = root/name
    assert path.is_file() and not path.is_symlink(), name
    data = path.read_bytes()
    assert sha(data)==expected, name
    oid = hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    assert name in index and index[name][1]==oid, name
    rows[name] = {"sha256":expected,"git_blob":oid,"mode":index[name][0],"bytes":len(data)}
map_path = out/"source-map.json"
map_path.write_text(json.dumps(rows,indent=2)+"\n")
report = {
    "scope":"Final native/Rust5 captured inputs bound to the proposed Git index and pinned submodule blobs; no future commit identity claimed.",
    "base_commit":git("rev-parse","HEAD").decode().strip(),
    "references":references,
    "staged_change_paths":len(paths),
    "captured_input_paths":len(rows),
    "project_paths":sum(not name.startswith("external/")for name in rows),
    "reference_paths":sum(name.startswith("external/")for name in rows),
    "captured_source_map_sha256":sha(source_map.read_bytes()),
    "proposed_binding_map_sha256":sha(map_path.read_bytes()),
    "all_captured_inputs_match_index_or_pinned_blobs":True,
    "new_portable_tools":"Separately captured runtime consumer inputs; see stage45-portable-promotion-01 manifest.",
    "m1_source_capture_qualification":"M1 captured 76 of 77 production inputs directly. modules.txt is bound by the complete pre-platform freeze and post-platform native snapshot; see supplemental-platform-audit-03.",
    "full_m2_complete":False,
}
(out/"report.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report))
