import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

root = Path.cwd()
out = root / "target/m2/stage45-tooling-final-01"
manifest = root / "compatibility/m2-language.json"
before = json.loads(manifest.read_text())
(out / "manifest-before.json").write_bytes(manifest.read_bytes())
report = {"host": platform.platform(), "python": sys.version, "cwd": str(root), "commands": [], "complete": False}
def run(label, argv, expected=0):
    started = time.time()
    result = subprocess.run(argv, cwd=root, capture_output=True)
    (out / (label + ".stdout.bin")).write_bytes(result.stdout)
    (out / (label + ".stderr.bin")).write_bytes(result.stderr)
    row = {"label": label, "argv": argv, "exit_code": result.returncode, "expected_exit_code": expected, "seconds": time.time()-started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()}
    report["commands"].append(row)
    (out / "report.json").write_text(json.dumps(report, indent=2)+"\n")
    print(label, result.returncode, flush=True)
    assert result.returncode == expected

run("initial-manifest-stale", [sys.executable, "tools/m2_manifest.py", "--check"], 1)
run("manifest-refresh", [sys.executable, "tools/m2_manifest.py"])
run("manifest-freshness", [sys.executable, "tools/m2_manifest.py", "--check"])
after = json.loads(manifest.read_text())
assert before["cases"] == after["cases"]
assert before["counts"] == after["counts"]
changes = []
def differences(a, b, path=""):
    if a == b:
        return
    if isinstance(a, dict) and isinstance(b, dict) and a.keys() == b.keys():
        for key in a:
            differences(a[key], b[key], path+"/"+key)
    elif isinstance(a, list) and isinstance(b, list) and len(a) == len(b):
        for index, (left,right) in enumerate(zip(a,b)):
            differences(left,right,path+"/"+str(index))
    else:
        changes.append({"path":path,"before":a,"after":b})
differences(before, after)
assert all(change["path"].startswith("/requirements/") and change["path"].endswith("/sha256") for change in changes), changes
(out / "manifest-after.json").write_bytes(manifest.read_bytes())
(out / "manifest-changes.json").write_text(json.dumps(changes,indent=2)+"\n")
report["manifest_changes"] = {"source_sha256_fields":len(changes),"all_cases_counts_unchanged":True}
for name in ["guest_catch", "moduleinfo", "security_denial"]:
    run(name+"-fixtures", [sys.executable, "tools/"+name+"_fixtures.py"])
for name in ["guest_catch_fixtures", "moduleinfo_fixtures", "security_denial_fixtures", "m2_stdlib_bootstrap_compare"]:
    run(name+"-tests", [sys.executable,"-m","unittest","discover","-s","tools/tests","-p","test_"+name+".py"])
run("portable-transport-tests", ["node", "--test", *["tools/platform/"+name+"-session.test.mjs" for name in ["guest-catch","moduleinfo","security-denial","bootstrap"]]])
report["complete"] = True
report["manifest_after_sha256"] = hashlib.sha256(manifest.read_bytes()).hexdigest()
(out / "report.json").write_text(json.dumps(report, indent=2)+"\n")
