use std::{env,fs,path::Path};
use pkl_runtime::{parser::parse_module,source::SourceMap,evaluation::frontend::{evaluate_module_frontend,ModuleSourceInput,ModuleEvalOptions}};
fn main() {
 let args:Vec<_>=env::args().collect();let out=Path::new(&args[1]);
 for (i,path) in args[2..].iter().enumerate() {
  let p=Path::new(path);let text=fs::read_to_string(p).unwrap();let dir=out.join(format!("{i:02}"));fs::create_dir_all(&dir).unwrap();
  match parse_module(&text) {
   Ok(_)=>fs::write(dir.join("outcome.txt"),"parsed").unwrap(),
   Err(error)=>{
    fs::write(dir.join("outcome.txt"),format!("{:?}\n{:?}\n{}",error.kind,error.origin,error.disposition.as_str())).unwrap();
    fs::write(dir.join("message.bin"),error.message).unwrap();
    let mut sources=SourceMap::default();let id=sources.add(path,&text);let s=sources.get(id).unwrap();
    let start=s.position(error.span.start).map(|p|p.utf16).unwrap_or(error.span.start);
    let length=error.highlight_length_utf16.or_else(||s.utf16_span(error.span).map(|(_,n)|n)).unwrap_or(0);
    fs::write(dir.join("span.txt"),format!("{start}\n{length}\n")).unwrap();
   }
  }
  let uri=format!("file://{path}");let name=p.file_stem().unwrap().to_str().unwrap();
  let r=evaluate_module_frontend(ModuleSourceInput{text:&text,uri:&uri,inferred_name:name},&ModuleEvalOptions::default());
  fs::write(dir.join("stdout.bin"),r.stdout).unwrap();fs::write(dir.join("stderr.bin"),r.stderr).unwrap();
  fs::write(dir.join("result.txt"),format!("{}\n{}\n{}\n{:?}\n",r.exit_code,r.phase.as_str(),r.disposition.as_str(),r.reason)).unwrap();
 }
}
