from pathlib import Path
p=Path('crates/pkl-runtime/src/parser.rs');s=p.read_text()
# Proper lexical errors, with their original language disposition.
s=s.replace('''        } else {
            return Err(Diagnostic::language(
                DiagnosticOrigin::Lexer,
                DiagnosticKind::Unsupported,
                Span::new(start, self.cursor),
                format!("M1 token `{ch}` is unsupported."),
            ));
        };''','''        } else {
            if ch == '&' || ch == '~' {
                return Err(self.unexpected_unicode_character(
                    &ch.to_string(), if ch == '&' { "&&" } else { "~/" },
                ));
            }
            return Err(Diagnostic::language(
                DiagnosticOrigin::Lexer,
                DiagnosticKind::Syntax,
                Span::new(start, self.cursor),
                format!("Invalid identifier `{ch}`."),
            ));
        };''')
# Numeric separators use the source location of the illegal separator.
s=s.replace('''                if !self.peek().is_some_and(|ch| ch.is_digit(radix)) {''','''                if self.peek() == Some('_') { return Err(self.numeric_separator(self.cursor)); }
                if !self.peek().is_some_and(|ch| ch.is_digit(radix)) {''')
a='''                return Err(Diagnostic::language(
                    DiagnosticOrigin::Lexer,
                    DiagnosticKind::Syntax,
                    Span::new(start, self.cursor + 2),
                    "Invalid numeric separator position.",
                ));''';assert a in s;s=s.replace(a,'''                return Err(self.numeric_separator(self.cursor + 1));''')
s=s.replace('''            if !self.peek().is_some_and(|ch| ch.is_ascii_digit()) {''','''            if self.peek() == Some('_') { return Err(self.numeric_separator(self.cursor)); }
            if !self.peek().is_some_and(|ch| ch.is_ascii_digit()) {''')
anchor='    fn number(&mut self, start: usize, first: char) -> Result<Kind, Diagnostic> {'
s=s.replace(anchor,'''    fn numeric_separator(&self, offset: usize) -> Diagnostic {
        Diagnostic::language(DiagnosticOrigin::Lexer, DiagnosticKind::Syntax,
            Span::new(offset, offset + 1),
            "Unexpected separator character.\\n\\nThe separator character (`_`) cannot follow `0x`, `0b`, `.`, `e`, or 'E' in a number literal.")
    }

'''+anchor)
# Reserved identifiers are language errors, not capability failures.
a='''            return Err(Diagnostic::language(
                DiagnosticOrigin::Parser,
                DiagnosticKind::Unsupported,
                self.token.span,
                "M1 keyword cannot be used as an identifier.",
            ));''';assert a in s;s=s.replace(a,'''            return Err(Diagnostic::language(
                DiagnosticOrigin::Parser, DiagnosticKind::Syntax, self.token.span,
                format!("Keyword `{name}` is not allowed here.\\n\\nIf you must use this name as identifier, enclose it in backticks."),
            ));''')
# Shared string-constant grammar does not evaluate interpolations.
anchor='    fn annotations(&mut self) -> Result<Vec<Expr>, Diagnostic> {'
s=s.replace(anchor,'''    fn string_constant(&mut self) -> Result<(PklString, Span), Diagnostic> {
        match self.token.kind.clone() {
            Kind::String(text) => Ok((text, self.advance()?.span)),
            Kind::StringTemplate(parts) => {
                let span = parts.iter().find_map(|part| match part {
                    StringPart::Expression(_, span) => Some(*span), _ => None,
                }).unwrap_or(self.token.span);
                Err(Diagnostic::language(DiagnosticOrigin::Parser, DiagnosticKind::Syntax,
                    span, "String constant cannot have interpolated values."))
            }
            _ => Err(self.unexpected(Some("\\\""))),
        }
    }

'''+anchor)
a='''        let Kind::String(uri) = self.token.kind.clone() else {
            return Err(self.unexpected(Some("string constant")));
        };
        let uri_span = self.advance()?.span;''';assert a in s;s=s.replace(a,'''        let (uri, uri_span) = self.string_constant()?;''')
# Typed class property amendments reject at the body before later phases.
a='''            } else if self.is_symbol('{') && ty.is_none() {''';assert a in s;s=s.replace(a,'''            } else if self.is_symbol('{') && ty.is_some() {
                return Err(Diagnostic::language(DiagnosticOrigin::Parser, DiagnosticKind::Syntax,
                    self.token.span, "Properties with type annotations cannot have object bodies.\\n\\nTo define both a type annotation and an object body, try using assignment instead.\\nFor example: `obj: Bird = new { ... }`."));
            } else if self.is_symbol('{') {''',1)
# Missing object closer is diagnosed before a nested declaration.
a='''                if self.is_name("unknown") || self.is_name("nothing") {''';assert a in s;s=s.replace(a,'''                if self.is_name("class") || self.is_name("typealias") {
                    let mut error = Diagnostic::language(DiagnosticOrigin::Parser, DiagnosticKind::Syntax,
                        Span::new(self.previous_end, self.previous_end), "Missing `}` delimiter.");
                    error.highlight_length_utf16 = Some(1);
                    return Err(error);
                }
                if self.is_name("unknown") || self.is_name("nothing") {''',1)
# Parenthesized/function ambiguity commits at comma/colon/_/empty parameter head.
a='''                let parameters = candidate.parameters();
                if let Ok(parameters) = parameters''';assert a in s;s=s.replace(a,'''                let mut head = self.clone();
                head.advance()?;
                let mut committed = head.is_name("_") || head.is_symbol(')');
                if matches!(head.token.kind, Kind::Name(_) | Kind::QuotedName(_)) && !head.is_name("_") {
                    head.advance()?;
                    committed = head.is_symbol(',') || head.is_symbol(':');
                }
                let parameters = candidate.parameters();
                if committed && let Err(error) = &parameters { return Err(error.clone()); }
                if let Ok(parameters) = parameters''',1)
# Correct method and function parameter-list closing expectation.
a='''        self.expect(')')?;
        Ok(parameters)''';assert a in s;s=s.replace(a,'''        if !self.is_symbol(')') { return Err(self.unexpected(Some(",` or `)"))); }
        self.advance()?;
        Ok(parameters)''')
# Object entry body alternatives.
a='''                } else {
                    let parent = Expr {
                        kind: ExprKind::EntryParent,''';assert a in s;s=s.replace(a,'''                } else {
                    if !self.is_symbol('{') { return Err(self.unexpected(Some("{` or `="))); }
                    let parent = Expr {
                        kind: ExprKind::EntryParent,''',1)
# Amendment grammar allows new/amended objects as well as parentheses.
a='''                if !self.lexer.source[left.span.start..left.span.end].starts_with('(') {
                    return Err(Diagnostic::language(
                        DiagnosticOrigin::Parser,
                        DiagnosticKind::Unsupported,
                        self.token.span,
                        "M1 amendment parent must be parenthesized.",
                    ));
                }''';assert a in s;s=s.replace(a,'''                if !matches!(left.kind, ExprKind::Parenthesized(_) | ExprKind::New { .. } | ExprKind::Object { .. }) {
                    let parent = &self.lexer.source[left.span.start..left.span.end];
                    return Err(Diagnostic::language(DiagnosticOrigin::Parser, DiagnosticKind::Syntax,
                        self.token.span, format!("Unexpected token: `{{`.\\n\\nIf you meant to write an amends expression, wrap the parent in parentheses. Try: `({parent}) {{ ... }}`")));
                }''')
# Keyword expressions must distinguish valid missing imports from invalid syntax.
a='''                    return Err(Diagnostic::language(
                        DiagnosticOrigin::Parser,
                        DiagnosticKind::Unsupported,
                        span,
                        format!("M1 expression `{name}` is unsupported."),
                    ));''';assert a in s;s=s.replace(a,'''                    if name == "import" {
                        return Err(Diagnostic::unsupported(DiagnosticOrigin::Parser,
                            "import-expression", span, "Import expressions are not implemented."));
                    }
                    return Err(self.unexpected(self.expectation.as_deref()));''')
a='''                return Err(Diagnostic::language(
                    DiagnosticOrigin::Parser,
                    DiagnosticKind::Unsupported,
                    span,
                    "M1 token `[` is unsupported.",
                ));''';assert a in s;s=s.replace(a,'''                return Err(self.unexpected(self.expectation.as_deref()));''')
# String-start token extent used by parser diagnostics, not full literal extent.
a='''                    self.token.span,
                    "Invalid token at position. Expected a class, typealias, method, or property.",''';assert a in s;s=s.replace(a,'''                    self.diagnostic_token_span(),
                    "Invalid token at position. Expected a class, typealias, method, or property.",''')
anchor='    fn unexpected(&self, expected: Option<&str>) -> Diagnostic {'
s=s.replace(anchor,'''    fn diagnostic_token_span(&self) -> Span {
        if matches!(self.token.kind, Kind::String(_) | Kind::StringTemplate(_)) {
            let text = &self.lexer.source[self.token.span.start..self.token.span.end];
            let hashes = text.bytes().take_while(|&b| b == b'#').count();
            let quotes = if text[hashes..].starts_with("\\\"\\\"\\\"") { 3 } else { 1 };
            Span::new(self.token.span.start, self.token.span.start + hashes + quotes)
        } else { self.token.span }
    }

'''+anchor)
# New type contextual expectation, using an explicit type machine argument.
s=s.replace('''Some(self.type_expression()?)
                };
                let missing_delimiter''','''Some(self.type_expression_expected(Some("{"))?)
                };
                let missing_delimiter''',1)
a='''    fn type_expression(&mut self) -> Result<Type, Diagnostic> {
        let depth = self.depth;
        let result = self.type_inner();''';assert a in s;s=s.replace(a,'''    fn type_expression(&mut self) -> Result<Type, Diagnostic> {
        self.type_expression_expected(None)
    }

    fn type_expression_expected(&mut self, expected: Option<&'static str>) -> Result<Type, Diagnostic> {
        let depth = self.depth;
        let result = self.type_inner(expected);''')
p.write_text(s)
# Hash-prefix EOF is ordinary lexer EOF.
p=Path('crates/pkl-runtime/src/parser/string_lexer.rs');s=p.read_text();a='''            if self.advance() != Some('"') {''';assert a in s;s=s.replace(a,'''            if self.peek().is_none() {
                return Err(Diagnostic::language(DiagnosticOrigin::Lexer, DiagnosticKind::Syntax,
                    Span::new(self.cursor.saturating_sub(1), self.cursor), "Unexpected end of file."));
            }
            if self.advance() != Some('"') {''',1)
# The ASCII error is now already classified by the ordinary lexer.
a='''                    "&" if error.kind == DiagnosticKind::Unsupported => {''';s=s.replace(a,'''                    "&" if error.origin == DiagnosticOrigin::Lexer => {''');s=s.replace('''                    "~" if error.kind == DiagnosticKind::Unsupported => {''','''                    "~" if error.origin == DiagnosticOrigin::Lexer => {''')
p.write_text(s)
