import json,sys,shutil,subprocess,hashlib,collections
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');OUT=ROOT/'target/m2/stage39-frontend-boundary-oracle-01';JAVA=ROOT/'target/m2/stage39-original72-java-01';PHASE=ROOT/'target/m2/stage39-original72-phase-01';WORK=OUT/'workspace'
sys.path.insert(0,str(ROOT/'tools'));import compat,oracle
assert (JAVA/'closure.json').is_file(),'Original CLI must be closed first'
profile=json.loads((JAVA/'profile.json').read_text());WORK.mkdir()
sources=[('import-interpolation-nested-error','import "\\( )"\nresult = 1\n'),('import-interpolation-later-escape','import "\\(1)\\q"\nresult = 1\n'),('extends-interpolation-nested-error','extends "\\( )"\n'),('valid-new-amendment','result = (new Dynamic { x = 1 } { y = 2 }).x\n'),('doc-comment-bridge','/// first\n// bridge\n/// continuation\nresult = 1\n'),('doc-comment-gap','/// first\n\n/// second\nresult = 1\n'),('doc-comment-trailing','result = 1\n/// trailing\n')]
records=[];inputs=[]
for i,(name,source) in enumerate(sources):
 path=WORK/(name+'.pkl');path.write_bytes(source.encode());inputs.append(path)
 case={'id':'stage39-boundary-'+name,'command':json.loads((JAVA/'original72.json').read_text())[0]['upstream_case']['command'][:-1]+[name+'.pkl'],'cwd':'.','environment':{'LANG':'C.UTF-8','LC_ALL':'C.UTF-8','NO_COLOR':'1','TERM':'dumb','TZ':'UTC'}}
 for repeat in [0,1]:
  directory=OUT/'cases'/name/str(repeat);command,env,generated,recorded=compat.case_execution(case,profile['command'],profile['environment'],WORK);before=compat.snapshot(WORK)
  try:result=compat.capture(command,WORK,env,60,generated)
  except compat.CaptureTimeout as e:result=e.result
  after=compat.snapshot(WORK);changes={k:{'before':before.get(k),'after':after.get(k)} for k in before.keys()|after.keys() if before.get(k)!=after.get(k)}
  # All sources must remain unchanged; retain unexpected writes instead of normalizing.
  result['workspace_changes']=changes;result['files']={f'generated/{k}':v for k,v in result['files'].items()}
  for k,v in changes.items():
   p=WORK/k
   if p.is_file() or p.is_symlink():result['files']['workspace/'+k]=compat.resource_bytes(p)
  metadata=compat.store_capture(directory,result);private=compat.output_files(WORK/'.state'/compat.case_directory(case['id']))
  for name2,data in private.items():
   p=directory/'private-state'/name2;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  process={'id':case['id'],'repeat':repeat,'source':path.name,'sourceSha256':oracle.sha256(path),'sourceUri':path.as_uri(),'command':command,'cwd':str(WORK),'environment':recorded,'result':metadata,'privateFiles':{k:compat.digest(v) for k,v in private.items()}}
  (directory/'process.json').write_bytes(compat.encoded(process));records.append(process)
  assert not changes,'Unexpected public writes retained; stop rather than reset authored boundary fixtures'
command=[profile['jdk']['executable'],*json.loads((ROOT/'oracle.lock.json').read_text())['jvm_options'],f'-Duser.home={OUT}/phase-home',f'-Djava.io.tmpdir={OUT}/phase-tmp','-cp',str(PHASE)+':'+profile['artifact'],'PhaseProbe',str(OUT/'phases'),*[str(p) for p in inputs]]
(OUT/'phase-home').mkdir();(OUT/'phase-tmp').mkdir();env={**profile['environment'],'HOME':str(OUT/'phase-home'),'TMPDIR':str(OUT/'phase-tmp'),'TMP':str(OUT/'phase-tmp'),'TEMP':str(OUT/'phase-tmp')};p=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,timeout=60);(OUT/'phase.stdout.bin').write_bytes(p.stdout);(OUT/'phase.stderr.bin').write_bytes(p.stderr);assert p.returncode==0
phases=[]
for i,(name,source) in enumerate(sources):
 folder=OUT/'phases'/f'{i:02d}';phases.append({'id':'stage39-boundary-'+name,'sourceSha256':oracle.sha256(inputs[i]),'outcome':(folder/'outcome.txt').read_text()})
diffs=[]
for name,_ in sources:
 changed=compat.differences(compat.load_capture(OUT/'cases'/name/'0'),compat.load_capture(OUT/'cases'/name/'1'));diffs.append({'id':name,'channels':changed})
report={'scope':'Supplemental original-authored Java CLI + Parser boundaries, not original72 replacements or Rust compatibility','caseCount':len(sources),'processCount':len(records),'oracleProfilePath':str(JAVA/'profile.json'),'oracleProfileSha256':oracle.sha256(JAVA/'profile.json'),'phaseCommand':command,'phaseExit':p.returncode,'phaseClassSha256':oracle.sha256(PHASE/'PhaseProbe.class'),'records':records,'phases':phases,'repeatDifferences':diffs,'note':'Parsed positive controls require real output evaluation; frontend-prefix candidate must retain unsupported, never synthesize output success.'}
(OUT/'report.json').write_bytes(compat.encoded(report));print(json.dumps({'cases':len(sources),'processes':len(records),'phases':phases,'repeatDifferences':diffs}))
