from pathlib import Path
import subprocess,json,hashlib,os
r=Path.cwd();o=r/'target/m2/stage39-adapter-checks-01'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
checks=[('module-tool',['python3','-m','unittest','discover','-s','tools/tests','-p','test_m2_module_eval.py','-v'],None),
('selection',['python3','-m','unittest','-v','test_m2_language.AdapterSelectionTests'],{'PYTHONPATH':str(r/'tools/tests')}),
('clippy',['cargo','clippy','-p','pkl-runtime','--example','module_eval_probe','-p','pkl-napi','-p','pkl-wasm','--locked','--target-dir','target/m2/stage39-adapter-cargo','--','-D','warnings'],None)]
results=[]
for name,command,environment in checks:
 with (o/(name+'.stdout.bin')).open('wb') as stdout,(o/(name+'.stderr.bin')).open('wb') as stderr:
  p=subprocess.run(command,cwd=r,env={**os.environ,**(environment or {})},stdout=stdout,stderr=stderr)
 row={'name':name,'command':command,'cwd':str(r),'environment_overrides':environment or {},'exit_code':p.returncode,'stdout_sha256':sha(o/(name+'.stdout.bin')),'stderr_sha256':sha(o/(name+'.stderr.bin'))}
 (o/(name+'.process.json')).write_text(json.dumps(row,indent=2)+'\n');results.append(row);print(name,p.returncode,flush=True)
(o/'report.json').write_text(json.dumps({'scope':'Targeted adapter checks during active A parser work; not a frozen runtime comparison.','checks':results,'all_passed':all(x['exit_code']==0 for x in results)},indent=2)+'\n')
raise SystemExit(any(x['exit_code'] for x in results))
