"""Archive closed Stage39 observations with exact, pre-traversal cache exclusions."""
from pathlib import Path
import hashlib
import io
import json
import os
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).parent
BASE = ROOT / 'target/m2'
DEST = ROOT / 'reports/m2'

def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def sha(data):
    return hashlib.sha256(data).hexdigest()

groups = {
    'development': [
        'stage39-adapter-checks-01', 'stage39-adapter-final-checks-01',
        *[f'stage39-adapter-tests-{number:02d}' for number in range(1, 8)],
        'stage39-manifest-refresh-01', 'stage39-module-baseline-build-01',
        'stage39-module-baseline-comparison-01',
        'stage39-core-validation-01', 'stage39-core-validation-02',
        'stage39-core-validation-03', 'stage39-core-original72-baseline-01',
        'stage39-core-original72-02', 'stage39-root-contract-review-01',
        'stage39-next-scope-design-01', 'stage39-frontend-boundary-oracle-01',
        'stage39-doc-semicolon-oracle-01',
    ],
    'platform': [
        'stage39-module-boundary-platform-final-01', 'stage39-module-boundary-platform-tool-01',
        'stage39-module-platform-driver-review-01', 'stage39-module-platform-driver-review-02',
        'stage39-original72-platform-final-01', 'stage39-platform-build-session-01',
        'stage39-platform-final-audit-01', 'stage39-platform-preparation-01',
        'stage39-platforms-final-01', 'stage39-portable-session-01',
    ],
    'regression': [
        'stage39-check-runner-01', 'stage39-checks-final-01',
        'stage39-persistent-final-01', 'stage39-trace-final-01',
        'stage39-regression-review-01',
    ],
}
excluded = {
    BASE / 'stage39-persistent-final-01/build',
    BASE / 'stage39-trace-final-01/build',
}
# These wrappers are terminal. The live full-language wrapper is deliberately
# outside this checkpoint, and will be preserved with the final acquisition.
groups['regression'] += [
    'stage39-command-captures-01/' + name for name in [
        'persistent-final-01', 'persistent-contract-final-01',
        'trace-final-01', 'trace-report-final-01', 'trace-contract-final-01',
    ]
]

def files(roots):
    found = {}
    for name in roots:
        path = BASE / name
        assert path.is_dir(), path
        for directory, children, names in os.walk(path, topdown=True, followlinks=False):
            children[:] = sorted(child for child in children if Path(directory) / child not in excluded)
            for child in children:
                assert not (Path(directory) / child).is_symlink(), Path(directory) / child
            for filename in sorted(names):
                source = Path(directory) / filename
                assert source.is_file() and not source.is_symlink(), source
                key = source.relative_to(BASE).as_posix()
                assert key not in found, key
                found[key] = source
    return found

results = {}
for group, roots in groups.items():
    sources = files(roots)
    if group == 'development':
        sources['stage39-checkpoint-seal-01/seal.py'] = Path(__file__)
    inventory = {}
    for name, source in sorted(sources.items()):
        data = source.read_bytes()
        inventory[name] = dict(bytes=len(data), sha256=sha(data), mode=stat.S_IMODE(source.stat().st_mode))
    inventory_bytes = encoded(dict(schema=1, scope='Closed Stage39 checkpoint evidence; final native acquisitions remain separate.',
                                  roots=roots, files=inventory,
                                  exclusions=[str(path.relative_to(BASE)) for path in sorted(excluded)
                                              if any(path.is_relative_to(BASE / root) for root in roots)],
                                  exclusion_policy='Only the listed actual Cargo cache paths are pruned before traversal. Other build directories and all closure files are retained.'))
    archive = DEST / f'stage39-{group}-evidence.tar.gz'
    assert not archive.exists(), archive
    with tarfile.open(archive, 'w:gz') as target:
        for name in sorted(inventory):
            data = sources[name].read_bytes()
            assert sha(data) == inventory[name]['sha256']
            info = tarfile.TarInfo(name)
            info.size, info.mode = len(data), inventory[name]['mode']
            target.addfile(info, io.BytesIO(data))
        info = tarfile.TarInfo('archive-inventory.json')
        info.size = len(inventory_bytes)
        target.addfile(info, io.BytesIO(inventory_bytes))
    with tarfile.open(archive, 'r:gz') as target:
        members = target.getmembers()
        assert len(members) == len(inventory) + 1
        assert {member.name for member in members} == set(inventory) | {'archive-inventory.json'}
        for member in members:
            assert member.isfile()
            data = target.extractfile(member).read()
            if member.name == 'archive-inventory.json':
                assert data == inventory_bytes
            else:
                row = inventory[member.name]
                assert len(data) == row['bytes'] and sha(data) == row['sha256']
                assert member.mode == row['mode']
    for name, source in sources.items():
        assert sha(source.read_bytes()) == inventory[name]['sha256'], name
    row = dict(path=str(archive.relative_to(ROOT)), bytes=archive.stat().st_size,
               sha256=sha(archive.read_bytes()), inventory_sha256=sha(inventory_bytes),
               original_files=len(inventory), original_bytes=sum(row['bytes'] for row in inventory.values()),
               roots=roots, extracted_members_verified=True, originals_stable=True)
    results[group] = row
    (OUT / f'{group}.json').write_bytes(encoded(row))
    print(json.dumps(row), flush=True)

report = dict(schema=1, scope='Closed Stage39 checkpoint development, platform and regression evidence. Pending native language acquisitions are not included or claimed complete.',
              helper_sha256=sha(Path(__file__).read_bytes()), archives=results,
              existing_oracle_archive=dict(path='reports/m2/stage39-oracle-evidence.tar.gz',
                  sha256=sha((DEST / 'stage39-oracle-evidence.tar.gz').read_bytes())),
              excluded_cargo_paths=[str(path) for path in sorted(excluded)],
              excluded_cargo_contents_enumerated=False)
(OUT / 'report.json').write_bytes(encoded(report))
(DEST / 'stage39-checkpoint-captures.json').write_bytes(encoded(report))
