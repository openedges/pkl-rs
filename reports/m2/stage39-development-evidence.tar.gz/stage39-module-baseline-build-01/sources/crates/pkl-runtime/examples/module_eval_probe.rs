//! Development-only original module-eval frontend boundary, not a product CLI.
use pkl_runtime::evaluation::frontend::{
    ModuleSourceInput, arguments::parse_module_eval_args, evaluate_module_frontend,
};
use std::{io::Write, path::Path};

fn file_uri(path: &Path) -> Result<String, String> {
    let path = path
        .to_str()
        .ok_or("module-eval adapter requires a UTF-8 source path")?;
    let mut uri = String::from("file://");
    for byte in path.bytes() {
        if byte.is_ascii_alphanumeric() || b"/-._~:".contains(&byte) {
            uri.push(char::from(byte));
        } else {
            use std::fmt::Write;
            write!(uri, "%{byte:02X}").expect("writing to String cannot fail");
        }
    }
    Ok(uri)
}

fn run() -> Result<i32, String> {
    let arguments = std::env::args().skip(1).collect::<Vec<_>>();
    let invocation = parse_module_eval_args(&arguments)?;
    // Resolve the authored relative path against the actual process cwd. Do not
    // canonicalize symlinks or substitute an oracle display URI.
    let path = std::path::absolute(&invocation.source_path).map_err(|error| error.to_string())?;
    let text = std::fs::read_to_string(&path).map_err(|error| error.to_string())?;
    let uri = file_uri(&path)?;
    let inferred_name = path
        .file_stem()
        .and_then(|value| value.to_str())
        .ok_or("module-eval adapter requires a UTF-8 module name")?;
    let result = evaluate_module_frontend(
        ModuleSourceInput {
            text: &text,
            uri: &uri,
            inferred_name,
        },
        &invocation.options,
    );
    std::io::stdout()
        .write_all(&result.stdout)
        .map_err(|error| error.to_string())?;
    std::io::stderr()
        .write_all(&result.stderr)
        .map_err(|error| error.to_string())?;
    Ok(result.exit_code)
}

fn main() {
    match run() {
        Ok(code) => std::process::exit(code),
        Err(error) => {
            eprintln!("module-eval adapter unsupported: {error}");
            std::process::exit(2);
        }
    }
}
