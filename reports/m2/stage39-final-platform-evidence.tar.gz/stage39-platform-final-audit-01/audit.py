import json,sys,hashlib,os,collections
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage39');M2=ROOT/'target/m2';OUT=M2/'stage39-platform-final-audit-01';sys.path.insert(0,str(ROOT/'tools'));import m1_platforms

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def close(path,scope):
 if (path/'closure.json').exists():
  closure=load(path/'closure.json');assert sha(path/'report.json')==closure['reportSha256'] and sha(path/'inventory.json')==closure['inventorySha256']
  for entry in load(path/'inventory.json')['files']:
   file=path/entry['path'];assert file.stat().st_size==entry['bytes'] and sha(file)==entry['sha256']
  return {'reportSha256':closure['reportSha256'],'closureSha256':sha(path/'closure.json'),'inventorySha256':closure['inventorySha256'],'files':closure['files']}
 files=[]
 # Actual caches are excluded before traversal. Never exclude generic build log directories.
 excluded={ROOT/'target/debug',ROOT/'target/release',ROOT/'target/wasm32-unknown-unknown',ROOT/'.cache'}
 for current,dirs,names in os.walk(path,topdown=True,followlinks=False):
  dirs[:]=sorted(name for name in dirs if name not in {'node_modules','.cache'} and Path(current)/name not in excluded and not name.endswith('-cargo'))
  for name in sorted(names):
   p=Path(current)/name;relative=p.relative_to(path).as_posix()
   if relative in ['inventory.json','closure.json']:continue
   assert not p.is_symlink(),p
   files.append({'path':relative,'bytes':p.stat().st_size,'sha256':sha(p)})
 write(path/'inventory.json',{'files':files});closure={'status':'closed','files':len(files),'reportSha256':sha(path/'report.json'),'inventorySha256':sha(path/'inventory.json'),'scope':scope};write(path/'closure.json',closure);return {'reportSha256':closure['reportSha256'],'closureSha256':sha(path/'closure.json'),'inventorySha256':closure['inventorySha256'],'files':len(files)}

standard=M2/'stage39-platforms-final-01';report=load(standard/'report.json');build=M2/'stage39-platform-build-session-01';process=load(build/'process.json');sourceBefore=load(build/'sources-before.json');sourceAfter=load(build/'sources-after.json')
assert process['exitCode']==0 and process['sourceStability'] and not process['changedSources']
assert sourceBefore==sourceAfter==report['source_hashes']==load(standard/'sources.json')
for name,digest in sourceBefore.items():assert sha(ROOT/name)==digest==sha(standard/'sources'/name)
for name,digest in report['artifacts'].items():assert sha(standard/name)==digest
m1_platforms.check_scenarios(report['execution']);captures={'java':(standard/'oracle-native/java.stdout.bin').read_bytes(),'rust':(standard/'oracle-native/rust.stdout.bin').read_bytes(),'node':(standard/'execution/node.stdout.bin').read_bytes(),'browser':(standard/'execution/browser.stdout.bin').read_bytes()};rows=m1_platforms.compare(m1_platforms.generate_cases()['cases'],captures);assert rows==report['comparisons'];assert m1_platforms.contract_matches(rows)
assert report['source_stability'] and report['shared_engine_passed']==6078 and report['oracle_passed']=={'rust':6076,'node':6076,'browser':6076} and report['compatibility_status']=='fail' and report['experiment_contract_status']=='pass'
commands=load(standard/'commands.json');assert [(x['name'],x['exit_code']) for x in commands]==[('bindgen-version',0),('rust-version',0),('native-build',0),('napi-build',0),('wasm-build',0),('wasm-bindgen',0),('oracle-native',1),('platforms',0)]
portable=M2/'stage39-original72-platform-final-01';pr=load(portable/'execution.json');fixtures=load(portable/'fixtures.json');original=load(M2/'stage39-original72-java-01/original72.json');assert len(fixtures)==72 and [x['id'] for x in fixtures]==[x['id'] for x in original]
phaseDifferences={};reasonKinds={}
for target,data in pr['targets'].items():
 assert data['complete'] and data['statusCounts']=={'pass':144} and len(data['results'])==144
 seen=set();bad=[];reasonKinds[target]=collections.Counter()
 for row in data['results']:
  pair=(row['id'],row['repeat']);assert pair not in seen;seen.add(pair);assert row['status']=='pass' and row['rawMatch'] and row['exitCodeEqual'] and row['expectedExitCode']==row['actualExitCode']==1 and row['disposition']=='language-error'
  fixture=next(x for x in fixtures if x['id']==row['id']);directory=portable/target/fixture['directory']/str(row['repeat']);assert load(directory/'result.json')==row
  for channel,meta in row['channels'].items():
   left=(directory/('java.'+channel+'.bin')).read_bytes();right=(directory/(channel+'.bin')).read_bytes();assert left==right and meta['rawEqual'] and hashlib.sha256(left).hexdigest()==meta['expectedSha256']==meta['actualSha256']
  assert row['phaseMatch']==(row['phase']==row['expectedFrontendPhase'])
  if not row['phaseMatch']:bad.append(row)
  reasonKinds[target][row['reasonKind']]+=1
 assert len(bad)==24 and len({x['id'] for x in bad})==12 and all(x['expectedFrontendPhase']=='parsing' and x['phase']=='lexing' for x in bad)
 phaseDifferences[target]=[{'id':x['id'],'repeat':x['repeat'],'javaProducer':x['expectedFrontendPhase'],'rustProducer':x['phase']} for x in bad]
assert pr['compatibilityComplete'] and not pr['phaseObservationsMatched'] and not pr['changedInputs'] and not pr['infrastructureErrors'] and not pr['browserErrors']
for path,digest in pr['artifactAndInputHashes'].items():assert sha(Path(path))==digest
boundary=M2/'stage39-module-boundary-platform-final-01';br=load(boundary/'execution.json');assert br['prefixContractPassed'] and not br['compatibilityComplete'] and not br['changedInputs'] and not br['infrastructureErrors'] and not br['browserErrors']
for target,data in br['targets'].items():
 assert data['complete'] and data['statusCounts']=={'unsupported':8} and len(data['results'])==8
 for row in data['results']:
  assert row['status']=='unsupported' and row['prefixBoundaryCorrect'] and not row['rawMatch'] and row['javaExitCode']==0 and row['candidateExitCode']==2 and row['phase']=='module-output' and row['disposition']=='unsupported'
  directory=boundary/target/row['id']/str(row['repeat']);assert load(directory/'result.json')==row
  for channel,meta in row['channels'].items():
   left=(directory/('java.'+channel+'.bin')).read_bytes();right=(directory/(channel+'.bin')).read_bytes();assert hashlib.sha256(left).hexdigest()==meta['javaSha256'] and hashlib.sha256(right).hexdigest()==meta['candidateSha256'] and meta['rawEqual']==(left==right)
for path,digest in br['hashes'].items():assert sha(Path(path))==digest
session=M2/'stage39-portable-session-01';sr=load(session/'report.json');assert sr['sourceStability'] and sr['artifactStability'] and not sr['changedSources'];assert [x['exitCode'] for x in sr['commands']]==[0,1];assert load(session/'sources-before.json')==load(session/'sources-after.json')==sourceBefore;assert load(session/'artifacts-before.json')==load(session/'artifacts-after.json')
for name,digest in load(session/'artifacts-before.json').items():assert sha(standard/name)==digest
assert pr['browser']==br['browser']==report['execution']['browser']=='156.0.8078.4';assert pr['browserExecutableSha256']==br['browserExecutableSha256']==sha(Path(pr['browserExecutable']));assert pr['node']==br['node']==report['execution']['node'];assert pr['playwright']==br['playwright']==report['execution']['playwright']=='1.64.1'
prep=M2/'stage39-platform-preparation-01';layout=load(prep/'cache-layout.json');after={name:sha(ROOT/'.cache'/name) for name in layout['artifactHashesBefore']};assert after==layout['artifactHashesBefore']==layout['artifactHashesAfter'];
if not (prep/'closure.json').exists():
 write(prep/'shared-artifacts-after.json',after);write(prep/'report.json',{'scope':'Ignored Stage39 cache layout only; MAIN input JAR/tool bytes unchanged; local oracle private state remains mutable cache outside evidence.','layoutSha256':sha(prep/'cache-layout.json'),'sharedArtifactHashes':after,'writableOraclePrivateRoot':str(ROOT/'.cache/oracle'),'original72WorkspaceUnmodifiedByPlatformRun':True})
if not (build/'closure.json').exists():
 write(build/'report.json',{'process':process,'standardReportPath':str(standard/'report.json'),'standardReportSha256':sha(standard/'report.json'),'sourcesStable':True,'sourceCount':len(sourceBefore),'scope':'Actual prescribed standard platform build/process; architecture pass preserves strict known compatibility gaps.'})
tool=M2/'stage39-module-boundary-platform-tool-01'
if not (tool/'closure.json').exists():
 write(tool/'report.json',{'scope':'Ignored four-source accepted-output dependency transport, source executed by portable-session-01; no platform-specific evaluator.','sourceSha256':sha(tool/'run.mjs'),'executionReportPath':str(boundary/'execution.json'),'executionReportSha256':sha(boundary/'execution.json')})
for path,scope in [(portable,'Original72 portable byte API raw equality, internal producer differences retained'),(boundary,'Four Java output-success controls remain Unsupported on frontend prefix')]:
 if not (path/'closure.json').exists():
  write(path/'report.json',{'scope':scope,'executionPath':'execution.json','executionSha256':sha(path/'execution.json'),'rawPayloadsUnchanged':True})
closed={}
for path,scope in [(prep,'Ignored cache isolation metadata'),(build,'Recorded actual prescribed platform process'),(standard,'Standard actual Node/Chromium architecture contract pass; strict6076/6078 preserved'),(portable,'Original72 portable byte API raw equality only; internal producer differences retained'),(tool,'Ignored accepted-source dependency transport'),(boundary,'Four accepted Java-output sources remain Unsupported on frontend prefix'),(session,'Actual portable process/source/artifact bindings')]:closed[path.name]=close(path,scope)
audit={'status':'pass','scope':'Offline complete raw audit, no evaluator rerun. Original72 native CLI process/files contract remains separately owned by B.','standard':{'cases':6078,'sharedEngine':6078,'oracleMatchesEach':6076,'architectureScenariosEach':92,'contractStatus':'pass','strictCompatibility':'fail','knownMismatchIds':[x['id'] for x in rows if not all(x['oracle_matches'].values())]},'original72Portable':{'cases':72,'nodeCalls':144,'browserCalls':144,'rawPasses':288,'sourceUriAndOriginalArgvBoundary':'Exact source/physical URI/argv from closed original Java acquisition','internalPhaseDifferencesDistinct':12,'phaseDifferenceCallsEach':24,'phaseDifferences':phaseDifferences,'reasonKinds':{k:dict(v) for k,v in reasonKinds.items()},'phaseInterpretation':'Actual Rust producer names differ from Java throw sites; no relabeling and no change to raw compatibility pass criteria.'},'acceptedBoundary':{'cases':4,'callsEachTarget':8,'status':'unsupported','prefixContractCorrect':True,'compatibilityComplete':False,'java':'actual output success0','candidate':'explicit module-output Unsupported2'},'browser':{'version':pr['browser'],'executable':pr['browserExecutable'],'sha256':pr['browserExecutableSha256'],'playwright':'1.64.1'},'node':{'version':pr['node'],'executable':pr['nodeExecutable'],'sha256':pr['nodeExecutableSha256']},'artifacts':report['artifacts'],'sourceCount':len(sourceBefore),'sourceStability':True,'artifactStability':True,'terminalProcesses':{'standardSession':58419,'standardExit':0,'portableSession':59294,'portableWrapperExit':0,'original72Exit':0,'boundaryStrictExit':1},'closedRoots':closed,'noLiveWriters':True,'cachePruning':'Only explicit owned evidence roots traversed; actual target/debug,release,wasm32-unknown-unknown and named*-cargo plus node_modules/.cache pruned before descent. Generic build log directories retained.'};write(OUT/'report.json',audit);c=close(OUT,'Independent complete platform/source/artifact/raw audit');print(json.dumps({'audit':c,'closedRoots':closed}))
