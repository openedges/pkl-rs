from pathlib import Path
import subprocess,json,time,hashlib
root=Path.cwd();out=root/'target/m2/stage39-platforms-command-02'
cmd=['python3','tools/m1_platforms.py','--output','target/m2/stage39-platforms-final-02','--verify-contract']
def enc(d):return (json.dumps(d,indent=2,sort_keys=True)+'\n').encode()
(out/'started.json').write_bytes(enc({'command':cmd,'cwd':str(root),'started_unix_ns':time.time_ns()}))
t=time.time()
with (out/'stdout.bin').open('wb') as stdout,(out/'stderr.bin').open('wb') as stderr:
 p=subprocess.run(cmd,cwd=root,stdout=stdout,stderr=stderr)
report={'command':cmd,'cwd':str(root),'exit_code':p.returncode,'elapsed_seconds':time.time()-t}
for ch in ['stdout','stderr']:report[ch+'_sha256']=hashlib.sha256((out/(ch+'.bin')).read_bytes()).hexdigest()
(out/'report.json').write_bytes(enc(report));print(json.dumps(report),flush=True)
raise SystemExit(p.returncode)
