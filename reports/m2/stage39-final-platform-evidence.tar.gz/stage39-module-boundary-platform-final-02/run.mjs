// Independent four accepted-source dependency observations; never compatibility passes.
import { createRequire } from 'node:module';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import { resolve, dirname, basename, sep, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { evaluateModuleFixtures } from '../../../tools/platform/module-eval-session.mjs';
const script=fileURLToPath(import.meta.url),root=resolve(dirname(script),'../../..');
if(process.argv.length!==5)throw Error('usage: run.mjs OUTPUT WASM_DIR NAPI_BINARY');
const [out,wasm,addon]=process.argv.slice(2).map(p=>resolve(p));
const require=createRequire(resolve(root,'tools/platform/package.json'));
const {chromium}=require('playwright');
const hash=b=>createHash('sha256').update(b).digest('hex'),json=x=>JSON.stringify(x,null,2)+'\n';
const selection=[['stage39-frontend-boundary-oracle-01',['stage39-boundary-valid-new-amendment','stage39-boundary-doc-comment-bridge']],
 ['stage39-doc-semicolon-oracle-01',['stage39-doc-semicolon-before-member','stage39-doc-semicolon-between-docs']]];
const hashes={},fixtures=[],expected=new Map();
async function record(p){hashes[p]=hash(await readFile(p));}
async function tree(p){for(const e of await readdir(p,{withFileTypes:true})){const q=resolve(p,e.name);if(e.isDirectory())await tree(q);else if(e.isFile())await record(q);else throw Error('unexpected artifact entry');}}
for(const [name,ids] of selection){
 const origin=resolve(root,'target/m2',name),reportPath=resolve(origin,'report.json'),closurePath=resolve(origin,'closure.json');
 const report=JSON.parse(await readFile(reportPath)),closure=JSON.parse(await readFile(closurePath)),inventoryPath=resolve(origin,'inventory.json');
 if(closure.status!=='closed'||closure.reportSha256!==hash(await readFile(reportPath))||closure.inventorySha256!==hash(await readFile(inventoryPath)))throw Error('origin closure differs');
 const inventory=JSON.parse(await readFile(inventoryPath));
 for(const entry of inventory.files){const path=resolve(origin,entry.path);if(!path.startsWith(origin+sep)||hash(await readFile(path))!==entry.sha256)throw Error('origin payload differs');await record(path);}
 await record(closurePath);await record(inventoryPath);
 const profilePath=report.oracleProfilePath,profile=JSON.parse(await readFile(profilePath));
 if(hash(await readFile(profilePath))!==report.oracleProfileSha256)throw Error('oracle profile differs');await record(profilePath);
 for(const id of ids){
  const observations=report.records.filter(x=>x.id===id).sort((a,b)=>a.repeat-b.repeat);
  if(observations.length!==2||observations[0].repeat!==0||observations[1].repeat!==1)throw Error('missing Java repeats');
  const first=observations[0],sourcePath=resolve(first.cwd,first.source),source=await readFile(sourcePath);
  if(hash(source)!==first.sourceSha256||report.phases.find(x=>x.id===id)?.outcome!=='parsed')throw Error('expected actual parsed original source');
  const sourceText=new TextDecoder('utf-8',{fatal:true}).decode(source);if(!Buffer.from(sourceText).equals(source))throw Error('source UTF8 differs');
  const args=first.command.slice(profile.command.length);
  if(args[0]!=='eval'||args.at(-1)!==first.source||args.includes('--test-mode'))throw Error('original control argv differs');
  fixtures.push({id,sourceText,sourceSha256:first.sourceSha256,uri:first.sourceUri,moduleName:basename(first.source,'.pkl'),arguments:args});
  for(const observation of observations){
   if(observation.sourceSha256!==first.sourceSha256||observation.sourceUri!==first.sourceUri)throw Error('source repeat differs');
   const caseRoot=resolve(origin,'cases',basename(first.source,'.pkl'),String(observation.repeat));
   const value={exitCode:observation.result.exit_code};
   for(const channel of ['stdout','stderr']){const p=resolve(caseRoot,channel+'.bin');value[channel]=await readFile(p);if(hash(value[channel])!==observation.result.sha256[channel])throw Error('Java bytes differ');}
   if(value.exitCode!==0||value.stderr.length||!value.stdout.length||observation.result.timed_out||Object.keys(observation.result.files).length||Object.keys(observation.result.workspace_changes).length)throw Error('control is not actual Java output success');
   expected.set(id+':'+observation.repeat,value);
  }
 }
}
const manifestPath=resolve(root,'tools/platform/package.json'),lockPath=resolve(root,'tools/platform/package-lock.json');
const manifest=JSON.parse(await readFile(manifestPath)),lock=JSON.parse(await readFile(lockPath));
const pin=manifest.devDependencies.playwright,playwright=require('playwright/package.json').version,playwrightCore=require('playwright-core/package.json').version;
if(playwright!==pin||playwrightCore!==pin||lock.packages['node_modules/playwright'].version!==pin||lock.packages['node_modules/playwright-core'].version!==pin)throw Error('browser tool pin differs');
await mkdir(out,{recursive:false});
for(const p of [script,resolve(root,'tools/platform/module-eval-session.mjs'),manifestPath,lockPath,addon])await record(p);await tree(wasm);
await writeFile(resolve(out,'fixtures.json'),json(fixtures));await writeFile(resolve(out,'run.mjs'),await readFile(script));
const report={schema:1,scope:'Four exact Java parse-success/output-success sources compared to frontend-prefix API. Unsupported is a preserved output-evaluation dependency, never compatibility pass.',
 argv:process.argv,cwd:process.cwd(),node:process.version,nodeExecutable:process.execPath,nodeExecutableSha256:hash(await readFile(process.execPath)),playwright,playwrightCore,playwrightPin:pin,hashes,targets:{},infrastructureErrors:[],browserErrors:[]};
async function save(target,rows){const seen=new Set(),results=[];for(const row of rows){const key=row.id+':'+row.repeat;if(!expected.has(key)||seen.has(key))throw Error('duplicate/unexpected result');seen.add(key);const origin=expected.get(key),actual=row.result;
 const dir=resolve(out,target,row.id,String(row.repeat));await mkdir(dir,{recursive:true});const channels={};
 for(const channel of ['stdout','stderr']){await writeFile(resolve(dir,'java.'+channel+'.bin'),origin[channel]);if(actual)await writeFile(resolve(dir,channel+'.bin'),Buffer.from(actual[channel]));channels[channel]={javaSha256:hash(origin[channel]),candidateSha256:actual?hash(Buffer.from(actual[channel])):null,rawEqual:!!actual&&Buffer.from(actual[channel]).equals(origin[channel])};}
 const prefixBoundaryCorrect=!!actual&&actual.disposition==='unsupported'&&actual.phase==='module-output'&&actual.exitCode===2&&actual.stdout.length===0&&actual.reason==='module-output-evaluation';
 const result={id:row.id,repeat:row.repeat,status:!actual?'acquisition-failed':actual.disposition==='unsupported'?'unsupported':'boundary-violation',rawMatch:!!actual&&actual.exitCode===origin.exitCode&&Object.values(channels).every(x=>x.rawEqual),prefixBoundaryCorrect,
 javaExitCode:origin.exitCode,candidateExitCode:actual?.exitCode??null,phase:actual?.phase??null,disposition:actual?.disposition??null,reason:actual?.reason??null,reasonPresent:actual?.reasonPresent??null,reasonKind:actual?.reasonKind??null,acquisitionError:row.acquisitionError,channels};await writeFile(resolve(dir,'result.json'),json(result));results.push(result);}
 return{complete:seen.size===expected.size,statusCounts:results.reduce((a,r)=>({...a,[r.status]:(a[r.status]??0)+1}),{}),results};}
try{report.targets.node=await save('node',evaluateModuleFixtures(require(addon),fixtures));}catch(error){report.infrastructureErrors.push({target:'node',message:error.message,stack:error.stack});}
const server=createServer(async(request,response)=>{try{const url=new URL(request.url,'http://127.0.0.1');if(url.pathname==='/'){response.writeHead(200,{'Content-Type':'text/html'});response.end('<!doctype html><title>Frontend dependency boundaries</title>');return;}
 const path=url.pathname==='/module-eval-session.mjs'?resolve(root,'tools/platform/module-eval-session.mjs'):resolve(wasm,'.'+decodeURIComponent(url.pathname));if(url.pathname!=='/module-eval-session.mjs'&&!path.startsWith(wasm+sep))throw Error('unsafe path');response.writeHead(200,{'Content-Type':extname(path)==='.wasm'?'application/wasm':'text/javascript'});response.end(await readFile(path));}catch{response.writeHead(404);response.end();}});
let browser;try{await new Promise((ok,fail)=>{server.once('error',fail);server.listen(0,'127.0.0.1',ok);});browser=await chromium.launch({headless:true});report.browser=browser.version();report.browserExecutable=chromium.executablePath();report.browserExecutableSha256=hash(await readFile(report.browserExecutable));const page=await browser.newPage();page.on('pageerror',e=>report.browserErrors.push({message:e.message,stack:e.stack}));page.on('crash',()=>report.browserErrors.push({message:'crash'}));await page.goto(`http://127.0.0.1:${server.address().port}`);const rows=await page.evaluate(async fixtures=>{const api=await import('/pkl_wasm.js');await api.default();const {evaluateModuleFixtures}=await import('/module-eval-session.mjs');return evaluateModuleFixtures(api,fixtures);},fixtures);report.targets.browser=await save('browser',rows);}catch(error){report.infrastructureErrors.push({target:'browser',message:error.message,stack:error.stack});}finally{if(browser)await browser.close();if(server.listening)await new Promise(ok=>server.close(ok));}
report.changedInputs=[];for(const [path,expectedHash]of Object.entries(hashes))if(hash(await readFile(path))!==expectedHash)report.changedInputs.push(path);
report.prefixContractPassed=!report.infrastructureErrors.length&&!report.browserErrors.length&&!report.changedInputs.length&&['node','browser'].every(t=>report.targets[t]?.complete&&report.targets[t].results.every(r=>r.prefixBoundaryCorrect));
report.compatibilityComplete=false; // Every declared source requires unimplemented output evaluation.
await writeFile(resolve(out,'execution.json'),json(report));console.log(json({prefixContractPassed:report.prefixContractPassed,compatibilityComplete:false,targets:Object.fromEntries(Object.entries(report.targets).map(([k,v])=>[k,v.statusCounts])),infrastructureErrors:report.infrastructureErrors,browserErrors:report.browserErrors}));process.exitCode=1;
