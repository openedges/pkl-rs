"""Explicit reviewed-proposal admission. Default only checks pins; --execute starts fresh capture."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,stat,subprocess,sys
O=Path(__file__).parent.resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 p=argparse.ArgumentParser();p.add_argument('--handoff-sha256',required=True);p.add_argument('--output',type=Path);p.add_argument('--execute',action='store_true');a=p.parse_args();require(sha(O/'handoff.json')==a.handoff_sha256,'explicit reviewed handoff pin');handoff=json.loads((O/'handoff.json').read_bytes())
 for rel,row in handoff['sourceFiles'].items():
  q=O/rel;require(stat.S_ISREG(q.lstat().st_mode)and sha(q)==row['sha256'],'frozen tool source pin: '+rel)
 config=json.loads((O/'canonical-artifacts.json').read_bytes())
 for path,row in config['files'].items():require(sha(Path(path))==row['sha256'],'canonical artifact/tool pin: '+path)
 if not a.execute:print(json.dumps({'preflightPins':True,'actualPortableEvaluations':0}));return
 require(a.output is not None and not a.output.exists(),'fresh actual output required');record=Path(str(a.output)+'.launch');require(not record.exists(),'fresh process record root');record.mkdir(parents=True)
 cmd=[config['node'],str(O/'compare-admission-policy.mjs'),str(a.output.resolve()),config['wasm'],config['addon'],config['fixtures'],config['package']];row={'command':cmd,'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'handoffSha256':a.handoff_sha256,'sourceBefore':{rel:sha(O/rel)for rel in handoff['sourceFiles']},'environment':{'PYTHONDONTWRITEBYTECODE':'1'}}
 with(record/'stdout.bin').open('wb')as out,(record/'stderr.bin').open('wb')as err:
  child=subprocess.Popen(cmd,cwd=O,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=child.pid;(record/'launch.json').write_text(json.dumps(row,indent=2)+'\n');row['exitCode']=child.wait()
 row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceAfter={rel:sha(O/rel)for rel in handoff['sourceFiles']},stdoutSha256=sha(record/'stdout.bin'),stderrSha256=sha(record/'stderr.bin'),liveHandles=[]);(record/'terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row,indent=2));return row['exitCode']
if __name__=='__main__':raise SystemExit(main())
