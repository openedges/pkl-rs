# Module/query arena 읽기 전용 검토

이 기록은 변경 중인 Stage49 소스의 제한된 관찰이며 candidate 동결, 테스트 실행 또는 Java 호환 통과 판정이 아니다. exact 입력 7개는 inputs-first.json / inputs-after.json으로 구분한다. 이전 초기 읽기는 이 해시 기록보다 앞서므로 그 구간 전체가 동결이었다고 주장하지 않는다.

- loaded module의 compile_loaded_module은 새 CodeArena를 만들고 receiver 및 initializer 환경에 code_owner를 지정한다. receiver/closure/type 환경은 코드 owner를 trace하고, resolved declaration/class/alias/static executable 캐시는 해당 arena owner의 조건부 자식이 된다. 따라서 이전 영구 root 경로가 수정되는 방향을 확인했다.
- 남은 저장 공간 경로: query_lifecycle.rs CodeArena::retire는 non-tail range의 내용만 비우며 각 vector의 end와 일치할 때만 truncate한다. uncached module을 반복해서 덮어쓰면 새 retained module이 이전 retired range 뒤에 있어 blocks/metadata/objects/units/type_recipes의 빈 슬롯이 누적된다. 새 overwritten_uncached_modules_release_class_alias_and_source_code_graphs 테스트는 내용 합계와 source 존재 개수를 보지만 backing vector 길이를 보지 않는다. 이는 기존 receiver/source가 살아 있다는 주장이 아니라 실제 Program 저장 공간의 선형 누적 경로다. 원래 인덱스의 안정성을 보존하는 arena 분리/재사용 또는 안전한 간접화가 필요하다.
- compile query failure는 append_guarded의 checkpoint rollback을 사용한다. compile loaded module failure도 ArenaCheckpoint rollback을 사용한다. post-GC retired metadata는 source Arc를 제거하고 RuntimeError frame의 독립 Arc는 남는다. 새 cached-error 및 escaped-constraint 회귀의 의도는 확인했으나 실행하지 않았다.
- SourceSession retain_active_query_text는 이미 수정되어 있다. 현재 경로는 successful start/reenter 후 active call 최대 index만 남기며 이전 diagnostic은 다음 admission까지 유지한다. 새 private storage test는 ordinary failure 반복 및 suspended-parent/child failure 문자열 수를 확인한다. 이 테스트 역시 실행하지 않았다. 이전 stale 지적 정정은 별도 sealed addendum에 보존한다.

실제 C 실행 검증은 없음. A의 freeze 및 실제 test capture가 오면 그 별도 입력에 대해서만 추가 검토한다.
