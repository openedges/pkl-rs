# Stage49 코드 arena 저장 공간 회수 후속 계획

상태: 구현 전 소스 설계. production/Git 변경, 새 실행 또는 호환 통과 판정은 없다. build04 진행 중 소스를 읽지 않고 고정 build03만 근거로 삼았다.

## 기준과 확인된 문제

- 고정 자료: `target/m2/stage49-modulekey-build03`, `build.json` SHA `09a1a98411606ce3a9d36e41c6bc23e6c5d930f97875daaf0fcd608cdae03b04`, source226 map SHA `08a2a3ee06d973368a86c728ebf961d165b8e4465fbf5d9356045d6d92a366ac`.
- 기존 `module-arena-tests-04.log`의 12회 uncached 반복에서 blocks176→264, units4→26, blocks capacity256→512다. heap/live source/code payload plateau를 전체 저장 공간의 상한 증거로 사용할 수 없다.
- `vm/query_lifecycle.rs:32`는 non-tail range에 기본값을 남기고 끝과 일치할 때만 truncate한다. `:69`의 `initial_members.clear()`와 `import_order.clear()`는 내부 Vec capacity도 남긴다. source Arc 제거만으로 이 두 문제는 끝나지 않는다.

## 권고: 논리 주소를 유지하는 segment 저장소

물리 슬롯의 숫자를 재사용하는 free-list보다 **기존 논리 ID는 유지하고 resident segment 자체를 제거하는 방법**을 먼저 구현한다. 살아 있는 값의 주소를 다시 쓰지 않아 변경 범위를 줄인다. dense Vec 전체를 주기적으로 compact하거나 새 compile 결과를 빈 hole로 relocate하는 방식은 선택하지 않는다.

1. blocks/metadata, objects, units, type_recipes를 고정 초기 영역과 동적 segment 영역으로 나눈다. 동적 영역은 `BTreeMap<virtual_start, segment>`처럼 **현재 resident segment 수만큼**의 directory를 가진다. 논리 최대 ID 크기의 page table이나 generation 이력 Vec는 두지 않는다. 블록과 metadata는 동일 주소를 원자적으로 할당한다.
2. 각 namespace의 `next_id`는 단조 증가하는 논리 주소다. segment는 해당 주소 range와 실제 Vec/boxed-slice만 소유한다. retire하면 directory entry와 payload를 모두 drop한다. 새 segment의 물리 메모리는 allocator가 재사용해도 논리 주소는 재사용하지 않는다. 누적 이력은 고정 크기 counter만 남고, 디렉터리/outer 슬롯은 남지 않는다.
3. 기존 코드 인덱스를 원칙적으로 유지한다. `Member.code`, Frame.block, ImportSpec.unit, TypeRecipe.unit/recipe, Class template, Alias ID, `(block, pc)` executable site와 metadata 내부 instruction offset은 relocation하지 않는다. ID overflow는 기존 checked limit 경로와 동급의 명시적 오류로 처리하고 wrap하지 않는다. `UnitId(u32)` 한도는 별도 그대로 존재하며 무한 수명 지원을 주장하지 않는다.
4. `CodeArena`는 owner와 segment ID 집합을 보유한다. **owner 하나에 segment 여러 개**가 가능해야 한다. `uri_resolution.rs:499–545`는 clause 준비 뒤 full body를 다시 compile하여 동일 owner에 새 range를 붙인다. 원래 UnitId는 처음 segment에 그대로 있고 그 unit의 본문 정보만 commit 때 교체된다. 새 body segment만 추적하거나 초기 segment를 먼저 버리면 안 된다.
5. 현재 heap tracing/owner 생존 판정을 유지한다. owner가 죽은 뒤 static executable/declaration/class/alias cache와 constraint origin을 제거하고 그 owner의 segment 전부를 drop한다. receiver/closure/class/alias/type constraint/active·suspended frame이 owner를 붙잡고 있으면 하나도 retire하지 않는다. 다른 owner가 해당 code를 사용할 때는 현재처럼 환경의 code_owner edge를 보존한다.
6. 임시 public operation entry도 별도 작은 segment로 등록한다. `public_operation_entries`와 active/suspended block 판정을 유지하여 완료한 `LoadPrimary/EvaluateQuery` code 및 그 Arc source를 drop한다. raw hand-authored Program 초기 blocks와 owner 없는 고정 bootstrap 코드는 기존 의미대로 persistent 영역에 둔다.

예상 비용: 동적 lookup에 segment 검색이 추가된다. 고정 prefix는 O(1) lookup을 유지할 수 있다. 성능 개선을 선행 주장하지 않고 같은 workload의 시간/메모리를 후속 측정한다.

## 최소 API/트랜잭션 변경

| 현재 결합 지점 | 필요한 변경 |
| --- | --- |
| `vm.rs:808` Program Vec fields; `:6125` Compiler.block의 len→push | `alloc_block(code, metadata) -> id`, `alloc_object`, `alloc_unit`, `alloc_recipe`를 먼저 만들고, ID 산출에 resident `len()`을 쓰지 않는다. |
| `vm.rs:5472–5483` metadata 정렬/UnitId 산출; `:5975`, `:6055`, `:7469` | block/metadata 동시 할당 및 명시 `next_id`/returned ID 사용. `Program::new(raw_blocks)`와 개발 adapter raw append 경로도 빠짐없이 이전한다. |
| `vm.rs:1203,2434,4700` `id >= blocks.len()` 유효성 검사 | hole과 높은 virtual ID를 구별하는 `get(id)`/`contains(id)` 검사. retire된 ID는 이전 code로 alias하지 않고 기존 invalid/stale 경계로 거절한다. |
| `[checkpoint.blocks..]`, range slice, `iter().enumerate()` | 새 transaction의 appended block 순회와 `iter_with_ids()`로 구분한다. resident iteration의 순번을 논리 ID로 사용하지 않는다. 전역 `0..next_id` 순회도 금지한다. |
| `uri_resolution.rs:307,547,651` 전체 block 수정 | resident block만 논리 순서로 순회한다. URI operand patch 순서 및 matching unit/span 조건은 유지한다. 필요한 segment만 COW 수정한다. |
| `stdlib_modules.rs` 직접 block/object/unit 삽입, public operation append | 같은 allocation API를 사용한다. implicit stdlib의 영구 수명과 authored module 수명을 합치지 않는다. |
| `modules.rs:1175–1208` ArenaCheckpoint | namespace counter + 미공개 segment 집합 + 새 alias/constraint IDs + replacement unit journal을 checkpoint로 둔다. 오류 시 해당 transaction만 drop/복원한다. |

compiler는 미공개 mutable transaction Vec에 append하고 성공 시 segment를 commit한다. 크기를 미리 계산하려고 Host preflight 전에 compile하거나 URI/key/cache getter를 먼저 호출하지 않는다. `finish_module_build`의 replacement Unit은 성공 commit에만 교체한다. 실패 rollback에서는 이미 수행된 Host 효과를 재실행하거나 취소하지 않는다.

기존 `Arc<Program>` snapshot 격리를 보존한다. segment가 공유되면 수정되는 segment만 COW하고, 읽기 전용 snapshot이 참조하는 payload는 그 snapshot 수명 동안 합법적으로 남는다. 이를 VM 누수와 혼동하지 않는다. rollback된 **미공개** ID counter는 현재 checkpoint 계약처럼 되돌릴 수 있으나 한번 commit 후 retire한 주소는 재사용하지 않는다.

별도 임시 개선으로 `clear()` 대신 `mem::take()`하여 retired unit의 두 Vec capacity를 먼저 버릴 수 있다. 그러나 outer 슬롯 누적은 그대로이므로 이 변경만으로 완료 처리하지 않는다. segment 방식은 unit 전체를 drop하여 nested capacity/Arc를 함께 해제한다.

## generation과 relocation 의무

권고안은 virtual ID를 재사용하지 않으므로 새 generation/전체 relocation을 요구하지 않는다. 기존 heap ObjectId/ExecutableOwnerId generation 검사는 계속 필요하다. 물리 page/slot 번호를 기존 논리 ID로 다시 노출하는 최적화를 추가한다면 이 전제가 깨진다. 그 경우 block/template/unit/recipe/alias/site cache 등 **모든** 외부 참조에 generation을 전파해야 하며 부분 generation 검사는 허용하지 않는다.

반대로 dense Vec compact/compile-tail relocation을 택하면 Instructions, recursive TypeCheck, Member, ModuleUnit, TypeRecipe, metadata, alias definition, constraint origin, active/suspended Frame, heap class/closure/member environments 및 executable/import-site cache key까지 모든 참조를 옮겨야 한다. 현 구조보다 검증 범위가 크고 live class/closure의 identity를 바꿀 위험이 있어 이번 최소안에서 제외한다.

## 필수 회귀와 완료 기준

1. 같은 URI의 uncached module에 class, generic/type alias, annotation, lazy member·constraint와 **import clause**를 넣어 shell→full-body 두 segment 경로까지 반복한다. heap live뿐 아니라 resident segments/slots, outer 및 nested capacity/보관 source bytes가 warmup 이후 plateau인지 확인한다. raw success/error/Host request 순서는 이전과 같아야 한다.
2. 첫 module의 class/alias/closure/constraint를 외부 root로 보관하고 같은 URI를 새 내용으로 여러 번 덮어쓴다. GC 뒤 old/new 값·class identity·lazy forcing과 import site cache가 각각 올바른지 검사한다. 마지막 root를 버리면 old handles가 실제 stale되고 해당 owner의 모든 segment가 없어져야 한다. scalar-only module로 대체하지 않는다.
3. parent query를 Host suspension에 둔 채 여러 nested query/module을 생성·회수한다. parent의 local/constraint/code가 유지되고 callback 복귀/late token rejection/cancel/timeout/close0이 기존 계약과 같아야 한다. old cached module failure의 원문 source/frame Arc도 다른 allocation 뒤 살아 있어야 한다.
4. 부분 compile 실패를 block/object/recipe/alias allocation 뒤 유발한다. rollback 전후 live segment/address/cache/원래 Unit과 기존 escaping 값이 동일하고 stale 논리 ID를 이후 allocation이 가로채지 않음을 검사한다. 원래 256KiB stress/depth/실행 budget을 유지한다.
5. 동일한 최대 동시 live graph로 반복 횟수 N→10N을 늘려 요청·raw 값은 같고 저장소 계측값이 선형 증가하지 않는지 본다. 단조 ID 숫자가 커지는 것은 허용하지만 그 숫자 크기의 배열 할당은 금지한다. 실제 allocator/RSS는 별도 계측으로 보완하며 payload 합계만 전체 메모리 증거로 세지 않는다.
6. 공유 primitive 변경이므로 required Rust5, pinned Java differential/native 원문, 실제 Node/Chromium 및 기존 raw failures를 새 source/artifact에 결합한다. standalone 내부 테스트를 Java/전체 M2 완료로 확대하지 않는다.

## 고정 소스 해시

아래 경로는 모두 위 build03의 `sources/` 기준이다. production 파일은 수정하지 않았다.

| 소스 | SHA-256 |
| --- | --- |
| `crates/pkl-runtime/src/vm.rs` | `1bc19c67554328a2db1de2a16700d48f23c10d0d2236c70252e7428ebf70399e` |
| `crates/pkl-runtime/src/vm/query_lifecycle.rs` | `1c7eb7ff7d7f1421a050f0c39a17597076bb95c1c84a1ee7a6d6a29392c2cf9d` |
| `crates/pkl-runtime/src/vm/modules.rs` | `272c4b963ce852bcf61eb4f6a8ea74f86aeca17f298efd1c44aca0569aec23c3` |
| `crates/pkl-runtime/src/vm/uri_resolution.rs` | `19f5f620b0506a6f1937e02a24322d0f361efe524495a17c967e7f6cd3d0d992` |
| `crates/pkl-runtime/src/vm/session_expressions.rs` | `5d3a689761b62301ab4539d9f3484a766ef131e72cdbb5cb0e31d91459ffe50f` |
| `crates/pkl-runtime/src/vm/type_resolution.rs` | `94f89da43713e0a5abc19b59950b26659d776e4f48779f0dc47b491bf4761cd7` |
| `crates/pkl-runtime/src/heap.rs` | `29e085eba2bf6d249a3a01a73f12db56fcaedf3c214f28b9d6cbb896ecc1332a` |
