# Stage49 공개 ModuleSource/query 1차 독립 검토

읽기 전용 소스 검토다. 새 Rust·Java·Node·browser 평가를 실행하지 않았다. A가 생산 코드를 수정 중이므로 before/after SHA와 drift를 기록하고 전체 freeze·최신 native 호환 통과를 주장하지 않는다. 이번 기록은 원본 코드를 복사하지 않고 명시 파일 SHA와 readonly diff만 보존한다.

## 구체적 finding

1. **factory Synthetic과 내부 synthetic의 혼동.** selected_module_key는 contents가 있는 primary에서 key.kind!=Synthetic일 때만 SuppliedText wrapper를 만든다. Java ModuleResolver:48–55/63–65는 정확한 repl:text 내부 특례 밖에서 underlying key 종류와 관계없이 CachedModuleKey로 감싼다. custom factory가 Synthetic을 반환해도 URI+contents는 wrapper의 cached=true·resolve-security 우회·wrapper 기본 getter semantics를 가져야 한다. 외부 Synthetic의 isCached를 종류만으로 false라고 고정하는 것도 ModuleKeys.synthetic(...,isCached=true)와 구분해야 한다. root에 전달했다. B 확인상 Java01–05에는 factory Synthetic 실제 관찰이 없고 새06은 별도 취득 예정이므로 현재 finding은 소스 근거다.

2. **wrapper hasFragmentPaths의 delegate 누수.** start_uri_resolution은 wrapper delegate_key를 Capabilities/HasElement로 운반한다. 이는 실제 delegate의 local/hierarchical/hasElement에 필요하다. 그러나 resolved_capabilities가 delegate.fragment_paths를 그대로 candidate 계산에 넘기면 잘못이다. CachedModuleKey:188–212는 hasFragmentPaths를 override하지 않아 ReaderBase 기본 false를 사용한다. wrapper가 delegate.fragment_paths=true를 상속하면 안 된다. wrapper와 delegate 역할을 분리해야 한다. 기존 public wrapper test는 Capabilities에서 거부하여 성공 후 true 경계를 검사하지 않는다. B Java04의 module-source-valid-fragment-key는 inferred name의 wrapper false 대비를 실제 관찰했지만 triple/hasElement control은 없으므로 이를 triple 호환 결과로 확대하지 않는다.

3. **fresh query executable owner의 영구 heap root.** compile_public_query는 매 호출 새 query block/unit을 만든다. query import의 begin_import→current_executable→executable_root가 그 block을 VM.executable_roots에 넣고 collect는 map 전부를 강하게 trace한다. close 전 삭제 경로가 없다. 따라서 완료된 단발 query도 import-site owner/cache를 계속 보존한다. cached child를 반복 import해도 executable_live가 증가하며, uncached source reload이면 이전 query site의 old receiver까지 남을 수 있다. Java VmUtils:958–969의 fresh query SimpleRootNode와 달리 완료 query의 수명과 살아 있는 closure/callback·escape한 값의 수명을 구분하지 않는다. 이 경로는 append-only code arena의 capacity 문제와 별개의 heap root 문제다. root에 전달했으며 새 측정/실행이나 정량 성능 주장은 없다.

## 확인한 유지 경로

Primary는 import-edge를 합성하지 않고 실제 선택·cache-policy·ResolveKey·source/AST/초기화로 진행한다. 일반 query는 fresh key를 만들고 Query ResolveKey에서 보안 거부 후 parse하도록 되어 있으며 ModuleCache를 우회한다. output.text 문자열 API의 direct fast path를 별도로 유지한다. supplied wrapper는 일반 Host delegate의 key identity를 보존해 capability callback에 전달한다. 다만 위 kind 구분 및 fragment-path 의미는 보완이 필요하다.

public_primary와 suspended context의 이전 primary는 GC root에 포함되고 reentry 복귀 때 VM context와 함께 복원된다. pending module receiver도 원래 frame root에 포함된다. opaque key/ResolvedKey ID와 wrong-phase validation은 원래 typed completion 경로를 사용한다. 이 소스 관찰은 실제 public cancel/timeout·late completion·trace/error 전체 순서 검사를 대신하지 않는다.

기존 URI 기반 error alias 연결은 module_failure_id로 바뀌었다. 실제 독립 failure에서 ID를 생성하고 동일 exception의 clone·부모 cache·alias 갱신만 같은 ID로 묶는다. 이 구조는 앞서 제기한 E1/E2 URI 충돌을 피하는 방향이다. B의 봉인 Java03 report56722461...는 parent E1과 uncached child E2가 교대로 GC 이후에도 독립 유지되는 실제40 API 관찰이다. 새 Rust/native가 이 control을 통과했다는 뜻은 아니다.

## Ref +2 heap 회계는 미확정

현재 m2_references_lifecycle.rs의 원래 exact added-values 기대5/4/15와 close0·Host retry/error assertions를 읽었으며 기대를 수정하지 않았다. 새 DeclBuiltin materialization은 기존 declaring-module owner를 root하고 builtin_class는 호출당 하나의 Object를 만든다. 이 사실만으로 +2를 새로운 builtin 두 개라고 단정할 수 없다. class/annotation/ref cache baseline 이동인지 user graph retention인지 구분하려면 A의 완료 capture에서 어떤 두 tests가 실패했는지, baseline/final live 및 executable 값, exact source와 graph provenance가 필요하다. root에 자료를 요청했으며 packet이 없는 상태에서는 수치 조정을 지지하지 않는다. query root finding과도 별도 범위다.

Stage47 전체 wrapper는 root의 실제 terminal 통보 전 최종 감사하지 않는다. 이번 검토에서는 해당 실행을 poll/재실행하거나 미완료 결과를 봉인하지 않았다.
