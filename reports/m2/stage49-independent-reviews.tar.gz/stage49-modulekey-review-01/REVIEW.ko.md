# Stage49 ModuleKey 설계 독립 검토

소스 기반 설계 검토이며 새 평가·빌드·테스트를 실행하지 않았다. Stage49 live 구현의 통과 판정이 아니다. 입력 경로와 SHA는 source-bindings.json에 보존한다. 원본 소스는 복사하거나 수정하지 않았다.

## 구현 전 필수 조건

1. **정적 singleton과 일반 URI cache 분리.** Java ModuleCache.java:82–121은 StandardLibrary singleton을 두 URI map 바깥에서 반환한다. C01 vm/stdlib_modules.rs:56–65와 vm/modules.rs:189–198의 modules_original 재사용을 그대로 유지하면, 이미 암묵 base가 초기화된 evaluator의 custom pkl:base가 builtin receiver를 얻을 수 있다. append_definition:89–94의 URI-only unit dedup도 같은 문제다. 반대로 pkl:json 같은 비-singleton은 ModuleCache:133–164의 공통 URI cache를 custom key와 공유해야 한다. 모든 key kind별 cache partition은 정답이 아니다. 기본→custom/custom→기본 순서와 비-singleton 대조가 필요하다.

2. **builtin 권한은 receiver/key provenance로.** vm.rs:4563–4566의 ref_module rawURI 플래그와 6776/7208/7228의 Ref 타입 compile 특수화도 함께 이동해야 한다. Java AstBuilder:301–307,2797은 실제 StandardLibrary kind로 base/external/stdlib 동작을 결정한다. 선택만 바꾸고 이 표식을 남기면 custom pkl:ref가 builtin 동작을 얻는다. 캐시가 반환한 receiver의 실제 provenance도 보존한다.

3. **inferred-name getter를 앞당기지 않는다.** AstBuilder:1648–1654는 명시 alias에도 factory를 호출하지만 inference는 생략한다. IoUtils:299–314는 selected-key URI의 jar 분기에서 hasFragmentPaths를 호출하지 않는다. 일반 경우만 hasFragmentPaths 이후 decoded fragment 또는 opaque/path 규칙을 사용한다. 선택 completion에 모든 getter 결과를 eager 묶음으로 넣지 않는다. 모듈 자체의 inferred name도 Host가 준 ModuleSource.inferred_name을 그대로 신뢰하는 대신 AstBuilder:329–339의 selected-key 규칙과 명시 module declaration 우선순위를 반영해야 한다.

4. **synthetic primary와 synthetic query는 서로 다른 진입점.** ModuleSource.text는 ModuleResolver:48–52의 synthetic, ModuleKeys:66–71의 isCached=false지만 EvaluatorImpl:465–470에서 ModuleCache를 거친다. 따라서 lookup 생략과 doLoad write는 유지한다. ordinary expression query는 VmUtils:938–969에서 직접 resolve/source/AST/call하며 ModuleCache를 거치지 않는다. 같은 synthetic 태그로 합치지 않는다. supplied-content wrapper는 delegate의 cache policy/resolve/fragment getter를 복사하지 않는다(ModuleKeys:159–214). 같은 URI의 다른 supplied contents는 cache 우선순위도 실제 대조해야 한다.

5. **세 original/source 의미를 구분.** cache original URI는 selected ModuleKey.getUri(ModuleCache:181/191), source URI와 source IO 오류 URI는 ResolvedKey.getOriginal().getUri(VmUtils:560–577), 모듈명/AST declaration key는 selected key(AstBuilder:329–350)다. ResolvedKeyId를 운반하면서도 이 관계를 강제로 같은 문자열로 만들지 않는다. 비표준 SPI 반환의 지원 범위는 명시하고 새 관찰이 없다면 일반 호환으로 주장하지 않는다.

## 설계에서 원문과 일치하는 핵심

- ImportNode:50–63의 성공 site hit는 edge check/factory/isCached 모두 우회한다. miss는 resolved importer edge check 뒤 새 factory 선택이다.
- ModuleResolver:76–100의 normalized factory 입력과 반환 key URI는 별개다. cache에 추가 normalize를 적용하지 않는다.
- ModuleCache:133은 일반 key cache hit보다 먼저 isCached를 호출한다. 별도 bool 효과가 적절하다. false는 두 조회를 생략하나 doLoad:180–193의 성공·소스/초기화 실패 양쪽 write를 유지한다. resolve 실패는 doLoad 밖이므로 새 cache 오류를 쓰지 않는다.
- resolved hit는 original alias를 seed하지 않는다. source 성공 뒤 부분 receiver 게시, 초기화 실패 후 양 URI cache가 오류로 교체되더라도 성공한 ImportNode의 이전 receiver는 독립적으로 남는다.
- factory clause 오류와 runtime 오류의 optional location 차이, 실제 primary/query 호출을 통한 lifecycle, custom-first Host 우선순위 및 wrong-phase token 미소비 설계는 유지해야 한다.

## 검증 의무와 한계

B에 위 singleton/cache 및 inference/source identity 경계를 공유했다. 추가 Java 실행은 요청하지 않았다. 기존 212개 custom SPI와 공개 primary/query·정책84는 각 실제 phase/event/counter를 비교해야 하며 C01 440 raw API 성공을 새 계약의 통과로 승계하지 않는다. 새 phase의 취소/timeout/late token/GC, 실제 Node/Wasm 바인딩, 원본 strict gate는 별도 검증이다. Stage47 full regression은 root의 실제 terminal 통보 전 감사하지 않는다.
