// Read recorded results only. Never construct an evaluator or launch a browser.
import {readFile, writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import assert from 'node:assert/strict';
import {compareLoaderResult, compareScopedResourceReads, javaUtf8} from '../stage49-platform-integration-02/sources/tools/platform/compare-module-loader.mjs';
import {compareResourceCase} from '../stage49-platform-integration-02/sources/tools/platform/resource-session.mjs';
import {compareModulePreparationCase} from '../stage49-platform-integration-02/sources/tools/platform/module-preparation-session.mjs';
import {compareModuleKeyCase} from '../stage49-platform-integration-02/sources/tools/platform/modulekey-session.mjs';
import {auditRequests, auditObservations} from '../stage49-platform-integration-02/sources/tools/platform/compare-modulekey.mjs';
const root = '/Users/cody.ij.hwang/Projects/pkl-rs/target/m2';
const load = async path => JSON.parse(await readFile(path));
const report = {scope: 'Existing05 raw readback; no evaluator, Java, browser or test execution.', loader: [], api: []};
const unitBytes = units => {const b = Buffer.alloc(units.length * 2); units.forEach((u, i) => b.writeUInt16BE(u, i * 2)); return b;};
for (const capture of ['stage49-platform-integration-02']) {
  for (const label of ['module-loader', 'module-inheritance']) {
    const dir = resolve(root, capture, label), fixtures = await load(resolve(dir, 'fixtures.json'));
    const execution = await load(resolve(dir, 'execution.json'));
    for (const target of ['node', 'browser']) {
      const rows = await load(resolve(dir, target + '.raw.json'));
      assert.deepEqual(rows.map(r => [r.id, r.repeat]), fixtures.flatMap(f => [0, 1].map(n => [f.id, n])));
      const statuses = {}, acquisitionFailures = [], channelDifferences = [], strictTraceFailures = [];
      let payloads = 0, callbacks = 0;
      for (const [index, row] of rows.entries()) {
        const f = fixtures.find(f => f.id === row.id), saved = execution.targets[target].results[index];
        const sub = resolve(dir, target, row.id, String(row.repeat));
        assert.deepEqual(await load(resolve(sub, 'actual.json')), row);
        assert.deepEqual(await load(resolve(sub, 'expected.json')), f.expected);
        const comparisons = [];
        for (const [group, expected, actual] of [['results', f.expected.results, row.results],
          ['callbacks', f.expected.callbacks ?? [], row.callbacks.map(c => ({...c.result, path: c.path}))]]) {
          for (let i = 0; i < Math.max(expected.length, actual.length); i++) {
            assert.ok(expected[i], 'extra raw result');
            const c = compareLoaderResult(expected[i], actual[i]);
            assert.deepEqual(await readFile(resolve(sub, `${group}-${i}.java.bin`)), c.expectedBytes);
            if (c.actualBytes !== null) assert.deepEqual(await readFile(resolve(sub, `${group}-${i}.actual.bin`)), c.actualBytes);
            if (c.actualUnits !== null) assert.deepEqual(await readFile(resolve(sub, `${group}-${i}.actual.utf16be.bin`)), unitBytes(c.actualUnits));
            const expectedUnits = expected[i].javaValueUnits ?? expected[i].javaErrorUnits;
            if (expectedUnits) assert.deepEqual(await readFile(resolve(sub, `${group}-${i}.java.utf16be.bin`)), unitBytes(expectedUnits));
            c.indexMatches = group === 'results' ? actual[i]?.actionIndex === expected[i].actionIndex : actual[i]?.path === expected[i].path;
            if (!c.indexMatches && c.status === 'pass') c.status = 'mismatch';
            const {expectedBytes, actualBytes, actualUnits, ...recorded} = c;
            comparisons.push({group, index: i, ...recorded});
            if (group === 'callbacks') callbacks++; else payloads++;
            if (!c.rawMatch || !c.indexMatches) channelDifferences.push({id: row.id, repeat: row.repeat, group, index: i, channels: c.channels});
          }
        }
        assert.deepEqual(comparisons, saved.comparisons);
        const counts = row.requests.reduce((out, request) => ({...out, [request.kind]: (out[request.kind] ?? 0) + 1}), {});
        assert.deepEqual(counts, saved.requestCounts);
        const countMatch = f.expected.requestCounts == null ? null :
          [...new Set([...Object.keys(counts), ...Object.keys(f.expected.requestCounts)])].every(k => (counts[k] ?? 0) === (f.expected.requestCounts[k] ?? 0));
        assert.equal(countMatch, saved.requestCountsMatch);
        assert.equal(compareScopedResourceReads(f.expected, row.reads), saved.resourceReadCountsMatch);
        if (f.expected.logs != null) {
          const fields = ['level', 'message', 'moduleUri', 'memberName', 'sourceLines', 'startLine', 'startColumn', 'endLine', 'endColumn'];
          const logs = row.logs.map(log => fields.map(k => log[k]));
          assert.equal(JSON.stringify(logs) === JSON.stringify(f.expected.logs.map(log => fields.map(k => log[k]))), saved.logsMatch);
        }
        if (row.acquisitionError) acquisitionFailures.push({id: row.id, repeat: row.repeat, error: row.acquisitionError});
        if (countMatch === false) strictTraceFailures.push({id: row.id, repeat: row.repeat, expected: f.expected.requestCounts, actual: counts});
        statuses[saved.status] = (statuses[saved.status] ?? 0) + 1;
        assert.equal(row.architecture.terminalSlots, 0);
        assert.equal(row.architecture.ownedResultsStable, true);
        if (capture === 'stage49-platform-integration-02') {
          assert.equal(row.acquisitionError, null);
          assert.ok(comparisons.every(c => c.status === 'pass' && c.rawMatch && c.indexMatches));
          assert.notEqual(saved.logsMatch, false); assert.notEqual(saved.resourceReadCountsMatch, false);
          assert.equal(saved.status, countMatch === false ? 'mismatch' : 'pass');
        }
      }
      assert.deepEqual(statuses, execution.targets[target].statusCounts);
      report.loader.push({capture, label, target, sessions: rows.length, payloads, callbacks, statuses,
        acquisitionFailures, channelDifferences, strictTraceFailures});
    }
  }
}
for (const label of ['modulekey-public', 'modulekey-provided-primary', 'renderer', 'resource', 'module-preparation']) {
  const dir = resolve(root, 'stage49-platform-integration-02', label), execution = await load(resolve(dir, 'execution.json'));
  const fixtures = (await load(resolve(dir, 'fixtures.json'))).fixtures;
  for (const target of ['node', 'browser']) {
    const rows = await load(resolve(dir, target + '.raw.json')); assert.equal(rows.length, fixtures.length);
    let calls = 0;
    for (const [i, row] of rows.entries()) {
      const fixture = fixtures[i], saved = execution.targets[target].sessions[i];
      if (label.startsWith('modulekey-')) {
        const c = compareModuleKeyCase(fixture, row), transport = auditRequests(row), observations = auditObservations(row, fixture);
        assert.deepEqual(c.failures, saved.failures); assert.equal(c.rawApiPassed, saved.rawApiPassed);
        assert.deepEqual(transport, saved.transport); assert.deepEqual(observations, saved.observations);
        assert.ok(c.rawApiPassed && transport.passed && observations.passed); assert.equal(saved.fullLifecyclePassed, false);
      } else {
        const c = label === 'module-preparation' ? compareModulePreparationCase(fixture, row) : compareResourceCase(fixture, row);
        assert.deepEqual(c.checks, saved.checks); assert.deepEqual(c.comparisons, saved.comparisons); assert.equal(c.passed, true);
      }
      calls += row.calls.length;
    }
    report.api.push({label, target, sessions: rows.length, calls, rawRecomparisonPassed: true,
      fullJavaEventCounterParityClaimed: false});
  }
}
for (const label of ['moduleinfo', 'security-denial', 'guest-catch']) {
  const dir = resolve(root, 'stage49-platform-integration-02', label), fixtures = await load(resolve(dir, 'fixture-data.json'));
  const execution = await load(resolve(dir, 'execution.json'));
  for (const target of ['node', 'browser']) {
    const rows = await load(resolve(dir, target + '.raw.json')); assert.equal(rows.length, fixtures.length);
    let calls = 0, internalUnsupported = 0, constructors = 0;
    for (const [i, row] of rows.entries()) {
      const f = fixtures[i]; assert.deepEqual([row.id, row.repeat], [f.id, f.repeat]);
      assert.equal(row.acquisitionError, null);
      const sub = label === 'guest-catch' ? resolve(dir, target, row.group, row.id, String(row.repeat)) : resolve(dir, target, row.id, String(row.repeat));
      assert.deepEqual(await load(resolve(sub, 'actual.json')), row);
      if (f.comparisonScope === 'frontend-constructor-only') {
        assert.equal(row.constructorError.isError, true);
        for (const c of f.expected.calls) {assert.deepEqual(row.constructorError.messageUnits, c.units); assert.deepEqual(javaUtf8(c.units), Buffer.from(c.utf8));}
        constructors++; continue;
      }
      assert.equal(row.constructorError, null); assert.equal(row.architecture.terminalSlots, 0); assert.equal(row.architecture.ownedResultsStable, true);
      const expected = label === 'guest-catch' ? f.expected.calls.filter(c => f.comparisonScope === 'full-ordered-api' || c.prefix === 'outer-0' || (f.mode.endsWith('-close') && c.prefix === 'outer-1')) : f.expected;
      assert.equal(row.calls.length, expected.length);
      for (const [j, call] of row.calls.entries()) {
        const e = expected[j]; assert.equal(call.prefix, e.prefix);
        const units = unitBytes(call.units), utf8 = javaUtf8(call.units);
        assert.deepEqual(await readFile(resolve(sub, call.prefix + '.actual.utf16be.bin')), units);
        assert.deepEqual(await readFile(resolve(sub, call.prefix + '.actual.utf8.bin')), utf8);
        if (f.comparisonScope === 'java-internal-parser-boundary') {
          assert.equal(e.errorClass, 'org.pkl.core.PklBugException'); assert.equal(call.kind, 'error'); assert.equal(call.disposition, 'unsupported'); internalUnsupported++;
        } else {
          assert.equal(call.kind, e.kind);
          assert.deepEqual(units, label === 'guest-catch' ? unitBytes(e.units) : Buffer.from(e.unitHex, 'hex'));
          assert.deepEqual(utf8, label === 'guest-catch' ? Buffer.from(e.utf8) : Buffer.from(e.utf8Hex, 'hex'));
          if (call.kind === 'error') assert.equal(call.disposition, 'language-error');
        }
        if (label === 'security-denial') assert.equal(call.denialsAfter, e.denialsAfter);
        calls++;
      }
      if (label === 'guest-catch' && f.comparisonScope === 'full-ordered-api') {
        assert.deepEqual(row.counts, f.expected.counters); assert.deepEqual(row.events, f.expected.events); assert.deepEqual(row.logs, f.expected.logs);
      }
      if (label === 'guest-catch' && f.comparisonScope !== 'full-ordered-api') assert.deepEqual(row.followupRejections, [true, true]);
    }
    report.api.push({label, target, sessions: rows.length, calls, internalUnsupported, constructors,
      ordinaryRawRecomparisonPassed: true, qualification: 'Preserved constructor/terminal/internal boundaries are separate from ordinary Java equality.'});
  }
}
await writeFile(resolve(root, 'stage49-platform05-c-review-01/raw-readback-final.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({loaderGroups: report.loader.length, apiGroups: report.api.length, actualEvaluatorsStarted: 0}));
