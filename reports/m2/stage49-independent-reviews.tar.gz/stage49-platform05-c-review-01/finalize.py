from pathlib import Path
import hashlib
import json
import datetime

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, v: p.write_text(json.dumps(v, indent=2) + '\n')
binding = json.loads((OUT / 'binding-readback.json').read_text())
raw = json.loads((OUT / 'raw-readback-final.json').read_text())
assert json.loads((OUT / 'post-readback-drift.json').read_text()) == []
primitive = ROOT / 'target/m2/stage49-platform-control-02/primitives'
commands = json.loads((primitive / 'commands.json').read_text())
assert {row['name']: row['exit_code'] for row in commands} == {
    'bindgen-version': 0, 'rust-version': 0, 'native-build': 0, 'napi-build': 0,
    'wasm-build': 0, 'wasm-bindgen': 0, 'oracle-native': 1, 'platforms': 0}
command_files = []
for row in commands:
    for channel in ['stdout', 'stderr']:
        path = primitive / (row['name'] + '.' + channel + '.bin')
        command_files.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)})
oracle = json.loads((primitive / 'oracle-native/report.json').read_text())
for runtime, row in oracle['records'].items():
    assert row['exit_code'] == 0
    for channel in ['stdout', 'stderr']:
        assert sha(primitive / 'oracle-native' / (runtime + '.' + channel + '.bin')) == row[channel + '_sha256']
write(OUT / 'm1-command-readback.json', {'commands': commands, 'channelHashes': command_files,
      'nativeJavaProcesses': oracle['records'], 'qualification': 'oracle-native comparison command exit1 retains two regex mismatches. Actual Java/Rust child processes exit0; platform architecture command exit0. No commands executed by this readback.'})
write(OUT / 'initial-finalizer-failure.json', {'session': 40298, 'exitCode': 1, 'actualToolChunk': '09c910',
      'reason': 'C finalizer wrongly required every M1 command0; oracle-native correctly exited1 for two preserved regex mismatches.',
      'producerFailure': False, 'originalChanges': [], 'sourceReport': str(primitive / 'commands.json'), 'sourceReportSha256': sha(primitive / 'commands.json')})
notes = '''# Stage49 build05 실제 플랫폼 독립 readback

고정05 platform-control02/integration02에만 귀속한다. 04 원본 및 provider-only followup 감사는 별도 봉인되어 있으며 그 원본 실패를 수정하지 않았다. C는 새로운 evaluator/Java/브라우저/제품 테스트를 실행하지 않았다. Node는 저장된 raw에 frozen pure comparator를 적용했고 Python은 선언 map 경로의 바이트만 읽었다.

- build05 source226개와 platform snapshot320개, integration snapshot101개 및 NAPI/Wasm/native artifacts/sourceBindings를 재해시했다. 기록된 입력42289개 post-hash 변경0이다. exact cache 디렉터리를 탐색하거나 tree를 walk하지 않았다.
- M1 Java/Rust/Node/browser의6078개 raw stdout protocol을 모두 재구성했다. shared6078, 각Java6076이며 원래 regex2개가 실패다. 기록된 build/transform 및 platform command는0, oracle-native comparison command는1이다. 실제 Java/Rust 프로세스는0이며 stdout/stderr hash도 확인했다. architecture pass와 compatibility fail을 구분한다.
- ModuleKey public 및 provided-primary 각각212 API/target의 raw와 request/host completion observation join을 확인했다. Java2248 전체 event/counter gate와 selectedContract는 false 그대로다. 원본 fixture를 바꾸거나 요청을 제거하지 않았다.
- renderer860/Resource1008/module-preparation252 API/target의 status·양채널 UTF16/JavaUTF8·reader trace/count·ownership 및 module observable events를 다시 비교했다. ordinary 판정은 일치한다.
- loader는 target마다32pass12mismatch, inheritance6mismatch다. loader108결과+8callback, inheritance18결과+2callback/target을 모두 Java 원문 및 저장된 payload/UTF16 파일과 재비교했다. 차이는0이며 모든 strict mismatch는 full requestCounts 한 항목이다. scoped resource reads/logs/cleanup은 일치하고 provider acquisition errors는0이다. 이전04의 두 provider 실패는 이전 감사에 남는다.
- ModuleInfo168중156ordinary+12Unsupported 내부Java오류 경계, security-denial10, guest-catch178calls 및 constructor/terminal의 제한된 비교를 양 target에서 보존했다. root-switch56 등 원래 미실행 경계를 통과로 세지 않는다.
- exact browser executablePath/hash 및 helper/copy/served input tracking, 있는 driver의 HTTP200 ledger와 empty404 probe를 검증했다. browser OS PID나 네트워크 packet capture 증거는 없다.

actual root19475(M1)/78086(integration) exit0는 부모가 제공한 종료 관찰이다. C 자체 raw82169exit0/f303d9와 binding49906exit0/ea9f52는 별도다. root wrapper0은 자식 실행 완료·취득 무결성의 의미이며 strict1을 pass로 바꾸지 않는다. Rust5/native944/전체선택 회귀 또는 전체M2 완료는 이 감사 범위가 아니다. 빈 CodeArena history 슬롯 등 남은 메모리 과제도 닫히지 않았다.

초기 C finalizer40298의 모든 M1 command0 가정은 잘못이었다. 실제 oracle-native1을 보존하여 정정했고, evaluator는 재실행하지 않았다. 별도 original post-hash15554exit0에서도 변경0을 확인했다.
'''
(OUT / 'REVIEW.ko.md').write_text(notes)
write(OUT / 'actual-terminal-records.json', {'schema': 1, 'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'reviewerExecutions': [{'session': 82169, 'exitCode': 0, 'chunk': 'f303d9', 'scope': 'Stored raw only'},
                            {'session': 49906, 'exitCode': 0, 'chunk': 'ea9f52', 'scope': 'Binding readback'},
                            {'session': 40298, 'exitCode': 1, 'chunk': '09c910', 'scope': 'Overly strict C finalizer'},
                            {'session': 15554, 'exitCode': 0, 'chunk': '84521a', 'scope': 'Original post-hash'}],
      'rootReportedExecutions': [{'session': 19475, 'exitCode': 0, 'chunk': 'd9f7b0'}, {'session': 78086, 'exitCode': 0, 'chunk': '8e8ace'}],
      'newEvaluatorRunsByReviewer': 0})
write(OUT / 'report.json', {'schema': 1, 'status': 'read-only-05-audit-complete-with-strict-failures-retained',
      'candidateBuildSha256': binding['candidateBuildSha256'], 'candidateSourceCount': binding['candidateSourceCount'],
      'snapshotCounts': binding['snapshotCounts'], 'primitive': binding['primitive'],
      'm1CommandCodes': {row['name']: row['exit_code'] for row in commands},
      'loader': [{'label': row['label'], 'target': row['target'], 'statuses': row['statuses'],
                  'resultPayloads': row['payloads'], 'callbackPayloads': row['callbacks'],
                  'channelDifferences': row['channelDifferences'], 'acquisitionFailures': row['acquisitionFailures'],
                  'strictTraceFailures': len(row['strictTraceFailures'])} for row in raw['loader']],
      'apiGroups': raw['api'], 'inputFilesRehashed': binding['checkedFiles'], 'originalChanges': [],
      'strictCompatibilityPassed': False, 'newEvaluatorRuns': 0, 'productionWrites': [], 'gitWrites': 0,
      '04Failures': 'Preserved in separate stage49-platform04-c-review-01.',
      'remaining': 'FullJava events/counters, unexecuted scopes, arena slot memory and whole-M2 completion remain open.'})
print(json.dumps({'reportSha256': sha(OUT / 'report.json'), 'originalChanges': [], 'inputFiles': binding['checkedFiles']}))
