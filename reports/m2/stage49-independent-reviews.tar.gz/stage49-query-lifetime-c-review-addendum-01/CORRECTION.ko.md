# query text history 판정 정정

이전 query-lifetime-c-review-01의 query text history를 현재 미해결로 남긴 판정을 철회한다. 해당 source binding SHA에는 이미 교정이 있었다. C가 더 이전 public lifecycle 읽기의 관찰을 다시 확인하지 않고 최신 binding에 잘못 적용한 검토 오류다. 원 기록은 수정하지 않고 이 addendum으로 명시 정정한다.

현재 파일과 build02의 불변 capture는 모두 SHA4612768367dce698647e8674fa7b536567a93900a1038768c1d432af0a5e3969다. retain_active_query_text는 실제 start/reenter 성공 뒤 기존 calls 중 expression index 최대치+1만큼 paths를 truncate한 다음 새 query를 추가한다. 종료된 진단의 text는 다음 허용된 operation까지 보존하고, suspended parent의 index는 남긴다. 따라서 영구적으로 모든 완료 query 문자열을 쌓는다는 주장은 이 버전에는 해당하지 않는다.

첫 historical public review before SHA f71fded4e4760d4846beb7de009b0523ac13e0b596f36790482c05966e2c66b7의 readonly diff에는 helper가 없었다. 그 이전 버전 관찰과 현재/build02 보완을 분리한다. query review의 supplemental binding이 이미 보완된 SHA를 가리켰다는 점도 report에 기록했다.

검토는 source/API 순서 확인이며 새 unit/evaluator를 실행하지 않았다. A가 추가하는 실제 private storage plateau/errors/nested regression의 결과는 별도 검증이다. loaded uncached module의 class/alias/receiver 및 code/source 수명 finding은 이 text-storage 정정과 별개이며 미완료로 유지한다. 그 교정은 A 작업 중이다.
