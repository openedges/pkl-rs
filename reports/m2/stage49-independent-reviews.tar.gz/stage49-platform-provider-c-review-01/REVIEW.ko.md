# Stage49 portable provider 통합 독립 검토 03

고정된 provider 체크03의 명시 15파일 snapshot을 현재 검토 입력과 SHA 대조했다. actual all-Node 150/150 및 driver 4개 syntax exit0, producer before=after/changedInputs=[]를 원본 raw 로그와 report에서 확인했다. 같은 검사를 다시 실행하지 않았다. 실제 Rust binding·Java·Node/Chromium evaluator 실행 결과가 아니다. 기존 01/02의 실패 기록은 그대로 참조한다.

## 확인한 보완

빈 opaque handle은 문자열로 허용하고 비문자열은 거절한다. fixture-key:<decimal-id> ownership은 exact 비교한다. ModuleTransportError가 malformed request/잘못된 fixture ownership/non-bool default result를 표시하고 loader의 acquisition failure 경로로 전달한다. 실제 binding callback이 던진 일반 stale-token 예외는 기존 per-call thrown 경계를 유지한다.

selected/cache key 요청은 configured exact URI의 fixture factory가 default보다 먼저 처리하며, isCached completion은 별도 요청 때만 호출한다. moduleprep은 shared strict validation 뒤 descriptor fields를 기존 provider lookup projection에서만 제외한다. actual new request는 원문 metadata와 provider 선택을 기록하고 Java observable event를 추가하지 않는다. loader와 resource도 raw request를 보존하며 Java reader plan을 변경하지 않는다.

4개 driver는 module-policy-session.mjs를 복사하고 browser import 경로로 제공한다. helper/source/HTTP asset의 tracked read와 입력 변경 거부, 실제 HTTP bytes를 200 headers 전에 읽는 순서 및 headersSent 404/destroy guard를 확인했다. 명시 executablePath로 browser를 실행한다. actual browser acquisition을 실행하거나 통과로 판정하지 않았다.

## 구체적 finding 1 — custom callback에서 partial new descriptor를 수용

security-denial-session의 직접 denied Resolve 경로와 guest-catch-session의 catch:/child Resolve/LoadSource 경로는 shared validateModuleRequest를 거치지 않는다. partial key metadata를 raw에 기록하면서 legacy completion을 수행할 수 있다.

새 target-only mocked observation에서 keyId만 있는 Resolve를 shared validator가 거절하는 것을 먼저 확인했다. 동일 이벤트를 실제 helper에 주면 security와 guest 모두 acquisitionError:null이며 각각 reject-resolution/complete-resolution callback이 1회 호출된다. 실제 evaluator/Java/플랫폼 실행이 아니라 이 tooling 경계의 재현이다. 원본 observed raw/입력 및 actual wrapper exit0는 별도 보존했다. root가 모든 실제 custom resolve/source context 검증과 기존 최소 mock의 Stage48 필드 보강, 새 회귀를 맡았다. 새04 결과 전까지03의 strict transport 완료로 세지 않는다.

## 구체적 finding 2 — 일부 browser binary가 changedInputs 대상에서 빠짐

compare-resource:137, compare-module-preparation:138, compare-module-loader:174는 browser executable SHA를 직접 readFile로 계산해 tracked read hash map에 넣지 않는다. compare-renderer:141은 tracked read를 사용한다. 따라서03은 명시 경로 launch와 초기 binary SHA는 기록하지만 위3개 driver의 changedInputs=[]가 browser binary의 사후 불변까지 증명하지 않는다. loader의 Node executable도 초기 SHA만 직접 측정한다. root가 browser tracked-read 교정을 맡았다. 실제 실행 전의 source-only provenance finding이며 기존 실행 자료를 바꾸지 않는다.

## 범위와 다음 확인

root의 후속04는 본03과 별도 source SHA/실제 raw 결과로 검토해야 한다. callback 우선순위, full raw output/reader/event projection과 terminal cleanup, custom provider의 정책 결정은 여전히 공유 Rust가 소유한다. moduleloader의 Java 두 SPI count와 실제 추가 admission/key 요청의 범위 차이를 strict pass로 바꾸거나 fixture를 다시 쓰면 안 된다. 현재 검토는 새 evaluator 호환 결과 및 전체 M2 종료의 근거가 아니다.
