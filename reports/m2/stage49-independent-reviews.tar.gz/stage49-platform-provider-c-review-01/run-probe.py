from pathlib import Path
import subprocess,json,hashlib,time,os
out=Path(__file__).parent;cmd=['node',str(out/'partial-descriptor-observation.mjs')];start=time.time()
with(out/'probe.stdout.bin').open('wb')as stdout,(out/'probe.stderr.bin').open('wb')as stderr:r=subprocess.run(cmd,stdout=stdout,stderr=stderr)
(out/'probe-report.json').write_text(json.dumps({'scope':'Target-only mocked source transport observation; asserts current bypass is reproducible, not desired passing compatibility.','argv':cmd,'wrapperPid':os.getpid(),'exitCode':r.returncode,'elapsedSeconds':time.time()-start,'stdoutSha256':hashlib.sha256((out/'probe.stdout.bin').read_bytes()).hexdigest(),'stderrSha256':hashlib.sha256((out/'probe.stderr.bin').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'exitCode':r.returncode,'output':str(out)}));raise SystemExit(r.returncode)
