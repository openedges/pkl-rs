import assert from 'node:assert/strict';
import {runSecurityDenialCase} from '/Users/cody.ij.hwang/Projects/pkl-rs/tools/platform/security-denial-session.mjs';
import {runGuestCatchCase} from '/Users/cody.ij.hwang/Projects/pkl-rs/tools/platform/guest-catch-session.mjs';
import {validateModuleRequest} from '/Users/cody.ij.hwang/Projects/pkl-rs/tools/platform/module-policy-session.mjs';
function api(events, observed) {
 class Session {
  static forExpressions() {return new Session();}
  startPath(){this.queue=structuredClone(events);}
  poll(){return this.queue.shift()??{kind:'value',value:Uint16Array.of(55)};}
  rejectModuleResolution(){observed.push('reject-resolution');}
  completeModuleResolution(){observed.push('complete-resolution');}
  completeModuleSource(){observed.push('complete-source');}
  collect(){} close(){} heapSlots(){return 0;}
  drainCancelledModules(){return [];} drainCancelledReads(){return [];}
 }
 return {SourceSession:Session};
}
const resolve=uri=>({kind:'module-request',token:'token',module:{id:'1',kind:'resolve',
 originalUri:uri,importUri:uri,importerOriginalUri:'file:///main.pkl',importerResolvedUri:'file:///main.pkl',keyId:'7'}});
const fixture={id:'partial-metadata',repeat:0,group:'transport',comparisonScope:'mock-only',mode:'plain',
 source:'value=7',moduleUri:'file:///main.pkl',expressions:['value'],callbacks:[],deniedUri:'denied:/child',
 causes:[{uri:'denied:/child',errorClass:'org.pkl.core.SecurityManagerException',units:[100]}]};
const securityEvent=resolve(fixture.deniedUri),securityCallbacks=[];
assert.throws(()=>validateModuleRequest(securityEvent),/module request context/);
const security=runSecurityDenialCase(api([securityEvent],securityCallbacks),fixture);
assert.equal(security.acquisitionError,null);assert.deepEqual(securityCallbacks,['reject-resolution']);
const guestEvent=resolve('catch:/child'),guestCallbacks=[];
assert.throws(()=>validateModuleRequest(guestEvent),/module request context/);
const guest=runGuestCatchCase(api([guestEvent],guestCallbacks),fixture);
assert.equal(guest.acquisitionError,null);assert.deepEqual(guestCallbacks,['complete-resolution']);
console.log(JSON.stringify({scope:'Mock-only source validation observation, not evaluator execution.',
 security:{malformedDescriptorAccepted:security.acquisitionError===null,callbacks:securityCallbacks,raw:security.moduleRequests},
 guest:{malformedDescriptorAccepted:guest.acquisitionError===null,callbacks:guestCallbacks,raw:guest.moduleRequests}},null,2));
