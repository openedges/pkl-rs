# Build03 query/module 소유권 검토

고정 build03의 선언 source226개 및 artifact를 명시 경로로 전수 재해시했다. 새로운 Cargo/Java/Node/browser 실행은 없으며 build03 source와 현재 live 소스를 섞지 않았다.

## 고정 소스 관찰

- compile_public_query는 compile 성공 뒤 CodeArena와 executable/code owner를 만든다. query compile 오류는 append_guarded checkpoint rollback을 거친다.
- compile_loaded_module은 성공한 module ranges를 별도 CodeArena로 기록하고 receiver와 initializer에 code_owner를 붙인다. 실패 compile tail은 rollback한다.
- declaration_code_roots는 recipe/block/template/alias 범위로 캐시를 찾아 owner의 조건부 GC edge로 묶는다. module receiver/escaping closure/object/type environment는 owner를 trace하고, active+suspended VM frame도 owner를 root한다. 따라서 source/code payload 및 class/alias cycle이 VM 전체 영구 root가 되는 이전 경로를 수정한다.
- GC 이후 owner가 수거된 arena의 metadata/source/syntax/build/recipe/class/alias/declaration cache를 정리한다. RuntimeError의 source Arc는 별도로 살아 있어 retired code가 error source를 무효화하지 않는다.
- SourceSession text storage 수정은 고정 소스에 이미 포함됐다. successful admission 후 active 호출의 최대 expression index까지 보존하며 suspended parent와 마지막 diagnostic을 구분한다. 이전 C stale 지적 정정은 별도 addendum에 남긴다.

## 실제 기존 테스트 기록 범위

module-arena-tests-04.log는 9개 테스트 성공을 기록한다: 일반 query code/source/recipe 회수, 실패 query와 error source 보관, cached module error source 회수 뒤 보관, old closure import site 유지, lazy object constraint, function type constraint 실패/재성공, suspended parent reentry, 반복 uncached class/alias/module payload plateau, 공개 session text 보관. raw-result 3종은 underlying VM test에서 ToString instruction을 제거하므로 공개 expression-string API 자체의 escaping value 결과를 뜻하지 않는다.

이 debug log는 단독 development stdout/stderr 합본이며 실행 command/독립 terminal/source-before-after map은 옆에 없다. 이름·본문은 build03의 테스트와 대응하지만 log 자체만으로 동일 frozen byte interval의 실행을 독립 증명했다고 하지 않는다. required Rust5/full workspace의 별도 capture가 후속 더 강한 바인딩이다. 이전 tests03 및 diagnostic-discovery의 실제 실패는 그대로 보존된다. cached error 시험의 초기 잘못된 query-source 가정은 own-module source 보관으로 정정됐으며 Java frame 호환 통과로 세지 않는다.

## 계속 열린 메모리 경계

non-tail retire는 빈 index 슬롯을 남긴다. 기존 실제 log에서 12회 반복 시 blocks176→264, units4→26, blocks capacity256→512가 기록된다. tests04는 내용 합계/source 존재/heap live/executable live/arena 수의 plateau를 검사한다. 따라서 payload 회수 성공을 전체 저장 공간 bounded로 표현할 수 없다. 이 문제는 build.json scope에도 명시되어 있고 전체 M2 후속 의무다. vector 길이/메모리 한도 변경으로 숨기지 않았다.

별도 미검증 조합: 외부에서 보관한 module Class/TypeAlias/constraint가 동일 URI uncached replacement 후에도 실제 사용 가능한 조합은 이 9개만으로 전부 커버하지 않는다. source trace 연결은 검토했으나 Java/portable/full-M2 의미 통과로 확대하지 않는다. 현재 required5/platform 결과는 본 검토의 pass 항목이 아니다.
