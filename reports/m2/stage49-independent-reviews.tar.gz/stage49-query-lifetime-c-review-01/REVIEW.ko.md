# Stage49 query code-lifetime 독립 소스 검토

새 Rust/Java/Node/browser 실행, 생산 코드 편집 또는 Git 변경 없이 검토했다. query_lifecycle-read.rs는 첫 읽기 버전이고 before/after SHA와 WIP drift를 별도로 보존한다. A의 완료된 동결 후보에 대한 blanket signoff나 새 호환성 pass가 아니다.

## 확인한 query 소유권 구조

- compile_public_query는 순수 query compile 전후 block/object/unit/recipe/alias 범위를 기록하고 fresh executable owner를 만든다. 이 owner를 frame의 executable_owner 및 code_owner에 넣는다.
- collect는 active 및 suspended frame의 code_owner를 root한다. heap은 object 환경, member environment 및 collection cast의 code_owner를 trace하고 typecheck continuation의 environment_roots도 같은 필드를 trace한다. 따라서 활성 부모 query와 중첩 Host reentry가 서로 다른 query owner를 유지하는 구조다.
- query 범위의 declaration/executable/class/alias cache는 영구 VM root 대신 query owner의 code_roots로 연결된다. 살아 있는 closure/object/class/alias의 캡처 환경은 code_owner로 다시 query code를 유지한다. 자기 순환만 있는 unreachable owner는 이 구조에서 외부 root가 아니다.
- heap mark 뒤 owner가 실제 stale이면 해당 range를 정리한다. code/source/recipe/alias/constraint 원문을 지우고, tail일 때만 vector를 축소해 다른 module/중첩 query의 numeric index를 덮지 않는다. 실패 append rollback은 root가 별도 검토한 범위이며 이번에 새 실행하지 않았다.
- RuntimeFrame와 frontend diagnostic은 source Arc를 보유한다. 완성된 오류의 문자열/source를 보존하는 것과 query 실행 코드를 계속 보존하는 것은 별도다. cached diagnostic의 미래 lazy 평가까지 모두 검증했다고 주장하지 않는다.

위 경로는 소스 확인이다. escaped closure를 raw VM 값으로 관찰하는 내부 test는 public expression-string API의 ToString을 의도적으로 제거하는 architecture test이며 Java raw API pass를 대신하지 않는다. 현재 일반 query code-count test와 closure/cache test, public callback test가 서로 다른 범위를 다룬다. class/alias/constraint escape의 실제 추가 대조가 완료된 것으로 세지 않는다.

## 구체적인 남은 범위 1: query가 로드한 uncached module

QueryArena.finish는 query 컴파일 직후 범위만 소유한다. query 실행 중 Host에서 로드·컴파일한 module의 blocks/templates/units/recipes는 이 범위 밖이다. 이는 code의 주석에도 명시되어 있다.

그 module이 class 또는 typealias를 초기화하면 vm.rs의 class_singletons/alias_singletons에 들어가고, declaration_code_roots는 어느 query arena에도 속하지 않는 항목을 다시 영구 root로 취급한다. class/alias 환경은 원래 module receiver/scopes를 trace한다. 따라서 uncached reload가 동일 URI cache를 새 receiver로 바꾸고 query가 완료된 뒤에도 이전 module의 클래스/alias·receiver를 보존하는 경로가 있다. ModuleCache 자체가 요구하는 마지막 URI 값 보존과 다른 경로다.

단순 child text tag=N의 public heap-plateau test는 class/alias를 만들지 않아 이 경로를 검사하지 않는다. 이 scalar test가 통과해도 runtime에 추가된 old module의 code/source/unit/recipes는 어떤 QueryArena에서도 retire되지 않는다. 일반 no-import query의 code-count test 또한 이 범위를 검사하지 않는다. non-tail slot을 안전하게 비우는 것만으로 loaded module code lifetime이 닫혔다고 볼 수 없다.

권고: loaded module의 declaration/code 소유권을 receiver 및 실제 살아 있는 값/cache/site와 연결하거나 이 미완료 범위를 명시한다. uncached child에 실제 class/alias/type constraint를 포함한 반복 조회에서 이전 receiver/owner의 stale, 현재 receiver/escaping value 생존, code/source plateau를 나누어 확인해야 한다. 새 실행은 요청하거나 수행하지 않았으며 root에 source-backed finding을 전달했다.

## 구체적인 남은 범위 2: 공개 query 원문 history

SourceSession의 public start_evaluation/reenter_evaluation은 매 호출 expression을 self.paths에 복사하고 이를 삭제하지 않는다. query arena와 public_operation_entries가 비어도 과거 모든 query 문자열이 Vec<String>에 남는다. 고정 expression 개발 profile의 paths와 새 공개 lifecycle의 active/suspended/마지막 render 대기 원문을 구분해야 한다. 이는 Rust heap stats와 다른 host-memory 보존 경로이며 새 메모리 수치를 측정한 것은 아니다.

## 판정 한계

확인한 query-owned root 전달 구조는 개선 방향과 맞다. 그러나 loaded module lifetime과 query text history를 포함한 전체 evaluator 메모리 계약이 완료됐다고 판정하지 않는다. 이후 A의 좁은 동결 corrective source 및 실제 class/alias/constraint·repeated failure/Host reentry 결과를 별도 결합해야 한다. 원래 Stage47 게시·회귀 자료와 이번 Stage49 WIP는 혼합하지 않는다.
