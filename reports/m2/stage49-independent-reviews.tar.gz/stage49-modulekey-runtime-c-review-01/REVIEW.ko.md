# Stage49 ModuleKey runtime 1차 소스 검토

이 문서는 작업 중인 소스의 좁은 검토다. Rust/build/evaluator/Java를 실행하지 않았다. 전체 freeze·테스트 통과·호환성 통과를 주장하지 않는다. reviewed-changes.diff와 입력 SHA를 보존하며 최종 readback의 drift를 별도로 기록한다. Clause continuation·공개 primary/query·Ref 동적 타입 dispatch는 구현 중인 알려진 범위라 이번 blocker 목록에 중복하지 않는다.

## 남은 구체적 결함

### 같은 URI의 독립적인 실패 identity 충돌

vm.rs:1994–2006은 module_failure_key(URI 문자열)가 같은 모든 Failed cache를 현재 오류의 clone으로 교체한다. 새 uncached load는 같은 URI에서 별도 실제 실패를 만들고 기존 URI cache를 덮어쓸 수 있으므로 이 키는 더 이상 exception identity가 아니다.

소스 기반 최소 경로: P1 초기화가 U 로딩의 E1로 실패하고 outer catch가 이를 보존한다. 다른 새 site의 uncached U 로딩에서 별도 E2가 발생하여 U cache를 덮어쓴다. P1은 아직 E1을 보존한다. 이후 P1 cached E1을 catch/throw하여 stack을 갱신하면, URI U를 키로 삼는 loop가 현재 U의 E2까지 E1로 바꿀 수 있다. 메시지 E1/E2가 서로 달라도 발생한다. Java ModuleCache:186–193은 실제 Exception 객체를 map 값으로 공유하므로 E1 alias만 갱신되어야 한다.

권고: 실제 독립 실패마다 고유 identity를 할당하고 같은 예외가 부모 cache/URI alias/clone으로 전파될 때만 유지한다. URI는 표시·cache lookup용으로 남기고 error-object alias 연결에 사용하지 않는다. P1/E1 및 uncached U/E2를 만든 뒤 P1 재throw→U cached조회에서 E2 보존을 확인하는 실제 회귀가 필요하다. 아직 새 oracle/native 실행은 요청하거나 수행하지 않았다.

## 검토 중 전달했고 후속 소스에서 확인한 보완

- Runtime SelectKey 실패 진단은 normalized factory 입력이 아니라 spec.absolute_uri를 사용해야 한다. Java ModuleResolver:76은 factory 입력만 normalize하고 :84/:104의 오류 표시는 원래 moduleUri다. 현재 selected_module_key:238에서 absolute_uri 사용을 확인했다.
- default StandardLibrary Resolve는 raw import target이 아니라 selected key.uri를 사용해야 한다. 현재 modules.rs:288–296에서 해당 수정이 확인된다. factory가 다른 raw URI에 대해 StandardLibrary(pkl:json)을 반환해도 edge 신뢰도와 key resolution을 합치지 않는다.
- 새 NoLoader가 CheckImport에서 token을 소비하지 않도록 phase별 실패 검증이 필요했다. 현재 complete_module:355–374에서 ImportChecked(NoLoader) 및 factory/cache/resolve/source/preparation phase matrix 거부가 token 처리 전에 추가된 것을 확인했다. 이 확인은 소스 관찰이며 회귀 실행 결과가 아니다.
- singleton cache와 일반 URI cache는 modules_stdlib로 분리되었고, GC root/close clear/failure publication 경로에 포함된다. stdlib append_definition dedup에도 standard_library 조건이 있다. 비-singleton의 일반 URI cache 공유는 유지한다.

## completion·cache·GC 확인 범위

SelectKey 성공 completion은 request key ID와 absolute URI/stdlib kind를 검증한 뒤 continuation을 바꾼다. KeyResolved는 resolved ID와 전체 selected descriptor가 일치해야 한다. 틀린 phase/ID/해결 URI는 처리 전에 Err를 반환하여 대기 상태를 소비하지 않는 구조다. SourceProbe의 cache-policy/resolved-key completion도 decimal identity 문자열과 현재 pending request를 대조한다.

일반 key의 별도 cache-policy 효과는 original hit보다 먼저 실행된다. cached=false는 original/resolved 두 lookup을 우회하고 source 성공/실패 뒤 양 cache write는 유지한다. resolved hit는 original alias를 seed하지 않는다. 성공 site hit는 edge/factory/cache-policy를 모두 우회한다. pending receiver는 frame.module_load 및 suspended frame roots에서 추적되고 modules_stdlib receiver는 cache roots에 포함된다. 이번 검토는 실제 GC/timeout/close/호스트 재진입 회귀를 대체하지 않는다.

## JS 교차 계약

Rust default StandardLibrary key와 legacy resolved wrapper는 빈 opaque handle을 사용한다. 따라서 JS transport가 nonempty를 요구하면 실제 default cache-policy 요청을 거부한다. root에게 전달했고 root가 빈 문자열을 허용하되 비문자열을 거절하는 후속 변경과 회귀를 맡았다. fixture-key:<id> 소유권은 별도로 exact 비교해야 한다. 내 unit02의 28 mocked tests는 해당 실제 빈 default handle 경계를 포함하지 않았으며 binding pass로 주장하지 않는다.
