# Stage49 build04 플랫폼·파일 factory 검토

현재 loader helper 및 completed04/followup 기록의 읽기 전용 검토다. 새 Rust/Java/Node evaluator/Chromium 실행, 테스트, source/Git 변경은 없었다. Node는 저장된 raw를 pure comparison 함수로 재비교하는 데만 사용했다. build05 결과를 이 판정에 섞지 않았다.

## 파일 key 선택

ModuleKeyFactories.File.create:177–181은 case-insensitive file scheme에 대해 즉시 ModuleKeys.file을 반환하고, ModuleKeys.File:315→IoUtils.validateFileUri:872–875는 decoded scheme-specific part가 /로 시작하는지만 검사한다. 따라서 현재 helper의 hierarchical file selection을 source 존재/Resolve 이전에 허용하는 보완은 현재 원본 사례의 unused missing import와 supplied-main identity 문제를 올바른 단계에서 다룬다. resolve/source는 후속 실제 요청에서만 수행한다.

구체적인 넓은 범위의 차이도 남는다: /^file:\//i는 decoded-SSP 규칙 전체가 아니다. 예를 들어 file:%2Fmissing의 decoded SSP는 /missing이지만 raw regex는 거절한다. 이는 pinned source에서 도출한 경계이며 새로운 Java 실행 결과나 현재 선택 사례의 실패라고 하지 않는다. helper의 hierarchical-file subset scope를 유지해야 하며 전체 File factory 지원이라고 표시할 수 없다.

## 독립 raw readback

- M1 actual primitive raw stdout6078개를 Java/Rust/Node/browser 각각 hex decode하여 report의 모든 hash·match 판정을 재계산했다. shared6078, vsJava각6076, regex 2개는 그대로 실패다. architecture contract pass와 compatibility fail은 분리된다.
- 원래 integration01의 loader는 target마다30pass/2acquisition-failed/12mismatch, inheritance는4mismatch/2acquisition-failed다. 원본 missing payload/callback 차이도 남겨 뒀다. 두 실제 입력은 unused-missing-load 및 amends-parent-source-primary-identity이며 repeat0/1과 양 target에 존재한다.
- provider-only followup은 같은04 artifact를 사용한다. target마다 loader32pass/12mismatch, inheritance6mismatch다. 모든 결과 및 callback의 kind/rawpayload/UTF16(원래 있는 경우)/exit/index와 저장된 .bin을 보존 Java와 재비교했다. 모두 일치하며 acquisition errors는0이다. logs/scoped resource reads/terminal slots/owned result도 유지된다. 남은 모든 nonpass는 원래 full requestCounts의 정확한 비교만 실패한다. 추가 CheckImport/select/cache/getter 요청을 제거하거나 fixture를 재정의하지 않았다.
- modulekey public/provided 각각212 API, renderer860, Resource1008, module-preparation252를 양 target에서 frozen 비교 함수로 다시 확인했다. request·completion observation join도 그대로 검증한다. fullJava2248 events/counters는 여전히 false다.
- ModuleInfo168중156ordinary+12explicit Unsupported boundary, security-denial10, guest-catch178call 및 constructor/terminal의 제한된 경계를 양 target에서 원문 UTF16/JavaUTF8와 재비교했다. ModuleInfo의56 root-switch followup은 미실행이고 내부Java오류12를 호환 pass로 세지 않는다. guest-catch의 ordinary event/log/counter와 constructor/partial terminal 구분도 유지했다.

## 출처와 한계

build04 고정 source226개와 artifact를 확인하고, platform source320 및 integration/followup source각101개 snapshot을 명시 map으로 검증했다. artifact manifest/sourceBindings와 생성된 NAPI/Wasm/native bytes를 결합했다. 이후 source 수정은 옛 snapshot과 구분하여 current live 파일의 차이를 옛 acquisition drift로 오인하지 않았다.

모든 child terminal/실행 report·stdout/stderr hashes 및 기록된 input42400개를 직접 읽고 마지막에 다시 해시해 변경0을 확인했다. tree/cache enumeration은 하지 않았다. exact Chromium executablePath/hash, helper/served copy hashes와 HTTP200 ledger(존재하는 driver), empty404 probe를 확인했다. browser OS PID/네트워크 packet capture는 없다. primitive/integration 부모의 독립 OS terminal receipt는 이 입력 목록에 없으며 complete child records와 root 보고를 넘는 독립 관찰을 주장하지 않는다. followup root85203exit0는 부모 전달 근거다.

C binding harness 첫 실행은 producer 문제 없이 실패했다. renderer/resource/preparation의404 probe에 path 필드가 있다는 이유로 객체전체 동일성 가정이 실패했다. script/stderr/actual1을 보존하고 새02 script는 status404·emptybody 및 있으면 exact missing path를 검증했다. 실제 evaluator를 재실행하지 않았다.
