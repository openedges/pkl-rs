from pathlib import Path
import hashlib
import json
from collections import Counter

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
OUT = Path(__file__).resolve().parent
CONTROL = ROOT / 'target/m2/stage49-platform-control-01'
INTEGRATION = ROOT / 'target/m2/stage49-platform-integration-01'
FOLLOWUP = ROOT / 'target/m2/stage49-loader-provider-integration-01'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_bytes())
seen = {}
def checked(path, expected=None):
    path = Path(path)
    value = sha(path)
    if expected is not None:
        assert value == expected, str(path)
    if str(path) in seen:
        assert seen[str(path)] == value, str(path)
    seen[str(path)] = value
    return value

capture_maps = {}
for capture in [CONTROL, INTEGRATION, FOLLOWUP]:
    before, after = load(capture / 'sources-before.json'), load(capture / 'sources-after.json')
    assert before == after
    for rel, digest in before.items():
        checked(capture / 'sources' / rel, digest)
    capture_maps[capture.name] = before
control, integration, followup = [load(p / 'report.json') for p in [CONTROL, INTEGRATION, FOLLOWUP]]
assert all(row['complete'] for row in [control, integration, followup])
assert control['sourceChanges'] == control['runtimeChanges'] == []
assert integration['infrastructureErrors'] == integration['sourceChanges'] == integration['artifactChanges'] == integration['runtimeChanges'] == []
assert followup['infrastructureErrors'] == followup['sourceChanges'] == followup['artifactChanges'] == followup['runtimeChanges'] == []
build_path = Path(control['candidateBuild']); checked(build_path, control['candidateBuildSha256'])
build = load(build_path)
assert build['status'] == 'CLOSED' and build['exitCode'] == 0 and build['sourceStable']
before, after = load(build_path.parent / 'sources-before.json'), load(build_path.parent / 'sources-after.json')
assert before == after
checked(build_path.parent / 'sources-before.json', control['candidateSourceMapSha256'])
for rel, digest in before.items():
    checked(build_path.parent / 'sources' / rel, digest)
    assert capture_maps[CONTROL.name][rel] == digest
checked(Path(build['artifact']), build['artifactSha256'])
pins_path = CONTROL / 'artifact-pins.json'
assert integration['artifactManifest'] == followup['artifactManifest'] == str(pins_path)
checked(pins_path, integration['artifactManifestSha256']); checked(pins_path, followup['artifactManifestSha256'])
pins = load(pins_path)
for path, digest in {**pins['files'], **pins['sourceBindings']}.items():
    checked(path, digest)
primitive_path = CONTROL / 'primitives/report.json'; checked(primitive_path, control['primitiveReportSha256'])
primitive = load(primitive_path)
for rel, digest in primitive['artifacts'].items():
    checked(CONTROL / 'primitives' / rel, digest)
for rel, digest in primitive['source_hashes'].items():
    assert capture_maps[CONTROL.name][rel] == digest
    checked(CONTROL / 'primitives/sources' / rel, digest)
streams = {}
for runtime, rel in {'java': 'oracle-native/java.stdout.bin', 'rust': 'oracle-native/rust.stdout.bin',
                     'node': 'execution/node.stdout.bin', 'browser': 'execution/browser.stdout.bin'}.items():
    path = CONTROL / 'primitives' / rel; checked(path)
    lines = path.read_bytes().splitlines()
    assert len(lines) == primitive['total']
    streams[runtime] = [bytes.fromhex(line.decode('ascii')) for line in lines]
passed = Counter(); shared = 0; mismatches = []
for i, comparison in enumerate(primitive['comparisons']):
    for runtime in streams:
        assert hashlib.sha256(streams[runtime][i]).hexdigest() == comparison['sha256'][runtime]
    match = all(streams[runtime][i] == streams['rust'][i] for runtime in ['node', 'browser'])
    assert match == comparison['shared_engine_match']; shared += match
    for runtime in ['rust', 'node', 'browser']:
        same = streams[runtime][i] == streams['java'][i]
        assert same == comparison['oracle_matches'][runtime]; passed[runtime] += same
    if not all(comparison['oracle_matches'].values()): mismatches.append(comparison['id'])
assert shared == primitive['shared_engine_passed'] and dict(passed) == primitive['oracle_passed']
browser_records = []
for capture, wrapper in [(INTEGRATION, integration), (FOLLOWUP, followup)]:
    for row in wrapper['commands']:
        label = row['label']; checked(capture / (label + '.stdout.bin'), row['stdoutSha256']); checked(capture / (label + '.stderr.bin'), row['stderrSha256'])
        assert load(capture / (label + '.terminal.json')) == row
        path = capture / label / 'execution.json'; checked(path, row['executionReportSha256']); execution = load(path)
        assert execution['infrastructureErrors'] == execution['browserErrors'] == execution['changedInputs'] == []
        assert execution['browserLaunchOptions']['executablePath'] == execution['browserExecutable']
        checked(execution['browserExecutable'], execution['browserExecutableSha256'])
        input_hashes = execution['artifactAndInputHashes']
        assert input_hashes[execution['browserExecutable']] == execution['browserExecutableSha256']
        # Historical source hashes join preserved copies; later provider fixes are not retroactive drift.
        for source_path, digest in input_hashes.items():
            p = Path(source_path)
            rel = str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else None
            if rel in capture_maps[capture.name]:
                assert capture_maps[capture.name][rel] == digest
                checked(capture / 'sources' / rel, digest)
            else:
                checked(p, digest)
        for asset in execution.get('httpAssets', []):
            if asset.get('status') == 200:
                assert input_hashes[asset['file']] == asset['sha256']
                assert Path(asset['file']).stat().st_size == asset['bytes']
        if 'serverMissingAssetProbe' in execution:
            probe = execution['serverMissingAssetProbe']
            assert probe['status'] == 404 and probe['bodyHex'] == ''
            if 'path' in probe:
                assert probe['path'] == '/__pkl_verification_missing_asset__.js'
        browser_records.append({'capture': capture.name, 'label': label, 'executable': execution['browserExecutable'],
                                'sha256': execution['browserExecutableSha256'], 'version': execution['browser'],
                                'osPidRecorded': execution.get('browserOsPid') is not None})
for channel in ['stdout', 'stderr']:
    checked(CONTROL / ('primitives.' + channel + '.bin'), control['process'][channel + 'Sha256'])
assert primitive['execution']['browserLaunchOptions']['executablePath'] == primitive['execution']['browserExecutable']
checked(primitive['execution']['browserExecutable'], primitive['execution']['browserExecutableSha256'])
result = {'schema': 1, 'scope': 'Explicit frozen04 source/artifact/report/recorded-input hashes and primitive raw readback; no evaluator rerun.',
          'candidateBuildSha256': sha(build_path), 'candidateSourceCount': len(before),
          'snapshotCounts': {name: len(rows) for name, rows in capture_maps.items()},
          'primitive': {'total': primitive['total'], 'shared': shared, 'vsJava': dict(passed),
                        'preservedMismatchIds': mismatches, 'architectureContract': primitive['experiment_contract_status'],
                        'compatibilityStatus': primitive['compatibility_status']},
          'browserRecords': browser_records, 'checkedFiles': len(seen), 'checkedSha256': seen,
          'originalChanges': [], 'currentRuntimeOrSourceWrites': [],
          'qualification': 'Report/child terminal records are verified. No independent parent OS-exit receipt was supplied for primitives/integration; followup root actual85203exit0 is separately reported. Browser OS PIDs are absent; exact executablePath/hash recorded. Existing hash-bound served copies are verified; no network packet capture claim.'}
(OUT / 'binding-readback-02.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['candidateSourceCount', 'snapshotCounts', 'primitive', 'checkedFiles']}))
