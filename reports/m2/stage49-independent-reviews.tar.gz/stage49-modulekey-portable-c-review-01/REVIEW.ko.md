# ModuleKey portable 연결 소스 검토

정확한 입력은 inputs.json에 고정한다. 구현 동결 전체, 실제 Node/N-API/Wasm/Chromium evaluator 실행 또는 Java 호환 통과를 주장하지 않는다. C는 새 테스트/평가/취득을 실행하지 않았다. 기존 proposal02의 9개 driver 단위검사·2개 구문검사·mock artifact/browser preflight 종료0을 기록 그대로 확인했다. helper unit06은 별도 기존 기록이다.

구체적인 acquisition 시작 차단 결함은 이번 소스 범위에서 찾지 못했다.

- all212는 36 sessions/212 APIs, spi132는20/132, factory80은16/80을 원본 배열 순서대로 선택하고 나머지를 unexecuted로 남긴다. public은 moduleEvaluator→evaluateModuleSource(uri,null,expression), provided-primary는 forExpressions→startPath 경계로 명시된다.
- manifest/verifier/sidecar 및 pinned upstream 소스 proof가 literal SHA로 인증된다. custom key 입력은 fixture moduleProviders와 결합하며 파일 text/hash/URI는 원본 workspace 복사본과 결합한다. factory IOException 규칙은 실제 AdmissionProbe 원문 및 rule 위치로, NoLoader는 정확한 원문 URI/실제 factory attempt stream으로 제한된다.
- custom key/cache snapshot은 실제 요청이 올 때만 완성한다. selected/resolved id와 opaque handle 소유권을 확인하고, default false이면 observation의 pending token을 그대로 남겨 같은 token으로 explicit NoLoader reject를 기록한다. 잘못된 callback throw는 acquisition failure이다.
- request id/token은 중복·범위·순서를 검사한다. observation은 각 request, host call/return, API 결과 및 명시 GC/cache operation을 실제 기록과 결합한다. 자동 per-poll GC는 별도 counter다. 이것은 선택된 diagnostic stream consistency이며 Java2248 ordered events/counter equality의 대체가 아니다. raw API가 일치해도 fullLifecycle/selectedContract는 false, 실제 acquisition exit도1로 남는다.
- raw status/양 채널 UTF16+JavaUTF8를 직접 비교하며 trim/정렬/재직렬화로 차이를 숨기지 않는다. close/free 이후 owned Uint16 payload와 terminal slots0를 확인한다.
- actual addon/Wasm/glue hash와 명시 artifact/source manifest pin을 요구한다. 이 manifest와 실제 frozen compiler/build의 연결은 root의 별도 build provenance에서 확인할 의무이며 driver는 선언 입력의 바이트를 검증한다. 현재 preflight의 mock binding/browser bytes는 실행 검증이 아니다.
- exact browser executable을 해시하고 executablePath로 launch한다. served module/helper/Wasm bytes는 tracked read를 거쳐 HTTP200보다 먼저 읽고, missing asset은 empty404이며 final input rehash가 있다. Node·Playwright runtime module 및 package/lock도 추적된다. browser OS PID는 미기록으로 명시된다.

선택 제외 및 범위: 전체Java2248 event/counters, 실제 File secure-path callback parity, 새로운 일반 provider/policy 호환성은 완료되지 않았다. 현재 9개 authenticated Host profile의 설정 테이블 범위만 검토했다. 실제 evaluator/platform 결과는 추후 별도 raw acquisition으로 판정한다.
