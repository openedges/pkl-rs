"""Archive immutable publication metadata and emit a target-only handoff."""
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
COMMIT = "01971d0c0a231132bcb30a7dae6ac244b7fed953"
sha = lambda data: hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")

archive_report = json.loads((OUT / "archive-report.json").read_bytes())
process = json.loads((OUT / "archive-process.json").read_bytes())
binding = json.loads((OUT / "source-binding.json").read_bytes())
proposal = json.loads((OUT / "proposal.json").read_bytes())
assert process["exit_code"] == 0 and process["inputs_stable"]
assert archive_report["source_verified_before_gather_after_gather_after_archiving"]
raw_commit = (OUT / "commit.raw").read_bytes()
assert hashlib.sha1(b"commit " + str(len(raw_commit)).encode() + b"\0" + raw_commit).hexdigest() == COMMIT
metadata_names = ["collect.py", "package.py", "run_archive.py", "closeout.py", "selection.json", "proposal.json",
                  "exclusions.json", "source-binding.json", "original-source-map.json", "combined-source-map.json",
                  "committed-change-map.json", "commit.raw", "gather-report.json", "archive-report.json",
                  "archive-process.json", "archive.stdout.bin", "archive.stderr.bin"]
source = OUT / "closeout-source"
assert source.is_dir()
metadata = []
for name in metadata_names:
    data = (OUT / name).read_bytes()
    assert (source / name).read_bytes() == data
    metadata.append({"path": name, "bytes": len(data), "sha256": sha(data)})
spec = importlib.util.spec_from_file_location("classpath_publication_evidence", ROOT / "tools/evidence.py")
evidence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evidence)
destination = OUT / "archives/classpath-integration-closeout.tar.gz"
assert destination.is_file()
evidence.verify(destination)
assert destination.stat().st_size <= 48 * 1024 * 1024
for row in metadata:
    assert sha((OUT / row["path"]).read_bytes()) == row["sha256"]
archives = [*archive_report["archives"], {"group": "closeout", "path": str(destination),
            "sha256": sha(destination.read_bytes()), "compressed_bytes": destination.stat().st_size,
            "archive_payloads_excluding_evidence_inventory": len(metadata), "metadata": metadata}]
assert all(row["compressed_bytes"] <= 48 * 1024 * 1024 for row in archives)
group_metadata_bytes = sum((OUT / "gathered" / row["group"] / "CAPTURE_SELECTION.json").stat().st_size for row in archive_report["archives"])
write(OUT / "handoff.json", {
    "schema": 1, "scope": "Classpath-to-M2 integration publication preparation only. Original and combined focused success do not establish whole-corpus completion.",
    "integration_commit": COMMIT,
    "source_binding": {"path": str(OUT / "source-binding.json"), "sha256": sha((OUT / "source-binding.json").read_bytes())},
    "binding_uses_actual_commit_and_frozen_sources_not_current_readme_or_later_head": True,
    "combined_frozen_inputs_matching_commit_and_pinned_reference_blobs": 3823,
    "original_frozen_inputs": 3813, "original_historical_differences_explicit": len(binding["captures"]["original"]["historical_differences"]),
    "original_and_combined_frozen_parent_child_raw_sources_preserved": True,
    "recorded_parent_build_child_supplied_frozen_artifact_and_oracle_bindings_preserved": True,
    "focused_scope": {"case_ids": 1, "original_repetitions": 2, "combined_repetitions": 2, "remaining_selected_not_reacquired": 3663,
                      "cases": 4527, "requirements": 475, "default_selected": 3664, "ready": 3664, "unimplemented": 823, "unmapped": 40,
                      "full_gate_failures_in_focused_report": 5476, "full_selected_regression_claimed": False},
    "retained_failures": ["combined-validation-01 runtime-source unit fixture scope failure exit1, completefalse", "combined-validation-02 invalid compat.py --check orchestration exit2, completefalse"],
    "successful_continuation": "combined-validation-03 correct discover freshness, focused acquisition/report/subset exit0 and strict full gate exit1.",
    "selection": {"path": str(OUT / "selection.json"), "sha256": archive_report["selection_sha256"]},
    "selected_payloads": archive_report["source_payloads_verified"], "selected_raw_bytes": proposal["bytes"],
    "original_producer_payloads": archive_report["source_payloads_verified"] - proposal["group_counts"]["committed-files"]["payloads"],
    "derived_committed_file_snapshots": proposal["group_counts"]["committed-files"]["payloads"],
    "archives": archives, "archive_count": len(archives),
    "total_compressed_bytes": sum(row["compressed_bytes"] for row in archives),
    "largest_compressed_bytes": max(row["compressed_bytes"] for row in archives),
    "archive_payloads_excluding_evidence_inventories": archive_report["source_payloads_verified"] + len(archive_report["archives"]) + len(metadata),
    "archive_raw_payload_bytes_excluding_evidence_inventories": proposal["bytes"] + group_metadata_bytes + sum(row["bytes"] for row in metadata),
    "each_archive_has_independent_evidence_inventory_and_selection": True,
    "all_archives_below_48_mib": True,
    "all_selected_original_bytes_verified_before_and_after_gather_and_after_archiving": True,
    "symbolic_links_as_raw_target_bytes_with_original_kind_mode_metadata": 22,
    "compiled_artifact_policy": archive_report["compiled_artifacts_preserved"],
    "original_evidence_changed": False, "production_changed": False, "git_writes": False, "reports_writes": False,
    "remaining": ["Root review and reports/Git publication", "Combined full selected and sequential evaluator regression", "Original whole-language and unmapped requirements", "Generic classpath, error-frame/security controls, Wasm/N-API/product API and performance obligations"],
    "full_m2_complete": False, "hosted_ci_claimed": False, "performance_target_claimed": False,
})
print(json.dumps({"archives": len(archives), "compressed_bytes": sum(row["compressed_bytes"] for row in archives),
                  "largest_compressed_bytes": max(row["compressed_bytes"] for row in archives),
                  "handoff_sha256": sha((OUT / "handoff.json").read_bytes())}))
