"""Recheck exact producer path sets/bytes and seal the metadata-only recovery."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import stat

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")

selection_raw = (OUT / "selection.json").read_bytes()
selection = json.loads(selection_raw)
exclusions = json.loads((OUT / "exclusions.json").read_bytes())
excluded = {Path(name) for name in exclusions["exact_absolute_paths"]}
expected = {row["archive_path"]: row for row in selection["rows"]}
current = {}
def capture(path, archive_path, group):
    metadata = path.lstat()
    if stat.S_ISLNK(metadata.st_mode):
        data = os.readlink(os.fsencode(path)); kind = "symbolic-link-as-exact-target-bytes"
    else:
        assert stat.S_ISREG(metadata.st_mode)
        data = path.read_bytes(); kind = "regular-file"
    row = {"source": str(path), "archive_path": archive_path, "group": group, "kind": kind,
           "bytes": len(data), "sha256": sha(data), "original_mode": stat.S_IMODE(metadata.st_mode)}
    assert row == expected[archive_path], str(path)
    assert archive_path not in current
    current[archive_path] = row

for group, roots in selection["groups"].items():
    for source_name in roots:
        source = Path(source_name)
        assert source.is_dir() and not source.is_symlink()
        for directory, dirs, files in os.walk(source, topdown=True, followlinks=False):
            directory = Path(directory)
            assert directory not in excluded
            keep = []
            for name in sorted(dirs):
                child = directory / name
                if child in excluded:
                    continue
                if child.is_symlink():
                    capture(child, f"{group}/{source.name}/{child.relative_to(source).as_posix()}", group)
                else:
                    keep.append(name)
            dirs[:] = keep
            for name in sorted(files):
                child = directory / name
                if child not in excluded:
                    capture(child, f"{group}/{source.name}/{child.relative_to(source).as_posix()}", group)
assert current.keys() == expected.keys()
write(OUT / "integrity.json", {"schema": 1, "scope": "Post-archive exact original producer pathset and bytes recheck with the same before-descent exclusions; no tests/builds/Java.",
                              "selection_sha256": sha(selection_raw), "paths": len(current),
                              "bytes": sum(row["bytes"] for row in current.values()),
                              "pathset_changes": [], "byte_mode_kind_changes": [], "symlink_targets_followed": False,
                              "original_evidence_changed": False,
                              "metadata_recovery": "Initial closeout archive was already verified; resume_closeout.py returned0 after verifying/reusing it and obtaining byte totals from frozen proposal.json. Failed initial script/archive stay unchanged."})
names = ["closeout-failure.json", "resume_closeout.py", "handoff.json", "integrity.json", "finalize.py"]
source = OUT / "recovery-source"
assert not source.exists()
source.mkdir()
metadata = []
for name in names:
    data = (OUT / name).read_bytes()
    (source / name).write_bytes(data)
    metadata.append({"path": name, "sha256": sha(data), "bytes": len(data)})
spec = importlib.util.spec_from_file_location("classpath_recovery_evidence", ROOT / "tools/evidence.py")
evidence = importlib.util.module_from_spec(spec)
spec.loader.exec_module(evidence)
destination = OUT / "archives/classpath-integration-closeout-recovery.tar.gz"
assert not destination.exists()
evidence.create(source, destination, [])
assert destination.stat().st_size <= 48 * 1024 * 1024
prior = json.loads((OUT / "handoff.json").read_bytes())
archives = [*prior["archives"], {"group": "closeout-recovery", "path": str(destination),
             "sha256": sha(destination.read_bytes()), "compressed_bytes": destination.stat().st_size,
             "archive_payloads_excluding_evidence_inventory": len(names), "metadata": metadata}]
write(OUT / "publication-index.json", {
    "schema": 1, "scope": prior["scope"], "integration_commit": prior["integration_commit"],
    "handoff": {"path": str(OUT / "handoff.json"), "sha256": sha((OUT / "handoff.json").read_bytes())},
    "source_binding": prior["source_binding"], "selection": prior["selection"],
    "integrity": {"path": str(OUT / "integrity.json"), "sha256": sha((OUT / "integrity.json").read_bytes())},
    "archives": archives, "archive_count": len(archives),
    "selected_payloads": prior["selected_payloads"], "selected_raw_bytes": prior["selected_raw_bytes"],
    "archive_payloads_excluding_evidence_inventories": prior["archive_payloads_excluding_evidence_inventories"] + len(names),
    "archive_raw_payload_bytes_excluding_evidence_inventories": prior["archive_raw_payload_bytes_excluding_evidence_inventories"] + sum(row["bytes"] for row in metadata),
    "total_compressed_bytes": sum(row["compressed_bytes"] for row in archives),
    "largest_compressed_bytes": max(row["compressed_bytes"] for row in archives),
    "all_archives_below_48_mib": True, "original_pathset_and_bytes_changes": [],
    "publication_metadata_failure_preserved_and_recovered": True,
    "original_evidence_changed": False, "production_changed": False, "git_writes": False, "reports_writes": False,
    "full_selected_regression_claimed": False, "full_m2_complete": False,
})
print(json.dumps({"archives": len(archives), "compressed_bytes": sum(row["compressed_bytes"] for row in archives),
                  "largest_compressed_bytes": max(row["compressed_bytes"] for row in archives),
                  "publication_index_sha256": sha((OUT / "publication-index.json").read_bytes())}))
