"""Capture actual strict gate exits without treating known failures as passes."""
import json
from pathlib import Path
import subprocess
import sys
import hashlib

ROOT=Path(__file__).resolve().parents[3]
OUT=ROOT/'target/m2/gates-stage36-final-01'
OUT.mkdir(exist_ok=False)
(OUT/'gates.py').write_bytes(Path(__file__).read_bytes())
rows=[]
commands=[(name,[sys.executable,'tools/m2_language.py','--verify-'+name,'target/m2/language-stage36-final-01'])
          for name in ('report','development','subset','full')]
commands += [('persistent-'+name,[sys.executable,'tools/m2_class_lifecycle.py','--verify-'+name,
              'target/m2/class-lifecycle-stage36-final-01']) for name in ('report','contract')]
for name,command in commands:
    with (OUT/(name+'.stdout.bin')).open('wb') as stdout,(OUT/(name+'.stderr.bin')).open('wb') as stderr:
        result=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr)
    row=dict(name=name,command=command,exit_code=result.returncode)
    row.update({channel+'_sha256':hashlib.sha256((OUT/(name+'.'+channel+'.bin')).read_bytes()).hexdigest()
                for channel in ('stdout','stderr')})
    rows.append(row)
    (OUT/'report.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,result.returncode,flush=True)
