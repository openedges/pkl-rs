"""Bind the Stage36 selection to the full acquisition and replay the frozen baseline."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import m2_language as language

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

full = ROOT / 'target/m2/language-stage36-final-01'
report = json.loads((full / 'report.json').read_bytes())
assert report['source_stability'] and report['artifact_stability']
assert report['candidate']['source_binding'] == 'recorded-build'
assert json.loads((ROOT / 'target/m2/stage36-executions/language/process.json').read_bytes())['exit_code'] == 0
selection = json.loads((ROOT / 'tests/fixtures/m2/cases.json').read_bytes())['cases']
selected = [row for row in selection if row['id'].startswith('object-string-stage36-')]
assert len(selected) == 83
results = {row['id']: row for row in report['results']}
output = ROOT / 'target/m2/focused-stage36-final-01'
output.mkdir(exist_ok=False)
baseline_origin = ROOT / 'target/m2/language-stage35-final-01/artifacts/language_probe'
assert sha(baseline_origin) == '04780a951968c9d59e97c4815d585ba2c6a0a2c939846438315ba9e7ea812b26'
baseline = output / 'stage35-language-probe'
shutil.copy2(baseline_origin, baseline)
shutil.copyfile(__file__, output / 'focused.py')
rows = []
for case in selected:
    identifier = case['id']
    origin = full / 'cases' / identifier
    destination = output / 'cases' / identifier
    destination.mkdir(parents=True)
    for path in origin.iterdir():
        assert path.is_file()
        relative = str(path.relative_to(full))
        assert sha(path) == report['evidence_sha256'][relative]
        shutil.copyfile(path, destination / path.name)
    source = ROOT / case['input']
    assert source.read_bytes() == (destination / 'input.pkl').read_bytes()
    args = language.expression_arguments(source, case['expression'], case.get('power_assertions', False))
    old = language.capture([str(baseline), *args], destination, 'stage35', report['oracle']['environment'])
    java = results[identifier]['java']
    old_equal = not old['timed_out'] and old['exit_code'] == java['exit_code'] and all(
        (destination / ('stage35.' + channel + '.bin')).read_bytes()
        == (destination / ('java.' + channel + '.bin')).read_bytes()
        for channel in ['stdout', 'stderr'])
    rows.append(dict(id=identifier, status=results[identifier]['status'],
                     raw_equal=results[identifier]['status'] == 'pass', baseline_raw_equal=old_equal,
                     source_sha256=sha(source), full_origin=str(origin.relative_to(ROOT)), baseline=old))
summary = dict(scope='Focused view of the same full final acquisition, with fresh Stage35 baseline replays. This is not an independent second candidate acquisition.',
               full_report=str((full / 'report.json').relative_to(ROOT)), full_report_sha256=sha(full / 'report.json'),
               candidate_sha256=report['candidate']['sha256'], baseline_origin=str(baseline_origin.relative_to(ROOT)),
               baseline_sha256=sha(baseline), selected=len(rows), results=rows,
               raw_matches=sum(row['raw_equal'] for row in rows),
               baseline_raw_matches=sum(row['baseline_raw_equal'] for row in rows))
summary['source_stability'] = all(sha(ROOT / case['input']) == row['source_sha256']
                                  for case, row in zip(selected, rows))
summary['artifact_stability'] = (sha(baseline) == sha(baseline_origin)
                                 and sha(full / 'artifacts/language_probe') == report['candidate']['sha256'])
assert summary['source_stability'] and summary['artifact_stability']
(output / 'report.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ['selected', 'raw_matches', 'baseline_raw_matches']}))
sys.exit(0 if all(row['raw_equal'] for row in rows) else 1)
