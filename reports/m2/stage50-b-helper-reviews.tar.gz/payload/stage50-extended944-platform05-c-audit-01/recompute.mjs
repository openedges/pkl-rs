import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const root='/Users/cody.ij.hwang/Projects/pkl-rs.stage50', out=root+'/target/m2/stage50-extended944-platform05-c-audit-01';
const read=async p=>JSON.parse(await readFile(p));
const fixtureRoot=root+'/tests/fixtures/m2-modulekey-extended';
const bundle=await read(fixtureRoot+'/fixtures.json'),meta=await read(fixtureRoot+'/host-metadata.json');
const profiles=new Map(meta.profiles.map(p=>[p.id,p]));const cohorts=[];
for(const control of ['01','02']){
 const producer=root+'/target/m2/stage50-extended944-platform05-control-'+control;
 const driver=await import(pathToFileURL(producer+'/compare-modulekey-extended.mjs'));
 const helper=await import(pathToFileURL(producer+'/modulekey-extended-session.mjs'));
 const execution=await read(producer+'/actual/execution.json');const targets={};
 for(const target of ['node','browser']){
  const rows=await read(producer+'/actual/'+target+'.raw.json'), sessions=[];
  if(rows.length!==bundle.fixtures.length)throw Error('session count');
  for(let i=0;i<rows.length;i++){
   const f=bundle.fixtures[i],actual=rows[i];
   const c=driver.combineSessionComparison(f,actual,profiles.get(f.providerProfileId),helper.compareModuleKeyExtendedCase(f,actual));
   const saved=await read(producer+'/actual/'+target+'/'+i+'/comparison.json');
   if(JSON.stringify(c)!==JSON.stringify(saved))throw Error('saved comparison differs '+control+'/'+target+'/'+i);
   if(JSON.stringify(c)!==JSON.stringify(execution.targets[target].sessions[i]))throw Error('aggregate comparison differs');
   sessions.push(c);
  }
  const aggregate=driver.aggregateComparisons(sessions);
  for(const [k,v]of Object.entries(aggregate))if(JSON.stringify(v)!==JSON.stringify(execution.targets[target][k]))throw Error('aggregate gate '+k);
  targets[target]={...aggregate,sessions:rows.length,failedObservationSessions:sessions.flatMap((c,i)=>c.observationIntegrityPassed?[]:[{index:i,id:bundle.fixtures[i].id,failures:c.observations.failures}]),
    helperAcquisitionFailures:sessions.filter(c=>!c.helperAcquisitionIntegrityPassed).length,
    cleanupFailures:sessions.filter(c=>!c.cleanupPassed).length,
    classificationFailures:sessions.flatMap(c=>c.classificationFailures??[]).length};
 }
 cohorts.push({control,targets});
}
await writeFile(out+'/recomputed-gates.json',JSON.stringify({scope:'Read-only recomputation over recorded JSON using captured checker/helper source; no evaluation methods called.',cohorts},null,2)+'\n');
console.log(JSON.stringify(cohorts.map(c=>({control:c.control,targets:Object.fromEntries(Object.entries(c.targets).map(([t,v])=>[t,{rawMatches:v.rawByteMatches,acquisition:v.acquisitionIntegrityPassed,observationFailures:v.failedObservationSessions.length,cleanupFailures:v.cleanupFailures}]))}))));
