import collections,hashlib,json,pathlib,stat,datetime
ROOT=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage50'); OUT=ROOT/'target/m2/stage50-extended944-platform05-c-audit-01'; MAIN=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs'); before={}
def raw(p):
 p=pathlib.Path(p);assert stat.S_ISREG(p.lstat().st_mode),p
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest(); row={'bytes':len(b),'sha256':h}
 assert str(p) not in before or before[str(p)]==row,('changed during audit',p)
 before[str(p)]=row;return b
def load(p):return json.loads(raw(p))
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def digest(p):return hashlib.sha256(raw(p)).hexdigest()
def utf16(us):return b''.join(u.to_bytes(2,'big') for u in us)
def java8(us):return utf16(us).decode('utf-16-be','surrogatepass').encode('utf8','replace')
F=ROOT/'tests/fixtures/m2-modulekey-extended';manifest=load(F/'manifest.json');assert digest(F/'manifest.json')=='eda9449570132c0f76ebf2ea67071a94b6b3a53b29fb9a49dfb982e66ad18bb2'
for n in ['fixtures.json','host-metadata.json']:
 b=raw(F/n);assert hashlib.sha256(b).hexdigest()==manifest['files'][n]['sha256']
bundle=load(F/'fixtures.json');assert len(bundle['fixtures'])==140
history=[]; projections={}; mismatches=[]; controls={}
for number in ['01','02']:
 producer=ROOT/f'target/m2/stage50-extended944-platform05-control-{number}';actual=producer/'actual';pr=load(producer/'process-report.json');e=load(actual/'execution.json');controls[number]=e
 assert pr['complete'] and pr['exitCode']==1 and pr['inputsBefore']==pr['inputsAfter'] and pr['changedInputs']==[]
 assert not e['preflightOnly'] and e['entrypoint']=='public' and not e['infrastructureErrors'] and not e['browserErrors'] and not e['changedInputs']
 assert (e['javaApiCalls'],e['javaOrderedEvents'],e['selectedApiCallsPerTarget'],e['unexecuted'])==(944,10124,944,[])
 assert not e['fullCompatibilityPassed'] and not e['fullLifecyclePassed'] and not e['fullLifecycleGate']['passed'] and not e['selectedContractPassed']
 for p,h in pr['inputsBefore'].items():assert digest(producer/pathlib.Path(p).name)==h
 for n in ['stdout.bin','stderr.bin']:raw(producer/n)
 for phase in ['preflight','postflight']:
  p=load(actual/f'{phase}.process.json');assert p==e[phase] and p['exitCode']==0 and p['signal'] is None and p['error'] is None
  for n in ['stdout.bin','stderr.bin']:raw(actual/f'{phase}.{n}')
 targets={}
 for target in ['node','browser']:
  rows=load(actual/f'{target}.raw.json');assert len(rows)==140;totals=collections.Counter();resultProjection=[];failedObservers=[]
  for i,(f,row) in enumerate(zip(bundle['fixtures'],rows)):
   assert [row['id'],row['repeat'],row['session']]==[f['id'],f['repeat'],f['session']]
   d=actual/target/str(i);assert load(d/'actual.json')==row and load(d/'expected.json')==f['expected'] and load(d/'observations.json')==row['observations']
   comparison=load(d/'comparison.json');assert comparison==e['targets'][target]['sessions'][i]
   assert not row['constructorError'] and not row['acquisitionError'];assert row['architecture']['terminalSlots']==0 and row['architecture']['ownedResultsStable'] and row['architecture']['releasedHostKeys']
   assert comparison['cleanupPassed'] and comparison['helperAcquisitionIntegrityPassed'] and comparison['transport']['passed']
   if not comparison['observationIntegrityPassed']:failedObservers.append({'index':i,'id':f['id'],'failures':comparison['observations']['failures']})
   assert len(row['calls'])==len(f['expected']);resultProjection.extend(row['calls'])
   for call,expected in zip(row['calls'],f['expected']):
    j=call['index'];assert call['sourceProfileId']==expected['sourceProfileId']
    assert raw(d/f'{j}.source-profile.bin').decode()==call['sourceProfileId'];assert raw(d/f'{j}.status.bin').hex()==call['statusRawHex']
    assert raw(d/f'{j}.status.bin')==(call['status']+'\n').encode()
    assert (call['disposition'] is None if call['status']=='success' else call['disposition'] in ['language-error','unsupported','limit-exceeded','internal-failure'])
    matched=call['status']==expected['status'] and call['statusRawHex']==expected['statusRawHex']
    for ch in ['stdout','stderr']:
     units=call[ch+'Units'];assert all(type(u) is int and 0<=u<=65535 for u in units)
     assert raw(d/f'{j}.{ch}.utf16be.bin')==utf16(units);assert raw(d/f'{j}.{ch}.java-utf8.bin')==java8(units)
     matched=matched and units==expected[ch+'Units'] and java8(units).hex()==expected[ch+'Hex']
    totals['calls']+=1;totals['rawMatched' if matched else 'rawMismatch']+=1;totals[expected['scope']]+=1
    if matched:totals[expected['scope']+'Matched']+=1
    if expected['scope']=='ordinary' and matched and (call['status']=='success' or call['disposition']=='language-error'):totals['ordinaryCompatible']+=1
    if not matched:mismatches.append({'control':number,'target':target,'session':i,'caseId':f['id'],'callIndex':j,'scope':expected['scope'],'disposition':call['disposition'],'oracleErrorClass':expected['errorClass']})
   assert comparison['raw']['matched']==sum(c['rawMatched'] for c in comparison['cases'])
  assert totals['calls']==e['targets'][target]['actualApiCalls'];assert totals['rawMatched']==e['targets'][target]['rawByteMatches'];assert totals['ordinaryCompatible']==e['targets'][target]['intendedOrdinaryRawMatched']
  projections[number,target]=resultProjection;targets[target]={'counts':dict(totals),'failedObserverSessions':failedObservers,'rawApiPassed':e['targets'][target]['rawApiPassed'],'ordinaryCompatibilityPassed':e['targets'][target]['ordinaryCompatibilityPassed'],'acquisitionIntegrityPassed':e['targets'][target]['acquisitionIntegrityPassed'],'observationIntegrityPassed':e['targets'][target]['observationIntegrityPassed']}
 history.append({'control':number,'processReportSha256':digest(producer/'process-report.json'),'executionSha256':digest(actual/'execution.json'),'targets':targets})
assert digest(ROOT/'target/m2/stage50-extended944-platform05-control-02/actual/execution.json')=='105a6c3c03d33c8ea71db42adedf96de1a3468c41647ee4d37da4702855439f7'
for t in ['node','browser']:
 assert projections['01',t]==projections['02',t],('raw or delivered classification changed',t)
assert projections['02','node']==projections['02','browser']
e=controls['02'];assert e['acquisitionIntegrityPassed'] and e['ordinaryCompatibilityPassed'] and not e['rawApiPassed'] and e['toolIntegrityPassed']
assert e['browserLaunchOptions']=={'headless':True,'executablePath':e['browserExecutable']};assert digest(e['browserExecutable'])==e['browserExecutableSha256'];assert e['serverMissingAssetProbe']=={'status':404,'bodyHex':''}
assert e['browserOsPid'] is None and e['browserOsPidQualification']
for asset in e['httpAssets']:
 if asset['status']==200:assert digest(asset['file'])==asset['sha256'] and len(raw(asset['file']))==asset['bytes']
 else:assert asset['status']==404 and 'file' not in asset
proof=e['artifactProof'];assert proof==load(MAIN/'target/m2/stage49-platform-control-02/artifact-pins.json');assert digest(MAIN/'target/m2/stage49-platform-control-02/artifact-pins.json')=='0048fd8ef9a586288e325e5caf9fe4814ccf209161918d9a320e802efb1d033a'
for p,h in {**proof['files'],**proof['sourceBindings']}.items():assert digest(p)==h
broot=MAIN/'target/m2/stage49-modulekey-build05';build=load(broot/'build.json');bmap=load(broot/'sources-before.json');assert load(broot/'sources-after.json')==bmap and build['sourceStable'] and build['sourceCount']==len(bmap)==226 and build['status']=='CLOSED' and build['exitCode']==0
assert digest(build['artifact'])==build['artifactSha256']
for rel,h in bmap.items():assert digest(broot/'sources'/rel)==h
pmap=load(MAIN/'target/m2/stage49-platform-control-02/sources-before.json');pafter=load(MAIN/'target/m2/stage49-platform-control-02/sources-after.json');assert pmap==pafter and len(pmap)==320
assert all(pmap[k]==v for k,v in bmap.items())
primitive=load(MAIN/'target/m2/stage49-platform-control-02/primitives/report.json');assert primitive['source_stability'] and primitive['source_hashes']==pmap
for p,h in proof['files'].items():assert primitive['artifacts'][str(pathlib.Path(p).relative_to(MAIN/'target/m2/stage49-platform-control-02/primitives'))]==h
# Explicit declared input map only; no artifact, source, fixture or cache directory walk.
for p,h in e['artifactAndInputHashes'].items():assert digest(p)==h,('current captured input drift',p)
for t in ['node','browser']:
 assert [r['index'] for r in history[0]['targets'][t]['failedObserverSessions']]==[104,105,106,107]
 assert not history[1]['targets'][t]['failedObserverSessions']
 assert all(r['failures']==['incomplete-stream'] for r in history[0]['targets'][t]['failedObserverSessions'])
for n,h in [('playwright','1.64.1'),('playwright-core','1.64.1')]:assert e['playwrightPin']==h
write('result-history.json',history);write('remaining-mismatches.json',mismatches);write('original-inputs-before.json',before)
changes=[]
for p,row in before.items():
 b=pathlib.Path(p).read_bytes()
 if len(b)!=row['bytes'] or hashlib.sha256(b).hexdigest()!=row['sha256']:changes.append(p)
assert not changes
write('original-inputs-after.json',before)
write('report.json',{'scope':'Read-only audit of actual Stage50 Host/driver profile on immutable Stage49 build05 engine. Not Stage50 runtime verification. No evaluator runs.','executionSha256':digest(ROOT/'target/m2/stage50-extended944-platform05-control-02/actual/execution.json'),'actualRootReceipt':{'sessionId':40111,'chunkId':'c6ba5c','exitCode':1,'qualification':'Actual terminal supplied by parent; this auditor does not recreate producer contemporaneous receipt.'},'perTarget':history[1]['targets'],'rawAndClassificationEqualToControl01':True,'nodeBrowserDeliveredCallsEqual':True,'historicalControl01':history[0],'candidateSources':226,'platformSources':320,'declaredDriverInputs':len(e['artifactAndInputHashes']),'uniqueReadOriginalFiles':len(before),'originalChanges':changes,'artifactProofSourceAndBinaryHashesPassed':True,'exactBrowserAndHttpAssetHashesPassed':True,'fullStrictGatePassed':False,'knownRemaining':['Eight invalid-fragment Java PklBugException boundaries do not raw-match on either target; all retained.','836 ordinary successes/errors and100 intent-not-reached diagnostics are separate from8 internal-boundary cases.','Original Java10124 ordered events/counters are retained but full equality is not established.','Virtual configured File Host does not establish actual secure-path callback parity.','Browser OS PID is not recorded; explicit executablePath/hash and version are bound.','This intermediate profile on Stage49 build05 does not validate pending Stage50 segmented runtime.'],'inputSelection':'Exact fixture manifest-derived/raw result paths, producer-declared33004 input hashes, candidate maps226/platform320 and explicit process/source/artifact records only; no directory/cache traversal.'})
print(json.dumps({'originalFiles':len(before),'inputChanges':changes,'rawPerTarget':history[1]['targets']['node']['counts'],'strictPassed':False}))
