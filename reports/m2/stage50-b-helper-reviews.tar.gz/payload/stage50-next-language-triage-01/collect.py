import hashlib,json,pathlib,subprocess
R=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage50');M=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs');P=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2/stage47-language-final-01');O=R/'target/m2/stage50-next-language-triage-01';catalog={}
def get(p):
 p=pathlib.Path(p);b=p.read_bytes();row={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};assert str(p)not in catalog or catalog[str(p)]==row;catalog[str(p)]=row;return b
def load(p):return json.loads(get(p))
def write(n,v):(O/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
s=load(M/'reports/m2/stage47-final-summary.json');status=load(M/'reports/m2/stage47-final-status-changes.json');report=load(P/'report.json');inventory=load(M/'compatibility/m2-language.json')
assert s['implementation_commit']=='0e13a589d43c4cb1d83f41dd1ec416cac1770fc1' and s['status_counts']=={'candidate-unsupported':2,'mismatch':9,'oracle-error':1,'pass':3652}
rows=[c for c in report['results']if c['status']!='pass'];assert len(rows)==12 and {c['id']for c in rows}=={c['id']for c in status['current_nonpass']}
groups={'error-cycle':'oracle-environment','error-remainder-zero':'java-internal-profile','annotation-stage35-builtin-source-code-union-and-string':'collection-transform','trace-stage37-repeat-empty-cast-negative':'java-internal-profile','trace-stage37-repeat-empty-max-count':'java-internal-profile','read-stage38-uri-unpaired-surrogate':'lossless-uri-policy','read-stage38-edge-http-opaque':'java-internal-profile','read-stage38-edge-http-invalid-host':'java-internal-profile','read-stage38-edge-http-nonnumeric-port':'java-internal-profile'}
ledger=[]
for c in rows:
 directory=c.get('directory')or c['id'];d=P/'cases'/directory;entry={'id':c['id'],'publishedStatus':c['status'],'adapter':c.get('adapter','language-api-string'),'originalDirectory':str(d),'raw':{},'group':groups.get(c['id'],'glob'if'/日本語.pkl'in c['id']else'parameterized-mixin'if'lambdaTrailingCommas'in c['id']else'reflection-doc-metadata')}
 for who in ['java','rust']:
  for ch in ['stdout','stderr']:
   path=d/who/(ch+'.bin')if c.get('directory')else d/(who+'.'+ch+'.bin');b=get(path);assert hashlib.sha256(b).hexdigest()==c[who][ch+'_sha256'];rel=path.relative_to(P).as_posix();assert report['evidence_sha256'][rel]==hashlib.sha256(b).hexdigest()
   dest=O/'original-cases'/directory/(who+'.'+ch+'.bin');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);entry['raw'][who+'.'+ch]={'path':str(path),'copiedPath':dest.relative_to(O).as_posix(),**catalog[str(path)]}
  entry[who+'ExitCode']=c[who]['exit_code']
 inp=d/'input.pkl';b=get(inp);dest=O/'original-cases'/directory/'input.pkl';dest.write_bytes(b);entry['input']={'path':str(inp),'copiedPath':dest.relative_to(O).as_posix(),**catalog[str(inp)]}
 if c.get('directory'):
  upstream=c['id'].removeprefix('pkl:language-snippet:');pinned=R/'external/pkl'/upstream;assert get(pinned)==b and hashlib.sha256(b).hexdigest()==c['java']['upstream_case_sha256'];entry['pinnedWholeUpstreamInput']=str(pinned)
 else:
  outcome=get(d/'java.outcome.bin');(O/'original-cases'/directory/'java.outcome.bin').write_bytes(outcome);entry['oracleOutcomeUtf8']=outcome.decode()
  if entry['group']=='java-internal-profile':assert outcome==b'pkl-exception\torg.pkl.core.PklBugException\n'
  if c['id']=='error-cycle':assert outcome==b''and get(d/'java.stderr.bin').startswith(b'Exception in thread "main" java.lang.NoClassDefFoundError:')
 ledger.append(entry)
assert sum(c['group']=='java-internal-profile'for c in ledger)==6
project=['parser.rs','syntax.rs','vm.rs','vm/collections.rs','vm/compiler_expressions.rs','vm/strings.rs','vm/stdlib_modules.rs','vm/annotations.rs','host/resources.rs','modules.rs','heap.rs']
for rel in project:get(M/'crates/pkl-runtime/src'/rel)
upstream=['pkl-core/src/main/java/org/pkl/core/stdlib/base/ListNodes.java','pkl-core/src/main/java/org/pkl/core/stdlib/base/SetNodes.java','pkl-core/src/main/java/org/pkl/core/stdlib/base/MapNodes.java','pkl-core/src/main/java/org/pkl/core/runtime/VmSafeMath.java','pkl-core/src/main/java/org/pkl/core/stdlib/base/StringNodes.java','pkl-core/src/main/java/org/pkl/core/resource/ResourceReaders.java','pkl-core/src/main/java/org/pkl/core/runtime/VmExceptionRenderer.java','pkl-core/src/main/java/org/pkl/core/ast/builder/AstBuilder.java','pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ImportGlobNode.java','pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ReadGlobNode.java','pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ImportGlobMemberBodyNode.java','pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ReadGlobMemberBodyNode.java','pkl-core/src/main/java/org/pkl/core/util/GlobResolver.java','stdlib/base.pkl','stdlib/reflect.pkl']
for rel in upstream:get(R/'external/pkl'/rel)
affected=[]
for name in ['list','set','map']:
 suffix=f'pkl-core/src/test/files/LanguageSnippetTests/input/api/{name}.pkl';case=next(c for c in inventory['cases']if c['id']=='pkl:language-snippet:'+suffix);b=get(R/'external/pkl'/suffix);text=b.decode();lines=[{'line':i,'source':line}for i,line in enumerate(text.splitlines(),1)if '.map('in line or 'map()'in line];assert lines
 affected.append({'id':case['id'],'existingExecution':case['execution'],'inputSha256':hashlib.sha256(b).hexdigest(),'exactWholeInputMapLines':lines,'qualification':'Source-confirmed map use in an existing original inventory file. Entire input has other dependencies; no predicted case pass, adapter promotion or coverage numerator.'})
for p in ['source-map.json','report.json']:get(R/'target/m2/stage50-code-storage-c-review-01'/p)
write('case-ledger.json',{'publishedStage47Counts':s['status_counts'],'implementationCommit':s['implementation_commit'],'currentNonpass':ledger,'noNewOutcomes':True})
write('affected-inventory-cases.json',affected)
write('source-inputs-before.json',catalog)
changes=[p for p,row in catalog.items()if hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=row['sha256']];assert not changes;write('source-inputs-after.json',catalog)
write('report.json',{'scope':'Read-only source/raw triage; no evaluator/build/test rerun. Source current Main and pinned Java are distinguished from Stage47 historical outcomes.','mainHead':subprocess.check_output(['git','-C',str(M),'rev-parse','HEAD'],text=True).strip(),'publishedStage47SourceCommit':s['implementation_commit'],'publishedSelected':3664,'publishedPass':3652,'publishedNonpass':12,'publishedFullGateFailureReasons':1825,'groups':{'ordinaryFeatureFirstBlockers':4,'losslessUriPolicy':1,'javaPklBugExceptionRawProfiles':6,'oracleNoClassDefWithEmptyOutcome':1},'recommendedNextBatch':'Shared resumable Collection transform/map, starting original annotation-stage35-builtin-source-code-union-and-string whole input; generic List callback execution, then precisely scoped List/Set/Map variants. No SourceCode-specific shortcut.','sourceConfirmedAffectedInventoryFiles':[c['id']for c in affected],'noProjectedCoverageIncrease':True,'separateFollowups':['read*/import* typed listing + lazy Mapping/Unicode original','parameterized Mixin AST/function/amendment','reflection authored declaration/doc metadata','lossless UTF16 URI/reader-policy','full Java internal-error profile/oracle environment','Extended944 eight internal boundaries and10124 full event/counter parity'],'noOriginalChanges':changes,'inputFiles':len(catalog),'limits':['Current source blocking string/method gap is source evidence, not a new original-case evaluation.','Stage48/49 full regressions remain parent-owned and are not final-audited here.','Stage50 candidate storage changes and old05 portable checks cannot be counted as language-case closure.']})
print(json.dumps({'currentNonpass':12,'inputFiles':len(catalog),'sourceChanges':changes,'affectedInventoryWholeFiles':len(affected)}))
