import {writeFile} from 'node:fs/promises';
import {compareModuleKeyExtendedCase} from '../../../tools/platform/modulekey-extended-session.mjs';
const expected = {status:'error',statusRawHex:'6572726f720a',sourceProfileId:'main.pkl',scope:'ordinary',
 errorClass:'org.pkl.core.PklException',messageNull:false,stdoutUnits:[],stdoutHex:'',stderrUnits:[120],stderrHex:'78'};
const fixture = {expected:[expected]};
const rows = [null,'unknown-classification','limit-exceeded','unsupported','internal-failure','language-error'].map(disposition => {
 const actual={calls:[{index:0,status:expected.status,statusRawHex:expected.statusRawHex,sourceProfileId:'main.pkl',stdoutUnits:[],stderrUnits:[120],disposition}],
 architecture:{terminalSlots:0,ownedResultsStable:true,releasedHostKeys:true},constructorError:null,acquisitionError:null};
 const c=compareModuleKeyExtendedCase(fixture,actual);
 return {disposition,rawApiPassed:c.rawApiPassed,ordinaryCompatibilityPassed:c.ordinaryCompatibilityPassed,intendedOrdinaryMatched:c.intendedOrdinaryMatched};
});
await writeFile(new URL('./disposition-results.json',import.meta.url),JSON.stringify({scope:'Pure comparator synthetic input; no evaluator or Java execution.',rows},null,2)+'\n');
console.log(JSON.stringify(rows));
