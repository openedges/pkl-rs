import json,pathlib,collections
R=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage50');O=R/'target/m2/stage50-extended944-platform05-c-audit-03';F=R/'tests/fixtures/m2-modulekey-extended';fixtures=json.loads((F/'fixtures.json').read_text())['fixtures'];profiles={p['id']:p for p in json.loads((F/'host-metadata.json').read_text())['profiles']}
allowed={'select-key':{'completeDefaultModule','completeModuleKey','rejectModuleKey'},'check-import':{'completeDefaultModule','rejectModuleImportCheck'},'query-cache-policy':{'completeDefaultModule','completeModuleCachePolicy'},'query-fragment-paths':{'completeDefaultModule','completeModuleFragmentPaths'},'resolve':{'completeDefaultModule','completeModuleResolvedKey','rejectModuleResolution'},'resolve-key':{'completeDefaultModule','completeModuleResolvedKey','rejectModuleResolution'},'resolve-import-uri':{'completeDefaultModule','completeImportUri'},'load-source':{'completeModuleSource','rejectModuleSource'},'capabilities':{'completeModuleCapabilities'},'has-element':{'completeModuleHasElement'}}
summary=[]
for control in ['01','02']:
 for target in ['node','browser']:
  rows=json.loads((R/f'target/m2/stage50-extended944-platform05-control-{control}/actual/{target}.raw.json').read_text());counts=collections.Counter()
  for row,f in zip(rows,fixtures):
   p=profiles[f['providerProfileId']];active=False;pending=None;host=None;results=0;ops=[];req=[];closed=False;ctor=0;gc=False
   for i,event in enumerate(row['observations']):
    k=event['kind'];assert event['sequence']==i and event['callIndex']==results
    if k=='constructor-call':assert i==0 and ctor==0 and event['method']=='moduleEvaluator';ctor=1
    elif k=='constructor-return':assert ctor==1;ctor=2
    elif k=='api-call':
     assert ctor==2 and not active and not pending and not closed;active=True
     operation=[x for x in f['operations'] if x['kind']=='evaluate'][results];s=p['sourceProfiles'][operation['sourceProfileId']];contents=None if s['kind']=='uri' else p['sources'][s['sourceId']]['text'];assert event['args']==[s['uri'],contents,operation['expression'],0];ops.append({'kind':'evaluate'})
    elif k=='api-started':assert active and event['method']=='evaluateModuleSource'
    elif k=='module-request':assert active and pending is None and host is None;pending={'token':event['token'],'module':event['module']};req.append({'callIndex':results,**pending});counts['requests']+=1
    elif k=='host-call':
     assert active and pending and host is None and event['args'][0]==pending['token'];method=event['method'];request=pending['module'];assert method in allowed[request['kind']]
     if method in ['completeModuleKey','completeModuleResolvedKey','completeModuleCachePolicy','completeModuleFragmentPaths','completeImportUri']:assert event['args'][1]==request['keyId']
     if method=='completeModuleResolvedKey':assert event['args'][2]==request['resolvedKeyId']
     host=method;counts[method]+=1
    elif k=='host-return':
     assert pending and host==event['method']
     if host=='completeDefaultModule':
      assert not event['returnedUndefined'] and type(event['value']) is bool
      if event['value']:pending=None
      else:counts['defaultFalseTokenPreserved']+=1
     else:pending=None
     host=None
    elif k=='api-result':assert active and pending is None and host is None and event['call']==row['calls'][results];active=False;results+=1;counts['calls']+=1
    elif k=='explicit-gc-call':assert not active and not pending and not gc and not closed;gc=True;ops.append({'kind':'gc'})
    elif k=='explicit-gc-return':assert gc;gc=False
    elif k.endswith('-config'):
     assert not active and not closed and not pending
     if k=='cache-config':ops.append({'kind':'cache','value':'on' if event['cached'] else 'off'})
     elif k=='factory-config':ops.append({'kind':'factory','value':'custom' if event['customFactory'] else 'builtin'})
     elif k=='source-config':ops.append({'kind':'source','value':event['state']})
     elif k=='policy-config':ops.append({'kind':'policy','value':event['mode']})
     else:raise AssertionError(k)
    elif k=='close-call':assert not active and pending is None and host is None and not closed
    elif k=='close-return':assert event['terminalSlots']==row['architecture']['terminalSlots']==0;closed=True
    else:raise AssertionError(k)
   planned=[{'kind':'evaluate'} if x['kind']=='evaluate' else {'kind':'gc'} if x['kind']=='gc' else x for x in f['operations']]
   assert ops==planned and req==row['requests'] and closed and results==len(row['calls'])
   assert row['architecture']['ownedResultsStable'] and row['architecture']['releasedHostKeys']
  summary.append({'control':control,'target':target,'counts':dict(counts),'sessions':len(rows)})
(O/'independent-observer-readback.json').write_text(json.dumps({'scope':'Independent Python operation/request/completion/token/source-profile FSM over captured records only; no evaluator or checker import. Accepts authenticated empty GC operand as no-argument operation; does not override original failed checker gate.','results':summary},indent=2)+'\n');print(json.dumps(summary))
