import ast, collections, hashlib, json, pathlib, datetime
ROOT=pathlib.Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage50'); OUT=ROOT/'target/m2/stage50-extended-pipeline-c-review-02'; FIX=ROOT/'tests/fixtures/m2-modulekey-extended'
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return p.read_bytes()
def load(p): return json.loads(read(p))
def write(n,v): (OUT/n).write_text(json.dumps(v,indent=2)+'\n')
paths=['tools/platform/modulekey-extended-session.mjs','tools/platform/compare-modulekey-extended.mjs','tools/modulekey_extended_fixtures.py','tools/platform/module-policy-session.mjs','tools/platform/resource-session.mjs','tools/platform/compare-modulekey.mjs','tools/platform/modulekey-session.mjs','tools/platform/modulekey-extended-session.test.mjs','tools/platform/compare-modulekey-extended.test.mjs','crates/pkl-runtime/src/diagnostic.rs','crates/pkl-runtime/src/probe.rs','external/pkl/pkl-core/src/main/java/org/pkl/core/module/ModuleKeys.java','external/pkl/pkl-core/src/main/java/org/pkl/core/module/ModuleKey.java']
paths += [f'tests/fixtures/m2-modulekey-extended/original/java{i:02}/AdmissionProbe.java' for i in range(1,8)]
paths += ['tests/fixtures/m2-modulekey-extended/'+p for p in ['manifest.json','fixtures.json','host-metadata.json']]
def catalog(): return {p:{'sha256':sha(read(ROOT/p)),'bytes':(ROOT/p).stat().st_size} for p in paths}
before=catalog();write('inputs-before.json',before)
expected={'tools/platform/modulekey-extended-session.mjs':'ba64f305ddd723a0f15b705178f61e3ac126a3d3b9749db0d5e3f43e6060c840','tools/platform/compare-modulekey-extended.mjs':'e44cbf8b0cabed4955353cd255cc62679f34985bd080d6b85cbfbedc71e570e5','tools/modulekey_extended_fixtures.py':'30131893b23f908aebdcf54eec1ac37dd6666a3054ee5e017e77e935068beaaf','tests/fixtures/m2-modulekey-extended/manifest.json':'eda9449570132c0f76ebf2ea67071a94b6b3a53b29fb9a49dfb982e66ad18bb2'}
assert all(before[p]['sha256']==h for p,h in expected.items())
manifest=load(FIX/'manifest.json'); bundle=load(FIX/'fixtures.json'); metadata=load(FIX/'host-metadata.json'); used={}
def payload(rel):
 b=read(FIX/rel); row=manifest['files'][rel];assert sha(b)==row['sha256'] and len(b)==row['bytes'];used[rel]={'sha256':sha(b),'bytes':len(b)};return b
pins=next(ast.literal_eval(n.value) for n in ast.parse((ROOT/'tools/modulekey_extended_fixtures.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PINS' for t in n.targets))
for name, pin in pins.items():
 docs=[payload(f'provenance/{name}/{n}.json') for n in ['report','inventory','closure']];assert tuple(sha(b) for b in docs)==pin
 report,inventory,closure=map(json.loads,docs);assert closure['sealed'] and closure['liveHandles']==[] and not report['inputChanges'] and report['workspacesUnchanged'] and report['jarStable']
 helper=payload(f'original/{name}/AdmissionProbe.java');assert sha(helper)==inventory['files']['AdmissionProbe.java']['sha256']
scopes=collections.Counter();events=0;api=0
for f in bundle['fixtures']:
 for c in f['expected']:
  api+=1;scopes[c['scope']]+=1;prefix=c['javaRawPrefix']
  assert payload(prefix+'.status.bin').hex()==c['statusRawHex']
  assert payload(prefix+'.error-class.bin').decode()==c['errorClass']
  assert (payload(prefix+'.message-null.bin')==b'true')==c['messageNull']
  assert payload(prefix+'.source.bin').decode()==c['sourceProfileId']
  for channel in ['stdout','stderr']:
   b=payload(prefix+'.'+channel+'.code-units.bin');assert len(b)%2==0
   assert [int.from_bytes(b[i:i+2],'big') for i in range(0,len(b),2)]==c[channel+'Units']
   assert payload(prefix+'.'+channel+'.bin').hex()==c[channel+'Hex']
  for when in ['Before','After']:
   b=payload(prefix+'.counters-'+when.lower()+'.bin');assert b.hex()==c['counterBytes'+when+'Hex']
 for event in f['orderedJavaEvents']:
  events+=1;prefix='original/'+f['oracleId']+'/'+event['rawPrefix']
  assert payload(prefix+'.bin').hex()==event['utf8Hex']
  assert payload(prefix+'.code-units.bin').hex()==event['utf16BEHex']
assert (len(bundle['fixtures']),len(metadata['profiles']),api,events)==(140,35,944,10124)
assert scopes=={'ordinary':836,'intent-not-reached-diagnostic':100,'internal-boundary':8}
synthetic=[p for profile in metadata['profiles'] for p in profile['customModules'] if p['keyKind']=='synthetic'];assert synthetic and all(not p['fragmentPaths'] and p['sourceMode']=='state-at-factory' for p in synthetic)
after=catalog();write('inputs-after.json',after);assert before==after
write('checked-payloads.json',used)
write('report.json',{'reviewScope':'Frozen source/authority readback and pure comparator mock only; no evaluator rerun. Successor ba64 helper/e44cb driver reviewed; original findings/reproducer and pin-drift failure retained separately.','frozenPins':expected,'sourceChanges':[],'originalApiRows':api,'originalJavaEvents':events,'sessions':len(bundle['fixtures']),'providerProfiles':len(metadata['profiles']),'scopeLedger':dict(scopes),'openPublicationBlockers':[],'directAuthenticatedPayloads':len(used),'literalAuthorityTriples':7,'historicalCorrectedFindings':[{'id':'C50-extended-disposition','severity':'correctness','source':'tools/platform/modulekey-extended-session.mjs:364','observation':'Matching ordinary error raw bytes with null/unknown/limit-exceeded disposition are counted ordinary-compatible. Current shared probe errors always carry classification.','reproducer':'disposition-results.json','correction':'Current helper classified() positively requires success/null or known error disposition; records api-result before rejecting malformed metadata; comparator ordinary errors require language-error. C unit04 36/36 includes null/unknown/limit and forged-actual controls.'},{'id':'C50-driver-gc-operand','severity':'correctness','source':'tools/platform/compare-modulekey-extended.mjs:206','observation':'Original gc operations can retain value:""; planned spread differs from emitted no-argument GC observation. Root actual first capture exposed four java03 session observation failures.','provenance':'Parent reported actual root8676 terminal1; this review does not acquire or re-audit its output.','correction':'Current driver validates absent/exact empty GC operand and projects no-argument GC in observations; nonempty rejected. Parent/B retain initial actual capture and reported 11 successor driver units.'}],'confirmedBoundaries':['Full944 APIs and10124 ordered Java events retained with original status/UTF16/JavaUTF8/error metadata and counter bytes.','Execution helper does not read fixture.expected; Host inputs are authored/source-derived tables, expected outputs from sealed Java only.','Raw equality, acquisition, ownership/cleanup, observation consistency, ordinary support and full lifecycle are distinct gates. Full Java event/counter parity remains false.','Factory and cache snapshots, source-at-factory vs source-at-load, custom Synthetic vs internal/supplied wrappers, exact declaration overrides, Java07 membership and raw deny causes follow bounded sealed helper inputs.','File table is virtual configured Host, not actual secure-path/factory callback parity. Browser PID is unrecorded; explicit executablePath/hash and tracked actual HTTP assets are required.'],'limitations':['Verifier full coverage already belongs to B actual checks; this review authenticates selected explicit original paths, not a new whole fixture scan.','Default-success behavior is delegated to the shared engine, not independently reimplemented in JS.','Observation checker establishes internal recorded-stream consistency; it is not a Java10124 semantic-event oracle.','Hostile tests cover malformed ownership/request/cause and cleanup paths, not all future ModuleKey SPI configurations.']})
print(json.dumps({'api':api,'events':events,'payloads':len(used),'changes':[]}))
