# Stage50 extended944 provider 소스 검토

읽기 전용 설계 검토다. Main의 Stage49 완료 소스/봉인 Java01–07/transport03만 읽었고, A의 변경 중인 segmented Rust source를 동결 후보로 취급하지 않았다. Main/원본 증거/production/Git 변경 및 Java/evaluator/test 실행은 없다. 결과944는140session/35logicalcase, intended836/diagnostic-intent-not-reached100/internal8로 구분한다. 새 portable 결과를 예상 성공 수936에 맞추지 않는다.

## phase별 URI와 소유권

기준은 Main `crates/pkl-runtime/src/probe.rs:278–424`의 실제 serializer다. opaque handle·decimal u64를 변환하지 않고 request를 validation 전에 그대로 기록한다. keyId와 resolvedKeyId는 별도 namespace이며 같은 문자열 숫자여도 서로 대신 조회하지 않는다.

| 요청 | `originalUri` 의미 | Host 검증/완료 기준 |
| --- | --- | --- |
| select-key | factory에 전달된 요청 URI | 새로운 keyId, phase 검증; custom 활성 Plan→exact File→Rust default. requestedURI를 selectedURI로 강제하지 않음 |
| cache-policy/fragment-paths | selected key URI | 등록 id+kind+handle 및 stored selected URI. bool은 factory 시 snapshot/Plan flag |
| resolve-key | selected key URI, primary/query 별도 phase | 등록 custom key 또는 알려진 engine-owned wrapper/internal context. resolved ID/handle을 실제 완료 후 등록 |
| resolve | import-original URI; selected URI와 다를 수 있음 | id/kind/handle은 registry로 검증. importUri와 importer original/resolved 문맥을 보존. 완료 triple은 stored selected/resolved/source URI |
| load-source | resolved original key URI | key id/kind/handle + resolved id/handle + original/resolved/source triple 모두 일치해야 함 |
| resolve-import-uri | declaration selected key URI | 등록된 declaration key의 override exact(selectedURI,authoredOperand)만 우선. wrapper/unknown key에 URI spelling만으로 override 적용 금지 |
| capabilities | module-original URI | optional delegate id/kind/handle로 registry를 찾아 CAPS 사용. 이 요청에는 selected URI 필드가 따로 없으므로 originalUri==selectedURI 공통 검사는 틀림 |
| has-element | 검색 candidate URI | 등록 selected key URI + candidate의 exact membership; 명시 ELEMENT_DEFAULT가 있을 때만 없는 항목을 false로 완료 |

sourceUri는 registered custom key의 selected URI이며 ResolvedKey URI와 다르다. 이 계약은 Java PlannedKey.getOriginal/resolve/loadSource에서 나온다. 기존212의 owned() URI equality를 모든 phase에 재사용하면 alias/wrapper/triple 입력을 거부한다.

## 실제 정책 원인 선택

- pinned SecurityManagers.java:148–174에서 allowedModules는 checkResolveModule에 적용되고 checkImportModule은 trust만 검사한다. 실제944 operation policy는 allow/deny-repl/deny-supplied뿐이고 모든 initialPolicy는allow다. 따라서 deny-* target을 CheckImport에서 거부하면 원래 Java보다 앞선 잘못된 오류가 된다.
- CheckImport 원인 context는 importerResolvedUri→importUri다. registered PlannedKey/customSynthetic resolve는 stored selectedURI에 checkResolveModule을 한다. Resolve.originalUri/importUri를 selectedURI처럼 사용하면 alias 정책이 틀린다. Main의 기존 native adapter는 일부 importUri 단순화를 가지므로 새 portable helper의 규범으로 복사하지 않는다.
- CachedModuleKey.resolve는 `ModuleKeys.java:159–190`에서 자신을 반환하며 보안 검사하지 않는다. supplied-text wrapper resolve에 delegate의 원인을 적용하지 않는다. 반대로 Synthetic.resolve `:254–258`은 실제 security.checkResolveModule(uri)를 한다. 내부query/repl도 deny-repl 원인을 적용한 뒤 default에 위임해야 한다. synthetic kind 전체를 무조건 allow/default로 처리하지 않는다.
- Java07 PlannedKey.hasElement `AdmissionProbe.java:47–53`은 정확한 set-membership만 수행하며 전달된 security를 사용하지 않는다. capabilities에도 정책 callback이 없다. policy state를 이유로 이 phase에 원인을 새로 만들지 않는다.
- 원인은 mode+실제 policy call kind(module/import)+context로 raw cause를 조회한다. null flag와 원래 UTF16/JavaUTF8를 보존하며 formatted Pkl stderr를 원인 문자열로 사용하지 않는다. 알려진 거부인데 해당 raw cause가 없으면 명시 acquisition gap이다. 관찰되지 않은 allow/deny를 추측하지 않는다.

## snapshot·wrapper 불변식과 필요한 mock

1. key별 cache bool은 select 시 snapshot이다. factory=builtin이나 cache/source 상태 변경 뒤에도 이미 만들어진 key의 getter/resolve/source 소유권은 유효하다. JS는 semantic URI/cache/site 결과를 보관하지 않는다.
2. fixed/state-at-load/state-at-factory를 각각 검사한다. URI/source bank는 사전 인증·불변이고 state-at-factory는 선택 시 source를 고정한다. state-at-load는 실제 LoadSource 시 현재 상태를 사용한다. factory에서 파일 읽기/해결/모듈 초기화를 하지 않는다.
3. **실제 Java06 입력 경계:** initial sourceState는good지만 두 synthetic config에는 SOURCE good가 없다. 첫 operation source=one 뒤에야 evaluate한다. 초기 state가 즉시 source bank에 있어야 한다는 eager admission 검사는 authentic 입력을 거부한다. 실제 source operation/사용 시에만 존재성을 요구한다.
4. custom Synthetic는 등록된 id/kind/opaque handle로 snapshot/getter/source를 제공한다. unknown custom Synthetic의 foreign/비어있지 않은 handle은 내부 query처럼 default로 우회시키지 않는다. 내부 Synthetic와 supplied wrapper의 서로 다른 phase·빈 handle 문맥을 따로 시험한다. URI가 같아도 등록된 객체 구현은 구분한다.
5. wrapper는 delegate local/hierarchical/hasElement를 쓰지만 자체 hasFragmentPaths는 기본false이고 resolveUri override를 delegate하지 않는다. Java07 delegate CAPS.fragmentPaths=true를 Host에서 false로 덮어쓰지 않는다. Java05 같은 URI의 Host key override가 wrapper에는 적용되지 않는 mock이 필요하다.
6. Java06 factory의 throwing hook은 `customMode?plans.get(uri):null`보다 먼저 실행된다. factory=builtin은 Plan lookup만 끄며 authored throwing IOException을 숨기지 않는다. 이 조합의 mock은 source-backed invariant이고 새 Java 실제 관찰로 표시하지 않는다.
7. phase별 foreign key/resolved handle/triple 변조, null/부분 descriptor, u64 초과·2^53 이상 ID, id namespace 충돌, stale callback throw, default false 뒤 같은 token으로 허용된 fallback 완료를 시험한다. malformed transport는 acquisition failure이며 raw request는 남겨야 한다.
8. supplied contents의 null과 빈 문자열을 구분하고 operation sourceProfile을 그대로 public API에 전달한다. wrapper/repl을 Host key로 대신 만들지 않는다. 실제 delivered request만 완료하고 Java 예상 이벤트를 actual diagnostic stream에 복사하지 않는다.
9. SOURCE IOException `stage49-source-io` 입력은 ASCII/helper/failure bytes에서 도출된 운반 units이며 독립 JavaUTF16 관찰이 아니다. API 출력·오류 및 security cause의 독립 raw units와 provenance를 합치지 않는다. nullable sourceIO 범위를 임의로 추가하지 않는다.

## 검증 경계

836 ordinary,100 초기 query alias 의도 미도달 진단,8 invalid-fragment Java internal 오류를 전부 실행·기록한다. raw equality/ordinary compatibility/intent/내부오류/취득/cleanup/fullJava10124events·counter를 분리한다. 추가944의 실제 Node/Chromium은 후속 frozen artifact에서만 판정한다. 기존212·native944 성공을 portable944로 재사용하지 않는다. Java GC 요청과 native per-poll GC도 같은 관찰이라고 표시하지 않는다.

root와 B에 위 phase/policy/initial-state 관찰을 직접 전달했다. 새 helper/fixture/driver가 고정되면 별도의 코드·권위 바인딩 검토가 필요하다. 이 문서는 그 구현 검토나 실제 실행 통과가 아니다.
