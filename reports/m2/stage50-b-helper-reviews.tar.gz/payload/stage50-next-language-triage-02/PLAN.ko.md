# Stage50 이후 M2 언어 구현 우선순위 — 원본 Stage47 미통과 12건

이 문서는 읽기 전용 소스·기록 조사다. 새 Java/Rust/Node/Chromium 평가를 실행하지 않았고, 원본 입력·기대 결과·실패 상태를 변경하지 않았다. 게시된 Stage47의 구현은 `0e13a589d43c4cb1d83f41dd1ec416cac1770fc1`이며 3,664개 중 3,652개 일치, 미지원 2·불일치 9·oracle 오류 1이다. 조사 시점 Main의 Stage49 소스와 Stage50 초기 동결 검토는 후속 구현 근거일 뿐 이 12건의 새로운 판정이 아니다. 실행 중인 Stage48/49 전체 회귀가 끝난 뒤 실제 결과로 우선순위를 재확인해야 한다.

## 12건의 실제 원인 분류

| 원본 사례 | 게시 상태 | 원본 raw가 보여 주는 첫 장애 | 현재 소스에서 확인한 경계 |
|---|---|---|---|
| `annotation-stage35-builtin-source-code-union-and-string` | mismatch | Java는 12개 SourceCode language 문자열을 반환하지만 Rust는 `missing member map` | 일반 Collection callback 변환 메서드가 없다. `collections.rs:929`는 제한된 속성 조회, `vm.rs:4100`의 List/Set 메서드 연결은 join이다. SourceCode 직접 생성 성공을 이 원본 map 입력의 성공으로 바꿀 수 없다. |
| `modules/日本語.pkl` | mismatch | `import*`의 `*`에서 파싱 실패. Java 전체 출력에는 read*/import*의 Unicode 상대 경로 keys가 있다. | `parser.rs:906`의 glob import 거부, `compiler_expressions.rs:1096`의 read* Unsupported. 원본은 Resource·ordinary import·glob Mapping.keys까지 모두 요구한다. |
| `parser/lambdaTrailingCommas.pkl` | candidate-unsupported | 함수 trailing comma가 아니라 첫 parameterized `new Mixin { a, -> ... }`에서 미지원 | `parser.rs:1311`는 parameters를 검출해 DeferredAstValidation Unsupported를 만들고 일반 Object/New AST에 parameter 목록을 보존하지 않는다. 진단만 삭제하는 수정은 불충분하다. |
| `parser/lineCommentBetween.pkl` | candidate-unsupported | `pkl:reflect` 로드 미지원. Java는 두 doc-comment 줄을 합친 속성 docComment 반환 | `stdlib_modules.rs`에 reflect 본문/외부 바인딩이 없다. `parser.rs:664`의 doc_comment()는 bool을 반환하며 주석을 소비한다. mirror 객체만 추가해서는 원본 doc metadata를 복구할 수 없다. |
| `read-stage38-uri-unpaired-surrogate` | mismatch | Java는 URI `life:?`의 resource allowlist 거부, Rust는 unmatched UTF16 미지원 | `vm.rs:4958`의 PklString→str 경계에서 거부한다. lossless URI carrier, Java URI/diagnostic encoding, reader 선택·정책 순서를 함께 다뤄야 한다. 입력의 surrogate를 미리 '?'로 치환해서는 안 된다. |
| `error-remainder-zero` | mismatch | Java outcome은 `PklBugException`, native ArithmeticException `/ by zero`가 포함된 전체 bug report | `VmSafeMath.java:92`, Rust `vm.rs:5241/5341`. 일반 Division-by-zero 진단으로 raw 동등성을 대신할 수 없다. |
| `trace-stage37-repeat-empty-cast-negative` / `trace-stage37-repeat-empty-max-count` | 각 mismatch | Java outcome은 PklBugException. checked length 후 long→int narrowing이 음수인 JDK String.repeat 예외 | `StringNodes.java:277–284`, Rust `vm/strings.rs:143–173`의 명시적 Unsupported. 실제 정수 narrowing·external frame·Java internal-report profile을 분리한다. |
| `read-stage38-edge-http-opaque` / `...invalid-host` / `...nonnumeric-port` | 각 mismatch | Java outcome은 PklBugException. HttpRequest 구축이 allowlist 검사보다 앞서 실패 | `ResourceReaders.java:311/357`, Rust `host/resources.rs:44–50`의 명시적 Unsupported. 정책 거부로 바꿔서 통과시킬 수 없다. |
| `error-cycle` | oracle-error | Java outcome이 비었고 stderr는 VmStackOverflowException 초기화의 NoClassDefFoundError. Rust는 cycle 진단 | Oracle 실패다. Rust 오류를 Java 내부 stacktrace 문자열로 바꾸거나 성공으로 집계하지 않는다. 기존 기록을 유지하고 별도 oracle 실행 환경/재현 의무로 둔다. |

따라서 보통 언어/표준 라이브러리의 실제 첫 장애 4건, lossless URI·정책 경계 1건, Java PklBugException profile 6건, oracle 자체 오류 1건이다. 원본 12건 전체의 raw/status/hash 연결은 `case-ledger.json`에 보존했다. Java 내부 오류 6건을 일반 언어 오류 수정과 섞지 않는다.

## 권고: 공통 resumable Collection transform/map 경로

다음 구현 묶음의 첫 원본 목표는 `annotation-stage35-builtin-source-code-union-and-string` 전체 입력이다. 여기에 필요한 `List.map`을 SourceCode 전용 연산으로 만들지 않고, 일반 사용자 Function을 호출하는 공유 Collection 변환 continuation으로 구현하는 것을 권한다. 이미 검증된 call/type/Host/reentry/GC 경로를 이용할 수 있고 새 filesystem/network 프로토콜 없이 실제 표준 라이브러리 결손을 줄인다. 최초 map 장애가 사라진 뒤 다른 SourceCode 오류가 드러날 수 있으므로 예상 1건 통과를 약속하지 않는다.

- 계약은 `stdlib/base.pkl:2654–2677`, List 선언 `:3150–3158`, `ListNodes.java:555–583`이다. List.map은 입력 순서대로 각 요소를 Function1에 전달하고 결과를 builder에 추가한다. 결과 안쪽 객체/중첩 List를 추가로 deep-force하지 않는다. mapIndexed의 인덱스는 Java long 의미와 순서를 보존한다.
- 공통 continuation은 receiver/input 값·callback·부분 결과·현재 인덱스·대기 상태를 Frame에 둔다. 기존 `JoinRun`의 resumable/GC 연결 지점을 참고하되 문자열 변환이나 collection force를 그대로 가져오지 않는다. `vm.rs`의 ordinary call과 typed parameter/return 검사를 거쳐야 한다. callback을 Rust/JS에서 임의 실행하거나 이미 계산된 Java expected 값을 재생하지 않는다.
- callback read/import/trace 중단, nested API reentry, throw와 guest catch, 실패 후 재호출, cancellation/timeout/close, escaped callback과 생성한 객체/클래스/alias를 보존한다. 최초 실패 뒤 다음 callback은 실행하지 않는다. 실패 시 partial result를 다른 호출에 재사용하지 않으며, 이미 성공한 guest property/resource/site cache의 기존 수명은 유지한다.
- 외부 메서드와 callback parameter의 boxing/slot 이력, 실제 declaration frame/span을 유지한다. Stage47 reference identity 처리를 우회하는 별도 callback evaluator를 만들지 않는다. Stage50 segmented owner에는 callback·대기 중 Frame·부분 결과를 통해 필요한 코드만 연결한다.
- 같은 기반으로 List map 계열을 확장하고 Set.map·Map.map/maps를 구현할 때는 결과 종류·순서·중복 키·hash/force 시점을 각 pinned Java node에서 확인한다. `SetNodes.java:332`의 builder와 `MapNodes.java:145`의 Function2→Pair 계약을 List.map으로 일반화하면 안 된다. filter/fold/flatMap 전체나 전체 Collection 완료를 아직 주장하지 않는다.
- 원본 `api/list.pkl:83–85` 등에는 추가 map 사용이 있지만 전체 파일에는 아직 많은 다른 메서드가 있다. 일부 식의 성공을 원본 전체 사례나 inventory ready 승격으로 계산하지 않는다. 추가 differential 사례는 원본 실패를 대체하는 새 bounded 성공 코퍼스가 아니라 의미·오류 순서·Host/GC 회귀를 확인하는 보조 증거다.

원본 inventory의 구체적 의존성은 `pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/api/list.pkl` 83–85행, `api/set.pkl` 67–69행, `api/map.pkl` 88–92행에서 확인했다. 세 파일은 모두 현재 unimplemented 행이며 전체 입력에는 다른 미구현 메서드가 있다. 이 세 개를 예상 추가 통과 수로 계산하지 않는다. 원래 Map 사례의 빈 Map callback 비실행과 잘못된 Pair 반환도 보존한다. 자세한 원본 행/해시는 `affected-inventory-cases.json`에 있다.

완료 판정은 원본 전체 입력/원래 adapter/동일 기대 raw 출력 유지, 새 고정 Java 비교 및 native·Node·Chromium, 해당 lifecycle·Rust5, 최종 whole selected/full gate로 연결한다. 지금은 구현 계획만 있으며 새 평가 결과는 없다.

## 그 다음 큰 묶음: 공통 glob 탐색과 지연 Mapping

Unicode 원본 `日本語.pkl`을 닫는 별도 coherent batch로 read*/import*를 권한다. 단순 parser 허용이나 native 폴더 regex 검색으로 끝내면 안 된다.

1. Import clause/ImportExpr의 glob flag를 AST→resolver preparation→compiler에 보존한다. `AstBuilder.java:645–659`는 triple-dot glob을 거부하고 실제 declaration key의 URI resolution을 사용한다. read*는 runtime 패턴 문자열별 경로다.
2. ModuleKey/resource Reader의 glob 가능 여부, listElements, hasElement, 계층/비계층 URI와 정책 효과를 Host 뒤에 둔다. 현재 ModuleRequest에 Capabilities/HasElement는 있지만 목록 반환 계약이 없다. 새 typed 목록 요청·완료/거부·잘못된 token/phase·default false 및 Native/NAPI/Wasm/providers가 필요하다. 기존 selected key/custom factory/wrapper 소유권과 cache 순서를 재사용한다.
3. 현재 shared collection 경로에는 일반 Mapping `.keys`도 구현되어 있지 않다(`collections.rs:929`는 length/isEmpty만 처리). 따라서 glob 생성만이 아니라 기존 lazy entry/key·generator·predicate 순회 위에 keys Set의 순서/중복 처리를 연결해야 한다. `.keys`를 얻으려고 매칭된 모듈/Resource 값을 강제하지 않는다.
4. `GlobResolver.java:249/264/342/479`의 PathElement 순서·정규 pattern·탐색 상한·존재 확인·상대 key spelling/Unicode를 보존한다. I/O를 먼저 한 뒤 JS에서 정렬/URI 정규화하여 Java raw 차이를 숨기지 않는다.
5. `ImportGlobNode.java:78`는 node 성공 결과를 cache하고, `ReadGlobNode.java:73`는 pattern별 성공 결과를 cache한다. 결과는 lazy Mapping이다. keys만 조회할 때 `日本語_error.pkl`을 로드/평가하면 원본 성공을 깨뜨린다. `ImportGlobMemberBodyNode.java:65`의 개별 값 강제 시 import-edge→factory→load, ReadGlobMemberBodyNode의 ResourceManager read를 유지한다. 오류·partial success·재시도·GC와 suspend 중 listing/result roots를 확인한다.
6. `basic/importGlob.pkl`·`basic/readGlob.pkl` 등 원본의 package/HTTP/TLS fixture 의무는 별도다. 로컬 Unicode 사례 통과를 full glob/filesystem/package/외부 reader 지원으로 확대하지 않는다. 이 조사에서 제목에 glob이 든 16개 inventory 행을 찾았다는 것은 동작 범위나 기능 분모가 아니다.

## 별도 필수 의무와 다음 판정 순서

- Parameterized Mixin은 parameter AST·type 방문 순서·captured this·ordinary amendment/call 경로를 구현해야 한다. `AstBuilder.java:2250–2363/2652`의 parameter descriptor/type 처리와 generator owner 복원을 연결한다. 원본 trailing comma 진단을 고치는 작업으로 축소하지 않는다.
- Reflection은 authored declaration metadata와 mirror 수명·주석/annotations/source identity 전반의 묶음이다. doc comment를 출력 문자열 상수로 채우거나 reflect.Class 하나의 특례로 닫지 않는다.
- UTF16 URI와 Java internal-error report는 별도 계약이다. 수치·repeat·HTTP 실제 의미를 유지하며 PklBugException 전체 원문/환경 의존 JDK frame을 어떻게 검증하는지 명시해야 한다. Java fallback·원문 normalization·예외 삭제는 금지한다.
- Stage50 extended944의 원래 internal boundary 8건과 Java ordered event/counter 10,124개 full parity는 이 12건과 다른 의무다. ordinary 836 + intent-not-reached diagnostic 100 raw 일치로 이 의무가 닫히지 않는다. 현재 Stage49 build05 portable 결과는 새 Stage50 runtime 검증도 아니다.
- Stage50 후보02의 source/required checks/native/portable를 먼저 닫고, 실행 중 Stage48/49 full regression은 actual terminal 이후 별도로 감사한다. 그때 새 결과와 원본 12건을 다시 비교해 다음 구현을 확정한다. 이 문서로 PLAN·mapping·기대 결과·미통과 상태를 수정하지 않는다.
