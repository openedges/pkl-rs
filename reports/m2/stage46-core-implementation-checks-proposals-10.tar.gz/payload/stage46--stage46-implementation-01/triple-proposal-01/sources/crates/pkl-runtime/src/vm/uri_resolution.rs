//! Declaration ModuleKey URI preparation. Triple-dot read resolution precedes
//! every ResourceManager lookup; import preparation precedes module evaluation.
use super::*;
use crate::modules::{
    ModuleCapabilities, ModuleHostError, ModuleIdentity, ModuleRequestKind, UnitId,
};
use std::collections::VecDeque;

struct Import {
    spec: modules::ImportSpec,
    origin: RuntimeFrame,
}
enum Target {
    Read(ReadRequest),
    Import {
        current: Import,
        remaining: VecDeque<Import>,
    },
}
pub(super) struct Resolution {
    module: ModuleIdentity,
    path: String,
    candidates: VecDeque<String>,
    target: Target,
}
impl Resolution {
    fn failure(&self, mut error: RuntimeError) -> RuntimeError {
        if let Target::Import { current, .. } = &self.target {
            error.frames.insert(0, current.origin.clone());
            error.span = Some(current.spec.span);
        }
        error
    }
    fn host_failure(&self, failure: ModuleHostError) -> RuntimeError {
        let error = match &self.target {
            Target::Import { current, .. } => failure.into_runtime(&current.spec.authored),
            Target::Read(request) => match failure {
                ModuleHostError::NotFound => crate::host::resources::missing(&request.uri),
                ModuleHostError::Io(cause) => {
                    let mut error = RuntimeError::host_language(format!(
                        "I/O error reading resource `{}`.",
                        request.uri
                    ));
                    error.hint = cause.message;
                    error
                }
                other => other.into_runtime(&request.uri),
            },
        };
        self.failure(error)
    }
}
impl Vm {
    pub(super) fn begin_read_resolution(
        &mut self,
        request: ReadRequest,
    ) -> Result<(), RuntimeError> {
        let Some(path) = crate::host::resources::read_triple_path(&request.uri)? else {
            return self.publish_read(request);
        };
        let uri = request.module_uri.clone().ok_or_else(|| {
            RuntimeError::new(
                ErrorKind::Unsupported,
                "Triple-dot reads require a declaration ModuleKey.",
            )
        })?;
        let module = self
            .program
            .units
            .iter()
            .filter_map(|unit| unit.identity.as_ref())
            .find(|identity| identity.original_uri == uri)
            .cloned()
            .unwrap_or(ModuleIdentity {
                original_uri: uri.clone(),
                resolved_uri: uri,
            });
        self.start_uri_resolution(Resolution {
            module,
            path,
            candidates: VecDeque::new(),
            target: Target::Read(request),
        })
    }

    fn publish_read(&mut self, request: ReadRequest) -> Result<(), RuntimeError> {
        if let Ok(uri) = crate::host::resources::resolved_uri(&request)
            && let Some(value) = self.resources.get(&crate::host::resources::cache_key(&uri))
        {
            self.stack.push(match value {
                Some(value) => value.clone(),
                None if request.nullable => Value::Null,
                None => return Err(crate::host::resources::missing(&request.uri)),
            });
            self.state = State::Running;
        } else {
            self.state = State::Waiting(PendingRequest::Read(request));
        }
        Ok(())
    }

    pub(super) fn prepare_module_imports(&mut self, unit: UnitId) -> Result<(), RuntimeError> {
        let mut imports = BTreeMap::new();
        for (block, code) in self.program.blocks.iter().enumerate() {
            for instruction in code {
                if let Instruction::ImportModule(spec) = instruction
                    && spec.unit == unit
                    && crate::host::resources::import_triple_path(&spec.authored)?.is_some()
                {
                    let metadata = &self.program.metadata[block];
                    imports.entry(spec.span).or_insert(Import {
                        spec: spec.clone(),
                        origin: RuntimeFrame {
                            source: metadata
                                .source
                                .clone()
                                .or_else(|| self.context.primary_source.clone()),
                            span: spec.span,
                            member: metadata.member.clone(),
                        },
                    });
                }
            }
        }
        let mut remaining = VecDeque::new();
        for span in &self.program.units[unit.0 as usize].import_order {
            if let Some(import) = imports.remove(span) {
                remaining.push_back(import);
            }
        }
        if !imports.is_empty() {
            return Err(invalid("import omitted from AST preparation order"));
        }
        let Some(mut current) = remaining.pop_front() else {
            return Ok(());
        };
        // Imported AST construction belongs to the importing call target. Its
        // source section remains the child's import operand.
        if self.frames.len() > 1 {
            let caller = &self.frames[self.frames.len() - 2];
            if caller
                .module_load
                .as_ref()
                .is_some_and(|run| run.initializing)
            {
                let metadata = &self.program.metadata[caller.block];
                let owner = metadata
                    .source
                    .as_ref()
                    .map_or(self.program.module_name.as_ref(), |source| {
                        &source.module_name
                    });
                for import in std::iter::once(&mut current).chain(&mut remaining) {
                    if let Some(source) = &mut import.origin.source {
                        Arc::make_mut(source).module_name = owner.into();
                    }
                    import.origin.member = caller
                        .diagnostic_member
                        .clone()
                        .unwrap_or_else(|| metadata.member.clone());
                }
            }
        }
        let module = self.program.units[unit.0 as usize]
            .identity
            .clone()
            .ok_or_else(|| {
                RuntimeError::new(
                    ErrorKind::Unsupported,
                    "Triple-dot imports require a declaration ModuleKey.",
                )
            })?;
        let path = crate::host::resources::import_triple_path(&current.spec.authored)?.unwrap();
        self.start_uri_resolution(Resolution {
            module,
            path,
            candidates: VecDeque::new(),
            target: Target::Import { current, remaining },
        })
    }

    fn start_uri_resolution(&mut self, run: Resolution) -> Result<(), RuntimeError> {
        let request = ModuleRequestKind::Capabilities {
            module: run.module.clone(),
        };
        self.frames
            .last_mut()
            .expect("URI preparation frame")
            .uri_resolution = Some(run);
        self.wait_module(request)
    }

    pub(super) fn resolved_capabilities(
        &mut self,
        result: Result<ModuleCapabilities, ModuleHostError>,
    ) -> Result<(), RuntimeError> {
        let mut run = self
            .frames
            .last_mut()
            .and_then(|frame| frame.uri_resolution.take())
            .ok_or_else(|| invalid("missing URI capabilities continuation"))?;
        let caps = result.map_err(|error| run.host_failure(error))?;
        run.candidates =
            crate::host::resources::triple_candidates(&run.module.original_uri, &run.path, caps)
                .map_err(|error| run.failure(error))?
                .into();
        self.next_uri_candidate(run)
    }
    fn next_uri_candidate(&mut self, mut run: Resolution) -> Result<(), RuntimeError> {
        let Some(uri) = run.candidates.pop_front() else {
            return Err(run.host_failure(ModuleHostError::NotFound));
        };
        let request = ModuleRequestKind::HasElement {
            module: run.module.clone(),
            element_uri: uri.into(),
        };
        self.frames.last_mut().unwrap().uri_resolution = Some(run);
        self.wait_module(request)
    }
    pub(super) fn resolved_element(
        &mut self,
        result: Result<bool, ModuleHostError>,
    ) -> Result<(), RuntimeError> {
        let State::Waiting(PendingRequest::Module(request)) = &self.state else {
            return Err(invalid("missing element request"));
        };
        let ModuleRequestKind::HasElement { element_uri, .. } = &request.kind else {
            return Err(invalid("wrong URI preparation effect"));
        };
        let uri = element_uri.clone();
        let run = self
            .frames
            .last_mut()
            .and_then(|frame| frame.uri_resolution.take())
            .ok_or_else(|| invalid("missing element continuation"))?;
        if !result.map_err(|error| run.host_failure(error))? {
            return self.next_uri_candidate(run);
        }
        match run.target {
            Target::Read(mut request) => {
                request.resolved_uri = Some(uri);
                self.publish_read(request)
            }
            Target::Import {
                current,
                mut remaining,
            } => {
                let (absolute, original) = crate::host::resources::prepare_module_uri(&uri, None)?;
                for code in &mut Arc::make_mut(&mut self.program).blocks {
                    for instruction in code {
                        if let Instruction::ImportModule(spec) = instruction
                            && spec.unit == current.spec.unit
                            && spec.span == current.spec.span
                        {
                            spec.absolute_uri = absolute.clone().into();
                            spec.original_uri = original.clone().into();
                        }
                    }
                }
                if let Some(current) = remaining.pop_front() {
                    let path = crate::host::resources::import_triple_path(&current.spec.authored)?
                        .unwrap();
                    self.start_uri_resolution(Resolution {
                        module: run.module,
                        path,
                        candidates: VecDeque::new(),
                        target: Target::Import { current, remaining },
                    })
                } else {
                    self.state = State::Running;
                    Ok(())
                }
            }
        }
    }
}

/// Pinned AstBuilder visits module declarations by category, class properties
/// before methods, and object members in their authored sequence. Keep this
/// ordering independently from bytecode block allocation and source offsets.
pub(super) fn module_import_order(module: &crate::syntax::Module) -> Vec<Span> {
    use crate::syntax::{Expr, ExprKind as E, Member, ObjectMember as O, Type, TypeKind as T};
    enum Visit<'a> {
        Expr(&'a Expr),
        Member(&'a Member),
        Object(&'a O),
        Type(&'a Type),
        Import(Span),
    }
    fn method(member: &Member) -> bool {
        matches!(member.expr.kind, E::Function { method: true, .. })
    }
    fn member_category(member: &Member) -> usize {
        match member.expr.kind {
            E::Class { .. } => 0,
            E::TypeAlias { .. } => 1,
            _ if method(member) => 3,
            _ => 2,
        }
    }
    let clause = |member: &Member| {
        matches!(member.expr.kind, E::Import { .. })
            && module.source[member.span.start..].starts_with("import")
    };
    let mut ordered = module
        .members
        .iter()
        .filter(|m| clause(m))
        .map(Visit::Member)
        .collect::<Vec<_>>();
    if let Some(declaration) = &module.declaration {
        ordered.extend(declaration.annotations.iter().map(Visit::Expr));
        if let Some(parent) = &declaration.parent {
            ordered.push(Visit::Import(parent.span));
        }
    }
    for category in 0..4 {
        ordered.extend(
            module
                .members
                .iter()
                .filter(|m| !clause(m) && member_category(m) == category)
                .map(Visit::Member),
        );
    }
    let mut work = ordered.into_iter().rev().collect::<Vec<_>>();
    let mut result = Vec::new();
    while let Some(visit) = work.pop() {
        let mut children = Vec::new();
        match visit {
            Visit::Import(span) => result.push(span),
            Visit::Member(member) => {
                children.extend(member.annotations.iter().map(Visit::Expr));
                children.push(Visit::Expr(&member.expr));
                children.extend(member.ty.iter().map(Visit::Type));
            }
            Visit::Type(ty) => match &ty.kind {
                T::Named { arguments, .. }
                | T::Union {
                    types: arguments, ..
                } => children.extend(arguments.iter().map(Visit::Type)),
                T::Nullable(inner) => children.push(Visit::Type(inner)),
                T::Constrained { base, constraints } => {
                    children.push(Visit::Type(base));
                    children.extend(constraints.iter().map(Visit::Expr));
                }
                T::Function {
                    parameters,
                    return_type,
                } => {
                    children.extend(parameters.iter().map(Visit::Type));
                    children.push(Visit::Type(return_type));
                }
                _ => (),
            },
            Visit::Object(member) => match member {
                O::Property(member) => children.push(Visit::Member(member)),
                O::Element { value, .. } | O::Spread { value, .. } => {
                    children.push(Visit::Expr(value))
                }
                O::Entry { key, value, .. } => {
                    children.extend([Visit::Expr(key), Visit::Expr(value)])
                }
                O::Predicate {
                    condition, value, ..
                } => children.extend([Visit::Expr(condition), Visit::Expr(value)]),
                O::When {
                    condition,
                    then_members,
                    else_members,
                    ..
                } => {
                    children.push(Visit::Expr(condition));
                    children.extend(then_members.iter().chain(else_members).map(Visit::Object));
                }
                O::For {
                    iterable, members, ..
                } => {
                    children.push(Visit::Expr(iterable));
                    children.extend(members.iter().map(Visit::Object));
                }
            },
            Visit::Expr(expr) => match &expr.kind {
                E::Import { uri_span, .. } => result.push(*uri_span),
                E::Class {
                    superclass,
                    members,
                    ..
                } => {
                    children.extend(superclass.iter().map(Visit::Type));
                    for methods in [false, true] {
                        children.extend(
                            members
                                .iter()
                                .filter(|member| method(member) == methods)
                                .map(Visit::Member),
                        );
                    }
                }
                E::TypeAlias { ty, .. } => children.push(Visit::Type(ty)),
                E::Object { parent, members } => {
                    children.extend(parent.iter().map(|parent| Visit::Expr(parent)));
                    children.extend(members.iter().map(Visit::Object));
                }
                E::New { ty, members } | E::Annotation { ty, members, .. } => {
                    children.push(Visit::Type(ty));
                    children.extend(members.iter().map(Visit::Object));
                }
                E::TypeCheck { value, ty } | E::TypeCast { value, ty } => {
                    children.extend([Visit::Expr(value), Visit::Type(ty)])
                }
                E::Function {
                    body,
                    parameters,
                    return_type,
                    ..
                } => {
                    children.push(Visit::Expr(body));
                    children.extend(
                        parameters
                            .iter()
                            .filter_map(|p| p.ty.as_ref())
                            .map(Visit::Type),
                    );
                    children.extend(return_type.iter().map(Visit::Type));
                }
                E::Let {
                    ty, value, body, ..
                } => {
                    children.push(Visit::Expr(value));
                    children.extend(ty.iter().map(Visit::Type));
                    children.push(Visit::Expr(body));
                }
                _ => children.extend(expr.expression_children().into_iter().map(Visit::Expr)),
            },
        }
        work.extend(children.into_iter().rev());
    }
    result
}

pub(super) fn expression_import_order(
    expression: &crate::syntax::Expr,
    source: Arc<str>,
) -> Vec<Span> {
    let module = crate::syntax::Module {
        source,
        declaration: None,
        members: vec![crate::syntax::Member {
            annotations: Vec::new(),
            name: String::new(),
            name_span: expression.span,
            expr: expression.clone(),
            span: Span::new(0, expression.span.end),
            local: true,
            ty: None,
            modifiers: Vec::new(),
            override_fixed_span: None,
            override_const_span: None,
        }],
        folded_integer_spans: BTreeMap::new(),
        interpolation_spans: BTreeMap::new(),
    };
    module_import_order(&module)
}
