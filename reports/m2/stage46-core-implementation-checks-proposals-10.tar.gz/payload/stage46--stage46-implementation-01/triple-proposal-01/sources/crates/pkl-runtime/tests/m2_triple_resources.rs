//! Shared ModuleKey preparation and ResourceManager boundaries. Actual File
//! oracle captures remain separate from these typed Host regressions.
use pkl_runtime::{
    modules::{ModuleCompletion, ModuleHostError},
    probe::{SourceEvent, SourceProbe},
    resources::ReadResult,
};
fn probe(source: &str, expressions: &[&str]) -> SourceProbe {
    SourceProbe::new_expressions_text(
        source,
        "file:///one/two/main.pkl",
        "main",
        &expressions.iter().map(|s| (*s).into()).collect::<Vec<_>>(),
        "compact",
        false,
        false,
        false,
    )
    .unwrap()
}
fn next(p: &mut SourceProbe) -> SourceEvent {
    for _ in 0..100_000 {
        let e = p.poll(0, 1).unwrap();
        p.collect();
        if e.kind != "yield" {
            return e;
        }
    }
    panic!("did not settle")
}
fn capabilities(p: &mut SourceProbe) {
    let e = next(p);
    assert_eq!(e.kind, "module-request");
    assert_eq!(e.module.unwrap().kind, "capabilities");
    p.complete_module_capabilities(e.token.as_deref().unwrap(), true, true, false, 0)
        .unwrap();
}
fn element(p: &mut SourceProbe, expected: &str, exists: bool) {
    let e = next(p);
    assert_eq!(e.kind, "module-request");
    let m = e.module.unwrap();
    assert_eq!(m.kind, "has-element");
    assert_eq!(m.original_uri, expected);
    p.complete_module_has_element(e.token.as_deref().unwrap(), exists, 0)
        .unwrap();
}
fn value(e: SourceEvent) -> String {
    assert_eq!(e.kind, "value", "{e:?}");
    String::from_utf16(&e.value.unwrap()).unwrap()
}

#[test]
fn module_key_search_precedes_every_resource_cache_lookup() {
    let mut p = probe(
        "a=read(\".../resource.txt\")\nb=read?(\".../resource.txt\")",
        &["a", "b"],
    );
    for index in 0..2 {
        p.start_path(index, 0, None).unwrap();
        capabilities(&mut p);
        element(&mut p, "file:///one/resource.txt", true);
        if index == 0 {
            let e = next(&mut p);
            assert_eq!(e.kind, "read");
            let t = e.token.unwrap();
            assert_eq!(p.resolved_read_uri(&t).unwrap(), "file:///one/resource.txt");
            p.complete_read(&t, Ok(ReadResult::Text("cached".into())), 0)
                .unwrap();
        }
        assert_eq!(value(next(&mut p)), "cached");
    }
    p.close();
    assert_eq!(p.collect().slots, 0);
}

#[test]
fn nullable_search_missing_is_an_error_before_any_resource_read() {
    let mut p = probe("a=read?(\".../missing\")", &["a"]);
    p.start_path(0, 0, None).unwrap();
    capabilities(&mut p);
    element(&mut p, "file:///one/missing", false);
    element(&mut p, "file:///missing", false);
    let e = next(&mut p);
    assert_eq!(e.kind, "error");
    assert!(
        String::from_utf16(e.error.as_ref().unwrap())
            .unwrap()
            .contains("Cannot find resource `.../missing`.")
    );
}

#[test]
fn unused_import_and_nested_method_are_prepared_in_astbuilder_order() {
    let mut p = probe(
        "function unused() = import(\".../method.pkl\")\nx=import(\".../property.pkl\")\nstable=7",
        &["stable"],
    );
    p.start_path(0, 0, None).unwrap();
    capabilities(&mut p);
    // Java visits class/module property bodies before method bodies.
    element(&mut p, "file:///one/property.pkl", true);
    capabilities(&mut p);
    element(&mut p, "file:///one/method.pkl", true);
    assert_eq!(value(next(&mut p)), "7");
}

#[test]
fn eager_missing_unused_import_is_retained_on_repeated_module_calls() {
    let mut p = probe(
        "unused=import(\".../missing.pkl\")\nlazy=read(\"res:/unused\")\nstable=7",
        &["stable", "lazy"],
    );
    p.start_path(0, 0, None).unwrap();
    capabilities(&mut p);
    element(&mut p, "file:///one/missing.pkl", false);
    element(&mut p, "file:///missing.pkl", false);
    let first = next(&mut p);
    assert_eq!(first.kind, "error");
    p.start_path(1, 0, None).unwrap();
    let second = next(&mut p);
    assert_eq!(second.error, first.error);
}

#[test]
fn unrequested_query_ast_does_not_run_import_preparation() {
    let mut p = probe("stable=7", &["stable", "import(\".../future.pkl\")"]);
    p.start_path(0, 0, None).unwrap();
    assert_eq!(value(next(&mut p)), "7");
    p.start_path(1, 0, None).unwrap();
    let e = next(&mut p);
    assert_eq!(e.module.unwrap().kind, "capabilities");
    p.complete_module_capabilities(e.token.as_deref().unwrap(), false, false, false, 0)
        .unwrap();
    assert_eq!(next(&mut p).kind, "error");
}

#[test]
fn module_key_security_denial_precedes_cached_read_and_invalid_completion_keeps_token() {
    let mut p = probe(
        "a=read(\"file:///one/item\")\nb=read(\".../item\")",
        &["a", "b"],
    );
    p.start_path(0, 0, None).unwrap();
    let e = next(&mut p);
    p.complete_read(
        e.token.as_deref().unwrap(),
        Ok(ReadResult::Text("cached".into())),
        0,
    )
    .unwrap();
    assert_eq!(value(next(&mut p)), "cached");
    p.start_path(1, 0, None).unwrap();
    capabilities(&mut p);
    let e = next(&mut p);
    let token = e.token.unwrap();
    assert!(
        p.complete_module(
            &token,
            ModuleCompletion::Source(Err(ModuleHostError::NotFound)),
            0
        )
        .is_err()
    );
    p.complete_module(
        &token,
        ModuleCompletion::HasElement(Err(ModuleHostError::SecurityManagerException {
            message: Some("typed ModuleKey denial".into()),
        })),
        0,
    )
    .unwrap();
    let error = next(&mut p);
    assert_eq!(error.kind, "error");
    assert!(
        String::from_utf16(error.error.as_ref().unwrap())
            .unwrap()
            .contains("typed ModuleKey denial")
    );
}
