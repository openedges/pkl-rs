"""Independent terminal-only Stage45 regression audit. Never acquire or build."""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
MAIN = ROOT.parent / "pkl-rs"
OUT = Path(__file__).resolve().parent
COMMIT = "01971d0c0a231132bcb30a7dae6ac244b7fed953"
LANG = ROOT / "target/m2/stage45-language-final-01"
LIFE = ROOT / "target/m2/stage45-class-lifecycle-final-01"
WRAPPER = ROOT / "target/m2/stage45-full-regression-01"
CASE = "pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/basic/import1b.pkl"
BASE_NAMES = ["stage44-final-summary.json", "stage44-final-raw-changes.json", "stage44-final-source-map.json", "stage44-final-regression-captures.json"]
COMMANDS = ["language-acquire", "language-verify-report", "language-verify-development", "language-verify-subset", "language-verify-full", "lifecycle-acquire", "lifecycle-verify-report", "lifecycle-verify-contract"]
INTEGRITY_COMMANDS = {"language-acquire", "language-verify-report", "lifecycle-acquire", "lifecycle-verify-report"}
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")

def git(*args, cwd=ROOT):
    return subprocess.check_output(["git", *args], cwd=cwd)

def safe(name):
    path = Path(name)
    assert not path.is_absolute() and ".." not in path.parts, name
    return path

def inventory(directory):
    """Exact cache pruning before descent; no basename or alias traversal."""
    excluded = {directory / "build", directory / "jvm-classpath/build"}
    rows = {}
    pruned = []
    for current, dirs, files in os.walk(directory, topdown=True, followlinks=False):
        current = Path(current)
        keep = []
        for name in sorted(dirs):
            child = current / name
            if child in excluded:
                pruned.append(str(child))
                continue
            assert not child.is_symlink(), str(child)
            keep.append(name)
        dirs[:] = keep
        for name in sorted(files):
            child = current / name
            assert child.is_file() and not child.is_symlink(), str(child)
            if child == directory / "report.json":
                continue
            raw = child.read_bytes()
            rows[child.relative_to(directory).as_posix()] = {"sha256": sha(raw), "bytes": len(raw)}
    return rows, pruned

def capture(directory):
    metadata = load(directory / "result.json")
    values = {channel: (directory / (channel + ".bin")).read_bytes() for channel in ["stdout", "stderr"]}
    assert all(sha(values[channel]) == metadata["sha256"][channel] for channel in values)
    files = {}
    folder = directory / "files"
    if folder.exists():
        for current, dirs, names in os.walk(folder, topdown=True, followlinks=False):
            assert all(not (Path(current) / name).is_symlink() for name in dirs)
            for name in names:
                path = Path(current) / name
                assert path.is_file() and not path.is_symlink()
                files[path.relative_to(folder).as_posix()] = path.read_bytes()
    assert {name: sha(raw) for name, raw in files.items()} == metadata["files"]
    return {**values, "files": files, "exit_code": metadata["exit_code"], "timed_out": metadata["timed_out"], "workspace_changes": metadata["workspace_changes"]}

def cli_status(java, rust, expected_exit):
    if java["workspace_changes"]:
        return "oracle-error"
    if rust["workspace_changes"]:
        return "candidate-environment-error"
    if java["timed_out"] or java["exit_code"] not in [0, 1]:
        return "oracle-error"
    if java["exit_code"] == 1 and not java["stderr"].startswith("–– Pkl Error ––\n".encode()):
        return "oracle-error"
    if java["exit_code"] not in expected_exit:
        return "oracle-contract-mismatch"
    if rust["timed_out"]:
        return "candidate-timeout"
    if rust["exit_code"] in [2, 3, 4]:
        return {2: "candidate-unsupported", 3: "candidate-limit-exceeded", 4: "candidate-internal-error"}[rust["exit_code"]]
    return "pass" if java == rust else "mismatch"

def valid_outcome(raw):
    prefix = b"pkl-exception\torg.pkl.core."
    return raw.startswith(prefix) and raw.endswith(b"\n") and bool(raw[len(prefix):-1]) and all(byte in b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_$" for byte in raw[len(prefix):-1])

def full_failures(manifest, results):
    by_id = {row["id"]: row for row in results}
    failures = []
    if len(by_id) != len(results):
        failures.append("duplicate execution results")
    for row in manifest["requirements"]:
        if not row["required"]:
            continue
        if row["implementation"]["state"] != "implemented" or not row["implementation"]["links"]:
            failures.append("implementation incomplete: " + row["id"])
        if row["tests"]["state"] != "mapped" or not row["tests"]["case_ids"]:
            failures.append("test mapping incomplete: " + row["id"])
        elif any(by_id.get(identifier, {}).get("status") != "pass" for identifier in row["tests"]["case_ids"]):
            failures.append("requirement execution incomplete: " + row["id"])
    for row in manifest["cases"]:
        if row["required"] and (not row["requirements"] or row["execution"]["state"] != "ready" or by_id.get(row["id"], {}).get("status") != "pass"):
            failures.append("required case incomplete: " + row["id"])
    return failures

def metamorphic(manifest):
    definitions = {tuple(case["metamorphic_relation"]["case_ids"]): case["metamorphic_relation"] for case in manifest["cases"] if "metamorphic_relation" in case}
    results = []
    for identifiers, relation in sorted(definitions.items()):
        statuses = {}
        for runtime in ["java", "rust"]:
            captures = []
            for identifier in identifiers:
                folder = LANG / "cases" / identifier
                process = load(folder / (runtime + ".process.json"))
                captures.append((process["exit_code"], process["timed_out"], (folder / (runtime + ".stdout.bin")).read_bytes(), (folder / (runtime + ".stderr.bin")).read_bytes()))
            statuses[runtime] = all(row[:2] == (0, False) and row[3] == b"" for row in captures) and len(set(captures)) == 1
        results.append({**relation, "runtimes": statuses, "status": "pass" if all(statuses.values()) else "mismatch"})
    return results

def scalar_status(case, row):
    folder = LANG / "cases" / row["id"]
    values = {}
    for runtime in ["java", "rust"]:
        process = load(folder / (runtime + ".process.json"))
        assert process == row[runtime]
        raw = [(folder / (runtime + "." + channel + ".bin")).read_bytes() for channel in ["stdout", "stderr"]]
        assert all(sha(data) == process[channel + "_sha256"] for channel, data in zip(["stdout", "stderr"], raw))
        values[runtime] = [process["exit_code"], *raw]
    java, rust = values["java"], values["rust"]
    outcome = (folder / "java.outcome.bin").read_bytes()
    assert sha(outcome) == row["java"]["outcome_sha256"]
    expected = 0 if case["expected_outcome"] == "success" else 1
    java_ok = not row["java"]["timed_out"] and java[0] == expected and (not java[2] and outcome == b"success\n" if expected == 0 else not java[1] and bool(java[2]) and valid_outcome(outcome))
    return "oracle-error" if not java_ok else "candidate-timeout" if row["rust"]["timed_out"] else "pass" if java == rust else "mismatch"

def tree(commit, repository=ROOT):
    rows = {}
    for item in git("ls-tree", "-rz", commit, cwd=repository).split(b"\0"):
        if item:
            meta, name = item.split(b"\t", 1)
            mode, kind, oid = meta.decode().split()
            rows[name.decode()] = (mode, kind, oid)
    return rows

def prepare():
    assert not (OUT / "prepared.json").exists(), "Preserve previous preparation."
    inputs = {}
    for name in BASE_NAMES:
        source = MAIN / "reports/m2" / name
        raw = source.read_bytes()
        copy = OUT / "baseline" / name
        copy.parent.mkdir(exist_ok=True)
        copy.write_bytes(raw)
        inputs[str(source)] = sha(raw)
    summary = load(OUT / "baseline/stage44-final-summary.json")
    captures = load(OUT / "baseline/stage44-final-regression-captures.json")
    for key, name in [("source_map", "stage44-final-source-map.json"), ("raw_changes", "stage44-final-raw-changes.json"), ("captures", "stage44-final-regression-captures.json")]:
        assert summary[key]["sha256"] == sha((OUT / "baseline" / name).read_bytes())
    archive = MAIN / captures["archive"]["path"]
    assert sha(archive.read_bytes()) == captures["archive"]["sha256"]
    inputs[str(archive)] = captures["archive"]["sha256"]
    expected = git("show", COMMIT + ":compatibility/m2-language.json")
    (OUT / "expected-contract.json").write_bytes(expected)
    wrapper = (WRAPPER / "run.py").read_bytes()
    (OUT / "wrapper-run.py").write_bytes(wrapper)
    write("prepared.json", {
        "schema": 1, "status": "Audit prepared only; no Stage45 result was read or classified.",
        "implementation_commit": COMMIT, "baseline_input_sha256": inputs,
        "expected_contract_sha256": sha(expected), "wrapper_source_sha256": sha(wrapper),
        "expected": {"case_definitions": 4527, "requirements": 475, "selected": 3664,
                     "one_case_mapping_change": CASE, "case_fields": ["adapter", "execution", "execution_profile"],
                     "sequence_executions": 334, "persistent_calls_per_language": 2782,
                     "persistent_equality_channels": ["status", "stdout", "stderr"],
                     "baseline_language_statuses": summary["status_counts"], "baseline_full_gate_reasons": summary["full_gate_failure_reasons"]},
        "terminal_guard": "--audit refuses until process-report.complete and all8commands have final return codes. Optional root terminal receipt distinguishes wrapper OS exit from recorded child exits.",
        "planned_checks": ["Published Stage44 pointer/archive integrity", "4527originalID/order and requirements475", "Same selected3664ID/order; explicit one-row JVM-profile mapping", "Independent raw status reconstruction and nonpass transitions", "Parent/child artifact,source,oracle,profile and original input binding", "Exact declared payload/path coverage with build cache pruning before walking", "334persistent sequences/2782ordered calls, raw statuses/stdout/stderr and retained error classes", "All captured source blobs bound to01971d0/pinned references", "Hash-only raw/source changes, no diagnostic/path normalization", "Separate wrapper/child terminal provenance and all strict failures", "Later publication archives/index/source-binding review remains separate"],
        "no_acquisition_tests_builds_java_git_or_source_changes": True, "actual_audit_run": False,
    })
    print("Prepared only; no Stage45 completion or passing result claimed.")

def baseline_archive():
    prepared = load(OUT / "prepared.json")
    for name, expected in prepared["baseline_input_sha256"].items():
        assert sha(Path(name).read_bytes()) == expected
    captures = load(OUT / "baseline/stage44-final-regression-captures.json")
    with tarfile.open(MAIN / captures["archive"]["path"], "r:gz") as archive:
        members = archive.getmembers()
        indexed = {member.name: member for member in members}
        assert len(indexed) == len(members)
        assert all(member.isfile() and safe(member.name) for member in members)
        declared = json.load(archive.extractfile(indexed["EVIDENCE.json"]))["files"]
        rows = {row["path"]: row for row in declared}
        assert len(rows) == len(declared) and rows.keys() == indexed.keys() - {"EVIDENCE.json"}
        data = {}
        for name, member in indexed.items():
            if name == "EVIDENCE.json":
                continue
            raw = archive.extractfile(member).read()
            assert sha(raw) == rows[name]["sha256"] and len(raw) == rows[name]["bytes"]
            data[name] = raw
    assert len(rows) == captures["payload_files"] and sum(row["bytes"] for row in rows.values()) == captures["payload_bytes"]
    return data

def audit(terminal_receipt):
    assert not (OUT / "report.json").exists(), "Preserve previous audit."
    driver = load(WRAPPER / "process-report.json")
    assert driver.get("complete") is True, "Acquisition/wrapper not terminal: no audit or closure claim."
    assert [row["label"] for row in driver["commands"]] == COMMANDS
    assert driver["commit"] == COMMIT and not driver["infrastructureFailures"]
    assert all(type(row.get("returncode")) is int for row in driver["commands"])
    assert sha((WRAPPER / "run.py").read_bytes()) == driver["runnerSha256"] == load(OUT / "prepared.json")["wrapper_source_sha256"]
    for row in driver["commands"]:
        assert row["requiresZeroForIntegrity"] == (row["label"] in INTEGRITY_COMMANDS)
        if row["label"] in INTEGRITY_COMMANDS:
            assert row["returncode"] == 0
        else:
            assert row["returncode"] in [0, 1], "Usage/infrastructure exit must not be relabeled strict failure."
        for channel in ["stdout", "stderr"]:
            assert sha((WRAPPER / (row["label"] + "." + channel + ".bin")).read_bytes()) == row[channel + "_sha256"]
    old = baseline_archive()
    old_lang = json.loads(old["language/report.json"])
    old_life = json.loads(old["lifecycle/report.json"])
    baseline_summary = load(OUT / "baseline/stage44-final-summary.json")
    assert sha(old["language/report.json"]) == baseline_summary["raw"]["language"]["report_sha256"]
    assert sha(old["lifecycle/report.json"]) == baseline_summary["raw"]["lifecycle"]["report_sha256"]
    lang = load(LANG / "report.json")
    life = load(LIFE / "report.json")
    manifests = {"old": json.loads(old["language/sources/compatibility/m2-language.json"]), "new": load(LANG / "sources/compatibility/m2-language.json")}
    assert (LANG / "sources/compatibility/m2-language.json").read_bytes() == (OUT / "expected-contract.json").read_bytes()
    before, after = manifests["old"], manifests["new"]
    assert len(before["cases"]) == len(after["cases"]) == 4527 and len(before["requirements"]) == len(after["requirements"]) == 475
    assert [row["id"] for row in before["cases"]] == [row["id"] for row in after["cases"]]
    assert [(row["id"], row["required"]) for row in before["requirements"]] == [(row["id"], row["required"]) for row in after["requirements"]]
    changed = [{"id": a["id"], "fields": sorted(key for key in a.keys() | b.keys() if a.get(key) != b.get(key)), "before": a, "after": b} for a, b in zip(before["cases"], after["cases"]) if a != b]
    assert len(changed) == 1 and changed[0]["id"] == CASE and changed[0]["fields"] == ["adapter", "execution", "execution_profile"]
    assert after["counts"]["cases_by_execution"] == {"ready": 3664, "unimplemented": 823, "unmapped": 40}
    for name in ["compatibility/corpus.json", "compatibility/m2-module-eval.json"]:
        assert old["language/sources/" + name] == (LANG / "sources" / name).read_bytes()
    assert lang["selection"]["case_ids"] == old_lang["selection"]["case_ids"]
    assert [row["id"] for row in lang["results"]] == lang["selection"]["case_ids"]
    assert len(lang["results"]) == lang["selected_count"] == 3664 and len(set(lang["selection"]["case_ids"])) == 3664
    inventories = {}
    pruned = {}
    for label, directory, report in [("language", LANG, lang), ("lifecycle", LIFE, life)]:
        inventories[label], pruned[label] = inventory(directory)
        assert {name: row["sha256"] for name, row in inventories[label].items()} == report["evidence_sha256"]
    assert lang["source_stability"] and lang["artifact_stability"]
    assert life["source_stability_before_execution"] and life["source_stability_after_execution"] and not life["acquisition_error"]
    case_by_id = {case["id"]: case for case in after["cases"]}
    reconstructed = {}
    for row in lang["results"]:
        case = case_by_id[row["id"]]
        if row.get("adapter") == "language-jvm-classpath-output":
            continue
        if row.get("adapter") == "language-module-eval":
            folder = LANG / "cases" / row["directory"]
            captures = {runtime: capture(folder / runtime) for runtime in ["java", "rust"]}
            for runtime in captures:
                assert load(folder / runtime / "process.json") == row[runtime]
            reconstructed[row["id"]] = cli_status(captures["java"], captures["rust"], case["upstream_case"]["expected_exit"])
        else:
            reconstructed[row["id"]] = scalar_status(case, row)
        assert reconstructed[row["id"]] == row["status"]
    context = lang["classpath_eval"]
    child_directory = LANG / "jvm-classpath"
    child_raw = (child_directory / "report.json").read_bytes()
    child = json.loads(child_raw)
    assert sha(child_raw) == context["child_report_sha256"] and context["directory"] == "jvm-classpath" and context["parent_output"] == str(LANG)
    assert child["sources"] == child["sources_after"] == lang["source_sha256"] and child["oracle"] == lang["oracle"]
    for name, digest in child["sources"].items():
        assert sha((child_directory / "sources" / safe(name)).read_bytes()) == digest
    assert child["profile"] == load(LANG / "sources/compatibility/m2-jvm-classpath.json")
    assert child["original_case"] == case_by_id[CASE]["upstream_case"] and child["original_cli_contract_preserved"] is True
    assert child["full_m2_complete"] is False and child["output"] == str(child_directory)
    child_inventory = {name[len("jvm-classpath/"):]: row["sha256"] for name, row in inventories["language"].items() if name.startswith("jvm-classpath/") and name != "jvm-classpath/report.json"}
    assert child_inventory == child["files"]
    assert child["workspace"] == context["workspace"] and not Path(context["workspace"]).is_relative_to(LANG)
    assert child["candidate"]["source_binding"] == "unbound-caller-supplied" and child["candidate"]["original_path"] == str(LANG / "artifacts/jvm_snippet_probe")
    assert child["candidate"]["sha256"] == lang["classpath_candidate"]["sha256"]
    assert child["artifacts_before"] == child["artifacts_after"] and [row["name"] for row in child["commands"]] == ["javac"]
    assert not (child_directory / "build").exists()
    for name, digest in child["artifacts_before"].items():
        assert sha((child_directory / "artifacts" / safe(name)).read_bytes()) == digest
    repetitions = []
    for index, row in enumerate(child["results"]):
        java, rust = [capture(child_directory / "cases" / str(index) / runtime) for runtime in ["java", "rust"]]
        outcome = (child_directory / "cases" / str(index) / "java/outcome.bin").read_bytes()
        assert outcome == b"success\n" and java["exit_code"] == 0 and not java["timed_out"] and not java["stderr"] and not java["workspace_changes"]
        status = "candidate-timeout" if rust["timed_out"] else {2: "candidate-unsupported", 3: "candidate-limit-exceeded", 4: "candidate-internal-error"}.get(rust["exit_code"], "pass" if java == rust else "mismatch")
        assert row["status"] == status
        staged_input = Path(context["workspace"]) / case_by_id[CASE]["input"]
        staged_classpath = Path(context["workspace"]) / "external/pkl/pkl-core/src/test/resources"
        assert sha(staged_input.read_bytes()) == case_by_id[CASE]["input_sha256"]
        for runtime in ["java", "rust"]:
            process = load(child_directory / "cases" / str(index) / runtime / "process.json")
            assert process == row["processes"][runtime]
            assert process["source_uri"] == staged_input.as_uri() and process["classpath_root"] == str(staged_classpath)
            assert process["cwd"] == str(Path(context["workspace"]) / child["original_case"]["cwd"])
            if runtime == "rust":
                assert process["command"] == [str(child_directory / "artifacts/jvm_snippet_probe"), str(staged_input), str(staged_classpath)]
            else:
                assert process["command"][-2:] == ["M2JvmSnippetOutputProbe", str(staged_input)]
                cp = process["command"][process["command"].index("-cp") + 1]
                assert cp == os.pathsep.join(map(str, [child_directory / "artifacts/pkl-tools-0.32.0.jar", child_directory / "artifacts/java", staged_classpath]))
        repetitions.append((java, rust))
    assert len(repetitions) == 2
    repeat_stable = all(repetitions[0][index] == repetitions[1][index] for index in [0, 1])
    child_status = "pass" if repeat_stable and all(row["status"] == "pass" for row in child["results"]) else next((row["status"] for row in child["results"] if row["status"] != "pass"), "mismatch")
    mapped = next(row for row in lang["results"] if row["id"] == CASE)
    assert mapped["status"] == child_status and mapped["execution_profile"] == case_by_id[CASE]["execution_profile"] and mapped["child_report_sha256"] == sha(child_raw)
    reconstructed[CASE] = child_status
    assert dict(Counter(reconstructed.values())) == lang["status_counts"]
    assert metamorphic(after) == lang["metamorphic_results"] and len(lang["metamorphic_results"]) == 88
    assert full_failures(after, lang["results"]) == lang["full_gate_failures"]
    for report in [lang, life]:
        assert report["oracle"]["artifact_sha256"] == old_lang["oracle"]["artifact_sha256"]
        for key in ["executable_sha256", "runtime_modules_sha256", "release_sha256"]:
            assert report["oracle"]["jdk"][key] == old_lang["oracle"]["jdk"][key]
    build = load(LANG / "build.process.json")
    assert build["exit_code"] == 0 and not build["timed_out"]
    expected_build = ["cargo", "build", "-p", "pkl-runtime", "--locked", "--release"]
    for name, key in [("language_probe", "candidate"), ("module_eval_probe", "module_candidate"), ("jvm_snippet_probe", "classpath_candidate")]:
        claim = lang[key]
        assert claim["build"] == build and claim["source_binding"] == "recorded-build" and claim["path"] == str(ROOT / "target/release/examples" / name)
        assert sha((LANG / "artifacts" / name).read_bytes()) == claim["sha256"]
        expected_build += ["--example", name]
    assert build["command"] == expected_build + ["--target-dir", str(ROOT / "target")]
    assert life["languages"] == ["java", "rust"] and life["repetitions"] == 2 and life["comparison_channels"] == ["status", "stdout", "stderr"]
    assert [(row["id"], row["repetition"]) for row in life["cases"]] == [(row["id"], row["repetition"]) for row in old_life["cases"]]
    assert len(life["cases"]) == 334
    calls, life_mismatches, classes = 0, [], 0
    life_statuses = {runtime: Counter() for runtime in ["java", "rust"]}
    for row in life["cases"]:
        java, rust = [row["observations"]["processes"][runtime]["calls"] for runtime in ["java", "rust"]]
        assert len(java) == len(rust) == len(row["observations"]["comparisons"])
        for left, right, comparison in zip(java, rust, row["observations"]["comparisons"]):
            assert left["index"] == right["index"] and left["expression"] == right["expression"]
            equal = True
            for channel in ["status", "stdout", "stderr", "error-class"]:
                raw = [(LIFE / row["directory"] / runtime / f"{call['index']}.{channel}.bin").read_bytes() for runtime, call in [("java", left), ("rust", right)]]
                for call, data in zip([left, right], raw):
                    assert call["channels"][channel] == {"bytes": len(data), "sha256": sha(data)}
                if channel == "error-class":
                    classes += raw[0] != raw[1]
                else:
                    equal &= raw[0] == raw[1]
            valid = left["status"] != "oracle-error" and right["status"] != "oracle-error"
            expected = "pass" if equal and valid else "mismatch"
            assert comparison["status"] == expected and comparison["raw_equal"] == equal
            if expected != "pass":
                life_mismatches.append({"id": row["id"], "repetition": row["repetition"], "index": left["index"], "expression": left["expression"]})
            for runtime, call in [("java", left), ("rust", right)]:
                life_statuses[runtime][call["status"]] += 1
            calls += 1
    assert calls == 2782
    assert life["unexecuted_groups"] == old_life["unexecuted_groups"] and life["compatibility_complete"] is False
    for row in life["artifacts"]:
        data = (LIFE / safe(row["path"])).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
    assert sha((LIFE / "binaries/class_lifecycle_probe").read_bytes()) == life["candidate_build_sha256"]
    project = tree(COMMIT)
    expanded = {name: (*row, COMMIT) for name, row in project.items()}
    pins = {}
    for name in ["external/pkl", "external/pkl-pantry"]:
        pin = project[name][2]
        pins[name] = pin
        expanded.update({name + "/" + path: (*row, pin) for path, row in tree(pin, ROOT / name).items()})
    records = [(name, LANG / "sources" / name, digest, "language") for name, digest in lang["source_sha256"].items()]
    records += [(row["path"], LIFE / row["snapshot"], row["sha256"], "lifecycle") for row in life["sources"]]
    bound = {}
    for name, path, digest, label in records:
        data = path.read_bytes()
        assert sha(data) == digest
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        mode, kind, oid, commit = expanded[name]
        assert kind == "blob" and oid == blob, name
        if name in bound:
            assert bound[name]["sha256"] == digest
            bound[name]["capture_scopes"].append(label)
        else:
            bound[name] = {"sha256": digest, "git_blob": blob, "commit": commit, "mode": mode, "capture_scopes": [label]}
    assert "crates/pkl-runtime/src/stdlib/modules.txt" in lang["source_sha256"]
    assert any(row["path"] == "crates/pkl-runtime/src/stdlib/modules.txt" for row in life["sources"])
    config = ".cargo/config.toml"
    assert config in lang["source_sha256"] and sha((ROOT / config).read_bytes()) == lang["source_sha256"][config]
    config_direct_lifecycle = any(row["path"] == config for row in life["sources"])
    transitions = [{"id": row["id"], "before": previous["status"], "after": row["status"]} for previous, row in zip(old_lang["results"], lang["results"]) if previous["status"] != row["status"]]
    nonpass = [{"id": row["id"], "before": previous["status"], "after": row["status"]} for previous, row in zip(old_lang["results"], lang["results"]) if previous["status"] != "pass" or row["status"] != "pass"]
    raw_changes = {}
    for label in ["language", "lifecycle"]:
        old_bins = {name[len(label) + 1:]: sha(data) for name, data in old.items() if name.startswith(label + "/") and name.endswith(".bin")}
        new_bins = {name: row["sha256"] for name, row in inventories[label].items() if name.endswith(".bin")}
        raw_changes[label] = {"changed_common_bin_paths": sorted(name for name in old_bins.keys() & new_bins.keys() if old_bins[name] != new_bins[name]),
                              "added_bin_paths": sorted(new_bins.keys() - old_bins.keys()), "removed_bin_paths": sorted(old_bins.keys() - new_bins.keys()),
                              "note": "Exact hash changes only, with no path/diagnostic normalization and no implied compatibility."}
    terminal = None
    if terminal_receipt:
        receipt = load(terminal_receipt)
        assert type(receipt["exit_code"]) is int
        terminal = {"path": str(terminal_receipt), "sha256": sha(terminal_receipt.read_bytes()), "exit_code": receipt["exit_code"]}
    write("source-map.json", bound)
    write("case-changes.json", changed)
    write("status-changes.json", {"transitions": transitions, "all_old_or_new_nonpass": nonpass})
    write("raw-changes.json", raw_changes)
    write("payload-manifest.json", inventories)
    report = {"schema": 1, "scope": "Independent terminal data audit of Stage45/classpath full selected regression at01971d0; not M2 completion, CI, platform or performance evidence.",
              "implementation_commit": COMMIT, "pinned_references": pins,
              "wrapper_commands_complete": True, "wrapper_own_terminal": terminal,
              "wrapper_terminal_qualification": "Missing receipt means wrapper OS exit remains unknown; individual recorded child exits are kept separate.",
              "gates": {row["label"]: row["returncode"] for row in driver["commands"]},
              "language": {"report_sha256": sha((LANG / "report.json").read_bytes()), "case_definitions": 4527, "requirements": 475, "selected": 3664,
                           "case_order_and_selection_unchanged": True, "status_counts": lang["status_counts"], "full_gate_failure_reasons": len(lang["full_gate_failures"]),
                           "status_transition_count": len(transitions), "nonpass_rows": len(nonpass), "declared_payloads_verified": len(inventories["language"]),
                           "classpath_child_report_sha256": sha(child_raw), "classpath_repetitions": 2, "classpath_same_case_counted_once": True},
              "lifecycle": {"report_sha256": sha((LIFE / "report.json").read_bytes()), "sequences": 334, "calls_each_language": calls,
                            "status_counts": {key: dict(value) for key, value in life_statuses.items()}, "raw_mismatches": life_mismatches,
                            "comparison_channels": ["status", "stdout", "stderr"], "error_class_differences_retained_excluded_from_equality": classes,
                            "declared_payloads_verified": len(inventories["lifecycle"]), "unexecuted_groups_preserved": True},
              "source_binding": {"captured_records": len(records), "unique_paths": len(bound), "all_match_commit_blobs": True,
                                 "lifecycle_config_directly_captured": config_direct_lifecycle,
                                 "config_qualification": "Root.cargo/config.toml is bound by language pre-lifecycle capture,01971d0Gitblob and current post-run bytes; do not relabel it a direct lifecycle capture when absent."},
              "exact_build_paths_pruned_before_walk": pruned,
              "output_pointers": {name: {"path": str(OUT / name), "sha256": sha((OUT / name).read_bytes())} for name in ["source-map.json", "case-changes.json", "status-changes.json", "raw-changes.json", "payload-manifest.json"]},
              "remaining": ["Root review and publication archive/summary/source pointers", "All remaining strict failures and unmapped/unimplemented requirements", "Stage46 is a separate unmerged source/evidence scope"],
              "full_m2_complete": False, "hosted_ci_claimed": False, "performance_target_claimed": False}
    write("report.json", report)
    print(json.dumps({"status": "Data audit complete; inspect retained compatibility failures and terminal qualification.", "report_sha256": sha((OUT / "report.json").read_bytes()), "language_status_counts": lang["status_counts"], "persistent_mismatches": len(life_mismatches)}))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--prepare", action="store_true")
    group.add_argument("--audit", action="store_true")
    parser.add_argument("--wrapper-terminal", type=Path)
    args = parser.parse_args()
    prepare() if args.prepare else audit(args.wrapper_terminal)
