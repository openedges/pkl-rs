"""Archive complete candidate03 failure history from its frozen closed captures."""
from pathlib import Path
import datetime,hashlib,json,os,platform,shutil,stat,subprocess,sys,tarfile
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def need(x,s):
 if not x:raise ValueError(s)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
s=json.loads((O/'selection.json').read_bytes());summary=json.loads((O/'summary.json').read_bytes());G=O/'gather';A=O/'archives';G.mkdir();A.mkdir();evidence=O/'tool-sources/tools/evidence.py';evidence.parent.mkdir(parents=True);shutil.copyfile(R/'tools/evidence.py',evidence)
inputs={str(p):{'sha256':sha(p),'bytes':p.stat().st_size}for p in [O/'selection.json',O/'summary.json',O/'prepare.py',Path(__file__).resolve(),evidence,Path(sys.executable).resolve()]};save(O/'archive-inputs-before.json',inputs);commands=[];archives=[]
def execute(name,argv):
 row={'argv':[str(x)for x in argv],'cwd':str(R),'parentPid':os.getpid(),'startedUtc':now()}
 with(O/(name+'.stdout.bin')).open('wb')as stdout,(O/(name+'.stderr.bin')).open('wb')as stderr:
  p=subprocess.Popen(row['argv'],cwd=R,stdout=stdout,stderr=stderr);row['pid']=p.pid;save(O/(name+'.launch.json'),row);row['exitCode']=p.wait()
 row.update(finishedUtc=now(),stdoutSha256=sha(O/(name+'.stdout.bin')),stderrSha256=sha(O/(name+'.stderr.bin')));save(O/(name+'.terminal.json'),row);commands.append(row);need(row['exitCode']==0,'archive command failed '+name)
for unit in ['build-and-snapshots','native-results','portable-results','checks-original-launches']:
 gather=G/unit;gather.mkdir();rows=[x for x in s['rows']if x['unit']==unit]
 for row in rows:
  p=Path(row['sourcePath']);data=p.read_bytes();need(len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']and stat.S_IMODE(p.stat().st_mode)==row['mode'],'original changed '+str(p));out=gather/'originals'/row['root']/row['relative'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 save(gather/'CAPTURE_SELECTION.json',{'schema':1,'historicalCandidate':'candidate03-failed-ordinary-contract','selectionSha256':sha(O/'selection.json'),'rows':rows,'sourceSnapshotGuards':s['sourceSnapshotGuards'],'explicitReceiptFiles':s['explicitReceiptFiles'],'allOtherReceiptSiblingsExcluded':True,'allPayloadsRetainedWithoutDeduplication':True,'noCacheExclusionsNeededInsideSixClosedCaptureRoots':True,'noLiveCratesComparison':True})
 save(gather/'SCOPE.json',{'candidate':'candidate03','classification':'historical-failing-candidate-not-final','buildProofSha256':s['proofSha256'],'nativeAndEachPortable':summary['nativeAndEachPortable'],'originalAdapterMatches':2,'requiredChecksPassed':5,'rustTests':summary['rustTests'],'fullJavaEventsCountersPassed':False,'fullCompatibilityPassed':False,'actualTerminals':summary['actualTerminalReceipts'],'runtimePins':s['runtimePins'],'dependency':'Java golden authority is the exact installed fixture manifest a90cc8d0c409b03c783192f39cf265052e3efa48e0d9bc5f7d64818e57a2558d and collection_transform_fixtures.py pins. Expected arrays/bundle captured here remain original Java-derived data. They are not generated from this candidate. Root must bind eventual fixture commit separately.','runtimeQualification':'JDK/Node/Chromium binaries and dependency caches are not copied. Exact runtime hashes/paths and source-bound executed tools remain in original reports. Source snapshots and compiled candidate artifacts are preserved in the build unit.','independentSemanticAudit':'C owns the separate full candidate03 raw interpretation audit; this package performs static source/payload/receipt/archive integrity, not evaluator rerun or independent feature pass counting.'})
 (gather/'README.md').write_text('''# Candidate03 failure history

This is immutable historical Stage51 candidate03 evidence. Native and each Node/Chromium target acquired 2,108 calls with acquisition integrity, while the ordinary contract failed: 1,984 of 2,000 ordinary observations matched; 16 ordinary failures and 12 post-close raw boundaries remain. The 96 diagnostic observations remain separate. Original SourceCode adapter repeats and required local Rust checks passed within their recorded scope; neither closes compatibility.

All selected original files are preserved as regular archive payloads, including copied fixtures, frozen sources, original stdout/stderr, UTF-16 and Java-UTF8 channels, counters, effects, actual policy requests, tools, process receipts and failures. No duplicate source or fixture files have been silently removed. Every original file hash, size and mode is recorded in CAPTURE_SELECTION.json.

Frozen build snapshots, source maps, build proof and artifact hashes establish candidate03 identity. Current live crates are not compared. Candidate04 or later results cannot replace these historical failures. Only seven explicit root terminal receipts are selected; all additional receipt siblings are outside scope.

Archive creation, independent evidence.py verification and complete raw-member readback are recorded by the preparation producer. Java administrative lifecycle and whole-language compatibility gates remain false. No evaluator or Java acquisition was run during packaging.
''')
 archive=A/('stage51-candidate03-'+unit+'-history.tar.gz');execute(unit+'-create',[sys.executable,'-B',evidence,'create',gather,archive]);need(archive.stat().st_size<100_000_000,'archive over100MB; logical split required');execute(unit+'-verify',[sys.executable,'-B',evidence,'verify',archive])
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();need(len(members)==len({m.name for m in members})and all(m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts for m in members),'unsafe or duplicate archive members');actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in members};expected={'originals/'+x['root']+'/'+x['relative']:x['sha256']for x in rows};expected.update({name:sha(gather/name)for name in ['CAPTURE_SELECTION.json','SCOPE.json','README.md']});need(set(actual)==set(expected)|{'EVIDENCE.json'},'archive exact path coverage differs');need(all(actual[n]==h for n,h in expected.items()),'raw member/source hash differs')
 row={'unit':unit,'path':str(archive),'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'payloadFiles':len(expected),'originalFiles':len(rows),'originalBytes':sum(x['bytes']for x in rows),'createExitCode':0,'separateVerifyExitCode':0,'allRawMembersReadBack':True};archives.append(row);save(O/'archive-progress.json',archives)
# Preserve full historical pathsets under the six closed roots. Receipt directory siblings may legitimately grow.
actual_files=set();actual_dirs={}
for root in s['roots'].values():
 todo=[Path(root)]
 while todo:
  p=todo.pop();need(not p.is_symlink(),'original path became symlink');m=p.stat().st_mode
  if stat.S_ISDIR(m):actual_dirs[str(p)]=stat.S_IMODE(m);todo.extend(Path(e.path)for e in os.scandir(p))
  else:need(stat.S_ISREG(m),'nonregular original path');actual_files.add(str(p))
closed_expected={r['sourcePath']for r in s['rows']if r['root']in s['roots']};expected_dirs={x['path']:x['mode']for x in s['directories']};need(actual_files==closed_expected and actual_dirs==expected_dirs,'closed original pathset/directory mode changed')
changes=[]
for row in s['rows']:
 p=Path(row['sourcePath'])
 if not p.is_file()or p.is_symlink()or sha(p)!=row['sha256']or p.stat().st_size!=row['bytes']or stat.S_IMODE(p.stat().st_mode)!=row['mode']:changes.append(str(p))
for p,row in inputs.items():need(sha(Path(p))==row['sha256'],'packaging input drift')
for row in s['runtimePins'].values():need(sha(Path(row['path']))==row['sha256'],'explicit runtime executable changed')
need(not changes,'original payload changed');save(O/'original-guard.json',{'filesChecked':len(s['rows']),'originalChanges':changes,'sizeAndModesChecked':True,'sixClosedRootsPathsetAndDirectoryModesEqual':True,'receiptScope':'Only selected seven file identities guarded; directory siblings deliberately not walked or compared.','liveCratesNeverCompared':True,'frozenSnapshotsValidated':s['sourceSnapshotGuards']})
report={'status':'CLOSED-static-package-of-failed-candidate03','archives':archives,'compressedBytes':sum(x['compressedBytes']for x in archives),'commands':commands,'selectionSha256':sha(O/'selection.json'),'originalGuardSha256':sha(O/'original-guard.json'),'originalChanges':[],'allBelow100000000':True,'allPayloadsRetainedWithoutDeduplication':True,'noSourceReportsGitMutation':True,'newEngineExecutions':0,'finishedUtc':now()};save(O/'archive-report.json',report);print(json.dumps(report),flush=True)
