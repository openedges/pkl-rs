# Candidate03 실패 후보 역사 증거 게시 준비

닫힌 root6개와 root terminal receipt7개 파일만 selection.json에 명시했다. receipt root를 통째로 수집하지 않으며 inventory-refresh02.json과 이후 추가 형제 파일은 모두 대상 밖이다. launch root는 native/original/portable 및 고정 run.py만 포함하고 m1 디렉터리가 없다. live candidate04 및 C 독립 감사의 진행 출력은 포함하지 않는다.

build의430개 declared frozen snapshot을 실제 바이트로 검증했다. required checks의432개도 각각 before/after 및 copied source와 일치한다. 공통430개는 같고 추가2개는 compatibility/m2-language.json 및 fixture manifest다. current live crates 또는 live adapters와 비교하여 과거 후보를 부정하지 않는다. build proof1c53ebe4와 각 artifact SHA, 기록된 Node/Chromium executable pin을 확인했다.

Native/Node/browser는 각각2,108회 취득했으나 ordinary2,000 중1,984만 맞았다. ordinary16개와 공개 API post-close raw12개 실패를 그대로 보존하며 diagnostic96개와 구분한다. 원본 SourceCode adapter2회 match와 required5개/860Rust pass/1ignored(frontend_probe)는 별도 결과이고 compatibility 마감이 아니다. 모든 Java 행정 lifecycle/whole compatibility gate는 false다.

원본 payload를 줄이기 위해 fixture/source 파일을 제외하지 않았다. copied fixtures,430/432 source, 원시 채널/counter/effect/policy ledger, stdout/stderr, tool/source/process/terminal metadata를 모두 archive payload로 보존했다. 각 파일 단위 SHA/size/mode와 전체 닫힌 root pathset을 guard했다. dependency cache나 빌드 target를 걷지 않았고, 선택된 immutable capture root 안에서는 cache 이름 필터도 쓰지 않는다.

네 logical archive와 별도 metadata archive는 clean regular-file gather에서 tools/evidence.py create, 독립 verify 프로세스, 전체 raw member SHA readback을 수행한다. 모든 archive는100,000,000B보다 작아야 한다. 임시 selector의 SyntaxWarning2개는 stderr 원문과 실행 소스를 그대로 보존한다(exit0). 이 준비는 static integrity이며 C의 독립 의미 검증을 대체하거나 Java/native/Node/browser 평가를 재실행하지 않는다. 새 reports/Git 변경도 없다.
