from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();command=[sys.executable,'-B',str(O/'archive.py')];row={'command':command,'cwd':str(R),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceSha256':sha(O/'archive.py')}
with(O/'archive.stdout.bin').open('wb')as out,(O/'archive.stderr.bin').open('wb')as err:
 p=subprocess.Popen(command,cwd=R,stdout=out,stderr=err);row['pid']=p.pid;(O/'archive-launch.json').write_text(json.dumps(row,indent=2)+'\n');row['exitCode']=p.wait()
row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceAfterSha256=sha(O/'archive.py'),stdoutSha256=sha(O/'archive.stdout.bin'),stderrSha256=sha(O/'archive.stderr.bin'));(O/'archive-terminal.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True);sys.exit(row['exitCode'])
