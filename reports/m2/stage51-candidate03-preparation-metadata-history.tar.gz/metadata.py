from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tarfile
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=json.loads((O/'archive-report.json').read_bytes());assert not a['originalChanges']
(O/'PLAN.ko.md').write_text('''# Candidate03 실패 후보 역사 증거 게시 준비

닫힌 root6개와 root terminal receipt7개 파일만 selection.json에 명시했다. receipt root를 통째로 수집하지 않으며 inventory-refresh02.json과 이후 추가 형제 파일은 모두 대상 밖이다. launch root는 native/original/portable 및 고정 run.py만 포함하고 m1 디렉터리가 없다. live candidate04 및 C 독립 감사의 진행 출력은 포함하지 않는다.

build의430개 declared frozen snapshot을 실제 바이트로 검증했다. required checks의432개도 각각 before/after 및 copied source와 일치한다. 공통430개는 같고 추가2개는 compatibility/m2-language.json 및 fixture manifest다. current live crates 또는 live adapters와 비교하여 과거 후보를 부정하지 않는다. build proof1c53ebe4와 각 artifact SHA, 기록된 Node/Chromium executable pin을 확인했다.

Native/Node/browser는 각각2,108회 취득했으나 ordinary2,000 중1,984만 맞았다. ordinary16개와 공개 API post-close raw12개 실패를 그대로 보존하며 diagnostic96개와 구분한다. 원본 SourceCode adapter2회 match와 required5개/860Rust pass/1ignored(frontend_probe)는 별도 결과이고 compatibility 마감이 아니다. 모든 Java 행정 lifecycle/whole compatibility gate는 false다.

원본 payload를 줄이기 위해 fixture/source 파일을 제외하지 않았다. copied fixtures,430/432 source, 원시 채널/counter/effect/policy ledger, stdout/stderr, tool/source/process/terminal metadata를 모두 archive payload로 보존했다. 각 파일 단위 SHA/size/mode와 전체 닫힌 root pathset을 guard했다. dependency cache나 빌드 target를 걷지 않았고, 선택된 immutable capture root 안에서는 cache 이름 필터도 쓰지 않는다.

네 logical archive와 별도 metadata archive는 clean regular-file gather에서 tools/evidence.py create, 독립 verify 프로세스, 전체 raw member SHA readback을 수행한다. 모든 archive는100,000,000B보다 작아야 한다. 임시 selector의 SyntaxWarning2개는 stderr 원문과 실행 소스를 그대로 보존한다(exit0). 이 준비는 static integrity이며 C의 독립 의미 검증을 대체하거나 Java/native/Node/browser 평가를 재실행하지 않는다. 새 reports/Git 변경도 없다.
''')
M=O/'gather/preparation-metadata';M.mkdir();names=['prepare.py','prepare.stdout.bin','prepare.stderr.bin','selection.json','summary.json','archive.py','archive-inputs-before.json','archive-launch.json','archive-terminal.json','actual-tool-terminal.json','archive-report.json','archive-progress.json','archive.stdout.bin','archive.stderr.bin','launch-archives.py','original-guard.json','PLAN.ko.md','metadata.py']
for unit in ['build-and-snapshots','native-results','portable-results','checks-original-launches']:
 for action in ['create','verify']:
  names.extend(unit+'-'+action+suffix for suffix in ['.stdout.bin','.stderr.bin','.launch.json','.terminal.json'])
for name in names:shutil.copyfile(O/name,M/name)
(M/'tool-sources/tools').mkdir(parents=True);shutil.copyfile(O/'tool-sources/tools/evidence.py',M/'tool-sources/tools/evidence.py');(M/'METADATA_SOURCE_SELECTION.json').write_text(json.dumps({'files':{n:{'sourcePath':str(O/n),'sha256':sha(O/n),'bytes':(O/n).stat().st_size}for n in names},'semanticArchives':a['archives'],'historicalCandidate':'candidate03-failed-not-final','allPayloadsRetained':True,'qualification':'Metadata archive own create/verify receipts are finalized outside itself to avoid recursive self inclusion.'},indent=2)+'\n')
archive=O/'archives/stage51-candidate03-preparation-metadata-history.tar.gz';commands=[]
for action in ['create','verify']:
 cmd=[sys.executable,'-B',str(O/'tool-sources/tools/evidence.py'),action]+([str(M),str(archive)]if action=='create'else[str(archive)])
 with(O/('metadata-'+action+'.stdout.bin')).open('wb')as out,(O/('metadata-'+action+'.stderr.bin')).open('wb')as err:
  p=subprocess.Popen(cmd,cwd=R,stdout=out,stderr=err);code=p.wait()
 commands.append({'argv':cmd,'pid':p.pid,'exitCode':code,'stdoutSha256':sha(O/('metadata-'+action+'.stdout.bin')),'stderrSha256':sha(O/('metadata-'+action+'.stderr.bin'))});assert code==0
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert all(m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts for m in members);assert len(members)==len({m.name for m in members});actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in members};expected={p.relative_to(M).as_posix():sha(p)for p in M.rglob('*')if p.is_file()};assert set(actual)==set(expected)|{'EVIDENCE.json'}and all(actual[k]==v for k,v in expected.items())
report={'unit':'preparation-metadata','path':str(archive),'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'payloadFiles':len(expected),'createExitCode':0,'separateVerifyExitCode':0,'allRawMembersReadBack':True,'commands':commands};assert report['compressedBytes']<100000000;(O/'metadata-archive-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
