"""Prepare complete closed candidate03 historical capture selection; never compare live engine sources."""
from pathlib import Path
import collections,hashlib,json,os,re,stat
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def need(x,s):
 if not x:raise ValueError(s)
def read(root,name):return json.loads((root/name).read_bytes())
roots={n:O.parent/n for n in ['stage51-candidate03-build','stage51-candidate03-launches-01','stage51-native-candidate03-01','stage51-portable-candidate03-01','stage51-original-adapter-candidate03-01','stage51-required-checks-candidate03-01']}
receipt_root=O.parent/'stage51-root-terminal-receipts-01';receipt_names=['candidate03-build.json','native-candidate03.json','portable-candidate03.json','original-candidate03.json','required-candidate03.json','native-policy-parser-tests01.json','native-policy-parser-tests02.json'];receipts={}
for name in receipt_names:
 p=receipt_root/name;row=json.loads(p.read_bytes());need(sha(R/row['report'])==row['reportSha256'],'receipt report changed '+name);receipts[name]={'path':str(p),'sha256':sha(p),'receipt':row}
B=roots['stage51-candidate03-build'];proof=read(B,'build-proof.json');build=read(B,'report.json');need(proof['status']=='CLOSED'and proof['sourceStable']and build['complete']and build['sourceStable'],'candidate build not closed');need(sha(B/'build-proof.json')==build['buildProofSha256']=='1c53ebe4ab3221688389c5740c4946b2ad787e208fe03009aade3a155f4e3787','candidate proof binding differs');need(all(x['exitCode']==0for x in build['commands']),'build command failed');need(sha(B/'run.py')==build['runnerSha256'],'build runner differs')
source_guards={}
for name in ['stage51-candidate03-build','stage51-required-checks-candidate03-01']:
 root=roots[name];before=read(root,'sources-before.json');after=read(root,'sources-after.json');need(before==after,'frozen source maps differ '+name)
 for rel,h in before.items():
  p=Path(rel);need(not p.is_absolute()and '..'not in p.parts,'unsafe frozen snapshot path');p=root/'sources'/p;need(p.is_file()and not p.is_symlink()and sha(p)==h,'frozen snapshot differs '+str(p))
 source_guards[name]={'paths':len(before),'beforeSha256':sha(root/'sources-before.json'),'afterSha256':sha(root/'sources-after.json'),'snapshotRoot':str(root/'sources'),'allSnapshotFilesMatch':True}
need(len(proof['sources'])==430 and proof['sources']==read(B,'sources-before.json'),'build source map mismatch');need(Path(proof['snapshotRoot'])==B/'sources','unexpected snapshot root')
for kind,row in proof['artifacts'].items():need(sha(Path(row['path']))==row['sha256'],'artifact differs '+kind)
need(sha(Path(build['languageProbe']['path']))==build['languageProbe']['sha256'],'language probe differs')
required=read(roots['stage51-required-checks-candidate03-01'],'report.json');need(required['passed']and required['complete']and required['sourceStable']and required['buildProofSha256']==sha(B/'build-proof.json'),'required checks binding/status differs');need(all(x['exitCode']==0for x in required['commands']),'required command failed')
base=proof['sources'];check=read(roots['stage51-required-checks-candidate03-01'],'sources-before.json');need(all(base[p]==check[p]for p in base.keys()&check.keys()),'frozen shared snapshots differ');need(sorted(set(check)-set(base))==['compatibility/m2-language.json','tests/fixtures/m2-collection-transforms/manifest.json'],'required source additions differ')
N=roots['stage51-native-candidate03-01'];native=read(N,'report.json');np=read(N,'payloads.json');need(sha(N/'payloads.json')==native['payloadManifestSha256'],'native payload manifest binding differs');need(native['complete']and native['acquisitionIntegrityPassed']and not native['ordinaryContractPassed']and native['changedInputs']==[],'native historical gates differ');nc=read(N,'comparison.json');need(nc['calls']==2108 and nc['ordinaryCompatible']==1984 and nc['ordinaryCount']==2000 and nc['rawMatches']==2080,'native summary differs')
P=roots['stage51-portable-candidate03-01'];portable=read(P,'execution.json');pi=read(P,'output-inventory.json');need(sha(P/'output-inventory.json')==portable['outputInventory']['sha256'],'portable inventory differs');need(portable['acquisitionIntegrityPassed']and not portable['ordinaryContractPassed']and portable['changedInputs']==[],'portable historical gates differ');need(portable['buildProofSha256']==sha(B/'build-proof.json'),'portable build proof differs')
for target in ['node','browser']:
 x=portable['targets'][target];need(x['complete']and x['calls']==2108 and x['ordinaryCompatible']==1984 and x['ordinaryCount']==2000 and x['rawByteMatches']==2080 and x['diagnosticOnlyRawMatches']==96 and x['publicApiBoundaryRawMatches']==0,'portable summary differs '+target)
for root,inv in [(N,np),(P,pi)]:
 for rel,row in inv['files'].items():
  q=Path(rel);need(not q.is_absolute()and '..'not in q.parts,'unsafe payload path');p=root/q;need(p.is_file()and not p.is_symlink()and sha(p)==row['sha256']and p.stat().st_size==row['bytes'],'payload changed '+str(p))
original=read(roots['stage51-original-adapter-candidate03-01'],'report.json');need(original['complete']and original['passed']and original['changedInputs']==[]and len(original['commands'])==2 and all(x['exitCode']==0 and all(x['rawMatches'].values())and x['exitMatches']for x in original['commands']),'original adapter result differs')
launch=roots['stage51-candidate03-launches-01'];need(not(launch/'m1').exists(),'unrequested m1 child exists');need(set(p.name for p in launch.iterdir())=={'native','portable','original','run.py'},'launch root has unexpected children')
for name,code in [('native',0),('portable',1),('original',0)]:
 t=read(launch/name,'terminal.json');need(t['exitCode']==code and t['buildProofSha256']==sha(B/'build-proof.json') and t['runnerSha256']==sha(launch/'run.py'),'launch terminal binding differs '+name)
 for channel in ['stdout','stderr']:need(sha(launch/name/(channel+'.bin'))==t[channel+'Sha256'],'launch stream differs')
# Runtime pins are checked only through explicitly recorded executable paths, not by walking caches or comparing live crates.
runtime={}
for name,key in [('node',None),('browser','browserExecutable')]:
 t=read(launch/'portable','terminal.json');p=Path(t[name]);h=t[name+'Sha256'];need(p.is_file()and sha(p)==h,'recorded runtime executable differs');runtime[name]={'path':str(p),'sha256':h,'bytes':p.stat().st_size,'notArchived':True}
rows=[];dirs=[]
for name,root in roots.items():
 unit='build-and-snapshots'if name=='stage51-candidate03-build'else('native-results'if name=='stage51-native-candidate03-01'else('portable-results'if name=='stage51-portable-candidate03-01'else'checks-original-launches'))
 todo=[root]
 while todo:
  p=todo.pop();need(not p.is_symlink(),'unexpected selected link '+str(p));m=p.stat()
  if stat.S_ISDIR(m.st_mode):dirs.append({'path':str(p),'mode':stat.S_IMODE(m.st_mode)});todo.extend(sorted((Path(e.path)for e in os.scandir(p)),reverse=True));continue
  need(stat.S_ISREG(m.st_mode),'nonregular closed payload');rows.append({'sourcePath':str(p),'root':name,'relative':p.relative_to(root).as_posix(),'bytes':m.st_size,'mode':stat.S_IMODE(m.st_mode),'sha256':sha(p),'unit':unit,'storage':'archive-payload'})
for name in receipt_names:
 p=receipt_root/name;m=p.stat();rows.append({'sourcePath':str(p),'root':receipt_root.name,'relative':name,'bytes':m.st_size,'mode':stat.S_IMODE(m.st_mode),'sha256':sha(p),'unit':'checks-original-launches','storage':'archive-payload'})
# Native and portable inventories deliberately omit only their own noncircular top-level authority records.
for root,inv,extra in [(N,np,{'payloads.json','report.json'}),(P,pi,{'execution.json','output-inventory.json'})]:
 actual={row['relative']for row in rows if row['root']==root.name};need(actual==set(inv['files'])|extra,'producer payload coverage differs '+root.name)
text=(roots['stage51-required-checks-candidate03-01']/'test.stdout.bin').read_text();summaries=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);totals=list(map(sum,zip(*(tuple(map(int,x))for x in summaries))));need(totals==[860,0,1],'Rust summary totals differ')
selection={'schema':1,'status':'closed-failing-candidate03-history-only','roots':{k:str(v)for k,v in roots.items()},'explicitReceiptFiles':[str(receipt_root/n)for n in receipt_names],'allOtherReceiptSiblingsExcluded':True,'knownUnselectedReceiptSibling':'inventory-refresh02.json','cachePrunes':[],'noGenericBuildCacheFilters':True,'noDependencyCacheWalks':True,'rows':rows,'directories':dirs,'sourceSnapshotGuards':source_guards,'frozenBuildRequiredSharedPathsEqual':True,'requiredAdditionalSnapshotPaths':sorted(set(check)-set(base)),'proofSha256':sha(B/'build-proof.json'),'runtimePins':runtime,'liveCratesNeverCompared':True,'allPayloadsRetainedWithoutDeduplication':True,'fullJavaEventsCountersPassed':False,'fullCompatibilityPassed':False}
save(O/'selection.json',selection);counts=collections.Counter();sizes=collections.Counter()
for row in rows:counts[row['unit']]+=1;sizes[row['unit']]+=row['bytes']
summary={'selectedClosedRoots':6,'explicitReceiptFiles':7,'files':len(rows),'bytes':sum(x['bytes']for x in rows),'units':{u:{'files':counts[u],'bytes':sizes[u]}for u in counts},'sourceIdentityIssues':[],'selectionSha256':sha(O/'selection.json'),'buildSourcePaths':430,'requiredSourcePaths':432,'nativeAndEachPortable':{'calls':2108,'rawMatches':2080,'ordinaryCompatible':1984,'ordinaryCount':2000,'ordinaryFailures':16,'diagnosticMatches':96,'postCloseRawFailures':12,'acquisitionIntegrityPassed':True,'ordinaryCompatibilityPassed':False},'originalAdapterMatches':2,'requiredChecksPassed':5,'rustTests':{'passed':860,'failed':0,'ignored':1,'ignoredLines':[line for line in text.splitlines()if '... ignored'in line]},'actualTerminalReceipts':receipts,'historicalFailedCandidateNotFinal':True,'currentLiveCratesCompared':False,'noJavaOrEngineRerun':True};save(O/'summary.json',summary);print(json.dumps(summary),flush=True)
