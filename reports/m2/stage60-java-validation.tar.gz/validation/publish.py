"""Publish and fully read back Stage 60 Java-only validation and capture history."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
VALIDATION = Path(__file__).resolve().parent
REPORTS = ROOT / "reports/m2"
CAPTURE_PREFIX = "target/m2/stage60-bytes-oracle-"
HISTORY_NUMBERS = ("01", "02", "03", "04")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def paths_under(root, prefix):
    need(root.is_dir() and not root.is_symlink(), "capture root missing or symlinked")
    result = {}
    for path in root.rglob("*"):
        need(not path.is_symlink(), "capture contains symlink")
        if path.is_file():
            result[prefix + path.relative_to(root).as_posix()] = path
        else:
            need(path.is_dir(), "capture contains nonregular path")
    return result


def emit_archive(path, files, scope):
    need(not path.exists(), "fresh publication archive required")
    entries = {name: source.read_bytes() for name, source in files.items()}
    manifest = {"schema": 1, "scope": scope,
                "members": {name: {"bytes": len(raw), "sha256": sha(raw)}
                            for name, raw in sorted(entries.items())}}
    entries["archive-manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with path.open("wb") as out:
        with gzip.GzipFile(fileobj=out, mode="wb", mtime=0, filename="") as zipped:
            with tarfile.open(fileobj=zipped, mode="w") as tar:
                for name, raw in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    tar.addfile(info, io.BytesIO(raw))
    observed = {}
    with tarfile.open(path, "r:gz") as tar:
        for member in tar:
            need(member.isfile() and member.name not in observed and not member.name.startswith("/")
                 and ".." not in Path(member.name).parts, "unsafe or duplicate archive member")
            raw = tar.extractfile(member).read()
            need(len(raw) == member.size, "archive member size differs")
            observed[member.name] = raw
    need(observed == entries and json.loads(observed["archive-manifest.json"]) == manifest,
         "archive full member byte/hash readback differs")
    return {"archive": path.relative_to(ROOT).as_posix(), "identity": identity(path),
            "members": len(observed), "member_hash_readback": True,
            "embedded_manifest_sha256": sha(observed["archive-manifest.json"])}


def check_capture(number):
    root = ROOT / (CAPTURE_PREFIX + number)
    provenance = json.loads((root / "provenance.json").read_bytes())
    audit = json.loads((root / "audit.json").read_bytes())
    rows = json.loads((root / "cases.json").read_bytes())["rows"]
    need(audit["rows"] == len(rows) == 300 and len(provenance["sessions"]) == 2,
         f"history {number} row/session coverage differs")
    need(provenance["complete"] is True and provenance["stable"] is True
         and provenance["raw_equal"] is True and provenance["raw_differences"] == []
         and provenance["input_before"] == provenance["input_after"]
         and provenance["source_before"] == provenance["source_after"]
         and provenance["artifact_sha256"] == provenance["artifact_after_sha256"],
         f"history {number} stability differs")
    for name, expected in provenance["input_before"].items():
        need(identity(root / name)["sha256"] == expected, f"history {number} input differs: {name}")
    for name, expected in provenance["source_before"].items():
        need(identity(root / "sources" / name)["sha256"] == expected,
             f"history {number} source differs: {name}")
    need(len({session["pid"] for session in provenance["sessions"]}) == 2 and
         provenance["sessions"][0]["finished_epoch"] <= provenance["sessions"][1]["started_epoch"],
         f"history {number} JVMs not ordered/fresh")
    for session in provenance["sessions"]:
        repeat = session["repeat"]
        need(session["exit_code"] == 0 and session["query_directories"] == 300,
             f"history {number} session failed")
        folder = root / f"repeat-{repeat}"
        counts = Counter()
        protocol = ["session-open mode=string rows=300"]
        for index, row in enumerate(rows):
            case = folder / f"{index:03d}-{row['id']}"
            need(case.is_dir(), f"history {number} query missing")
            status = (case / "result.status.bin").read_text().strip()
            need(status in ("success", "error", "oracle-error", "api-exception"),
                 f"history {number} row status differs")
            counts[status] += 1
            call = f"string-{index}-{row['id']}"
            protocol.extend((f"call-enter={call}", f"call-exit={call} status={status}"))
        protocol.append(f"session-closed mode=string rows=300 public-calls=300 "
                        f"success={counts['success']} errors={300-counts['success']}")
        need((folder / "process.stdout.bin").read_bytes() == ("\n".join(protocol) + "\n").encode(),
             f"history {number} whole protocol differs")
        need(dict(counts) == audit["statuses"], f"history {number} status audit differs")
    return root, {"rows": audit["rows"], "statuses_per_session": audit["statuses"],
                  "pids": [session["pid"] for session in provenance["sessions"]],
                  "source_stable": provenance["stable"], "raw_repetitions_equal": provenance["raw_equal"]}


def main():
    validation = json.loads((VALIDATION / "validation.json").read_bytes())
    need(validation["complete"] is True and validation["source_stable"] is True
         and validation["snapshot_matches"] is True and len(validation["checks"]) == 5
         and all(check["exit_code"] == 0 for check in validation["checks"]),
         "recorded Java-only validation incomplete")
    for name, expected in validation["source_before"].items():
        need(identity(VALIDATION / "sources" / name)["sha256"] == expected,
             "validation copied source differs")
    histories = {}
    history_files = {}
    for number in HISTORY_NUMBERS:
        root, details = check_capture(number)
        histories[number] = details
        history_files.update(paths_under(root, f"history/stage60-bytes-oracle-{number}/"))
    validation_files = paths_under(VALIDATION, "validation/")
    validation_archive = emit_archive(REPORTS / "stage60-java-validation.tar.gz", validation_files,
                                      "Stage 60 Java Bytes authority checks, raw logs and copied source closure")
    history_archive = emit_archive(REPORTS / "stage60-java-history.tar.gz", history_files,
                                   "Four preserved Stage 60 exploratory Java Bytes captures, all raw channels")
    canonical_root = ROOT / "target/m2/stage60-bytes-oracle-05"
    canonical_provenance = json.loads((canonical_root / "provenance.json").read_bytes())
    fixture = ROOT / "tests/fixtures/m2-bytes-values"
    identity_report = json.loads((fixture / "archive-identity.json").read_bytes())
    result = {
        "schema": 1, "kind": "stage60-bytes-java-authority-checkpoint", "baseline": "Pkl 0.32.0",
        "canonical": {"fixture": "tests/fixtures/m2-bytes-values", "rows": 300,
                      "statuses_per_session": {"success": 223, "error": 77}, "repetitions": 2,
                      "archive_identity": identity(fixture / "oracle-evidence.tar.gz"),
                      "archive_members": identity_report["members"],
                      "raw_files_per_repetition": canonical_provenance["raw_files"],
                      "pids": [session["pid"] for session in canonical_provenance["sessions"]],
                      "module_uri": "file:///stage60/bytes-values.pkl",
                      "row_channels": {"status_binary": 1, "string_names": [
                          "expression", "result.stdout", "result.stderr", "result.error-class",
                          "result.exception-to-string", "result.cause-class", "result.cause-message",
                          "result.cause-to-string"], "encodings_per_string": ["UTF-8", "UTF-16BE-code-units"]}},
        "history": {"captures": histories,
                    "reason_superseded": {"01": "Module-local properties were not visible to public expression evaluation.",
                                          "02": "Authored NUL escape used unsupported syntax.",
                                          "03": "Value equality labels incorrectly suggested reference identity.",
                                          "04": "List eager construction labels incorrectly suggested toBytes error order."},
                    **history_archive},
        "java_runtime": {"artifact_sha256": canonical_provenance["artifact_sha256"],
                         "jdk_executable_sha256": canonical_provenance["jdk"]["executable_sha256"],
                         "jdk_modules_sha256": canonical_provenance["jdk"]["modules_sha256"],
                         "jdk_release_sha256": canonical_provenance["jdk"]["release_sha256"],
                         "reference_revision": canonical_provenance["reference_revision"],
                         "artifact_before_after_equal": canonical_provenance["artifact_sha256"] == canonical_provenance["artifact_after_sha256"]},
        "validation": {"directory": VALIDATION.relative_to(ROOT).as_posix(),
                       "record": (VALIDATION / "validation.json").relative_to(ROOT).as_posix(),
                       "record_identity": identity(VALIDATION / "validation.json"),
                       "source_stable": validation["source_stable"], "checks": validation["checks"],
                       "deferred_final_integration": validation["deferred_final_integration"],
                       **validation_archive},
        "candidate_compatibility_passes_claimed": 0,
        "limits": [
            "The original upstream basic/bytes.pkl, api/bytes.pkl and invalidBytes4.pkl sources were reviewed and copied; original snippet suite replay remains separate.",
            "This Java string API capture does not establish VM cache/backlink reference identity or typed byte[] export aliasing.",
            "No Rust candidate, browser, Node, full M2, or performance compatibility is established by this Java authority checkpoint.",
            "M2 manifest freshness is deferred until concurrent Rust/core changes freeze and the manifest is regenerated.",
        ],
    }
    dest = REPORTS / "stage60-java-checkpoint.json"
    need(not dest.exists(), "fresh checkpoint publication required")
    dest.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"validation_archive": validation_archive, "history_archive": history_archive,
                      "checkpoint": identity(dest)}, sort_keys=True))


if __name__ == "__main__":
    main()
