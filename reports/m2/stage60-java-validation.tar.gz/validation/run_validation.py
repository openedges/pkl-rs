"""Record Stage 60 Java Bytes authority checks with raw output and source closure."""
import hashlib
import json
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent
PYTHON_SOURCES = [
    "target/m2/stage60-java-validation-01/run_validation.py",
    "tools/bytes_values_oracle.py",
    "tools/bytes_values_fixtures.py",
    "tools/tests/test_bytes_values_fixtures.py",
    "tools/inventory.py",
]
UPSTREAM_SOURCES = [
    "external/pkl/stdlib/base.pkl",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmBytes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/BytesNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/BaseNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/ListNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/StringNodes.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/util/ByteArrayUtils.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/literal/BytesLiteralNode.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/builder/AstBuilder.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/binary/AdditionNode.java",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/bytes.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/bytes.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/list.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/errors/invalidBytes4.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/output/basic/bytes.pcf",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/output/api/bytes.pcf",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/output/errors/invalidBytes4.err",
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(path):
    return {"bytes": path.stat().st_size, "sha256": digest(path)}


def source_names():
    names = set(PYTHON_SOURCES + UPSTREAM_SOURCES + [
        "tools/java/BytesValuesOracle.java", "oracle.lock.json", "references.lock",
        "compatibility/inventory.json",
    ])
    names.update(path.relative_to(ROOT).as_posix() for path in
                 (ROOT / "tests/fixtures/m2-bytes-values").iterdir() if path.is_file())
    return sorted(names)


def run(name, argv):
    folder = OUTPUT / "checks" / name
    folder.mkdir(parents=True)
    started = time.time()
    process = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=300)
    ended = time.time()
    stdout, stderr = folder / "stdout.bin", folder / "stderr.bin"
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    result = {"name": name, "argv": argv, "cwd": str(ROOT), "started_epoch": started,
              "finished_epoch": ended, "exit_code": process.returncode,
              "stdout": identity(stdout), "stderr": identity(stderr)}
    (folder / "process.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"{name}: {process.returncode}", flush=True)
    return result


def save(report):
    (OUTPUT / "validation.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


def main():
    if (OUTPUT / "sources").exists() or (OUTPUT / "validation.json").exists():
        raise ValueError("fresh validation output required")
    names = source_names()
    before = {name: digest(ROOT / name) for name in names}
    for name in names:
        dest = OUTPUT / "sources" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, dest)
    python = sys.executable
    report = {"schema": 1, "kind": "stage60-bytes-java-authority-validation",
              "scope": "Java authority integrity and source inventory only; no Rust candidate pass",
              "host": platform.uname()._asdict(),
              "python": {"executable": python, "executable_identity": identity(Path(python)),
                         "version": sys.version},
              "python_source_closure": PYTHON_SOURCES,
              "source_before": before, "checks": [], "complete": False,
              "deferred_final_integration": ["M2 manifest freshness after Rust/core source freeze and regeneration"]}
    save(report)
    commands = [
        ("fixture-verifier", [python, "tools/bytes_values_fixtures.py"]),
        ("fixture-verifier-O", [python, "-O", "tools/bytes_values_fixtures.py"]),
        ("fixture-tests", [python, "-m", "unittest", "tools.tests.test_bytes_values_fixtures", "-v"]),
        ("fixture-tests-O", [python, "-O", "-m", "unittest", "tools.tests.test_bytes_values_fixtures", "-v"]),
        ("source-inventory", [python, "tools/inventory.py", "--check"]),
    ]
    for name, argv in commands:
        report["checks"].append(run(name, argv))
        save(report)
    after = {name: digest(ROOT / name) for name in names}
    report["source_after"] = after
    report["source_stable"] = before == after
    report["snapshot_matches"] = before == {name: digest(OUTPUT / "sources" / name) for name in names}
    report["complete"] = report["source_stable"] and report["snapshot_matches"] and all(
        item["exit_code"] == 0 for item in report["checks"])
    save(report)
    if not report["complete"]:
        raise ValueError("Java-only validation incomplete; raw attempts retained")


if __name__ == "__main__":
    main()
