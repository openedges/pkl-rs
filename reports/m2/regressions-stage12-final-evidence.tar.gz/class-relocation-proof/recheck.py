import json, pathlib, sys
sys.dont_write_bytecode = True
artifact = pathlib.Path(sys.argv[1]).resolve()
sys.path.insert(0, str(artifact / "sources/tools"))
import m2_class_lifecycle as frozen
assert pathlib.Path(frozen.__file__).resolve() == artifact / "sources/tools/m2_class_lifecycle.py"
report = frozen.check_report(artifact)
assert frozen.contract_passes(report)
calls = [call for row in report["cases"] for call in row["observations"]["comparisons"]]
print(json.dumps(dict(status="pass", source="frozen relocated snapshot", sequence_executions=len(report["cases"]), unique_sequences=len({row["id"] for row in report["cases"]}), call_comparisons=len(calls), passing_calls=sum(call["status"] == "pass" for call in calls), recorded_output_directory=report["output_directory"], actual_directory=str(artifact), captured_binaries_executed=False), sort_keys=True))
