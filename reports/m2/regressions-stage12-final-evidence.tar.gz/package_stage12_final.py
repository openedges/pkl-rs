"""Package final Stage 12 local evidence only after all fresh captures finish.

This helper reads raw evidence and runs integrity gates; it never acquires a
corpus or executes retained candidate binaries. Exact implementation-commit
binding is a separate later operation. Existing outputs are never replaced.
"""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
REPORTS = ROOT / 'reports/m2'
DIRECTORIES = {name: BASE / (name + '-stage12-final-02')
               for name in ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle']}
DIRECTORIES.update(classes=BASE / 'stage12-class-lifecycle-03',
                   prior=BASE / 'prior-selection-stage12-provisional-01')
KNOWN_LANGUAGE = {'error-cycle', 'error-remainder-zero'}
KNOWN_REGEX = {'regex-unicode-15-vs-16', 'regex-zero-width-supplementary'}


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def identity(path, expected, size=None):
    if sha(path) != expected or (size is not None and path.stat().st_size != size):
        raise ValueError('Evidence identity differs: ' + str(path))


def source_map(directory, mapping):
    for name, digest in mapping.items():
        identity(directory / 'sources' / name, digest)
        identity(ROOT / name, digest)


def raw_process(process):
    if process['status'] != 'executed':
        raise ValueError('Process was not executed: ' + repr(process['command']))
    values = []
    for name in ['stdout', 'stderr']:
        row = process[name]
        path = Path(row['path'])
        identity(path, row['sha256'], row['bytes'])
        values.append(path.read_bytes())
    return process['exit_code'], *values


def validation_report(directory):
    report = load(directory / 'report.json')
    required = [
        ['cargo', 'xtask', 'verify'], ['cargo', 'fmt', '--all', '--', '--check'],
        ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings'],
        ['cargo', 'test', '--workspace', '--locked'],
        ['cargo', 'check', '-p', 'pkl-runtime', '--target', 'wasm32-unknown-unknown', '--locked'],
    ]
    if [r['command'] for r in report['checks'][:5]] != required:
        raise ValueError('Required Rust verification command inventory differs')
    rust_output = python_output = None
    for index, row in enumerate(report['checks']):
        if row['exit_code'] != 0:
            raise ValueError('Required verification failed: ' + repr(row['command']))
        captures = {}
        for channel in ['stdout', 'stderr']:
            path = directory / f'{index}.{channel}.bin'
            identity(path, row[channel + '_sha256'])
            captures[channel] = path.read_bytes().decode()
        if row['command'] == required[3]:
            rust_output = captures['stdout'] + captures['stderr']
        if row['command'][1:] == ['-m', 'unittest', 'discover', '-s', 'tools/tests', '-v']:
            python_output = captures['stdout'] + captures['stderr']
    if len(report['checks']) != 7 or report['checks'][6]['command'][1:] != ['tools/m2_manifest.py', '--check']:
        raise ValueError('Python/inventory verification command inventory differs')
    rust_rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', rust_output or '')
    python_rows = re.findall(r'Ran (\d+) tests? in ', python_output or '')
    if not rust_rows or len(python_rows) != 1 or not re.search(r'\nOK\s*$', python_output or ''):
        raise ValueError('Missing successful raw Rust/Python test summaries')
    counts = dict(rust_passed=sum(int(row[0]) for row in rust_rows),
                  rust_intentionally_ignored=sum(int(row[2]) for row in rust_rows),
                  python_passed=int(python_rows[0]))
    if any(int(row[1]) for row in rust_rows) or not counts['rust_passed'] or not counts['python_passed']:
        raise ValueError('Failed or empty verification summaries')
    return dict(report, **counts, evidence_sha256={str(p.relative_to(directory)): sha(p)
                for p in sorted(directory.rglob('*')) if p.is_file()})


def inspect():
    sys.path.insert(0, str(ROOT / 'tools'))
    language_tool = importlib.import_module('m2_language')
    frontend_tool = importlib.import_module('m1_frontend')
    lifecycle_tool = importlib.import_module('m1_lifecycle')
    platform_tool = importlib.import_module('m1_platforms')
    class_tool = importlib.import_module('m2_class_lifecycle')
    runtime_tool = importlib.import_module('m1_runtime')
    language = language_tool.check_report(DIRECTORIES['language'])
    if not language_tool.development_passes(language, DIRECTORIES['language']):
        raise ValueError('Language selected development contract failed')
    if language_tool.subset_passes(language) or not language['full_gate_failures']:
        raise ValueError('Strict compatibility incompleteness unexpectedly changed')
    if language['selected_count'] != 1291 or len(language['results']) != 1291:
        raise ValueError('Existing selected denominator changed')
    if {r['id'] for r in language['results'] if r['status'] != 'pass'} != KNOWN_LANGUAGE:
        raise ValueError('Existing selected failure inventory changed')
    if len(language['metamorphic_results']) != 46 or not all(r['status'] == 'pass' for r in language['metamorphic_results']):
        raise ValueError('Existing metamorphic contract changed')
    if not language['source_stability'] or not language['artifact_stability'] or language['candidate']['source_binding'] != 'recorded-build':
        raise ValueError('Fresh language build identity/stability failed')
    source_map(DIRECTORIES['language'], language['source_sha256'])
    frontend = frontend_tool.check_report(DIRECTORIES['frontend'])
    if not frontend['source_stability'] or not all(r['passed'] for r in frontend['results']):
        raise ValueError('Frontend comparison failed')
    source_map(DIRECTORIES['frontend'], frontend['source_sha256'])
    identity(Path(frontend['rust_artifact']['path']), frontend['rust_artifact']['sha256'])
    lifecycle = lifecycle_tool.check_report(DIRECTORIES['lifecycle'])
    if not lifecycle['source_stability_before_execution'] or not lifecycle['source_stability_after_execution']:
        raise ValueError('Lifecycle sources changed during capture')
    source_map(DIRECTORIES['lifecycle'], {r['path']: r['sha256'] for r in lifecycle['sources']})
    platforms = load(DIRECTORIES['platforms'] / 'report.json')
    platform_tool.check_scenarios(platforms['execution'])
    rows = platforms['comparisons']
    if not platforms['source_stability'] or not platform_tool.contract_matches(rows):
        raise ValueError('Platform shared-engine or exact known-gap contract failed')
    if platforms['compatibility_status'] != 'fail' or platforms['experiment_contract_status'] != 'pass' or set(platforms['known_gaps']) != KNOWN_REGEX:
        raise ValueError('Platform compatibility/architecture outcomes changed')
    source_map(DIRECTORIES['platforms'], platforms['source_hashes'])
    for path, digest in platforms['artifacts'].items():
        identity(DIRECTORIES['platforms'] / path, digest)
    primitive = DIRECTORIES['platforms'] / 'oracle-native'
    captures = {'java': (primitive / 'java.stdout.bin').read_bytes(),
                'rust': (primitive / 'rust.stdout.bin').read_bytes(),
                'node': (DIRECTORIES['platforms'] / 'execution/node.stdout.bin').read_bytes(),
                'browser': (DIRECTORIES['platforms'] / 'execution/browser.stdout.bin').read_bytes()}
    cases = platform_tool.generate_cases()['cases']
    if platform_tool.compare(cases, captures) != rows:
        raise ValueError('Platform recorded comparisons disagree with raw captures')
    runtime = load(DIRECTORIES['runtime'] / 'report.json')
    if [r['id'] for r in runtime['cases']] != list(runtime_tool.SUCCESS_CASES + runtime_tool.ERROR_CASES):
        raise ValueError('Runtime case coverage changed')
    for item in runtime['identities']:
        path = Path(item.get('snapshot', item['path']))
        identity(path, item['sha256'], item.get('bytes'))
        if 'snapshot' in item:
            identity(Path(item['path']), item['sha256'], item.get('bytes'))
    mismatches = []
    for row in runtime['cases']:
        java, rust = raw_process(row['java']), raw_process(row['rust'])
        if row['raw_equal'] != (java == rust):
            raise ValueError('Runtime raw verdict changed')
        if row['id'] in runtime_tool.SUCCESS_CASES:
            if java != rust or java[0] != 0 or java[2]:
                raise ValueError('Runtime value mismatch')
        else:
            if java[0] != 1 or rust[0] != 1:
                raise ValueError('Runtime error outcome changed')
            if java != rust:
                mismatches.append(row['id'])
    if mismatches != ['forcing-cycle']:
        raise ValueError('Runtime full diagnostic known-gap inventory changed')
    classes = class_tool.check_report(DIRECTORIES['classes'])
    if not class_tool.contract_passes(classes):
        raise ValueError('Class sequence selected contract failed')
    calls = [call for row in classes['cases'] for call in row['observations']['comparisons']]
    class_counts = dict(unique_sequences=len({r['id'] for r in classes['cases']}),
                        sequence_executions=len(classes['cases']), call_comparisons=len(calls),
                        passing_calls=sum(c['status'] == 'pass' for c in calls))
    if tuple(class_counts.values()) != (18, 36, 194, 194):
        raise ValueError('Unexpected class sequence denominator/outcome')
    source_map(DIRECTORIES['classes'], {r['path']: r['sha256'] for r in classes['sources']})
    prior = load(DIRECTORIES['prior'] / 'report.json')
    prior_inventory = load(DIRECTORIES['prior'] / 'evidence-sha256.json')
    observed_prior = {str(p.relative_to(DIRECTORIES['prior'])) for p in DIRECTORIES['prior'].rglob('*')
                      if p.is_file() and p.name != 'evidence-sha256.json'}
    if set(prior_inventory) != observed_prior:
        raise ValueError('Prior selection evidence inventory incomplete')
    for name, digest in prior_inventory.items():
        identity(DIRECTORIES['prior'] / name, digest)
    candidate = load(DIRECTORIES['prior'] / 'candidate.json')
    identity(DIRECTORIES['prior'] / 'artifacts/language_probe', candidate['sha256'])
    baseline_metadata = load(DIRECTORIES['prior'] / 'baseline.json')
    baseline_dir = Path(baseline_metadata['path'])
    identity(baseline_dir / 'report.json', baseline_metadata['report_sha256'])
    baseline_report = load(baseline_dir / 'report.json')
    baseline_rows = {r['id']: r for r in baseline_report['results']}
    original_selection = load(DIRECTORIES['prior'] / 'original-selection.json')['cases']
    current_selection = load(ROOT / 'tests/fixtures/m2/cases.json')['cases']
    if original_selection != current_selection:
        raise ValueError('Original independent selection definitions changed')
    definitions = {r['id']: r for r in original_selection}
    observed_statuses = []
    for row in prior['results']:
        folder = DIRECTORIES['prior'] / 'cases' / row['id']
        baseline_folder = baseline_dir / 'cases' / row['id']
        java = baseline_rows[row['id']]['java']
        if load(folder / 'rust.process.json') != row['rust']:
            raise ValueError('Prior replay process metadata differs from report')
        identity(folder / 'input.pkl', row['input_sha256'])
        if (folder / 'input.pkl').read_bytes() != (baseline_folder / 'input.pkl').read_bytes():
            raise ValueError('Original Java/Rust input bytes differ')
        for engine, process, directory in [('java', java, baseline_folder), ('rust', row['rust'], folder)]:
            for channel in ['stdout', 'stderr']:
                identity(directory / (engine + '.' + channel + '.bin'), process[channel + '_sha256'])
        identity(baseline_folder / 'java.outcome.bin', java['outcome_sha256'])
        observed_status = language_tool.status(definitions[row['id']], java, row['rust'],
            (baseline_folder / 'java.stdout.bin').read_bytes(), (baseline_folder / 'java.stderr.bin').read_bytes(),
            (folder / 'rust.stdout.bin').read_bytes(), (folder / 'rust.stderr.bin').read_bytes(),
            (baseline_folder / 'java.outcome.bin').read_bytes())
        if row['status'] != observed_status:
            raise ValueError('Prior selection verdict differs from original raw bytes')
        observed_statuses.append(observed_status)
    from collections import Counter
    if dict(Counter(observed_statuses)) != prior['status_counts']:
        raise ValueError('Prior selection counts disagree with raw bytes')
    if len(prior['results']) != 1291 or not prior['prior1291_definitions_preserved'] or not prior['prior1291_input_bytes_preserved']:
        raise ValueError('Prior selection definitions/input preservation failed')
    if {r['id'] for r in prior['results'] if r['status'] != 'pass'} != KNOWN_LANGUAGE or prior['status_counts'] != language['status_counts']:
        raise ValueError('Prior selection known outcomes changed')
    return dict(language=language, platforms=platforms, frontend=frontend, runtime=runtime,
                lifecycle=lifecycle, classes=classes, class_counts=class_counts, prior=prior,
                validation=validation_report(DIRECTORIES['validation']))


def archive(source, destination):
    if destination.exists():
        raise ValueError('Refusing to replace prior archive: ' + str(destination))
    command = [sys.executable, str(ROOT / 'tools/evidence.py'), 'create', str(source), str(destination),
               '--exclude', 'build/*', '--exclude', '__pycache__/*', '--exclude', '*/__pycache__/*']
    subprocess.run(command, check=True)
    subprocess.run([sys.executable, str(ROOT / 'tools/evidence.py'), 'verify', str(destination)], check=True)
    with tarfile.open(destination, 'r:gz') as stream:
        files = len(stream.getmembers())
    return dict(path=str(destination.relative_to(ROOT)), sha256=sha(destination),
                bytes=destination.stat().st_size, files_including_inventory=files, inventory_verified=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-ready', action='store_true', help='read and verify final captures without packaging')
    args = parser.parse_args()
    data = inspect()
    for required in [REPORTS / 'stage12-class-lifecycle.json', REPORTS / 'exploration-stage12-provisional-evidence.tar.gz', BASE / 'stage12-class-relocation-proof-01/result.json']:
        if not required.is_file():
            raise ValueError('Required separate retained evidence missing: ' + str(required))
    if args.check_ready:
        print(json.dumps(dict(status='ready', class_counts=data['class_counts'],
              selected_count=data['language']['selected_count'], validation={k: data['validation'][k]
              for k in ['rust_passed', 'rust_intentionally_ignored', 'python_passed']}), sort_keys=True))
        return
    outputs = [REPORTS / name for name in ['stage12-final-summary.json', 'validation-stage12-final.json']]
    outputs += [REPORTS / (name + '-stage12-final-evidence.tar.gz')
                for name in ['language', 'validation', 'platforms', 'gates', 'regressions']]
    gates_dir, regressions_dir = BASE / 'gates-stage12-final', BASE / 'regressions-stage12-final'
    if any(path.exists() for path in [*outputs, gates_dir, regressions_dir]):
        raise ValueError('Refusing to replace an existing Stage 12 final output')
    gates_dir.mkdir()
    gates = []
    for name, expected in [('report', 0), ('development', 0), ('subset', 1), ('full', 1)]:
        command = [sys.executable, 'tools/m2_language.py', '--verify-' + name, str(DIRECTORIES['language'])]
        result = subprocess.run(command, cwd=ROOT, capture_output=True)
        row = dict(gate=name, command=command, exit_code=result.returncode, expected_exit_code=expected)
        for channel in ['stdout', 'stderr']:
            path = gates_dir / (name + '.' + channel + '.bin')
            path.write_bytes(getattr(result, channel))
            row[channel + '_sha256'] = sha(path)
        gates.append(row)
        if result.returncode != expected:
            raise ValueError('Unexpected gate result; original failure capture retained: ' + name)
    write_new(gates_dir / 'report.json', dict(scope='Raw integrity and selected development gates; strict selected/full compatibility failures retained.', rows=gates))
    regressions_dir.mkdir()
    for name in ['frontend', 'runtime', 'lifecycle', 'prior']:
        shutil.copytree(DIRECTORIES[name], regressions_dir / name,
                        ignore=shutil.ignore_patterns('build', '__pycache__'))
    shutil.copytree(BASE / 'stage12-class-relocation-proof-01', regressions_dir / 'class-relocation-proof',
                    ignore=shutil.ignore_patterns('artifact', '__pycache__'))
    # Keep the packager itself reviewable without importing old stage summaries.
    shutil.copyfile(Path(__file__), regressions_dir / 'package_stage12_final.py')
    archives = {name: archive(DIRECTORIES[name] if name in DIRECTORIES else
                (gates_dir if name == 'gates' else regressions_dir),
                REPORTS / (name + '-stage12-final-evidence.tar.gz'))
                for name in ['language', 'validation', 'platforms', 'gates', 'regressions']}
    language, platforms, lifecycle = data['language'], data['platforms'], data['lifecycle']
    class_summary = REPORTS / 'stage12-class-lifecycle.json'
    exploration = REPORTS / 'exploration-stage12-provisional-evidence.tar.gz'
    if not class_summary.is_file() or not exploration.is_file():
        raise ValueError('Separate class/exploration evidence must already be retained')
    with tarfile.open(exploration, 'r:gz') as stream:
        exploration_files = len(stream.getmembers())
    if exploration_files != 2537:
        raise ValueError('Interrupted/superseded archive denominator changed')
    summary = dict(schema_version=1,
        scope='Stage 12 bounded evaluator-owned class singleton publication and partial-class retry. Existing selected language, M1 architecture and GC/Host lifecycle regressions remain separate. Full M2 language/API compatibility and performance targets remain incomplete.',
        full_m2_complete=False,
        source_to_commit_binding='Pending separate exact implementation-commit verification; source snapshots and recorded-build identities verified here.',
        language={key: language[key] for key in ['selected_count', 'status_counts', 'source_stability', 'artifact_stability', 'candidate', 'inventory_counts']},
        class_lifecycle=dict(data['class_counts'], compatibility_complete=False, separate_summary=str(class_summary.relative_to(ROOT)),
            separate_summary_sha256=sha(class_summary), unexecuted_groups=data['classes']['unexecuted_groups'],
            scope='Ordered calls share one evaluator/module; excluded from the independent 1291 selected-expression denominator.'),
        platforms={key: platforms[key] for key in ['total', 'oracle_passed', 'shared_engine_passed', 'compatibility_status', 'known_gaps', 'experiment_contract_status', 'source_stability']},
        regressions=dict(frontend_raw_matches=sum(r['passed'] for r in data['frontend']['results']),
            runtime_value_matches=sum(r['status'] == 'bounded-value-bytes-match' for r in data['runtime']['cases']),
            runtime_diagnostic_matches=sum(r['status'] == 'diagnostic-bytes-match' for r in data['runtime']['cases']),
            runtime_diagnostic_mismatches=sum(r['status'] == 'diagnostic-byte-mismatch' for r in data['runtime']['cases']),
            runtime_known_diagnostic_mismatch_ids=['forcing-cycle'],
            lifecycle_protocol_matches=sum(r['observations']['protocol_raw_equal'] for r in lifecycle['cases']),
            lifecycle_full_diagnostic_mismatches=sum(not item['raw_equal'] for r in lifecycle['cases'] for item in r['observations']['diagnostics'])),
        validation={key: data['validation'][key] for key in ['rust_passed', 'rust_intentionally_ignored', 'python_passed']},
        prior_selection_replay=dict(count=len(data['prior']['results']), status_counts=data['prior']['status_counts'],
            scope='Original 1291 definitions/input bytes against retained prior Java captures, using frozen stage12-preflight-candidate-01; separate fresh Java acquisition above.'),
        gates=gates, archives=archives,
        exploration=dict(path=str(exploration.relative_to(ROOT)), sha256=sha(exploration), evidence_files=exploration_files-1,
            scope='Interrupted and superseded captures retained separately; not passing compatibility cases.'),
        source_report_identities={name: dict(path=str(directory / 'report.json'), sha256=sha(directory / 'report.json'))
                                 for name, directory in DIRECTORIES.items()},
        reviewed_mappings=dict(count=len(load(ROOT / 'compatibility/m2-mappings.json')['requirements']), scope='Partial reviewed mappings; strict full-gate failures remain open.'))
    summary['language'].update(source_snapshot_count=len(language['source_sha256']),
        metamorphic_relations=len(language['metamorphic_results']),
        metamorphic_statuses=[r['status'] for r in language['metamorphic_results']],
        full_gate_failure_reasons=len(language['full_gate_failures']),
        known_failures=[dict(id=r['id'], status=r['status']) for r in language['results'] if r['status'] != 'pass'],
        power_assertion_profiles=sum(r.get('power_assertions', False) for r in load(ROOT / 'tests/fixtures/m2/cases.json')['cases']))
    summary['platforms'].update(node_scenarios=len(platforms['execution']['nodeChecks']),
                                browser_scenarios=len(platforms['execution']['browserChecks']))
    write_new(REPORTS / 'validation-stage12-final.json', data['validation'])
    write_new(REPORTS / 'stage12-final-summary.json', summary)
    print(json.dumps(dict(summary='reports/m2/stage12-final-summary.json', validation=summary['validation'],
                         language=language['status_counts'], class_counts=data['class_counts'], archives=archives), sort_keys=True))


if __name__ == '__main__':
    main()
