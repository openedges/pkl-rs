"""Publish actual closed Stage53 observations without dropping earlier failures."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
TARGET = ROOT / 'target/m2'
REPORTS = ROOT / 'reports/m2'
sys.path.insert(0, str(ROOT / 'tools'))
import evidence

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def get(name):
    return json.loads((TARGET / name).read_bytes())

def put(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

validation = get('stage53-validation-02/report.json')
comparison = get('stage53-parameterized-final-02/report.json')
originals = get('stage53-original-mixins-01/report.json')
platforms = get('stage53-platforms-01/report.json')
assert validation['complete'] and validation['sourceStable']
assert len(validation['commands']) == 17 and all(row['exitCode'] == 0 for row in validation['commands'])
assert comparison['status'] == 'passed' and len(comparison['case_ids']) == 85
assert len(comparison['oracle_boundaries']) == 7
assert originals['complete'] and originals['selected_status'] == originals['integrity_status'] == 'passed'
assert originals['status_counts'] == {'pass': 3}
assert platforms['experiment_contract_status'] == 'pass' and platforms['compatibility_status'] == 'fail'
REPORTS.mkdir(parents=True, exist_ok=True)

archive_rows = []
for source, name in [
    ('stage53-oracle-publication-01/oracle-evidence.tar.gz', 'stage53-oracle-evidence.tar.gz'),
    ('stage53-candidate-publication-01/candidate-evidence.tar.gz', 'stage53-candidate-evidence.tar.gz'),
]:
    original = TARGET / source
    destination = REPORTS / name
    assert not destination.exists()
    shutil.copyfile(original, destination)
    assert sha(original) == sha(destination)
    evidence.verify(destination)
    archive_rows.append({'path': str(destination.relative_to(ROOT)), 'sha256': sha(destination), 'bytes': destination.stat().st_size})

gather = OUT / 'validation-and-review'
gather.mkdir()
directories = [
    'stage53-validation-01', 'stage53-validation-02',
    'stage53-original-mixins-prep-01', 'stage53-original-mixins-01', 'stage53-original-mixins-audit-01',
    'stage53-final-comparison-audit-01', 'stage53-core-review-01',
    'stage53-next-scope-review-01', 'stage53-semantics-review-01',
    'stage53-runner-review-01', 'stage53-runner-review-correction-01',
    'stage53-oracle-relative-uri-driver-freeze-02',
    'stage53-implementation-compare-01', 'stage53-implementation-compare-02',
    'stage53-implementation-nested-01', 'stage53-manifest-refresh-01',
    'stage53-build-cache-cleanup-01',
]
directories.extend(path.name for path in sorted(TARGET.glob('stage53-native-relative-read-unit-*')) if path.is_dir())
mapping, exclusions = [], []

def copy(source, name):
    assert not source.is_symlink() and source.is_file(), source
    before = sha(source)
    destination = gather / name
    assert not destination.exists(), destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    assert sha(destination) == before == sha(source)
    mapping.append({'original': str(source), 'archive_path': name, 'bytes': source.stat().st_size, 'sha256': before})

for name in directories:
    base = TARGET / name
    assert base.is_dir(), base
    for path in sorted(base.rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file():
            continue
        relative = path.relative_to(base).as_posix()
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            exclusions.append({'path': str(path), 'sha256': sha(path), 'reason': 'Generated Python import cache, not source or compatibility evidence; retained locally.'})
        elif name == 'stage53-build-cache-cleanup-01' and relative == 'processes.before.bin':
            exclusions.append({'path': str(path), 'sha256': sha(path), 'reason': 'Unrelated host process command lines retained locally. Cleanup report and observed absence of active Cargo/rustc are published; this is not compatibility evidence.'})
        else:
            copy(path, name + '/' + relative)

setup = ROOT.parent / 'pkl-rs.stage52/target/m2/stage53-worktree-setup-01'
for path in sorted(setup.rglob('*')):
    if path.is_file():
        copy(path, 'stage53-worktree-setup-01/' + path.relative_to(setup).as_posix())
for name in ['stage53-oracle-publication-01', 'stage53-candidate-publication-01']:
    for path in sorted((TARGET / name).iterdir()):
        if path.is_file() and not path.name.endswith('.tar.gz'):
            copy(path, name + '/' + path.name)

receipts = {
    'validation01': {'session': 54992, 'terminal_chunk': 'f0c044', 'exit_code': 0},
    'platform_wrapper01': {'session': 21297, 'terminal_chunk': '8cb3c7', 'exit_code': 0, 'qualification': 'Wrapper completed; first parameterized comparison exit1 and M1 strict exit1 are retained.'},
    'validation02': {'session': 61412, 'terminal_chunk': 'b7fa43', 'exit_code': 0},
    'comparison_wrapper02': {'session': 45487, 'terminal_chunk': 'cd94b4', 'exit_code': 0},
    'original_three': {'session': 46157, 'terminal_chunk': 'b5b2ec', 'exit_code': 0},
}
put(gather / 'root-terminal-observations.json', receipts)
put(gather / 'copy-map.json', mapping)
put(gather / 'exclusions.json', exclusions)
shutil.copyfile(ROOT / 'tools/evidence.py', gather / 'evidence.py')
destination = REPORTS / 'stage53-validation-review-evidence.tar.gz'
assert not destination.exists()
evidence.create(gather, destination, [])
archive_rows.append({'path': str(destination.relative_to(ROOT)), 'sha256': sha(destination), 'bytes': destination.stat().st_size})

test_output = (TARGET / 'stage53-validation-02/workspace-tests.stdout.bin').read_text()
counts = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored', test_output)
rust = dict(zip(['passed', 'failed', 'ignored'], [sum(int(row[i]) for row in counts) for i in range(3)]))
python_counts = {}
for name in ['m2-python-tests', 'parameterized-python-tests', 'compat-python-tests']:
    text = (TARGET / 'stage53-validation-02' / (name + '.stderr.bin')).read_text()
    python_counts[name] = int(re.search(r'Ran (\d+) tests?', text).group(1))
manifest = json.loads((ROOT / 'compatibility/m2-language.json').read_bytes())
checkpoint = {
    'schema': 1, 'scope': 'Stage53 shared object-body parameter and Mixin semantics. Local bounded implementation checkpoint; whole M2 remains incomplete.',
    'createdUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
    'implementationCommitBinding': 'Pending the actual Git commit; exact current sources are retained in validation02 and comparison02 snapshots. No predicted commit identifier is used.',
    'baseline': manifest['baseline'],
    'implementation': ['Object-body parameter AST/resolution and first-call checks', 'Raw parent arguments versus checked lazy captures', 'Currying, eager generator scope, nested validation and diagnostic ordering', 'Mixin declaration identity and delegated explicit/inferred defaults', 'Traced raw arguments and retained executable ownership'],
    'ordinaryComparison': {'cases': 85, 'javaSuccessCases': 56, 'javaLanguageErrorCases': 29, 'repetitionsPerTarget': 2, 'targets': {target: {'executions': row['executions'], 'passed': row.get('passingExecutions', row.get('statuses', {}).get('pass', 0))} for target, row in comparison['targets'].items()}, 'totalExecutions': 510, 'rawChannelsMatched': ['stdout', 'stderr', 'exit_code'], 'javaInternalErrorBoundaries': 7, 'boundaryCandidateExecution': 'not-requested; retained as nonpasses'},
    'originalModules': {'cases': originals['selected_case_ids'], 'passed': 3, 'channels': ['stdout', 'stderr', 'exit_code', 'generated_file_set_and_bytes'], 'qualification': 'Parser original produces empty output; the two generator originals produce actual output. Each case has one Java and one Rust process, independently verified twice without reevaluation.'},
    'validation': {'commands': [{'name': row['name'], 'exitCode': row['exitCode']} for row in validation['commands']], 'sourceInputs': validation['sourceCount'], 'sourceStable': validation['sourceStable'], 'host': validation['host'], 'rustWorkspaceHarnessObservations': rust, 'rustCountQualification': 'Includes nested harness observations, not distinct features. The ignored frontend probe is not counted as an executed passing unit test.', 'nativeAdapterTests': 4, 'pythonTests': python_counts, 'jsTests': 13},
    'platformRegression': {key: platforms[key] for key in ['total', 'oracle_passed', 'shared_engine_passed', 'compatibility_status', 'experiment_contract_status', 'known_gaps', 'source_stability']},
    'platformRegressionReuse': get('stage53-comparison-run-02/report.json')['platformEvidenceReuse'],
    'historicalFailure': {'candidate01': {'perTargetExecutions': 170, 'perTargetPass': 164, 'perTargetAcquisitionFailures': 6}, 'cause': 'Adapter incorrectly equated the authored relative resource URI with the resolved absolute URI.', 'correction': 'Preserve both identities and enforce exact declared resolved URI/resource bytes. Native and JS regressions cover relative and undeclared resources.', 'originalEvidencePreserved': True},
    'sourceRefresh': get('stage53-manifest-refresh-01/report.json'),
    'inventoryCounts': manifest['counts'],
    'independentAudits': [{'path': name, 'sha256': sha(TARGET / name)} for name in ['stage53-final-comparison-audit-01/report.json', 'stage53-original-mixins-audit-01/report.json']],
    'archives': archive_rows,
    'fullM2Complete': False, 'fullCompatibilityComplete': False, 'hostedCIClaimed': False, 'performanceTargetClaimed': False,
    'remaining': ['All nine M2 workstreams and strict full-language inventory gate remain open.', 'The new arbitrary-expression fixture is a separate selected contract, not a complete mapping or passing execution of every inventory row.', 'Remaining module initialization/inheritance, lazy/recursive types/constraints, collection/Reference metadata and complete diagnostics.', 'Original-suite stdlib/rendering/loading dependencies, deprecation warnings, reflection and URI gaps remain required.', 'Seven Java internal boundaries and two known Java regex discrepancies remain nonpasses.', 'Full API/platform coverage and execution-time/peak-memory targets remain unverified.'],
}
put(REPORTS / 'stage53-implementation-checkpoint.json', checkpoint)
put(OUT / 'publication.json', {'archives': archive_rows, 'checkpointSha256': sha(REPORTS / 'stage53-implementation-checkpoint.json'), 'copiedValidationReviewFiles': len(mapping), 'exclusions': exclusions, 'complete': True})
print(json.dumps({'archives': archive_rows, 'validation': rust, 'python': python_counts, 'copiedValidationReviewFiles': len(mapping)}, indent=2))
