"""Bind final recorded inputs to actual Git blobs after the implementation commit."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import sys

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
TARGET = ROOT / 'target/m2'
sys.path.insert(0, str(ROOT / 'tools'))
import evidence

def sha(data):
    return hashlib.sha256(data).hexdigest()

def put(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

assert not (OUT / 'report.json').exists()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip()
assert subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all']) == b''
assert subprocess.check_output(['git', 'rev-parse', '--show-object-format']).strip() == b'sha1'
catalogs = ['stage53-validation-02/sources.json', 'stage53-comparison-run-02/sources.json', 'stage53-original-mixins-01/sources.json']
expected, identities = {}, {}
for name in catalogs:
    payload = (TARGET / name).read_bytes()
    identities[name] = {'sha256': sha(payload), 'entries': len(json.loads(payload))}
    for path, digest in json.loads(payload).items():
        assert '\n' not in path and '\r' not in path
        assert expected.get(path, digest) == digest
        expected[path] = digest
groups = {'project': {'root': ROOT, 'commit': commit, 'paths': []}}
for path in sorted(expected):
    if path.startswith('external/'):
        parts = Path(path).parts
        prefix = '/'.join(parts[:2])
        if prefix not in groups:
            tree = subprocess.check_output(['git', 'ls-tree', commit, '--', prefix]).decode().strip()
            mode, kind, rest = tree.split(' ', 2)
            oid, name = rest.split('\t', 1)
            assert mode == '160000' and kind == 'commit' and name == prefix
            actual = subprocess.check_output(['git', '-C', str(ROOT / prefix), 'rev-parse', 'HEAD']).decode().strip()
            assert actual == oid
            groups[prefix] = {'root': ROOT / prefix, 'commit': oid, 'paths': [], 'gitlink': tree}
        groups[prefix]['paths'].append((path, '/'.join(parts[2:])))
    else:
        groups['project']['paths'].append((path, path))
bindings = []
commands = []
for key, group in groups.items():
    label = key.replace('/', '-')
    requests = ''.join(group['commit'] + ':' + relative + '\n' for _, relative in group['paths']).encode()
    (OUT / (label + '.requests.bin')).write_bytes(requests)
    argv = ['git', '-C', str(group['root']), 'cat-file', '--batch']
    result = subprocess.run(argv, input=requests, capture_output=True)
    (OUT / (label + '.objects.bin')).write_bytes(result.stdout)
    (OUT / (label + '.stderr.bin')).write_bytes(result.stderr)
    commands.append({'argv': argv, 'exitCode': result.returncode, 'stdoutSha256': sha(result.stdout), 'stderrSha256': sha(result.stderr)})
    assert result.returncode == 0
    offset = 0
    for path, relative in group['paths']:
        end = result.stdout.index(b'\n', offset)
        oid, kind, length = result.stdout[offset:end].split()
        assert kind == b'blob'
        size = int(length)
        payload = result.stdout[end + 1:end + 1 + size]
        offset = end + 1 + size
        assert result.stdout[offset:offset + 1] == b'\n'
        offset += 1
        digest = sha(payload)
        assert digest == expected[path] == sha((ROOT / path).read_bytes()), path
        calculated_oid = hashlib.sha1(b'blob ' + str(size).encode() + b'\0' + payload).hexdigest()
        assert calculated_oid == oid.decode()
        bindings.append({'path': path, 'repository': key, 'commit': group['commit'], 'gitPath': relative,
                         'blob': oid.decode(), 'bytes': size, 'sha256': digest})
    assert offset == len(result.stdout)
put(OUT / 'bindings.json', bindings)
for directory in ['stage53-git-01', 'stage53-oracle-publication-review-01']:
    for path in sorted((TARGET / directory).rglob('*')):
        if path.is_file():
            dest = OUT / directory / path.relative_to(TARGET / directory)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, dest)
for name in ['run.py', 'publication.json']:
    shutil.copyfile(TARGET / 'stage53-publication-01' / name, OUT / ('publication-' + name))
shutil.copyfile(ROOT / 'tools/evidence.py', OUT / 'evidence.py')
report = {'schema': 1, 'scope': 'Actual postcommit byte binding of final validation, comparison and original-module inputs; no claim that historical candidate01/helper sources equal final Git.',
          'completedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'implementationCommit': commit,
          'sourceCatalogs': identities, 'uniquePaths': len(bindings),
          'repositories': {key: {'commit': group['commit'], 'paths': len(group['paths']), **({'gitlink': group['gitlink']} if 'gitlink' in group else {})} for key, group in groups.items()},
          'commands': commands, 'allGitBlobBytesMatch': True, 'gitObjectFramingVerified': True,
          'allCurrentInputBytesMatch': True, 'differences': [],
          'bindingsSha256': sha((OUT / 'bindings.json').read_bytes()),
          'checkpointSha256': sha((ROOT / 'reports/m2/stage53-implementation-checkpoint.json').read_bytes()),
          'publicationTerminalObservation': {'session': 7356, 'chunk': 'a642af', 'exitCode': 0},
          'qualification': 'The checkpoint retains its original precommit observation. This sidecar supplies the actual implementation commit. M1 overinclusive source catalog contains two historical JS helper/test versions, explicitly separated from unchanged engine/binding inputs and frozen artifacts in the comparison02 reuse record. No Pantry blob batch is claimed unless listed in repositories.',
          'fullM2Complete': False, 'fullCompatibilityComplete': False, 'performanceTargetClaimed': False}
put(OUT / 'report.json', report)
archive = ROOT / 'reports/m2/stage53-source-binding-evidence.tar.gz'
assert not archive.exists()
evidence.create(OUT, archive, [])
report['evidenceArchive'] = {'path': str(archive.relative_to(ROOT)), 'sha256': sha(archive.read_bytes()), 'bytes': archive.stat().st_size}
put(ROOT / 'reports/m2/stage53-source-binding.json', report)
print(json.dumps({'implementationCommit': commit, 'uniquePaths': len(bindings), 'repositories': report['repositories'], 'archive': report['evidenceArchive']}, indent=2))
