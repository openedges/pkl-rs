"""Target-only Java 0.32.0 exploration for NUL property and surrogate collision."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tools"))
from collection_lookups_oracle import SOURCES  # noqa: E402
SOURCES = (*SOURCES, "external/pkl/pkl-parser/src/main/java/org/pkl/parser/Lexer.java")

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def main():
    if (OUT / "provenance.json").exists():
        raise ValueError("fresh target-only probe required")
    lock = json.loads((ROOT / "oracle.lock.json").read_bytes())
    jar = ROOT / ".cache/oracle" / lock["artifact"]["filename"]
    if sha(jar) != lock["artifact"]["sha256"]:
        raise ValueError("pinned jar identity differs")
    rows = json.loads((OUT / "cases.json").read_bytes())["rows"]
    shutil.copyfile(ROOT / "tools/java/CollectionConversionsOracle.java", OUT / "CollectionConversionsOracle.java")
    for name in SOURCES:
        target = OUT / "sources" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, target)
    java = Path("/usr/bin/java").resolve()
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC",
           "TERM": "dumb", "NO_COLOR": "1", "COLUMNS": "80"}
    ident = subprocess.run([str(java), "-XshowSettings:properties", "-version"],
                           cwd=OUT, env=env, capture_output=True, timeout=60)
    (OUT / "java-identity.stdout.bin").write_bytes(ident.stdout)
    (OUT / "java-identity.stderr.bin").write_bytes(ident.stderr)
    if ident.returncode:
        raise ValueError("Java identity failed")
    inputs = ("run.py", "cases.json", "queries.tsv", "module.pkl", "CollectionConversionsOracle.java")
    report = {"schema": 1, "scope": "Target-only Java NUL property and surrogate collision exploration",
              "host": platform.uname()._asdict(), "baseline": "Pkl 0.32.0",
              "jar": {"path": str(jar), "sha256": sha(jar)},
              "jdk": {"java": str(java), "sha256": sha(java),
                      "identity_stdout_sha256": sha(OUT / "java-identity.stdout.bin"),
                      "identity_stderr_sha256": sha(OUT / "java-identity.stderr.bin")},
              "environment": env, "input_before": {p: sha(OUT / p) for p in inputs},
              "source_before": {p: sha(ROOT / p) for p in SOURCES}, "sessions": [],
              "complete": False, "candidate_passes_claimed": 0}
    save(OUT / "provenance.json", report)
    options = [*lock["jvm_options"], f"-Duser.home={env['HOME']}",
               f"-Djava.io.tmpdir={env['TMPDIR']}"]
    for repeat in range(2):
        folder = OUT / f"repeat-{repeat}"
        folder.mkdir()
        command = [str(java), *options, "-cp", str(jar),
                   str(OUT / "CollectionConversionsOracle.java"), str(folder), str(OUT),
                   "file:///stage62/nul-property-collision.pkl"]
        start = time.time()
        process = subprocess.Popen(command, cwd=OUT, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
        stdout, stderr = process.communicate(timeout=240)
        (folder / "process.stdout.bin").write_bytes(stdout)
        (folder / "process.stderr.bin").write_bytes(stderr)
        session = {"repeat": repeat, "pid": process.pid, "argv": command,
                   "started_epoch": start, "finished_epoch": time.time(),
                   "exit_code": process.returncode,
                   "stdout_sha256": sha(folder / "process.stdout.bin"),
                   "stderr_sha256": sha(folder / "process.stderr.bin"),
                   "query_directories": sum(p.is_dir() for p in folder.iterdir())}
        report["sessions"].append(session)
        save(OUT / "provenance.json", report)
        print(f"repeat {repeat}: exit {process.returncode}, rows {session['query_directories']}", flush=True)
        if process.returncode or session["query_directories"] != len(rows):
            raise ValueError("Java session failed; raw files retained")
    report["input_after"] = {p: sha(OUT / p) for p in inputs}
    report["source_after"] = {p: sha(ROOT / p) for p in SOURCES}
    report["jar_after_sha256"] = sha(jar)
    raw = [{p.relative_to(OUT / f"repeat-{n}").as_posix(): sha(p)
            for p in (OUT / f"repeat-{n}").rglob("*") if p.is_file()} for n in range(2)]
    report["raw_files"] = len(raw[0])
    report["raw_equal"] = raw[0] == raw[1]
    report["complete"] = (report["input_before"] == report["input_after"] and
                           report["source_before"] == report["source_after"] and
                           report["jar"]["sha256"] == report["jar_after_sha256"] and
                           report["raw_equal"])
    save(OUT / "provenance.json", report)
    observations = []
    for index, row in enumerate(rows):
        case = OUT / "repeat-0" / f"{index:03d}-{row['id']}"
        stderr = (case / "result.stderr.bin").read_text()
        observations.append({"id": row["id"], "expression": row["expression"],
                             "status": (case / "result.status.bin").read_text().strip(),
                             "stdout": (case / "result.stdout.bin").read_text(),
                             "first_error_line": stderr.splitlines()[1] if len(stderr.splitlines()) > 1 else "",
                             "error_class": (case / "result.error-class.bin").read_text().strip()})
    save(OUT / "audit.json", {"rows": len(rows),
                              "statuses": dict(Counter(r["status"] for r in observations)),
                              "observations": observations,
                              "candidate_passes_claimed": 0})
    if not report["complete"]:
        raise ValueError("probe incomplete")

if __name__ == "__main__":
    main()
