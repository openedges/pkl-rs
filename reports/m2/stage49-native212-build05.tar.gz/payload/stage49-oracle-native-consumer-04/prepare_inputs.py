"""Export native observer tables from authenticated original Java SPI fixtures."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, os, stat

O=Path(__file__).resolve().parent
GOLDEN=O.parent/'stage49-oracle-spi-fixtures-01'
TOOL=O.parent/'stage49-oracle-spi-tools-01/modulekey_fixtures.py'
TOOL_SHA='14b95a5cf0b9268b7072a0070d1b2f289c00f67c8212ca0b5ace3aa5174306c8'
sha=lambda b:hashlib.sha256(b).hexdigest()
def module():
    spec=importlib.util.spec_from_file_location('modulekey_fixture_verifier',TOOL)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def construct():
    m=module();proof=m.verify(GOLDEN);bundle=json.loads((GOLDEN/'fixtures.json').read_bytes());files={};cases=[]
    for f in bundle['fixtures']:
        key=f"{f['cohort']}/{f['id']}/{f['repeat']}/{f['session']}";base='cases/'+key
        ops=''.join(op['kind']+'\t'+('' if op['kind']=='gc' else op['expression'] if op['kind']=='evaluate' else op['value']).encode().hex()+'\n' for op in f['operations'])
        files[base+'/source.pkl']=f['source'].encode();files[base+'/operations.tsv']=ops.encode()
        plan=[]
        for index,p in enumerate(f['moduleProviders']):
            source_rel=base+'/provider-'+str(index)+'.pkl';files[source_rel]=p['sourceText'].encode()
            # Absolute original source path exists and is independently authenticated by golden provenance.
            plan.append('\t'.join([p['requestedUri'],p['selectedUri'],p['resolvedUri'],p['originalAbsoluteSource'],p['cacheMode']])+'\n')
        files[base+'/module-plan.tsv']=''.join(plan).encode()
        cases.append({**f,'key':key,'sourceFile':base+'/source.pkl','operationsFile':base+'/operations.tsv','modulePlanFile':base+'/module-plan.tsv','profile':'provided-primary-modulekey-v1','rawApiCount':len(f['expected']),'runnable':True,'unexecutedReason':None})
    files['causes.tsv']=b''
    result={'schema':1,'profile':'provided-primary-modulekey-v1','cases':cases,'javaApiCalls':bundle['javaApiCalls'],'runnableApiCalls':sum(c['rawApiCount'] for c in cases if c['runnable']),'unexecutedApiCalls':sum(c['rawApiCount'] for c in cases if not c['runnable']),'javaOrderedEvents':bundle['javaOrderedEvents'],'golden':str(GOLDEN),'goldenManifestSha256':proof['manifestSha256'],'fixtureVerifier':str(TOOL),'fixtureVerifierSha256':sha(TOOL.read_bytes()),'scope':bundle['scope'],'fullLifecycleGate':'Full original actual events and counter bytes stay strict. Provided-primary profile is not public primary/repl lifecycle.'}
    files['inputs.json']=m.dump(result);return files,result
def export(output):
    m=module();m.check(not output.exists(),'fresh native input output');files,_=construct();output.mkdir(parents=True)
    for rel,b in files.items():
        p=output/m.safe(rel);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    (output/'manifest.json').write_bytes(m.dump({'schema':1,'files':{rel:{'sha256':sha(b),'bytes':len(b)} for rel,b in files.items()}}));return verify(output)
def verify(output):
    m=module();files,result=construct();m.coverage(output,set(files)|{'manifest.json'})
    expected={'schema':1,'files':{rel:{'sha256':sha(b),'bytes':len(b)} for rel,b in files.items()}}
    m.check(json.loads(m.regular(output,'manifest.json'))==expected,'native input manifest exact')
    for rel,b in files.items():m.check(m.regular(output,rel)==b,'native Java-derived input bytes')
    return {'files':len(files)+1,'runnableApiCalls':result['runnableApiCalls'],'unexecutedApiCalls':result['unexecutedApiCalls'],'allOriginalApiCalls':result['javaApiCalls'],'manifestSha256':sha(m.regular(output,'manifest.json'))}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--verify',action='store_true');p.add_argument('--fixtures',type=Path,default=GOLDEN);p.add_argument('--verifier',type=Path,default=TOOL);a=p.parse_args();GOLDEN=a.fixtures.resolve();TOOL=a.verifier.resolve();print(json.dumps(verify(a.output) if a.verify else export(a.output),indent=2))
