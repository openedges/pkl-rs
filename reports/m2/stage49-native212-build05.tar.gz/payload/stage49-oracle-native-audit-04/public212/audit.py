"""Readback of actual native132 results; no evaluator process launched."""
from pathlib import Path
import collections, hashlib, json, re, stat
O=Path(__file__).resolve().parent;B=O.parents[1];G=B/'stage49-oracle-spi-fixtures-01';N=B/'stage49-oracle-native-public212-build05-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def check(ok,msg):
    if not ok:raise ValueError(msg)
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
check(sha(G/'manifest.json')=='ebd3591361efc0a03e98e38695b120e9c625d9c09d0438fc641de420114aab97','literal golden manifest')
manifest=json.loads((G/'manifest.json').read_bytes())
for rel,row in manifest['files'].items():
    p=G/rel;check(stat.S_ISREG(p.lstat().st_mode) and sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],'unchanged golden raw/source '+rel)
bundle=json.loads((G/'fixtures.json').read_bytes());goldens={f"{f['cohort']}/{f['id']}/{f['repeat']}/{f['session']}":f for f in bundle['fixtures']}
report=json.loads((N/'report.json').read_bytes());pre=json.loads((N/'preflight.json').read_bytes())
check(sha(N/'report.json')=='1c17f4dbbed2ea2e477b939b58cd2a5aded0a3839f8653abe31e657c83e285e1','literal actual native report')
check(report['allProcessesTerminal'] and report['liveHandles']==[] and report['inputsAndToolsStable'],'closed stable producer')
check(len(report['records'])==36 and report['unexecutedApiCalls']==0,'native scope20sessions and remaining80')
counts=collections.Counter();requests=collections.Counter();checks=0;session_rows=[]
for record in report['records']:
    proc=record['process'];case=goldens[proc['key']];target=N/proc['key'];raw=target/'raw/session-0'
    check(proc['exitCode']==0 and not proc['timedOut'],'actual native process zero terminal')
    check(json.loads((target/'terminal.json').read_bytes())==proc,'actual captured terminal/report binding')
    check(sha(target/'stdout.bin')==proc['stdoutSha256'] and sha(target/'stderr.bin')==proc['stderrSha256'],'actual native process raw streams')
    check(all(Path(v).is_absolute() for v in [proc['command'][0],proc['command'][1],proc['command'][4],proc['command'][5],proc['command'][8],proc['command'][10]]),'canonical executable/source/operations/output/cause/plan paths')
    for i,e in enumerate(case['expected']):
        check((raw/f'outer-{i}.status.bin').read_bytes()==bytes.fromhex(e['statusRawHex']),'exact API status');counts[e['status']]+=1
        for channel in ['stdout','stderr']:
            b=(raw/f'outer-{i}.{channel}.bin').read_bytes();u=(raw/f'outer-{i}.{channel}.code-units.bin').read_bytes()
            check(b.hex()==e[channel+'Hex'] and u==b''.join(x.to_bytes(2,'big') for x in e[channel+'Units']),'complete JavaUTF8 and UTF16 result channels');checks+=2
        check(record['api'][i]['pass'] and all(record['api'][i]['checks'].values()),'producer API comparison raw recomputation')
    check((raw/'terminal-slots.bin').read_bytes()==b'0','actual closed heap slots zero')
    cache_by_api={};cached=True;api=0
    for op in case['operations']:
        if op['kind']=='cache':cached=op['value']=='on'
        if op['kind']=='evaluate':cache_by_api[api]=cached;api+=1
    providers={p['requestedUri']:p for p in case['moduleProviders']};keys={};resolved={};ids=[];tokens=set();j=0
    while (raw/f'module-{j}.request.bin').is_file():
        prefix=raw/f'module-{j}';read=lambda suffix:prefix.with_name(prefix.name+'.'+suffix+'.bin').read_text()
        req=read('request');completion=read('completion');kind=read('kind');ident=int(read('id'));token=read('token');api_index=int(read('api-index'))
        check(re.fullmatch(r'\d+:\d+:\d+',token) and token not in tokens,'actual unique typed token shape');tokens.add(token);ids.append(ident)
        check(0<=api_index<len(case['expected']) and bool(completion),'request associated with actual API and typed completion');requests[kind]+=1
        if req.startswith('SelectKey '):
            kid=int(re.search(r'ModuleKeyId\((\d+)\)',req)[1]);uri=re.search(r'uri: "([^"]*)"',req)[1]
            if completion.startswith('KeySelected(Ok(') and 'handle: "custom-key-' in completion:
                check(uri in providers,'actual custom factory request matches configured Java Host input');p=providers[uri]
                check(f'id: ModuleKeyId({kid})' in completion and f'handle: "custom-key-{kid}"' in completion and f'uri: "{p["selectedUri"]}"' in completion,'actual selected id/opaque handle/URI linked')
                keys[kid]=p['cacheMode']=='true' or p['cacheMode']=='dynamic' and cache_by_api[api_index]
        elif req.startswith('QueryCachePolicy ') and 'handle: "custom-key-' in req:
            kid=int(re.search(r'ModuleKeyId\((\d+)\)',req)[1]);check(kid in keys and completion==f'CachePolicy(Ok({str(keys[kid]).lower()}))','separate actual getter uses factory snapshot')
        elif (req.startswith('Resolve ') or req.startswith('ResolveKey ')) and 'handle: "custom-key-' in req:
            kid=int(re.search(r'ModuleKeyId\((\d+)\)',req)[1]);rid=int(re.search(r'ResolvedKeyId\((\d+)\)',req)[1]);check(kid in keys and f'id: ResolvedKeyId({rid})' in completion and f'handle: "custom-resolved-{rid}"' in completion,'actual resolved handle tied to selected key');resolved[rid]=kid
        elif req.startswith('LoadSource ') and 'handle: "custom-resolved-' in req:
            rid=int(re.search(r'ResolvedKeyId\((\d+)\)',req)[1]);kid=int(re.search(r'ModuleKeyId\((\d+)\)',req)[1]);check(resolved.get(rid)==kid and completion.startswith('Source(Ok('),'actual source request uses prior resolved/selected handles')
        j+=1;checks+=3
    check(all(a<b for a,b in zip(ids,ids[1:])),'actual typed request IDs monotonically increase')
    counters=dict((k,int(v))for k,v in (line.split('=',1) for line in (raw/'counters.bin').read_text().splitlines()))
    check(counters['requests']==j,'all typed requests captured')
    native=[];k=0
    while (raw/f'event-{k}.text.bin').is_file():native.append((raw/f'event-{k}.text.bin').read_bytes().hex());k+=1
    check(native==record['nativeEvents'],'actual native event stream report binding')
    full_events=native==[v['utf8Hex']for v in case['orderedEvents']]
    full_counters=all((raw/f'outer-{i}.counters-{when.lower()}.bin').read_bytes().hex()==e['counterBytes'+when+'Hex']for i,e in enumerate(case['expected'])for when in ['Before','After'])
    check(full_events==record['fullEventBytesEqual'] and full_counters==record['fullCounterBytesEqual'] and not record['fullLifecyclePass'],'full raw lifecycle gate independently remains failed')
    session_rows.append({'key':proc['key'],'pid':proc['pid'],'apiCalls':len(case['expected']),'requests':j,'rawApiPass':True,'fullLifecyclePass':False,'slots':0})
build=Path(pre['config']['buildRoot'])
for rel,h in pre['config']['buildPins'].items():check(sha(build/rel)==h,'frozen build metadata unchanged')
for rel,h in json.loads((build/'sources-after.json').read_bytes()).items():check(sha(build/'sources'/rel)==h,'frozen226 relevant source bytes')
check(sha(build/'stage49_modulekey_probe')==pre['config']['artifactSha256'],'frozen executable unchanged')
first=json.loads((B/'stage49-oracle-native-spi132-01/report.json').read_bytes());check(len(first['records'])==20 and all(r['process']['exitCode']==101 for r in first['records']),'initial launch failure preserved')
summary={'schema':1,'kind':'Independent raw readback, no evaluation','nativeRoot':str(N),'nativeReportSha256':sha(N/'report.json'),'actualToolHandle':91365,'actualToolTerminalExit':0,'rawApiPass':sum(counts.values()),'statusCounts':dict(counts),'sessions':session_rows,'typedRequests':dict(requests),'fullLifecyclePassSessions':0,'fullLifecycleFailSessions':36,'remaining80Unexecuted':False,'initialFailure':{'root':str(B/'stage49-oracle-native-spi132-01'),'actualTool':61168,'exit':1,'processes101':20,'apiReached':0,'missingApiCalls':132,'reason':'Relative CLI SOURCE path, before reading source; not runtime compatibility mismatch.'},'checks':checks,'sourceOrArtifactChanges':0,'scope':['All oldSPI212 under explicit public212 build05 profile; actual public entrypoint presence is not full event/counter parity. Non-tail arena index history remains producer-declared lifecycle limitation; code-payload retirement is shared runtime behavior.','No Java implementation-class callbacks synthesized.','No error-class/JVM lifecycle/wholeM2 completion claim.']}
write(O/'report.json',summary);write(O/'handoff.json',{'schema':1,'reportSha256':sha(O/'report.json'),'scriptSha256':sha(Path(__file__)),'nativeRoot':str(N),'nativeReportSha256':sha(N/'report.json'),'scope':summary['scope']})
print(json.dumps(summary,indent=2))
