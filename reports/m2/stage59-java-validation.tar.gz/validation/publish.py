"""Package and read back Stage 59 Java validation and exploratory evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
VALIDATION = Path(__file__).resolve().parent
HISTORY = ROOT / "target/m2/stage59-duration-oracle-01"
REPORTS = ROOT / "reports/m2"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}


def emit_archive(path, files, scope):
    entries = {name: source.read_bytes() for name, source in files.items()}
    manifest = {"schema": 1, "scope": scope,
                "members": {name: {"bytes": len(raw), "sha256": sha(raw)}
                            for name, raw in sorted(entries.items())}}
    entries["archive-manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with path.open("wb") as out:
        with gzip.GzipFile(fileobj=out, mode="wb", mtime=0, filename="") as zipped:
            with tarfile.open(fileobj=zipped, mode="w") as tar:
                for name, raw in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    tar.addfile(info, io.BytesIO(raw))
    observed = {}
    with tarfile.open(path, "r:gz") as tar:
        for member in tar:
            if not member.isfile() or member.name in observed or member.name.startswith("/") or ".." in Path(member.name).parts:
                raise ValueError("unsafe or duplicate archive member")
            raw = tar.extractfile(member).read()
            if len(raw) != member.size:
                raise ValueError("archive member size differs")
            observed[member.name] = raw
    if observed != entries:
        raise ValueError("archive full member byte readback differs")
    if json.loads(observed["archive-manifest.json"]) != manifest:
        raise ValueError("archive manifest readback differs")
    return {"archive": path.relative_to(ROOT).as_posix(), "identity": identity(path),
            "members": len(observed), "member_hash_readback": True,
            "embedded_manifest_sha256": sha(observed["archive-manifest.json"])}


def main():
    validation = json.loads((VALIDATION / "validation.json").read_bytes())
    if not (validation["complete"] is True and validation["source_stable"] is True
            and validation["snapshot_matches"] is True and len(validation["checks"]) == 8
            and all(check["exit_code"] == 0 for check in validation["checks"])):
        raise ValueError("recorded validation incomplete")
    history = json.loads((HISTORY / "provenance.json").read_bytes())
    exploratory = json.loads((HISTORY / "audit.json").read_bytes())
    if not (history["complete"] is True and history["stable"] is True and history["raw_equal"] is True
            and history["input_before"] == history["input_after"]
            and history["source_before"] == history["source_after"]
            and history["artifact_sha256"] == history["artifact_after_sha256"]
            and exploratory["rows"] == 263 and exploratory["statuses"] == {"success": 227, "error": 36}
            and len(history["sessions"]) == 2 and
            all(session["exit_code"] == 0 and session["query_directories"] == 263
                for session in history["sessions"])):
        raise ValueError("historical exploratory capture incomplete")
    for folder in ("repeat-0", "repeat-1"):
        raw = (HISTORY / folder / "process.stdout.bin").read_bytes()
        if not raw.startswith(b"session-open mode=string rows=263\n") or not raw.endswith(
                b"session-closed mode=string rows=263 public-calls=263 success=227 errors=36\n"):
            raise ValueError("historical process protocol differs")
    if history["sessions"][0]["pid"] == history["sessions"][1]["pid"]:
        raise ValueError("historical JVM repetitions not fresh")
    for name, expected in history["input_before"].items():
        if identity(HISTORY / name)["sha256"] != expected:
            raise ValueError("historical input differs")
    for name, expected in history["source_before"].items():
        if identity(HISTORY / "sources" / name)["sha256"] != expected:
            raise ValueError("historical source differs")
    validation_files = {"validation/" + p.relative_to(VALIDATION).as_posix(): p
                        for p in VALIDATION.rglob("*") if p.is_file() and p.name != ".DS_Store"}
    history_files = {"history/stage59-duration-oracle-01/" + p.relative_to(HISTORY).as_posix(): p
                     for p in HISTORY.rglob("*") if p.is_file() and p.name != ".DS_Store"}
    validation_archive = emit_archive(REPORTS / "stage59-java-validation.tar.gz", validation_files,
                                      "Stage 59 Java oracle-only validation, raw commands and source snapshots")
    history_archive = emit_archive(REPORTS / "stage59-java-history.tar.gz", history_files,
                                   "Original exploratory 263-row Java capture; superseded by canonical 274 rows")
    canonical_root = ROOT / "tests/fixtures/m2-duration-values"
    bits_root = ROOT / "tests/fixtures/m2-duration-values-bits"
    canonical_provenance = json.loads((ROOT / "target/m2/stage59-duration-oracle-02/provenance.json").read_bytes())
    bits_provenance = json.loads((ROOT / "target/m2/stage59-duration-bits-oracle-01/provenance.json").read_bytes())
    result = {
        "schema": 1, "kind": "stage59-duration-java-authority-checkpoint", "baseline": "Pkl 0.32.0",
        "canonical": {"fixture": "tests/fixtures/m2-duration-values", "rows": 274,
                      "statuses_per_session": {"success": 240, "error": 34}, "repetitions": 2,
                      "archive_identity": identity(canonical_root / "oracle-evidence.tar.gz"),
                      "archive_members": 4961, "raw_files_per_repetition": 2468,
                      "pids": [s["pid"] for s in canonical_provenance["sessions"]]},
        "raw_bits_supplement": {"fixture": "tests/fixtures/m2-duration-values-bits", "rows": 15,
                                "statuses_per_session": {"success": 15}, "repetitions": 2,
                                "archive_identity": identity(bits_root / "oracle-evidence.tar.gz"),
                                "archive_members": 419, "raw_files_per_repetition": 197,
                                "pids": [s["pid"] for s in bits_provenance["sessions"]]},
        "history": {"rows": 263, "statuses_per_session": exploratory["statuses"],
                    "pids": [s["pid"] for s in history["sessions"]],
                    "reason_superseded": "Source `===` parser errors and distinct rather than equal mixed-unit threshold keys; canonical cohort corrects these controls.",
                    **history_archive},
        "java_runtime": {"artifact_sha256": canonical_provenance["artifact_sha256"],
                         "jdk_executable_sha256": canonical_provenance["jdk"]["executable_sha256"],
                         "jdk_modules_sha256": canonical_provenance["jdk"]["modules_sha256"],
                         "jdk_release_sha256": canonical_provenance["jdk"]["release_sha256"],
                         "reference_revision": canonical_provenance["reference_revision"],
                         "canonical_artifact_before_after_equal": canonical_provenance["artifact_sha256"] == canonical_provenance["artifact_after_sha256"],
                         "bits_artifact_before_after_equal": bits_provenance["artifact_sha256"] == bits_provenance["artifact_after_sha256"]},
        "validation": {"directory": VALIDATION.relative_to(ROOT).as_posix(),
                       "record": "target/m2/stage59-java-validation-01/validation.json",
                       "record_identity": identity(VALIDATION / "validation.json"),
                       "source_stable": validation["source_stable"],
                       "checks": validation["checks"], **validation_archive},
        "candidate_compatibility_passes_claimed": 0,
        "limits": [
            "The original upstream basic/duration.pkl and api/duration.pkl programs were reviewed but are not inputs to these authored public API calls; original snippet suite replay remains separate.",
            "The canonical Java source snapshot includes unrelated basic/api reference.pkl files instead of duration.pkl. Java producer, authored inputs, pinned JAR/JDK, and complete raw call captures are present; the duration source files are captured in the separate validation source snapshot.",
            "No Rust candidate, browser, Node, typed product API, full M2, or performance compatibility is established by this Java authority checkpoint.",
        ],
    }
    dest = REPORTS / "stage59-java-checkpoint.json"
    dest.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"validation_archive": validation_archive, "history_archive": history_archive,
                      "checkpoint": identity(dest)}, sort_keys=True))


if __name__ == "__main__":
    main()
