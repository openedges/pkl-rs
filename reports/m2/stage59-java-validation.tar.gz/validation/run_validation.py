"""Record Stage 59 Java-only verification without changing sealed authorities."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(path):
    return {"bytes": path.stat().st_size, "sha256": digest(path)}


def source_names():
    names = {
        "target/m2/stage59-java-validation-01/run_validation.py",
        "oracle.lock.json", "references.lock", "compatibility/m2-language.json",
        "compatibility/m2-mappings.json", "compatibility/m2-module-eval.json",
        "tools/inventory.py", "tools/m2_manifest.py", "tools/m2_source_inputs.py",
        "tools/duration_values_oracle.py", "tools/duration_values_fixtures.py",
        "tools/duration_values_bits_oracle.py", "tools/duration_values_bits_fixtures.py",
        "tools/java/DurationValuesOracle.java", "tools/java/DurationValuesBitsOracle.java",
        "tools/tests/test_duration_values_fixtures.py",
        "tools/tests/test_duration_values_bits_fixtures.py",
    }
    names.update(p.relative_to(ROOT).as_posix() for p in (ROOT / "tools").glob("m2_*.py"))
    for folder in ("m2-duration-values", "m2-duration-values-bits"):
        names.update(p.relative_to(ROOT).as_posix()
                     for p in (ROOT / "tests/fixtures" / folder).rglob("*") if p.is_file())
    for rel in (
        "external/pkl/stdlib/base.pkl",
        "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmDuration.java",
        "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/DurationNodes.java",
        "external/pkl/pkl-core/src/main/java/org/pkl/core/util/DurationUtils.java",
        "external/pkl/pkl-core/src/main/java/org/pkl/core/Duration.java",
        "external/pkl/pkl-core/src/main/java/org/pkl/core/DurationUnit.java",
        "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/duration.pkl",
        "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/duration.pkl",
        "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/output/basic/duration.pcf",
        "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/output/api/duration.pcf",
    ):
        names.add(rel)
    return sorted(names)


def run(name, argv):
    folder = OUTPUT / "checks" / name
    folder.mkdir(parents=True)
    started = time.time()
    process = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=180)
    ended = time.time()
    stdout, stderr = folder / "stdout.bin", folder / "stderr.bin"
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    result = {"name": name, "argv": argv, "cwd": str(ROOT), "started_epoch": started,
              "finished_epoch": ended, "exit_code": process.returncode,
              "stdout": identity(stdout), "stderr": identity(stderr)}
    (folder / "process.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"{name}: {process.returncode}", flush=True)
    return result


def main():
    if (OUTPUT / "sources").exists() or (OUTPUT / "validation.json").exists():
        raise ValueError("fresh validation output required")
    names = source_names()
    before = {name: digest(ROOT / name) for name in names}
    for name in names:
        dest = OUTPUT / "sources" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, dest)
    python = sys.executable
    report = {"schema": 1, "kind": "stage59-java-authority-validation",
              "host": platform.uname()._asdict(),
              "python": {"executable": python, "executable_identity": identity(Path(python)),
                         "version": sys.version},
              "source_before": before, "checks": [], "complete": False}
    (OUTPUT / "validation.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    commands = [
        ("canonical-verifier", [python, "tools/duration_values_fixtures.py"]),
        ("bits-verifier", [python, "tools/duration_values_bits_fixtures.py"]),
        ("canonical-verifier-O", [python, "-O", "tools/duration_values_fixtures.py"]),
        ("bits-verifier-O", [python, "-O", "tools/duration_values_bits_fixtures.py"]),
        ("fixture-tests", [python, "-m", "unittest", "tools.tests.test_duration_values_fixtures",
                            "tools.tests.test_duration_values_bits_fixtures", "-v"]),
        ("fixture-tests-O", [python, "-O", "-m", "unittest", "tools.tests.test_duration_values_fixtures",
                              "tools.tests.test_duration_values_bits_fixtures", "-v"]),
        ("source-inventory", [python, "tools/inventory.py", "--check"]),
        ("m2-manifest", [python, "tools/m2_manifest.py", "--check"]),
    ]
    for name, argv in commands:
        report["checks"].append(run(name, argv))
        (OUTPUT / "validation.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    after = {name: digest(ROOT / name) for name in names}
    report["source_after"] = after
    report["source_stable"] = before == after
    report["snapshot_matches"] = before == {name: digest(OUTPUT / "sources" / name) for name in names}
    report["complete"] = (report["source_stable"] and report["snapshot_matches"]
                          and all(item["exit_code"] == 0 for item in report["checks"]))
    (OUTPUT / "validation.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    if not report["complete"]:
        raise ValueError("validation incomplete; raw attempts retained")


if __name__ == "__main__":
    main()
