"""Seal only explicitly listed new Stage19 observations; prior archives remain hash dependencies."""
from pathlib import Path
import argparse,hashlib,json,shutil,sys,subprocess,datetime,platform
sys.dont_write_bytecode=True
ROOT=Path.cwd();sys.path.insert(0,str(ROOT/'tools'));import evidence

def encoded(x):return (json.dumps(x,sort_keys=True,indent=2)+'\n').encode()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(b,s):
 if not b:raise ValueError(s)
def ident(p):return dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
def write(p,value):
 with p.open('xb')as f:f.write(encoded(value))

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('config',type=Path);parser.add_argument('staging',type=Path);args=parser.parse_args();config=json.loads(args.config.read_bytes());stage=args.staging.resolve();stage.mkdir(parents=True,exist_ok=False)
 paths=set()
 for name in config['paths']:
  p=ROOT/name;require(p.exists(),'missing explicit evidence: '+name);require(not p.is_symlink(),'symlink evidence: '+name)
  paths.update([p]if p.is_file()else(q for q in p.rglob('*')if q.is_file()))
 require(paths,'empty selected exploration');mainroot=stage/'main';supportroot=stage/'support';mainroot.mkdir();(supportroot/'payload').mkdir(parents=True)
 rows=[];unique={}
 for p in sorted(paths):
  require(not p.is_symlink()and p.resolve().is_relative_to(ROOT),'unsafe evidence: '+str(p));digest=sha(p);size=p.stat().st_size;relative=p.relative_to(ROOT).as_posix();rows.append(dict(path=relative,bytes=size,sha256=digest,mode=p.stat().st_mode&0o777,storage='payload/'+digest))
  if digest not in unique:
   dest=supportroot/'payload'/digest;shutil.copyfile(p,dest);require(sha(dest)==digest,'copy instability: '+relative);unique[digest]=size
 old_summary=ROOT/'reports/m2/stage18-final-summary.json';old=json.loads(old_summary.read_bytes());old_archives={r['path']:r for r in old['archives'].values()};old_archives.update({r['path']:r for r in old['exploration']['support_archives']})
 for name,row in old_archives.items():p=ROOT/name;require(p.stat().st_size==row['bytes']and sha(p)==row['sha256'],'historical archive identity changed: '+name)
 history=dict(summary=ident(old_summary),archives=[old_archives[k]for k in sorted(old_archives)],scope='Immutable Stage18 evidence is retained without payload duplication; these archives remain required for historical offline review, including the original native SIGABRT and broader failures.')
 support=ROOT/config['support_archive'];require(not support.exists(),'refusing existing support archive');evidence.create(supportroot,support,[]);supportrow=dict(**ident(support),blob_count=len(unique),uncompressed_unique_bytes=sum(unique.values()),inventory_verified=True)
 rehydrate='''"""Restore captured files byte-for-byte; never execute captured artifacts."""\nfrom pathlib import Path\nimport argparse,hashlib,json,os\np=argparse.ArgumentParser();p.add_argument("destination",type=Path);a=p.parse_args();root=Path(__file__).resolve().parent;dest=a.destination.resolve();dest.mkdir(parents=True,exist_ok=False);rows=json.loads((root/"ORIGINALS.json").read_bytes())["files"]\nfor row in rows:\n rel=Path(row["path"]);assert not rel.is_absolute()and ".."not in rel.parts\n data=(root/row["storage"]).read_bytes();assert len(data)==row["bytes"]and hashlib.sha256(data).hexdigest()==row["sha256"]\n out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);out.chmod(row["mode"])\nprint(f"Restored {len(rows)} files; captured artifacts were not executed.")\n'''
 (mainroot/'rehydrate.py').write_text(rehydrate);write(mainroot/'ORIGINALS.json',dict(schema=1,files=rows));write(mainroot/'SUPPORT_ARCHIVES.json',dict(archives=[supportrow]));write(mainroot/'HISTORY_DEPENDENCIES.json',history);(mainroot/'sealer.py').write_bytes(Path(__file__).read_bytes());(mainroot/'configuration.json').write_bytes(args.config.read_bytes())
 # Test the exact retained offline helper using only the packed main metadata and support payload.
 offline=stage/'offline';offline.mkdir();shutil.copytree(supportroot/'payload',offline/'payload');shutil.copyfile(mainroot/'ORIGINALS.json',offline/'ORIGINALS.json');shutil.copyfile(mainroot/'rehydrate.py',offline/'rehydrate.py');restored=stage/'restored';process=subprocess.run([sys.executable,str(offline/'rehydrate.py'),str(restored)],capture_output=True);(mainroot/'rehydration.stdout.bin').write_bytes(process.stdout);(mainroot/'rehydration.stderr.bin').write_bytes(process.stderr);require(process.returncode==0,'offline helper failed')
 for row in rows:
  original=ROOT/row['path'];copy=restored/row['path'];require(original.read_bytes()==copy.read_bytes(),'original/restored bytes differ: '+row['path']);require(sha(copy)==row['sha256']and copy.stat().st_size==row['bytes']and copy.stat().st_mode&0o777==row['mode'],'restored identity/mode differs: '+row['path'])
 proof=dict(status='pass',files=len(rows),bytes=sum(r['bytes']for r in rows),all_original_paths_sizes_hashes_and_bytes_verified=True,all_original_modes_verified=True,captured_binaries_executed=False,original_file_bytes_compared_after_sealing=True,all_archives_inventory_verified=True,support_paths_disjoint=True)
 write(mainroot/'REHYDRATION_VERIFICATION.json',proof);summary=dict(schema=1,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host=platform.platform(),scope=config['scope'],original_files=len(rows),original_bytes=proof['bytes'],unique_payloads=len(unique),unique_bytes=sum(unique.values()),historical_payloads_duplicated=False,historical_dependencies=history,observations=config['observations'],limitations=config['limitations']);write(mainroot/'SUMMARY.json',summary)
 archive=ROOT/config['main_archive'];require(not archive.exists(),'refusing existing main archive');evidence.create(mainroot,archive,[]);index=dict(main=dict(**ident(archive),inventory_verified=True),support_archives=[supportrow],rehydration=proof,summary_sha256=sha(mainroot/'SUMMARY.json'));write(ROOT/config['index'],index);print(json.dumps(index,indent=2))
if __name__=='__main__':main()
