"""Restore captured files byte-for-byte; never execute captured artifacts."""
from pathlib import Path
import argparse,hashlib,json,os
p=argparse.ArgumentParser();p.add_argument("destination",type=Path);a=p.parse_args();root=Path(__file__).resolve().parent;dest=a.destination.resolve();dest.mkdir(parents=True,exist_ok=False);rows=json.loads((root/"ORIGINALS.json").read_bytes())["files"]
for row in rows:
 rel=Path(row["path"]);assert not rel.is_absolute()and ".."not in rel.parts
 data=(root/row["storage"]).read_bytes();assert len(data)==row["bytes"]and hashlib.sha256(data).hexdigest()==row["sha256"]
 out=dest/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);out.chmod(row["mode"])
print(f"Restored {len(rows)} files; captured artifacts were not executed.")
