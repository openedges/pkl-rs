"""Read-only audit of terminal original-three raw contracts; no evaluator rerun."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'target/m2/stage53-original-mixins-01'
sys.path.insert(0, str(ROOT / 'tools'))
import compat
import m2_module_eval
import m2_workspace

failures = []
counts = Counter()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def check(condition, label):
    counts['assertions'] += 1
    if not condition:
        failures.append(label)


def main():
    report = load(EVIDENCE / 'report.json')
    selection = load(EVIDENCE / 'selection.json')
    baseline = load(EVIDENCE / 'module-workspace.json')
    profile = load(EVIDENCE / 'module-workspace-profile.json')
    corpus = load(EVIDENCE / 'sources/compatibility/corpus.json')
    registry = load(EVIDENCE / 'sources/compatibility/m2-module-eval.json')
    sources = load(EVIDENCE / 'sources.json')
    freeze_path = Path(report['freeze_authority']['path'])
    frozen = load(freeze_path)
    comparison_sources = load(ROOT / 'target/m2/stage53-comparison-run-02/sources.json')
    oracle = load(EVIDENCE / 'oracle.json')
    workspace = Path(report['workspace'])
    expected = ['pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/' + name for name in (
        'parser/lambdaTrailingCommas.pkl', 'generators/forGeneratorInMixins.pkl',
        'generators/forGeneratorInMixinWithObjectParam.pkl')]
    check(report['complete'] and report['integrity_status'] == report['selected_status'] == 'passed', 'terminal-selected-integrity')
    check(report['selected_case_ids'] == selection['case_ids'] == expected and [r['id'] for r in report['results']] == expected, 'exact-three-selection-order')
    check(report['status_counts'] == {'pass': 3} and all(r['status'] == 'pass' for r in report['results']), 'selected-counts')
    check(report['source_binding'] == 'recorded-release-build-after-source-snapshot' and report['candidate']['source_binding'] == 'recorded-build', 'recorded-build-binding')
    for field in ['artifact_stability', 'freeze_authority_stability', 'oracle_stability', 'runner_stability', 'source_snapshot_stability', 'source_stability', 'workspace_stability']:
        check(report[field] is True, field)
    check(sha(freeze_path) == report['freeze_authority']['sha256'], 'root-validation02-freeze-identity')
    check(sources == report['sources_before'], 'source-map-identity')
    for name, digest in sources.items():
        check(sha(ROOT / name) == sha(EVIDENCE / 'sources' / name) == digest == frozen.get(name) == comparison_sources.get(name), 'source-snapshot-current-freeze:' + name)
    counts['source_entries'] = len(sources)
    check(sha(Path(report['runner_path'])) == sha(EVIDENCE / 'runner.py') == report['runner_sha256'], 'runner-snapshot-identity')
    for name in ['corpus', 'registry', 'manifest']:
        path = {'corpus': 'compatibility/corpus.json', 'registry': 'compatibility/m2-module-eval.json', 'manifest': 'compatibility/m2-language.json'}[name]
        check(sha(ROOT / path) == selection[name + '_sha256'], 'selection-authority:' + name)
    check(profile == report['workspace_profile'] and profile['profile'] == m2_workspace.ORIGINAL_PROFILE, 'original-profile')
    originals = {r['id']: r for r in corpus['cases']}
    registrations = {r['id']: r for r in registry['cases']}
    cases = selection['cases']
    for case in cases:
        original = originals[case['id']]
        check(case['upstream_case'] == original and original['execution']['status'] == 'ready' and case['execution']['state'] == 'ready' and case['adapter'] == m2_module_eval.ADAPTER, case['id'] + ':unchanged-admitted-original')
        check(registrations[case['id']]['upstream_case_sha256'] == compat.digest(compat.encoded(original)) and registrations[case['id']]['input_sha256'] == case['input_sha256'] == original['source']['sha256'], case['id'] + ':registry-authentication')
    m2_workspace.validate_baseline(baseline, corpus, profile)
    m2_module_eval.validate_resource_set(baseline, corpus['sources'])
    check(compat.snapshot(workspace) == baseline, 'actual-complete-original-workspace')
    counts['workspace_entries'] = len(baseline)
    counts['retained_reference_resources'] = sum(len(r['resources']) for r in corpus['sources'])
    check(oracle == report['oracle'] and oracle['version'] == '0.32.0' and oracle['source']['revision'] == 'e51fb2f91774265666f94980ec630db794a4db2d', 'pinned-Java-oracle')
    check(sha(Path(oracle['artifact'])) == oracle['artifact_sha256'] and sha(ROOT / 'oracle.lock.json') == oracle['lock_sha256'], 'oracle-artifact-lock-identity')
    artifact = report['candidate']
    binary = Path(artifact['frozen_path'])
    check(sha(binary) == artifact['sha256'] == sha(Path(artifact['path'])), 'recorded-native-artifact-copy')
    check(artifact['build'] == report['commands'][1] and artifact['build']['argv'] == ['cargo', 'build', '-p', 'pkl-runtime', '--locked', '--release', '--example', 'module_eval_probe', '--target-dir', str(ROOT / 'target')], 'exact-recorded-release-build')
    for command in report['commands']:
        directory = EVIDENCE / 'commands' / command['name']
        metadata = load(directory / 'result.json')
        check(command['exit_code'] == metadata['exit_code'] == 0 and command['timed_out'] is metadata['timed_out'] is False, 'closed-command-exit:' + command['name'])
        for channel in ('stdout', 'stderr'):
            check(sha(directory / (channel + '.bin')) == command[channel + '_sha256'] == metadata['sha256'][channel], 'closed-command-bytes:' + command['name'] + ':' + channel)
    check((EVIDENCE / 'commands/rustc/stdout.bin').read_bytes().startswith(b'rustc 1.98.1 '), 'pinned-rustc')
    observations = []
    input_copies = []
    for case, row in zip(cases, report['results'], strict=True):
        m2_module_eval.verify_case(ROOT, workspace, case, row, EVIDENCE, oracle, binary, baseline)
        directory = EVIDENCE / 'cases' / compat.case_directory(case['id'])
        check((directory / 'input.pkl').read_bytes() == (ROOT / case['input']).read_bytes() == (workspace / case['input']).read_bytes() and sha(directory / 'input.pkl') == case['input_sha256'], case['id'] + ':unaltered-input-bytes')
        java, rust = [compat.load_capture(directory / runtime) for runtime in ('java', 'rust')]
        check(not compat.differences(java, rust), case['id'] + ':raw-channels-exit-files')
        check(java['exit_code'] == rust['exit_code'] == 0 and not java['timed_out'] and not rust['timed_out'] and not java['workspace_changes'] and not rust['workspace_changes'], case['id'] + ':successful-original-contract')
        check(row['raw_channels_match'] is True and row['upstream_expected_exit_match'] is True, case['id'] + ':reported-raw-contract-verdict')
        for runtime in ('java', 'rust'):
            process = load(directory / runtime / 'process.json')
            check(process == row[runtime], case['id'] + ':' + runtime + ':process-record')
            counts['closed_original_processes'] += 1
            counts['raw_stdout_stderr_channels'] += 2
        observations.append(dict(id=case['id'], stdout_bytes=len(java['stdout']), stderr_bytes=len(java['stderr']), stdout_sha256=hashlib.sha256(java['stdout']).hexdigest(), stderr_sha256=hashlib.sha256(java['stderr']).hexdigest(), files_sha256={name: compat.digest(data) for name, data in java['files'].items()}, exit_code=0))
        # Post-capture, byte-identical archival copy from the unchanged staged
        # workspace. This is not a recapture or an alternate input graph.
        destination = OUT / 'inputs' / case['input']
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((workspace / case['input']).read_bytes())
        digest = sha(destination)
        original = case['upstream_case']
        check(digest == case['input_sha256'] == original['source']['sha256'] == baseline[case['input']]['sha256'] == sha(ROOT / case['input']) == sha(directory / 'input.pkl'), case['id'] + ':post-capture-copy-identities')
        input_copies.append(dict(id=case['id'], path=destination.relative_to(OUT).as_posix(),
                                 upstream_input=case['input'], source=original['source'],
                                 sha256=digest, bytes=destination.stat().st_size,
                                 copy_origin='unchanged staged workspace, after completed capture',
                                 declared_resources=original['resources']))
    metadata_copies = {}
    for name in ['module-workspace.json', 'module-workspace-profile.json', 'module-inputs.json', 'selection.json', 'oracle.json']:
        destination = OUT / 'metadata' / name
        destination.parent.mkdir(exist_ok=True)
        destination.write_bytes((EVIDENCE / name).read_bytes())
        check(sha(destination) == sha(EVIDENCE / name), 'archival-metadata:' + name)
        metadata_copies[name] = dict(path=destination.relative_to(OUT).as_posix(), sha256=sha(destination), bytes=destination.stat().st_size)
    inventory = load(EVIDENCE / 'inventory.json')
    actual = {p.relative_to(EVIDENCE).as_posix() for p in EVIDENCE.rglob('*') if p.is_file() and p.name != 'inventory.json'}
    check(actual == set(inventory), 'evidence-file-set')
    for name, metadata in inventory.items():
        path = EVIDENCE / name
        check(sha(path) == metadata['sha256'] and path.stat().st_size == metadata['bytes'], 'evidence-file:' + name)
    counts['evidence_files'] = len(inventory)
    result = dict(scope='Independent read-only audit of exactly three closed original module CLI contracts. Existing verification helpers performed metadata/raw checks only; no Java/Rust execution or runtime rerun.', status='passed' if not failures else 'failed', failures=failures, counts=dict(counts), observations=observations,
                  report_sha256=sha(EVIDENCE / 'report.json'), inventory_sha256=sha(EVIDENCE / 'inventory.json'), freeze_authority=report['freeze_authority'], native_artifact=artifact,
                  post_capture_input_copies=input_copies, retained_metadata=metadata_copies,
                  retained_source_tree_pins=profile['retained_sources'],
                  full_gate_accounting=dict(count=len(report['full_gate_failures']), by_prefix=dict(Counter(s.split(':', 1)[0] for s in report['full_gate_failures']))),
                  limits=['The parser input has only local functions and empty output; it does not execute its function bodies.', 'The two generator originals execute their complete unchanged original module outputs; this establishes only these selected cases.', 'The 85-case arbitrary-expression cohort and required platform/Rust checks are separate evidence.', 'All omitted required cases, unmapped requirements, Java internal errors, full API/platform/performance/RSS gates remain open.'])
    (OUT / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status=result['status'], failures=failures, counts=dict(counts), observations=observations), indent=2))
    return 0 if not failures else 1


if __name__ == '__main__':
    sys.exit(main())
