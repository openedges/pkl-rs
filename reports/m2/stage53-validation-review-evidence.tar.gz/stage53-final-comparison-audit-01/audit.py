"""Independent read-only audit of closed candidate02; no evaluator or rerun."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
CANDIDATE = ROOT / 'target/m2/stage53-parameterized-final-02'
WRAPPER = ROOT / 'target/m2/stage53-comparison-run-02'
FIXTURE = ROOT / 'tests/fixtures/m2-parameterized-object-bodies'
sys.path.insert(0, str(ROOT / 'tools'))
import parameterized_object_fixtures

failures = []
counts = Counter()
observed_units = {}
read_counts = Counter()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def check(condition, label):
    counts['assertions'] += 1
    if not condition:
        failures.append(label)


def java_utf8(units):
    return units.decode('utf-16-be', 'surrogatepass').encode('utf-8', 'replace')


def hashes(mapping, prefix, label):
    for name, expected in mapping.items():
        check(sha(prefix / name) == expected, label + ':' + name)
    counts[label] += len(mapping)


def inventory(directory, label):
    expected = load(directory / 'inventory.json')
    actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*')
              if p.is_file() and p.name != 'inventory.json'}
    check(actual == set(expected), label + ':file-set')
    for name, metadata in expected.items():
        p = directory / name
        check(sha(p) == metadata['sha256'] and p.stat().st_size == metadata['bytes'], label + ':' + name)
    counts[label] += len(expected)


def main():
    verification = parameterized_object_fixtures.verify(FIXTURE)
    cases = load(FIXTURE / 'cases.json')
    boundaries = load(FIXTURE / 'oracle-boundaries.json')
    by_id = {row['id']: row for row in cases}
    pairs = [(row['id'], repeat) for row in cases for repeat in (0, 1)]
    report = load(CANDIDATE / 'report.json')
    portable_root = CANDIDATE / 'portable'
    portable = load(portable_root / 'report.json')
    wrapper = load(WRAPPER / 'report.json')
    snapshots = load(WRAPPER / 'sources.json')
    check(len(cases) == len(by_id) == 85 and len(boundaries) == 7, 'exact-85-ordinary-7-boundaries')
    check(report['status'] == portable['status'] == 'passed' and wrapper['complete'], 'closed-passed-reports')
    check(report['case_ids'] == portable['caseIds'] == list(by_id), 'case-identity-order')
    check(report['repetitions'] == portable['repetitions'] == 2, 'two-fresh-repeats')
    check(report['fixture_manifest_sha256'] == portable['fixtureManifestSha256'] == sha(FIXTURE / 'manifest.json'), 'fixture-manifest')
    check(not report['infrastructure_errors'] and not portable['infrastructureErrors'] and not portable['browserErrors'], 'no-acquisition-browser-errors')
    check(not report['changed_inputs'] and not portable['changedInputs'] and not wrapper['changedSources'], 'reported-stability')
    check(report['portable_process']['exit_code'] == 0 and report['portable_process']['timed_out'] is False, 'portable-process-terminal')
    check(sha(CANDIDATE / report['portable_report']['path']) == report['portable_report']['sha256'], 'portable-report-binding')
    boundary_ids = {row['id'] for row in boundaries}
    for key, records, field in [('native', report['oracle_boundaries'], 'candidate_execution'),
                                ('portable', portable['oracleBoundaries'], 'candidateExecution')]:
        check({row['id'] for row in records} == boundary_ids and len(records) == 7, key + ':boundary-coverage')
        check(all(row['status'] == 'oracle-error' and row[field] == 'not-requested' for row in records), key + ':boundaries-not-passes')
    for target in ('native', 'napi', 'chromium'):
        rows = report['targets'][target]['results']
        check([(row['id'], row['repeat']) for row in rows] == pairs and len(set((row['id'], row['repeat']) for row in rows)) == 170, target + ':exact-pairs')
        check(report['targets'][target]['complete'] and report['targets'][target]['executions'] == 170, target + ':complete')
        if target != 'native':
            check(rows == portable['targets'][target]['results'], target + ':parent-child-results')
        counts[target + '_executions'] = len(rows)
        for row in rows:
            case = by_id[row['id']]
            expected = case['observations'][0]
            code = row['exit_code' if target == 'native' else 'exitCode']
            label = target + ':' + row['id'] + ':' + str(row['repeat'])
            check(code == expected['exit_code'] and row['status'] == 'pass' and all(row['checks'].values()), label + ':verdict')
            channels = {}
            directory = CANDIDATE / row['directory'] if target == 'native' else portable_root / row['channels']['stdout']['path']
            if target != 'native':
                directory = directory.parent
            for channel in ('stdout', 'stderr'):
                raw = (directory / (channel + '.bin')).read_bytes()
                channels[channel] = raw
                reference = expected['channels'][channel]
                check(raw == (FIXTURE / reference['path']).read_bytes(), label + ':' + channel + ':full-Java-bytes')
                metadata = row if target == 'native' else row['channels'][channel]
                digest = metadata[channel + '_sha256'] if target == 'native' else metadata['sha256']
                check(hashlib.sha256(raw).hexdigest() == digest, label + ':' + channel + ':recorded-hash')
                if target != 'native':
                    check(len(raw) == metadata['bytes'], label + ':' + channel + ':recorded-size')
                    units = (directory / (channel + '.utf16be.bin')).read_bytes()
                    check(len(units) % 2 == 0 and java_utf8(units) == raw, label + ':' + channel + ':UTF16-Java-UTF8')
                    observed_units[(target, row['id'], row['repeat'], channel)] = units
                counts['raw_channels'] += 1
            if target == 'native':
                check(row['timed_out'] is False and row['cwd'] == str(ROOT), label + ':process')
                command = [report['native_artifact']['frozen_path'], str(FIXTURE / case['source']), case['source_uri'], case['module_name'], case['expression']]
                for resource in case['resources']:
                    command += [resource['source_uri'], str(FIXTURE / resource['source'])]
                check(row['command'] == command, label + ':exact-command-identities')
                check(load(directory / 'process.json') == row, label + ':process-record')
                raw_trace = (directory / 'trace.tsv').read_bytes()
                check(raw_trace.endswith(b'\n') and hashlib.sha256(raw_trace).hexdigest() == row['trace_sha256'], label + ':complete-trace-hash')
                fields = {}
                for line in raw_trace.decode('utf-8').splitlines():
                    key, value = line.split('\t', 1)
                    fields.setdefault(key, []).append(value)
                def one(key):
                    values = fields[key]
                    check(len(values) == 1, label + ':single-field:' + key)
                    return values[0]
                for key, value in [('source_utf8_hex', (FIXTURE / case['source']).read_bytes()), ('source_uri_utf8_hex', case['source_uri'].encode()), ('module_name_utf8_hex', case['module_name'].encode()), ('expression_utf8_hex', case['expression'].encode())]:
                    check(bytes.fromhex(one(key)) == value, label + ':identity:' + key)
                check(one('profile') == 'arbitrary-expression-noop-logger-power-off-v1' and case['power_assertions'] is False, label + ':profile')
                check(one('session_constructed') == 'true' and one('terminal_slots') == one('terminal_depth') == '0', label + ':terminal-lifecycle')
                check(one('guest_exit_code') == str(code) and one('disposition') == ('' if code == 0 else 'language-error'), label + ':disposition')
                check(int(one('polls')) > 0 and int(one('collections')) == 2 * int(one('polls')) + 1, label + ':GC-polls')
                for channel in ('stdout', 'stderr'):
                    key = 'value_utf16be_hex' if channel == 'stdout' else 'error_utf16be_hex'
                    units = bytes.fromhex(one(key)) if (code == 0) == (channel == 'stdout') else b''
                    check(len(units) % 2 == 0 and java_utf8(units) == channels[channel], label + ':owned-UTF16:' + channel)
                    observed_units[(target, row['id'], row['repeat'], channel)] = units
                requested = fields.get('read_requested_uri_utf8_hex', [])
                resolved = fields.get('read_resolved_uri_utf8_hex', [])
                replies = fields.get('read_bytes_hex', [])
                check(len(requested) == len(resolved) == len(replies) == int(one('reads')), label + ':read-ledger-count')
                for authored, uri, reply in zip(requested, resolved, replies, strict=True):
                    authored, uri = bytes.fromhex(authored).decode(), bytes.fromhex(uri).decode()
                    configured = {r['source_uri']: (FIXTURE / r['source']).read_bytes() for r in case['resources']}
                    check(uri in configured and bytes.fromhex(reply) == configured.get(uri), label + ':resolved-resource-bytes')
                    check(authored == 'gate.txt' and authored != uri, label + ':authored-relative-preserved')
                read_counts[target] += len(resolved)
                check(not case['requires_host'] or bool(resolved), label + ':required-resource-observed')
            else:
                trace = load(portable_root / row['tracePath'])
                architecture = trace['architecture']
                check(trace['acquisitionError'] is None and architecture['sessionConstructed'] and architecture['terminalSlots'] == architecture['terminalDepth'] == 0 and architecture['ownedResultStable'], label + ':terminal-lifecycle')
                check(architecture['polls'] > 0 and architecture['collections'] == architecture['polls'] + 1, label + ':GC-polls')
                reads = [r for r in trace['requests'] if r['kind'] == 'read']
                for request in reads:
                    check(request['resolvedUri'] in {r['source_uri'] for r in case['resources']}, label + ':resolved-resource-table')
                    check(request['requestedUri'] == 'gate.txt' and request['requestedUri'] != request['resolvedUri'], label + ':authored-relative-preserved')
                read_counts[target] += len(reads)
                check(not case['requires_host'] or bool(reads), label + ':required-resource-observed')
                check(code == 0 and row['disposition'] is None or code == 1 and row['disposition'] == 'language-error', label + ':disposition')
            counts['traces'] += 1
    for identifier, repeat in pairs:
        for channel in ('stdout', 'stderr'):
            units = [observed_units[(target, identifier, repeat, channel)] for target in ('native', 'napi', 'chromium')]
            check(units[0] == units[1] == units[2], identifier + ':' + str(repeat) + ':' + channel + ':cross-target-UTF16')
    hashes(report['sources_before'], Path('/'), 'comparison_input_hashes')
    hashes(portable['inputHashes'], Path('/'), 'portable_input_hashes')
    hashes(snapshots, ROOT, 'wrapper_current_source_hashes')
    hashes(snapshots, WRAPPER / 'sources', 'wrapper_snapshot_hashes')
    check(len(snapshots) == wrapper['sourceCount'] == 4537, 'snapshot-source-count')
    check(sha(WRAPPER / 'run.py') == wrapper['runnerSha256'], 'wrapper-runner-hash')
    for row in wrapper['commands']:
        check(row['exitCode'] == 0 and sha(WRAPPER / (row['name'] + '.stdout.bin')) == row['stdoutSha256'] and sha(WRAPPER / (row['name'] + '.stderr.bin')) == row['stderrSha256'], 'closed-command:' + row['name'])
    artifact = report['native_artifact']
    check(sha(Path(artifact['original_path'])) == sha(Path(artifact['frozen_path'])) == artifact['sha256'] == wrapper['nativeBuildArtifact']['sha256'], 'native-artifact-build-copy-binding')
    reuse = wrapper['platformEvidenceReuse']
    platform_path = Path(reuse['report'])
    platform_report = load(platform_path)
    check(sha(platform_path) == reuse['sha256'], 'platform-report-reuse-hash')
    check(reuse['artifacts'] == platform_report['artifacts'], 'all-platform-artifact-identities')
    hashes(reuse['artifacts'], platform_path.parent, 'reused_artifact_hashes')
    engine = {name: digest for name, digest in platform_report['source_hashes'].items() if name.startswith('crates/') or name in {'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'}}
    check(list(engine) == reuse['unchangedEngineInputs'], 'engine-input-reuse-set')
    hashes(engine, ROOT, 'unchanged_engine_input_hashes')
    changes = [name for name, digest in platform_report['source_hashes'].items() if sha(ROOT / name) != digest]
    check(set(changes) == set(reuse['changedOverinclusivePlatformCatalogInputs']) == {'tools/platform/parameterized-object-session.mjs', 'tools/platform/parameterized-object-session.test.mjs'}, 'explicit-driver-only-platform-catalog-change')
    check(platform_report['compatibility_status'] == 'fail' and platform_report['experiment_contract_status'] == 'pass' and platform_report['oracle_passed'] == {'rust': 6076, 'node': 6076, 'browser': 6076} and platform_report['shared_engine_passed'] == platform_report['total'] == 6078, 'preserved-M1-regex-failures')
    inventory(CANDIDATE, 'candidate02_inventory')
    old = ROOT / 'target/m2/stage53-parameterized-final-01'
    old_report = load(old / 'report.json')
    prior = load(ROOT / 'target/m2/stage53-runner-review-correction-01/correction.json')
    check(sha(old / 'report.json') == prior['observed_closed_candidate']['sha256'] and old_report['status'] == 'failed', 'failed-candidate01-report-preserved')
    inventory(old, 'failed_candidate01_inventory')
    check(old_report['fixture_manifest_sha256'] == report['fixture_manifest_sha256'], 'same-independent-Java-fixture')
    for target in ('native', 'napi', 'chromium'):
        n = old_report['targets'][target]
        check(n['executions'] == 170 and (n['statuses'] == {'pass': 164, 'acquisition-failed': 6} if target == 'native' else n['passingExecutions'] == 164), target + ':historical-failure-preserved')
    result = dict(scope='Independent read-only audit of closed candidate02 raw evidence and source/artifact provenance; no evaluator, build, tests or comparison reruns.',
                  status='passed' if not failures else 'failed', failures=failures, counts=dict(counts),
                  fixture_verification=verification, ordinary_cases=85, repetitions=2,
                  targets=['native', 'napi', 'chromium'], total_candidate_executions=510,
                  oracle_boundaries=7, oracle_boundary_candidate_executions=0,
                  observed_resource_requests=dict(read_counts),
                  report_hashes={str(p): sha(p) for p in [CANDIDATE / 'report.json', portable_root / 'report.json', WRAPPER / 'report.json', WRAPPER / 'sources.json', platform_path, old / 'report.json']},
                  limits=['Java raw UTF8 stdout/stderr/exit compatibility is bounded to these 85 ordinary inputs.', 'Cross-target UTF16 agreement is observed; no independent Java UTF16 callback fixture was captured.', 'Host requests and lifecycle are candidate observations, not Java event-order/count agreement.', 'Seven Java internal-error boundaries remain unexecuted nonpasses.', 'Existing M1 regex failures, full language/API/platform/performance/RSS gates remain open.', 'Required validation02 and the three original module contracts are separate ongoing work; they were not polled or restarted.'])
    (OUT / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status=result['status'], failures=len(failures), counts=dict(counts), resource_requests=dict(read_counts)), indent=2))
    return 0 if not failures else 1


if __name__ == '__main__':
    sys.exit(main())
