"""Record required Stage53 checks against a frozen source inventory."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools'))
import m2_source_inputs
import m1_platforms

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not (OUT / 'report.json').exists(), 'Use a fresh output directory'
paths = set(m2_source_inputs.source_paths(ROOT))
paths.update(str(p.relative_to(ROOT)) for p in m1_platforms.source_paths(ROOT))
paths.update(str(p.relative_to(ROOT)) for p in (ROOT / 'tools/tests').glob('test_*.py'))
paths.update(['tools/inventory.py', 'tools/discover.py', 'tools/regression_manifest.py', 'tools/smoke_manifest.py'])
paths = sorted(paths)
before = {name: sha(ROOT / name) for name in paths}
for name in paths:
    dst = OUT / 'sources' / name
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, dst)
(OUT / 'sources.json').write_text(json.dumps(before, indent=2) + '\n')
env = dict(os.environ, CARGO_INCREMENTAL='0', PYTHONDONTWRITEBYTECODE='1')
report = {'scope': 'Stage53 required Rust checks, relevant Python verification and inventory freshness; not full-language or performance compatibility.',
          'startedUtc': utc(), 'wrapperPid': os.getpid(), 'cwd': str(ROOT),
          'baseCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD']).decode().strip(),
          'host': platform.platform(), 'python': sys.version, 'pythonExecutable': sys.executable,
          'environmentOverrides': {'CARGO_INCREMENTAL': '0', 'PYTHONDONTWRITEBYTECODE': '1'},
          'commands': [], 'complete': False, 'sourceCount': len(before),
          'runnerSha256': sha(Path(__file__))}
(OUT / 'git-status.before.bin').write_bytes(subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all']))
(OUT / 'git-diff.before.bin').write_bytes(subprocess.check_output(['git', 'diff', '--binary']))

def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

commands = [
    ('xtask', ['cargo', 'xtask', 'verify']),
    ('fmt', ['cargo', 'fmt', '--all', '--', '--check']),
    ('clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('workspace-tests', ['cargo', 'test', '--workspace', '--locked']),
    ('expression-probe-tests', ['cargo', 'test', '-p', 'pkl-runtime', '--example', 'expression_fixture_probe', '--locked']),
    ('wasm-check', ['cargo', 'check', '-p', 'pkl-runtime', '--target', 'wasm32-unknown-unknown', '--locked']),
    ('m2-python-tests', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_*.py']),
    ('parameterized-python-tests', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_parameterized_object*.py']),
    ('parameterized-js-tests', ['node', '--test', 'tools/platform/parameterized-object-session.test.mjs', 'tools/platform/compare-parameterized-objects.test.mjs']),
    ('compat-python-tests', [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_compat.py']),
    ('parameterized-fixture', [sys.executable, 'tools/parameterized_object_fixtures.py']),
    ('module-registry', [sys.executable, 'tools/m2_module_eval.py', '--check']),
    ('m2-manifest', [sys.executable, 'tools/m2_manifest.py', '--check']),
    ('inventory', [sys.executable, 'tools/inventory.py', '--check']),
    ('corpus', [sys.executable, 'tools/discover.py', '--check']),
    ('regressions', [sys.executable, 'tools/regression_manifest.py', '--check']),
    ('smoke', [sys.executable, 'tools/smoke_manifest.py', '--check']),
]
save()
for name, argv in commands:
    print('START', name, flush=True)
    start = time.monotonic()
    row = {'name': name, 'argv': argv, 'startedUtc': utc()}
    stdout, stderr = OUT / (name + '.stdout.bin'), OUT / (name + '.stderr.bin')
    with stdout.open('wb') as output, stderr.open('wb') as error:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=output, stderr=error)
        row['pid'] = child.pid
        (OUT / 'active.json').write_text(json.dumps(row, indent=2) + '\n')
        row['exitCode'] = child.wait()
    row.update(seconds=time.monotonic() - start, finishedUtc=utc(), stdoutSha256=sha(stdout), stderrSha256=sha(stderr))
    report['commands'].append(row)
    save()
    print('FINISH', name, row['exitCode'], flush=True)
    if row['exitCode'] != 0:
        report.update(failedCommand=name, finishedUtc=utc())
        save()
        raise SystemExit(row['exitCode'])
after = {name: sha(ROOT / name) for name in paths}
report.update(complete=True, finishedUtc=utc(), sourceStable=before == after,
              changedSources=[name for name in paths if before[name] != after[name]])
save()
assert before == after, 'Source changed during validation'
print('COMPLETE', len(paths), 'stable inputs', flush=True)
