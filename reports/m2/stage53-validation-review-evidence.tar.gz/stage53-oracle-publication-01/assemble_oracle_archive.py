"""Copy original Java-only evidence into a fresh archive staging tree."""
from pathlib import Path
import hashlib,json,os,platform,shutil,stat,sys
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
STAGE=OUT/'payload'
STAGE.mkdir()

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def put(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')

def files(directory):
 pending=[directory]
 while pending:
  parent=pending.pop()
  with os.scandir(parent)as entries:
   for entry in sorted(entries,key=lambda e:e.name,reverse=True):
    path=Path(entry.path)
    if entry.is_symlink():raise ValueError('symlink cannot enter evidence: '+str(path))
    if entry.is_dir(follow_symlinks=False):pending.append(path)
    elif entry.is_file(follow_symlinks=False):yield path
    else:raise ValueError('nonregular original evidence: '+str(path))

roots=[(ROOT/f'target/m2/stage53-oracle-parameterized-{number:02d}',f'original-cohorts/{number:02d}','original-java-acquisition')for number in range(1,12)]
roots += [(ROOT/'target/m2/stage53-oracle-fixture-01','historical-packets/74','derived-selected-java-packet'),
          (ROOT/'target/m2/stage53-oracle-fixture-78-frozen-01','historical-packets/78','immutable-historical-fixture-and-delta'),
          (ROOT/'target/m2/stage53-oracle-fixture-81-frozen-01','historical-packets/81','immutable-historical-fixture-and-delta'),
          (ROOT/'tests/fixtures/m2-parameterized-object-bodies','final-selected-fixture','frozen-final-java-derived-fixture'),
          (ROOT/'target/m2/stage53-oracle-verification-01','verification-records/original-fixture-checks','verification-only-no-candidate-evaluation'),
          (ROOT/'target/m2/stage53-oracle-tools-final-freeze-01','verification-records/final-tool-freeze','source-hashes-only-no-candidate-evaluation')]
scripts=[ROOT/'target/m2/stage53-oracle-fixture-01-publish.py',ROOT/'target/m2/stage53-publish-supplement-08.py',ROOT/'target/m2/stage53-append-ordinary-cohort.py']
rows=[];exclusions=[];groups={}

def copy(source,name,origin):
 info=source.stat(follow_symlinks=False)
 if not stat.S_ISREG(info.st_mode):raise ValueError('not a regular evidence file: '+str(source))
 digest=sha(source)
 row=dict(original_path=str(source),worktree_relative_path=source.relative_to(ROOT).as_posix(),archive_path=name,
          bytes=info.st_size,sha256=digest,source_mode=stat.S_IMODE(info.st_mode),source_mtime_ns=info.st_mtime_ns,origin=origin)
 if '__pycache__'in source.parts and source.suffix=='.pyc':
  exclusions.append(dict(**row,reason='Redundant Python import bytecode cache; exact .py capture sources are preserved. Java probe .class bytecode and original Java output/private-runtime payloads are retained.'))
  return
 destination=STAGE/name;destination.parent.mkdir(parents=True,exist_ok=True)
 if destination.exists():raise ValueError('duplicate archive destination: '+name)
 shutil.copy2(source,destination)
 if sha(destination)!=digest or sha(source)!=digest:raise ValueError('copied/original bytes changed: '+str(source))
 rows.append(row)

for source,prefix,origin in roots:
 if source.is_symlink()or not source.is_dir():raise ValueError('missing/nonregular evidence root: '+str(source))
 before=len(rows)
 for path in sorted(files(source)):copy(path,prefix+'/'+path.relative_to(source).as_posix(),origin)
 groups[prefix]=dict(source=str(source),origin=origin,copied_files=len(rows)-before)
for source in scripts:copy(source,'scripts/'+source.name,'original-derived-publication-script')
if len({row['original_path']for row in rows})!=len(rows):raise ValueError('duplicate original path')
if len({row['archive_path']for row in rows})!=len(rows):raise ValueError('duplicate archive mapping')

cohorts=[]
for number in range(1,12):
 source=ROOT/f'target/m2/stage53-oracle-parameterized-{number:02d}'
 report=json.loads((source/'report.json').read_bytes())
 observations=report['observations']
 if any(len(row['observations'])!=2 for row in observations):raise ValueError('missing original Java repeat')
 states={}
 for row in observations:
  for call in row['observations']:
   key=str(call['process']['exit_code'])+' / '+repr(call['outcome'])
   states[key]=states.get(key,0)+1
 cohorts.append(dict(cohort=f'{number:02d}',source=str(source),original_report_sha256=sha(source/'report.json'),
                     expression_observations=len(observations),fresh_java_processes=2*len(observations),
                     original_outcome_counts=states,input_files_unchanged=report['input_files_unchanged'],
                     nonidentical_replay_ids=[row['id']for row in observations if not row['replay_equal']]))
final=ROOT/'tests/fixtures/m2-parameterized-object-bodies'
summary=json.loads((final/'summary.json').read_bytes())
authority=sha(final/'manifest.json')
freeze=json.loads((ROOT/'target/m2/stage53-oracle-tools-final-freeze-01/sources.json').read_bytes())
if authority!=freeze['tests/fixtures/m2-parameterized-object-bodies/manifest.json']:raise ValueError('final authority differs from frozen Java-derived fixture')
if summary['ordinary_cases']!=85 or summary['oracle_error_cases']!=7:raise ValueError('final unique selection count differs')
if sum(row['fresh_java_processes']for row in cohorts)!=460:raise ValueError('historical Java process accounting differs')
cli=json.loads((ROOT/'target/m2/stage53-oracle-parameterized-03/original-cli/report.json').read_bytes())
if len(cli['observations'])!=2:raise ValueError('original CLI repeat missing')
metadata=dict(schema=1,scope='Original Java acquisitions 01..11, original CLI, immutable historical derived packets and final Java-only selection; no candidate evaluation result is classified as original Java.',
              copied_regular_files=len(rows),copied_regular_file_bytes=sum(row['bytes']for row in rows),excluded_cache_files=len(exclusions),
              historical_expression_java_processes=460,original_cli_java_processes=2,total_original_java_processes=462,
              distinct_final_ordinary_cases=85,final_ordinary_successes=56,final_ordinary_language_errors=29,
              final_ordinary_java_processes=170,distinct_final_oracle_error_boundaries=7,boundary_java_processes=14,
              compatibility_passes_claimed=0,authority_manifest_sha256=authority,
              historical_counts_are_not_unique_semantic_features=True,cohorts=cohorts,groups=groups)
put(STAGE/'source-to-archive.json',dict(schema=1,files=rows,exclusions=exclusions))
put(STAGE/'oracle-publication-summary.json',metadata)
(STAGE/'README.md').write_text('''# Stage53 original Java evidence\n\nThis archive preserves the original Pkl 0.32.0 Java acquisitions, including all failed, unreached-intent, ordinary diagnostic and oracle-internal controls. `source-to-archive.json` records every original regular file, exact archived destination, SHA-256, size and source file metadata. The only exclusions are explicitly listed redundant Python import-bytecode caches. Java probe bytecode, raw process channels/outcomes, original input/resource bytes, commands/environments/runtime identities, original CLI private-state evidence and all derivation scripts remain intact. Archive headers are deterministic; original file modes and modification timestamps remain recorded in the mapping.\n\n`original-cohorts/01..11` are the original Java-only acquisitions. The original CLI is nested under cohort03. `historical-packets/74`, `78` and `81` retain the earlier selected packets, snapshots and exact admission deltas. `final-selected-fixture` is the frozen, derived final selection: 85 distinct ordinary cases and seven separately classified oracle-error boundaries. Earlier failures and raw payloads were not overwritten by later controls. The 460 historical expression processes plus two original CLI processes are acquisition/repeat counts, never additional feature passes. There is no candidate evaluator compatibility verdict in this archive.\n\n`verification-records` contains fixture-integrity/tool-test evidence and frozen source hashes. These records are explicitly separate from original Java payloads and contain no later candidate evaluation result. Source paths inside original reports are retained exactly; expected diagnostics were not rewritten. Archive creation/verification tools and their review logs remain outside this archive.\n''')
put(STAGE/'assembly-inventory.json',dict(schema=1,files={path.relative_to(STAGE).as_posix():dict(sha256=sha(path),bytes=path.stat().st_size)for path in sorted(files(STAGE))}))
# Final read-back uses only original Java/derived fixture inputs, never later candidates.
for row in rows:
 if sha(Path(row['original_path']))!=row['sha256']or sha(STAGE/row['archive_path'])!=row['sha256']:raise ValueError('final copy read-back failed')
put(OUT/'assembly-review.json',dict(schema=1,platform=platform.platform(),python=dict(executable=sys.executable,version=sys.version),
                                  copied_regular_files=len(rows),copied_regular_file_bytes=sum(row['bytes']for row in rows),
                                  exclusions=exclusions,all_original_and_copied_hashes_equal=True,
                                  authority_manifest_sha256=authority,staging_regular_files=len(list(files(STAGE))),
                                  candidate_evaluation_payloads_included=False))
print(json.dumps(dict(copied_files=len(rows),bytes=sum(row['bytes']for row in rows),excluded_caches=len(exclusions),staging_files=len(list(files(STAGE))),authority_manifest_sha256=authority),indent=2))
