"""Create and independently verify the original-Java archive; logs stay outside it."""
from pathlib import Path
import hashlib,json,os,platform,shutil,subprocess,sys,tarfile
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
archive=OUT/'oracle-evidence.tar.gz';payload=OUT/'payload'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def put(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')
env={key:value for key,value in os.environ.items()if key in ['PATH','HOME','LANG','LC_ALL','TZ','TERM','TMPDIR','TMP','TEMP']};env['PYTHONDONTWRITEBYTECODE']='1'
tool=ROOT/'tools/evidence.py';toolcopy=OUT/'tool-sources/evidence.py';toolcopy.parent.mkdir();shutil.copy2(tool,toolcopy)
records=[]
for label,args in [('create',['create',str(payload),str(archive)]),('independent-verify',['verify',str(archive)])]:
 command=[sys.executable,str(tool),*args]
 result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True)
 for channel in ['stdout','stderr']:(OUT/(label+'.'+channel+'.bin')).write_bytes(getattr(result,channel))
 record=dict(command=command,cwd=str(ROOT),environment=env,exit_code=result.returncode,stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),tool_sha256=sha(tool))
 records.append(record);put(OUT/(label+'.process.json'),record)
 if result.returncode!=0:raise ValueError(label+' failed; raw channels retained')
 if sha(tool)!=sha(toolcopy):raise ValueError('evidence tool changed')
with tarfile.open(archive,'r:gz')as tar:
 indexed={member.name:member for member in tar.getmembers()}
 evidence=json.load(tar.extractfile(indexed['EVIDENCE.json']))
 mapping=json.load(tar.extractfile(indexed['source-to-archive.json']))
 archive_paths={row['path']:row for row in evidence['files']}
 staged={path.relative_to(payload).as_posix():dict(bytes=path.stat().st_size,sha256=sha(path))for path in payload.rglob('*')if path.is_file()}
 if set(staged)!=set(archive_paths):raise ValueError('archive/staged file coverage differs')
 for name,pin in staged.items():
  row=archive_paths[name]
  data=tar.extractfile(indexed[name]).read()
  if row['sha256']!=pin['sha256']or row['bytes']!=pin['bytes']or hashlib.sha256(data).hexdigest()!=pin['sha256']:raise ValueError('archive/staged bytes differ: '+name)
 for row in mapping['files']:
  if sha(Path(row['original_path']))!=row['sha256']or archive_paths[row['archive_path']]['sha256']!=row['sha256']:raise ValueError('archive/original mapping differs')
review=dict(schema=1,scope='Independent archive structure/inventory and full copied-original raw-byte verification; no candidate compatibility verdict',platform=platform.platform(),python=dict(executable=sys.executable,version=sys.version,sha256=sha(Path(sys.executable))),commands=records,
            archive_path=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,
            archive_payload_files=len(staged),original_regular_files=len(mapping['files']),excluded_redundant_python_caches=len(mapping['exclusions']),
            archive_inventory_sha256=hashlib.sha256((json.dumps(evidence,indent=2)+'\n').encode()).hexdigest(),
            source_mapping_sha256=sha(payload/'source-to-archive.json'),assembly_review_sha256=sha(OUT/'assembly-review.json'),
            authority_manifest_sha256=sha(payload/'final-selected-fixture/manifest.json'),
            all_original_staged_archived_bytes_equal=True,symlinks_included=False,candidate_evaluation_payloads_included=False)
put(OUT/'archive-review.json',review)
put(OUT/'archive-files.json',dict(schema=1,files={p.relative_to(OUT).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(OUT.rglob('*'))if p.is_file()and not p.is_relative_to(payload)and p.name!='archive-files.json'}))
print(json.dumps(dict(archive=str(archive),sha256=review['archive_sha256'],bytes=review['archive_bytes'],files=review['archive_payload_files'],original_files=review['original_regular_files'],independent_evidence_verify_exit=records[1]['exit_code']),indent=2))
