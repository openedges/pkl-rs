"""Exact three original module contracts; no edited input or manifest overrides."""
from collections import Counter
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import tomllib
import traceback

ROOT = Path(__file__).resolve().parents[3]
PREP = Path(__file__).resolve().parent
OUTPUT = ROOT / 'target/m2/stage53-original-mixins-01'
WORKSPACE = ROOT / 'target/m2/stage53-original-mixins-01-workspace'
DEFAULT_FREEZE = ROOT / 'target/m2/stage53-validation-01/sources.json'
sys.path.insert(0, str(ROOT / 'tools'))
import compat
import m2_manifest as contract
import m2_module_eval
import m2_source_inputs
import m2_workspace
import oracle

PREFIX = 'pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/'
IDS = [PREFIX + name for name in (
    'parser/lambdaTrailingCommas.pkl',
    'generators/forGeneratorInMixins.pkl',
    'generators/forGeneratorInMixinWithObjectParam.pkl',
)]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_json(path, value):
    path.write_bytes(contract.encoded(value))


def command(name, argv, report, environment, timeout):
    generated = OUTPUT / (name + '-private-files')
    generated.mkdir()
    started = utc()
    try:
        result = compat.capture(argv, ROOT, environment, timeout, generated)
    except compat.CaptureTimeout as failure:
        result = failure.result
    directory = OUTPUT / 'commands' / name
    compat.store_capture(directory, result)
    record = dict(name=name, argv=argv, cwd=str(ROOT), started_utc=started,
                  finished_utc=utc(), timeout_seconds=timeout,
                  exit_code=result['exit_code'], timed_out=result['timed_out'],
                  stdout_sha256=sha(directory / 'stdout.bin'),
                  stderr_sha256=sha(directory / 'stderr.bin'))
    report['commands'].append(record)
    write_json(OUTPUT / 'report.json', report)
    if result['timed_out'] or result['exit_code'] != 0:
        raise ValueError('Recorded command failed: ' + name)
    return record


def evidence_inventory():
    found = {}
    for path in sorted(OUTPUT.rglob('*')):
        if path.is_symlink():
            raise ValueError('Symlink in acquisition evidence: ' + str(path))
        if path.is_file() and path.name != 'inventory.json':
            found[path.relative_to(OUTPUT).as_posix()] = dict(
                sha256=sha(path), bytes=path.stat().st_size)
    write_json(OUTPUT / 'inventory.json', found)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze-manifest', type=Path, default=DEFAULT_FREEZE,
                        help='Existing frozen source catalog from root validation')
    args = parser.parse_args()
    freeze_path = args.freeze_manifest.resolve()
    if Path.cwd().resolve() != ROOT:
        raise ValueError('Run from the frozen Stage53 worktree')
    compat.validate_paths(ROOT, WORKSPACE, OUTPUT)
    if OUTPUT.exists() or WORKSPACE.exists():
        raise ValueError('Fresh output and workspace required; preserve prior evidence')
    OUTPUT.mkdir()
    environment = dict(os.environ, CARGO_INCREMENTAL='0', PYTHONDONTWRITEBYTECODE='1')
    report = dict(
        schema_version=1,
        scope='Exactly three unchanged original upstream module CLI contracts in the complete '
              'upstream-original-modules-v1 workspace. Raw stdout/stderr/exit/files and original '
              'failure classifications remain authoritative. The local-only parser case is not '
              'execution evidence for its functions. This supplements the arbitrary-expression '
              'cohort and does not replace it or close full language/platform/performance gates.',
        cwd=str(ROOT), host=platform.platform(), python=sys.version,
        python_executable=sys.executable, python_sha256=sha(Path(sys.executable).resolve()),
        runner_path=str(Path(__file__)), runner_sha256=sha(Path(__file__)),
        started_utc=utc(), complete=False, commands=[], results=[],
        source_binding='recorded-release-build-after-source-snapshot',
        environment_overrides={'CARGO_INCREMENTAL': '0', 'PYTHONDONTWRITEBYTECODE': '1'},
        selected_case_ids=IDS, workspace=str(WORKSPACE), output=str(OUTPUT))
    write_json(OUTPUT / 'report.json', report)
    try:
        freeze_bytes = freeze_path.read_bytes()
        freeze = json.loads(freeze_bytes)
        names = m2_source_inputs.source_paths(ROOT)
        before = {name: sha(ROOT / name) for name in names}
        if any(freeze.get(name) != digest for name, digest in before.items()):
            raise ValueError('Current source catalog differs from root validation freeze')
        report['freeze_authority'] = dict(path=str(freeze_path), sha256=sha(freeze_path))
        report['sources_before'] = before
        for name in names:
            target = OUTPUT / 'sources' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, target)
            if sha(target) != before[name]:
                raise ValueError('Source changed during snapshot: ' + name)
        shutil.copyfile(Path(__file__), OUTPUT / 'runner.py')
        write_json(OUTPUT / 'sources.json', before)
        metadata = oracle.ensure_oracle(ROOT, fetch=False)
        write_json(OUTPUT / 'oracle.json', metadata)
        manifest = contract.current_manifest()
        corpus = contract.load(Path('compatibility/corpus.json'))
        registry = contract.load(m2_module_eval.REGISTRY)
        registered = m2_module_eval.registry_cases(ROOT, corpus, registry)
        by_id = {row['id']: row for row in manifest['cases']}
        cases = [by_id[identifier] for identifier in IDS]
        if len(set(IDS)) != 3 or any(
            case['id'] not in registered or case['adapter'] != m2_module_eval.ADAPTER
            or case['execution']['state'] != 'ready' for case in cases
        ):
            raise ValueError('Exact original registry selection is not admitted')
        write_json(OUTPUT / 'selection.json', dict(
            case_ids=IDS, adapter=m2_module_eval.ADAPTER, cases=cases,
            corpus_sha256=sha(ROOT / 'compatibility/corpus.json'),
            registry_sha256=sha(ROOT / m2_module_eval.REGISTRY),
            manifest_sha256=sha(ROOT / contract.MANIFEST)))
        profile = m2_workspace.profile_record(m2_workspace.ORIGINAL_PROFILE, corpus, cases)
        write_json(OUTPUT / 'module-workspace-profile.json', profile)
        report['workspace_profile'] = profile
        report['oracle'] = metadata
        write_json(OUTPUT / 'report.json', report)
        command('rustc', ['rustc', '--version', '--verbose'], report, environment, 120)
        pinned_rust = tomllib.loads((ROOT / 'rust-toolchain.toml').read_text())['toolchain']['channel']
        if not (OUTPUT / 'commands/rustc/stdout.bin').read_bytes().startswith(
            ('rustc ' + pinned_rust + ' ').encode()
        ):
            raise ValueError('Actual Rust compiler differs from rust-toolchain.toml')
        build = command('build', [
            'cargo', 'build', '-p', 'pkl-runtime', '--locked', '--release',
            '--example', 'module_eval_probe', '--target-dir', str(ROOT / 'target'),
        ], report, environment, 1200)
        original = ROOT / 'target/release/examples/module_eval_probe'
        original_hash = sha(original)
        artifacts = OUTPUT / 'artifacts'
        artifacts.mkdir()
        binary = artifacts / 'module_eval_probe'
        shutil.copy2(original, binary)
        if not original_hash == sha(binary) == sha(original):
            raise ValueError('Recorded executable changed during frozen-copy admission')
        report['candidate'] = dict(path=str(original), frozen_path=str(binary),
                                   sha256=original_hash, build=build,
                                   source_binding='recorded-build')
        write_json(OUTPUT / 'report.json', report)
        m2_workspace.prepare(ROOT, WORKSPACE, profile)
        original_manifest = dict(sources=corpus['sources'], cases=[case['upstream_case'] for case in cases])
        inputs = compat.validate_inputs(ROOT, original_manifest, WORKSPACE)
        write_json(OUTPUT / 'module-inputs.json', inputs)
        baseline = compat.snapshot(WORKSPACE)
        m2_workspace.validate_baseline(baseline, corpus, profile)
        m2_module_eval.validate_resource_set(baseline, corpus['sources'])
        write_json(OUTPUT / 'module-workspace.json', baseline)
        for case in cases:
            if compat.snapshot(WORKSPACE) != baseline:
                raise ValueError('Original workspace changed before case acquisition')
            row = m2_module_eval.acquire_case(ROOT, WORKSPACE, case, metadata, binary, OUTPUT)
            m2_module_eval.verify_case(ROOT, WORKSPACE, case, row, OUTPUT, metadata, binary, baseline)
            report['results'].append(row)
            write_json(OUTPUT / 'report.json', report)
            print(case['id'] + ': ' + row['status'], flush=True)
        for case, row in zip(cases, report['results'], strict=True):
            m2_module_eval.verify_case(ROOT, WORKSPACE, case, row, OUTPUT, metadata, binary, baseline)
        after = {name: sha(ROOT / name) for name in names}
        report.update(
            complete=True, finished_utc=utc(),
            source_stability=names == m2_source_inputs.source_paths(ROOT) and before == after,
            source_snapshot_stability=all(sha(OUTPUT / 'sources' / name) == digest for name, digest in before.items()),
            freeze_authority_stability=freeze_path.read_bytes() == freeze_bytes,
            runner_stability=sha(Path(__file__)) == report['runner_sha256'] == sha(OUTPUT / 'runner.py'),
            artifact_stability=sha(binary) == original_hash == sha(original),
            oracle_stability=oracle.ensure_oracle(ROOT, fetch=False) == metadata,
            workspace_stability=compat.snapshot(WORKSPACE) == baseline,
            status_counts=dict(Counter(row['status'] for row in report['results'])),
            inventory_counts=manifest['counts'],
            full_gate_failures=contract.full_gate_failures(manifest, report['results']),
            verification='Each original case verified twice without rerunning guest evaluation')
        integrity = all(report[key] for key in (
            'source_stability', 'source_snapshot_stability', 'freeze_authority_stability',
            'runner_stability', 'artifact_stability', 'oracle_stability', 'workspace_stability'))
        report['integrity_status'] = 'passed' if integrity else 'failed'
        report['selected_status'] = 'passed' if integrity and len(report['results']) == 3 and all(
            row['status'] == 'pass' for row in report['results']) else 'failed'
        write_json(OUTPUT / 'report.json', report)
        evidence_inventory()
        print(json.dumps(dict(complete=True, integrity_status=report['integrity_status'],
                              selected_status=report['selected_status'], statuses=report['status_counts'])), flush=True)
        return 0 if report['selected_status'] == 'passed' else 1
    except BaseException as error:
        report.update(complete=False, finished_utc=utc(), infrastructure_error=dict(
            type=type(error).__name__, message=str(error)))
        (OUTPUT / 'failure.traceback.txt').write_text(traceback.format_exc())
        write_json(OUTPUT / 'report.json', report)
        evidence_inventory()
        raise


if __name__ == '__main__':
    sys.exit(main())
