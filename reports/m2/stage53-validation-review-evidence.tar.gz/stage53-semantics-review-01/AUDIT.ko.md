# Stage 53 parameterized object body 독립 의미론 검토

## 범위와 근거

Stage 52의 고정 소스와 Stage 51 `stage51-next-parser-dependencies-01/PLAN.ko.md` Batch A를 읽었다. Stage 53 `d7d691b` 준비 완료 후 이 target에만 기록했다. 평가·build·Git·참조 checkout 변경은 실행하지 않았다. 이 문서는 Java 0.32.0 소스 해석이며 실제 Java/Rust 차등 결과나 구현 통과 판정이 아니다. 읽은 핵심 upstream 파일 SHA와 기존 완료 capture 검사는 `audit.json`에 있다.

## 구현이 보존해야 할 의미

| 경계 | 고정 Java 규칙 | 반드시 필요한 대조군 |
|---|---|---|
| 명시적 `new` | `AstBuilder.java:886`은 타입 default를 부모로 얻는다. 타입 인자가 있는 DeclaredType에는 본문 바깥 TypeCast가 추가된다. inferred `new`는 property/method/member default와 owner를 사용한다. | 명시적 class·`Mixin<T>`·Mixin을 가리키는 사용자 alias·구조적 함수 alias·타입이 있는 inferred property/method |
| 함수 alias | `TypeNode.java:2814`는 실제 `BaseModule.getMixinTypeAlias()` 선언 identity에만 identity default를 만든다. 일반 함수 타입은 default가 없다. Mixin으로 확장되는 alias는 위임을 통해 default를 얻을 수 있다. | `typealias F = (Dynamic) -> Dynamic`의 `new F`와 `typealias F = Mixin<Dynamic>`의 구별 |
| 인자 수 | `ObjectLiteralNode.java`는 body parameter 수가 0보다 클 때만 parent arity와 비교한다. ordinary parameterless amendment는 Function0/1/2 등 모두 허용한다. `{ -> ... }` 문법은 허용하지 않는다. | Function0/1/2/3, 다중 parameter, 부족·초과 count, 잘못된 call arity |
| 빈 본문 | `AstBuilder.java:2233`은 member가 없으면 parameter 타입 방문 이전에 EmptyObjectLiteralNode를 선택한다. parameter count/type 검사를 추가하면 안 된다. | 잘못된 count와 존재하지 않는 타입을 가진 빈 body, parent 자체의 실패 |
| 생성 시 순서 | parent 평가·함수 body count guard 이후 parameter 타입을 왼쪽부터 resolve한다. nonfunction 또는 빈 body에서는 이 타입 resolve를 수행하지 않는다. | wrong count + unresolved type, wrong parent + bad parameter, construction과 invocation을 별도 조회 |
| 호출 시 순서 | 최초 parameterized wrapper는 FunctionNode이므로 call count → parameter type checks → parent call이다. named slot에는 검사된 값을 넣지만 parent에는 원래 frame arguments를 전달한다. | parent 자체 오류와 parameter 오류가 동시에 있을 때 첫 오류, lazy Mapping cast의 raw/checked 구별 |
| currying | 최초 checked parameter slot은 첫 호출 frame에서 보존한다. 후속 wrapper는 SimpleRoot이고 새 parent arity를 따른다. 최종 객체를 만들 때 최초 slot을 복구한다. 후속 인자가 최초 값을 덮어쓰면 안 된다. | 서로 다른 x/y/z의 2·3단계 curry, 첫 wrapper만 typed, 두 호출 결과의 독립성 |
| 이름 조회 | `SymbolTable.ObjectScope`는 own property → 첫 일치 body binding → outer scope 순서다. `_`는 이름으로 조회되지 않는다. 중복 binding은 첫 slot이 조회된다. | property/parameter 동명이인, 중복 x,x, 반복 `_`, outer shadow, for-variable shadow |
| receiver/owner | amendment wrapper는 생성 lexical/custom-this를 유지하되 parent 호출의 receiver/owner는 parent function의 값을 사용한다. 최종 object member는 object receiver와 최초 parameter capture를 함께 가진다. | 서로 다른 parent receiver·amendment outer·object this, custom-this constraint, 반환 closure |

property-only Dynamic은 SpecializedObjectLiteral 경로에서 parameter를 금지하지 않는다. Typed/Listing/Mapping은 member validity를 먼저 검사하고 parameter를 금지한다. 반면 GeneratorObjectLiteral은 Dynamic까지 parameter를 금지하며 Null도 default redispatch 전에 guard를 적용한다. generator 오류 위치는 `parameterTypes[0]`이므로 untyped parameter의 null 위치에서 생기는 Java 내부 오류를 일반 오류로 대체하거나 성공으로 세면 안 된다. 최종 함수 amendment 실행에는 복사된 parameter 없는 literal을 쓰므로 정상적인 함수 → generator object 경로는 별도다.

일반 FunctionTypeNode는 FunctionN arity만 검사하고 원래 함수를 반환한다. 함수 타입이 호출 인자·반환 타입 wrapper를 만든다고 가정한 테스트는 근거가 없다. raw parent argument와 checked capture의 차이는 `Mapping<String, Int>`의 lazy value cast로 관측한다. 예를 들어 parent가 `raw = m["x"]`를 정의하고 amendment가 typed `m`으로 `checked = m["x"]`를 정의한 뒤 문자열 값의 Mapping을 넘겨 두 속성을 별도로 조회한다. 실제 기대 바이트는 oracle agent가 취득한다.

`SymbolTable.java:507`의 EagerGeneratorScope는 다음 ObjectScope의 property와 parameter binding을 모두 건너뛴다. parameter가 있으면 숨은 amendment 함수의 lexical level도 추가한다. 이 규칙은 for iterable·when predicate뿐 아니라 entry key·spread expression·member predicate에도 적용된다. 따라서 outer `p = "outer"`와 body parameter `p = "inner"`를 가진 `{ p -> [p] = p }`에서는 key와 value가 서로 다른 scope를 볼 수 있다. body 전체에 parameter scope를 단순 추가하면 이 경계를 깨뜨린다. nested for 변수는 별도 ForGeneratorScope이고 건너뛰지 않으며, when이 ObjectScope를 건너뛴 경우 frame skip도 필요하다. for/when body 자체의 parameter 목록은 별도의 `forWhenBodyCannotHaveParameters` 오류다.

## 수명주기 검토 항목

- 새 Frame raw argument 저장소는 BindLocal이 checked slot을 덮어쓴 뒤에도 GC root여야 한다. 실행 중·중단 중 frame을 모두 확인한다.
- 최초 checked captures가 Amendment에 저장되면 heap tracer에 명시적으로 연결한다. 기존 tracer는 amendment.parent만 직접 추적한다. 최종 lazy member environment도 capture를 유지해야 한다.
- wrapper의 동적 코드 block은 ExecutableOwner/CodeArena에 소속되어야 한다. 호출마다 소유자 없는 block append나 전역 영구 root를 추가하지 않는다. escaped curry·object·closure·class/alias가 살아 있으면 이전 code/source를 보존하고 모두 해제되면 회수한다.
- type check·parent call·generator key·lazy member에서 Host 중단, nested public reentry, 매 poll GC, 실패 후 다른 인자로 재호출, 취소·닫기를 검증한다. 실패한 최초 호출의 slot을 다음 호출에 재사용하지 않는다.
- nested for/when/spread/predicate body의 lazy 결과가 최초 parameter와 각 generator frame을 올바르게 캡처하는지 확인한다. N→10N 회수 검사는 heap 값뿐 아니라 code slots/segments/source bytes를 본다. RSS나 전체 성능 gate로 확대하지 않는다.

## 기존 broad888의 완료된 prefix 관찰

전체 실행은 진행 중이다. 이 감사는 newline으로 끝난 완료 로그를 `api/duration.pkl` 행까지만 고정했다. `completed-prefix.stdout.bin`은 그 2,973바이트이고 SHA는 `audit.json`에 있다. 기록한 모든 nonpass의 Java/Rust `process.json`이 존재하며 raw stdout/stderr SHA를 각 process 필드와 대조했다. 이후 행, inflight capture, 전체 결과·최종 건수는 판정하지 않았다. 원시 capture 경로는 `audit.json`의 `case_directory` 아래 `java`/`rust`이다.

- deprecation 관련 8개는 exit 0과 stdout은 같지만 Java WARN stderr가 Rust에서 없다. 의미 결과 성공으로 raw 경고 실패를 지우지 않는다.
- `annotation7`은 reflect, `Resource`는 md5, `benchmarkModule`은 Benchmark의 명시적 미지원이다.
- `baseModule`의 Regex와 `bytes`의 Bytes는 constructor method 누락이다.
- `annotationConverters`의 Regex.replaceAllMapped, `any`의 getClass().simpleName, `dataSize`의 isPositive, `duration`의 isBetween은 `expected an object`에서 실패했다.
- `anyConverter`와 `relativePathTo`는 양쪽 exit 0이지만 stdout이 다르다.

이 관찰은 다음 기능 우선순위의 근거이며 Stage 53 parameterized body 구현으로 해당 실패들이 해소된다는 뜻이 아니다. M2 전체 inventory·strict completion·플랫폼·성능 gate는 계속 열려 있다.

## Stage 53 첫 구현 독립 검토

구현 agent의 검토 준비 신호 후 현재 소스를 읽었다. frozen candidate 검증이나 테스트 실행은 하지 않았다. 최초 raw arguments는 별도 Frame 필드와 `Vm::collect`에 연결되고, 최초 checked locals는 기존 heap tracer가 읽는 Environment에 보존된다. 후속 wrapper는 공통 forwarding block을 쓰고 최초 wrapper에만 type/arity 검사를 적용한다. wrapper block은 일반 Compiler::block으로 source arena 안에 생성한다. 이 네 구조에는 읽은 범위에서 별도 수명주기 결손을 발견하지 못했으며 실제 GC·Host·반복 회수 결과는 구현 agent가 별도로 취득한다.

첫 검토에서 `check_object_parameters`가 `frame.amendment_end.is_some()`이면 모든 nongenerator 검사를 생략하는 문제를 발견했다. 이 flag는 outer literal의 parameter 제거만 나타내야 하지만, eager key 안에서 같은 frame으로 실행되는 **nested** literal의 parameter 오류도 가릴 수 있다. `(parent) { arg -> [(new Listing { p: Int -> 1 }).length] = arg }`가 예다. oracle agent는 별도 `stage53-oracle-parameterized-07`의 Listing/Mapping/Box 오류와 Dynamic 성공 네 입력을 각각 두 번 취득해 일치를 확인했다. 구현 agent에게 수정·회귀를 요청했다. 이 기록 시점에는 수정 검토 전이며 완료 판정하지 않는다.

추가 검토 요청은 typed `instance_body`의 `MakeInstance → initialize_member_types → CheckObjectParameters` 순서다. Java specialized typed guard는 member validity 이후 parameter를 금지하므로, local member의 미정의 타입 해석이 parameter 금지보다 먼저 실행되지 않는지 확인해야 한다. 이 항목은 source-driven 의심이며 실제 Java/Rust 차등 실패로 보고하지 않는다.

구현 agent의 후속 수정 소스를 다시 읽었다. Builder 검사에는 자신의 EndFunctionAmendment PC만 연결하고, 그 PC가 실행 frame의 값과 같을 때만 parameter 제거를 적용한다. nested Value 검사는 생략하지 않는다. typed instance의 순서도 `MakeInstance → CheckObjectParameters → initialize_member_types`로 바뀌었다. 읽은 범위에서 위 두 구조 문제는 수정됐다. 실제 supplemental raw 비교는 별도 담당 agent의 결과가 필요하다.

후속 진단 위치 검토도 요청했다. `vm.rs`의 일반 Object fallback이 `collection_body` 첫 instruction에 parent span을 덮어쓰는데, parameterized generator의 첫 instruction은 parameter type span을 가진 CheckObjectParameters일 수 있다. parent count guard와 generator 금지 guard의 서로 다른 source location을 보존해야 한다. 이 항목은 그 시점 소스의 의심이며 아직 실제 차등 실패 판정은 아니다.

구현 agent가 추가로 발견한 parser `take_object_members`의 for/when body parameter 손실도 확인했다. 기존 미지원 제거 이후 이 목록을 버리면 금지된 입력이 성공으로 바뀔 수 있다. Java `doVisitForWhenBody`는 body 목록을 방문하는 단계에서 금지하지만, 사용한 `forWhenBodyCannotHaveParameters` 키는 고정 errorMessages.properties에 없다. oracle에 별도 for·when·실행되지 않는 when branch 입력의 경계를 요청했다. 정상 입력과 분리해 AST metadata를 보존하고 명시적으로 실패시켜야 하며, Java 내부 오류를 언어 오류 일치나 성공으로 세면 안 된다.
