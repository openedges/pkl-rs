"""Read the existing verified archive once in member order; never recreate it."""
from pathlib import Path
import hashlib,json,platform,sys,tarfile
OUT=Path(__file__).resolve().parent;archive=OUT/'candidate-evidence.tar.gz';payload=OUT/'payload'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def put(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
restart=json.loads((OUT/'readback-restart.json').read_text())
if sha(archive)!=restart['archive_sha256_before']:raise ValueError('archive changed during audit restart')
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();indexed={member.name:member for member in members}
 inventory_bytes=tar.extractfile(indexed['EVIDENCE.json']).read();inventory=json.loads(inventory_bytes)
 mapping=json.loads((payload/'source-to-archive.json').read_bytes())
 declared={row['path']:row for row in inventory['files']}
 staged={p.relative_to(payload).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))for p in payload.rglob('*')if p.is_file()}
 if set(staged)!=set(declared)or set(indexed)!=set(staged)|{'EVIDENCE.json'}:raise ValueError('archive/stage/inventory coverage differs')
 for member in members:
  if member.name=='EVIDENCE.json':continue
  if not member.isfile():raise ValueError('nonregular archive member')
  data=tar.extractfile(member).read();pin=staged[member.name];record=declared[member.name]
  if record['sha256']!=pin['sha256']or record['bytes']!=pin['bytes']or len(data)!=pin['bytes']or hashlib.sha256(data).hexdigest()!=pin['sha256']:raise ValueError('archive/staged bytes differ: '+member.name)
 for row in mapping['files']:
  if sha(Path(row['original_path']))!=row['sha256']or declared[row['archive_path']]['sha256']!=row['sha256']:raise ValueError('archive/original binding differs')
records=[json.loads((OUT/(name+'.process.json')).read_text())for name in ['create','independent-verify']]
if any(row['exit_code']!=0 for row in records):raise ValueError('archive tool process failed')
review=dict(schema=1,scope='Independent archive inventory and complete original/staged/archived raw-byte equality; candidate comparisons are preserved historical scoped verdicts, not newly executed or strict language/API compatibility.',platform=platform.platform(),python=dict(executable=sys.executable,version=sys.version,sha256=sha(Path(sys.executable))),commands=records,archive_path=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,archive_payload_files=len(staged),original_regular_files=len(mapping['files']),excluded_files_within_selected_directories=0,archive_inventory_sha256=hashlib.sha256(inventory_bytes).hexdigest(),source_mapping_sha256=sha(payload/'source-to-archive.json'),assembly_review_sha256=sha(OUT/'assembly-review.json'),authority_manifest_sha256=sha(payload/'stage53-comparison-run-02/sources/tests/fixtures/m2-parameterized-object-bodies/manifest.json'),all_original_staged_archived_bytes_equal=True,symlinks_included=False,candidate_evaluation_payloads_included=True,mutable_original_native_binary_read=False,custom_audit_restart=dict(record='readback-restart.json',archive_unchanged=sha(archive)==restart['archive_sha256_before'],reason=restart['reason']))
put(OUT/'archive-review.json',review)
put(OUT/'archive-files.json',dict(schema=1,files={p.relative_to(OUT).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(OUT.rglob('*'))if p.is_file()and not p.is_relative_to(payload)and p.name!='archive-files.json'}))
print(json.dumps(dict(archive=str(archive),sha256=review['archive_sha256'],bytes=review['archive_bytes'],files=review['archive_payload_files'],original_files=review['original_regular_files'],independent_evidence_verify_exit=records[1]['exit_code'],full_raw_readback_passed=True),indent=2))
