"""Preserve only five closed candidate evidence directories, with exact copy bindings."""
from pathlib import Path
import hashlib,json,os,platform,shutil,stat,sys
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;STAGE=OUT/'payload';STAGE.mkdir()
NAMES=['stage53-platform-run-01','stage53-platforms-01','stage53-parameterized-final-01','stage53-comparison-run-02','stage53-parameterized-final-02']

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def put(path,value):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')
def read(path):return json.loads(path.read_bytes())
def files(directory):
 pending=[directory]
 while pending:
  parent=pending.pop()
  with os.scandir(parent)as entries:
   for entry in sorted(entries,key=lambda e:e.name,reverse=True):
    path=Path(entry.path)
    if entry.is_symlink():raise ValueError('evidence symlink refused: '+str(path))
    if entry.is_dir(follow_symlinks=False):pending.append(path)
    elif entry.is_file(follow_symlinks=False):yield path
    else:raise ValueError('nonregular evidence refused: '+str(path))

rows=[];groups={}
for name in NAMES:
 source=ROOT/'target/m2'/name
 if not source.is_dir()or source.is_symlink():raise ValueError('closed evidence root unavailable: '+name)
 before=len(rows)
 for path in sorted(files(source)):
  info=path.stat(follow_symlinks=False);digest=sha(path);relative=path.relative_to(source).as_posix();archive_name=name+'/'+relative;destination=STAGE/archive_name
  destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,destination)
  if sha(destination)!=digest or sha(path)!=digest:raise ValueError('original/copy hash mismatch: '+str(path))
  rows.append(dict(original_path=str(path),archive_path=archive_name,bytes=info.st_size,sha256=digest,source_mode=stat.S_IMODE(info.st_mode),source_mtime_ns=info.st_mtime_ns))
 groups[name]=dict(original_root=str(source),copied_regular_files=len(rows)-before,copied_bytes=sum(row['bytes']for row in rows[before:]))

# Validate source snapshots against their own closed catalogs, never later live source files.
snapshots={}
for name in ['stage53-platform-run-01','stage53-comparison-run-02','stage53-platforms-01']:
 source=STAGE/name;catalog=read(source/'sources.json')
 for relative,digest in catalog.items():
  path=source/'sources'/relative
  if not path.is_file()or sha(path)!=digest:raise ValueError('source snapshot binding differs: '+name+'/'+relative)
 snapshots[name]=dict(files=len(catalog),catalog_sha256=sha(source/'sources.json'),copied_source_bytes_match=True)

first=read(STAGE/'stage53-parameterized-final-01/report.json');second=read(STAGE/'stage53-parameterized-final-02/report.json')
wrapper1=read(STAGE/'stage53-platform-run-01/report.json');wrapper2=read(STAGE/'stage53-comparison-run-02/report.json')
if not wrapper1['complete']or not wrapper2['complete']or not wrapper1['sourceStable']or not wrapper2['sourceStable']:raise ValueError('wrapper is not closed/stable')
if first['case_ids']!=second['case_ids']or len(second['case_ids'])!=85 or len(first['oracle_boundaries'])!=7 or len(second['oracle_boundaries'])!=7:raise ValueError('selected ordinary/oracle boundary identity differs')
if first['status']!='failed'or second['status']!='passed':raise ValueError('historical comparison verdicts differ')
native=[]
for name,report,wrapper in [('stage53-parameterized-final-01',first,wrapper1),('stage53-parameterized-final-02',second,wrapper2)]:
 path=STAGE/name/'artifacts/expression_fixture_probe';digest=sha(path)
 if digest!=report['native_artifact']['sha256']or digest!=wrapper['nativeBuildArtifact']['sha256']:raise ValueError('actual frozen native binary differs: '+name)
 native.append(dict(run=name,archive_path=name+'/artifacts/expression_fixture_probe',sha256=digest,bytes=path.stat().st_size,recorded_mutable_original_path=report['native_artifact']['original_path'],mutable_original_path_read=False))

m1root=STAGE/'stage53-platforms-01';m1=read(m1root/'report.json');reused=wrapper2['platformEvidenceReuse']
if sha(m1root/'report.json')!=reused['sha256']:raise ValueError('reused M1 report binding differs')
artifact_bindings=[]
for relative,digest in reused['artifacts'].items():
 path=m1root/relative
 if sha(path)!=digest or m1['artifacts'][relative]!=digest:raise ValueError('reused artifact bytes differ')
 absolute=str(ROOT/'target/m2/stage53-platforms-01'/relative)
 if relative=='pkl_napi.node'or relative.startswith('wasm/'):
  for candidate in ['stage53-parameterized-final-01','stage53-parameterized-final-02']:
   portable=read(STAGE/candidate/'portable/report.json')
   if portable['inputHashes'].get(absolute)!=digest:raise ValueError('portable run reused different binding artifact: '+relative)
 artifact_bindings.append(dict(archive_path='stage53-platforms-01/'+relative,sha256=digest,bytes=path.stat().st_size))
source1=read(STAGE/'stage53-platform-run-01/sources.json');source2=read(STAGE/'stage53-comparison-run-02/sources.json')
for path in reused['unchangedEngineInputs']:
 if source1.get(path)!=source2.get(path):raise ValueError('claimed unchanged engine source differs: '+path)
source_delta=dict(added=sorted(source2.keys()-source1.keys()),removed=sorted(source1.keys()-source2.keys()),changed=sorted(path for path in source1.keys()&source2.keys()if source1[path]!=source2[path]))
verdicts=[]
for name,report in [('stage53-parameterized-final-01',first),('stage53-parameterized-final-02',second)]:
 targets={}
 for target,data in report['targets'].items():
  if data['executions']!=170 or not data['complete']:raise ValueError('missing requested comparison execution')
  passing=data['statuses'].get('pass',0)if target=='native'else data['passingExecutions']
  targets[target]=dict(executions=data['executions'],passing_executions=passing,nonpassing_executions=data['executions']-passing)
 verdicts.append(dict(run=name,recorded_status=report['status'],distinct_ordinary_cases=85,repetitions=2,oracle_error_boundaries=7,targets=targets))
if any(row['passing_executions']!=170 for row in verdicts[1]['targets'].values()):raise ValueError('second selected comparison result differs')
if m1['compatibility_status']!='fail'or m1['experiment_contract_status']!='pass'or len(m1['known_gaps'])!=2:raise ValueError('known M1 strict failures were altered')

summary=dict(schema=1,scope='Closed candidate source/build/platform evidence and two selected85-case comparisons; preserves first failed acquisition and second successful scoped rerun. Not strict full-language/API/platform/performance compatibility.',
 included_closed_directories=NAMES,excluded_live_or_unrequested_evidence='Every directory outside this exact allowlist, including still-live required-validation and original-three runs, is excluded.',
 copied_regular_files=len(rows),copied_regular_file_bytes=sum(row['bytes']for row in rows),exclusions_within_selected_directories=[],source_snapshots=snapshots,
 comparisons=verdicts,frozen_native_artifacts=native,reused_m1_artifacts=artifact_bindings,engine_source_hashes_equal_for_reused_inputs=len(reused['unchangedEngineInputs']),source_catalog_delta=source_delta,
 m1_recorded_contract=dict(total=m1['total'],oracle_passed=m1['oracle_passed'],shared_engine_passed=m1['shared_engine_passed'],compatibility_status=m1['compatibility_status'],experiment_contract_status=m1['experiment_contract_status'],known_gaps=m1['known_gaps']),
 final_fixture_authority_manifest_sha256=second['fixture_manifest_sha256'],mutable_original_native_binary_read=False)
put(STAGE/'source-to-archive.json',dict(schema=1,files=rows,excluded_patterns=[]))
put(STAGE/'candidate-publication-summary.json',summary)
(STAGE/'README.md').write_text('''# Stage53 closed candidate evidence\n\nThis archive contains exactly the five closed directories listed in `candidate-publication-summary.json`: the first platform/build wrapper and M1 platform evidence, the failed first selected expression comparison, the second build/comparison wrapper and the successful second selected expression comparison. Other runs, including required-validation and original-three evidence that was still live at archive assembly, are excluded. No file within an included directory is excluded.\n\nEvery regular file was copied and read back against its original SHA-256. `source-to-archive.json` preserves exact original paths, archived paths, sizes, hashes, modes and modification timestamps. Source snapshots are checked against their own closed catalogs, rather than current workspace files. The archive includes full captured source files, frozen binaries, candidate channels, Host request traces, logs, reports and original inventories. Original payloads and historical verdicts remain unchanged.\n\nThe native artifact from each comparison is its actual frozen `artifacts/expression_fixture_probe` copy. The mutable original build output recorded in the reports was legitimately rebuilt; it was not read or substituted as the earlier identity. Both portable comparisons reuse the exact NAPI/Wasm artifacts retained in `stage53-platforms-01`, with byte hashes cross-checked against both captured portable reports.\n\nThe first selected comparison retains 164 of 170 matching executions on each target and its six acquisition failures per target. The second retains 170 matching executions per target for the same 85 ordinary cases, two fresh executions each on native, NAPI and actual Chromium. Seven Java oracle-error boundaries remain explicitly separate nonpasses. These bounded scalar-expression results establish neither strict full-language/API compatibility nor performance completion. The M1 strict comparison remains failed for its two recorded regex gaps even though its separate architecture contract passes.\n\nArchive creation tools and review logs remain outside the archive. Deterministic archive headers do not replace the source file metadata retained in the mapping.\n''')
put(STAGE/'assembly-inventory.json',dict(schema=1,files={path.relative_to(STAGE).as_posix():dict(sha256=sha(path),bytes=path.stat().st_size)for path in sorted(files(STAGE))}))
for row in rows:
 if sha(Path(row['original_path']))!=row['sha256']or sha(STAGE/row['archive_path'])!=row['sha256']:raise ValueError('original/copy final read-back changed')
put(OUT/'assembly-review.json',dict(schema=1,platform=platform.platform(),python=dict(executable=sys.executable,version=sys.version),copied_regular_files=len(rows),copied_regular_file_bytes=sum(row['bytes']for row in rows),all_original_and_copied_hashes_equal=True,symlinks_included=False,mutable_original_native_binary_read=False,selected_directories=NAMES,source_snapshots=snapshots))
print(json.dumps(dict(copied_files=len(rows),bytes=sum(row['bytes']for row in rows),source_catalog_delta=source_delta,native_frozen=native),indent=2))
