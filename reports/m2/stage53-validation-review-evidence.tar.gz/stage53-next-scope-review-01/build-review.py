from pathlib import Path
import json,hashlib,collections,difflib
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage53')
OUT=ROOT/'target/m2/stage53-next-scope-review-01'
m=json.loads((OUT/'snapshot.json').read_text())
class Group:
    def __init__(self,category,reason): self.category,self.reason=category,reason

def classify(c,stderr):
    n=c['case_id'].split('/input/')[-1]
    if c['status']=='pass': return Group('observed-pass','Only this original raw case under the captured Stage52 profile passed.')
    if c['status']=='oracle-error': return Group('oracle-boundary','Java OutOfMemoryError at VmList.repeat under recorded -Xmx512m; not an ordinary compatibility result.')
    if n.startswith('annotation/deprecat'): return Group('method-deprecation','Value output matches; all Java warning bytes are absent from Rust stderr.')
    if n in ['api/module.pkl','api/dir1/dir2/relativePathTo.pkl']: return Group('module-relative-path','Missing Module.relativePathTo; one original catches the missing-method error instead of the Java URI relation error.')
    if n in ['api/any.pkl','api/anyConverter.pkl']: return Group('class-value-and-ancestry','Class.simpleName dispatch is absent (any), or Any converter fails to follow implicit Typed/Any ancestry (anyConverter).')
    if n in ['api/dynamic.pkl','api/typed.pkl']: return Group('object-introspection-and-projection','Missing Dynamic.length() / Typed.getProperty; original continues into hasProperty/getPropertyOrNull and conversions.')
    if n in ['annotation/annotation7.pkl','api/reflect1.pkl','api/reflect2.pkl','api/reflect3.pkl','api/reflect4.pkl','api/reflect5.pkl','api/reflectedDeclaration.pkl']: return Group('reflection-metadata','pkl:reflect is not executable; reflect1 first stops at unsupported base Typed class value. Full mirrors also need preserved declaration metadata.')
    if n in ['api/dataSize.pkl','api/duration.pkl','api/float.pkl','api/int.pkl','api/protobuf.pkl']: return Group('quantity-values-and-operations','First failure is DataSize unit construction, Duration.isBetween/toDuration, or Duration arithmetic, before renderer behavior.')
    if n in ['api/baseModule.pkl','api/pair.pkl','api/regex.pkl']: return Group('regex-constructor','Original first stops at missing base Regex constructor.')
    if n=='api/intseq.pkl': return Group('intseq-constructor','Original first stops at missing base IntSeq constructor.')
    if n in ['api/bytes.pkl','api/Resource.pkl']: return Group('bytes-and-resource-primitives','Missing Bytes constructor or explicitly unsupported Resource.md5 default binding.')
    if n in ['api/annotationConverters.pkl','api/string.pkl','api/stringUnicode.pkl','api/jsonRenderer6.json.pkl']: return Group('string-and-regex-operations','First failure is replaceAllMapped, String.isNotEmpty/isBlank, or String.reverse inside converter; does not prove renderer failure.')
    if n in ['api/jsonRenderer4.pkl','api/jsonRenderer5.pkl','api/pcfRenderer4.pkl','api/pcfRenderer5.pkl']: return Group('renderer-input-value-dependencies','Complete stdout diff shows DataSize/IntSeq constructor failures; pcfRenderer4 aborts at DataSize before rendering.')
    if n in ['api/listNullable.pkl','api/listing.pkl','api/map.pkl','api/set.pkl','api/setNullable.pkl']: return Group('collection-members','First failure is getOrNull, isNotEmpty or firstOrNull; these are base external members.')
    if n=='api/mapping.pkl': return Group('collection-custom-default','Explicit unsupported custom collection default functions at amended mapping entry.')
    if n=='api/typeAliases.pkl': return Group('base-alias-bindings','First unsupported type is Uri.')
    if 'M1 base-module name resolution' in stderr: return Group('builtin-class-value-bindings','First unresolved class value is DataSize (or IntSeq in propertiesRenderer2), before renderer initialization.')
    if 'Standard-library module `' in stderr: return Group('bundled-module-bindings','The named bundled pkl: module is explicitly unsupported; no claim about later language or renderer behavior.')
    if 'pkl:json#Parser' in stderr: return Group('json-parser-binding','pkl:json source loads, but external Parser declaration is unsupported.')
    if any('type '+s+' are not implemented' in stderr for s in ['PListRenderer','PropertiesRenderer','YamlRenderer']): return Group('renderer-class-bindings','Named renderer class/type is explicitly unsupported.')
    raise AssertionError(n+' '+stderr)
rows=[]; groups=collections.defaultdict(list)
for c in m['cases']:
    d=OUT/'captures/cases'/c['case_directory'];stderr=(d/'rust/stderr.bin').read_text();g=classify(c,stderr)
    row={k:c[k] for k in ['case_id','case_directory','status','input_sha256']};row.update(group=g.category,reason=g.reason,source_link=c['original_source'],java_stderr=str(d/'java/stderr.bin'),rust_stderr=str(d/'rust/stderr.bin'))
    row['raw_channels_equal']={channel:(d/'java'/(channel+'.bin')).read_bytes()==(d/'rust'/(channel+'.bin')).read_bytes() for channel in ['stdout','stderr']}
    if c['status']=='mismatch':
        diff=''.join(''.join(difflib.unified_diff((d/'java'/(ch+'.bin')).read_text().splitlines(True),(d/'rust'/(ch+'.bin')).read_text().splitlines(True),fromfile='java/'+ch,tofile='rust/'+ch)) for ch in ['stdout','stderr'])
        dest=OUT/'inspection-diffs'/(c['case_directory']+'.diff');dest.parent.mkdir(exist_ok=True);dest.write_text(diff);row['inspection_diff']=str(dest)
    rows.append(row);groups[g.category].append(c['case_id'])
(OUT/'root-groups.json').write_text(json.dumps({'scope':'All fixed 169 CLOSED prefix rows; categories describe observed first blockers, not predicted passes or feature completion. Raw captures remain authority; text diffs are inspection aids only.','snapshot_sha256':hashlib.sha256((OUT/'snapshot.json').read_bytes()).hexdigest(),'groups':groups,'cases':rows},indent=2)+'\n')
paths=['references.lock','rust-toolchain.toml','AGENTS.md','INTENT.md','PLAN.md','TESTING.md','docs/architecture.md','tools/m2_module_eval.py','crates/pkl-runtime/src/vm.rs','crates/pkl-runtime/src/vm/annotations.rs','crates/pkl-runtime/src/vm/tracing.rs','crates/pkl-runtime/src/logging.rs','crates/pkl-runtime/src/heap.rs','crates/pkl-runtime/src/modules.rs','crates/pkl-runtime/src/value.rs','crates/pkl-runtime/src/parser.rs','crates/pkl-runtime/src/syntax.rs','crates/pkl-runtime/src/vm/primitives.rs','crates/pkl-runtime/src/vm/reference.rs','crates/pkl-runtime/src/vm/builtins.rs','crates/pkl-runtime/src/vm/converters.rs','crates/pkl-runtime/src/vm/stdlib_modules.rs','external/pkl/stdlib/base.pkl','external/pkl/stdlib/reflect.pkl']
paths+=['external/pkl/pkl-core/src/main/java/org/pkl/core/'+p for p in ['ast/member/ClassMethod.java','ast/member/UnresolvedMethodNode.java','ast/expression/member/InvokeMethodDirectNode.java','ast/expression/member/InvokeClassMethodNode.java','ast/expression/member/InvokeSuperMethodNode.java','ast/expression/member/InvokeMethodVirtualNode.java','stdlib/base/ModuleClassNodes.java','stdlib/base/ClassNodes.java','stdlib/base/DynamicNodes.java','stdlib/base/TypedNodes.java','stdlib/base/DurationNodes.java','stdlib/base/IntNodes.java','stdlib/base/FloatNodes.java','stdlib/base/StringNodes.java','stdlib/PklConverter.java','stdlib/reflect/ReflectNodes.java','runtime/MirrorFactories.java','runtime/VmClass.java']]
(OUT/'reviewed-source-identities.json').write_text(json.dumps({'scope':'Sources read for causal triage; Stage53 files were inspected, not executed for this report.','files':[{'path':str(ROOT/p),'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest(),'bytes':(ROOT/p).stat().st_size} for p in paths]},indent=2)+'\n')
print('rows',len(rows),'groups',len(groups),'unassigned',sum(not r['group'] for r in rows))
