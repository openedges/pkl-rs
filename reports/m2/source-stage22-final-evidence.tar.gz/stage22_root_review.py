"""Record root source review of the frozen Stage22 implementation."""
from pathlib import Path
import hashlib,json
root=Path.cwd()
paths=['crates/pkl-runtime/src/'+name for name in ['diagnostic_values.rs','evaluation.rs','heap.rs','lib.rs','resolver.rs','strict_map.rs','vm.rs','vm/collections.rs','vm/equality.rs','vm/generics.rs','vm/reference.rs','vm/typecheck.rs']]
paths+=['crates/pkl-runtime/tests/m2_strict_map_lifecycle.rs']
record=dict(status='pass',scope='Root independent review of strict Map runtime, trie routing, lifecycle assertions and shared boundary integration. Root authored diagnostic_values.rs/evaluation.rs changes, so review of those two files is self-review; the lifecycle reviewer independently reviewed them. Root also authored documentation and final verification orchestration.',source_sha256={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},self_reviewed_sources=paths[:2],independently_reviewed_sources=paths[2:],findings=[
 'Strict Map is a separate collection kind with traced evaluated keys/values and an optional boxed slot-only trie. It does not reuse EconomicMap declaration or cache lookup rules.',
 'Construction evaluates each key/value before immediate resumable preparation and insertion. Original insertion slots survive duplicate replacement; published cache values and builder roots remain live across Host suspension and GC.',
 'Trie lookup models consumed-prefix leaves, insertion-ordered hash collisions and the seventeenth occupied bitmap slot transition. Rehashing stored leaves occurs through the VM before trie mutation; index recursion is bounded by 32-bit hash chunks.',
 'Collision lookup and insertion retain distinct hash guards. Internal table slots can outnumber insertion-order keys; public length, iteration, type checks, equality and hashing use their respective upstream views. All table entries remain GC roots through the owning Map.',
 'Map equality schedules each lookup key preparation and boxed value comparison before the next entry. Strict Map/List hash preparation recomputes hashes; hash entries follow trie order without an initial full Map deep-force pass.',
 'Parameterized Map checks preserve nested lazy value wrappers and clear structural/hash metadata on replacement. Empty defaults avoid constructing a value default; explicit amendments retain external-class errors.',
 'Map stringification shares non-forcing diagnostic rendering. REPL errors retain the complete authored path while highlighting the actually evaluated prefix; persistent raw witnesses exercise failed receivers.',
 'The first full frozen acquisition exposed an unchanged generic-metadata small-stack abort and existing Node List-key Mapping instruction-budget regression. The scheduler now enters collection/continuation work outside the large general dispatch frame; completed key preparations accumulate only through retries of one instruction and are cleared at its completion. Failed first acquisitions and their incomplete interruption metadata are preserved separately.',
 'Native assertions retain original small-stack/depth/time conditions. The intermediate stack overflow is preserved; boxed optional index storage and extracted dispatch helpers correct the added debug-frame cost. Nine tests separately cover constructor order, lookup/comparison, retries, 24 cancellations, evaluator-local handles, invisible table-entry retention and terminal release.'
],limits=[
 'Review covers bounded implementation and requires separate raw Java comparisons and recorded test execution for semantic evidence.',
 'JVM identity-dependent key hashing uses a documented fallback; its traversal/equality order is not established as portable Java compatibility.',
 'General compound output, Set, full Map APIs and remaining missing-method/arity/reference diagnostics are outside the selected contract.',
 'Synchronous recursive snapshot rendering, parser/compiler depth, latency/resource bounds, full language/API/platform coverage and execution-time/peak-RSS parity remain open.'
])
out=root/'target/m2/stage22-root-review-final-02.json'
with out.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('Reviewed source files:',len(paths))
