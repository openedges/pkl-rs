"""Independently inspect sealed exploration bytes; never execute retained artifacts."""
from pathlib import Path
import datetime,fnmatch,hashlib,json,platform,sys,tarfile
ROOT=Path.cwd()
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for data in iter(lambda:stream.read(1024*1024),b''):h.update(data)
 return h.hexdigest()
def ident(path):return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest(path)}
def require(condition,description):
 if not condition:raise AssertionError(description)
index_path=ROOT/'target/m2/stage22-exploration-index.json';config_path=ROOT/'target/m2/stage22-exploration-configuration.json'
index=json.loads(index_path.read_bytes());config=json.loads(config_path.read_bytes())
require(index['scope']==config['scope'] and index['counts']==config['counts'],'index/config scope/count disagreement')
require(index['history_dependencies']==config['history_dependencies'],'history configuration disagreement')
require(index['captured_artifacts_executed'] is False,'index artifact execution claim')
archives=[index['main'],*index['additional_archives']];require(len(archives)==len(config['groups']) and archives,'exploration archive/configuration closure')
results=[];all_originals=set()
for expected,group in zip(archives,config['groups']):
 path=ROOT/expected['path'];require(ident(path)=={k:expected[k] for k in ['path','bytes','sha256']},'archive identity mismatch '+str(path))
 require(group['archive']==expected['path'],'archive group mismatch')
 with tarfile.open(path,'r:gz') as archive:
  members=archive.getmembers();names=[x.name for x in members]
  require(len(names)==len(set(names)) and 'EVIDENCE.json' in names,'duplicate/missing archive inventory')
  require(all(x.isfile() and not Path(x.name).is_absolute() and '..' not in Path(x.name).parts for x in members),'unsafe archive path/type')
  require(all(x.mode==0o644 and x.mtime==0 for x in members),'unexpected deterministic header')
  inventory=json.load(archive.extractfile('EVIDENCE.json'));rows=inventory['files'];mapping={x['path']:x for x in rows}
  require(len(mapping)==len(rows) and set(mapping)==set(names)-{'EVIDENCE.json'},'incomplete evidence inventory')
  require(inventory['schema_version']==1 and inventory['excluded_patterns']==group['excludes'],'inventory exclusion configuration')
  payload_bytes=0
  for row in rows:
   data=archive.extractfile(row['path']).read();payload_bytes+=len(data)
   require(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],'evidence payload mismatch '+row['path'])
  original=json.load(archive.extractfile('ORIGINAL_PATHS.json'));original_rows=original['files'];original_mapping={x['path']:x for x in original_rows}
  require(original['schema']==1 and len(original_mapping)==len(original_rows),'original mapping schema/duplicates')
  require(set(mapping)==set(original_mapping)|{'ORIGINAL_PATHS.json','PACKAGE.json','configuration.json','sealer.py'},'unmapped payload files')
  require(len(original_rows)==expected['original_files'],'index original count')
  for name,row in original_mapping.items():
   require(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe original path')
   require(row==mapping[name],'original and archive inventory disagree '+name)
   require(ident(ROOT/name)==row,'original filesystem bytes changed '+name)
   require(name not in all_originals,'duplicate path across archives '+name);all_originals.add(name)
  captured_config=json.load(archive.extractfile('configuration.json'));require(captured_config==config,'captured configuration mismatch')
  require(archive.extractfile('sealer.py').read()==(ROOT/'target/m2/stage22_seal_exploration.py').read_bytes(),'captured sealer mismatch')
  package=json.load(archive.extractfile('PACKAGE.json'))
  require(package['original_paths_preserved'] is True and package['captured_artifacts_executed'] is False,'package provenance flags')
  require(package['history_dependencies']==index['history_dependencies'] and package['counts']==index['counts'],'package history/count mismatch')
  require(package['excluded_patterns']==group['excludes'] and package['scope']==expected['scope'],'package scope/exclusions mismatch')
  candidates=set()
  for name in group['paths']:
   source=ROOT/name;require(source.exists() and not source.is_symlink(),'missing/linked configured source '+name)
   candidates.update([source] if source.is_file() else [p for p in source.rglob('*') if p.is_file()])
  candidate_paths={p.relative_to(ROOT).as_posix() for p in candidates}
  require(all(not p.is_symlink() and p.resolve().is_relative_to(ROOT) for p in candidates),'linked/outside configured child')
  excluded={name for name in candidate_paths if any(fnmatch.fnmatchcase(name,pattern) for pattern in group['excludes'])}
  excluded_rows=original['excluded_cache_files'];excluded_mapping={x['path']:x for x in excluded_rows}
  require(set(excluded_mapping)==excluded and len(excluded_mapping)==len(excluded_rows)==expected['excluded_cache_files'],'explicit excluded cache inventory mismatch')
  require(set(original_mapping)==candidate_paths-excluded,'retained configured path inventory mismatch')
  for name,row in excluded_mapping.items():require((ROOT/name).stat().st_size==row['bytes'],'excluded cache size changed '+name)
  results.append(dict(**ident(path),inventory_files=len(rows),inventory_payload_bytes=payload_bytes,original_paths=len(original_rows),original_bytes=sum(x['bytes'] for x in original_rows),excluded_cache_files=len(excluded_rows),excluded_cache_bytes=sum(x['bytes'] for x in excluded_rows),excluded_patterns=group['excludes'],original_mapping='ORIGINAL_PATHS.json',deterministic_headers_verified=True,status='pass'))
history=[]
for expected in index['history_dependencies']:
 actual=ident(ROOT/expected['path']);require(actual==expected,'history dependency mismatch '+expected['path']);history.append(actual)
helper=Path(__file__).resolve()
report=dict(status='pass',scope='Root independent read-only audit of sealed Stage22 exploration archives, full evidence/original inventories, explicit cache exclusions, helper/config provenance and historical dependency identities. Root authored Map diagnostic rendering, expression-string adapter integration, documentation and final verification orchestration, but did not author the exploration sealer, native tests, platform scenarios or selected Java captures.',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host=platform.platform(),python=sys.version,captured_artifacts_executed=False,retained_helpers_executed=False,archive_count=len(results),inventory_files=sum(x['inventory_files'] for x in results),original_paths=len(all_originals),excluded_cache_files=sum(x['excluded_cache_files'] for x in results),archives=results,history_dependencies=history,helper_provenance=dict(audit_helper=ident(helper),reviewed_sealer=ident(ROOT/'target/m2/stage22_seal_exploration.py'),reviewed_inventory_implementation=ident(ROOT/'tools/evidence.py'),index=ident(index_path),configuration=ident(config_path)),limitations=['This validates archive bytes and provenance; it does not execute retained binaries or independently establish the semantic correctness of captured Java/Rust outcomes.','Historical dependencies were checked by exact archive/summary hashes and sizes; their internal inventories were not recursively re-audited in this check.','Tar headers use normalized0644 modes; ORIGINAL_PATHS maps bytes, size, and paths and does not claim restoration of original executable modes.'])
output=ROOT/'target/m2/stage22-exploration-independent-audit.json';require(not output.exists(),'audit output already exists');output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','archive_count','inventory_files','original_paths','excluded_cache_files','captured_artifacts_executed']},indent=2))
