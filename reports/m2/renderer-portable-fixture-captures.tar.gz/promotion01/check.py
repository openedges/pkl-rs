from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SOURCES = [
    'tools/renderer_fixtures.py',
    'tools/tests/test_renderer_fixtures.py',
    'tools/platform/compare-renderer.mjs',
    'tools/platform/resource-session.mjs',
    'tools/platform/resource-session.test.mjs',
    'tests/fixtures/m2-renderer-portable/manifest.json',
    'references.lock',
    'rust-toolchain.toml',
]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

before = {name: sha(ROOT / name) for name in SOURCES}
save('installed-inputs-before.json', before)
snapshot = OUT / 'installed-sources'
snapshot.mkdir()
for name in SOURCES:
    target = snapshot / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, target)
node = Path(shutil.which('node')).resolve()
report = {
    'schema': 1,
    'scope': 'Installed Java renderer reference fixture and verification tooling; no Rust evaluator, Node binding or browser acquisition.',
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'host': platform.platform(),
    'python': sys.version,
    'pythonExecutable': sys.executable,
    'pythonExecutableSha256': sha(sys.executable),
    'nodeExecutable': str(node),
    'nodeExecutableSha256': sha(node),
    'environment': {key: os.environ.get(key) for key in ['RENDERER_PORTABLE_GOLDEN', 'PYTHONPATH', 'RUSTUP_TOOLCHAIN']},
    'commands': [],
}
commands = [
    ('tests', [sys.executable, '-W', 'error::ResourceWarning', '-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_renderer_fixtures.py', '-v']),
    ('fixture', [sys.executable, 'tools/renderer_fixtures.py', '--fixtures', 'tests/fixtures/m2-renderer-portable']),
    ('driver-syntax', [str(node), '--check', 'tools/platform/compare-renderer.mjs']),
    ('session-helper', [str(node), '--test', 'tools/platform/resource-session.test.mjs']),
    ('inventory', [sys.executable, 'tools/m2_manifest.py', '--check']),
    ('repository', ['cargo', 'xtask', 'verify']),
]
for name, argv in commands:
    with (OUT / f'{name}.stdout.bin').open('wb') as stdout, (OUT / f'{name}.stderr.bin').open('wb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
        save('active.json', {'name': name, 'pid': process.pid, 'argv': argv})
        code = process.wait()
    row = {'name': name, 'argv': argv, 'cwd': str(ROOT), 'pid': process.pid, 'exitCode': code,
           'stdoutSha256': sha(OUT / f'{name}.stdout.bin'), 'stderrSha256': sha(OUT / f'{name}.stderr.bin')}
    report['commands'].append(row)
    save('process-report.json', report)
    print(f'{name}: exit {code}', flush=True)
    if code:
        sys.exit(code)
after = {name: sha(ROOT / name) for name in SOURCES}
save('installed-inputs-after.json', after)
report['sourceChanges'] = [name for name in before if before[name] != after[name]]
report['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report['allChecksPassed'] = not report['sourceChanges']
save('report.json', report)
save('active.json', {'terminal': True, 'exitCode': 0 if report['allChecksPassed'] else 1})
sys.exit(0 if report['allChecksPassed'] else 1)
