from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
STAGING = OUT / 'clean-source'
STAGING.mkdir()
rows = []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy(source, relative):
    assert source.is_file() and not source.is_symlink(), source
    destination = STAGING / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    destination.write_bytes(data)
    rows.append({'source': str(source), 'archivePath': relative, 'bytes': len(data),
                 'sha256': sha(source), 'mode': stat.S_IMODE(source.stat().st_mode)})

roots = {
    'promotion01': ROOT / 'target/m2/stage47-renderer-fixture-promotion-01',
    'promotion02': ROOT / 'target/m2/stage47-renderer-fixture-promotion-02',
    'independent-review': ROOT / 'target/m2/stage47-renderer-portable-review-01',
}
excluded = [path / '__pycache__' for path in roots.values()]
for prefix, source in roots.items():
    for current, directories, files in os.walk(source, topdown=True, followlinks=False):
        directories[:] = sorted(name for name in directories if Path(current) / name not in excluded)
        for name in directories:
            assert not (Path(current) / name).is_symlink()
        for name in sorted(files):
            path = Path(current) / name
            copy(path, f'{prefix}/{path.relative_to(source)}')

original = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2/stage47-renderer-tool-evidence-publication-01')
for source in sorted(original.iterdir()):
    if source.is_file() and source.name != 'renderer-tooling-originals.tar.gz':
        copy(source, f'original-publication/{source.name}')
for name in ['package.py', 'staged-source-binding.json', 'original-archive-copy.json']:
    copy(OUT / name, f'publication/{name}')
copy(ROOT / 'tools/evidence.py', 'publication/evidence.py')
(STAGING / 'publication/selection.json').write_text(json.dumps({
    'schema': 1, 'files': rows,
    'excludedBeforeTraversal': [str(path) for path in excluded],
    'fixturePayloads': 'Published directly in Git; source mapping verifies every staged blob.',
    'nativeAndActualPlatformAcquisitionsIncluded': False,
}, indent=2) + '\n')

commands = [
    ('original-archive-verify', [sys.executable, 'tools/evidence.py', 'verify', 'reports/m2/renderer-tooling-originals.tar.gz']),
    ('create', [sys.executable, 'tools/evidence.py', 'create', str(STAGING), 'reports/m2/renderer-portable-fixture-captures.tar.gz']),
    ('verify', [sys.executable, 'tools/evidence.py', 'verify', 'reports/m2/renderer-portable-fixture-captures.tar.gz']),
]
results = []
for name, argv in commands:
    result = subprocess.run(argv, cwd=ROOT, capture_output=True)
    (OUT / f'{name}.stdout.bin').write_bytes(result.stdout)
    (OUT / f'{name}.stderr.bin').write_bytes(result.stderr)
    results.append({'name': name, 'argv': argv, 'exitCode': result.returncode,
                    'stdoutSha256': hashlib.sha256(result.stdout).hexdigest(),
                    'stderrSha256': hashlib.sha256(result.stderr).hexdigest()})
    print(f'{name}: exit {result.returncode}', flush=True)
    assert result.returncode == 0
assert all(sha(Path(row['source'])) == row['sha256'] for row in rows)
archive = ROOT / 'reports/m2/renderer-portable-fixture-captures.tar.gz'
report = {'schema': 1, 'commands': results, 'sourceChanges': [], 'copiedOriginalFiles': len(rows),
          'archive': str(archive.relative_to(ROOT)), 'archiveSha256': sha(archive),
          'archiveBytes': archive.stat().st_size, 'archivePayloadFiles': len(rows) + 1}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'commands'}, indent=2))
