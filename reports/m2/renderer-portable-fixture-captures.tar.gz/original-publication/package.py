from pathlib import Path
import argparse, datetime, hashlib, json, os, shutil, stat, subprocess, sys, tarfile, time
O = Path(__file__).parent
B = O.parent
R = Path('/Users/cody.ij.hwang/Projects/pkl-rs')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value):
 p.parent.mkdir(parents=True, exist_ok=True)
 p.write_text(json.dumps(value, indent=2) + '\n')

def identity(path):
 st = path.lstat()
 assert stat.S_ISREG(st.st_mode) and not path.is_symlink(), str(path)
 return {'kind': 'regular', 'bytes': st.st_size, 'mode': oct(stat.S_IMODE(st.st_mode)), 'sha256': sha(path)}

PRUNE = [str(B / f'stage47-renderer-portable-consumer-{n:02}' / '__pycache__') for n in [1, 2, 3]]

def select():
 assert not (O / 'selection.json').exists()
 write(O / 'prewalk-exclusions.json', {'declaredBeforeTraversal': True, 'exactExcludedDirectoryPaths': PRUNE, 'genericNameFilters': [], 'selectionMethod': 'Flat consumer/handoff root listings only; sealed initial compile failure read by pinned inventory exact paths. No directory is descended in original source enumeration. Negative test temporary clones are already removed, confirmed by flat listings, not assumed empty.', 'fixture02': {'path': str(B / 'stage47-renderer-portable-fixtures-02'), 'reason': 'Exact14996 files being published byte-identically by root; no archive payload duplication'}, 'futureRuntimeEvidenceExcluded': [str(B / 'stage47-renderer-api-oracle-07'), str(B / 'stage47-renderer-api-oracle-08'), str(B / 'stage47-renderer-native-c03-01')]})
 rows = []
 listings = {}
 def add(path, archive_path):
  assert str(path) not in PRUNE
  rows.append({'source': str(path), 'archivePath': archive_path, **identity(path)})
 for number in [1, 2, 3]:
  root = B / f'stage47-renderer-portable-consumer-{number:02}'
  listed = []
  for entry in sorted(os.scandir(root), key=lambda x: x.name):
   path = Path(entry.path)
   if str(path) in PRUNE:
    listed.append({'path': str(path), 'excludedBeforeDescent': True})
    continue
   assert entry.is_file(follow_symlinks=False) and not entry.is_symlink(), f'Unexpected non-file root entry, not descended: {path}'
   listed.append({'path': str(path), 'kind': 'regular'})
   add(path, f'originals/{root.name}/{path.name}')
  listings[str(root)] = listed
 root = B / 'stage47-renderer-handoff-01'
 for entry in sorted(os.scandir(root), key=lambda x: x.name):
  path = Path(entry.path)
  assert entry.is_file(follow_symlinks=False) and not entry.is_symlink()
  add(path, f'originals/{root.name}/{path.name}')
 initial = B / 'stage47-renderer-api-oracle-01'
 closure = json.loads((initial / 'closure.json').read_bytes())
 inventory = json.loads((initial / 'inventory.json').read_bytes())
 assert sha(initial / 'inventory.json') == closure['inventorySha256']
 assert sha(initial / 'report.json') == closure['reportSha256']
 assert closure['files'] == len(inventory['files']) == 88
 for row in inventory['files']:
  p = initial / row['path']
  assert identity(p)['sha256'] == row['sha256'] and p.stat().st_size == row['bytes']
  add(p, f'originals/{initial.name}/{row["path"]}')
 for name in ['inventory.json', 'closure.json']:
  add(initial / name, f'originals/{initial.name}/{name}')
 corrected = B / 'stage47-renderer-api-oracle-02'
 for name in ['RendererProbe.java', 'correction.json', 'helper-starting-point.json', 'javac.process.json', 'javac/stdout.bin', 'javac/stderr.bin', 'javac/result.json']:
  add(corrected / name, f'originals/{corrected.name}/{name}')
 draft = B / 'stage47-renderer-portable-fixtures-01'
 for name in ['manifest.json', 'fixtures.json']:
  add(draft / name, f'draft-export-metadata/{draft.name}/{name}')
 # Sealing producer source only; full later Java/native roots remain outside this archive.
 for name in ['PLAN.ko.md', 'seal.py']:
  add(B / 'stage47-renderer-sealing-01' / name, 'producer/sealing/' + name)
 add(R / 'tools/evidence.py', 'producer/tools/evidence.py')
 add(O / 'package.py', 'producer/package.py')
 assert len({r['source'] for r in rows}) == len(rows)
 assert len({r['archivePath'] for r in rows}) == len(rows)
 selection = {'schema': 1, 'scope': 'Original renderer fixture tooling and failures/corrections/checks only; not whole oracle, runtime implementation, native or portable compatibility evidence.', 'files': rows, 'fileCount': len(rows), 'rawBytes': sum(r['bytes'] for r in rows), 'flatRootListings': listings, 'exactPrewalkPrunes': PRUNE, 'sealedOriginalRoots': [str(initial), str(B/'stage47-renderer-portable-consumer-03'), str(root)], 'unsealedOriginalRoots': [str(B/'stage47-renderer-portable-consumer-01'), str(B/'stage47-renderer-portable-consumer-02')], 'missingHistoricalMetadata': {'consumer01': 'Only original exporter source exists. No on-disk export launch/terminal/test logs. Do not infer a JVM run or tests from the exported artifact.', 'draftFixture01': 'Only original manifest and fixtures metadata are archived here. Referenced draft raw payload remains at original source; intentionally not a complete draft fixture archive.'}, 'fixture02ExternalBinding': {'repositoryPath': 'tests/fixtures/m2-renderer-portable', 'originalPath': str(B/'stage47-renderer-portable-fixtures-02'), 'manifestSha256': '90f6694ff7637cfbe86e0a1a99f1a2351baba9537018022ffa8e3ff17c52cd77', 'regularFiles':14996,'gitCommit':None,'gitCommitBoundary':'Root owns subsequent Git checkpoint; no commit inferred by this archive.'}, 'knownToolLimits': ['Consumer01 lacks copied helper/profile provenance; source preserved as initial draft.', 'Consumer02 traverses before fixed provenance authentication.', 'Consumer03 authenticates fixed provenance before traversal, but still descends unknown dirs and accepts undeclared empty dirs.', 'Captured tests03 require explicit golden environment; root owns installed default-path and directory-gate correction with separate source hashes.'], 'initialJavaHelperFailure': 'Oracle01 javac failed because ResourceReader.isGlobbable was absent;648 planned APIs all unexecuted. Actual stderr/launcher/terminal/helper/input88payload preserved. Oracle02 helper correction and javac success captured separately.'}
 write(O / 'selection.json', selection)
 print(json.dumps({'phase':'selection','files':selection['fileCount'],'rawBytes':selection['rawBytes'],'selectionSha256':sha(O/'selection.json')}),flush=True)
 return selection

def run_phase(name, command):
 start=time.time_ns()
 with (O/(name+'.stdout.bin')).open('wb') as out, (O/(name+'.stderr.bin')).open('wb') as err:
  proc=subprocess.Popen(command,stdout=out,stderr=err)
  launch={'pid':proc.pid,'parentPid':os.getpid(),'command':command,'cwd':str(Path.cwd()),'startedUnixNs':start}
  write(O/(name+'.launch.json'),launch)
  code=proc.wait()
 row={**launch,'exitCode':code,'finishedUnixNs':time.time_ns(),'stdoutSha256':sha(O/(name+'.stdout.bin')),'stderrSha256':sha(O/(name+'.stderr.bin'))}
 write(O/(name+'.terminal.json'),row)
 assert code==0,row
 return row

def package(selection):
 gather=O/'clean-source';gather.mkdir()
 changes=[]
 for row in selection['files']:
  source=Path(row['source']);assert identity(source)=={key:row[key]for key in ['kind','bytes','mode','sha256']}
  target=gather/row['archivePath'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);assert sha(target)==row['sha256']
 write(gather/'CAPTURE_SELECTION.json',selection)
 shutil.copyfile(O/'prewalk-exclusions.json',gather/'PREWALK_EXCLUSIONS.json')
 archive=O/'renderer-tooling-originals.tar.gz'
 create=run_phase('archive-create',[sys.executable,str(R/'tools/evidence.py'),'create',str(gather),str(archive)])
 verify=run_phase('archive-verify',[sys.executable,str(R/'tools/evidence.py'),'verify',str(archive)])
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();indexed={m.name:m for m in members};evidence=json.load(tar.extractfile(indexed['EVIDENCE.json']))
  assert len(indexed)==len(members)==len(selection['files'])+3
  assert set(indexed)=={r['archivePath']for r in selection['files']}|{'CAPTURE_SELECTION.json','PREWALK_EXCLUSIONS.json','EVIDENCE.json'}
  assert len(evidence['files'])==len(selection['files'])+2
  for row in selection['files']:
   member=indexed[row['archivePath']];assert member.isfile()
   data=tar.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==row['sha256'] and len(data)==row['bytes']
 for row in selection['files']:
  if identity(Path(row['source']))!={key:row[key]for key in ['kind','bytes','mode','sha256']}:changes.append(row['source'])
 assert not changes
 index={'schema':1,'archives':[{'path':archive.name,'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'sourceFiles':len(selection['files']),'archivePayloadFiles':len(selection['files'])+2,'sourceRawBytes':selection['rawBytes']}],'selectionSha256':sha(O/'selection.json'),'fixture02ExternalBinding':selection['fixture02ExternalBinding']}
 write(O/'index.json',index)
 report={'schema':1,'selectionSha256':sha(O/'selection.json'),'indexSha256':sha(O/'index.json'),'exactSelectedOriginalFiles':len(selection['files']),'selectedRawBytes':selection['rawBytes'],'archives':index['archives'],'create':create,'verify':verify,'independentAllMemberReadback':True,'allSourceOriginalJoinsVerified':True,'selectedOriginalChanges':changes,'sourceArtifactPayloadExcluded':'Exact14996 fixture02 files external-published. Full07/08/nativeC03 roots excluded for later runtime publication. No Git/main writes.', 'knownToolLimits':selection['knownToolLimits'],'missingHistoricalMetadata':selection['missingHistoricalMetadata'],'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'liveHandles':[]}
 write(O/'report.json',report)
 print(json.dumps({'phase':'complete','archiveSha256':sha(archive),'compressedBytes':archive.stat().st_size,'reportSha256':sha(O/'report.json'),'originalChanges':len(changes)}),flush=True)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--selection-only',action='store_true');args=parser.parse_args()
 selected=json.loads((O/'selection.json').read_bytes()) if (O/'selection.json').exists() else select()
 if not args.selection_only:package(selected)
