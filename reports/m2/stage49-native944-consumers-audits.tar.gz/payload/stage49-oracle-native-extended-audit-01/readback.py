from pathlib import Path
import hashlib,json,re,collections
O=Path(__file__).resolve().parent;B=O.parent;N=B/'stage49-oracle-native-extended944-build04-01';T=B/'stage49-oracle-extended-transport-03';BUILD=B/'stage49-modulekey-build04'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
def check(ok,msg):
    if not ok:raise ValueError(msg)
check(sha(N/'report.json')=='d9af12838a2949ea130ce30e70e96741259eccea3baf19c37ed1e5811755dae9','literal native944 report')
check(sha(T/'index.json')=='175130f4b2c0ed57968bb4a9bb42d11f6d99b6d6bc32d0676fde0acff3e09282','literal source-input table index')
report=json.loads((N/'report.json').read_bytes());tables=json.loads((T/'index.json').read_bytes());bycase={(Path(t['oracleRoot']).name,t['id']):t for t in tables['cases']}
totals=collections.Counter();request_kinds=collections.Counter();cases=collections.defaultdict(collections.Counter);mismatches=[];intents=collections.Counter();inputs={}
def bound(p,h):
    p=Path(p);check(sha(p)==h,'authenticated source/reference '+str(p));inputs[str(p)]=h;return p.read_bytes()
for row in report['records']:
    proc=row['process'];parts=proc['key'].split('/');oracle_name,case,repeat,session=parts[0],parts[1],int(parts[2]),int(parts[3]);t=bycase[(oracle_name,case)];root=Path(t['oracleRoot'])
    jr=json.loads(bound(root/'report.json',t['oracleReportSha256']));closure=json.loads(bound(root/'closure.json',t['oracleClosureSha256']));inv=json.loads(bound(root/'inventory.json',closure['inventorySha256']))['files']
    for p,h in t['files'].items():bound(p,h)
    for p,r in t['authoredSources'].items():bound(p,r['sha256'])
    obs=next(x for x in jr['observations']if x['case']==case and x['repeat']==repeat);calls=[c for c in obs['calls']if c['session']==session]
    target=N/proc['key'];raw=target/'raw/session-0';check(json.loads((target/'terminal.json').read_bytes())==proc and proc['exitCode']==0 and not proc['timedOut'],'actual140 process terminal linkage');check(sha(target/'stdout.bin')==proc['stdoutSha256']and sha(target/'stderr.bin')==proc['stderrSha256'],'process stream hashes')
    check((raw/'terminal-slots.bin').read_bytes()==b'0','actual terminal slots0')
    for i,c in enumerate(calls):
        checks={};prefix=c['rawPrefix']
        for suffix,expected in [('status.bin',c['status'].encode()),('stdout.bin',bytes.fromhex(c['stdoutUtf8Hex'])),('stderr.bin',bytes.fromhex(c['stderrUtf8Hex'])),('stdout.code-units.bin',bytes.fromhex(c['stdoutUtf16BEHex'])),('stderr.code-units.bin',bytes.fromhex(c['stderrUtf16BEHex']))]:
            original=bound(root/(prefix+'.'+suffix),inv[prefix+'.'+suffix]['sha256']);check(original==expected,'original exact API/raw binding');checks[suffix]=(raw/f'outer-{i}.{suffix}').read_bytes()==expected
        actual=row['api'][i];matched=all(checks.values());check(actual['comparisons']==checks and actual['rawBytesMatch']==matched and not actual['missing'],'independent raw recomputation')
        internal=c['errorClass']=='org.pkl.core.PklBugException';alias=(oracle_name=='stage49-oracle-modulekey-01'and(case.startswith('inference-')and i in[1,2,3]or case=='custom-ref-qualified-types'and i==5))
        check(internal==actual['javaInternalApiBoundary'],'Java internal boundary retained');totals['apis']+=1;totals['matched'if matched else'mismatched']+=1;totals['javaSuccess'if c['status']=='success\n'else'javaError']+=1
        if internal:intents['invalidFragmentInternalApi']+=1
        elif alias:intents['initialAliasIntentNotReached']+=1;check(matched,'initial diagnostic behavior preserved')
        else:intents['intendedOrdinaryMatched'if matched else'intendedOrdinaryMismatch']+=1
        cases[oracle_name+'/'+case]['matched'if matched else'mismatched']+=1
        if not matched:mismatches.append({'key':proc['key'],'index':i,'expression':c['expression'],'javaRawPrefix':str(root/prefix),'nativeRawPrefix':str(raw/f'outer-{i}'),'javaInternalBoundary':internal,'differingChannels':[k for k,v in checks.items()if not v]})
    ids=[];tokens=set();j=0
    while(raw/f'module-{j}.request.bin').is_file():
        p=raw/f'module-{j}';read=lambda s:p.with_name(p.name+'.'+s+'.bin').read_text();token=read('token');ident=int(read('id'));api=int(read('api-index'));check(re.fullmatch(r'\d+:\d+:\d+',token)and token not in tokens and 0<=api<len(calls),'actual unique token and API linkage');tokens.add(token);ids.append(ident);request_kinds[read('kind')]+=1;check(bool(read('completion')),'actual completion retained');j+=1
    check(all(a<b for a,b in zip(ids,ids[1:])),'actual per-session IDs monotonic');check(int(dict(line.split('=',1)for line in(raw/'counters.bin').read_text().splitlines())['requests'])==j,'complete actual typed request ledger')
check(totals==collections.Counter({'apis':944,'matched':904,'mismatched':40,'javaSuccess':760,'javaError':184}),'exact944 accounting')
check(intents==collections.Counter({'invalidFragmentInternalApi':8,'initialAliasIntentNotReached':100,'intendedOrdinaryMatched':804,'intendedOrdinaryMismatch':32}),'intent and ordinary/internal boundaries distinct')
check(sha(BUILD/'build.json')=='08078fe2039aa1844912a2af210c417d81a4a802bf9f3d99489f85ca169b00a6','CLOSED artifact proof');release=json.loads((BUILD/'build.json').read_bytes());check(sha(Path(release['artifact']))==release['artifactSha256'],'unchanged executable')
for rel,h in json.loads((BUILD/'sources-after.json').read_bytes()).items():check(sha(BUILD/'sources'/rel)==h,'unchanged frozen226 source snapshot')
out={'schema':1,'scope':'Independent existing-raw readback only, no evaluation','nativeReportSha256':sha(N/'report.json'),'actualNativeTool':97523,'nativeToolObservedExit':0,'totals':dict(totals),'intentLedger':dict(intents),'typedRequestCounts':dict(request_kinds),'caseCounts':{k:dict(v)for k,v in cases.items()},'mismatches':mismatches,'actualProcessesZero':140,'actualTerminalSlotsZero':140,'sourceAndArtifactChanges':0,'fullOriginalJavaEventCounterGatePassed':False,'qualification':'100 original query-local alias errors are diagnostic observations, not intended feature successes.8 invalid-SPI Java internal errors remain unmatched API boundaries.32 ordinary runtime mismatches require correction; no oracle rewrite.'}
write(O/'report.json',out);write(O/'handoff.json',{'schema':1,'reportSha256':sha(O/'report.json'),'scriptSha256':sha(Path(__file__)),'nativeRoot':str(N),'nativeReportSha256':sha(N/'report.json'),'sourceReferenceFiles':len(inputs),'mismatchCount':40,'ordinaryMismatchCount':32,'internalApiBoundaries':8,'newEvaluations':0});print(json.dumps({'handoffSha256':sha(O/'handoff.json'),'totals':dict(totals),'intentLedger':dict(intents)}))
