"""Frozen build04 only, all acquired Java01–07 raw controls; no Java or build execution."""
from pathlib import Path
import collections,datetime,hashlib,json,os,subprocess,time
O=Path(__file__).resolve().parent;B=O.parent;BUILD=B/'stage49-modulekey-build04';TABLES=B/'stage49-oracle-extended-transport-03'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
def check(ok,msg):
    if not ok:raise ValueError(msg)
check(sha(BUILD/'build.json')=='08078fe2039aa1844912a2af210c417d81a4a802bf9f3d99489f85ca169b00a6','literal CLOSED build04')
check(sha(TABLES/'index.json')=='175130f4b2c0ed57968bb4a9bb42d11f6d99b6d6bc32d0676fde0acff3e09282','literal authenticated input table index')
release=json.loads((BUILD/'build.json').read_bytes());binary=Path(release['artifact']);check(sha(binary)=='7ea24b5ed3e8e085d6f2e41ab0fb6e9cfa270098cc4551ac5060a93f5bed9b98'and release['sourceStable']and release['sourceCount']==226,'released executable and source scope')
check((BUILD/'sources-before.json').read_bytes()==(BUILD/'sources-after.json').read_bytes(),'before/after source maps exact')
mapping=json.loads((BUILD/'sources-after.json').read_bytes());check(len(mapping)==226,'exact source map226')
for rel,h in mapping.items():check(sha(BUILD/'sources'/rel)==h,'frozen source '+rel)
index=json.loads((TABLES/'index.json').read_bytes());check(index['acquiredApiCalls']==944 and len(index['cases'])==35,'all acquired944 accounted')
output=B/'stage49-oracle-native-extended944-build04-01';check(not output.exists(),'fresh actual output');output.mkdir()
inputs={str(BUILD/'build.json'):sha(BUILD/'build.json'),str(BUILD/'sources-after.json'):sha(BUILD/'sources-after.json'),str(binary):sha(binary),str(TABLES/'index.json'):sha(TABLES/'index.json'),str(Path(__file__)):sha(Path(__file__))}
def bound(path,h=None):
    path=Path(path);actual=sha(path);check(h is None or actual==h,'authenticated input '+str(path));inputs[str(path)]=actual;return path.read_bytes()
authorities={};causes={};cause_proof=[]
for t in index['cases']:
    root=Path(t['oracleRoot'])
    if str(root)not in authorities:
        report=json.loads(bound(root/'report.json',t['oracleReportSha256']));closure=json.loads(bound(root/'closure.json',t['oracleClosureSha256']));inv=json.loads(bound(root/'inventory.json',closure['inventorySha256']))['files'];check(closure['sealed']and not closure['liveHandles'],'closed original oracle');authorities[str(root)]=(report,inv)
    report,inv=authorities[str(root)]
    for p,h in t['files'].items():bound(p,h)
    for p,row in t['authoredSources'].items():bound(p,row['sha256'])
    for obs in [r for r in report['observations']if r['case']==t['id']]:
        for s in obs['sessions']:
            mode=t['initialPolicy']
            for e in s['events']:
                raw=bound(root/(e['rawPrefix']+'.bin'),inv[e['rawPrefix']+'.bin']['sha256']);check(raw.hex()==e['utf8Hex'],'original ordered raw event report binding')
                if raw.startswith(b'policy-profile '):mode=raw.decode().removeprefix('policy-profile ')
                if raw.startswith(b'actual-')and b'-denied 'in raw:
                    number=int(raw.rsplit(b'denial=',1)[1]);prefix=f"cases/{t['id']}/{obs['repeat']}/calls/session-{s['session']}/denial-{number}"
                    def cause(field):return bound(root/(prefix+'.'+field+'.bin'),inv[prefix+'.'+field+'.bin']['sha256'])
                    kind=cause('kind').decode();context=cause('context').decode();null=cause('message-null').decode();message=cause('message.code-units');key=(mode,kind,context);row='\t'.join([mode.encode().hex(),kind,context.encode().hex(),null,message.hex()])+'\n';check(key not in causes or causes[key]==row,'consistent actual raw cause profile');causes[key]=row;cause_proof.append({'root':str(root),'rawPrefix':prefix,'mode':mode,'kind':kind,'context':context})
cause_file=O/'causes.tsv';check(not cause_file.exists(),'fresh raw cause table');cause_file.write_text(''.join(causes[k]for k in sorted(causes)));inputs[str(cause_file)]=sha(cause_file)
write(output/'preflight.json',{'build':str(BUILD),'buildSha256':sha(BUILD/'build.json'),'artifactSha256':sha(binary),'sourceMapSha256':sha(BUILD/'sources-after.json'),'sourceCount':226,'tableIndex':str(TABLES/'index.json'),'inputsBefore':inputs,'rawCauseProvenance':cause_proof,'profile':'public-module-source-extended-v1','scope':'All944 acquired raw API rows, including100query-alias intent failures and8 invalid-SPI Java PklBugException boundaries; these are not ordinary intended feature successes.'})
records=[]
for t in index['cases']:
    root=Path(t['oracleRoot']);report,inv=authorities[str(root)]
    for obs in [r for r in report['observations']if r['case']==t['id']]:
        for session in obs['sessions']:
            key=f"{root.name}/{t['id']}/{obs['repeat']}/{session['session']}";target=output/key;target.mkdir(parents=True)
            command=[str(binary),t['mainSource'],t['mainUri'],'main',t['operations'],str(target/'raw'),'1',t['initialPolicy'],str(cause_file),'public-module-source-extended-v1',t['config']]
            process={'key':key,'command':command,'cwd':str(O),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'TZ':'UTC','LANG':'C','LC_ALL':'C'}}
            with(target/'stdout.bin').open('wb')as out,(target/'stderr.bin').open('wb')as err:
                p=subprocess.Popen(command,cwd=O,env={**os.environ,**process['environment']},stdout=out,stderr=err);process['pid']=p.pid;write(target/'launch.json',process)
                try:process['exitCode']=p.wait(timeout=120);process['timedOut']=False
                except subprocess.TimeoutExpired:p.kill();process['exitCode']=p.wait();process['timedOut']=True
            process.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha(target/'stdout.bin'),stderrSha256=sha(target/'stderr.bin'));write(target/'terminal.json',process)
            native=target/'raw/session-0';calls=[c for c in obs['calls']if c['session']==session['session']];results=[]
            for i,c in enumerate(calls):
                check(not c['missingFields'],'complete original API capture');prefix=c['rawPrefix'];checks={};missing=[]
                for suffix,expected in [('status.bin',c['status'].encode()),('stdout.bin',bytes.fromhex(c['stdoutUtf8Hex'])),('stderr.bin',bytes.fromhex(c['stderrUtf8Hex'])),('stdout.code-units.bin',bytes.fromhex(c['stdoutUtf16BEHex'])),('stderr.code-units.bin',bytes.fromhex(c['stderrUtf16BEHex']))]:
                    original=bound(root/(prefix+'.'+suffix),inv[prefix+'.'+suffix]['sha256']);check(original==expected,'original API/raw report exact binding');path=native/f'outer-{i}.{suffix}'
                    if path.is_file():checks[suffix]=path.read_bytes()==expected
                    else:missing.append(suffix)
                boundary=c['errorClass']=='org.pkl.core.PklBugException';matched=not missing and all(checks.values());results.append({'index':i,'expression':c['expression'],'sourceProfileId':c['source'],'javaErrorClass':c['errorClass'],'javaInternalBoundary':boundary,'missing':missing,'comparisons':checks,'rawBytesMatch':matched,'ordinaryCompatibilityPass':matched and not boundary})
            row={'process':process,'api':results,'rawBytesMatch':sum(c['rawBytesMatch']for c in results),'rawMismatchOrMissing':sum(not c['rawBytesMatch']for c in results),'ordinaryCompatibilityPass':sum(c['ordinaryCompatibilityPass']for c in results),'javaInternalApiBoundaries':sum(c['javaInternalBoundary']for c in results),'javaIntentScope':t['scope'],'terminalSlots':(native/'terminal-slots.bin').read_text()if(native/'terminal-slots.bin').is_file()else None,'fullJavaObserverGatePassed':False,'fullJavaObserverScope':'Original raw events/counters retained by pinned oracle reference; no synthetic getter/factory/security observer events.'}
            write(target/'comparison.json',row);records.append(row);write(output/'progress.json',{'terminalProcesses':len(records),'lastCase':key,'rawMatches':sum(x['rawBytesMatch']for x in records),'rawMismatchOrMissing':sum(x['rawMismatchOrMissing']for x in records)})
after={p:sha(Path(p))for p in inputs};changes=[p for p,h in inputs.items()if after[p]!=h]
for rel,h in mapping.items():check(sha(BUILD/'sources'/rel)==h,'frozen source after '+rel)
summary={'schema':1,'profile':'public-module-source-extended-v1','records':records,'acquiredJavaApiCalls':944,'rawBytesMatch':sum(r['rawBytesMatch']for r in records),'rawMismatchOrMissing':sum(r['rawMismatchOrMissing']for r in records),'ordinaryCompatibilityPass':sum(r['ordinaryCompatibilityPass']for r in records),'javaInternalApiBoundaries':sum(r['javaInternalApiBoundaries']for r in records),'inputChanges':changes,'allProcessesTerminal':True,'processExitCounts':dict(collections.Counter(r['process']['exitCode']for r in records)),'allTerminalSlotsZero':all(r['terminalSlots']=='0'for r in records),'fullJavaEventCounterGatePassed':False,'sourceArtifactStable':not changes,'liveHandles':[],'qualification':'Raw mismatch/internal/intent-not-reached scopes remain separate. Java System.gc requests and native per-poll/explicit collection differ. No fullM2/platform/performance completion claim.'}
write(output/'report.json',summary);print(json.dumps({k:v for k,v in summary.items()if k!='records'},indent=2));raise SystemExit(0 if not changes and all(r['process']['exitCode']==0 and not r['process']['timedOut']for r in records)else 1)
