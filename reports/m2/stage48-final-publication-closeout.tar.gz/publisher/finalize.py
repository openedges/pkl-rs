"""Attach the closed packaging record, retaining later small raw logs inline."""
from pathlib import Path
import base64,hashlib,json
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');OUT=Path(__file__).parent;DEST=MAIN.parent/'pkl-rs.stage51';REPORTS=DEST/'reports/m2'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_bytes())
pub=load(OUT/'report.json');pub_exec=load(OUT/'execution/report.json');pub_terminal=load(OUT/'execution/outer-terminal.json')
closed=load(OUT/'closeout-report.json');ce=load(OUT/'closeout-execution/report.json');ct=load(OUT/'closeout-execution/outer-terminal.json')
assert pub_exec['terminal'] and pub_exec['exitCode']==0 and pub_terminal['exit_code']==0
assert pub_terminal['process_report_sha256']==sha(OUT/'execution/report.json')
assert ce['terminal'] and ce['exitCode']==0 and ct['exit_code']==0 and ct['process_report_sha256']==sha(OUT/'closeout-execution/report.json')
assert closed['independentMemberAndOriginalBytesEqual'] and all(row['exitCode']==0 for row in closed['commands'])
archive=Path(closed['archive']);assert sha(archive)==closed['archiveSha256']
summary_path=REPORTS/'stage48-final-summary.json';before=load(summary_path)
assert sha(summary_path)==closed['prePointerSummarySha256'] and 'publication_closeout' not in before
raw=lambda p:{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p),'base64':base64.b64encode(p.read_bytes()).decode()}
descriptor={'schema':1,'scope':'Closed Stage48 publication metadata. No acquisition/build/evaluator rerun or new compatibility result.',
 'archive':{'path':str(archive.relative_to(DEST)),'sha256':sha(archive),'compressed_bytes':archive.stat().st_size,'payload_files':closed['payloadFiles'],'payload_bytes':closed['payloadBytes']},
 'captures':{'path':'reports/m2/stage48-final-regression-captures.json','sha256':sha(REPORTS/'stage48-final-regression-captures.json')},
 'pre_pointer_summary_sha256':closed['prePointerSummarySha256'],
 'pre_pointer_summary_archive_member':'reviewed-publication/stage48-final-summary.json',
 'publication_execution':{'report':pub_exec,'actual_outer_terminal':pub_terminal,'archive_prefix':'execution/'},
 'closeout_execution':{'report':ce,'actual_outer_terminal':ct,'stdout':raw(OUT/'closeout-execution/stdout.bin'),'stderr':raw(OUT/'closeout-execution/stderr.bin')},
 'closeout_evidence_commands':[{'result':row,'stdout':raw(OUT/('closeout-'+action)/'stdout.bin'),'stderr':raw(OUT/('closeout-'+action)/'stderr.bin')}for action,row in zip(['create','verify'],closed['commands'])],
 'closeout_raw_qualification':'The primary packaging process and command raw logs are in the closeout archive. Later closeout process/command raw bytes are retained exactly as base64 here to avoid circular archive recapture.',
 'source_mode_qualification':'Exact acquisition source paths/kinds/modes/lengths/hashes are recoverable from archived publication/selection.json and publisher/selection.json; deterministic tar headers are0644.',
 'producer_terminal_qualification':'Late root actual terminal receipt and C actual audit terminal receipt both retained explicitly; late recorded timestamps are not contemporaneous exit timestamps.',
 'all_create_verify_and_original_readback_passed':True,'original_acquisition_changes':[],
 'full_m2_complete':False,'root_review_docs_git_pending':True}
path=REPORTS/'stage48-final-publication-closeout.json';assert not path.exists();path.write_text(json.dumps(descriptor,indent=2)+'\n')
after={**before,'publication_closeout':{'path':str(path.relative_to(DEST)),'sha256':sha(path)}}
assert {k:v for k,v in after.items()if k!='publication_closeout'}==before
summary_path.write_text(json.dumps(after,indent=2)+'\n')
result={'scope':'Final metadata pointer only; all pre-existing summary fields unchanged.','summary':{'path':str(summary_path.relative_to(DEST)),'sha256':sha(summary_path)},'closeout':{'path':str(path.relative_to(DEST)),'sha256':sha(path)},'archiveCount':len(pub['archives'])+1,'archiveCompressedBytes':sum(row['compressed_bytes']for row in pub['archives'])+archive.stat().st_size,'originalAcquisitionChanges':[]}
(OUT/'finalization-report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
