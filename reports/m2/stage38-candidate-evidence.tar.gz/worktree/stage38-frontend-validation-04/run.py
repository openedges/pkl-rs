from pathlib import Path
import json,hashlib,sys,os
R=Path.cwd();O=R/'target/m2/stage38-frontend-validation-04';sys.path.insert(0,str(R/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
owned=['crates/pkl-runtime/src/'+n for n in ('syntax.rs','parser.rs','resolver.rs','vm/compiler_expressions.rs','power_assertions.rs')]+['crates/pkl-runtime/tests/m2_read_frontend.rs']
owned=sorted(set(owned)|{str(p.relative_to(R)) for p in (R/'crates/pkl-runtime/src').rglob('*') if p.is_file() and p.suffix in ('.rs','.pkl')}|{'Cargo.lock','Cargo.toml','crates/pkl-runtime/Cargo.toml','references.lock','rust-toolchain.toml'})
before={n:sha(R/n) for n in owned}
for n in owned:
 p=O/'sources'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
build=benchmark.capture(['cargo','build','-p','pkl-runtime','--lib','--locked','--target-dir',str(R/'target/m2/stage38-frontend-cargo')],R,dict(os.environ),O/'cargo-build',timeout=120);assert build['exit_code']==0
libs=list((R/'target/m2/stage38-frontend-cargo/debug/deps').glob('libpkl_runtime-*.rlib'));assert len(libs)==1
(O/'linked-runtime.rlib').write_bytes(libs[0].read_bytes())
capture=benchmark.capture(['rustc','--edition=2024',str(O/'scalar_probe.rs'),'--extern','pkl_runtime='+str(libs[0]),'-L','dependency='+str(libs[0].parent),'-o',str(O/'scalar_probe')],R,dict(os.environ),O/'rustc',timeout=120);assert capture['exit_code']==0
results=[]
for group,power in [('stage38-read-frontend-oracle-01',False),('stage38-read-shadow-oracle-01',False),('stage38-read-power-oracle-01',True),('stage38-method-diagnostic-oracle-01',False),('stage38-method-order-oracle-01',False),('stage38-method-order-oracle-02',False)]:
 oracle=R/'target/m2'/group;manifest=json.loads((oracle/'manifest.json').read_text());jreport=json.loads((oracle/'report.json').read_text());meta=json.loads((oracle/'oracle.json').read_text())
 for c in manifest:
  d=O/'comparison'/group/c['id'];cmd=[str(O/'scalar_probe'),str(oracle/'cases'/c['id']/'input.pkl')]+(['power'] if power else []);record=benchmark.capture(cmd,R,meta['environment'],d,timeout=30)
  j=oracle/'cases'/c['id']/'java/process';equal={ch:(d/(ch+'.bin')).read_bytes()==(j/(ch+'.bin')).read_bytes() for ch in ('stdout','stderr')};expected=next(x['process']['exit_code'] for x in jreport['results'] if x['id']==c['id']);results.append({'group':group,'id':c['id'],'process':record,'raw_equal':equal,'exit_equal':record['exit_code']==expected,'pass':all(equal.values()) and record['exit_code']==expected})
after={n:sha(R/n) for n in owned}
report={'scope':'Independent full-raw frontend comparison against unchanged pinned Java sources/captures, including original shadow failure and additive controls. Debug artifact; final root-wide build/acquisition remains separate.','wrapper_sha256':sha(O/'scalar_probe'),'rlib_sha256':sha(O/'linked-runtime.rlib'),'compiler':capture,'build':build,'owned_sources':before,'owned_source_stability':before==after,'results':results,'passing':sum(x['pass'] for x in results),'count':len(results)};(O/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passing':report['passing'],'count':len(results),'mismatches':[(r['group'],r['id']) for r in results if not r['pass']]}))
