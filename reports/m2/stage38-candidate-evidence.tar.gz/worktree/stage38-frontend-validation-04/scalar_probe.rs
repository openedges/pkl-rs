use std::{env,fs,io::{self,Write}};
fn main() {
    let args: Vec<_> = env::args().collect();
    let source=fs::read_to_string(&args[1]).unwrap();
    let options=pkl_runtime::evaluation::EvaluationOptions{power_assertions:args.get(2).is_some_and(|s|s=="power")};
    match pkl_runtime::evaluation::scalar_expression_with_options(&source,"file:///stage38-read-frontend.pkl","stage38-read-frontend","result",options) {
        Ok(value) => io::stdout().write_all(value.as_bytes()).unwrap(),
        Err(error) => {io::stderr().write_all(error.as_bytes()).unwrap();std::process::exit(1);}
    }
}
