# 다음 M2 작업 단위 독립 검토

## 결론과 조사 경계

다음 구현 단위는 **원본 frontend 오류 snippet 72개의 실제 `eval` 계약 연결**을 우선 권고한다. 새 scalar 사례를 더 만드는 대신, 이미 필수 목록에 있는 미실행 원본을 직접 실행하고 닫는 작업이다. 그다음은 원본 Lexer/Span JVM 계약 2개를 독립적으로 연결하고, 실제 `ModuleOutput` 오류 경계를 준비한 뒤 원본 const 오류 25개를 처리한다.

이 문서는 소스·목록을 읽고 계획만 세웠다. Java/Rust 실행, 빌드, 광범위 실험, 추적 파일 변경은 하지 않았다. 후보 개수는 앞으로 통과할 개수가 아니며 M2 완료율로 계산하지 않는다. Stage38 suggestion-order 수정과 플랫폼 최종 재취득은 별도 진행 중인 작업이다.

## 현재 원래 의무

조사 snapshot의 `compatibility/m2-language.json`은 accounting row 4,518개, ready 3,518개, unimplemented 960개, unmapped 40개다. 요구사항은 475개, semantic family는 31개이고 `m2-mappings.json`의 검토된 부분 연결 기록은 25개다. 이것들은 서로 겹치는 기록이며 독립 기능 수가 아니다.

- unimplemented 960개는 원본 `language-snippet` 957개와 이미 선별된 원본 rev1 module/CLI 회귀 3개다. 후자의 정확한 ID는 `m2:rev1:t36-foreign-nominal-identity`, `m2:rev1:t40-imported-declaration-authority`, `m2:rev1:t40-foreign-namesake`다.
- 원본 snippet 957개 중 888개는 전체 snippet/output adapter와 Rust renderer 미구현 사유다. 65개는 PackageServer·TLS·project fixture, 3개는 package/HTTP fixture, 1개는 JVM classpath/modulepath adapter 의존성이다. 이 분류는 새 실험 결과가 아니다.
- unmapped 40개는 모두 `rev1-candidate:*`다. 원문·후보 hash와 미선별 상태를 `unmapped40.json`에 보존했다. 지원 파일과 entrypoint가 함께 있으므로 40개를 기능 40개나 독립 assertion 40개로 취급하면 안 된다. 과거 rev1 통과를 이 프로젝트 결과로 옮길 수 없다.
- 현재 runner `tools/m2_language.py`는 `adapter == language-api-string`만 선택한다. `adapter:null`인 1,000개를 실제 취득하지 않는 것이 첫 구조적 장애다.

`PLAN.md`의 M2-01~09는 모두 진행 중이다. 이번 우선순위는 M2-01 목록/실행, M2-02 frontend, M2-08 진단, M2-09 gate의 원래 종료 조건을 직접 줄이는 방향이다. M2-03 함수, M2-04 클래스, M2-05 타입, M2-06 collection, M2-07 Reference의 미완료 범위는 그대로 남는다. PLAN의 과거 단계 서술이나 오래된 연결 수를 현재 수치로 사용하지 않고 위 기계 목록 snapshot을 기준으로 했다.

## 우선순위 1: 원본 frontend 오류 72개

**정확한 원본 집합**은 `candidate1-original72.json`에 원래 행 전체로 보존했다. ID prefix는 `pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/`다.

| 원본 하위 집합 | 수 | 정확한 지정 |
| --- | ---: | --- |
| delimiter 오류 | 46 | `errors/delimiters/*.pkl`의 현재 필수 행 전부 |
| numbered parser 오류 | 20 | `errors/parser1.pkl`~`parser12.pkl`, `errors/parser14.pkl`~`parser21.pkl`; `parser13.pkl` 행을 새로 만들어 넣지 않음 |
| parser 폴더의 오류 계약 | 6 | `parser/amendsRequiresParens.pkl`, `constantStringInterpolation.pkl`, `invalidCharacter.pkl`, `spacesBetweenDocComments.pkl`, `typeAnnotationInAmends.pkl`, `wrongDocComment.pkl` |

세 집합은 겹치지 않는다. 46+20+6=72개이며 전부 원본 `.err` resource를 가진다. parser 폴더 13개 전체를 완료로 말하지 않는다. 남은 7개는 PCF 결과 또는 별도 원래 동작을 요구한다. 여기서 frontend는 lexer, parser, AST 검증을 포함한다. 예를 들어 잘못된 import의 문자열 interpolation은 로딩을 성공시키는 것이 아니라 허용되지 않은 구문을 먼저 판정하는 사례다.

**원래 실행/출력 경계:** 원본 행의 `upstream_case.command`, `cwd`, 환경, property/env 설정, `--settings pkl:settings`, 원본 물리 파일 URI와 리소스 hash를 그대로 사용한다. 각 행의 `channels`는 `stdout`, `stderr`, `exit_code`, `files`다. `.err` golden은 upstream이 경로·줄 번호·웹사이트 등을 가공한 provenance이고 raw expected bytes가 아니다. 새 pinned Java CLI 실행으로 실제 원시 기대값과 정확한 종료 코드를 얻어야 한다. 원본 목록의 `[0,1]` 허용 범위나 `observe`를 성공 판정으로 사용하면 안 된다.

**구현/adapter 장애:** 현재 scalar API는 식 문자열을 평가하고 `repl:text` frame을 추가한다. 이것을 원래 module `eval` 계약으로 바꿔 부를 수 없다. 공통 source/diagnostic 경로를 쓰는 제한된 실제 eval adapter와 compiler 단계의 module URI/이름/첫 오류/UTF16 span 경계가 필요하다. 원래 옵션을 제거하거나 무시하는 fixture별 wrapper는 해법이 아니다. parser 오류에 도달하기 전의 CLI 설정 초기화도 실제 Java에서 확인해야 한다. 제품 CLI 전체를 구현했다는 주장은 별개다.

**M3/M4 관계:** 이 집합은 값의 성공 PCF 렌더링을 목표로 하지 않으므로 가장 먼저 독립적으로 연결하기 좋다. 다만 모든 입력이 실제로 renderer/외부 로딩 전에 실패하는지는 fresh Java와 source 경로로 확인할 검증 항목이다. 파일에서 원문을 읽고 source identity를 보존하는 fixture Host는 필요하다. 네트워크나 package 기능을 흉내 내서 지나가면 안 된다.

**닫는 증거:** 원본 72개 ID/명령/입력/리소스/순서를 보존하고 Java/Rust 실제 실행을 새 디렉터리에서 취득한다. 전체 stdout/stderr/정확한 exit/files 경로 집합과 바이트를 비교한다. 빈 stdout·빈 파일 집합도 확인한다. fresh evaluator 반복, 첫 lexical/syntax 오류 우선순위와 CR/CRLF·Unicode span 회귀, native와 실제 Node/browser의 같은 공통 진단을 확인한다. 통과한 원래 행만 ready/pass로 바꾸고 나머지는 실패 이유를 유지한다. 72개가 모두 실제 원래 경계를 통과할 때만 해당 72개 pending 의무가 줄어든다. 다른 parser/lexer 요구사항 전체가 완료되는 것은 아니다.

## 우선순위 2: 원본 Lexer/Span suite 2개

원본 IDs와 계약 행은 `candidate2-original-suites.json`에 있다.

1. `pkl:suite-source:pkl-parser/src/test/kotlin/org/pkl/parser/LexerTest.kt`: `@Test` method 8개.
2. `pkl:suite-source:pkl-parser/src/test/kotlin/org/pkl/parser/SpanTest.kt`: `@Test` method 1개 (`endWith test`).

8+1은 선언된 test method 수이며 assertion 수가 아니다. Unicode comment 검사는 원래 loop와 sentinel/비문자 경계를 그대로 실행해야 한다. 현재 corpus의 suite 행은 source/support 단위이며 실제 JVM 실행 전 assertion 수는 `null`이다.

**원래 경계:** pinned upstream `:pkl-parser:test`에서 정확한 두 test class를 실행하여 실제 test 실행 수·실패·JUnit 결과와 소스/도구 신원을 기록한다. Java pass 자체는 Rust pass가 아니다. Rust에서도 원래 identifier 판단/인용, token 순서, 오류 종류/원문/위치, LF/CR/CRLF continuation, U+7FFF/U+FFFF 및 원래 codepoint loop, Span.endWith의 네 입력쌍을 같은 입력·정의로 확인한다. 추가 differential 관찰 protocol은 lossless UTF16/token/span/오류를 기록하고 Rust가 기대값을 생성해서는 안 된다.

**장애:** Rust `parser.rs`의 `Lexer`는 private이고 외부 공개 경계는 `parse_module`/`parse_expression`다. token 수준을 실제로 관찰할 개발 adapter/공유 test entry가 필요하다. Java token enum과 Rust 내부 token 표현을 이름만 맞춰 출력해서는 안 되며, 원본 token의 실제 consumed span과 오류 시점을 관찰해야 한다. 기존 parser 최종 진단을 일부 메시지 `contains` 검사로 약화시키지 않는다. JVM/Gradle 실행 환경과 support source 연결도 필요하다.

**M3/M4 관계/효과:** PCF/HTTP/module loader 없이 가능한 원래 frontend 의무다. 단, 이 두 suite는 960/40 행과 별도 corpus-source 기록이다. 둘을 닫아도 미구현 960이 자동으로 958이 되는 것은 아니다. M2-02/09의 원본 검증 누락을 줄이고 이후 원래 snippet 연결의 회귀 근거를 만든다. `ParserComparisonTest` 1개와 SexpRenderer support 2개, 유효 source 전체 AST 비교 의무도 별도로 남는다. 임의로 그 suite의 원래 제외 규칙을 더 늘리면 안 된다.

## 우선순위 3: 원본 self-contained const 오류 25개

정확한 25개 원본 ID/명령은 `candidate3-original25.json`에 있다. `errors/const/` 원본 31개 중 외부 import/module amendment가 없는 25개다. 주 작업은 M2-03/04/05/08의 const lexical/receiver/owner/this/outer/super·closure·형식 초기화 오류다.

**남겨 두는 원래 6개:** `constAmend.pkl`, `constAssign.pkl`은 다른 원본 module amendment, `constAnnotation.pkl`, `constAnnotation2.pkl`, `constAnnotation3.pkl`은 `pkl:reflect`, `constLocalAmendModule.pkl`은 triple-dot module 로딩과 성공 PCF 출력을 요구한다. 이들은 `candidate3-deferred6.json`에 그대로 보존했으며 25개가 원래 31개 전체를 대체하지 않는다.

**원래 경계:** 우선순위 1과 같은 실제 original eval stdout/stderr/exit/files다. 단순 property path를 선별하거나 `result`를 덧붙이면 원래 module forcing/오류 선택 계약이 바뀐다. `constFunctionCallingNonConst.pkl`의 실제 함수 호출과 `constOuter2.pkl`의 중첩 lazy interpolation 등은 원래 원문 그대로 실행한다. 실제 CLI의 power assertion 기본값은 true다 (`EvalCommand.kt`의 `--no-power-assertions` 기본 설정). 현재 scalar 고정 URI/false 사례의 기대값을 가져오면 안 된다.

**중요한 선행 장애:** `EvaluatorImpl.evaluateOutputBytes`는 실제 ModuleOutput.bytes를 읽는다. `AbstractRenderer.visitTyped/visitDynamic/visitListing/visitMapping`은 `force(false,false)`와 converter/멤버 방문 경계를 사용한다. `VmObject.toString`의 `force(true,true)`나 현재 scalar `module.toString()`을 이 경로와 같다고 가정하면 undefined 처리·순서·프레임이 달라질 수 있다. 원래 오류가 출력 문자열을 만들기 전에 발생하더라도, 그 오류를 선택한 renderer 방문/강제 평가 경계 자체는 재현해야 한다. 이 부분을 source와 fresh Java로 확정하고 공통 실제 ModuleOutput 오류 경로를 구현한 뒤 진행한다. PCF 성공 출력 전체의 M3 완료를 주장하지 않으며, M3 경계를 피하려고 다른 평가를 대신 실행해서도 안 된다. 이 때문에 현재는 1·2보다 우선순위가 낮다.

**닫는 증거:** 25개 전체 original raw eval 비교, 같은 evaluator 반복과 실패 이후 상태 격리, pending 값/타입/const lexical owner GC·취소·재진입 회귀를 원래 의미론에 맞게 확인한다. 실제 first failure와 논리적 frame, power assertion 여부와 원문 URI를 보존한다. 성공한 original 행만 닫고 나머지 const/전체 오류 코퍼스는 그대로 남긴다.

## 공통 마감 규칙과 권고 실행 순서

1. 이 ignored 계획을 바탕으로 먼저 **72개 original frontend contract용 adapter + fresh Java 원본**을 승인 가능한 작은 작업으로 제안한다. 원문·ID·기대 경계를 동결하고 실제 실패를 먼저 취득한다.
2. lexer/Span 원본 suite는 별도 실행 경계로 연결할 수 있다. JVM 결과·Rust differential 결과·전체 960/40 accounting 변경을 서로 섞지 않는다.
3. runtime 오류 집합은 ModuleOutput/renderer force 경계의 의존성을 먼저 해결한다. 성공 PCF/API snippet을 scalar 식으로 바꾼 성공으로 원본 완료를 표시하지 않는다.
4. 957 original snippet, 3 selected original rev1, unmapped40, M2의 9 workstream과 M3/M4 의존성은 축소하지 않는다. 새 selected case와 회귀는 보완 증거이며 원래 계약의 대체물이 아니다.

검토에 사용한 모든 정확한 소스 hash와 counts, source 안정성은 `inventory-review.json`에 있다. 이 문서는 현재 소스의 통과 여부를 예측한 결과가 아니다.
