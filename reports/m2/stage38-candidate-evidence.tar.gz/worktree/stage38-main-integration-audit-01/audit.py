from pathlib import Path
from collections import Counter
import hashlib,json
R=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage38');M=Path('/Users/cody.ij.hwang/Projects/pkl-rs');O=R/'target/m2/stage38-main-integration-audit-01'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(Path(p).read_text())
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def ident(p):return {'path':str(p),'sha256':sha(p),'bytes':Path(p).stat().st_size}
Apath=R/'target/m2/stage38-core-order-validation-02/freeze.json';A=read(Apath);assert sha(Apath)=='b7462d88f39f5c750e50eff7b9daadd0be925276d033dfcaf34dd03faa5af021'
Bpath=R/'target/m2/stage38-frontend-validation-04/comparison.json';B=read(Bpath);assert B['passing']==B['count']==45 and B['owned_source_stability']
Cpath=R/'target/m2/stage38-platforms-final-03/report.json';C=read(Cpath);Cfpath=R/'target/m2/stage38-platform-review-final-03/final-source-freeze.json';Cf=read(Cfpath);Crpath=R/'target/m2/stage38-platform-review-final-03/report.json';Cr=read(Crpath)
assert C['source_stability'] and Cf['frozen'] and Cr['passed'] and Cr['source_stability'] and Cr['artifact_stability'] and Cr['manifest_stability']
assert Cf['A_corrected_freeze_sha256']==Cr['A_corrected_freeze_sha256']==sha(Apath)
union={};groups={}
for label,sources in [('A117',A['sources']),('B45',B['owned_sources']),('Ccompiled',C['source_hashes']),('C3-Bmodule-manifest',Cf['files_sha256'])]:
 for n,h in sources.items():
  assert sha(R/n)==h and sha(M/n)==h,n
  if n in union:assert union[n]==h,n
  union[n]=h
  if label=='B45':assert sha(Bpath.parent/'sources'/n)==h,n
  if label=='Ccompiled':assert sha(Cpath.parent/'sources'/n)==h,n
 groups[label]=len(sources)
for n,h in C['artifacts'].items():assert sha(Cpath.parent/n)==h,n
assert sha(Bpath.parent/'scalar_probe')==B['wrapper_sha256'] and sha(Bpath.parent/'linked-runtime.rlib')==B['rlib_sha256']
phasepath=M/'target/m2/stage38-integration-01/phase3.json';phase=read(phasepath)
for x in phase['copied']:assert sha(M/x['path'])==sha(R/x['path'])==x['after'],x['path']
# Reuse accepted corpus provenance; recheck direct current inputs and all100 origins.
prior=read(R/'target/m2/stage38-corpus-addition-01/prior-cases.json')['cases'];cases=read(M/'tests/fixtures/m2/cases.json')['cases'];assert len(prior)==3427 and len(cases)==3527 and cases[:3427]==prior
assert cases==read(R/'tests/fixtures/m2/cases.json')['cases']
preserved=read(R/'target/m2/stage38-corpus-independent-audit-01/original3427-preservation.json');assert len(preserved)==3427
for c in preserved:assert sha(M/c['input'])==c['sha256']
proofs=[read(R/f'target/m2/stage38-corpus-addition-{i:02}/report.json') for i in (1,2,3,4)];origins=sum((x['origins'] for x in proofs),[]);newcases=cases[3427:];assert len(origins)==100 and [x['id'] for x in origins]==[x['id'] for x in newcases]
for c,p in zip(newcases,origins):
 manifest=Path(p['manifest']);report=Path(p['report']);assert sha(manifest)==p['manifest_sha256'] and sha(report)==p['report_sha256'];original=next(x for x in read(manifest) if x['id']==p['origin_id'])
 data=original['source'].encode();assert data==(M/c['input']).read_bytes()==(R/c['input']).read_bytes();assert sha(M/c['input'])==p['source_sha256'];assert c['expression']==original['expression']
 rows=[x for x in read(report)['results'] if x['id']==original['id']];assert rows and all(x['process']['exit_code']==(0 if c['expected_outcome']=='success' else 1) for x in rows)
 assert c['expected_outcome'] in ('success','failure')
power=[c['id'] for c in newcases if c.get('power_assertions',False)];assert power==['read-stage38-power-power-read-null-comparison','read-stage38-power-power-read-lexical-operand']
oldmap=read(R/'target/m2/stage38-corpus-addition-01/prior-mappings.json');mapping=read(M/'compatibility/m2-mappings.json');assert mapping==read(R/'compatibility/m2-mappings.json')
before={x['requirement']:x for x in oldmap['requirements']};after={x['requirement']:x for x in mapping['requirements']};assert len(before)==22 and len(after)==25
for k,v in before.items():
 current=after[k];assert current['implementation']['state']==current['tests']['state']=='partial'
 if k=='semantic:diagnostics':
  assert current['implementation']==v['implementation'] and current['remaining']==v['remaining'];assert current['tests']['case_ids']==v['tests']['case_ids']+[x['id'] for x in newcases if x['id'].startswith('method-stage38-')];assert current['scope'].startswith(v['scope'])
 else:assert current==v
for k in set(after)-set(before):assert after[k]['implementation']['state']==after[k]['tests']['state']=='partial' and after[k]['remaining']
manifest=read(M/'compatibility/m2-language.json');assert sha(M/'compatibility/m2-language.json')==sha(R/'compatibility/m2-language.json')=='0be0a102d68afa09cac30467feea7bed755af0f2e2d2b17899f4993274842b36'
assert manifest['counts']['cases_by_execution']=={'ready':3527,'unimplemented':960,'unmapped':40} and manifest['counts']['requirements']==475 and manifest['counts']['requirements_by_kind']['semantic-family']==31
# Historical pre-order-fix3518 report, not the live corrected3527 run.
prepath=M/'target/m2/stage38-language-final-02/report.json';pre=read(prepath);preold=M/'target/m2/stage37-language-final-01';old=read(preold/'report.json')
assert pre['selected_count']==3518 and len(pre['results'])==3518 and dict(Counter(x['status'] for x in pre['results']))==pre['status_counts']=={'pass':3509,'mismatch':8,'oracle-error':1}
assert pre['source_stability'] and pre['artifact_stability'] and pre['candidate']['source_binding']=='recorded-build' and pre['candidate']['build']['exit_code']==0
prebase=prepath.parent;assert sha(prebase/'artifacts/language_probe')==pre['candidate']['sha256']
assert pre['source_sha256']['crates/pkl-runtime/src/vm.rs']=='df4a21a51d487fbdf0d444f1645a6bd48feabd988677b774dfd02b3e3adc6a7d'
for x in phase['copied']:
 if x['before'] is not None and x['path'] in pre['source_sha256']:assert pre['source_sha256'][x['path']]==x['before']
predefs=read(prebase/'sources/tests/fixtures/m2/cases.json')['cases'];assert predefs==read(R/'target/m2/stage38-corpus-addition-04/prior-cases.json')['cases'] and predefs==cases[:3518]
rows={x['id']:x for x in pre['results']};statuschanges=[];rawchanges={'java':[],'rust':[]}
for oldrow in old['results']:
 n=oldrow['id'];cur=rows[n];assert (prebase/'cases'/n/'input.pkl').read_bytes()==(preold/'cases'/n/'input.pkl').read_bytes()
 if oldrow['status']!=cur['status']:statuschanges.append({'id':n,'old':oldrow['status'],'new':cur['status']})
 for language in ('java','rust'):
  fields=['exit_code','timed_out','stdout_sha256','stderr_sha256'];different=[k for k in fields if oldrow[language].get(k)!=cur[language].get(k)]
  if different:
   rawchanges[language].append({'id':n,'changed_fields':different,'old':{k:oldrow[language].get(k) for k in fields},'new':{k:cur[language].get(k) for k in fields}})
   for prefix,base in [('old',preold),('new',prebase)]:
    for channel in ('stdout','stderr'):
     data=(base/'cases'/n/f'{language}.{channel}.bin').read_bytes();expected=(oldrow if prefix=='old' else cur)[language][channel+'_sha256'];assert hashlib.sha256(data).hexdigest()==expected
     target=O/'changed-raw'/n/prefix/f'{language}.{channel}.bin';target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
assert statuschanges==[{'id':'trace-stage37-noop-force-read','old':'mismatch','new':'pass'},{'id':'trace-stage37-strict-list-force','old':'mismatch','new':'pass'}]
assert {x['id'] for x in rawchanges['rust']}=={x['id'] for x in statuschanges}
assert {x['id'] for x in rawchanges['java']}=={'error-cycle'}
legacy=['error-remainder-zero','annotation-stage35-builtin-source-code-union-and-string','trace-stage37-repeat-empty-cast-negative','trace-stage37-repeat-empty-max-count'];assert all(rows[x]['status']=='mismatch' for x in legacy) and rows['error-cycle']['status']=='oracle-error'
internal=['read-stage38-edge-http-opaque','read-stage38-edge-http-invalid-host','read-stage38-edge-http-nonnumeric-port'];portable=read(R/'target/m2/stage38-platform-oracle-01/fixed-payloads.json')
for n in internal:
 assert rows[n]['status']=='mismatch' and (prebase/'cases'/n/'java.outcome.bin').read_bytes()==b'pkl-exception\torg.pkl.core.PklBugException\n'
 assert next(x for x in portable if x['id']==n)['oracleClassification']=='oracle-error'
assert len(pre['metamorphic_results'])==88 and all(x['status']=='pass' for x in pre['metamorphic_results'])
save('source-union.json',union);save('historical-result-changes.json',{'status_changes':statuschanges,'raw_changes':rawchanges,'remaining_old_mismatches':legacy,'cycle_status':'oracle-error','sourcepath_internal_errors_as_mismatch':internal,'portable_same_internal_errors_as_oracle_error':internal})
report={'status':'closed','scope':'Read-only MAIN final frozen-source and3527corpus integration audit plus completed historical pre-order-fix3518 report inspection. No builds or runtime reruns; live final3527 language/persistent/trace/check results are explicitly excluded.','source_groups_verified_main_worktree_snapshots':groups,'unique_source_identities':len(union),'source_drift':[],'source_conflicts':[],'identities':{'A_corrected_freeze':ident(Apath),'B_raw45':ident(Bpath),'C_compiled_standard':ident(Cpath),'C_final03_audit':ident(Crpath),'C_source_freeze':ident(Cfpath),'main_phase3':ident(phasepath),'historical_language3518':ident(prepath)},'phase3_paths_verified':len(phase['copied']),'corpus':{'total':3527,'original3427definitions_order_inputs_unchanged':True,'new100original_java_source_provenance_verified':True,'new_outcomes':dict(Counter(x['expected_outcome'] for x in newcases)),'two_power_cases':power,'pending_unimplemented':960,'pending_unmapped':40,'requirements':475,'semantic_families':31,'mappings_partial':25,'old_diagnostic_mapping_appended_method_controls':21},'historical_language':{'selected':3518,'status_counts':pre['status_counts'],'source_artifact_stable':True,'source_binding':'recorded-build','candidate_sha256':pre['candidate']['sha256'],'order_fix_not_present':True,'metamorphic_passes':88,'two_old_trace_gaps_retired':statuschanges,'old_native_raw_unchanged':3427-len(rawchanges['rust']),'old_java_raw_unchanged':3427-len(rawchanges['java']),'cycle_changed_full_bytes_preserved':True,'remaining_legacy_mismatches':legacy,'new_mismatches':['read-stage38-uri-unpaired-surrogate',*internal],'legacy_sourcepath_PklBug_classification':'mismatch, preserved; distinct portable oracle-error classification unchanged'},'not_claimed':['Live corrected final3527 acquisition outcomes','Live final167persistent/42trace/workspace outcomes','Complete M2 language/API/platform/Host/performance compatibility'],'no_cargo_or_target_cache_walks':True,'compatibility_complete':False}
save('report.json',report);print(json.dumps({'source_groups':groups,'union':len(union),'corpus':3527,'historical_counts':pre['status_counts'],'native_changes':len(rawchanges['rust']),'java_changes':len(rawchanges['java'])}),flush=True)
