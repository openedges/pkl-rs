import difflib,hashlib,json,os,platform,shutil,subprocess,time
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'target/m2/stage38-core-order-validation-02'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value): (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
owned=['crates/pkl-runtime/src/diagnostic.rs','crates/pkl-runtime/src/vm.rs','crates/pkl-runtime/tests/m2_implicit_method_diagnostics.rs']
files=sorted(str(p.relative_to(ROOT)) for d in ['crates/pkl-runtime/src','crates/pkl-runtime/tests'] for p in (ROOT/d).rglob('*') if p.is_file())
before={p:sha(ROOT/p) for p in files};write('sources-before.json',before)
for p in files:
 dest=OUT/'sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,dest)
deltas={}
for p in owned:
 prior=ROOT/'target/m2/stage38-final-native-01/sources'/p
 if not prior.exists(): prior=ROOT/'target/m2/stage38-core-validation-04/sources'/p
 deltas[p]={'before_sha256':sha(prior),'after_sha256':sha(ROOT/p)}
 (OUT/(Path(p).name+'.patch')).write_text(''.join(difflib.unified_diff(prior.read_text().splitlines(True),(ROOT/p).read_text().splitlines(True),fromfile='pre-order-fix/'+p,tofile=p)))
write('owned-deltas.json',deltas)
commands=[('rustc',['rustc','-vV']),('cargo',['cargo','-vV']),('targeted-tests',['cargo','test','-p','pkl-runtime','--test','m2_implicit_method_diagnostics','--test','m2_default_resources','--test','m2_scalar_sequence','--locked']),('suggestion-tests',['cargo','test','-p','pkl-runtime','--lib','suggestion_tests','--locked']),('fmt',['cargo','fmt','--all','--','--check']),('clippy',['cargo','clippy','-p','pkl-runtime','--all-targets','--locked','--','-D','warnings'])]
env=dict(os.environ,CARGO_TARGET_DIR=str(ROOT/'target/m2/stage38-core-cargo'));runs=[]
for name,argv in commands:
 started=time.time_ns()
 with (OUT/(name+'.stdout.log')).open('wb') as out,(OUT/(name+'.stderr.log')).open('wb') as err: code=subprocess.run(argv,cwd=ROOT,env=env,stdout=out,stderr=err).returncode
 runs.append({'name':name,'argv':argv,'cwd':str(ROOT),'exit_code':code,'elapsed_ns':time.time_ns()-started,'stdout_sha256':sha(OUT/(name+'.stdout.log')),'stderr_sha256':sha(OUT/(name+'.stderr.log'))});write('commands.json',runs)
 if code: break
after={p:sha(ROOT/p) for p in files};write('sources-after.json',after)
report={'scope':'Narrow implicit method suggestion scope-order correction; earlier final65/edge7 artifacts remain pre-order-fix evidence. No Java acquisition or full-M2 compatibility claim.','host':platform.platform(),'commands':runs,'source_count':len(before),'source_stability':before==after,'owned_deltas':deltas,'upstream':{'path':'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/MemberLookupSuggestions.java','sha256':sha(ROOT/'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/MemberLookupSuggestions.java')},'passed':len(runs)==len(commands) and all(r['exit_code']==0 for r in runs) and before==after}
write('report.json',report);print(json.dumps({'passed':report['passed'],'report_sha256':sha(OUT/'report.json')}));raise SystemExit(0 if report['passed'] else 1)
