//! Ignored development adapter: preserve the original ModuleSource URI separately
//! from the physical source-copy path. No Host policy or diagnostic logic lives here.
use std::{
    fs,
    io::{self, Write},
    path::Path,
};
fn units(path: &Path, text: &str) {
    let bytes: Vec<u8> = text.encode_utf16().flat_map(u16::to_be_bytes).collect();
    fs::write(path, bytes).unwrap();
}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    assert_eq!(
        args.len(),
        6,
        "OUTPUT SOURCE MODULE_URI MODULE_NAME EXPRESSION"
    );
    let out = Path::new(&args[1]);
    let source = fs::read_to_string(&args[2]).unwrap();
    units(&out.join("value.code-units.bin"), "");
    units(&out.join("error.code-units.bin"), "");
    match pkl_runtime::evaluation::scalar_expression_with_options(
        &source,
        &args[3],
        &args[4],
        &args[5],
        pkl_runtime::evaluation::EvaluationOptions {
            power_assertions: false,
        },
    ) {
        Ok(value) => {
            fs::write(out.join("status.bin"), b"success\n").unwrap();
            units(&out.join("value.code-units.bin"), &value);
            io::stdout().write_all(value.as_bytes()).unwrap();
        }
        Err(error) => {
            fs::write(out.join("status.bin"), b"error\n").unwrap();
            units(&out.join("error.code-units.bin"), &error);
            io::stderr().write_all(error.as_bytes()).unwrap();
            std::process::exit(1);
        }
    }
}
