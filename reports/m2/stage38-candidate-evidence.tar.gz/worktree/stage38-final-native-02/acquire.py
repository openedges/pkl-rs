#!/usr/bin/env python3
"""Native raw differential acquisition of the unchanged original Java matrix.

No Java evaluation, URI rewriting, expected-result generation or policy shim.
All unsupported/parser/I/O/UTF16 cases stay in the same complete selection.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse,collections,hashlib,json,os,sys,shutil
ROOT=Path.cwd();HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'tools'));import benchmark
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes())
EXPECTED_CLOSURE='1effb34c18d1d7c96d094f377800eca99553572e4053a87cf25e8b8ede9917c8'
EXCLUDED={'target','node_modules','.cache','.git'}
def sources():
 paths={ROOT/p for p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml']}
 for directory,dirs,names in os.walk(ROOT/'crates',topdown=True):
  dirs[:]=sorted(d for d in dirs if d not in EXCLUDED)
  for name in names:
   p=Path(directory)/name
   if p.suffix in {'.rs','.pkl','.toml'}:paths.add(p)
 return {str(p.relative_to(ROOT)):sha(p) for p in sorted(paths)}
def original_matrix(origin):
 assert sha(origin/'closure.json')==EXPECTED_CLOSURE
 closure=rd(origin/'closure.json');contexts={};rows=[]
 for group in ['', 'additional-empty-profile', 'prior-exact-controls']:
  root=origin/group;report=rd(root/'report.json');relative=(group+'/' if group else '')+'report.json';assert sha(root/'report.json')==closure['files_sha256'][relative];assert sha(root/'manifest.json')==closure['files_sha256'][(group+'/' if group else '')+'manifest.json']
  for case in rd(root/'manifest.json'):
   d=root/'cases'/case['id'];source=(d/'input.pkl').read_bytes();assert source==case['source'].encode();assert sha(d/'input.pkl')==closure['files_sha256'][str((d/'input.pkl').relative_to(origin))]
   uri=case['module_uri'];name='m2-platform' if uri=='file:///m2-platform.pkl' else 'module';assert uri=='file:///m2-platform.pkl' or uri==(origin/'fixtures/base dir/modules/module.pkl').as_uri()
   captures=[]
   for repeat in [0,1]:
    rec=rd(d/str(repeat)/'record.json');assert rec['process']['status']=='executed'
    for channel,h in rec['channels_sha256'].items():assert sha(d/str(repeat)/channel)==h==closure['files_sha256'][str((d/str(repeat)/channel).relative_to(origin))]
    captures.append({'directory':str(d/str(repeat)),'record':rec})
   rows.append(dict(id=case['id'],source=case['source'],source_sha256=sha(d/'input.pkl'),module_uri=uri,module_name=name,expression=case['expression'],origin_group=group,captures=captures))
 assert len(rows)==65 and len({c['id'] for c in rows})==65
 return rows,closure

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);ap.add_argument('--target-dir',type=Path,default=ROOT/'target/m2/stage38-review-cargo');ap.add_argument('--oracle-root',type=Path,default=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage38-default-host-oracle-01'));args=ap.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);cache=args.target_dir.resolve();origin=args.oracle_root.resolve();matrix,closure=original_matrix(origin);before=sources();fixture_before={p:sha(origin/p) for p in rd(origin/'controlled-fixtures.json')};env=dict(os.environ,CARGO_TARGET_DIR=str(cache));commands=[]
 for rel,h in before.items():
  p=out/'sources'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/rel,p);assert sha(p)==h
 shutil.copyfile(HERE/'scalar_context_probe.rs',out/'scalar_context_probe.rs');shutil.copyfile(Path(__file__),out/'acquire.py');benchmark.write_json(out/'matrix.json',matrix)
 for name,cmd in [('rust-version',['rustc','-Vv']),('build',['cargo','build','-p','pkl-runtime','--release','--locked']),('adapter',['rustc','--edition=2024','-O','-C','lto=thin','-C','codegen-units=1',str(out/'scalar_context_probe.rs'),'--extern','pkl_runtime='+str(cache/'release/libpkl_runtime.rlib'),'-L','dependency='+str(cache/'release/deps'),'-o',str(out/'scalar_context_probe')])]:
  rec=benchmark.capture(cmd,ROOT,env,out/name,timeout=900);commands.append(dict(name=name,record=rec,source_hashes_after=sources()));benchmark.write_json(out/'commands.json',commands)
  if rec['status']!='executed' or rec['exit_code']!=0:raise RuntimeError(name+' failed; raw build output retained')
 binary=out/'scalar_context_probe';binary_sha=sha(binary)
 for c in matrix:
  d=out/'cases'/c['id'];d.mkdir(parents=True);(d/'input.pkl').write_bytes(c['source'].encode());benchmark.write_json(d/'context.json',{k:c[k] for k in ['module_uri','module_name','expression','source_sha256','origin_group']})
 def run(pair):
  c,n=pair;d=out/'cases'/c['id']/str(n);d.mkdir();raw=c['captures'][n];old=Path(raw['directory']);java=raw['record'];assert java['process']['exit_code'] in [0,1]
  rec=benchmark.capture([str(binary),str(d),str(d.parent/'input.pkl'),c['module_uri'],c['module_name'],c['expression']],ROOT,env,d/'native',timeout=90)
  # JVM class names remain exact provenance, not fabricated Rust class markers.
  raw_status=(old/'status.bin').read_bytes();(d/'java.status.bin').write_bytes(raw_status);category=b'success\n' if raw_status==b'success\n' else b'error\n' if raw_status==b'pkl-exception\torg.pkl.core.PklException\n' else None
  oracle_valid=category is not None and java['process']['status']=='executed';comparisons=[]
  expected={'stdout.bin':benchmark.raw_channel(java['process'],'stdout'),'stderr.bin':benchmark.raw_channel(java['process'],'stderr'),'value.code-units.bin':(old/'value.code-units.bin').read_bytes(),'error.code-units.bin':(old/'error.code-units.bin').read_bytes()}
  for channel,data in expected.items():
   (d/('java.'+channel)).write_bytes(data);actual=benchmark.raw_channel(rec,channel[:-4]) if channel in ['stdout.bin','stderr.bin'] else (d/channel).read_bytes() if (d/channel).exists() else None
   if channel in ['stdout.bin','stderr.bin']:(d/('native.'+channel)).write_bytes(actual)
   comparisons.append(dict(channel=channel,expected_sha256=hashlib.sha256(data).hexdigest(),actual_sha256=hashlib.sha256(actual).hexdigest() if actual is not None else None,raw_equal=data==actual))
  native_status=(d/'status.bin').read_bytes() if (d/'status.bin').exists() else None;admitted=rec['status']=='executed' and rec['exit_code'] in [0,1] and native_status in [b'success\n',b'error\n'];match=oracle_valid and admitted and rec['exit_code']==java['process']['exit_code'] and native_status==category and all(x['raw_equal'] for x in comparisons);status='oracle-error' if not oracle_valid else 'acquisition-failed' if not admitted else 'pass' if match else 'mismatch';row=dict(id=c['id'],repeat=n,status=status,native=rec,java=java['process'],java_status_sha256=sha(d/'java.status.bin'),native_status_sha256=sha(d/'status.bin') if native_status is not None else None,status_category_match=native_status==category,comparisons=comparisons);benchmark.write_json(d/'comparison.json',row);return row
 with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,[(c,n) for c in matrix for n in [0,1]]))
 after=sources();fixture_after={p:sha(origin/p) for p in fixture_before};report=dict(scope='Original65 Java matrix native comparison including all unsupported cases; no Java rerun, I/O shim, URI rewriting or JVM class-equivalence claim.',case_count=65,repetitions=2,results=results,status_counts=dict(collections.Counter(r['status'] for r in results)),original_closure_sha256=EXPECTED_CLOSURE,source_hashes_before=before,source_hashes_after=after,source_stability=before==after and all(c['source_hashes_after']==before for c in commands),binary_sha256=binary_sha,binary_stability=sha(binary)==binary_sha,controlled_fixture_hashes_before=fixture_before,controlled_fixture_hashes_after=fixture_after,controlled_fixture_stability=fixture_before==fixture_after,commands=commands,excluded_before_traversal=[str(cache),'target','node_modules','.cache','.git'])
 benchmark.write_json(out/'report.json',report);print(json.dumps({k:v for k,v in report.items() if k in ['case_count','status_counts','source_stability','binary_stability','controlled_fixture_stability']},indent=2));return int(not report['source_stability'] or not report['binary_stability'] or not report['controlled_fixture_stability'] or any(r['status']!='pass' for r in results))
if __name__=='__main__':raise SystemExit(main())
