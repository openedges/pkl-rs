import java.net.URI;
import org.pkl.core.util.IoUtils;
class UriProbe {
  public static void main(String[] args) {
    for (String value : args) {
      try {
        URI uri = IoUtils.toUri(value);
        URI resolved = IoUtils.resolve(URI.create("file:///fixture/modules/input.pkl"), uri);
        System.out.println(value + "\t" + uri + "\t" + resolved.normalize());
      } catch (Exception e) { System.out.println(value + "\t" + e.getClass().getName() + "\t" + e.getMessage()); }
    }
  }
}
