"""Append nine original Java-observed diagnostic-order contracts."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[3]
out = root / 'target/m2/stage38-corpus-addition-04'
out.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
selection = root / 'tests/fixtures/m2/cases.json'
mapping_path = root / 'compatibility/m2-mappings.json'
(out / 'prior-cases.json').write_bytes(selection.read_bytes())
(out / 'prior-mappings.json').write_bytes(mapping_path.read_bytes())
document = json.loads(selection.read_text())
prior = document['cases']
assert len(prior) == 3518
old_hashes = {row['input']: sha(root / row['input']) for row in prior}
new, origins = [], []
for number in ['01', '02']:
    origin = root / ('target/m2/stage38-method-order-oracle-' + number)
    manifest = json.loads((origin / 'manifest.json').read_text())
    observed = json.loads((origin / 'report.json').read_text())
    results = {row['id']: row for row in observed['results']}
    assert observed['cases'] == manifest
    for case in manifest:
        result = results[case['id']]
        assert result['process']['exit_code'] == 1
        assert result['status'] == 'pkl-exception\torg.pkl.core.PklException\n'
        source = case['source'].encode()
        original = origin / 'cases' / case['id'] / 'input.pkl'
        assert original.read_bytes() == source
        for channel in ['stdout', 'stderr']:
            captured = result['process'][channel]
            assert sha(Path(captured['path'])) == captured['sha256']
        identifier = 'method-stage38-order-' + case['id']
        relative = 'tests/fixtures/m2/' + identifier + '.pkl'
        path = root / relative
        assert not path.exists()
        path.write_bytes(source)
        new.append(dict(expected_outcome='failure', expression=case['expression'],
                        id=identifier, input=relative,
                        requirements=['semantic:functions', 'semantic:name-resolution',
                                      'semantic:diagnostics', 'semantic:shared-engine']))
        origins.append(dict(id=identifier, origin_id=case['id'], source_sha256=sha(path),
                            manifest=str(origin / 'manifest.json'), manifest_sha256=sha(origin / 'manifest.json'),
                            report=str(origin / 'report.json'), report_sha256=sha(origin / 'report.json'),
                            original_uri=case['uri'], source_bytes_unchanged=True,
                            comparison_boundary='Fresh standard source-path Java capture is required; fixed URI bytes are retained separately.'))
assert len(new) == 9
document['cases'] = prior + new
assert len({row['id'] for row in document['cases']}) == 3527
selection.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
mapping = json.loads(mapping_path.read_text())
diagnostics = next(row for row in mapping['requirements'] if row['requirement'] == 'semantic:diagnostics')
diagnostics['tests']['case_ids'] += [row['id'] for row in new]
diagnostics['scope'] += ' Stage38 additionally checks lexical candidate ordering across property/method and scope boundaries, stable similarity/arity ranking, and explicit-receiver contrast against nine fresh Java observations.'
mapping_path.write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + '\n')
assert all(sha(root / name) == digest for name, digest in old_hashes.items())
assert json.loads(selection.read_text())['cases'][:3518] == prior
report = dict(scope='Add Java-observed generic suggestion ordering; preserve every existing definition and source.',
              prior_cases=3518, new_cases=9, selected_cases=3527,
              existing_definitions_order_input_bytes_unchanged=True, origins=origins,
              helper_sha256=sha(Path(__file__)), cases_sha256=sha(selection), mappings_sha256=sha(mapping_path))
(out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: value for key, value in report.items() if key != 'origins'}), flush=True)
