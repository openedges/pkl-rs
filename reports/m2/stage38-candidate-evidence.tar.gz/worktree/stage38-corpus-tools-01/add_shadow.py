"""Append unchanged read-shadow and power-assertion controls from Java captures."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'target/m2/stage38-corpus-addition-02'
OUT.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

selection = ROOT / 'tests/fixtures/m2/cases.json'
document = read(selection)
prior = document['cases']
assert len(prior) == 3498
before = selection.read_bytes()
(OUT / 'prior-cases.json').write_bytes(before)
prior_hashes = {row['input']: sha(ROOT / row['input']) for row in prior}
new = []
origins = []
read_token = 'language_token:pkl-parser/src/main/java/org/pkl/parser/Token.java:READ'
nullable_token = 'language_token:pkl-parser/src/main/java/org/pkl/parser/Token.java:READ_QUESTION'
nullable_spec = 'specification:docs/modules/language-reference/pages/index.adoc:Nullable Reads'
for folder, power in [('stage38-read-shadow-oracle-01', False), ('stage38-read-power-oracle-01', True)]:
    origin = ROOT / 'target/m2' / folder
    manifest = read(origin / 'manifest.json')
    report = read(origin / 'report.json')
    outcomes = {x['id']: x['process']['exit_code'] for x in report['results']}
    for case in manifest:
        if case['id'] == 'keyword-with-quoted-shadow':
            old = next(x for x in prior if x['id'] == 'read-stage38-frontend-keyword-with-quoted-shadow')
            assert (ROOT / old['input']).read_text() == case['source']
            continue
        identifier = 'read-stage38-' + ('power-' if power else 'shadow-') + case['id']
        name = 'tests/fixtures/m2/' + identifier + '.pkl'
        path = ROOT / name
        assert not path.exists()
        source = case['source'].encode()
        assert (origin / 'cases' / case['id'] / 'input.pkl').read_bytes() == source
        assert outcomes[case['id']] in (0, 1)
        path.write_bytes(source)
        requirements = [read_token, 'semantic:operators', 'semantic:diagnostics', 'semantic:shared-engine']
        if 'read?' in case['source']:
            requirements += [nullable_token, nullable_spec]
        if power:
            requirements.append('semantic:constraints')
        row = {'expected_outcome': 'success' if outcomes[case['id']] == 0 else 'error',
               'expression': case['expression'], 'id': identifier, 'input': name,
               'requirements': requirements}
        if power:
            row['power_assertions'] = True
        new.append(row)
        origins.append({'id': identifier, 'origin_id': case['id'],
                        'manifest': str(origin / 'manifest.json'), 'manifest_sha256': sha(origin / 'manifest.json'),
                        'report': str(origin / 'report.json'), 'report_sha256': sha(origin / 'report.json'),
                        'source_sha256': hashlib.sha256(source).hexdigest(), 'source_bytes_unchanged': True,
                        'original_uri': case['uri'], 'power_assertions': power,
                        'new_boundary': 'Fresh source-path Java acquisition; original fixed-URI diagnostic bytes are not reused.'})
document['cases'] = prior + new
assert len({x['id'] for x in document['cases']}) == len(document['cases'])
selection.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
assert read(selection)['cases'][:len(prior)] == prior
assert all(sha(ROOT / name) == expected for name, expected in prior_hashes.items())
mapping_path = ROOT / 'compatibility/m2-mappings.json'
(OUT / 'prior-mappings.json').write_bytes(mapping_path.read_bytes())
mapping = read(mapping_path)
for row in mapping['requirements']:
    if row['requirement'] in [read_token, nullable_token, nullable_spec]:
        row['tests']['case_ids'] += [x['id'] for x in new if row['requirement'] in x['requirements']]
mapping_path.write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + '\n')
report = {'scope': 'Additional Java-observed keyword shadow, missing quoted methods and power assertion controls.',
          'prior_cases': len(prior), 'added_cases': len(new), 'selected_cases': len(prior) + len(new),
          'prior_definitions_order_and_input_bytes_unchanged': True, 'origins': origins,
          'helper_sha256': sha(Path(__file__))}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'origins'}), flush=True)
