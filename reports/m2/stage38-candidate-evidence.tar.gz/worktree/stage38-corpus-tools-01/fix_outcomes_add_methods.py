"""Correct manifest outcome spelling and append original generic-method controls."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'target/m2/stage38-corpus-addition-03'
OUT.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

selection = ROOT / 'tests/fixtures/m2/cases.json'
before = selection.read_bytes()
(OUT / 'prior-cases.json').write_bytes(before)
document = json.loads(before)
prior = document['cases']
assert len(prior) == 3506
baseline = read(ROOT.with_name('pkl-rs') / 'tests/fixtures/m2/cases.json')['cases']
assert prior[:3427] == baseline
hashes = {x['input']: sha(ROOT / x['input']) for x in prior}
corrections = []
for row in prior[3427:]:
    if row['expected_outcome'] == 'error':
        row['expected_outcome'] = 'failure'
        corrections.append(row['id'])
    assert row['expected_outcome'] in ('success', 'failure')

origin = ROOT / 'target/m2/stage38-method-diagnostic-oracle-01'
manifest = read(origin / 'manifest.json')
oracle_report = read(origin / 'report.json')
outcomes = {x['id']: x['process']['exit_code'] for x in oracle_report['results']}
new = []
origins = []
for case in manifest:
    identifier = 'method-stage38-' + case['id']
    name = 'tests/fixtures/m2/' + identifier + '.pkl'
    path = ROOT / name
    assert not path.exists()
    source = case['source'].encode()
    assert (origin / 'cases' / case['id'] / 'input.pkl').read_bytes() == source
    assert outcomes[case['id']] == 1
    path.write_bytes(source)
    new.append({'expected_outcome': 'failure', 'expression': case['expression'],
                'id': identifier, 'input': name,
                'requirements': ['semantic:functions', 'semantic:name-resolution',
                                 'semantic:diagnostics', 'semantic:shared-engine']})
    origins.append({'id': identifier, 'origin_id': case['id'],
                    'manifest': str(origin / 'manifest.json'), 'manifest_sha256': sha(origin / 'manifest.json'),
                    'report': str(origin / 'report.json'), 'report_sha256': sha(origin / 'report.json'),
                    'source_sha256': hashlib.sha256(source).hexdigest(), 'source_bytes_unchanged': True,
                    'original_uri': case['uri'],
                    'new_boundary': 'Fresh standard source-path Java acquisition required; no diagnostic normalization.'})
assert len(new) == 12
document['cases'] = prior + new
assert len({x['id'] for x in document['cases']}) == len(document['cases'])
selection.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
assert read(selection)['cases'][:3427] == baseline
assert all(sha(ROOT / name) == expected for name, expected in hashes.items())

mapping_path = ROOT / 'compatibility/m2-mappings.json'
(OUT / 'prior-mappings.json').write_bytes(mapping_path.read_bytes())
mapping = read(mapping_path)
diagnostics = next(x for x in mapping['requirements'] if x['requirement'] == 'semantic:diagnostics')
diagnostics['tests']['case_ids'] += [x['id'] for x in new]
diagnostics['scope'] += ' Stage38 adds original generic implicit/explicit missing-method, suggestions, call-span and argument-order controls; failures remain visible until differential verification.'
mapping_path.write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + '\n')
report = {'scope': 'Correct invalid error label to schema-defined failure; previous manifest failure and Java-only captures are retained. Add12Java-observed generic method diagnostics.',
          'prior_cases': len(prior), 'new_cases': len(new), 'selected_cases': len(document['cases']),
          'original3427_definitions_order_input_bytes_unchanged': True,
          'all_existing_input_bytes_unchanged': True,
          'outcome_label_corrections': corrections, 'origins': origins,
          'helper_sha256': sha(Path(__file__))}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ('origins','outcome_label_corrections')}), flush=True)
