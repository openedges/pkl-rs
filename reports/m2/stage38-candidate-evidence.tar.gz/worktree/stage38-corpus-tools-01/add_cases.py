"""Add Java-observed read controls while preserving every prior corpus definition."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
MAIN = ROOT.with_name('pkl-rs')
OUT = ROOT / 'target/m2/stage38-corpus-addition-01'
OUT.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

selection = ROOT / 'tests/fixtures/m2/cases.json'
prior_bytes = selection.read_bytes()
(OUT / 'prior-cases.json').write_bytes(prior_bytes)
document = json.loads(prior_bytes)
prior = document['cases']
assert len(prior) == 3427
prior_hashes = {row['input']: sha(ROOT / row['input']) for row in prior}
new = []
origins = []
excluded = []
read_token = 'language_token:pkl-parser/src/main/java/org/pkl/parser/Token.java:READ'
nullable_token = 'language_token:pkl-parser/src/main/java/org/pkl/parser/Token.java:READ_QUESTION'
nullable_spec = 'specification:docs/modules/language-reference/pages/index.adoc:Nullable Reads'
inputs = [
    ('', MAIN / 'target/m2/stage38-default-host-oracle-01'),
    ('profile-', MAIN / 'target/m2/stage38-default-host-oracle-01/additional-empty-profile'),
    ('edge-', ROOT / 'target/m2/stage38-review-uri-edges-01'),
    ('frontend-', ROOT / 'target/m2/stage38-read-frontend-oracle-01'),
]
for prefix, source_root in inputs:
    manifest_path = source_root / 'manifest.json'
    report_path = source_root / 'report.json'
    manifest = read(manifest_path)
    report = read(report_path)
    outcomes = {}
    for result in report['results']:
        code = result['process']['exit_code']
        assert code in (0, 1), result['id']
        expected = 'success' if code == 0 else 'error'
        if result['id'] in outcomes:
            assert outcomes[result['id']] == expected
        outcomes[result['id']] = expected
    for case in manifest:
        # These original fixed-URI contracts remain in the complete independent
        # matrix. They need their controlled filesystem, not a relocated corpus
        # source with different path semantics. No original capture is removed.
        if case['id'].startswith('file-'):
            excluded.append({'origin': str(manifest_path), 'id': case['id'],
                             'reason': 'Retained in complete original fixed-URI/filesystem matrix; not relocated to the ordinary source-path adapter.'})
            continue
        identifier = 'read-stage38-' + prefix + case['id']
        name = 'tests/fixtures/m2/' + identifier + '.pkl'
        path = ROOT / name
        assert not path.exists(), path
        source = case['source'].encode()
        # Preserve authored source bytes. Standard language acquisitions use
        # their recorded source-path URI, distinct from original fixed-URI runs.
        original = source_root / 'cases' / case['id'] / 'input.pkl'
        assert original.read_bytes() == source, original
        path.write_bytes(source)
        requirements = [read_token, 'semantic:operators', 'semantic:diagnostics', 'semantic:shared-engine']
        if 'read?' in case['source']:
            requirements += [nullable_token, nullable_spec]
        if 'trace(' in case['source']:
            requirements.append('semantic:tracing')
        if 'surrogate' in case['id']:
            requirements.append('semantic:strings')
        new.append({'expected_outcome': outcomes[case['id']],
                    'expression': case['expression'], 'id': identifier,
                    'input': name, 'requirements': requirements})
        origins.append({'id': identifier, 'origin_id': case['id'],
                        'manifest': str(manifest_path), 'manifest_sha256': sha(manifest_path),
                        'report': str(report_path), 'report_sha256': sha(report_path),
                        'source_sha256': hashlib.sha256(source).hexdigest(),
                        'source_bytes_unchanged': True,
                        'original_uri': case.get('module_uri', case.get('uri')),
                        'new_boundary': 'Fresh standard language source-path acquisition required; original fixed-URI captures are not reused as expected diagnostic bytes.'})

ids = [x['id'] for x in prior + new]
assert len(ids) == len(set(ids))
document['cases'] = prior + new
selection.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
assert read(selection)['cases'][:len(prior)] == prior
assert all(sha(ROOT / name) == expected for name, expected in prior_hashes.items())

mapping_path = ROOT / 'compatibility/m2-mappings.json'
old_mapping = mapping_path.read_bytes()
(OUT / 'prior-mappings.json').write_bytes(old_mapping)
mapping = json.loads(old_mapping)
links = [
    {'path': 'crates/pkl-runtime/src/parser.rs', 'symbol': 'ReadResource'},
    {'path': 'crates/pkl-runtime/src/vm/compiler_expressions.rs', 'symbol': 'ReadResourceOrNull'},
    {'path': 'crates/pkl-runtime/src/host/resources.rs', 'symbol': 'default_result'},
]
for requirement in [read_token, nullable_token, nullable_spec]:
    assert not any(x['requirement'] == requirement for x in mapping['requirements'])
    case_ids = [x['id'] for x in new if requirement in x['requirements']]
    mapping['requirements'].append({
        'requirement': requirement,
        'implementation': {'state': 'partial', 'links': links},
        'tests': {'state': 'partial', 'case_ids': case_ids},
        'scope': 'Stage38 authored read/read? keyword and operand parsing, empty env/property profile, URI validation/normalization and raw diagnostic controls. Cases preserve Java-observed failures, including surrogate and internal-error boundaries; final differential acquisition is required.',
        'remaining': ['Complete resource readers, configured policy, loader/cache and Host absence transport remain open.',
                      'Complete URI and lossless UTF-16 diagnostic behavior, original upstream suites and all parser/error contexts remain unverified.'],
    })
mapping_path.write_text(json.dumps(mapping, ensure_ascii=False, indent=2) + '\n')
report = {'scope': 'Additive Stage38 standard source-path corpus. Original fixed-URI matrices remain complete independent contracts.',
          'prior_cases': len(prior), 'new_cases': len(new), 'selected_cases': len(prior) + len(new),
          'prior_definitions_order_and_input_bytes_unchanged': True,
          'prior_selection_sha256': hashlib.sha256(prior_bytes).hexdigest(),
          'new_selection_sha256': sha(selection), 'origins': origins,
          'not_relocated_original_contracts': excluded,
          'new_requirement_families': 0, 'added_partial_mappings': 3,
          'helper_sha256': sha(Path(__file__))}
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ('origins', 'not_relocated_original_contracts')}), flush=True)
