"""Fresh standard source-path Java outcomes for every added Stage38 corpus case."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import m2_language as language
import oracle

OUT = ROOT / 'target/m2/stage38-corpus-java-01'
OUT.mkdir(exist_ok=False)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

metadata = oracle.ensure_oracle(ROOT, fetch=False)
save(OUT / 'oracle.json', metadata)
manifest = json.loads((ROOT / 'tests/fixtures/m2/cases.json').read_text())
cases = [row for row in manifest['cases'] if row['id'].startswith('read-stage38-')]
assert len(cases) == 79
save(OUT / 'selected.json', cases)
source_names = ['tools/java/M2LanguageProbe.java', 'tools/m2_language.py', 'tools/oracle.py',
                'oracle.lock.json', 'references.lock', 'tests/fixtures/m2/cases.json',
                str(Path(__file__).relative_to(ROOT))] + [row['input'] for row in cases]
sources = {}
for name in source_names:
    path = ROOT / name
    destination = OUT / 'sources' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(path.read_bytes())
    sources[name] = sha(destination)
classes = OUT / 'artifacts/java'
classes.mkdir(parents=True)
javac = language.capture([str(Path(metadata['java']).with_name('javac')), '-encoding', 'UTF-8',
                          '-cp', metadata['artifact'], '-d', str(classes),
                          str(ROOT / 'tools/java/M2LanguageProbe.java')], OUT, 'javac', metadata['environment'])
assert javac['exit_code'] == 0

def acquire(case):
    directory = OUT / 'cases' / case['id']
    directory.mkdir(parents=True)
    source = ROOT / case['input']
    (directory / 'input.pkl').write_bytes(source.read_bytes())
    process = language.capture_java(metadata, OUT / 'artifacts/language_probe', case['id'],
                                    source, case['expression'], directory,
                                    case.get('power_assertions', False))
    assert not process['timed_out']
    expected = 0 if case['expected_outcome'] == 'success' else 1
    outcome = (directory / 'java.outcome.bin').read_bytes()
    return {'id': case['id'], 'expected_outcome': case['expected_outcome'],
            'process': process, 'outcome': outcome.decode(),
            'expected_exit_observed': process['exit_code'] == expected}

with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(acquire, cases))
stable = all(sha(ROOT / name) == digest for name, digest in sources.items())
report = {'scope': 'Java-only source-path controls for all79new selected Stage38 cases; fixed-URI original matrices remain independent.',
          'cases': cases, 'results': results, 'sources': sources, 'source_stability': stable,
          'rust_executed': False, 'oracle': metadata, 'javac': javac,
          'all_expected_exits_observed': all(x['expected_exit_observed'] for x in results),
          'files': {str(p.relative_to(OUT)): sha(p) for p in sorted(OUT.rglob('*')) if p.is_file()}}
save(OUT / 'report.json', report)
assert stable and report['all_expected_exits_observed']
print(json.dumps({'cases': len(cases), 'source_stability': stable,
                  'expected_exits_observed': report['all_expected_exits_observed'],
                  'java_internal_errors': [x['id'] for x in results if 'PklBugException' in x['outcome']]}), flush=True)
