from pathlib import Path
import json,hashlib,copy
R=Path.cwd();O=R/'target/m2/stage38-method-order-platform-generation-01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
module=R/'tools/platform/method-order-cases.mjs';assert not module.exists()
text=(R/'tools/platform/read-cases.mjs').read_text();base,_=json.JSONDecoder().raw_decode(text.split('export const context =',1)[1].lstrip());context=copy.deepcopy(base);context.update(uri='file:///stage38-read-frontend.pkl',moduleName='stage38-read-frontend',powerAssertions=False);context['oracle']['acquisitions']=[];cases=[];origins=[]
for group in ('stage38-method-order-oracle-01','stage38-method-order-oracle-02'):
 root=R/'target/m2'/group;manifest=json.loads((root/'manifest.json').read_text());report=json.loads((root/'report.json').read_text());closure=json.loads((root/'closure.json').read_text())
 assert all(sha(root/n)==v['sha256'] for n,v in closure['files'].items())
 context['oracle']['acquisitions'].append({'reportPath':str((root/'report.json').relative_to(R)),'reportSha256':sha(root/'report.json'),'manifestPath':str((root/'manifest.json').relative_to(R)),'manifestSha256':sha(root/'manifest.json'),'cases':len(manifest)})
 for c in manifest:
  path=root/'cases'/c['id'];j=path/'java';r=next(x for x in report['results'] if x['id']==c['id']);assert r['status']=='pkl-exception\torg.pkl.core.PklException\n' and r['process']['exit_code']==1
  source=(path/'input.pkl').read_bytes();assert source==c['source'].encode() and c['uri']==context['uri'] and c['expression']=='result'
  error=(j/'process/stderr.bin').read_bytes();units=(j/'error.code-units.bin').read_bytes();assert (j/'process/stdout.bin').read_bytes()==b''
  row={'id':'method-stage38-order-'+c['id'],'source':c['source'],'sourceSha256':sha(path/'input.pkl'),'expression':c['expression'],'powerAssertions':False,'oracleCasePath':str(path.relative_to(R)),'oracleClassification':'language-error','oracleStatus':r['status'],'captureSha256':{'stdout':sha(j/'process/stdout.bin'),'stderr':sha(j/'process/stderr.bin'),'status':sha(j/'status.bin'),'payloadCodeUnits':sha(j/'error.code-units.bin')},'expectedError':error.decode('utf8'),'expectedCodeUnitsHex':units.hex(),'oracleError':False}
  cases.append(row);origins.append({'id':row['id'],'origin_id':c['id'],'manifest':str((root/'manifest.json').relative_to(R)),'source_sha256':row['sourceSha256'],'module_uri':c['uri'],'classification':row['oracleClassification']})
(O/'fixed-payloads.json').write_text(json.dumps(cases,indent=2,ensure_ascii=True)+'\n');(O/'context.json').write_text(json.dumps(context,indent=2)+'\n')
module.write_text('// Original fixed-URI pinned Java method-suggestion errors and UTF16 units.\n// Generated from closed oracle captures; original Java UTF8 remains separate from JS string encoding.\nexport const context = '+json.dumps(context,indent=2,ensure_ascii=True)+';\n\nexport const cases = '+json.dumps(cases,indent=2,ensure_ascii=True)+';\n')
report={'status':'generated','scope':'Nine exact original Java fixed-URI method-order controls. No Rust-derived expected values, diagnostic URI rewriting or normalization. Regular corpus source-path Java acquisition is a separate boundary.','case_count':len(cases),'context':context,'origins':origins,'payload_path':str((O/'fixed-payloads.json').relative_to(R)),'payload_sha256':sha(O/'fixed-payloads.json'),'module_path':str(module.relative_to(R)),'module_sha256':sha(module),'generator_sha256':sha(Path(__file__))}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'cases':len(cases),'module_sha256':sha(module),'ids':[c['id'] for c in cases]}))
