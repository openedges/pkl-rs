from pathlib import Path
import json,hashlib,sys
R=Path.cwd();O=R/'target/m2/stage38-platform-review-final-03';sys.path.insert(0,str(R/'tools'));import benchmark,m1_platforms
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rd=lambda p:json.loads(p.read_bytes());B=R/'target/m2/stage38-platforms-final-03';build=rd(B/'report.json');assert build['source_stability'] and build['total']==build['shared_engine_passed']==6078 and build['oracle_passed']==dict(rust=6076,node=6076,browser=6076);assert build['experiment_contract_status']=='pass' and build['compatibility_status']=='fail';m1_platforms.check_scenarios(build['execution'])
for p,h in build['source_hashes'].items():assert sha(R/p)==sha(B/'sources'/p)==h
for p,h in build['artifacts'].items():assert sha(B/p)==h
captures={'java':(B/'oracle-native/java.stdout.bin').read_bytes(),'rust':(B/'oracle-native/rust.stdout.bin').read_bytes(),'node':(B/'execution/node.stdout.bin').read_bytes(),'browser':(B/'execution/browser.stdout.bin').read_bytes()};assert m1_platforms.compare(m1_platforms.generate_cases()['cases'],captures)==build['comparisons']
A=R/'target/m2/stage38-core-order-validation-02/freeze.json';assert sha(A)=='b7462d88f39f5c750e50eff7b9daadd0be925276d033dfcaf34dd03faa5af021'
for p,h in rd(A)['sources'].items():
 assert sha(R/p)==h
 if p in build['source_hashes']:assert build['source_hashes'][p]==h
M=R/'compatibility/m2-language.json';manifest=rd(M);assert manifest['counts']['cases_by_execution']==dict(ready=3527,unimplemented=960,unmapped=40);prior=rd(R/'target/m2/stage38-manifest-freeze-01/prior-manifest.json');priorids={c['id'] for c in prior['cases']};assert [c for c in manifest['cases'] if c['id'] in priorids]==prior['cases'];new=[c for c in manifest['cases'] if c['id'] not in priorids];assert len(new)==9
process=rd(R/'target/m2/stage38-portable-processes-final-03/report.json');assert process['artifact_stability'] and process['source_stability'] and process['manifest_stability'];assert process['artifacts_before']==process['artifacts_after']==build['artifacts'];assert sha(M)==process['manifest_sha256_before']==process['manifest_sha256_after'];assert [c['record']['exit_code'] for c in process['commands']]==[1,0,0,1,1]
for c in process['commands']:
 assert c['record']['status']=='executed'
 for ch in ['stdout','stderr']:benchmark.raw_channel(c['record'],ch)
def node_utf8(units):
 text=units.decode('utf-16-be','surrogatepass');return ''.join('\ufffd' if 0xd800<=ord(c)<=0xdfff else c for c in text).encode('utf-8')
summary={};channels=0;divergent=[];method_bindings=[]
for name,count,expected in [('read91',91,(87,1,3)),('method-order9',9,(9,0,0)),('trace18',18,(18,0,0)),('repeat20',20,(18,2,0))]:
 D=R/'target/m2'/f'stage38-{name}-platform-final-03';r=rd(D/'execution.json');fixture=rd(D/'fixtures.json');assert r['caseCount']==count and not r['infrastructureErrors'] and not r['browserErrors'] and not r['stability']['changed'];assert r['playwright']==r['playwrightCore']==r['playwrightPin']=='1.64.1' and r['browser']=='156.0.8078.4'
 for p,h in r['artifactHashes'].items():assert sha(R/p)==h
 assert r['artifactHashes'][str((B/'pkl_napi.node').relative_to(R))]==build['artifacts']['pkl_napi.node'];assert r['artifactHashes'][str((B/'wasm/pkl_wasm_bg.wasm').relative_to(R))]==build['artifacts']['wasm/pkl_wasm_bg.wasm']
 for case in fixture['cases']:assert sha(R/'tests/fixtures/m2'/f"{case['id']}.pkl")==case['sourceSha256']
 if name=='read91':
  assert fixture['cases']==rd(R/'target/m2/stage38-platform-oracle-01/fixed-payloads.json');assert sha(R/'target/m2/stage38-platform-oracle-01/closure.json')=='0da1620b65bc3e44d83725a752a75605adca6dcdda343fba62b528e12870ccc8'
 if name=='method-order9':
  assert sha(R/'tools/platform/method-order-cases.mjs')=='88f5861a3c2206c20244affae641c8f1527ea1273977b3d39a439c96d5360807';ctx=fixture['context'];assert (ctx['uri'],ctx['moduleName'],ctx['powerAssertions'])==('file:///stage38-read-frontend.pkl','stage38-read-frontend',False);payload=ctx['oracle']['generatedPayload'];assert sha(R/payload['path'])==payload['sha256'];assert fixture['cases']==rd(R/payload['path']);assert {c['id'] for c in fixture['cases']}=={c['id'] for c in new}
  for origin in ctx['oracle']['acquisitions']:assert sha(R/origin['reportPath'])==origin['reportSha256'] and sha(R/origin['manifestPath'])==origin['manifestSha256']
  for case in fixture['cases']:
   origin=R/case['oracleCasePath'];java=origin/'java';record=rd(java/'process/result.json');assert record['status']=='executed' and record['exit_code']==1;assert (origin/'input.pkl').read_bytes()==case['source'].encode();assert sha(origin/'input.pkl')==case['sourceSha256'];assert (java/'module-uri.bin').read_bytes()==ctx['uri'].encode();assert (java/'status.bin').read_bytes()==b'pkl-exception\torg.pkl.core.PklException\n';assert benchmark.raw_channel(record,'stderr')==case['expectedError'].encode();assert not benchmark.raw_channel(record,'stdout');assert (java/'error.code-units.bin').read_bytes().hex()==case['expectedCodeUnitsHex'];assert sha(java/'status.bin')==case['captureSha256']['status'] and sha(java/'error.code-units.bin')==case['captureSha256']['payloadCodeUnits'];method_bindings.append(dict(id=case['id'],originalCasePath=case['oracleCasePath'],sourceSha256=case['sourceSha256']))
 for target,t in r['targets'].items():
  assert t['complete'] and len(t['results'])==count*2;assert (t['passingCases'],t['mismatchingCases'],t['oracleErrorCases'])==expected;seen=set()
  for row in t['results']:
   pair=(row['id'],row['repetition']);assert pair not in seen;seen.add(pair);case=next(x for x in fixture['cases'] if x['id']==row['id']);assert row['powerAssertions']==case.get('powerAssertions',fixture['context']['powerAssertions']);e=D/row['expectedFile'];a=D/row['actualFile'];assert sha(e)==row['expectedSha256']==row['originalJavaUtf8Sha256'];assert sha(a)==row['actualSha256'];assert row['originalJavaUtf8File']==row['expectedFile'];assert e.read_bytes()==case.get('expectedValue',case.get('expectedError')).encode();original_equal=e.read_bytes()==a.read_bytes();assert original_equal==row['originalJavaUtf8Match']==row['utf8Match'];channels+=2;units_equal=True;node_expected=e.read_bytes()
   if 'expectedCodeUnitsHex' in case:
    assert row['comparisonBoundary']=='js-string-api';eu=D/row['expectedCodeUnitsFile'];au=D/row['actualCodeUnitsFile'];ne=D/row['expectedNodeUtf8File'];assert sha(eu)==row['expectedCodeUnitsSha256'] and sha(au)==row['actualCodeUnitsSha256'];assert eu.read_bytes().hex()==case['expectedCodeUnitsHex'];assert node_utf8(eu.read_bytes())==ne.read_bytes();assert sha(ne)==row['expectedNodeUtf8Sha256'];assert node_utf8(au.read_bytes())==a.read_bytes();units_equal=eu.read_bytes()==au.read_bytes();assert units_equal==row['codeUnitsMatch'];node_expected=ne.read_bytes();channels+=3
   else:assert row['comparisonBoundary']=='raw-utf8' and row['expectedNodeUtf8File'] is None and row['codeUnitsMatch'] is None
   assert (node_expected==a.read_bytes())==row['nodeUtf8Match'];divergence=e.read_bytes()!=node_expected;assert divergence==row['javaVsNodeSerializationDivergence'];match=row['actualStatus']==row['expectedStatus'] and row['nodeUtf8Match'] and units_equal;assert match==row['rawMatch'];assert row['status']==('oracle-error' if case.get('oracleError') else 'pass' if match else 'mismatch')
   if divergence:divergent.append(dict(target=target,id=row['id'],repeat=row['repetition'],status=row['status']))
  assert t['passingExecutions']==sum(x['status']=='pass' for x in t['results']);assert not any(x['status']=='pass' and x['oracleError'] for x in t['results'])
  if name=='read91':assert t['mismatchIds']==['read-stage38-uri-unpaired-surrogate'];assert len([x for x in t['results'] if x['powerAssertions'] and x['status']=='pass'])==4
 summary[name]={k:{p:v[p] for p in ['passingCases','mismatchingCases','oracleErrorCases','executions']} for k,v in r['targets'].items()}
assert len(divergent)==4
D=R/'target/m2/stage38-trace42-platform-final-03';r=rd(D/'execution.json');assert r['selectedCases']==42 and r['architecturePassed'] and not r['compatibilityComplete'];assert not r['infrastructureErrors'] and not r['browserErrors'] and not r['changedInputs'];assert r['oracleReportSha256']=='4d271632fa08f044386c5f752e926e945ee25ef2e8f6e7e02fc5cdd30f5b12a3'
for p,h in r['artifactAndInputHashes'].items():assert sha(Path(p))==h
for target,t in r['targets'].items():
 assert t['complete'] and len(t['results'])==84 and t['statusCounts']=={'pass':54,'oracle-error':30}
 for row in t['results']:
  dest=D/target/row['id']/str(row['repeat']);assert rd(dest/'result.json')==row;assert not row['acquisitionError'];assert row['architecture']['retainedEventBytesStable'];assert (row['status']=='oracle-error')==bool(row['oracleErrors'])
  for c in row['comparisons']:
   a=dest/c['name'];e=dest/('java.'+c['name']);assert (sha(e) if e.exists() else None)==c['expectedSha256'];assert (sha(a) if a.exists() else None)==c['actualSha256'];equal=e.exists() and a.exists() and e.read_bytes()==a.read_bytes();assert equal==c['rawEqual'];channels+=2
  if row['status']=='pass':assert all(c['rawEqual'] for c in row['comparisons'])
summary['trace42']={k:v['statusCounts'] for k,v in r['targets'].items()}
assert all(sha(R/p)==h for p,h in build['source_hashes'].items()) and sha(M)==process['manifest_sha256_before']
benchmark.write_json(O/'report.json',dict(passed=True,scope='Independent final corrected-runtime raw audit: standardplatform +91read +9method-order +18trace +20repeat +42source-session. Exact JSUTF16+Node-derivedUTF8 contract with originalJavaUTF8 separate; legacy rawUTF8 unchanged.',standard=dict(scenarios=92,shared=6078,java_each=6076,contract='pass',compatibility='fail'),platforms=summary,raw_payload_files_verified=channels,serialization_divergent_executions=divergent,method_original_bindings=method_bindings,source_stability=True,artifact_stability=True,manifest_stability=True,prior_manifest_rows_preserved=True,manifest_counts=manifest['counts'],manifest_sha256=sha(M),artifacts=build['artifacts'],A_corrected_freeze_sha256=sha(A),standard_report_sha256=sha(B/'report.json'),browser=r['browser'],playwright=r['playwright'],script_sha256=sha(Path(__file__))))
print('audit passed',channels)
