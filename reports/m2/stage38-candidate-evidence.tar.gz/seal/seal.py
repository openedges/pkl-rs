from pathlib import Path,PurePosixPath
import json,hashlib,os,tarfile,time
R=Path.cwd();BASE=R/'target/m2';O=BASE/'stage38-candidate-seal-01';MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs');PRIOR=MAIN/'target/m2/stage38-origins-seal-01'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def rd(p):return json.loads(p.read_bytes())
def write(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def declared(root):
 c=root/'closure.json'
 if not c.exists():return []
 r=rd(c);v=r.get('files_sha256',r.get('files',{}));items=v.items() if isinstance(v,dict) else [(x['path'],x) for x in v] if isinstance(v,list) else []
 out=[]
 for rel,val in items:
  h=val if isinstance(val,str) else val['sha256'];p=Path(rel)
  if not p.is_absolute():p=(root.parents[2]/p) if p.parts[:2]==('target','m2') else root/p
  out.append((p,h))
 return out
closed_names='''stage38-core-order-validation-01 stage38-core-order-validation-02 stage38-corpus-addition-04 stage38-corpus-tools-01 stage38-docs-draft-01 stage38-final-harness-02 stage38-final-native-02 stage38-final-native-audit-02 stage38-final-uri-edges-02 stage38-frontend-validation-04 stage38-main-integration-audit-01 stage38-manifest-freeze-01 stage38-method-order-oracle-01 stage38-method-order-oracle-02 stage38-method-order-platform-generation-01 stage38-method-order-platform-generation-02 stage38-method-order9-platform-final-03 stage38-next-scope-review-01 stage38-platform-review-final-03 stage38-platforms-final-03 stage38-portable-processes-final-03 stage38-read91-platform-final-03 stage38-repeat20-platform-final-03 stage38-trace18-platform-final-03 stage38-trace42-platform-final-03 stage38-uri-primitive-oracle-01'''.split()
active={'stage38-final-language-audit-01':'B live/future MAIN final language audit, explicitly excluded','stage38-upstream-error-adapter-design-01':'Stage39 adapter planning was writing at initial scope cutoff; excluded by explicit archive boundary pending parent decision'}
# Cache identities are rejected before is_dir/os.walk. A captured subprocess
# directory named build is evidence and is deliberately NOT a generic exclusion.
cache_names={'stage38-core-cargo','stage38-frontend-cargo','stage38-review-cargo'};skip_dirs={'.cache','node_modules','target','__pycache__','.pytest_cache','.git'}
old_files={};old_roots=[];dependencies={}
for name in ['oracle','development']:
 p=PRIOR/(name+'-inventory.json');r=rd(p);old_roots+=r['roots'];
 for entry in r['files'].values():
  origin=entry['origin'];assert origin not in old_files;old_files[origin]=entry
 archive=MAIN/'reports/m2'/('stage38-'+name+'-evidence.tar.gz');dependencies[name]=dict(inventory=str(p),inventory_sha256=sha(p),archive=str(archive),archive_sha256=sha(archive),roots=r['roots'],files=len(r['files']))
old_root_set=set(old_roots);snapshot=sorted(p.name for p in BASE.iterdir() if p.name.startswith('stage38-'));included_roots=[];loose=[];omitted=[]
for name in snapshot:
 p=BASE/name
 if name in cache_names or name.endswith('-cargo'):omitted.append(dict(path=str(p),reason='Cargo build cache excluded before traversal',traversed=False));continue
 if name==O.name:omitted.append(dict(path=str(p),reason='Live seal output/tooling; metadata added explicitly, no recursive self-inclusion',traversed=False));continue
 if any(name==prefix or name.startswith(prefix+'.') for prefix in active):omitted.append(dict(path=str(p),reason=next(v for k,v in active.items() if name==k or name.startswith(k+'.')),traversed=False));continue
 if str(p) in old_root_set or str(p) in old_files:omitted.append(dict(path=str(p),reason='Already in unchanged MAIN oracle/development archive inventory; referenced, not duplicated',traversed=False));continue
 if p.is_symlink():raise RuntimeError('unexpected direct symlink '+str(p))
 if p.is_dir():
  if name in closed_names:included_roots.append(p)
  else:omitted.append(dict(path=str(p),reason='Not on explicit confirmed-closed root list at cutoff',traversed=False))
 elif p.is_file():
  if name.endswith(('.stdout.log','.stderr.log')):loose.append(p)
  else:omitted.append(dict(path=str(p),reason='Unclassified loose file, not evidence-authorized at cutoff',traversed=False))
assert {p.name for p in included_roots}==set(closed_names)
for prefix,reason in active.items():
 if prefix not in snapshot:omitted.append(dict(path=str(BASE/prefix),reason=reason+'; absent at direct-root snapshot',traversed=False))
assert sha(BASE/'stage38-uri-primitive-oracle-01/report.json')=='a0ff1ed3c14886e4e7056ec6c72838e3ac6ec97c713f75c0f537611d2a1a06db'
root_manifest=dict(scope='Explicit remaining corrected Stage38 WORKTREE evidence; no MAIN final3527/checks completion claim. No production/Git edits or builds.',roots=[str(p) for p in included_roots],loose_files=[str(p) for p in loose],direct_stage38_snapshot=snapshot,omitted=omitted,dependencies=dependencies,owner_confirmed_bounded_history={'stage38-uri-primitive-oracle-01':'Terminal IoUtils/JDK primitive observations, not evaluator compatibility; no original closure','stage38-core-order-validation-01':'Immutable preliminary terminal test logs, no coherent source-bound final report','stage38-docs-draft-01':'Root-owned closed documentation snapshot','stage38-corpus-tools-01':'Root-owned closed helpers including add_order_cases.py after addition04'},excluded_before_traversal=dict(exact_caches=sorted(cache_names),nested_cache_names=sorted(skip_dirs),default_root_cargo=[str(R/'target'/x) for x in ['debug','release','wasm32-unknown-unknown']],retained_build_directories='Captured subprocess build logs are evidence, not Cargo caches.'))
files={};nested_omissions=[]
def add(p):
 assert p.is_file() and not p.is_symlink();origin=str(p);assert origin not in old_files,'would duplicate archived input '+origin;arc='worktree/'+p.relative_to(BASE).as_posix();assert arc not in files;st=p.stat();files[arc]=dict(origin=origin,sha256=sha(p),bytes=st.st_size,mtime_ns=st.st_mtime_ns)
for root in included_roots:
 for directory,dirs,names in os.walk(root,topdown=True,followlinks=False):
  kept=[]
  for name in sorted(dirs):
   child=Path(directory)/name
   if name in skip_dirs or name.endswith('-cargo'):nested_omissions.append(dict(path=str(child),reason='Nested known cache excluded before descent'));continue
   assert not child.is_symlink();kept.append(name)
  dirs[:]=kept
  for name in sorted(names):add(Path(directory)/name)
for p in loose:add(p)
# Repair the previous over-broad build exclusion using only explicit original
# closures, without recursively rewalking already sealed roots.
repairs=[]
for rootname in old_roots:
 root=Path(rootname)
 for p,h in declared(root):
  if str(p) not in old_files:
   assert str(p).startswith(str(BASE)+'/');assert sha(p)==h
   add(p);repairs.append(dict(origin=str(p),sha256=h,closure_origin_id=root.name,closure_path=str(root/'closure.json'),closure_sha256=sha(root/'closure.json'),reason='Original closure-declared subprocess build capture omitted by old generic build-directory exclusion'))
assert len(repairs)==12
root_manifest['supplemental_repair_files']=repairs;root_manifest['nested_cache_omissions']=nested_omissions
union=dict(old_files);union.update({v['origin']:v for v in files.values()});coverage=[]
for rootname in [*old_roots,*[str(p) for p in included_roots]]:
 root=Path(rootname);c=root/'closure.json'
 if not c.exists():coverage.append(dict(root=str(root),closure=None,declared_files=None,scope='No original closure; captured immutable bounded snapshot without backfilled claims'));continue
 h=sha(c)
 if str(c) in union:assert union[str(c)]['sha256']==h
 entries=declared(root)
 for p,expected in entries:assert str(p) in union,('union coverage missing',str(p));assert union[str(p)]['sha256']==expected,('union hash mismatch',str(p))
 coverage.append(dict(root=str(root),closure=str(c),closure_sha256=h,declared_files=len(entries),covered_files=len(entries),missing_files=[]))
write(O/'root-manifest.json',root_manifest);write(O/'closure-union-coverage.json',dict(passed=True,scope='Old verified archive inventories plus exact new supplement/payload cover every declared file/hash in each available original closure; no original closure rewritten.',roots=coverage,repair_count=12,repair_files=repairs));write(O/'inventory.json',dict(schema=1,scope=root_manifest['scope'],roots=root_manifest['roots'],loose_files=root_manifest['loose_files'],files=files,excluded_before_traversal=root_manifest['excluded_before_traversal'],helper_sha256=sha(Path(__file__))));print('inventory',len(included_roots),len(loose),len(files),sum(v['bytes'] for v in files.values()),flush=True)
archive=O/'stage38-candidate-evidence.tar.gz';metadata=['root-manifest.json','inventory.json','closure-union-coverage.json','seal.py']
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name in metadata:tar.add(O/name,arcname='seal/'+name,recursive=False)
 for arc,v in sorted(files.items()):tar.add(v['origin'],arcname=arc,recursive=False)
assert archive.stat().st_size<=90*1024*1024,'Archive exceeds90MiB: split logical parts before publication'
for v in files.values():assert sha(Path(v['origin']))==v['sha256'],'input changed during archive'
write(O/'creation.json',dict(archive=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,file_count=len(files),raw_bytes=sum(v['bytes'] for v in files.values()),input_stability=True,inventory_sha256=sha(O/'inventory.json'),root_manifest_sha256=sha(O/'root-manifest.json'),union_coverage_sha256=sha(O/'closure-union-coverage.json')));print('created',archive.stat().st_size,flush=True)
