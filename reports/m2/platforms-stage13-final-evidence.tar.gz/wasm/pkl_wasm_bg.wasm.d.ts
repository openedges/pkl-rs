/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_hostprobe_free: (a: number, b: number) => void;
export const evaluate: (a: any, b: any) => [number, number, number, number];
export const evaluateLanguage: (a: any, b: any, c: any, d: any, e: number) => [number, number, number, number];
export const evaluateLanguageSequence: (a: any, b: any, c: any, d: any, e: number) => [number, number, number];
export const hostprobe_cancel: (a: number) => void;
export const hostprobe_close: (a: number) => void;
export const hostprobe_drainCancelledReads: (a: number) => [number, number];
export const hostprobe_new: (a: any) => [number, number, number];
export const hostprobe_poll: (a: number, b: number, c: number) => [number, number, number, number];
export const hostprobe_reenter: (a: number, b: any, c: number, d: number) => [number, number];
export const hostprobe_reject: (a: number, b: any, c: any, d: number) => [number, number];
export const hostprobe_respondBytes: (a: number, b: any, c: any, d: number) => [number, number];
export const hostprobe_respondInteger: (a: number, b: any, c: any, d: number) => [number, number];
export const hostprobe_start: (a: number, b: number, c: number) => [number, number];
export const primitive: (a: any, b: any) => [number, number, number, number];
export const roundtripBytes: (a: any) => [number, number, number];
export const roundtripInteger: (a: any) => [number, number, number];
export const roundtripString: (a: any) => [number, number, number, number];
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_drop_slice: (a: number, b: number) => void;
export const __wbindgen_start: () => void;
