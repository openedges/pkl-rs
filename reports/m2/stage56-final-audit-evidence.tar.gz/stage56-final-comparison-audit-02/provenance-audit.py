from pathlib import Path
import hashlib,json,collections
R=Path.cwd();O=R/'target/m2/stage56-final-comparison-audit-02';M=R/'target/m2';read=lambda p:json.loads(p.read_bytes());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=M/'stage56-platforms-01';r=read(p/'report.json');assert len(r['comparisons'])==6078 and len({x['id'] for x in r['comparisons']})==6078
assert r['compatibility_status']=='fail' and r['experiment_contract_status']=='pass' and r['shared_engine_passed']==6078
assert r['known_gaps']==['regex-unicode-15-vs-16','regex-zero-width-supplementary']
assert {t:sum(x['oracle_matches'][t] for x in r['comparisons']) for t in ['rust','node','browser']}=={'rust':6076,'node':6076,'browser':6076}
for n,h in r['artifacts'].items():assert sha(p/n)==h,n
for n,h in r['source_hashes'].items():assert sha(p/'sources'/n)==h,n
assert {x['name']:x['exit_code'] for x in read(p/'commands.json')}=={'bindgen-version':0,'rust-version':0,'native-build':0,'napi-build':0,'wasm-build':0,'wasm-bindgen':0,'oracle-native':1,'platforms':0}
assert r['execution']['browserExecutableSha256']==sha(Path(r['execution']['browserExecutable']))
assert sha(p/'sources.json')==sha(p/'sources.json')
packets={}
for name in ['stage56-class-platform-01','stage56-metadata-platform-01']:
 q=M/name;main=read(q/'report.json');port=read(q/'portable/report.json');existing=read(O/(name+'-audit.json'))
 assert main['node_runtime']['before_sha256']==main['node_runtime']['after_sha256']==sha(Path(main['node_runtime']['executable']))
 assert port['browser']['sha256']==sha(Path(port['browser']['executable']))==r['execution']['browserExecutableSha256']
 assert port['browser']['version']==r['execution']['browser']
 assert port['node']['version']==r['execution']['node'] and port['node']['executable']==main['node_runtime']['executable']
 for n,h in r['artifacts'].items():
  if n=='semantics_probe':continue
  alias='napi' if n=='pkl_napi.node' else n
  assert main['artifacts'][alias]['frozen_before']==h,n
  assert sha(q/'artifacts'/('class-values.node' if alias=='napi' else alias))==h,n
 proc=main['portable_process'];assert proc['status']=='executed' and proc['exit_code']==0 and proc['error'] is None
 assert sha(q/'portable-process/stdout.bin')==proc['stdout']['sha256']
 assert sha(q/'portable-process/stderr.bin')==proc['stderr']['sha256']
 assert len(existing['targets'])==3
 packets[name]={'report_sha256':sha(q/'report.json'),'portable_report_sha256':sha(q/'portable/report.json'),'node_executable_sha256':main['node_runtime']['before_sha256'],'chromium_executable_sha256':port['browser']['sha256'],'frozen_portable_artifacts_match_platform_build':True,'portable_process_exit':proc['exit_code'],'fixture_archive_sha256':existing['fixture_archive_sha256'],'source_snapshot_count':existing['sources_verified'],'inventory_files_verified':existing['inventory_files_verified']}
freeze=M/'stage56-core-checks-04/core-freeze.json';assert sha(freeze)=='80aa1d1b915f688c136bec9894bed41df155f59efa168d8ea40f87baa283897b'
rv=M/'stage56-rust-validation-03';v=read(rv/'report.json');summ=read(rv/'summary.json');assert v['complete'] and not v['changed_sources'] and sha(rv/'sources.json')==v['source_manifest_sha256']
assert len(v['commands'])==5 and all(x['exit_code']==0 for x in v['commands']) and [x['name'] for x in v['commands']]==['references','format','clippy','workspace-tests','wasm-runtime']
for x in v['commands']+v['toolchain_commands']:
 assert sha(rv/(x['name']+'.stdout.bin'))==x['stdout_sha256'] and sha(rv/(x['name']+'.stderr.bin'))==x['stderr_sha256']
assert (summ['passed'],summ['failed'],summ['ignored'])==(910,0,1)
build=M/'stage56-platform-run-01';b=read(build/'report.json');assert b['complete'] and not b['changed_sources'] and sha(build/'sources.json')==b['source_manifest_sha256'] and all(x['exit_code']==0 for x in b['commands'])
assert b['native_artifact']['sha256']=='84548c956e549404967a7ead18be5c93d34988fca51be630a41a9e56ec713a9e'
assert sha(Path(b['native_artifact']['path']))==b['native_artifact']['sha256']
result={'scope':'Offline provenance and closure cross-check; no guest, build, comparator or Rust checks launched.','core_freeze04_sha256':sha(freeze),'rust_validation03':{'report_sha256':sha(rv/'report.json'),'source_manifest_sha256':v['source_manifest_sha256'],'commands':{x['name']:x['exit_code'] for x in v['commands']},'workspace_tests':{k:summ[k] for k in ['passed','failed','ignored']},'host':v['host']['platform'],'rustc_version':(rv/'rust-version.stdout.bin').read_text().splitlines()[0]},'platform_build01':{'report_sha256':sha(build/'report.json'),'source_manifest_sha256':b['source_manifest_sha256'],'native_release_sha256':b['native_artifact']['sha256']},'m1_platforms01':{'report_sha256':sha(p/'report.json'),'source_hashes_verified':len(r['source_hashes']),'artifact_hashes_verified':len(r['artifacts']),'rows':len(r['comparisons']),'java_matches':{t:sum(x['oracle_matches'][t] for x in r['comparisons']) for t in ['rust','node','browser']},'shared_matches':r['shared_engine_passed'],'known_gaps':r['known_gaps'],'strict_compatibility_status':r['compatibility_status'],'experiment_contract_status':r['experiment_contract_status'],'node_version':r['execution']['node'],'chromium_version':r['execution']['browser'],'chromium_executable_sha256':r['execution']['browserExecutableSha256']},'packets':packets}
(O/'provenance-audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'verified':True,'m1_sources':len(r['source_hashes']),'packets':list(packets)}))
