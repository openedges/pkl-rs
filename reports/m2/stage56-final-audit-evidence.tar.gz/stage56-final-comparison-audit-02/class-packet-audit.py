from pathlib import Path,PurePosixPath
import collections,hashlib,json,re,sys,tarfile
from urllib.parse import urlsplit
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage56-final-comparison-audit-02';packet=Path(sys.argv[1]);p=ROOT/'target/m2'/packet;read=lambda p:json.loads(p.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest();r=read(p/'report.json');manifest=read(p/'fixture/cases.json');freeze=read(ROOT/'target/m2/stage56-core-checks-04/core-freeze.json');kind=manifest.get('kind');pin='8b111f12f87e171106ce431c28a3267d027a2d24c927249d387348b0d216aab42a75a0c8f16c' if False else ('8b111f12f87e171106ce431c28a3267d027a2d24c927249d387348fd13f5f652' if kind=='pkl-java-class-metadata-completion-v1' else 'a39060fbf155947212aaae5b2e950dc2cd04381a78cb2860a7f8b1675b3657fc')
assert sha((p/'fixture/oracle-evidence.tar.gz').read_bytes())==pin
assert r['sources_before']==r['sources_after'] and r['source_changes']==[]
assert all(r[n]==[] for n in ['infrastructure_errors','portable_issues','layout_issues','artifact_changes'])
assert r['full_public_api_comparison_passed'] is False and r['full_public_api_status']=='blocked-unexecuted-required'
assert all(r[k]['status']=='not-executed-required' for k in ['provider_supplement','public_export_supplement'])
assert r['status_scope']=='common-query-logger-protocol'
assert set(r['requested_targets'])=={'native','napi','chromium'}
catalog=read(p/'source-catalog.json');assert sha((p/'source-catalog.json').read_bytes())==r['source_catalog_sha256'];assert set(catalog['paths'])==set(r['sources_before'])
for n,h in r['sources_before'].items():assert sha((p/'sources'/n).read_bytes())==h,n
assert {x.relative_to(p/'sources').as_posix() for x in (p/'sources').rglob('*') if x.is_file()}==set(r['sources_before'])
for n,h in freeze['files'].items():assert r['sources_before'][n]==h,n
if kind:assert {'tools/class_metadata_fixtures.py','tools/class_metadata_oracle.py'}<=r['sources_before'].keys()
for n,a in r['artifacts'].items():
 frozen=p/'artifacts'/('class_values_fixture_probe' if n=='native' else 'class-values.node' if n=='napi' else n)
 h=sha(frozen.read_bytes());assert all(a[k]==h for k in ['origin_before','origin_after','frozen_before','frozen_after']) and a['admission_error'] is None
assert r['artifacts']['native']['frozen_before']=='84548c956e549404967a7ead18be5c93d34988fca51be630a41a9e56ec713a9e'
build=read(ROOT/'target/m2/stage56-platform-run-01/report.json');buildsources=read(ROOT/'target/m2/stage56-platform-run-01/sources.json');assert build['complete'] is True and build['changed_sources']==[] and all(c['exit_code']==0 for c in build['commands']);assert build['native_artifact']['sha256']==r['artifacts']['native']['frozen_before'];assert sha((ROOT/'target/m2/stage56-platform-run-01/sources.json').read_bytes())==build['source_manifest_sha256']
shared=set(buildsources)&set(r['sources_before']);assert all(buildsources[n]==r['sources_before'][n] for n in shared);extra=set(buildsources)-shared;assert extra=={'tools/m1_platforms.py'};assert all(sha((ROOT/n).read_bytes())==buildsources[n] for n in extra)
inv=read(p/'inventory.json');actual={x.relative_to(p).as_posix() for x in p.rglob('*') if x.is_file()};assert actual==set(inv)|{'inventory.json'}
for n,v in inv.items():
 data=(p/n).read_bytes();assert v=={'sha256':sha(data),'bytes':len(data)},n
pr=read(p/'portable/report.json');assert pr['complete'] is True and pr['inputsBefore']==pr['inputsAfter'] and pr['fileSetsBefore']==pr['fileSetsAfter'] and pr['infrastructureErrors']==[]
expectedpairs={(c['id'],repeat) for c in manifest['cases'] for repeat in range(manifest['repetitions'])};assert manifest['repetitions']==2 and r['repetitions']==2
reports=[];allchannels=[]
with tarfile.open(p/'fixture/oracle-evidence.tar.gz','r:gz') as t:
 members=t.getmembers();assert len({m.name for m in members})==len(members)
 for m in members:
  n=PurePosixPath(m.name);assert not n.is_absolute() and '..' not in n.parts and (m.isfile() or m.isdir())
 expected={}
 for c in manifest['cases']:
  for repeat in range(2):
   prefix=f'main/cases/{c["id"]}/{repeat}/';flat={m.name[len(prefix):]:t.extractfile(m).read() for m in members if m.isfile() and m.name.startswith(prefix) and '/' not in m.name[len(prefix):] and m.name.endswith('.bin')};flat={n:b for n,b in flat.items() if not n.endswith('.error-class.bin')};assert flat['protocol.bin']==t.extractfile(prefix+'process/stdout.bin').read();expected[(c['id'],repeat)]=flat
 for target in r['requested_targets']:
  rows=r['targets'][target]['rows'];assert {(x['id'],x['repeat']) for x in rows}==expectedpairs and len(rows)==len(expectedpairs)
  if target!='native':assert {(x['id'],x['repeat']) for x in pr['targets'][target]}==expectedpairs
  counts=collections.Counter();channels=0;utf16=0;statuses=collections.Counter();unequal=[]
  for row in rows:
   c=next(c for c in manifest['cases'] if c['id']==row['id']);repeat=row['repeat'];d=p/row['directory'];e=expected[(c['id'],repeat)];known={n[:-len('.status.bin')] for n in e if n.endswith('.status.bin')};a={}
   for file in d.glob('*.bin'):
    n=file.name
    if re.fullmatch(r'(?:outer-\d+|log-callback-\d+)\.(?:disposition|phase|reason|api-error-kind|callback-origin)\.bin',n):assert n.rsplit('.',2)[0] in known;continue
    if target=='napi' and n in ['process.stdout.bin','process.stderr.bin']:assert file.read_bytes()==b'';continue
    a[n]=file.read_bytes()
   assert set(a)==set(e),(target,c['id'],repeat)
   derived=[]
   for n,b in sorted(e.items()):
    equal=b==a[n];item={'name':n,'expected_sha256':sha(b),'actual_sha256':sha(a[n]),'expected_bytes':len(b),'actual_bytes':len(a[n]),'raw_equal':equal};derived.append(item);channels+=1;utf16+=n.endswith('.code-units.bin')
    if not equal:unequal.append({'id':c['id'],'repeat':repeat,**item})
    if n.endswith('.status.bin'):statuses[b.decode().strip()]+=1
   assert {x['name']:x for x in derived}=={x['name']:x for x in row['channels']};assert row['raw_equal']==all(x['raw_equal'] for x in derived);assert row['exact_coverage'] is True;assert row['architecture']['valid'] is True
   if target=='native':
    trace=(d/'candidate-trace.tsv').read_text();assert trace.startswith('constructor\t("module-evaluator", "compact", '+('true' if c['logger']['mode']=='capture' else 'false')+', false, false)\n');assert 'terminal-heap-slots\t0\n' in trace and 'terminal-context-depth\t0\n' in trace;assert int(re.search(r'^polls\t(\d+)$',trace,re.M)[1])>0 and int(re.search(r'^collections\t(\d+)$',trace,re.M)[1])>0
    process=read(d/'process/result.json');assert type(process['exit_code']) is int and process['exit_code']==0 and process['status']=='executed' and process['error'] is None;assert (d/'process/stdout.bin').read_bytes()==a['protocol.bin'] and (d/'process/stderr.bin').read_bytes()==b''
    inputs={'input.pkl':(p/'fixture'/c['source']).read_bytes(),'expressions.txt':('\n'.join(c['expressions'])+'\n').encode(),'modules.tsv':''.join(s['uri']+'\tsupport-'+str(i)+'.pkl\n' for i,s in enumerate(c['support_modules'])).encode()};inputs.update({'support-'+str(i)+'.pkl':(p/'fixture'/s['source']).read_bytes() for i,s in enumerate(c['support_modules'])});assert all((d/n).read_bytes()==b for n,b in inputs.items())
   else:
    trace=read(d/'candidate-trace.json');arch=trace['architecture'];assert arch['sessionCreated'] is True and arch['retainedPayloadsStable'] is True and arch['terminalSlots']==0 and arch['terminalDepth']==0 and arch['polls']>0 and arch['collections']>0 and trace['acquisitionError'] is None
    proc=read(d/'process.json')
    if target=='napi':assert type(proc['exitCode']) is int and proc['exitCode']==0 and proc['signal'] is None and proc['error'] is None and proc['command'][2]=='--child'
    else:assert proc['isolation']=='new-browser-context-and-wasm-instance' and proc['browserErrors']==[] and proc['acquisitionError'] is None
    def transported(s):
     raw=(p/'fixture'/s['source']).read_bytes();assert sha(raw)==s['source_sha256'];filename=urlsplit(s['uri']).path.rsplit('/',1)[-1];return {**s,'sourcePath':s['source'],'source':raw.decode(),'moduleName':filename.rsplit('.',1)[0] if '.' in filename else filename}
    exact=transported(c);exact['support_modules']=[transported(s) for s in c['support_modules']];assert read(d/'input.json')==exact
   counts[row['status']]+=1
  assert dict(counts)==r['targets'][target]['statuses'];reports.append({'target':target,'rows':len(rows),'statuses':dict(counts),'common_channels':channels,'utf16_channels':utf16,'reference_call_statuses':dict(statuses),'unequal_channels':unequal})
result={'scope':'Independent offline raw/source/artifact/process audit. No evaluators, builds or comparator re-execution. Full public SPI/export API remains required.','packet':packet.as_posix(),'report_sha256':sha((p/'report.json').read_bytes()),'fixture_archive_sha256':pin,'sources_verified':len(r['sources_before']),'all37_core_freeze04_sources_match':True,'inventory_files_verified':len(inv),'release_native_sha256':r['artifacts']['native']['frozen_before'],'shared_build_sources_exact':len(shared),'separately_bound_driver_sources':{n:buildsources[n] for n in extra},'strict_common_matrix_passed':r['strict_main_comparison_passed'],'full_public_api_comparison_passed':False,'targets':reports,'portable_isolation':'One recorded fresh Node child per pair; one fresh browser context/Wasm instance per pair. Actual Node/browser runtime identities and tracked file sets retain original report provenance.'}
(OUT/(packet.name+'-audit.json')).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps({'packet':packet.as_posix(),'sources':len(r['sources_before']),'targets':[{k:v for k,v in x.items() if k!='unequal_channels'} for x in reports]}))
