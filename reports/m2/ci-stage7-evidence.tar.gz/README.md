# Stage 7 exact-commit CI evidence

`package/` preserves the original GitHub ZIP artifacts, exact commit identities,
all six terminal job outcomes, independent raw verification, helper preparation,
and the initial portable replay. `offline-proof/` records a second replay of the
sealed package. The package stayed byte-identical during that final replay.

M2 selected and M1 architecture contracts retain known failures. These artifacts
do not establish complete language/API compatibility or performance targets.
