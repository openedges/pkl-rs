"""Raw File/triple/order fixture preparation and fresh frozen-candidate comparison."""
from pathlib import Path
import argparse,collections,hashlib,json,os,re,shutil,subprocess,sys,time,zipfile
PINS={'stage46-logical-binding-oracle-01':'db1b7305da5f564a3b670b8e3deee304e7188ee579138b7cf5d9187a4ce64765','stage46-static-error-oracle-01':'cc91bd358368f5d9130852b6ed0285667f2bd78033eb5a7d221399050ce679f7','stage46-generator-owner-oracle-01':'bb1faea7304d4df90be9b7eb46a2eb23df991240f48c87ae34a791e5b41055ca','stage46-header-producer-oracle-01':'e83abd7b0a02295921d9bed5d30b3cdaa509a0601fcaf98a88899a88af2ca925','stage46-supertype-producer-oracle-01':'dc2ca1b417889e29f06b7fcf733f787de04f1bb4192269d3f8bed140e898f8ed','stage46-triple-dot-oracle-01':'0caca24eb7ae82eb75e3fab71dc43d3d39827fd86766ecf5cefb41602406e52d','stage46-triple-order-oracle-01':'e6b7eac58241771be5c4919506d3a1e0914f0889976445ef30bdc3e950b33ebb','stage46-module-capability-oracle-03':'eda49c0ed06b2320b33dd877391b64adb62a0611deac09d0a828da1d0e012740'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def safe(root,name):
 p=Path(name)
 if p.is_absolute()or'..'in p.parts:raise ValueError('unsafe input path')
 q=root/p
 if not q.resolve().is_relative_to(root.resolve()):raise ValueError('input escapes root')
 return q

def project(events,primary,native=False):
 kept=[];outside=[];unknown=[]
 for value in events:
  if value.startswith('policy-resolve-module ')and value[len('policy-resolve-module '):]in {primary,'repl:text'}:outside.append({'event':value,'boundary':'Java primary/query ModuleSource admission differs from supplied SourceProbe text'});continue
  if value==f'secure-path {primary} resource=false':outside.append({'event':value,'boundary':'Java primary source access'});continue
  if value.startswith(('policy-resolve-module ','policy-import ','policy-read-resource ','actual-file-reader ','actual-module-denied ','actual-resource-denied ','secure-path ')):kept.append(value)
  elif native and value.startswith(('module-capabilities ','module-has-element ','module-resolve ','module-source ','reader-request ')):outside.append({'event':value,'boundary':'Native typed transport/capability effect;Java does not expose same API event'})
  elif re.fullmatch(r'outer-\d+ (success|error org\.pkl\.core\.PklException)',value):outside.append({'event':value,'boundary':'API completion,comparedasrawchannelsseparately'})
  else:unknown.append(value)
 return {'events':kept,'outsideContract':outside,'unknownEvents':unknown}

def prepare(oracle,out):
 out.mkdir(parents=True,exist_ok=False);report=json.loads((oracle/'report.json').read_bytes())
 if sha(oracle/'report.json')!=PINS.get(oracle.name):raise ValueError('Java report identity differs')
 for p,h in report['inputHashes'].items():
  if sha(Path(p))!=h:raise ValueError('Java input differs '+p)
 (out/'provenance').mkdir()
 for name in ['report.json','cases.json']:shutil.copyfile(oracle/name,out/'provenance'/name)
 originals=json.loads((oracle/'cases.json').read_bytes());profile=json.loads((oracle/'profile.json').read_bytes());jar=Path(profile['jar'])
 if sha(jar)!=profile['jarSha256']:raise ValueError('pinned Java jar differs')
 with zipfile.ZipFile(jar)as z:
  name=next(n for n in z.namelist()if n.endswith('/errorMessages.properties'));properties=z.read(name).decode('utf-8')
 def template(key):
  marker=key+'=\\\n';start=properties.index(marker)+len(marker);return properties[start:properties.index('\n',start)]
 module_template=template('moduleNotInAllowList');resource_template=template('resourceNotInAllowList')
 put(out/'exclusions.json',{'declaredBeforeTraversal':True,'cargoCachePaths':[],'scope':'ExactexistingJava report/input/raw paths only. No neworacle,no cache/sourcewalk. Original roots unchanged.'})
 rows=[]
 for c in originals:
  work=Path(c['workspace']);primary=c['operations'][0][0];source=work/primary;source_uri=c['sourceUri'];copy=out/'sources'/c['id']/'main.pkl';copy.parent.mkdir(parents=True);shutil.copyfile(source,copy)
  denied=(work/'tree/a/resource.txt').as_uri();module_cause=module_template.replace('{0}',denied);resource_cause=resource_template.replace('{0}',denied)
  for n,value in [('module-cause',module_cause),('resource-cause',resource_cause)]:
   p=out/'sources'/c['id']/(n+'.units.bin');p.write_bytes(value.encode('utf-16-be'))
  for observation in [o for o in report['observations']if o['case']==c['id']]:
   for session in [0,1]:
    calls=[]
    for call in [v for v in observation['calls']if v['session']==session]:
     prefix=oracle/call['rawPrefix'];raw=lambda n:prefix.with_name(prefix.name+'.'+n).read_bytes();status=raw('status.bin');target='stdout'if status==b'success\n'else'stderr'
     if status!=call['status'].encode()or raw(target+'.bin').hex()!=call['utf8Hex']or raw(target+'.code-units.bin').hex()!=call['utf16BEHex']:raise ValueError('Java report raw mismatch')
     for counter,label in [('counters-before.bin','countersBefore'),('counters-after.bin','countersAfter')]:
      if raw(counter)!=call[label].encode():raise ValueError('Java counter mismatch')
     before=dict(x.split('=',1)for x in call['countersBefore'].splitlines());after=dict(x.split('=',1)for x in call['countersAfter'].splitlines());directory=prefix.parent
     events=[(directory/f'event-{i}.bin').read_text()for i in range(int(before['event']),int(after['event']))]
     channels={n:raw(n).hex()for n in ['status.bin','stdout.bin','stderr.bin','stdout.code-units.bin','stderr.code-units.bin','reads-before.bin','reads-after.bin']}
     if c['mode']=='deny-module'and'actual-module-denied '+denied in events:
      if not raw('stderr.code-units.bin').startswith(('–– Pkl Error ––\n'+module_cause+'\n\n').encode('utf-16-be')):raise ValueError('captured policy module cause template mismatch')
     if c['mode']=='deny-resource'and'actual-resource-denied '+denied in events:
      if not raw('stderr.code-units.bin').startswith(('–– Pkl Error ––\n'+resource_cause+'\n\n').encode('utf-16-be')):raise ValueError('captured policy resource cause template mismatch')
     calls.append({'prefix':call['prefix'],'expression':call['expression'],'source':call['source'],'rawJavaPrefix':str(prefix),'channelsHex':channels,'javaEvents':events,'javaProjection':project(events,source_uri),'errorClass':call['errorClass']})
    rows.append({'id':c['id'],'repeat':observation['repeat'],'session':session,'source':copy.relative_to(out).as_posix(),'sourceSha256':sha(copy),'sourceUri':source_uri,'primarySource':primary,'physicalSourcePath':str(source),'mode':c['mode'],'deniedUri':denied,'moduleCause':('sources/'+c['id']+'/module-cause.units.bin'),'resourceCause':('sources/'+c['id']+'/resource-cause.units.bin'),'calls':calls,'constructorBoundaryExpected':c['id'].startswith(('parse-error-','import-before-parse-error'))})
 data={'schema':1,'oracleRoot':str(oracle),'oracleReportSha256':sha(oracle/'report.json'),'javaApiCalls':report['apiCalls'],'cases':rows,'policyScope':'FullrawJava/nativeeventsretained. OnlyexplicitFilemodule/resourceguardscomparedafterlistedprimary/repladmission/transportboundaries;unknown events fail. Notfullproductsecurity/APIparity.','causeDerivation':'Pinned JAR ErrorMessages templates + capturedexactdeniedURI. Barecausewasnotseparatelyrecordedbyoriginalhelper;templatevalidatedagainstfulloriginalJavaerrorprefix;allcompleteerrorsstillcomparedraw.'}
 put(out/'fixtures.json',data);put(out/'manifest.json',{'files':{p.relative_to(out).as_posix():{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(out.rglob('*'))if p.is_file()and p.name!='manifest.json'}})
 return data

def verify_fixture(root):
 m=json.loads((root/'manifest.json').read_bytes())
 if not m['files']:raise ValueError('empty fixture')
 for n,r in m['files'].items():
  p=safe(root,n)
  if sha(p)!=r['sha256']or p.stat().st_size!=r['bytes']:raise ValueError('fixture bytes differ')
 d=json.loads((root/'fixtures.json').read_bytes());report_path=root/'provenance/report.json'
 if sha(report_path)!=d['oracleReportSha256']or d['oracleReportSha256']not in PINS.values():raise ValueError('Java report pin differs')
 report=json.loads(report_path.read_bytes());cases_path=root/'provenance/cases.json';original_case_path=str(Path(d['oracleRoot'])/'cases.json')
 if sha(cases_path)!=report['inputHashes'][original_case_path]:raise ValueError('original case declaration differs')
 originals=json.loads(cases_path.read_bytes());expected_keys=[(o['case'],o['repeat'],session)for o in report['observations']for session in [0,1]]
 if [(r['id'],r['repeat'],r['session'])for r in d['cases']]!=expected_keys:raise ValueError('session coverage/order differs')
 stdout_by_process={}
 for row in d['cases']:
  original=next(c for c in originals if c['id']==row['id']);source=Path(original['workspace'])/original['operations'][0][0]
  if row['sourceUri']!=original['sourceUri']or row['mode']!=original['mode']or row['physicalSourcePath']!=str(source)or row['primarySource']!=original['operations'][0][0]:raise ValueError('source/URI/policy identity differs')
  if sha(safe(root,row['source']))!=report['inputHashes'][str(source)]:raise ValueError('source bytes differ')
  observation=next(o for o in report['observations']if o['case']==row['id']and o['repeat']==row['repeat']);calls=[c for c in observation['calls']if c['session']==row['session']]
  if len(calls)!=len(row['calls']):raise ValueError('missing API calls')
  for actual,expected in zip(row['calls'],calls):
   target='stdout'if expected['status']=='success\n'else'stderr';other='stderr'if target=='stdout'else'stdout';raw=actual['channelsHex']
   if actual['expression']!=expected['expression']or actual['prefix']!=expected['prefix']or actual['source']!=expected['source']:raise ValueError('API call identity differs')
   if raw['status.bin']!=expected['status'].encode().hex()or raw[target+'.bin']!=expected['utf8Hex']or raw[target+'.code-units.bin']!=expected['utf16BEHex']or raw[other+'.bin']or raw[other+'.code-units.bin']:raise ValueError('Java raw channel differs')
   for suffix,key in [('reads-before.bin','countersBefore'),('reads-after.bin','countersAfter')]:
    count=dict(x.split('=',1)for x in expected[key].splitlines())['read']
    if raw[suffix]!=count.encode().hex():raise ValueError('Java read count differs')
   if project(actual['javaEvents'],row['sourceUri'])!=actual['javaProjection']:raise ValueError('effect projection differs')
   stdout_by_process.setdefault((row['id'],row['repeat']),bytearray()).extend(b''.join(e.encode()+b'\n'for e in actual['javaEvents']))
 for record in report['records']:
  if hashlib.sha256(stdout_by_process[(record['case'],record['repeat'])]).hexdigest()!=record['result']['sha256']['stdout']:raise ValueError('ordered raw Java events differ from process capture')
 if sum(len(c['calls'])for c in d['cases'])!=d['javaApiCalls']or d['javaApiCalls']!=report['apiCalls']:raise ValueError('fixture count differs')
 return d

def compare(fixture,release_path,out):
 data=verify_fixture(fixture);original_inputs=json.loads((fixture/'provenance/report.json').read_bytes())['inputHashes']
 for input_path,digest in original_inputs.items():
  if sha(Path(input_path))!=digest:raise ValueError('original Java observer/input changed '+input_path)
 release=json.loads(release_path.read_bytes());binary=Path(release['artifact']);source_map=Path(release['source_map']);snapshot=Path(release['source_snapshot'])
 out.mkdir(parents=True,exist_ok=False);put(out/'exclusions.json',{'declaredBeforeTraversal':True,'cargoCachePaths':[],'scope':'Explicitnewfrozenreleasedmap andfixture paths only;no oldcandidateexecution/cachewalk.'})
 if sha(binary)!=release['artifact_sha256']or sha(source_map)!=release['source_map_sha256']:raise ValueError('frozen release differs')
 hashes=json.loads(source_map.read_bytes())
 for n,h in hashes.items():
  if sha(safe(snapshot,n))!=h:raise ValueError('snapshot differs '+n)
 shutil.copyfile(__file__,out/'comparator.py');put(out/'release.json',release);shutil.copyfile(source_map,out/'source-map.json');put(out/'fixture-binding.json',{'fixtureManifest':str(fixture/'manifest.json'),'sha256':sha(fixture/'manifest.json')})
 runs=[];comparisons=[];constructors=[];effects=[]
 groups={}
 for row in data['cases']:groups.setdefault((row['id'],row['repeat']),[]).append(row)
 for (case_id,repeat),sessions in groups.items():
  c=sessions[0];selected=[v for v in c['calls']if v['source']==c['primarySource']];expressions=out/'inputs'/case_id/'expressions.txt';expressions.parent.mkdir(parents=True,exist_ok=True);expressions.write_text(''.join(v['expression']+'\n'for v in selected));target=out/'cases'/case_id/str(repeat);target.mkdir(parents=True)
  source=safe(fixture,c['source']);args=[str(binary),str(source),c['sourceUri'],'main',str(expressions),str(target/'calls'),'2',c['mode'],c['deniedUri'],str(safe(fixture,c['moduleCause'])),str(safe(fixture,c['resourceCause']))]
  before=sha(source);started=time.time_ns()
  with(target/'stdout.bin').open('wb')as stdout,(target/'stderr.bin').open('wb')as stderr:
   proc=subprocess.Popen(args,cwd=Path(c['physicalSourcePath']).parent,stdout=stdout,stderr=stderr);put(target/'launch.json',{'command':args,'pid':proc.pid,'startedUnixNs':started});timedout=False
   try:exitcode=proc.wait(timeout=90)
   except subprocess.TimeoutExpired:timedout=True;proc.kill();exitcode=proc.wait()
  run={'case':case_id,'repeat':repeat,'pid':proc.pid,'command':args,'exitCode':exitcode,'timedOut':timedout,'finishedUnixNs':time.time_ns()};runs.append(run);put(target/'terminal.json',run)
  if sha(source)!=before:raise ValueError('fixture source mutated')
  for row in sessions:
   directory=target/'calls'/f"session-{row['session']}";ctor=directory/'constructor.status.bin';calls=[v for v in row['calls']if v['source']==row['primarySource']]
   if ctor.exists():
    expected=calls[0]['channelsHex'];differences=[n for n,suffix in [('stderr.bin','stderr.bin'),('stderr.code-units.bin','stderr.code-units.bin')]if(directory/('constructor.'+suffix)).read_bytes().hex()!=expected[n]]
    constructors.append({'case':case_id,'repeat':repeat,'session':row['session'],'status':'constructor-boundary','javaApiCallsNotExecuted':len(calls),'differences':differences,'expectedBoundary':row['constructorBoundaryExpected']});continue
   for index,call in enumerate(calls):
    prefix=f'outer-{index}';differences=[]
    for suffix,expected in call['channelsHex'].items():
     p=directory/(prefix+'.'+suffix)
     if not p.exists()or p.read_bytes().hex()!=expected:differences.append(suffix)
    disposition=directory/(prefix+'.disposition.bin');kind=disposition.read_text()if disposition.exists()else None
    status='candidate-unsupported'if kind=='unsupported'else'mismatch'if differences else'pass'
    comparisons.append({'case':case_id,'repeat':repeat,'session':row['session'],'javaPrefix':call['prefix'],'nativePrefix':prefix,'expression':call['expression'],'status':status,'differences':differences})
    counters=directory/(prefix+'.host-counters-before.bin');after=directory/(prefix+'.host-counters-after.bin')
    if counters.exists()and after.exists():
     before_events=int(dict(x.split('=',1)for x in counters.read_text().splitlines())['event']);after_events=int(dict(x.split('=',1)for x in after.read_text().splitlines())['event']);events=[(directory/f'host-event-{i}.bin').read_text()for i in range(before_events,after_events)];native=project(events,row['sourceUri'],True);java=call['javaProjection'];effects.append({'case':case_id,'repeat':repeat,'session':row['session'],'expression':call['expression'],'java':java,'native':native,'nativeRawEvents':events,'matches':java['events']==native['events']and not java['unknownEvents']and not native['unknownEvents']})
    else:effects.append({'case':case_id,'repeat':repeat,'session':row['session'],'expression':call['expression'],'matches':False,'reason':'missingnativeeffectcapture'})
 for input_path,digest in original_inputs.items():
  if sha(Path(input_path))!=digest:raise ValueError('original Java observer/input mutated '+input_path)
 counts=dict(collections.Counter(c['status']for c in comparisons));report={'javaApiCalls':data['javaApiCalls'],'actualNativeApiCalls':len(comparisons),'counts':counts,'constructors':constructors,'javaApiCallsNotExecutedAtConstructor':sum(c['javaApiCallsNotExecuted']for c in constructors),'policyProjectionCounts':{'pass':sum(e['matches']for e in effects),'mismatch':sum(not e['matches']for e in effects)},'records':runs,'comparisons':comparisons,'effects':effects,'artifactSha256':sha(binary),'sourceMapSha256':sha(source_map),'sourceInputsVerified':len(hashes),'fixtureManifestSha256':sha(fixture/'manifest.json'),'originalInputPathsVerified':len(original_inputs),'originalInputChanges':[],'fullSelectedCompatibilityPassed':counts=={'pass':data['javaApiCalls']}and all(e['matches']for e in effects)and not constructors and all(r['exitCode']==0 and not r['timedOut']for r in runs),'scope':data['policyScope']}
 put(out/'report.json',report);return report

def main():
 p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='action',required=True);a=s.add_parser('prepare');a.add_argument('--oracle',required=True,type=Path);a.add_argument('--output',required=True,type=Path);a=s.add_parser('verify');a.add_argument('--fixture',required=True,type=Path);a=s.add_parser('compare');a.add_argument('--fixture',required=True,type=Path);a.add_argument('--release',required=True,type=Path);a.add_argument('--output',required=True,type=Path);a=p.parse_args()
 if a.action=='prepare':d=prepare(a.oracle,a.output);print(json.dumps({'javaApiCalls':d['javaApiCalls'],'sessions':len(d['cases'])}));return 0
 if a.action=='verify':d=verify_fixture(a.fixture);print(json.dumps({'javaApiCalls':d['javaApiCalls'],'sessions':len(d['cases'])}));return 0
 d=compare(a.fixture,a.release,a.output);print(json.dumps({k:d[k]for k in ['javaApiCalls','actualNativeApiCalls','counts','policyProjectionCounts','javaApiCallsNotExecutedAtConstructor']}));return 0 if d['fullSelectedCompatibilityPassed']else 1
if __name__=='__main__':sys.exit(main())
