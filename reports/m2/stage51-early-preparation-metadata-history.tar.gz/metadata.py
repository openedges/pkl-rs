from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tarfile
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=json.loads((O/'archive-report.json').read_bytes());assert not a['originalChanges']
(O/'PLAN.ko.md').write_text("""# 초기 build01 및 candidate02 역사 증거 게시 준비

선택은 명시된9개 닫힌 root 전체다. candidate03/04/live/A setup 로그는 포함하지 않는다. 모든 원본 파일을 archive payload로 보존하며 output/source 중복을 이유로 제외하지 않았다. dependency cache나 project target 전체를 걷지 않았고 cache/build 이름 필터도 쓰지 않는다.

build01의231개와 candidate02의233개 declared source는 각 before/after map 및 frozen copy와 일치한다. 이 과거 source를 current Git blob이나 live crates와 같은 내용이라고 주장하지 않는다. 각 artifact, reader snapshot, 원래 보고서/actual/payload manifest를 직접 연결했다.

initial76sessions/1060calls는 raw996/ordinary964-of992의 진단 기록이고, 뒤 readback은 같은1060 원시 결과에 terminal counter/module ledger 검사를 추가한 것뿐이다. 최초 Node 비교 실행파일 path/hash가 기록되지 않아 그대로 미확인으로 둔다. 현재 Node를 과거 provenance로 채우지 않는다. 완전한 hermetic 환경을 복원했다고 주장하지 않는다.

candidate02 원래 raw는96sessions/1272calls를 보존한다. 첫 parser가 post-close api-error-kind.bin을 소비하지 않아12sessions를 거절해1164calls만 actual JSON에 담았고 acquisition false/exit1이었다. 이후 authenticated readback은 평가/Java 재실행 없이 원래1272calls를 복원했다. 그 결과와 각각 Node/browser는 raw1248,ordinary1156-of1168,diagnostic92,postclose raw12불일치를 기록한다. 원래 failed report는 변경하지 않는다.

corpus가1060에서1272로 달라졌으므로 숫자 차이를 feature 수정량으로 세지 않는다. Readback도 새 runtime 실행이나 추가 compatibility pass가 아니다. candidate02 original adapter2회 match는 별도 결과다. 모든 full Java administrative/whole compatibility gate는 false다.

다섯 semantic archive와 metadata archive를 clean regular-file gather로 만들어 tools/evidence.py create, 별도 verify 프로세스 및 전체 raw member SHA readback을 수행한다. 원본 hash/size/mode와9개 닫힌 root pathset을 후행 대조한다. 각 archive는100,000,000B 미만이다. 새 reports/Git/평가/빌드를 실행하거나 변경하지 않는다.
""")
M=O/'gather/preparation-metadata';M.mkdir();names=['prepare.py','prepare.stdout.bin','prepare.stderr.bin','selection.json','summary.json','archive.py','archive-inputs-before.json','archive-launch.json','archive-terminal.json','actual-tool-terminal.json','archive-report.json','archive-progress.json','archive.stdout.bin','archive.stderr.bin','launch-archives.py','original-guard.json','children-guard.json','PLAN.ko.md','metadata.py']
for unit in ['diagnostic-build01','diagnostic-native01-readback','candidate02-build','candidate02-native-failure-readback','candidate02-portable-original']:
 for action in ['create','verify']:
  names.extend(unit+'-'+action+suffix for suffix in ['.stdout.bin','.stderr.bin','.launch.json','.terminal.json'])
for name in names:shutil.copyfile(O/name,M/name)
(M/'tool-sources/tools').mkdir(parents=True);shutil.copyfile(O/'tool-sources/tools/evidence.py',M/'tool-sources/tools/evidence.py');(M/'METADATA_SOURCE_SELECTION.json').write_text(json.dumps({'files':{n:{'sourcePath':str(O/n),'sha256':sha(O/n),'bytes':(O/n).stat().st_size}for n in names},'semanticArchives':a['archives'],'historicalCandidate':'initial-build01-and-candidate02-history-not-final','allPayloadsRetained':True,'qualification':'Metadata archive own create/verify receipts are finalized outside itself to avoid recursive self inclusion.'},indent=2)+'\n')
archive=O/'archives/stage51-early-preparation-metadata-history.tar.gz';commands=[]
for action in ['create','verify']:
 cmd=[sys.executable,'-B',str(O/'tool-sources/tools/evidence.py'),action]+([str(M),str(archive)]if action=='create'else[str(archive)])
 with(O/('metadata-'+action+'.stdout.bin')).open('wb')as out,(O/('metadata-'+action+'.stderr.bin')).open('wb')as err:
  p=subprocess.Popen(cmd,cwd=R,stdout=out,stderr=err);code=p.wait()
 commands.append({'argv':cmd,'pid':p.pid,'exitCode':code,'stdoutSha256':sha(O/('metadata-'+action+'.stdout.bin')),'stderrSha256':sha(O/('metadata-'+action+'.stderr.bin'))});assert code==0
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert all(m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts for m in members);assert len(members)==len({m.name for m in members});actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in members};expected={p.relative_to(M).as_posix():sha(p)for p in M.rglob('*')if p.is_file()};assert set(actual)==set(expected)|{'EVIDENCE.json'}and all(actual[k]==v for k,v in expected.items())
report={'unit':'preparation-metadata','path':str(archive),'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'payloadFiles':len(expected),'createExitCode':0,'separateVerifyExitCode':0,'allRawMembersReadBack':True,'commands':commands};assert report['compressedBytes']<100000000;(O/'metadata-archive-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
