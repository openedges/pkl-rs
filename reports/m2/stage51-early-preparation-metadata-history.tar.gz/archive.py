"""Archive closed initial build01 and candidate02 history from original frozen captures."""
from pathlib import Path
import datetime,hashlib,json,os,platform,shutil,stat,subprocess,sys,tarfile
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def need(x,s):
 if not x:raise ValueError(s)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
s=json.loads((O/'selection.json').read_bytes());summary=json.loads((O/'summary.json').read_bytes());G=O/'gather';A=O/'archives';G.mkdir();A.mkdir();evidence=O/'tool-sources/tools/evidence.py';evidence.parent.mkdir(parents=True);shutil.copyfile(R/'tools/evidence.py',evidence)
inputs={str(p):{'sha256':sha(p),'bytes':p.stat().st_size}for p in [O/'selection.json',O/'summary.json',O/'prepare.py',Path(__file__).resolve(),evidence,Path(sys.executable).resolve()]};save(O/'archive-inputs-before.json',inputs);commands=[];archives=[]
def execute(name,argv):
 row={'argv':[str(x)for x in argv],'cwd':str(R),'parentPid':os.getpid(),'startedUtc':now()}
 with(O/(name+'.stdout.bin')).open('wb')as stdout,(O/(name+'.stderr.bin')).open('wb')as stderr:
  p=subprocess.Popen(row['argv'],cwd=R,stdout=stdout,stderr=stderr);row['pid']=p.pid;save(O/(name+'.launch.json'),row);row['exitCode']=p.wait()
 row.update(finishedUtc=now(),stdoutSha256=sha(O/(name+'.stdout.bin')),stderrSha256=sha(O/(name+'.stderr.bin')));save(O/(name+'.terminal.json'),row);commands.append(row);need(row['exitCode']==0,'archive command failed '+name)
for unit in ['diagnostic-build01','diagnostic-native01-readback','candidate02-build','candidate02-native-failure-readback','candidate02-portable-original']:
 gather=G/unit;gather.mkdir();rows=[x for x in s['rows']if x['unit']==unit]
 for row in rows:
  p=Path(row['sourcePath']);data=p.read_bytes();need(len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']and stat.S_IMODE(p.stat().st_mode)==row['mode'],'original changed '+str(p));out=gather/'originals'/row['root']/row['relative'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 save(gather/'CAPTURE_SELECTION.json',{'schema':1,'history':'initial-build01-and-candidate02-not-final','selectionSha256':sha(O/'selection.json'),'rows':rows,'sourceSnapshotGuards':s['sourceSnapshotGuards'],'allOriginalFilesRetained':True,'outputOrSourceDuplicateExclusions':[],'noDependencyCacheWalkOrGenericNameFilters':True,'noCurrentGitBlobOrLiveCratesComparison':True})
 save(gather/'SCOPE.json',{'history':'initial1060-and-candidate02-1272','classification':'historical-diagnostic-and-failing-candidate-not-final','ledger':s['ledger'],'provenanceLimitations':summary['provenanceLimitations'],'sourceSnapshotGuards':s['sourceSnapshotGuards'],'actualExistingReceipts':s['actualExistingReceipts'],'fullJavaAdministrativeLifecyclePassed':False,'fullCompatibilityPassed':False,'readbackIsNotReexecution':True,'scopeExclusions':['candidate03','candidate04','live output','A setup logs'],'sourceIdentityQualification':'Historical source files remain raw frozen snapshots. No current Git blob identity, current live source equality, or complete hermetic environment claim is inferred.','goldenAuthorityQualification':'Copied fixture arrays and bundles remain original captured bytes. Java original provenance authority is separate from engine results and must be authenticated through the pinned fixture histories; no expectations are created from Rust.'})
 (gather/'README.md').write_text("""# Early Stage51 immutable history

This archive preserves one logical unit of the original diagnostic build01, initial 1,060-call native acquisition and readback, or candidate02's 1,272-call native/portable acquisition and authenticated readback. These are historical bounded results, not a final candidate or full language/API compatibility.

The initial Node comparison executable path and digest were not recorded. They remain unknown; current Node identity is not retroactively substituted. Frozen historical source snapshots are not claimed to be current Git blobs. Readback authenticates preserved raw observations and does not add an evaluator run or extra compatibility coverage.

Candidate02's first native parser rejected 12 sessions because it did not consume post-close api-error-kind.bin metadata. The failed report and all original raw files remain intact. Its later readback parsed all 1,272 original calls without evaluator reexecution, still leaving 12 ordinary mismatches and 12 post-close raw boundaries. Portable Node/Chromium results remain their separately recorded failed strict gates. Different 1,060/1,272 corpus totals must not be subtracted to infer feature fixes.

Every selected original file is retained, including copied fixtures, source snapshots, tools, outputs, errors, process metadata and recorded provenance limitations. No source/output duplicate exclusion or cache-name filter is applied to the nine explicit closed roots. CAPTURE_SELECTION.json records exact original paths, hashes, sizes and modes. Archive creation, separate verification, raw-member readback and original guards are recorded by the preparation producer. No Java, evaluator, native engine, browser, or build was run while packaging.
""")
 archive=A/('stage51-early-'+unit+'-history.tar.gz');execute(unit+'-create',[sys.executable,'-B',evidence,'create',gather,archive]);need(archive.stat().st_size<100_000_000,'archive over100MB; logical split required');execute(unit+'-verify',[sys.executable,'-B',evidence,'verify',archive])
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();need(len(members)==len({m.name for m in members})and all(m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts for m in members),'unsafe or duplicate archive members');actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in members};expected={'originals/'+x['root']+'/'+x['relative']:x['sha256']for x in rows};expected.update({name:sha(gather/name)for name in ['CAPTURE_SELECTION.json','SCOPE.json','README.md']});need(set(actual)==set(expected)|{'EVIDENCE.json'},'archive exact path coverage differs');need(all(actual[n]==h for n,h in expected.items()),'raw member/source hash differs')
 row={'unit':unit,'path':str(archive),'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'payloadFiles':len(expected),'originalFiles':len(rows),'originalBytes':sum(x['bytes']for x in rows),'createExitCode':0,'separateVerifyExitCode':0,'allRawMembersReadBack':True};archives.append(row);save(O/'archive-progress.json',archives)
# Preserve full historical pathsets under the six closed roots. Receipt directory siblings may legitimately grow.
actual_files=set();actual_dirs={}
for root in s['roots'].values():
 todo=[Path(root)]
 while todo:
  p=todo.pop();need(not p.is_symlink(),'original path became symlink');m=p.stat().st_mode
  if stat.S_ISDIR(m):actual_dirs[str(p)]=stat.S_IMODE(m);todo.extend(Path(e.path)for e in os.scandir(p))
  else:need(stat.S_ISREG(m),'nonregular original path');actual_files.add(str(p))
closed_expected={r['sourcePath']for r in s['rows']if r['root']in s['roots']};expected_dirs={x['path']:x['mode']for x in s['directories']};need(actual_files==closed_expected and actual_dirs==expected_dirs,'closed original pathset/directory mode changed')
changes=[]
for row in s['rows']:
 p=Path(row['sourcePath'])
 if not p.is_file()or p.is_symlink()or sha(p)!=row['sha256']or p.stat().st_size!=row['bytes']or stat.S_IMODE(p.stat().st_mode)!=row['mode']:changes.append(str(p))
for p,row in inputs.items():need(sha(Path(p))==row['sha256'],'packaging input drift')
# Historical missing runtime identities are never backfilled from current executables.
need(not changes,'original payload changed');save(O/'original-guard.json',{'filesChecked':len(s['rows']),'originalChanges':changes,'sizeAndModesChecked':True,'nineClosedRootsPathsetAndDirectoryModesEqual':True,'receiptScope':'Only the nine explicit closed roots are selected; all files within them are retained.','liveCratesNeverCompared':True,'frozenSnapshotsValidated':s['sourceSnapshotGuards']})
report={'status':'CLOSED-static-package-of-early-history','archives':archives,'compressedBytes':sum(x['compressedBytes']for x in archives),'commands':commands,'selectionSha256':sha(O/'selection.json'),'originalGuardSha256':sha(O/'original-guard.json'),'originalChanges':[],'allBelow100000000':True,'allPayloadsRetainedWithoutDeduplication':True,'noSourceReportsGitMutation':True,'newEngineExecutions':0,'finishedUtc':now()};save(O/'archive-report.json',report);print(json.dumps(report),flush=True)
