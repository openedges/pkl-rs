"""Preserve superseded Stage14 local runs without treating them as final passes."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path.cwd();base=root/'target/m2';out=base/'stage14-superseded-evidence';out.mkdir(exist_ok=False)
items={
 'validation-stage14-final':'First required-check sequence failed on historical compile-phase expectation; full raw Rust failure retained.',
 'validation-stage14-command-final':'Original required-check outer command failed; replaced by final-02.',
 'language-stage14-final':'Incomplete acquisition deliberately terminated after test source correction; cancellation.json records reason; no final compatibility count.',
 'language-stage14-command-final':'Original language acquisition outer command recorded SIGTERM; restarted in final-02.',
 'lifecycle-stage14-final':'Pre-correction test source snapshot; original raw outcomes retained; superseded by final-02.',
 'lifecycle-stage14-command-final':'Original lifecycle acquisition command.',
 'prior-selection-stage14-preflight-01':'Prior1380 Java bytes replay with pre-correction recorded candidate; same binary bytes later cross-bound to corrected test source build.',
 'prior-selection-stage14-command-final':'Original retained Java replay command.',
}
for name in items:
 shutil.copytree(base/name,out/name,ignore=shutil.ignore_patterns('build','__pycache__'))
for p in base.glob('stage14-workspace-test-phase-adjustment.*'):
 if p.is_file():shutil.copyfile(p,out/p.name)
shutil.copyfile(__file__,out/Path(__file__).name)
(out/'scope.json').write_text(json.dumps(dict(scope='Historical failed/incomplete/superseded local evidence, not final compatibility or performance success.',items=items,production_changed_by_test_correction=False,corrected_test='crates/pkl-runtime/tests/m2_runtime.rs',final_outputs='language/validation/lifecycle-stage14-final-02; prior-selection-stage14-preflight-02; separate final archives'),indent=2)+'\n')
archive=root/'reports/m2/superseded-stage14-evidence.tar.gz'
subprocess.run([sys.executable,'tools/evidence.py','create',str(out),str(archive)],check=True)
subprocess.run([sys.executable,'tools/evidence.py','verify',str(archive)],check=True)
summary=dict(path=str(archive.relative_to(root)),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),inventory_verified=True,scope='Original failed, interrupted, and superseded captures; no final passing case count.')
(base/'stage14-superseded-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
