import os,sys,json,hashlib,subprocess,platform
from pathlib import Path
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage54-oracle-checkpoint-validation-01'
sys.path.insert(0,str(ROOT/'tools'))
import benchmark
paths=['PLAN.md','docs/m2-deprecation.md','tools/deprecation_fixtures.py','tools/m2_deprecation.py','tools/java/M2DeprecationProbe.java','tools/java/M2DeprecationCyclesProbe.java','tools/tests/test_deprecation_fixtures.py','tools/benchmark.py','tools/oracle.py','oracle.lock.json','references.lock']
paths += [str(p.relative_to(ROOT)) for p in (ROOT/'tests/fixtures/m2-deprecation').rglob('*') if p.is_file()]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=sorted(set(paths));env={k:v for k,v in os.environ.items() if k in ('PATH','HOME','TMPDIR','LANG','LC_ALL','TZ','TERM')};env['PYTHONDONTWRITEBYTECODE']='1'
report={'scope':'Java-only authority/tooling checkpoint; Rust implementation and broader M2 are in progress','host':platform.platform(),'python':sys.version,'python_executable':sys.executable,'python_sha256':digest(Path(sys.executable)),'environment':env,'sources':{p:digest(ROOT/p) for p in paths},'commands':[]}
for name in paths:
 destination=OUT/'sources'/name;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes((ROOT/name).read_bytes())
commands=[('offline-authority',[sys.executable,'tools/deprecation_fixtures.py'],0),('tooling-tests',[sys.executable,'-m','unittest','discover','-s','tools/tests','-p','test_deprecation_fixtures.py'],0),('source-inventory',[sys.executable,'tools/inventory.py','--check'],0),('m2-inventory-observation',[sys.executable,'tools/m2_manifest.py','--check'],1)]
for name,command,expected in commands:
 result=benchmark.capture(command,ROOT,env,OUT/name,timeout=120)
 report['commands'].append({'name':name,'process':result,'expected_exit_for_checkpoint':expected})
 benchmark.write_json(OUT/'report.json',report)
 print(name,result['status'],result['exit_code'],flush=True)
 if result['status']!='executed' or result['exit_code']!=expected:raise RuntimeError('unexpected checkpoint result')
report['sources_after']={p:digest(ROOT/p) for p in paths}
report['source_bytes_stable']=report['sources']==report['sources_after']
benchmark.write_json(OUT/'report.json',report)
assert report['source_bytes_stable']
print('Java checkpoint validation complete; M2 inventory remains stale during uncommitted runtime work',flush=True)
