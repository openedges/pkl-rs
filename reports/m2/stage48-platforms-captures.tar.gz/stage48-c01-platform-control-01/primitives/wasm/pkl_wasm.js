/* @ts-self-types="./pkl_wasm.d.ts" */

export class HostProbe {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        HostProbeFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_hostprobe_free(ptr, 0);
    }
    cancel() {
        wasm.hostprobe_cancel(this.__wbg_ptr);
    }
    close() {
        wasm.hostprobe_close(this.__wbg_ptr);
    }
    /**
     * @returns {string[]}
     */
    drainCancelledReads() {
        const ret = wasm.hostprobe_drainCancelledReads(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {string} mode
     */
    constructor(mode) {
        const ret = wasm.hostprobe_new(mode);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        HostProbeFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} now
     * @param {number} budget
     * @returns {string}
     */
    poll(now, budget) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.hostprobe_poll(this.__wbg_ptr, now, budget);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @param {string} token
     * @param {number} now
     * @param {number} timeout
     */
    reenter(token, now, timeout) {
        const ret = wasm.hostprobe_reenter(this.__wbg_ptr, token, now, timeout);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string} message
     * @param {number} now
     */
    reject(token, message, now) {
        const ret = wasm.hostprobe_reject(this.__wbg_ptr, token, message, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {Uint8Array} value
     * @param {number} now
     */
    respondBytes(token, value, now) {
        const ret = wasm.hostprobe_respondBytes(this.__wbg_ptr, token, value, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {any} value
     * @param {number} now
     */
    respondInteger(token, value, now) {
        const ret = wasm.hostprobe_respondInteger(this.__wbg_ptr, token, value, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {number} now
     * @param {number} timeout
     */
    start(now, timeout) {
        const ret = wasm.hostprobe_start(this.__wbg_ptr, now, timeout);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
}
if (Symbol.dispose) HostProbe.prototype[Symbol.dispose] = HostProbe.prototype.free;

/**
 * Development-only parsed-source session. Logger callbacks run in the caller
 * after poll returns; this object owns no JavaScript callback or I/O semantics.
 */
export class SourceSession {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(SourceSession.prototype);
        obj.__wbg_ptr = ptr;
        SourceSessionFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SourceSessionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_sourcesession_free(ptr, 0);
    }
    /**
     * @param {string} token
     * @param {Uint16Array | null | undefined} failure
     * @param {number} now
     */
    acknowledgeLog(token, failure, now) {
        const ret = wasm.sourcesession_acknowledgeLog(this.__wbg_ptr, token, isLikeNone(failure) ? 0 : addToExternrefTable0(failure), now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    cancel() {
        wasm.sourcesession_cancel(this.__wbg_ptr);
    }
    close() {
        wasm.sourcesession_close(this.__wbg_ptr);
    }
    /**
     * @param {string} token
     */
    closeFromCallback(token) {
        const ret = wasm.sourcesession_closeFromCallback(this.__wbg_ptr, token);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {number}
     */
    collect() {
        const ret = wasm.sourcesession_collect(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * @param {string} token
     * @param {number} now
     * @returns {boolean}
     */
    completeDefaultModule(token, now) {
        const ret = wasm.sourcesession_completeDefaultModule(this.__wbg_ptr, token, now);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * @param {string} token
     * @param {boolean} local
     * @param {boolean} hierarchical
     * @param {boolean} fragment_paths
     * @param {number} now
     */
    completeModuleCapabilities(token, local, hierarchical, fragment_paths, now) {
        const ret = wasm.sourcesession_completeModuleCapabilities(this.__wbg_ptr, token, local, hierarchical, fragment_paths, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {boolean} exists
     * @param {number} now
     */
    completeModuleHasElement(token, exists, now) {
        const ret = wasm.sourcesession_completeModuleHasElement(this.__wbg_ptr, token, exists, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {number} now
     */
    completeModuleImportCheck(token, now) {
        const ret = wasm.sourcesession_completeModuleImportCheck(this.__wbg_ptr, token, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string} original_uri
     * @param {string} resolved_uri
     * @param {string} source_uri
     * @param {number} now
     */
    completeModuleResolution(token, original_uri, resolved_uri, source_uri, now) {
        const ret = wasm.sourcesession_completeModuleResolution(this.__wbg_ptr, token, original_uri, resolved_uri, source_uri, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string} text
     * @param {string} inferred_name
     * @param {number} now
     */
    completeModuleSource(token, text, inferred_name, now) {
        const ret = wasm.sourcesession_completeModuleSource(this.__wbg_ptr, token, text, inferred_name, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {number} now
     */
    completeReadMissing(token, now) {
        const ret = wasm.sourcesession_completeReadMissing(this.__wbg_ptr, token, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string} uri
     * @param {Uint8Array} bytes
     * @param {number} now
     */
    completeReadResource(token, uri, bytes, now) {
        const ret = wasm.sourcesession_completeReadResource(this.__wbg_ptr, token, uri, bytes, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {Uint16Array} units
     * @param {number} now
     */
    completeReadText(token, units, now) {
        const ret = wasm.sourcesession_completeReadText(this.__wbg_ptr, token, units, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {number}
     */
    contextDepth() {
        const ret = wasm.sourcesession_contextDepth(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @returns {string[]}
     */
    drainCancelledModules() {
        const ret = wasm.sourcesession_drainCancelledModules(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @returns {string[]}
     */
    drainCancelledReads() {
        const ret = wasm.sourcesession_drainCancelledReads(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {string} source
     * @param {string} uri
     * @param {string} module_name
     * @param {Array<any>} paths
     * @param {string | null} [trace_mode]
     * @param {boolean | null} [host_logger]
     * @param {boolean | null} [host_frame_transformer]
     * @param {boolean | null} [power_assertions]
     * @returns {SourceSession}
     */
    static forExpressions(source, uri, module_name, paths, trace_mode, host_logger, host_frame_transformer, power_assertions) {
        const ret = wasm.sourcesession_forExpressions(source, uri, module_name, paths, isLikeNone(trace_mode) ? 0 : addToExternrefTable0(trace_mode), isLikeNone(host_logger) ? 0xFFFFFF : host_logger ? 1 : 0, isLikeNone(host_frame_transformer) ? 0xFFFFFF : host_frame_transformer ? 1 : 0, isLikeNone(power_assertions) ? 0xFFFFFF : power_assertions ? 1 : 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SourceSession.__wrap(ret[0]);
    }
    /**
     * @param {string} source
     * @param {string} uri
     * @param {string} module_name
     * @param {Array<any>} paths
     * @param {Array<any>} _arguments
     * @param {string | null} [trace_mode]
     * @param {boolean | null} [host_logger]
     * @param {boolean | null} [host_frame_transformer]
     * @param {boolean | null} [power_assertions]
     * @returns {SourceSession}
     */
    static forOutput(source, uri, module_name, paths, _arguments, trace_mode, host_logger, host_frame_transformer, power_assertions) {
        const ret = wasm.sourcesession_forOutput(source, uri, module_name, paths, _arguments, isLikeNone(trace_mode) ? 0 : addToExternrefTable0(trace_mode), isLikeNone(host_logger) ? 0xFFFFFF : host_logger ? 1 : 0, isLikeNone(host_frame_transformer) ? 0xFFFFFF : host_frame_transformer ? 1 : 0, isLikeNone(power_assertions) ? 0xFFFFFF : power_assertions ? 1 : 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SourceSession.__wrap(ret[0]);
    }
    /**
     * @returns {number}
     */
    heapSlots() {
        const ret = wasm.sourcesession_heapSlots(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] >>> 0;
    }
    /**
     * @param {string} source
     * @param {string} uri
     * @param {string} module_name
     * @param {Array<any>} paths
     * @param {string | null} [trace_mode]
     * @param {boolean | null} [host_logger]
     * @param {boolean | null} [host_frame_transformer]
     * @param {boolean | null} [power_assertions]
     */
    constructor(source, uri, module_name, paths, trace_mode, host_logger, host_frame_transformer, power_assertions) {
        const ret = wasm.sourcesession_new(source, uri, module_name, paths, isLikeNone(trace_mode) ? 0 : addToExternrefTable0(trace_mode), isLikeNone(host_logger) ? 0xFFFFFF : host_logger ? 1 : 0, isLikeNone(host_frame_transformer) ? 0xFFFFFF : host_frame_transformer ? 1 : 0, isLikeNone(power_assertions) ? 0xFFFFFF : power_assertions ? 1 : 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        SourceSessionFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {number} now
     * @param {number} budget
     * @returns {any}
     */
    poll(now, budget) {
        const ret = wasm.sourcesession_poll(this.__wbg_ptr, now, budget);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {string} token
     * @param {number} now
     * @param {number | null} [timeout]
     */
    reenterOutputBytes(token, now, timeout) {
        const ret = wasm.sourcesession_reenterOutputBytes(this.__wbg_ptr, token, now, !isLikeNone(timeout), isLikeNone(timeout) ? 0 : timeout);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {number} index
     * @param {number} now
     * @param {number | null} [timeout]
     */
    reenterPath(token, index, now, timeout) {
        const ret = wasm.sourcesession_reenterPath(this.__wbg_ptr, token, index, now, !isLikeNone(timeout), isLikeNone(timeout) ? 0 : timeout);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string} message
     * @param {number} now
     */
    reject(token, message, now) {
        const ret = wasm.sourcesession_reject(this.__wbg_ptr, token, message, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string} kind
     * @param {string | null | undefined} message
     * @param {number} now
     */
    rejectModuleImportCheck(token, kind, message, now) {
        const ret = wasm.sourcesession_rejectModuleImportCheck(this.__wbg_ptr, token, kind, isLikeNone(message) ? 0 : addToExternrefTable0(message), now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {boolean} has_element
     * @param {string} kind
     * @param {string | null | undefined} message
     * @param {number} now
     */
    rejectModulePreparation(token, has_element, kind, message, now) {
        const ret = wasm.sourcesession_rejectModulePreparation(this.__wbg_ptr, token, has_element, kind, isLikeNone(message) ? 0 : addToExternrefTable0(message), now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string} kind
     * @param {string | null | undefined} message
     * @param {number} now
     */
    rejectModuleResolution(token, kind, message, now) {
        const ret = wasm.sourcesession_rejectModuleResolution(this.__wbg_ptr, token, kind, isLikeNone(message) ? 0 : addToExternrefTable0(message), now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string} kind
     * @param {string | null | undefined} message
     * @param {number} now
     */
    rejectModuleSource(token, kind, message, now) {
        const ret = wasm.sourcesession_rejectModuleSource(this.__wbg_ptr, token, kind, isLikeNone(message) ? 0 : addToExternrefTable0(message), now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string | null | undefined} message
     * @param {number} now
     */
    rejectReadIo(token, message, now) {
        const ret = wasm.sourcesession_rejectReadIo(this.__wbg_ptr, token, isLikeNone(message) ? 0 : addToExternrefTable0(message), now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {string | null | undefined} message
     * @param {number} now
     */
    rejectReadSecurityManager(token, message, now) {
        const ret = wasm.sourcesession_rejectReadSecurityManager(this.__wbg_ptr, token, isLikeNone(message) ? 0 : addToExternrefTable0(message), now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @returns {string}
     */
    resolvedReadUri(token) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.sourcesession_resolvedReadUri(this.__wbg_ptr, token);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * @param {string} token
     * @param {Uint8Array} value
     * @param {number} now
     */
    respondBytes(token, value, now) {
        const ret = wasm.sourcesession_respondBytes(this.__wbg_ptr, token, value, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {number} now
     */
    respondConfigured(token, now) {
        const ret = wasm.sourcesession_respondConfigured(this.__wbg_ptr, token, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {any} value
     * @param {number} now
     */
    respondInteger(token, value, now) {
        const ret = wasm.sourcesession_respondInteger(this.__wbg_ptr, token, value, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} token
     * @param {Uint16Array} value
     * @param {number} now
     */
    respondString(token, value, now) {
        const ret = wasm.sourcesession_respondString(this.__wbg_ptr, token, value, now);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @returns {boolean}
     */
    setupFailed() {
        const ret = wasm.sourcesession_setupFailed(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {number} now
     * @param {number | null} [timeout]
     */
    startModule(now, timeout) {
        const ret = wasm.sourcesession_startModule(this.__wbg_ptr, now, !isLikeNone(timeout), isLikeNone(timeout) ? 0 : timeout);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {number} now
     * @param {number | null} [timeout]
     */
    startOutputBytes(now, timeout) {
        const ret = wasm.sourcesession_startOutputBytes(this.__wbg_ptr, now, !isLikeNone(timeout), isLikeNone(timeout) ? 0 : timeout);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {number} index
     * @param {number} now
     * @param {number | null} [timeout]
     */
    startPath(index, now, timeout) {
        const ret = wasm.sourcesession_startPath(this.__wbg_ptr, index, now, !isLikeNone(timeout), isLikeNone(timeout) ? 0 : timeout);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
}
if (Symbol.dispose) SourceSession.prototype[Symbol.dispose] = SourceSession.prototype.free;

/**
 * @param {string} source
 * @param {string} member
 * @returns {string}
 */
export function evaluate(source, member) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.evaluate(source, member);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * Development-only scalar boundary with shared Pkl diagnostic rendering.
 * @param {string} source
 * @param {string} uri
 * @param {string} module_name
 * @param {string} expression
 * @param {boolean | null} [power_assertions]
 * @returns {string}
 */
export function evaluateLanguage(source, uri, module_name, expression, power_assertions) {
    const ret = wasm.evaluateLanguage(source, uri, module_name, expression, isLikeNone(power_assertions) ? 0xFFFFFF : power_assertions ? 1 : 0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Development-only ordered calls on one evaluator, retaining failures as data.
 * @param {string} source
 * @param {string} uri
 * @param {string} module_name
 * @param {Array<any>} expressions
 * @param {boolean | null} [power_assertions]
 * @returns {Array<any>}
 */
export function evaluateLanguageSequence(source, uri, module_name, expressions, power_assertions) {
    const ret = wasm.evaluateLanguageSequence(source, uri, module_name, expressions, isLikeNone(power_assertions) ? 0xFFFFFF : power_assertions ? 1 : 0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Portable frontend bytes; no native process exit or generated-files execution.
 * @param {string} source
 * @param {string} uri
 * @param {string} module_name
 * @param {Array<any>} _arguments
 * @returns {object}
 */
export function evaluateModuleFrontend(source, uri, module_name, _arguments) {
    const ret = wasm.evaluateModuleFrontend(source, uri, module_name, _arguments);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Actual shared module-output bytes; PCF and encoding stay in pkl-runtime.
 * @param {string} source
 * @param {string} uri
 * @param {string} module_name
 * @param {Array<any>} _arguments
 * @returns {object}
 */
export function evaluateModuleOutput(source, uri, module_name, _arguments) {
    const ret = wasm.evaluateModuleOutput(source, uri, module_name, _arguments);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} family
 * @param {string} input
 * @returns {string}
 */
export function primitive(family, input) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.primitive(family, input);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * @param {Uint8Array} input
 * @returns {Uint8Array}
 */
export function roundtripBytes(input) {
    const ret = wasm.roundtripBytes(input);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {any} input
 * @returns {bigint}
 */
export function roundtripInteger(input) {
    const ret = wasm.roundtripInteger(input);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * @param {string} input
 * @returns {string}
 */
export function roundtripString(input) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.roundtripString(input);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_is_bigint_31b12575b56f32fc: function(arg0) {
            const ret = typeof(arg0) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_string_cd444516edc5b180: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_throw_be289d5034ed271b: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_charCodeAt_8fdb057472688076: function(arg0, arg1) {
            const ret = arg0.charCodeAt(arg1 >>> 0);
            return ret;
        },
        __wbg_fromCharCode_8308cf0e9395e68f: function(arg0, arg1) {
            const ret = String.fromCharCode(...getArrayU16FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_get_9b94d73e6221f75c: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_instanceof_Uint16Array_008d03ef5a72e61d: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint16Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_9b9075935c74707c: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_join_b065ddca98fcc640: function(arg0, arg1, arg2) {
            const ret = arg0.join(getStringFromWasm0(arg1, arg2));
            return ret;
        },
        __wbg_length_32ed9a279acd054c: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_35a7bace40f36eac: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_68dc7c5cf1b6d349: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_8ce069301528a78d: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_new_361308b2356cecd0: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_3eb36ae241fe6f44: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_72b49615380db768: function(arg0, arg1) {
            const ret = new Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_from_slice_980b409db81dc3eb: function(arg0, arg1) {
            const ret = new Uint16Array(getArrayU16FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_from_slice_a3d2629dc1826784: function(arg0, arg1) {
            const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_prototypesetcall_2adb484744144f7f: function(arg0, arg1, arg2) {
            Uint16Array.prototype.set.call(getArrayU16FromWasm0(arg0, arg1), arg2);
        },
        __wbg_prototypesetcall_bdcdcc5842e4d77d: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_push_8ffdcb2063340ba5: function(arg0, arg1) {
            const ret = arg0.push(arg1);
            return ret;
        },
        __wbg_set_6cb8631f80447a67: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(arg0, arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_toString_3cadee6e7c22b39e: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.toString(arg1);
            return ret;
        }, arguments); },
        __wbindgen_cast_0000000000000001: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000002: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./pkl_wasm_bg.js": import0,
    };
}

const HostProbeFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_hostprobe_free(ptr >>> 0, 1));
const SourceSessionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_sourcesession_free(ptr >>> 0, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU16FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint16ArrayMemory0().subarray(ptr / 2, ptr / 2 + len);
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint16ArrayMemory0 = null;
function getUint16ArrayMemory0() {
    if (cachedUint16ArrayMemory0 === null || cachedUint16ArrayMemory0.byteLength === 0) {
        cachedUint16ArrayMemory0 = new Uint16Array(wasm.memory.buffer);
    }
    return cachedUint16ArrayMemory0;
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

let wasmModule, wasm;
function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedUint16ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('pkl_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
