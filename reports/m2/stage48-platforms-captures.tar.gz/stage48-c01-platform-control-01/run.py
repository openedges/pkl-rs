from pathlib import Path
import datetime,hashlib,json,os,platform,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
RELEASE=ROOT/'target/m2/stage48-implementation-01/admission-candidate-build-01/release.json'
PIN='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.UTC).isoformat()
assert sha(RELEASE)==PIN
release=json.loads(RELEASE.read_bytes())
source_map=Path(release['source_map']);assert sha(source_map)==release['source_map_sha256']
sources=json.loads(source_map.read_bytes())
def changes():return [p for p,h in sources.items() if not(ROOT/p).is_file() or sha(ROOT/p)!=h]
assert not changes(),'live sources differ from C01 before platform builds'
assert not os.environ.get('CARGO_TARGET_DIR'),'m1_platforms uses explicit default target paths'
report={'scope':'Actual native/Node/Chromium shared primitive and provider integration from frozen Stage48 C01. Integrity/process completion is distinct from raw compatibility gates; all mismatches retained. Bootstrap legacy and new policy84 have separately scheduled acquisitions. No complete M2 or performance claim.','startedUtc':now(),'cwd':str(ROOT),'host':platform.platform(),'candidateRelease':str(RELEASE),'candidateReleaseSha256':PIN,'sourceMapSha256':release['source_map_sha256'],'sourceCount':len(sources),'python':sys.executable,'pythonVersion':sys.version,'pythonSha256':sha(Path(sys.executable)),'commands':[],'complete':False,'infrastructureErrors':[]}
write(OUT/'report.json',report)
env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'}
def execute(label,argv,output):
 row={'label':label,'argv':list(map(str,argv)),'cwd':str(ROOT),'output':str(output),'startedUtc':now(),'environment':{k:env.get(k) for k in ['CARGO_TARGET_DIR','JAVA_HOME','PKL_ORACLE_JAVA','RUSTUP_TOOLCHAIN','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','PYTHONDONTWRITEBYTECODE','LANG','LC_ALL','TZ']}}
 with(OUT/(label+'.stdout.bin')).open('wb')as stdout,(OUT/(label+'.stderr.bin')).open('wb')as stderr:
  process=subprocess.Popen(row['argv'],cwd=ROOT,env=env,stdout=stdout,stderr=stderr);row['pid']=process.pid;write(OUT/'active.json',row);row['exitCode']=process.wait()
 row.update(finishedUtc=now(),stdoutSha256=sha(OUT/(label+'.stdout.bin')),stderrSha256=sha(OUT/(label+'.stderr.bin')))
 report['commands'].append(row);write(OUT/(label+'.terminal.json'),row);write(OUT/'report.json',report)
 print(json.dumps({'label':label,'exitCode':row['exitCode']}),flush=True)
 return row['exitCode']
platforms=OUT/'primitives'
code=execute('primitives',[sys.executable,'tools/m1_platforms.py','--output',platforms,'--verify-contract'],platforms)
if code!=0:
 report['infrastructureErrors'].append('Primitive build/acquisition or experiment contract failed; dependent integration was not started.')
else:
 p=json.loads((platforms/'report.json').read_bytes())
 assert p['source_stability'] and all(sources.get(k)==v for k,v in p['source_hashes'].items())
 report['primitiveGate']={key:p[key] for key in ['total','oracle_passed','shared_engine_passed','compatibility_status','experiment_contract_status','known_gaps']}
 artifact_hashes={str(q.relative_to(platforms)):sha(q)for q in [platforms/'pkl_napi.node',platforms/'semantics_probe',*(platforms/'wasm').iterdir()] if q.is_file()}
 report['platformArtifactHashes']=artifact_hashes
 cases=[('renderer','compare-renderer.mjs','m2-renderer-portable',True,None),('resource','compare-resource.mjs','m2-resource-portable',True,None),('module-preparation','compare-module-preparation.mjs','m2-module-portable',True,None),('moduleinfo','compare-moduleinfo.mjs','m2-moduleinfo',True,None),('security-denial','compare-security-denial.mjs','m2-security-denial',True,None),('guest-catch','compare-guest-catch.mjs','m2-guest-catch',True,None),('module-loader','compare-module-loader.mjs','m2-module-loading',False,None),('module-inheritance','compare-module-loader.mjs','m2-module-inheritance-platform',False,'module_inheritance_fixtures.py')]
 for label,driver,fixture,package,verifier in cases:
  output=OUT/label
  argv=['node',ROOT/'tools/platform'/driver,output,platforms/'wasm',platforms/'pkl_napi.node',ROOT/'tests/fixtures'/fixture]
  if package:argv+=[ROOT/'tools/platform/package.json']
  if verifier:argv+=[ROOT/'tools'/verifier]
  execute(label,argv,output)
 report['platformArtifactsStable']=all(sha(platforms/name)==h for name,h in artifact_hashes.items())
report['sourceChanges']=changes();report['complete']=True;report['finishedUtc']=now();report['liveHandles']=[]
write(OUT/'report.json',report)
write(OUT/'active.json',{'complete':True,'finishedUtc':report['finishedUtc'],'liveHandles':[]})
print(json.dumps({'complete':True,'sourceChanges':report['sourceChanges'],'commands':[{k:r[k]for k in ['label','exitCode']}for r in report['commands']]}),flush=True)
raise SystemExit(int(bool(report['sourceChanges'] or report['infrastructureErrors'] or not report.get('platformArtifactsStable',False))))
