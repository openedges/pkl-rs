# Exact-commit CI evidence

Repository: `luuvish/pkl-rs`
Commit: `52cabbe01a8392ee44bf55889346c6f692d3c595`
Run: https://github.com/luuvish/pkl-rs/actions/runs/39543295843

The original GitHub artifact ZIPs are retained byte-for-byte. Their SHA-256 digests
match GitHub metadata. Raw language comparisons, identifier regeneration and M1
native/Node/browser, frontend, runtime and lifecycle evidence were independently
checked against exact committed source snapshots. Recorded failures and incomplete
full language/API/performance requirements remain failures and incomplete scope.
See `verification/verification.json` for all outcomes and source/file counts.

## Repeat the independent check

Use Python 3.12 or newer and Git. A repository with the exact commit object above
and its pinned `external/pkl` submodule commit is required. No Java, Rust, Node or
browser process is executed by the verifier. The working tree can be elsewhere;
recorded absolute CI source URIs are preserved for raw comparison.

From this package directory, choose a fresh output directory:

```sh
python3 verification/unpack_and_verify.py --repository-root /path/to/pkl-rs --output /tmp/pkl-ci-recheck
```

The helper checks the complete package inventory, GitHub ZIP digests and safe ZIP
paths, then imports only captured project verifier sources already checked against
the exact Git commit. Python bytecode writes are disabled. Source sets, case and
scenario counts, and identifier interval counts come from frozen contracts.

`package-manifest.json` hashes every package file except itself. Extracted payload,
the duplicate verified-source overlay and empty committed-path index are omitted;
the two original ZIPs retain all captured payload bytes.
