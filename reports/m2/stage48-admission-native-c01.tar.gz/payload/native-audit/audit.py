from pathlib import Path
import collections,hashlib,json,os,re,stat
O=Path(__file__).parent.resolve();B=O.parent;P=B/'stage48-policy-native-c01-01';C=B/'stage48-policy-native-consumer-02';L=B/'stage48-policy-native-c01-launch-01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
check_count=0
def check(ok,message):
 global check_count
 if not ok:raise AssertionError(message)
 check_count+=1
def counters(data):return dict((k,int(v))for k,v in (line.split('=')for line in data.decode().splitlines()))
report=json.loads((P/'report.json').read_bytes());terminal=json.loads((L/'terminal.json').read_bytes());bundle=json.loads((C/'inputs/inputs.json').read_bytes());cases={c['key']:c for c in bundle['cases']};preflight=json.loads((P/'preflight.json').read_bytes());check(terminal['exitCode']==0 and terminal['sourceBefore']==terminal['sourceAfter']and not terminal['liveHandles'],'actual89927terminal0/PID33294/sourceStable');check(sha(P/'report.json')=='e5c093e9e450a949d32a87c0c2a37a15c67f4c857d8840f3f4d4424d69e92f14','raw report literal pin');check(preflight['releaseSha256']=='04881b69a3ec7e063dbe1cf594e7ddbfb358854fc17bca8f29e21d3f3c179dc0','release pin');check(preflight['artifactSha256']=='e54013aee4241c2d928e284f5623f8d47476eae107ebc5bea03030c4b354a3dc','artifact pin');check(sha(C/'inputs/manifest.json')=='711558cc972753d9ceb4b259c16b5b2b2cea48c2987e0bc97d1807255d2b031f','input manifest pin');check(not report['sourceChanges']and report['artifactStable']and report['toolsStable'],'capture inputs stable')
for rel,row in json.loads((C/'inventory.json').read_bytes())['files'].items():check(sha(C/rel)==row['sha256'],'tool frozen inventory '+rel)
for path,digest in preflight['sourceBefore'].items():check(sha(Path(path))==digest,'original input still unchanged '+path)
api=collections.Counter();cohorts=collections.defaultdict(lambda:{'api':0,'success':0,'error':0,'sessions':0,'edgeProjectionEqual':0});requests=[];edge_comparisons=[];statuses=[];request_kinds=collections.Counter()
for record in report['records']:
 process=record['process'];key=process['key'];case=cases[key];d=P/key;raw=d/'raw/session-0';check(process['exitCode']==0 and not process['timedOut'],'child terminal '+key);check(json.loads((d/'terminal.json').read_bytes())==process,'child terminal rawreport');check(sha(d/'stdout.bin')==process['stdoutSha256']and sha(d/'stderr.bin')==process['stderrSha256'],'process raw streams');check((raw/'terminal-slots.bin').read_bytes()==b'0','closed source slots0');check(not record['constructorBoundary'],'constructor reached all APIs');tally=cohorts[case['cohort']];tally['sessions']+=1
 for index,e in enumerate(case['expected']):
  prefix=raw/f'outer-{index}';status=prefix.with_name(prefix.name+'.status.bin').read_bytes();check(status==e['status'].encode()+b'\n','exact status');api[status.decode()]+=1;tally['api']+=1;tally[e['status']]+=1
  for channel in ['stdout','stderr']:
   b=prefix.with_name(prefix.name+'.'+channel+'.bin').read_bytes();u=prefix.with_name(prefix.name+'.'+channel+'.code-units.bin').read_bytes();check(b.hex()==e[channel+'Hex'],'complete JavaUTF8 channel');check(u==b''.join(v.to_bytes(2,'big')for v in e[channel+'Units']),'complete JavaUTF16 channel');check(u.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==b,'actual channel encoding relation')
  before=counters((raw/f'outer-{index}.counters-before.bin').read_bytes());after=counters((raw/f'outer-{index}.counters-after.bin').read_bytes());check(list(before)==['requests','import','resolve','event']and list(after)==list(before),'native actual counter schema');check(all(after[k]>=before[k]for k in before),'counter monotonicity');check(record['api'][index]['pass'],'producer raw pass independently confirmed')
 final=counters((raw/'counters.bin').read_bytes());seen_tokens=set();ids=[];kinds=collections.Counter();native_events=[]
 for i in range(final['event']):
  b=(raw/f'event-{i}.text.bin').read_bytes();u=(raw/f'event-{i}.text.code-units.bin').read_bytes();check(u.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==b,'actual observer UTF16/JavaUTF8');native_events.append(b.hex())
 check(native_events==record['nativeEvents'],'complete native event ledger raw/report')
 for i in range(final['requests']):
  prefix=raw/f'module-{i}';get=lambda suffix:prefix.with_name(prefix.name+'.'+suffix).read_bytes();token=get('token.bin').decode();id=get('id.bin').decode();kind=get('kind.bin').decode();call_index=int(get('api-index.bin'));check(re.fullmatch(r'\d+:\d+:\d+',token)is not None and token not in seen_tokens,'actual unique connected token');seen_tokens.add(token);check(id.isdecimal(),'actual decimal module request ID');ids.append(int(id));check(0<=call_index<len(case['expected']),'request API owner');kinds[kind]+=1;request_kinds[kind]+=1
  row={'case':key,'ordinal':i,'token':token,'id':id,'kind':kind,'callIndex':call_index,'policy':get('policy.bin').decode(),'requestDebugUtf8Hex':get('request.bin').hex(),'completionDebugUtf8Hex':get('completion.bin').hex()}
  for field in ['importer-original-uri','importer-resolved-uri','import-uri','original-uri','resolved-uri','source-uri']:
   q=prefix.with_name(prefix.name+'.'+field+'.bin')
   if q.exists():row[field]=q.read_text()
  if kind in ['check-import','resolve']:
   check(all(field in row for field in ['importer-original-uri','importer-resolved-uri','import-uri']),'full import context captured')
  requests.append(row)
 check(ids==sorted(set(ids)),'monotonic unique module IDs');check(kinds['check-import']==final['import']and kinds['resolve']==final['resolve'],'actual request/counter relation')
 java_edge=[e['utf8Hex']for e in case['javaOrderedEvents']if bytes.fromhex(e['utf8Hex']).startswith(b'policy-import ')];native_edge=[e for e in native_events if bytes.fromhex(e).startswith(b'policy-import ')];same=java_edge==native_edge;tally['edgeProjectionEqual']+=same;edge_comparisons.append({'case':key,'diagnosticOnly':True,'replacesNoFullGate':True,'javaOriginalPolicyImportUtf8Hex':java_edge,'nativeActualPolicyImportUtf8Hex':native_edge,'equal':same,'qualification':None if same else'Supplied-primary symlink identity is entry.pkl in native versus resolved actual/main.pkl in Java; full lifecycle still unimplemented.'})
 check(not record['fullEventBytesEqual']and not record['fullCounterBytesEqual']and not record['fullLifecyclePass'],'full strict lifecycle remains failed')
check(sum(api.values())==440 and report['rawApiPass']==440 and report['rawApiMismatchOrUnexecuted']==0,'440raw independently pass');check(len(report['records'])==52,'52 actual process/session records');check(sum(x['apis']for x in report['unexecutedProfiles'])==212,'212unexecuted preserved');check(sum(x['equal']for x in edge_comparisons)==48,'48/52 edge projection diagnostic only')
write(O/'actual-typed-requests.json',requests);write(O/'edge-projection-diagnostic.json',edge_comparisons)
summary={'scope':'C01 supplied-primary native raw API observations only; full lifecycle remains unpassed. No new evaluation during audit.','independentChecks':check_count,'checkFailures':0,'nativeApi':{'rawPass':440,'mismatch':0,'explicitUnexecuted':212,'statusCounts':dict(api)},'processes':52,'allProcessExit0':True,'allTerminalSlots0':True,'fullLifecycle':{'passSessions':0,'failedSessions':52,'qualification':'Missing actual primary/repl/factory/path callbacks plus different nativeobserver counter schema; not a claim that all mismatches are runtime-only defects.'},'edgeProjectionDiagnosticOnly':{'equalSessions':48,'differentSessions':4,'reason':'Actual primary symlink resolved importer identity is unavailable in supplied-primary SourceProbe.','replacesNoFullGate':True},'requestKinds':dict(request_kinds),'typedRequests':len(requests),'cohorts':dict(cohorts),'intentNotReachedOriginalApiRows':{'queryTestNameFailures':16,'lazyCycleNoFailure':36,'keptRaw':True},'sourceChanges':[],'artifactStable':True,'toolsStable':True,'gc':'ActualJavaSystem.gc requested only; native per-poll/explicit collection and processlayout differ.','actualToolHandle':89927,'actualDriverPid':33294,'liveHandles':[]};write(O/'report.json',summary)
# Snapshot terminal producer and wrapper trees after all processes finished. Exact known trees, no cache traversal.
for root,label in [(P,'native'),(L,'launcher')]:
 files={}
 def visit(q):
  for e in sorted(os.scandir(q),key=lambda e:e.name):
   child=Path(e.path);s=child.lstat()
   if stat.S_ISDIR(s.st_mode):visit(child)
   else:check(stat.S_ISREG(s.st_mode),'regular evidence');files[str(child.relative_to(root))]={'sha256':sha(child),'bytes':s.st_size,'mode':stat.S_IMODE(s.st_mode)}
 visit(root);write(O/(label+'-payload-inventory.json'),{'root':str(root),'files':files,'prewalkPrune':[]});check(all(sha(root/n)==r['sha256']for n,r in files.items()),'postterminal producer payload rehash')
write(O/'handoff.json',{'nativeRoot':str(P),'nativeReportSha256':sha(P/'report.json'),'nativeLaunchRoot':str(L),'nativeTerminalSha256':sha(L/'terminal.json'),'independentReportSha256':sha(O/'report.json'),'typedRequestLedgerSha256':sha(O/'actual-typed-requests.json'),'edgeDiagnosticSha256':sha(O/'edge-projection-diagnostic.json'),'nativePayloadInventorySha256':sha(O/'native-payload-inventory.json'),'launcherPayloadInventorySha256':sha(O/'launcher-payload-inventory.json'),'consumerHandoff':str(C/'handoff.json'),'consumerHandoffSha256':'1b46e7b1be091b166191be07d740bd969f540b5887821ce6a2ce395cf6e03496','fullM2Complete':False,'liveHandles':[]})
files={p.name:{'sha256':sha(p),'bytes':p.stat().st_size}for p in O.iterdir()if p.is_file()};write(O/'inventory.json',{'files':files});write(O/'closure.json',{'closed':True,'handoffSha256':sha(O/'handoff.json'),'inventorySha256':sha(O/'inventory.json'),'allPayloadHashesVerified':all(sha(O/n)==r['sha256']for n,r in files.items()),'liveHandles':[]});print(json.dumps(summary,indent=2));print('handoffSHA',sha(O/'handoff.json'))
