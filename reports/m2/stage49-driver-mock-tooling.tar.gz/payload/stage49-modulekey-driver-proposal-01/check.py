from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
O=Path(__file__).resolve().parent;R=O.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
unit=R/'target/m2/stage49-modulekey-session-unit-03/report.json';u=json.loads(unit.read_bytes())
for rel,h in u['after'].items():assert sha(R/rel)==h,rel
paths=[R/'tools/platform'/n for n in ['compare-modulekey.mjs','compare-modulekey.test.mjs','modulekey-session.mjs','module-policy-session.mjs','resource-session.mjs']]+[R/'target/m2/stage49-oracle-spi-tools-02/modulekey_fixtures.py',R/'target/m2/stage49-oracle-spi-fixtures-01/manifest.json',R/'target/m2/stage49-oracle-spi-host-profile-01/host-metadata.json']
before={str(p):sha(p)for p in paths};write(O/'source-before.json',before)
records=[]
commands=[['node','--check',str(paths[0])],['node','--check',str(paths[1])],['node','--test',str(paths[1])],json.loads((O/'planned-preflight.json').read_bytes())['command']]
for i,command in enumerate(commands):
    d=O/('command-'+str(i));d.mkdir(exist_ok=False);row={'command':command,'cwd':str(R),'parentPid':os.getpid(),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Syntax/unit/real-fixture preflight-only with explicitly mocked artifact/browser bytes; no actual Rust/binding/browser execution'}
    with(d/'stdout.bin').open('wb')as out,(d/'stderr.bin').open('wb')as err:
        p=subprocess.Popen(command,cwd=R,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=out,stderr=err);row['pid']=p.pid;write(d/'launch.json',row);row['exitCode']=p.wait()
    row.update(finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=sha(d/'stdout.bin'),stderrSha256=sha(d/'stderr.bin'));write(d/'terminal.json',row);records.append(row)
    if row['exitCode']!=0:break
after={str(p):sha(p)for p in paths};write(O/'source-after.json',after)
execution=O/'mock-preflight/execution.json';result=json.loads(execution.read_bytes())if execution.is_file()else None
report={'schema':1,'records':records,'allCommandsZero':len(records)==4 and all(r['exitCode']==0 for r in records),'sourceStable':before==after,'changedSources':[p for p,h in before.items()if after[p]!=h],'rootHelperUnitReport':str(unit),'rootHelperUnitReportSha256':sha(unit),'preflightExecutionSha256':sha(execution)if execution.is_file()else None,'preflightOnly':None if result is None else result['preflightOnly'],'rawApiPassed':None if result is None else result['rawApiPassed'],'actualEngineExecutions':0,'actualBrowserLaunches':0,'mockQualification':'Mock addon/Wasm/browser bytes are intentionally not executable. Actual preflight uses original authenticated Java fixtures, source facts and verifier only.'}
if result is not None:assert result['preflightOnly'] and not result['rawApiPassed'] and not result['targets']
write(O/'report.json',report);print(json.dumps(report,indent=2));raise SystemExit(0 if report['allCommandsZero']and report['sourceStable']else 1)
