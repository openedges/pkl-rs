"""Record real child processes for the frozen Stage51 candidate."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import subprocess
import sys

ROOT = Path.cwd()
BASE = Path(__file__).resolve().parent
BUILD = ROOT / "target/m2/stage51-candidate04-build"
mode = sys.argv[1]
OUT = BASE / mode
OUT.mkdir()
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
node = Path("/opt/homebrew/Cellar/node/26.10.0_1/bin/node")
assert sha(node) == "d4cd917f05a5730ffda8a203e32fb8f9b70f79213fff1fafb045e438db8a6c06"
python = Path(sys.executable).resolve()
build_report = json.loads((BUILD / "report.json").read_bytes())
assert build_report["complete"] and build_report["sourceStable"]
proof = BUILD / "build-proof.json"
assert sha(proof) == build_report["buildProofSha256"]
fixtures = ROOT / "tests/fixtures/m2-collection-transforms"
assert sha(fixtures / "manifest.json") == "a90cc8d0c409b03c783192f39cf265052e3efa48e0d9bc5f7d64818e57a2558d"
browser = Path("/Users/cody.ij.hwang/Library/Caches/ms-playwright/chromium-1248/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing")
browser_sha = "c8509aee32abd6977968e9999769980b7a420dea05402d90042d9e5b41db15ef"
assert sha(browser) == browser_sha
if mode == "native":
    argv = [python, ROOT / "tools/collection_transform_native.py", "--output",
            ROOT / "target/m2/stage51-native-candidate04-01", "--fixtures", fixtures,
            "--build-proof", proof, "--build-proof-sha256", sha(proof), "--node", node]
elif mode == "portable":
    argv = [node, ROOT / "tools/platform/compare-collection-transforms.mjs",
            ROOT / "target/m2/stage51-portable-candidate04-01", BUILD / "wasm", BUILD / "pkl_napi.node",
            fixtures, ROOT / "tools/platform/package.json", browser, browser_sha, proof, sha(proof), python]
elif mode == "original":
    argv = [python, ROOT / "target/m2/stage51-original-adapter-candidate04-01/run.py"]
elif mode == "m1":
    runtime_packages = {}
    for relative in ["tools/platform/package.json", "tools/platform/package-lock.json",
                     "tools/platform/node_modules/playwright/package.json",
                     "tools/platform/node_modules/playwright-core/package.json"]:
        path = (ROOT / relative).resolve()
        runtime_packages[relative] = {"path": str(path), "sha256": sha(path)}
        if "node_modules" in relative:
            assert json.loads(path.read_bytes())["version"] == "1.64.1"
    assert json.loads((ROOT / "tools/platform/package.json").read_bytes())["devDependencies"]["playwright"] == "1.64.1"
    query = [str(node), "--input-type=module", "-e",
             "import {chromium} from 'playwright'; process.stdout.write(chromium.executablePath());"]
    observed = subprocess.run(query, cwd=ROOT / "tools/platform", capture_output=True)
    (OUT / "browser-path.stdout.bin").write_bytes(observed.stdout)
    (OUT / "browser-path.stderr.bin").write_bytes(observed.stderr)
    assert observed.returncode == 0 and observed.stdout == str(browser).encode()
    bound_sources = json.loads(proof.read_bytes())["sources"]
    assert all(sha(ROOT / name) == digest for name, digest in bound_sources.items())
    argv = [python, ROOT / "tools/m1_platforms.py", "--output",
            ROOT / "target/m2/stage51-m1-platforms-candidate04-01", "--wasm-bindgen",
            (ROOT / ".cache/m1-tools/bin/wasm-bindgen").resolve(), "--verify-contract"]
else:
    raise ValueError("unknown capture mode")
row = {"mode": mode, "argv": list(map(str, argv)), "cwd": str(ROOT), "host": platform.platform(),
       "startedUtc": now(), "runnerSha256": sha(Path(__file__)), "python": str(python),
       "pythonSha256": sha(python), "node": str(node), "nodeSha256": sha(node),
       "browser": str(browser), "browserSha256": browser_sha, "buildProofSha256": sha(proof),
       "qualification": "Actual process receipt; compatibility and strict-gate results must be read from the child report."}
if mode == "m1":
    row["playwrightRuntimePackages"] = runtime_packages
    row["browserPathQuery"] = {"argv": query, "cwd": str(ROOT / "tools/platform"), "exitCode": observed.returncode}
    row["candidateSourceCount"] = len(bound_sources)
with (OUT / "stdout.bin").open("wb") as stdout, (OUT / "stderr.bin").open("wb") as stderr:
    child = subprocess.Popen(row["argv"], cwd=ROOT, stdout=stdout, stderr=stderr)
    row["pid"] = child.pid
    (OUT / "running.json").write_text(json.dumps(row, indent=2) + "\n")
    print("START", mode, child.pid, flush=True)
    row["exitCode"] = child.wait()
row.update(finishedUtc=now(), stdoutSha256=sha(OUT / "stdout.bin"), stderrSha256=sha(OUT / "stderr.bin"))
if mode == "m1":
    row["changedCandidateSources"] = [name for name, digest in bound_sources.items() if sha(ROOT / name) != digest]
    row["changedRuntimePackages"] = [name for name, pin in runtime_packages.items() if sha(Path(pin["path"])) != pin["sha256"]]
    row["sourceStable"] = not row["changedCandidateSources"] and not row["changedRuntimePackages"]
row["wrapperExitCode"] = row["exitCode"] or (0 if row.get("sourceStable", True) else 1)
(OUT / "terminal.json").write_text(json.dumps(row, indent=2) + "\n")
print(json.dumps(row), flush=True)
raise SystemExit(row["wrapperExitCode"])
