import os,json,hashlib,stat
from pathlib import Path
O=Path(__file__).parent
D=json.loads((O/'prewalk-prunes.json').read_bytes());prunes=set(D['exactDirectoryPaths'])
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def dump(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def group(n):
 if n.startswith('stage45-original6-java'):return 'original6-java'
 if n.startswith('stage45-original6-native'):
  if '-final-' in n:return 'original6-native-final'
  if '-audit-' in n or '-seal-' in n:return 'original6-audits'
  return 'original6-native-history'
 if n.startswith('stage45-guest-catch-'):return 'guest-catch'
 if n.startswith('stage45-bootstrap-oracle') or n=='stage45-bootstrap-audit-01':return 'bootstrap-java'
 if n.startswith('stage45-bootstrap-native'):return 'bootstrap-native'
 if n.startswith('stage45-bootstrap-'):return 'bootstrap-tools-platform'
 if n.startswith('stage45-moduleinfo-') or n.startswith('stage45-jdk-digit-'):return 'moduleinfo-digits'
 if n.startswith('stage45-security-denial-'):return 'security-denial'
 return 'audits-handoff-promotion'
rows=[];rootstats=[];links=[];pruned=[];errors=[]
for root in D['selectedRoots']:
 p=Path(root);start=len(rows)
 for directory,dirs,files in os.walk(p,topdown=True,followlinks=False):
  dirs.sort();files.sort()
  kept=[]
  for n in dirs:
   q=Path(directory)/n
   if str(q) in prunes:pruned.append(str(q));continue
   if q.is_symlink():links.append({'path':str(q),'target':os.readlink(q),'kind':'directory'});continue
   kept.append(n)
  dirs[:]=kept
  for n in files:
   q=Path(directory)/n
   if q.is_symlink():links.append({'path':str(q),'target':os.readlink(q),'kind':'file'});continue
   st=q.stat();assert stat.S_ISREG(st.st_mode),q
   rel=q.relative_to(p).as_posix()
   rows.append({'source':str(q),'root':str(p),'path':p.name+'/'+rel,'group':group(p.name),'bytes':st.st_size,'sha256':digest(q)})
 subset=rows[start:];mapping={r['path'].split('/',1)[1]:r for r in subset}
 ip=p/'inventory.json';checked=0
 if ip.is_file():
  inv=json.loads(ip.read_bytes());inv=inv.get('files',inv) if isinstance(inv,dict) else inv
  if isinstance(inv,dict):inv=[dict(v,path=k) for k,v in inv.items()]
  for r in inv:
   a=mapping.get(r['path'])
   if not a or a['sha256']!=r['sha256'] or a['bytes']!=r.get('bytes',a['bytes']):errors.append({'root':str(p),'producerInventoryEntry':r,'actual':a})
   checked+=1
 rootstats.append({'root':str(p),'group':group(p.name),'files':len(subset),'rawBytes':sum(r['bytes'] for r in subset),'producerInventoryEntriesChecked':checked,'originalClosure':json.loads((p/'closure.json').read_bytes()) if (p/'closure.json').is_file() else None})
dump('source-before.json',{'files':rows,'symlinks':links,'prunedExactDirectories':pruned,'producerInventoryErrors':errors,'roots':rootstats})
groups={}
for r in rows:
 g=groups.setdefault(r['group'],{'files':0,'rawBytes':0});g['files']+=1;g['rawBytes']+=r['bytes']
summary={'selectedRoots':len(rootstats),'files':len(rows),'rawBytes':sum(r['bytes'] for r in rows),'symlinks':links,'prunedDirectories':pruned,'producerInventoryErrors':len(errors),'groups':groups,'largestFiles':sorted([{'path':r['path'],'bytes':r['bytes']} for r in rows],key=lambda r:-r['bytes'])[:12]}
dump('selection-statistics.json',summary);print(json.dumps(summary,indent=2));assert not links and not errors
