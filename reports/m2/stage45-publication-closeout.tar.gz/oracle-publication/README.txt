Stage45 oracle and portable raw evidence publication

archive-index.json lists each publishable archive, its compressed size, SHA256,
source roots, raw file counts, and byte counts. Each archive was created and
separately verified using the exact captured tools/evidence.py in this directory.
Each archive has EVIDENCE.json and PUBLICATION-SOURCE.json; join them by path to
check raw archive bytes against original absolute source paths and SHA256 values.
The selection and exact cache-prune declarations were saved before traversal.
Clean gathered sources are retained separately under gathered/.

Publication integrity does not change compatibility results. Original failing
comparisons, failed audit attempts, unsupported outcomes, Java internal-error
boundaries and partial/unexecuted API scope remain unchanged. The two historical
roots without producer closures remain unsealed in PUBLICATION-SOURCE metadata.

The initial preparation assertion failed on one already documented historical
producer self-seal defect: native02 inventoried audit.stdout.bin before its final
print. producer-inventory-reconciliation.json binds the exact prior authoritative
seal-addendum. Both initial inventory and addendum remain verbatim in archives.
This publication uses current raw bytes with its own checked inventory and does
not rewrite the initial producer claim.

Core implementation, Rust5, main platform, canonical final native and classpath,
reviews, receipts and committed documentation are separate core publication
artifacts. Sealed comparison-root copies of native binaries remain included here.
No oracle/runtime acquisition was rerun. No Git, reports or production files were
changed by this publication.
