import json,hashlib,shutil,subprocess,sys,tarfile,time,os
from pathlib import Path
O=Path(__file__).parent
D=json.loads((O/'source-before.json').read_bytes());rows=D['files']
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
# Classify only the exact already captured historical inventory defect.
errors=D['producerInventoryErrors'];assert len(errors)==1
err=errors[0];a=err['actual'];assert a['path']=='stage45-original6-native-02/audit.stdout.bin'
addendum=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42/target/m2/stage45-original6-native-seal-addendum-01/report.json')
ad=json.loads(addendum.read_bytes());known=ad['initialInventoryReadbackMismatches'];assert len(known)==1
k=known[0];assert (a['sha256'],a['bytes'])==(k['actualSha256'],k['actualBytes'])
assert err['producerInventoryEntry']['sha256']==k['declaredSha256']
reconciliation={'initialPrepareExit':1,'reason':'Preparation conservatively rejected one producer inventory defect; exact prior addendum proves it is the previously recorded self-seal stdout print defect, not a new mutation. Original records remain byte-identical.','historicalDefects':[err],'authoritativePriorAddendum':{'path':str(addendum),'sha256':digest(addendum)},'unexplainedProducerInventoryMismatches':0}
dump(O/'producer-inventory-reconciliation.json',reconciliation)
assert not D['symlinks']
tool=Path('/Users/cody.ij.hwang/Projects/pkl-rs/tools/evidence.py');(O/'tools').mkdir();shutil.copyfile(tool,O/'tools/evidence.py');tool=O/'tools/evidence.py'
cap=48*1024*1024;groups={}
for r in rows:groups.setdefault(r['group'],[]).append(r)
(O/'archives').mkdir();(O/'logs').mkdir();(O/'gathered').mkdir()
commands=[];archives=[];failedAttempts=[]
def run(argv,name):
 start=time.time()
 with (O/'logs'/f'{name}.stdout.bin').open('wb') as out,(O/'logs'/f'{name}.stderr.bin').open('wb') as err:
  code=subprocess.run(argv,stdout=out,stderr=err).returncode
 rec={'command':argv,'exitCode':code,'elapsedSeconds':time.time()-start,'stdout':str(O/'logs'/f'{name}.stdout.bin'),'stderr':str(O/'logs'/f'{name}.stderr.bin')};commands.append(rec);dump(O/'commands.json',commands);assert code==0,rec

def pack(name,subset):
 gathered=O/'gathered'/name;gathered.mkdir()
 for r in subset:
  src=Path(r['source']);dst=gathered/r['path'];dst.parent.mkdir(parents=True,exist_ok=True)
  with src.open('rb') as s,dst.open('wb') as d:
   h=hashlib.sha256();size=0
   for b in iter(lambda:s.read(1048576),b''):h.update(b);size+=len(b);d.write(b)
  assert h.hexdigest()==r['sha256'] and size==r['bytes'],r
 manifest={'schemaVersion':1,'logicalGroup':name,'rawSourceFileCount':len(subset),'rawSourceBytes':sum(r['bytes'] for r in subset),'selectionSha256':digest(O/'selection.json'),'pruneDeclarationSha256':digest(O/'prewalk-prunes.json'),'sourceBeforeSha256':digest(O/'source-before.json'),'originalClosureNullsPreserved':[x['root'] for x in D['roots'] if x['originalClosure'] is None and any(r['root']==x['root'] for r in subset)],'knownHistoricProducerDefect':reconciliation if any(r['path']=='stage45-original6-native-02/audit.stdout.bin' for r in subset) else None,'files':subset}
 dump(gathered/'PUBLICATION-SOURCE.json',manifest)
 archive=O/'archives'/f'{name}.tar.gz'
 run([sys.executable,str(tool),'create',str(gathered),str(archive)],name+'.create')
 if archive.stat().st_size>cap:
  failedAttempts.append({'path':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive),'reason':'Above48MiB;preservedoversizeattempt,logicalroot-basedsplitfollows.'})
  units={}
  for r in subset:units.setdefault(r['root'],[]).append(r)
  assert len(units)>1,'Single logicalroot exceeds cap; requires subtree split'
  archive.rename(O/'archives'/f'{name}.oversize-attempt.tar.gz')
  failedAttempts[-1]['path']=str(O/'archives'/f'{name}.oversize-attempt.tar.gz')
  for i,(root,part) in enumerate(units.items(),1):pack(name+f'-part{i:02}',part)
  return
 run([sys.executable,str(tool),'verify',str(archive)],name+'.verify')
 with tarfile.open(archive,'r:gz') as tar:
  inventory=json.load(tar.extractfile('EVIDENCE.json'));idx={r['path']:r for r in inventory['files']}
  assert set(idx)=={r['path'] for r in subset}|{'PUBLICATION-SOURCE.json'}
  for r in subset:
   assert (idx[r['path']]['sha256'],idx[r['path']]['bytes'])==(r['sha256'],r['bytes'])
  assert idx['PUBLICATION-SOURCE.json']['sha256']==digest(gathered/'PUBLICATION-SOURCE.json')
 for r in subset:assert digest(gathered/r['path'])==r['sha256']
 rec={'logicalGroup':name,'archive':str(archive),'compressedBytes':archive.stat().st_size,'sha256':digest(archive),'rawSourceFileCount':len(subset),'rawSourceBytes':sum(r['bytes'] for r in subset),'archivePayloadFilesIncludingPublicationSource':len(subset)+1,'evidenceInventoryFiles':len(inventory['files']),'publicationSourceManifestSha256':digest(gathered/'PUBLICATION-SOURCE.json'),'roots':sorted({r['root'] for r in subset}),'createPassed':True,'verifyPassed':True,'archiveToOriginalHashJoinPassed':True,'gatheredHashReadbackPassed':True,'within48MiB':True}
 archives.append(rec);dump(O/'archive-index.in-progress.json',{'archives':archives,'failedAttempts':failedAttempts});print(json.dumps({'complete':name,'files':len(subset),'compressedBytes':archive.stat().st_size}),flush=True)
for name,subset in groups.items():pack(name,subset)
# Read each original again after all copies, compression and verification.
changes=[]
for r in rows:
 p=Path(r['source']);actual={'bytes':p.stat().st_size,'sha256':digest(p)}
 if actual!={'bytes':r['bytes'],'sha256':r['sha256']}:changes.append({'source':str(p),'before':r,'after':actual})
assert not changes,changes
# Re-enumerate exact selected roots using the SAME before-walk prune list.
prunes=set(json.loads((O/'prewalk-prunes.json').read_bytes())['exactDirectoryPaths']);afterpaths=[];afterlinks=[]
for root in json.loads((O/'selection.json').read_bytes())['roots']:
 for directory,dirs,files in os.walk(root,topdown=True,followlinks=False):
  kept=[]
  for n in dirs:
   p=Path(directory)/n
   if str(p) in prunes:continue
   if p.is_symlink():afterlinks.append(str(p));continue
   kept.append(n)
  dirs[:]=kept
  for n in files:
   p=Path(directory)/n
   if p.is_symlink():afterlinks.append(str(p))
   else:afterpaths.append(str(p))
assert not afterlinks and set(afterpaths)=={r['source'] for r in rows}
index={'schemaVersion':1,'archives':archives,'failedOversizeAttempts':failedAttempts,'compressedLimitBytes':cap,'archivesCount':len(archives),'rawSourceRoots':len(D['roots']),'rawSourceFiles':len(rows),'rawSourceBytes':sum(r['bytes'] for r in rows),'archivePayloadFilesIncludingPerArchivePublicationManifest':sum(r['evidenceInventoryFiles'] for r in archives),'compressedBytes':sum(r['compressedBytes'] for r in archives),'allArchivesWithinCap':True,'allCreatedAndVerifiedByCapturedEvidenceTool':True,'allArchiveRowsJoinedToCurrentOriginalHashes':True,'originalChanges':0,'originalPathSetChanges':0,'symlinks':0,'producerHistoricalInventoryDefects':1,'unexplainedProducerInventoryMismatches':0,'historicUnsealedRoots':[r['root'] for r in D['roots'] if r['originalClosure'] is None],'historicalCompatibilityAndAuditFailures':'Preserved byte-for-byte; archive integrity success does not relabel compatibility/audit failures.','evidenceTool':{'source':'/Users/cody.ij.hwang/Projects/pkl-rs/tools/evidence.py','captured':str(tool),'sha256':digest(tool)},'originalBeforeManifestSha256':digest(O/'source-before.json'),'pruneDeclarationSha256':digest(O/'prewalk-prunes.json'),'selectionSha256':digest(O/'selection.json'),'commandRecordsSha256':digest(O/'commands.json'),'rootSourceMutation':False,'gitAndReportsMutation':False}
dump(O/'archive-index.json',index)
dump(O/'source-after-audit.json',{'passed':True,'checkedFiles':len(rows),'checkedRoots':len(D['roots']),'sourceBeforeSha256':digest(O/'source-before.json'),'originalContentChanges':changes,'originalPathSetChanges':[],'symlinks':afterlinks,'samePrunesBeforeBothTraversals':True,'producerInventoryHistoricalDefectPreserved':reconciliation})
dump(O/'report.json',dict(index,passed=True,scope='Oracle/portable raw evidence publication only;no new oracle/runtime acquisition and no full M2 compatibility claim.'))
print(json.dumps({'finished':True,'archives':len(archives),'files':len(rows),'rawBytes':index['rawSourceBytes'],'compressedBytes':index['compressedBytes'],'reportSha256':digest(O/'report.json'),'archiveIndexSha256':digest(O/'archive-index.json'),'originalChanges':0},indent=2),flush=True)
