"""Publish already verified immutable Stage45 evidence without reacquisition."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil

root=Path.cwd()
out=root/'target/m2/stage45-publication-01'
reports=root/'reports/m2'
evidence_root=root.parent/'pkl-rs.stage45/target/m2'
core=evidence_root/'stage45-core-publication-01'
oracle=evidence_root/'stage45-oracle-publication-01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    assert not path.exists(),path
    path.write_text(json.dumps(value,indent=2)+'\n')
def copy(source,destination,expected=None):
    assert source.is_file()and not source.is_symlink(),source
    digest=sha(source)
    if expected is not None:assert digest==expected,source
    assert not destination.exists(),destination
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,destination)
    assert sha(destination)==digest==sha(source),source
    return {'path':str(destination.relative_to(root)),'sha256':digest,'bytes':destination.stat().st_size,'original':str(source)}

assert sha(core/'handoff.json')=='1726bcbe2ae8f1c5bb2701b5fe02e5de2737d5bc6aee4d88aa73d04a68e5889d'
assert sha(oracle/'archive-index.json')=='b03412d2c11b571400686ee2b4e7783e0de289ded9f9e7e3fe47513a4ea17d5d'
c=json.loads((core/'handoff.json').read_text())
o=json.loads((oracle/'archive-index.json').read_text())
assert c['archive_integrity_and_exact_selection_join_passed']and not c['original_evidence_changed']
assert o['allArchiveRowsJoinedToCurrentOriginalHashes']and o['originalChanges']==o['originalPathSetChanges']==0
planned=[]
for entry in c['archives']:
    source=Path(entry['path'])
    planned.append((source,reports/source.name,entry['sha256'],entry['compressed_bytes'],'core',entry['unit']))
for entry in o['archives']:
    source=Path(entry['archive'])
    planned.append((source,reports/('stage45-oracle-'+source.name),entry['sha256'],entry['compressedBytes'],'oracle',entry['logicalGroup']))
assert len(planned)==25
assert len({destination for _,destination,_,_,_,_ in planned})==25
for source,destination,digest,size,_,_ in planned:
    assert source.stat().st_size==size<48*1024*1024 and sha(source)==digest and not destination.exists()
archives=[]
for source,destination,digest,size,group,unit in planned:
    row=copy(source,destination,digest);row.update(group=group,unit=unit)
    archives.append(row)
binding=copy(core/'committed-source-binding.json',reports/'stage45-implementation-source-binding.json')
source_map=copy(core/'committed-source-map.json',reports/'stage45-implementation-source-map.json')
assert json.loads((reports/'stage45-implementation-source-binding.json').read_text())['source_map_sha256']==source_map['sha256']
core_index=copy(core/'handoff.json',reports/'stage45-core-captures.json')
oracle_index=copy(oracle/'archive-index.json',reports/'stage45-oracle-captures.json')

# Preserve the oracle publisher's declared metadata, excluding only the exact
# eleven archive files already published above. Never walk source/cache trees.
closure_source=out/'closeout-source'
closure_source.mkdir()
inventory=json.loads((oracle/'inventory.json').read_text())
closure=json.loads((oracle/'closure.json').read_text())
assert sha(oracle/'inventory.json')==closure['inventorySha256']
archive_sources={source for source,_,_,_,group,_ in planned if group=='oracle'}
for entry in inventory['files']:
    relative=Path(entry['path'])
    assert not relative.is_absolute()and '..'not in relative.parts
    source=oracle/relative
    assert source.stat().st_size==entry['bytes']and sha(source)==entry['sha256']
    if source in archive_sources:continue
    copy(source,closure_source/'oracle-publication'/relative,entry['sha256'])
for name in ['inventory.json','closure.json']:
    source=oracle/name;destination=closure_source/'oracle-publication'/name
    if not destination.exists():copy(source,destination)
copy(core/'handoff.json',closure_source/'core-handoff.json')
copy(Path(__file__),closure_source/'publish.py')
copy(root/'tools/evidence.py',closure_source/'evidence.py')
write(closure_source/'copied-archives.json',archives)
archive=reports/'stage45-publication-closeout.tar.gz'
assert not archive.exists()
spec=importlib.util.spec_from_file_location('evidence',root/'tools/evidence.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.create(closure_source,archive,[])
assert archive.stat().st_size<48*1024*1024
archives.append({'path':str(archive.relative_to(root)),'sha256':sha(archive),'bytes':archive.stat().st_size,'group':'publication','unit':'collector-closeout'})
index={
 'schema':1,'scope':'Published Stage45 implementation evidence. Original outcomes, failed attempts, unexecuted boundaries and historical inventory defects are preserved; this is not full M2 completion.',
 'implementation_commit':c['implementation_commit'],'archives':archives,'archive_count':len(archives),
 'compressed_bytes':sum(row['bytes']for row in archives),
 'source_payloads_by_group':{'core':c['source_payloads'],'oracle':o['rawSourceFiles']},
 'source_bytes_by_group':{'core':c['source_bytes'],'oracle':o['rawSourceBytes']},
 'count_scope':'Stored source payloads, including duplicate snapshots across experiments; not distinct semantic cases or feature coverage.',
 'core_index':core_index,'oracle_index':oracle_index,'committed_source_binding':binding,'committed_source_map':source_map,
 'all_published_archive_bytes_match_verified_preparation':True,'original_evidence_changes':0,
 'symlink_representation':'15 core symlinks retain exact raw target bytes plus kind/mode metadata; no links followed.',
 'historical_qualifications':['One original native02 self-seal stdout digest is stale; its prior authoritative addendum and both records are preserved.','Historical unsealed roots retain their explicit null/unsealed provenance.','The M1 source collector omitted modules.txt; complete pre/post frozen-source evidence binds it separately. Later collector fixes do not alter the historical claim.'],
 'full_selected_regression':'Running separately at combined commit01971d0; not established by these archives.',
 'full_m2_complete':False,'hosted_ci_claimed':False,'performance_target_claimed':False,
}
write(reports/'stage45-implementation-captures.json',index)
write(out/'report.json',{'complete':True,'index_sha256':sha(reports/'stage45-implementation-captures.json'),'archives':len(archives),'compressed_bytes':index['compressed_bytes'],'published_archives_sha256_verified':True,'original_evidence_changes':0})
print(json.dumps({'complete':True,'archives':len(archives),'compressed_bytes':index['compressed_bytes']}))
