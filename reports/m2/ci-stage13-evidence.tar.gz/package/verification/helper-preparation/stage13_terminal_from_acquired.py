"""Validate terminal CI metadata already retained by acquisition; no API calls."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def load(path):
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--acquired', type=Path, required=True)
    parser.add_argument('--commit', required=True)
    parser.add_argument('--run', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    base = args.acquired.resolve()
    run = load(base / 'm2/run.json')
    jobs = load(base / 'm2/jobs.json')
    verified = load(base / 'verification/verification.json')
    expected = {'M1 architecture experiments (known gaps recorded)',
                'M2 language development (full gate incomplete)',
                'Compatibility tooling and Java replay', 'Workspace (windows-latest)',
                'Workspace (macos-latest)', 'Workspace (ubuntu-latest)'}
    if (run['id'] != args.run or run['head_sha'] != args.commit or
            run['status'] != 'completed' or run['conclusion'] != 'success' or
            verified['run_id'] != args.run or verified['commit'] != args.commit):
        raise ValueError('Exact requested terminal workflow/verification identity differs')
    rows = jobs['jobs']
    if (len(rows) != jobs['total_count'] or len(rows) != len(expected) or
            {row['name'] for row in rows} != expected or
            any(row['status'] != 'completed' or row['conclusion'] != 'success' for row in rows)):
        raise ValueError('Terminal metadata does not contain all six successful required jobs')
    args.output.mkdir(parents=True, exist_ok=False)
    for name in ['run.json', 'jobs.json', 'artifacts.json']:
        shutil.copyfile(base / 'm2' / name, args.output / name)
    inputs = {name: hashlib.sha256((args.output / name).read_bytes()).hexdigest()
              for name in ['run.json', 'jobs.json', 'artifacts.json']}
    summary = dict(commit=args.commit, run_id=args.run, workflow_status='completed', conclusion='success',
                   all_six_jobs_succeeded=True,
                   jobs=[{key: row[key] for key in ['name', 'status', 'conclusion']} for row in rows],
                   source='Final original GitHub API metadata retained by the single acquisition process; no additional API call.',
                   input_sha256=inputs, verification_sha256=hashlib.sha256(
                       (base / 'verification/verification.json').read_bytes()).hexdigest())
    with (args.output / 'status-summary.json').open('x') as stream:
        stream.write(json.dumps(summary, indent=2, sort_keys=True) + '\n')
    print(json.dumps(summary, sort_keys=True))


if __name__ == '__main__':
    main()
