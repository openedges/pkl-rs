"""Retry only retained exact-run artifact downloads, preserving the failed attempt."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time
import urllib.request
import urllib.error

sys.dont_write_bytecode = True
root = Path.cwd()
base = root / 'target/m2'
previous = base / 'ci-stage13-acquired'
output = base / 'ci-stage13-acquired-retry03'
helpers = base / 'ci-stage13-review-02'
commit = 'f90d7b09124bb5a7d73dd5b2bfcddf2a90d2761f'
run_id = 39554130320


def load(path):
    return json.loads(path.read_bytes())


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


spec = importlib.util.spec_from_file_location('stage13_ci_retry_verifier', helpers / 'verify.py')
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)
output.mkdir(exist_ok=False)
for file in previous.glob('poll-*'):
    shutil.copyfile(file, output / file.name)
run_file = sorted(previous.glob('poll-*-run.json'))[-1]
prefix = run_file.name.removesuffix('run.json')
records = {label: previous / (prefix + label + '.json') for label in ['run', 'jobs', 'artifacts']}
run = load(records['run'])
if run['id'] != run_id or run['head_sha'] != commit or run['status'] != 'completed' or run['conclusion'] != 'success':
    raise ValueError('Retained terminal workflow identity differs')
write(output / 'retry-provenance.json', dict(
    reason='Original M1 ZIP buffered download timed out, and streamed retry02 received Blob TLS handshake timeout with zero bytes. Retry03 changes only download transport to curl IPv4; CI succeeded and no status metadata is reacquired.',
    prior_acquisition=str(previous), prior_process=str(base / 'ci-stage13-acquire-process/process.json'),
    retained_metadata={label: dict(path=str(path), sha256=tool.sha(path)) for label, path in records.items()},
    helper_sha256=tool.sha(Path(__file__)), verifier_sha256=tool.sha(helpers / 'verify.py')))
artifacts = load(records['artifacts'])['artifacts']
for kind, name in tool.NAMES.items():
    directory = output / kind
    directory.mkdir()
    for label, path in records.items():
        shutil.copyfile(path, directory / (label + '.json'))
    candidates = [row for row in artifacts if row['name'] == name]
    if len(candidates) != 1:
        raise ValueError('Missing/duplicate retained artifact: ' + name)
    artifact = candidates[0]
    endpoint = f"https://api.github.com/repos/luuvish/pkl-rs/actions/artifacts/{artifact['id']}/zip"
    # Stop at GitHub's redirect. The API token is never sent to the Blob host
    # or retained in process metadata/output.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, message, headers, newurl):
            return None
    token = subprocess.run(['gh', 'auth', 'token'], capture_output=True, check=True).stdout.decode().strip()
    request = urllib.request.Request(endpoint, headers={'Authorization': 'Bearer ' + token,
                                                       'Accept': 'application/vnd.github+json'})
    opener = urllib.request.build_opener(NoRedirect())
    try:
        response = opener.open(request, timeout=45)
    except urllib.error.HTTPError as error:
        if error.code not in [301, 302, 303, 307, 308]:
            raise
        response = error
    location = response.headers.get('Location')
    if not location or not location.startswith('https://'):
        raise ValueError('Missing HTTPS artifact redirect')
    write(directory / 'redirect.response.json', dict(
        endpoint=endpoint, status=response.code, headers=dict(response.headers),
        authorization='omitted; token used only for api.github.com request'))
    command = ['curl', '--ipv4', '--fail', '--location', '--retry', '2', '--retry-all-errors',
               '--retry-delay', '1', '--connect-timeout', '30', '--max-time', '180', location]
    started = time.monotonic_ns()
    print(json.dumps(dict(phase='download', name=name, expected_bytes=artifact['size_in_bytes'],
                          transport='curl IPv4 with bounded retries')), flush=True)
    timed_out = False
    with (directory / 'artifact.zip').open('xb') as stdout, (directory / 'artifact.zip.stderr.bin').open('xb') as stderr:
        try:
            result = subprocess.run(command, cwd=root, stdout=stdout, stderr=stderr, timeout=600)
            exit_code = result.returncode
        except subprocess.TimeoutExpired:
            timed_out = True
            exit_code = None
    row = dict(command=[*command[:-1], '<signed artifact redirect retained in redirect.response.json>'],
               redirect_url_sha256=hashlib.sha256(location.encode()).hexdigest(),
               exit_code=exit_code, timed_out=timed_out, elapsed_ns=time.monotonic_ns() - started,
               stdout_bytes=(directory / 'artifact.zip').stat().st_size,
               stdout_sha256=tool.sha(directory / 'artifact.zip'),
               stderr_sha256=tool.sha(directory / 'artifact.zip.stderr.bin'))
    write(directory / 'download.process.json', row)
    if timed_out or exit_code != 0 or artifact['digest'] != 'sha256:' + row['stdout_sha256']:
        raise ValueError('Artifact download failed or GitHub ZIP digest differs: ' + name)
    tool.safe_extract(directory / 'artifact.zip', directory / 'artifact')
    print(json.dumps(dict(phase='download-complete', name=name, bytes=row['stdout_bytes'], github_digest_verified=True)), flush=True)
args = type('Arguments', (), dict(repository_root=root, commit=commit, run=run_id, repo='luuvish/pkl-rs'))()
tool.verify(args, output / 'm1', output / 'm2', output / 'verification')
