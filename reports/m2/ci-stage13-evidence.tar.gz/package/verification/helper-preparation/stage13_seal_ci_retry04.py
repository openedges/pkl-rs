"""Package verified stage13 CI evidence, then retain an independent sealed replay."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

root = Path.cwd()
base = root / 'target/m2'
helpers = base / 'ci-stage13-review-02'
final = base / 'ci-stage13-final-evidence-retry04'
package = final / 'package'
acquired = base / 'ci-stage13-acquired-retry04'

def load(path):
    return json.loads(path.read_bytes())

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def capture(name, command):
    directory = base / ('ci-stage13-' + name + '-process')
    subprocess.run([sys.executable, str(helpers / 'capture_process.py'), '--output', str(directory), '--', *map(str, command)], check=True)
    return directory

def inventory(directory):
    return {str(p.relative_to(directory)): dict(bytes=p.stat().st_size, sha256=sha(p))
            for p in sorted(directory.rglob('*')) if p.is_file()}

def compare(original, replay, package_stable, replay_path):
    fields = sorted(set(original) - {'frozen_verifiers'})
    assert {key: original[key] for key in fields} == {key: replay[key] for key in fields}
    assert {key: row['sha256'] for key,row in original['frozen_verifiers'].items()} == {
        key: row['sha256'] for key,row in replay['frozen_verifiers'].items()}
    return dict(status='pass', commit=original['commit'], run_id=original['run_id'],
                compared_result_fields=fields, complete_result_fields_equal=True,
                frozen_verifier_hashes_equal=True, package_unchanged=package_stable,
                original_package=str(package), unpacked_replay=str(replay_path),
                verification_sha256=sha(replay_path/'verification/verification.json'),
                source_snapshot_copies=replay['exact_source_snapshot_copies'],
                unique_source_files=replay['unique_source_files'])

original = load(acquired/'verification/verification.json')
terminal = load(base/'ci-stage13-terminal-status/status-summary.json')
assert terminal['all_six_jobs_succeeded'] and terminal['commit'] == original['commit']
assert terminal['run_id'] == original['run_id']
assert len(terminal['jobs']) == 6 and all(row['conclusion']=='success' for row in terminal['jobs'])
assert original['commit'] == sys.argv[1]
final.mkdir(exist_ok=False)
print('Packaging original verified ZIPs and exact commit evidence.', flush=True)
package_process = capture('package', [sys.executable, helpers/'package.py', '--acquired', acquired, '--output', package])
before_initial = inventory(package)
write(base/'ci-stage13-pre-offline-inventory.json', before_initial)
initial_path = base/'ci-stage13-offline-initial'
initial_process = capture('offline-initial', [sys.executable, package/'verification/unpack_and_verify.py', '--repository-root', root, '--output', initial_path])
assert inventory(package) == before_initial
initial = compare(original, load(initial_path/'verification/verification.json'), True, initial_path)
write(package/'verification/portable-recheck.json', initial)
captures = package/'verification/captured-processes'
captures.mkdir()
for name, directory in [('discovery',base/'ci-stage13-discovery-process'), ('acquire',base/'ci-stage13-acquire-process'), ('acquire-retry02',base/'ci-stage13-acquire-retry02-process'), ('acquire-retry03',base/'ci-stage13-acquire-retry03-process'), ('acquire-retry04',base/'ci-stage13-acquire-retry04-process'), ('package',package_process),
                        ('terminal-status',base/'ci-stage13-terminal-process'), ('offline-initial',initial_process)]:
    shutil.copytree(directory,captures/name)
shutil.copytree(base/'ci-stage13-terminal-status',package/'metadata/terminal-status')
preparation = package/'verification/helper-preparation'
preparation.mkdir()
shutil.copyfile(helpers/'preparation.json',preparation/'preparation.json')
for name in ['self-test.stdout.bin','self-test.stderr.bin']:
    shutil.copyfile(helpers/name,preparation/name)
local_helpers = {}
for source in [base/'stage13_terminal_from_acquired.py', base/'stage13_retry_ci_downloads.py', base/'stage13_retry_ci_downloads03.py', base/'stage13_retry_ci_downloads04.py', Path(__file__)]:
    shutil.copyfile(source,preparation/source.name)
    local_helpers[source.name] = sha(source)
write(preparation/'local-helper-sha256.json',local_helpers)
for revision in sorted(helpers.glob('preparation-*.json')):
    shutil.copyfile(revision,preparation/revision.name)
transport = package/'metadata/transport-retry04'
transport.mkdir()
shutil.copyfile(acquired/'retry-provenance.json',transport/'retry-provenance.json')
for kind in ['m1','m2']:
    shutil.copyfile(acquired/kind/'download.process.json',transport/(kind+'-download.process.json'))
# Raw temporary redirect credentials stay only in ignored local target records.
# Public evidence keeps sanitized transport text and hashes of the original.
import re
for attempt in ['retry02','retry03']:
    previous = base/('ci-stage13-acquired-'+attempt)/'m1'
    shutil.copyfile(previous/'download.process.json',transport/(attempt+'-m1-download.process.json'))
    raw = (previous/'artifact.zip.stderr.bin').read_bytes()
    omitted = []
    def redact(match):
        value = match.group(0)
        if b'sig=' not in value and b'token=' not in value:
            return value
        digest = hashlib.sha256(value).hexdigest()
        omitted.append(dict(sha256=digest,bytes=len(value)))
        return ('<temporary signed redirect omitted; sha256='+digest+'>').encode()
    sanitized = re.sub(rb'https?://[^\s\"<>]+',redact,raw)
    (transport/(attempt+'-m1-download.sanitized.stderr.bin')).write_bytes(sanitized)
    write(transport/(attempt+'-m1-sanitization.json'),dict(
        scope='Original raw stderr remains only in ignored local target; temporary signed URL omitted from published evidence.',
        original_sha256=hashlib.sha256(raw).hexdigest(),original_bytes=len(raw),
        sanitized_sha256=hashlib.sha256(sanitized).hexdigest(),omitted_urls=omitted))
scanned = []
for candidate in sorted(package.rglob('*')):
    if not candidate.is_file() or candidate.suffix == '.zip':
        continue
    data = candidate.read_bytes()
    for url in re.findall(rb'https?://[^\s\"<>]+',data):
        if b'?' in url and any(marker in url.lower() for marker in
                               [b'sig=',b'token=',b'signature=',b'access_token=']):
            raise ValueError('Credential-bearing redirect found in public package file: '+str(candidate.relative_to(package)))
    scanned.append(dict(path=str(candidate.relative_to(package)),sha256=sha(candidate)))
write(package/'verification/credential-omission-audit.json',dict(
    status='pass',signed_redirect_credentials_published=False,
    scope='Public non-ZIP files scanned for credential-bearing HTTP URL query parameters. Original GitHub artifact ZIP payloads remain unchanged and digest-verified.',
    checked_files=scanned,private_local_records='Original redirect headers/URLs and unsanitized transport stderr remain in ignored target records only.'))
manifest = load(package/'package-manifest.json')
files = inventory(package)
del files['package-manifest.json']
manifest.update(files=files,file_count=len(files)+1,hashed_file_count=len(files))
write(package/'package-manifest.json',manifest)
sealed = inventory(package)
write(base/'ci-stage13-sealed-inventory.json',sealed)
print('Package sealed; replaying without executing captured binaries.', flush=True)
sealed_path = base/'ci-stage13-offline-sealed'
sealed_process = capture('offline-sealed', [sys.executable, package/'verification/unpack_and_verify.py', '--repository-root', root, '--output', sealed_path])
assert inventory(package) == sealed
portable = compare(original,load(sealed_path/'verification/verification.json'),True,sealed_path)
portable.update(offline_exit_code=0,package_manifest_sha256=sha(package/'package-manifest.json'),
                package_files=len(sealed),packaged_initial_offline_capture='verification/captured-processes/offline-initial',
                packaged_initial_offline_result='verification/portable-recheck.json',
                capture_rounds='Initial replay capture was integrated, then the final sealed package was replayed without further package mutation.')
proof = base/'ci-stage13-offline-proof'
shutil.copytree(sealed_process,proof)
shutil.copyfile(sealed_path/'verification/verification.json',proof/'verification.json')
write(proof/'result.json',portable)
shutil.copytree(proof,final/'offline-proof')
(final/'README.md').write_text('''# Stage 13 exact-commit CI evidence

`package/` preserves the original GitHub ZIP artifacts, exact commit identities,
all six terminal job outcomes, independent raw verification, helper preparation,
and the initial portable replay. `offline-proof/` records a second replay of the
sealed package. The package stayed byte-identical during that final replay.

M2 selected and M1 architecture contracts retain known failures. These artifacts
do not establish complete language/API compatibility or performance targets.
''')
archives={}
for name, directory, filename in [('main',final,'ci-stage13-evidence.tar.gz'),
                                  ('offline',proof,'ci-stage13-offline-evidence.tar.gz')]:
    archive=base/filename
    capture('archive-'+name,[sys.executable,root/'tools/evidence.py','create',directory,archive])
    with tarfile.open(archive,'r:gz') as stream:
        count=len(stream.getmembers())
    archives[name]=dict(path=str(archive),bytes=archive.stat().st_size,sha256=sha(archive),
                        inventory_verified=True,files_including_inventory=count)
summary=dict(original)
summary['transport_acquisition'] = dict(
    original_attempt=dict(process=load(base/'ci-stage13-acquire-process/process.json'),
        status='failed-artifact-download-timeout', timeout_seconds=180,
        partial_payload_retention='The original buffered helper did not publish a partial ZIP; its complete timeout traceback/process capture and terminal metadata are retained.'),
    intermediate_attempts={attempt:dict(process=load(base/('ci-stage13-acquire-'+attempt+'-process/process.json')),
        download=load(base/('ci-stage13-acquired-'+attempt+'/m1/download.process.json')),
        raw_signed_redirects='Omitted from published evidence; original local records and hashes preserved.')for attempt in ['retry02','retry03']},
    retry_attempt=dict(process=load(base/'ci-stage13-acquire-retry04-process/process.json'),
        status='pass', reused_terminal_metadata=True, additional_status_api_calls=0,signed_redirect_credentials_published=False,
        downloads={kind:load(acquired/kind/'download.process.json')for kind in ['m1','m2']}))
summary.update(package=str(package),artifact_payloads=load(package/'package-summary.json')['artifact_payloads'],
               all_six_jobs_succeeded=True,evidence_archives=archives,portable_recheck=portable,
               portable_recheck_process=load(sealed_process/'process.json'),
               captured_processes={name:load(directory/'process.json') for name,directory in [
                   ('acquire',base/'ci-stage13-acquire-process'),('acquire-retry02',base/'ci-stage13-acquire-retry02-process'), ('acquire-retry03',base/'ci-stage13-acquire-retry03-process'), ('acquire-retry04',base/'ci-stage13-acquire-retry04-process'),('package',package_process),
                   ('terminal-status',base/'ci-stage13-terminal-process'),
                   ('offline-initial',initial_process),('offline-sealed',sealed_process)]})
write(base/'ci-stage13-summary.json',summary)
print(json.dumps(dict(summary=str(base/'ci-stage13-summary.json'),archives=archives,
                      m2=summary['m2'],m1_platform=summary['m1']['platform']),sort_keys=True),flush=True)

# Publish only the three report files authorized for this exact implementation.
reports = root/'reports/m2'
for name,row in archives.items():
    original_archive=Path(row['path'])
    report_archive=reports/original_archive.name
    if report_archive.exists():
        raise ValueError('Refusing to replace prior CI evidence: '+str(report_archive))
    shutil.copyfile(original_archive,report_archive)
    assert sha(report_archive)==row['sha256']
    row['report_path']=str(report_archive.relative_to(root))
    row['report_digest_verified']=True
summary['evidence_archives']=archives
summary['source_count_contract']='exact_source_snapshot_copies counts each checked path in each captured source snapshot; unique_source_files counts distinct repository source paths across those snapshots.'
write(base/'ci-stage13-summary.json',summary)
report_summary=reports/'ci-stage13-summary.json'
if report_summary.exists():
    raise ValueError('Refusing to replace prior CI summary')
shutil.copyfile(base/'ci-stage13-summary.json',report_summary)
print(json.dumps({'report_summary':str(report_summary),'archives':archives,'exact_source_snapshot_copies':summary['exact_source_snapshot_copies'],'unique_source_files':summary['unique_source_files']},sort_keys=True),flush=True)
