"""M1 raw checks; counts come from exact-commit frozen contracts, without stage-specific constants."""
from pathlib import Path, PurePosixPath
import hashlib
import json

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def check_scenario_lists(directory, execution):
    for target in ['node', 'browser']:
        recorded = json.loads((directory / 'execution' / (target + '-checks.json')).read_bytes())
        if recorded != execution[target + 'Checks']:
            raise ValueError(target + ' scenario claims differ from retained check list')

def relocated_path(artifact, original, suite):
    prefix = f"/target/m1/{suite}/"
    if prefix not in original:
        raise ValueError(f"Unexpected remote evidence path: {original}")
    relative = PurePosixPath(original.split(prefix, 1)[1])
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Unsafe relocated evidence metadata: {original}")
    return artifact / suite / relative

def verify(artifact, context):
    m1_frontend = context.modules["m1_frontend"]
    m1_host = context.modules["m1_host"]
    m1_runtime = context.modules["m1_runtime"]
    m1_lifecycle = context.modules["m1_lifecycle"]
    m1_platforms = context.modules["m1_platforms"]
    verify_oracle = context.verify_oracle
    SNAPSHOT_CHECKS = []
    def snapshot_identity(path, relative, expected):
        context.snapshot_identity(path, relative, expected)
        SNAPSHOT_CHECKS.append(relative)
    git_bytes = context.git_bytes
    node_pin = context.node_pin()
    graal = json.loads((artifact / "ci-graal-verification.log").read_bytes())
    if graal != {"verified_diagnostic_cases": len(json.loads(git_bytes("reports/m1/graal.json"))["cases"]), "performance_evidence": False}:
        raise ValueError("Missing or incorrect remote Graal archive verification")
    frontend = artifact / "ci-frontend"
    front = m1_frontend.check_report(frontend)
    verify_oracle(front["oracle"])
    if len(front["results"]) != len(m1_frontend.CASES) or not all(row["passed"] for row in front["results"]):
        raise ValueError("Required frontend comparisons missing")
    for relative, expected in front["source_sha256"].items():
        snapshot_identity(frontend / "sources" / relative, relative, expected)

    host_dir = artifact / "ci-host-java"
    host = m1_host.check_report(host_dir)
    verify_oracle(host["oracle"])
    if len(host["results"]) != len(m1_host.MODES) or not all(all(row["checks"].values()) for row in host["results"]):
        raise ValueError("Required Java Host observation suites missing")
    for relative, expected in host["source_sha256"].items():
        snapshot_identity(host_dir / "sources" / relative, relative, expected)

    runtime_dir = artifact / "ci-runtime"
    runtime = json.loads((runtime_dir / "report.json").read_text())
    verify_oracle(runtime["oracle"])
    expected_cases = list(m1_runtime.SUCCESS_CASES + m1_runtime.ERROR_CASES)
    if [row["id"] for row in runtime["cases"]] != expected_cases:
        raise ValueError("Runtime case coverage differs")
    successes, diagnostic_matches, mismatches = [], [], []
    for row in runtime["cases"]:
        captures = {}
        for language in ("java", "rust"):
            process = row[language]
            if process["status"] != "executed":
                raise ValueError(f"Runtime process not executed: {row['id']}/{language}")
            channels = []
            for channel in ("stdout", "stderr"):
                info = process[channel]
                data = relocated_path(artifact, info["path"], "ci-runtime").read_bytes()
                if len(data) != info["bytes"] or hashlib.sha256(data).hexdigest() != info["sha256"]:
                    raise ValueError(f"Runtime capture hash differs: {row['id']}/{language}/{channel}")
                channels.append(data)
            captures[language] = (process["exit_code"], *channels)
        equal = captures["java"] == captures["rust"]
        if row["raw_equal"] != equal:
            raise ValueError(f"Runtime recorded equality wrong: {row['id']}")
        if row["id"] in m1_runtime.SUCCESS_CASES:
            if not equal or captures["java"][0] != 0 or captures["java"][2] != b"":
                raise ValueError(f"Runtime success mismatch: {row['id']}")
            successes.append(row["id"])
        else:
            if captures["java"][0] != 1 or captures["rust"][0] != 1:
                raise ValueError(f"Runtime error process outcome changed: {row['id']}")
            if row["id"] == "forcing-cycle":
                (diagnostic_matches if equal else mismatches).append(row["id"])
            else:
                if not equal:
                    raise ValueError(f"Required whole diagnostic mismatch: {row['id']}")
                diagnostic_matches.append(row["id"])
    for identity in runtime["identities"]:
        if "snapshot" in identity:
            path = relocated_path(artifact, identity["snapshot"], "ci-runtime")
            relative = identity["snapshot"].split("/target/m1/ci-runtime/sources/", 1)[1]
            snapshot_identity(path, relative, identity["sha256"])
        else:
            path = relocated_path(artifact, identity["path"], "ci-runtime")
            if sha(path) != identity["sha256"]:
                raise ValueError("Runtime executable hash differs")

    lifecycle_dir = artifact / "ci-lifecycle"
    lifecycle = m1_lifecycle.check_report(lifecycle_dir)
    verify_oracle(lifecycle["oracle"])
    for row in lifecycle["sources"]:
        snapshot_identity(lifecycle_dir / row["snapshot"], row["path"], row["sha256"])
    lifecycle_outcomes = {
        "exact_protocol_comparisons": len(lifecycle["cases"]),
        "full_diagnostic_byte_mismatches": sum(not error["raw_equal"]
            for row in lifecycle["cases"] for error in row["observations"]["diagnostics"]),
        "java_negative_observation": lifecycle["java_negative_observation"]["observations"],
        "source_stability_before_execution": lifecycle["source_stability_before_execution"],
        "source_stability_after_execution": lifecycle["source_stability_after_execution"],
    }

    platform_dir = artifact / "ci-platforms"
    platform = json.loads((platform_dir / "report.json").read_text())
    if not platform["source_stability"]:
        raise ValueError("Platform sources changed during execution")
    cases_manifest = json.loads((platform_dir / "oracle-native/cases.json").read_text())
    expected_manifest = json.loads(git_bytes("tests/fixtures/m1/semantics/cases.json"))
    total = len(cases_manifest["cases"])
    oracle_expected = total - len(m1_platforms.KNOWN_GAPS)
    if cases_manifest != expected_manifest or not total:
        raise ValueError("Primitive case inventory changed")
    captures = {"java": (platform_dir / "oracle-native/java.stdout.bin").read_bytes(),
                "rust": (platform_dir / "oracle-native/rust.stdout.bin").read_bytes(),
                "node": (platform_dir / "execution/node.stdout.bin").read_bytes(),
                "browser": (platform_dir / "execution/browser.stdout.bin").read_bytes()}
    recomputed = m1_platforms.compare(cases_manifest["cases"], captures)
    if recomputed != platform["comparisons"] or not m1_platforms.contract_matches(recomputed):
        raise ValueError("Platform raw comparison/known-gap inventory differs")
    execution = json.loads((platform_dir / "execution/execution.json").read_text())
    check_scenario_lists(platform_dir, execution)
    m1_platforms.check_scenarios(execution)
    if execution != platform["execution"]:
        raise ValueError("Platform execution metadata differs")
    if (execution["node"] != "v" + node_pin or execution["nodeVersions"]["node"] != node_pin
            or execution["total"] != total or not execution["browser"]
            or execution["fixtureSha256"] != hashlib.sha256(git_bytes("tests/fixtures/m1/semantics/cases.json")).hexdigest()):
        raise ValueError("Platform runtime identity or fixture bytes differ")
    if (platform["total"] != total or platform["shared_engine_passed"] != total
            or platform["oracle_passed"] != {target: oracle_expected for target in ("rust", "node", "browser")}
            or platform["compatibility_status"] != "fail" or platform["experiment_contract_status"] != "pass"):
        raise ValueError("Platform status falsely reports compatibility")
    for relative, expected in platform["source_hashes"].items():
        snapshot_identity(platform_dir / "sources" / relative, relative, expected)
    for relative, expected in platform["artifacts"].items():
        if sha(platform_dir / relative) != expected:
            raise ValueError(f"Platform artifact identity differs: {relative}")
    oracle_native = json.loads((platform_dir / "oracle-native/report.json").read_text())
    verify_oracle(oracle_native["oracle"])
    if json.loads((platform_dir / "sources.json").read_bytes()) != platform["source_hashes"]:
        raise ValueError("Platform source inventory disagrees with report")
    for relative, expected in oracle_native.get("sources", {}).items():
        snapshot_identity(platform_dir / "oracle-native/sources" / relative, relative, expected)
    for language in ("java", "rust"):
        for channel in ("stdout", "stderr"):
            data = (platform_dir / "oracle-native" / f"{language}.{channel}.bin").read_bytes()
            if hashlib.sha256(data).hexdigest() != oracle_native["records"][language][f"{channel}_sha256"]:
                raise ValueError("Primitive process capture identity differs")
        if oracle_native["records"][language]["exit_code"] != 0:
            raise ValueError("Primitive process failed")
    if (oracle_native["total"] != total or oracle_native["passed"] != oracle_expected
            or oracle_native["mismatched"] != len(m1_platforms.KNOWN_GAPS)
            or oracle_native["fixture_sha256"] != hashlib.sha256(git_bytes("tests/fixtures/m1/semantics/cases.json")).hexdigest()):
        raise ValueError("Nested primitive comparison summary differs")
    commands = json.loads((platform_dir / "commands.json").read_text())
    for row in commands:
        if row["exit_code"] != (1 if row["name"] == "oracle-native" else 0):
            raise ValueError(f"Platform acquisition subprocess failed: {row['name']}")
    return {"committed_snapshot_copies_checked": len(SNAPSHOT_CHECKS), "unique_committed_source_files": len(set(SNAPSHOT_CHECKS)),
            "retained_graal_evidence": graal, "lifecycle": lifecycle_outcomes, "frontend": {"exact_comparisons": len(m1_frontend.CASES), "source_stability": True},
            "java_host": {"observation_suites": len(m1_host.MODES), "rust_byte_comparisons": 0, "source_stability": True},
            "runtime": {"exact_value_cases": successes, "exact_whole_diagnostic_cases": diagnostic_matches, "known_diagnostic_byte_mismatches": mismatches},
            "platform": {"total": total, "all_shared_engine_matches": total,
                         "java_matches_each_target": oracle_expected, "known_gaps": sorted(m1_platforms.KNOWN_GAPS),
                         "scenarios_each_target": len(m1_platforms.REQUIRED_SCENARIOS),
                         "compatibility_status": "fail", "experiment_contract_status": "pass"}}
