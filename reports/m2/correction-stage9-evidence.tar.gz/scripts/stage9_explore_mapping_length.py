from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import sys,json,shutil
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
candidate=Path('target/m2/stage9-runtime-replay-05/language_probe');shutil.copy2(candidate,art/'language_probe')
(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(candidate.resolve()),sha256=oracle.sha256(candidate),binding='Frozen provisional Stage9 replay05 candidate; retained before the inherited Mapping.length correction. Not formal build-bound evidence.')))
r=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert r['exit_code']==0
cases=[]
def add(id,source,family):cases.append(dict(id=id,source=source if source.endswith('\n') else source+'\n',family=family,expression='result'))
for first,second in [(1,17),(1,2)]:
 for warm in ['none','left','right','both']:
  prefix='left=new Listing {'+str(first)+';'+str(second)+'};right=new Listing {'+str(first)+';'+str(second)+'};p=new Mapping {[left]=0};c=(p){[right]=7};result='
  pre=''.join('let(w'+side+'='+side+'[1]) 'for side in ([] if warm=='none' else ['left','right'] if warm=='both' else [warm]))
  add('mapping-length-listing-'+str(first)+'-'+str(second)+'-'+warm,prefix+pre+'c.length','mapping-length-hashset')
for swapped in [False,True]:
 add('mapping-length-local-query-'+('ordinary' if not swapped else 'local'),'left=new Listing {local x=0+0;x};right=new Listing {0};p=new Mapping {['+('left' if not swapped else 'right')+']=0};c=(p){['+('right' if not swapped else 'left')+']=7};result=c.length','mapping-length-direction')
for id,left,right in [('nan','NaN','NaN'),('signed-zero','0.0','-0.0'),('boxed-numeric','1','1.0'),('folded-int-collision','0','4294967297'),('entry-dynamic','new Dynamic {[1]=0}','new Dynamic {[1]=0}')]:
 add('mapping-length-key-'+id,'p=new Mapping {['+left+']=0};c=(p){['+right+']=7};result=c.length','mapping-length-hashset-controls')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','target/m2/stage9_explore_mapping_length.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{k}.java' for k in ['Object','Dynamic','Listing','Mapping','Typed','List','Class']]
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 d=out/'cases'/c['id'];d.mkdir(parents=True);source=d/'input.pkl';source.write_bytes(c['source'].encode())
 java=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],d)
 rust=lang.capture([str(art/'language_probe'),*lang.expression_arguments(source,c['expression'])],d,'rust',meta['environment'])
 expected='success' if (d/'java.outcome.bin').read_bytes()==b'success\n' else 'error'
 status=lang.status(dict(expected_outcome=expected),java,rust,*[(d/f'{runtime}.{channel}.bin').read_bytes() for runtime in ['java','rust'] for channel in ['stdout','stderr']],(d/'java.outcome.bin').read_bytes())
 row=dict(id=c['id'],family=c['family'],source_uri=source.as_uri(),input_sha256=oracle.sha256(source),java=java,rust=rust,status=status,java_stdout=(d/'java.stdout.bin').read_text(),rust_stdout=(d/'rust.stdout.bin').read_text(),java_stderr=(d/'java.stderr.bin').read_text(),rust_stderr=(d/'rust.stderr.bin').read_text())
 print(c['id'],status,java['exit_code'],repr(row['java_stdout']),rust['exit_code'],repr(row['rust_stdout']),flush=True)
 return row
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
