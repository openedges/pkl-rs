import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import org.graalvm.collections.*;
public final class M2Stage9MapProbe {
 static boolean logging=true;
 static void event(String s){ if(logging)System.out.println(s); }
 static final class Key {
  final String id; final int hash; boolean fail; CountDownLatch entered,release;
  Key(String i,int h){id=i;hash=h;}
  public int hashCode(){event("hash "+id+" "+hash);if(entered!=null){entered.countDown();try{if(!release.await(10,TimeUnit.SECONDS))throw new IllegalStateException("gate timeout");}catch(InterruptedException e){throw new RuntimeException(e);}}if(fail)throw new IllegalStateException("hash "+id);return hash;}
  public boolean equals(Object o){event("equals "+id+" "+((Key)o).id);return this==o;}
  public String toString(){return id;}
 }
 static Object field(Object o,String n)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
 static void snapshot(EconomicMap<Key,Integer> m,String label)throws Exception{
  Object[] entries=(Object[])field(m,"entries");byte[] hash=(byte[])field(m,"hashArray");
  System.out.println("state "+label+" size="+m.size()+" total="+field(m,"totalEntries")+" capacity="+(entries==null?0:entries.length/2)+" hash="+(hash==null?"null":Arrays.toString(hash)));
  var c=m.getEntries();var values=new StringJoiner(",");while(c.advance())values.add(c.getKey()+"="+c.getValue());System.out.println("cursor "+values);
 }
 static void lookup(EconomicMap<Key,Integer> m,Key k){System.out.println("get "+k+" => "+m.get(k));}
 static void collisions()throws Exception{
  var m=EconomicMap.<Key,Integer>create();for(int i=0;i<4;i++)m.put(new Key("k"+i,i*32),i);
  snapshot(m,"linear4");lookup(m,new Key("q64",64));m.put(new Key("k4",128),4);snapshot(m,"hashed5");lookup(m,new Key("q64",64));lookup(m,new Key("q1",1));lookup(m,new Key("qminus1",-1));lookup(m,new Key("qmin",Integer.MIN_VALUE));lookup(m,new Key("qhex",0x12345678));
  var s=EconomicMap.<String,Integer>create();s.put("Aa",1);s.put("BB",2);s.put("a",3);s.put("b",4);s.put("c",5);System.out.println("strings Aa="+s.get("Aa")+" BB="+s.get("BB")+" hashes="+"Aa".hashCode()+","+"BB".hashCode());
 }
 static void growth()throws Exception{
  var m=EconomicMap.<Key,Integer>create();logging=false;for(int i=0;i<22;i++)m.put(new Key("k"+i,i),i);logging=true;snapshot(m,"unique22");m.put(new Key("collision23",32),23);snapshot(m,"collision23");
  m=EconomicMap.create();logging=false;for(int i=0;i<225;i++)m.put(new Key("k"+i,i),i);logging=true;snapshot(m,"before226");m.put(new Key("k225",225),225);snapshot(m,"after226");
 }
 static void failure(int index,boolean gate)throws Exception{
  var m=EconomicMap.<Key,Integer>create();var keys=new Key[5];for(int i=0;i<5;i++)keys[i]=new Key("k"+i,i*32);for(int i=0;i<4;i++)m.put(keys[i],i);
  keys[index].fail=!gate;
  if(gate){keys[index].entered=new CountDownLatch(1);keys[index].release=new CountDownLatch(1);}
  if(gate){var f=new FutureTask<Void>(() -> {m.put(keys[4],4);return null;});new Thread(f).start();if(!keys[index].entered.await(10,TimeUnit.SECONDS))throw new IllegalStateException("not entered");snapshot(m,"gated-"+index);System.out.println("pending "+!f.isDone());keys[index].release.countDown();f.get(10,TimeUnit.SECONDS);keys[index].entered=null;snapshot(m,"resumed-"+index);}
  else{try{m.put(keys[4],4);}catch(Exception e){System.out.println("caught "+e);}snapshot(m,"failed-"+index);keys[index].fail=false;for(var k:keys)lookup(m,k);m.put(keys[4],44);snapshot(m,"retry-"+index);for(var k:keys)lookup(m,k);}
 }
 static void rebuildFailure(int size)throws Exception {
  var m=EconomicMap.<Key,Integer>create();var keys=new Key[size+1];for(int i=0;i<keys.length;i++)keys[i]=new Key("k"+i,0);logging=false;for(int i=0;i<size;i++)m.put(keys[i],i);logging=true;snapshot(m,"before-rebuild");keys[2].fail=true;try{m.put(keys[size],size);}catch(Exception e){System.out.println("caught "+e);}snapshot(m,"failed-rebuild");keys[2].fail=false;for(int i=0;i<Math.min(size,5);i++)lookup(m,keys[i]);lookup(m,keys[size]);
 }
 public static void main(String[] args)throws Exception{switch(args[0]){case "rebuild-failure"->rebuildFailure(Integer.parseInt(args[1]));case "collisions"->collisions();case "growth"->growth();case "failure"->failure(Integer.parseInt(args[1]),false);case "gate"->failure(Integer.parseInt(args[1]),true);default->throw new IllegalArgumentException();}}
}
