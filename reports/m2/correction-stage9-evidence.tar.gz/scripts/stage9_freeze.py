from pathlib import Path
import sys,shutil,json,subprocess
sys.path.insert(0,'tools')
import m2_manifest as c,oracle
out=Path('target/m2/stage9-selection-baseline-01');out.mkdir(exist_ok=False)
s=c.load(c.SELECTION); assert len(s['cases'])==907
(out/'selection.json').write_bytes(c.encoded(s));(out/'cases.json').write_bytes(c.encoded(s['cases']))
ident={}
for case in s['cases']:
 p=Path(case['input']); dest=out/'inputs'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes()); ident[case['id']]=dict(definition=case,input_sha256=oracle.sha256(p))
(out/'identities.json').write_bytes(c.encoded(ident))
p=Path('target/m2/language-stage8-final/artifacts/language_probe');shutil.copy2(p,out/'language_probe')
(out/'candidate.json').write_bytes(c.encoded(dict(source=str(p.resolve()),sha256=oracle.sha256(p),source_binding='Frozen original Stage 8 final recorded artifact; implementation 5024708, repository baseline 14d2791.')))
(out/'workspace.json').write_bytes(c.encoded(dict(head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),status=subprocess.check_output(['git','status','--porcelain=v1']).decode(),selection_sha256=oracle.sha256(Path(c.SELECTION)))))
print(out, len(ident),oracle.sha256(p))
