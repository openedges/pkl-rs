from pathlib import Path
import sys,json,shutil
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
origin=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False)
candidate=out/'language_probe';shutil.copy2('target/release/examples/language_probe',candidate)
(out/'candidate.json').write_bytes(contract.encoded(dict(sha256=oracle.sha256(candidate),binding='Provisional exploratory replay; runtime source is under active editing, no final build-source claim.')))
rows=[]
for c in json.loads((origin/'observations.json').read_bytes()):
 d=out/'cases'/c['id'];d.mkdir(parents=True)
 source=origin/'cases'/c['id']/'input.pkl'
 rust=lang.capture([str(candidate),*lang.expression_arguments(source,'result')],d,'rust',meta['environment'])
 old=source.parent
 expected='success' if (old/'java.outcome.bin').read_bytes()==b'success\n' else 'error'
 status=lang.status(dict(expected_outcome=expected),c['java'],rust,*[(p/f'{runtime}.{channel}.bin').read_bytes() for runtime,p in [('java',old),('rust',d)] for channel in ['stdout','stderr']],(old/'java.outcome.bin').read_bytes())
 rows.append(dict(id=c['id'],status=status,rust=rust,java_origin=str(old),input_sha256=oracle.sha256(source)))
 print(c['id'],status,flush=True)
(out/'observations.json').write_bytes(contract.encoded(rows))
