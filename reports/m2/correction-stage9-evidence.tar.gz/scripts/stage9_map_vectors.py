from pathlib import Path
import sys,shutil
sys.path.insert(0,'tools')
import oracle,m2_language as l,m2_manifest as c
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(c.ROOT,fetch=False);(out/'oracle.json').write_bytes(c.encoded(meta));art=out/'artifacts';art.mkdir();src=Path('target/m2/M2Stage9MapProbe.java');shutil.copy2(src,out/src.name)
r=l.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art),str(src.resolve())],out,'javac',meta['environment']);assert r['exit_code']==0
base=list(meta['command'][:-1]);base[-1]+=':'+str(art);rows=[]
for args in [('collisions',),('growth',)]+[('failure',str(i))for i in range(5)]+[('gate',str(i))for i in [0,2,4]]:
 id='-'.join(args);d=out/id;d.mkdir();r=l.capture([*base,'M2Stage9MapProbe',*args],d,'java',meta['environment']);rows.append(dict(id=id,process=r));print(id,r['exit_code'],flush=True)
(out/'observations.json').write_bytes(c.encoded(rows));(out/'source-identities.json').write_bytes(c.encoded({str(src):oracle.sha256(src),'oracle.lock.json':oracle.sha256(Path('oracle.lock.json'))}));(out/'evidence-sha256.json').write_bytes(c.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
