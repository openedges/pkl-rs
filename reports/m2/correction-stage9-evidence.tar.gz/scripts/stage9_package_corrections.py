"""Seal the Mapping.length correction while retaining the first archive unchanged."""
from pathlib import Path
from collections import Counter
import argparse,json,shutil,sys
sys.path.insert(0,'tools')
import evidence,m2_manifest as contract,m2_language as language,oracle
ROOT=contract.ROOT;TARGET=ROOT/'target/m2'
PARENT_SHA='13c8689f1d6fe51e772757cc428f71a584bf2cf130b291f03259022f1c7f9d15'
DIRECTORIES=['stage9-exploration-10','stage9-runtime-replay-06','stage9-platform-java-03','stage9-original-length-checkpoint-01','stage9-original-length-checkpoint-02','stage9-original-length-checkpoint-03','stage9-length-selection-baseline-01','prior-selection-stage9-provisional-02','prior-selection-stage9-final','language-stage9-final','language-stage9-process','new-selection-stage9-prepush','validation-stage9-final','platforms-stage9-final','frontend-stage9-final','runtime-stage9-final','lifecycle-stage9-final','regression-commands-stage9-final']

def load(path):return json.loads(path.read_bytes())
def summary_rows(path):
 report=load(path/'report.json');rows=report['results'];return dict(directory=path.name,rows=len(rows),status_counts=dict(Counter(row['status']for row in rows)),candidate=load(path/'candidate.json')if(path/'candidate.json').exists()else report.get('candidate_binding'))
def inventories(output):
 result=[]
 for name in DIRECTORIES:
  manifest=output/name/'evidence-sha256.json'
  if manifest.exists():
   rows=load(manifest)
   for p,h in rows.items():assert oracle.sha256(output/name/p)==h,(name,p)
   result.append(dict(directory=name,files=len(rows),all_original_checksums_match=True))
 return result

def build_index(output,plan):
 promotion=load(output/'sidecars/stage9-promotion.json');oldpromotion=load(output/'stage9-length-selection-baseline-01/first-promotion.json');assert promotion['selected_count']==152 and oldpromotion['selected_count']==137
 current=load(ROOT/contract.SELECTION);old=load(output/'stage9-length-selection-baseline-01/selection.json');assert len(current['cases'])==1059 and current['cases'][:1044]==old['cases']
 for case in old['cases']:assert (ROOT/case['input']).read_bytes()==(output/'stage9-length-selection-baseline-01/inputs'/case['input']).read_bytes()
 assert promotion['provenance'][:137]==oldpromotion['provenance'] and promotion['selected'][:137]==oldpromotion['selected']
 final=load(output/'stage9-runtime-replay-06/results.json');bycase={(Path(row['baseline']).name,row['id']):row for row in final};selected={(Path(row['exploration']).name,row['case_id'])for row in promotion['provenance']};excluded={(Path(row['exploration']).name,row['case_id'])for row in promotion['excluded']};assert len(selected)==152 and len(excluded)==48 and set(bycase)==selected|excluded and not selected&excluded;assert all(bycase[key]['status']=='pass'for key in selected)
 fresh=load(output/'stage9-exploration-10/observations.json');assert len(fresh)==15
 checkpoints=[]
 for name in ['stage9-original-length-checkpoint-01','stage9-original-length-checkpoint-02','stage9-original-length-checkpoint-03']:
  directory=output/name;row=load(directory/'observations.json')[0];folder=directory/'cases'/row['id'];checkpoints.append(dict(directory=name,candidate=load(directory/'candidate.json'),status=row['status'],source_uri=row['source_uri'],input_sha256=row['input_sha256'],java_stdout=(folder/'java.stdout.bin').read_text(),rust_stdout=(folder/'rust.stdout.bin').read_text(),java_process=row['java'],rust_process=row['rust']))
 assert checkpoints[0]['java_stdout']=='1' and checkpoints[0]['rust_stdout']=='2' and checkpoints[0]['status']=='mismatch'
 assert checkpoints[1]['java_stdout']=='1' and checkpoints[1]['rust_stdout']=='1' and checkpoints[1]['status']=='pass'
 assert checkpoints[2]['java_stdout']=='1' and checkpoints[2]['rust_stdout']=='2' and checkpoints[2]['status']=='mismatch'
 oldcandidate=oracle.sha256(output/'language-stage9-final/artifacts/language_probe');assert oldcandidate==checkpoints[2]['candidate']['sha256'];fixedcandidate=load(output/'stage9-runtime-replay-06/candidate.json');assert fixedcandidate['sha256']==checkpoints[1]['candidate']['sha256']
 prior_failed=summary_rows(output/'prior-selection-stage9-final');prior_fixed=summary_rows(output/'prior-selection-stage9-provisional-02')
 assert prior_failed['status_counts']=={'pass':904,'oracle-error':1,'mismatch':2};assert prior_fixed['status_counts']=={'pass':905,'oracle-error':1,'mismatch':1}
 first_new=summary_rows(output/'new-selection-stage9-prepush');assert first_new['rows']==137 and first_new['status_counts']=={'pass':137}
 first=output/'language-stage9-final';casefolders=[p for p in (first/'cases').iterdir()if p.is_dir()];complete=[p for p in casefolders if(p/'java.process.json').exists()and(p/'rust.process.json').exists()];partial=[p.name for p in casefolders if p not in complete];assert not(first/'report.json').exists()
 platform=load(output/'stage9-platform-java-03/report.json');java_captures=sum(1 for name in DIRECTORIES for _ in(output/name).rglob('java.process.json'));rust_captures=sum(1 for name in DIRECTORIES for _ in(output/name).rglob('rust.process.json'))
 return dict(scope='Supplemental Stage 9 Mapping.length correction and retained superseded checkpoints. The first exploration archive remains immutable. Final corrected source-bound selection, validation, platform and CI reports are packaged separately and are not claimed by this supplement.',parent_archive=dict(path='reports/m2/exploration-stage9-evidence.tar.gz',sha256=PARENT_SHA,retained_unchanged=True,content_files=8885),packaging=dict(command=[sys.executable,*sys.argv],cwd=str(ROOT),retained_scripts_scope='Current snapshot only; retaining a script does not assert that it was executed or that its current version matches every historical invocation.'),selection=dict(original_stage8_cases=907,first_stage9_additions=137,additional_length_controls=15,total_stage9_additions=152,total_selected=1059,total_metamorphic_relations=41,prior_1044_definitions_and_input_bytes_preserved=True,first_137_provenance_unchanged=True,selection_baseline='stage9-length-selection-baseline-01'),focused_acquisition=dict(directory='stage9-exploration-10',rows=len(fresh),distinct_input_sha256=len({row['input_sha256']for row in fresh}),initial_status_counts=dict(Counter(row['status']for row in fresh)),candidate=load(output/'stage9-exploration-10/candidate.json')),corrected_unified_replay=dict(directory='stage9-runtime-replay-06',rows=len(final),status_counts=dict(Counter(row['status']for row in final)),selected_pass=len(selected),excluded_status_counts=dict(Counter(bycase[key]['status']for key in excluded)),candidate=fixedcandidate),actual_original_fixture_checkpoints=checkpoints,first_failed_original_907=prior_failed,corrected_original_907=prior_fixed,first_137_at_actual_fixture_uris=first_new,interrupted_first_formal=dict(directory='language-stage9-final',candidate_sha256=oldcandidate,case_directories=len(casefolders),complete_java_and_rust_captures=len(complete),incomplete_cases=partial,full_report_present=False,interruption=load(first/'interruption.json'),scope='Partial interrupted acquisition. Complete process captures are retained; no complete selected report or source-stability verdict was produced.'),platform_java=dict(directory='stage9-platform-java-03',captures=len(platform['results']),uri=platform['uri'],helper_sha256=platform['helper_sha256'],scope=platform['scope']),superseded_checkpoint_directories=['validation-stage9-final','platforms-stage9-final','frontend-stage9-final','runtime-stage9-final','lifecycle-stage9-final','regression-commands-stage9-final'],excluded_active_final_directories='All final-02 and CI acquisition directories are deliberately excluded; their current evidence is packaged separately by the root agent.',retained_process_captures=dict(java=java_captures,rust=rust_captures,scope='Counts include repeats, superseded candidate captures, first partial formal captures and oracle inner observations. They are not distinct requirements or a compatibility-pass count.'),count_contract='Acquisition rows, process captures, distinct source-byte hashes, selected passes and retained excluded mismatches are separate counts. Raw channels, commands, outcomes, artifact and source identities are preserved without normalization.',source_inventory='CONTENT_SOURCES.json',corrected_source_snapshot=dict(directory='corrected-sources',scope='Current frozen workspace source bytes after the correction, with explicit correspondence to the corrected provisional replay source hashes. This is not a recorded-build claim; the final source-bound report is separate.',runtime_paths_match_provisional_replay=True),original_inventories=inventories(output))

def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--archive',type=Path,required=True);a=p.parse_args();parent=ROOT/'reports/m2/exploration-stage9-evidence.tar.gz';assert oracle.sha256(parent)==PARENT_SHA
 scripts=sorted(f for f in TARGET.iterdir()if f.is_file()and'stage9'in f.name.lower()and f.suffix in ['.py','.java']);sidecars=[TARGET/name for name in ['stage9-promotion.json','stage9-length-promotion.json']];rows=[]
 for name in DIRECTORIES:
  directory=TARGET/name;assert directory.is_dir(),name
  for f in sorted(directory.rglob('*')):
   if f.is_file():rows.append(dict(source=str(f.relative_to(ROOT)),destination=str(f.relative_to(TARGET)),sha256=oracle.sha256(f)))
 replay_sources=load(TARGET/'stage9-runtime-replay-06/source-identities-before.json')
 for relative in language.source_paths():
  f=ROOT/relative;digest=oracle.sha256(f)
  if relative.startswith('crates/') and f.suffix in ['.rs','.toml']:assert replay_sources.get(relative)==digest,relative
  rows.append(dict(source=relative,destination='corrected-sources/'+relative,sha256=digest))
 for category,files in [('scripts',scripts),('sidecars',sidecars)]:
  for f in files:rows.append(dict(source=str(f.relative_to(ROOT)),destination=f'{category}/{f.name}',sha256=oracle.sha256(f)))
 output=a.output.resolve();output.mkdir(parents=True,exist_ok=False)
 for row in rows:
  f=ROOT/row['source'];assert oracle.sha256(f)==row['sha256'];dest=output/row['destination'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dest);assert oracle.sha256(dest)==row['sha256']
 for row in rows:assert oracle.sha256(ROOT/row['source'])==row['sha256'],'Source changed during copy: '+row['source']
 plan=dict(directories=DIRECTORIES,files=rows);(output/'CONTENT_SOURCES.json').write_bytes(contract.encoded(plan));index=build_index(output,plan);(output/'INDEX.json').write_bytes(contract.encoded(index));assert not a.archive.exists();evidence.create(output,a.archive,[]);assert oracle.sha256(parent)==PARENT_SHA
 print(json.dumps(dict(output=str(output),archive=str(a.archive),archive_sha256=oracle.sha256(a.archive),source_files=len(rows),selection=index['selection'],focused=index['focused_acquisition'],corrected_replay=index['corrected_unified_replay'],interrupted_first_formal=index['interrupted_first_formal'],retained_process_captures=index['retained_process_captures']),indent=2))
if __name__=='__main__':main()
