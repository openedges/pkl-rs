"""Capture exact Java diagnostics using the URI supplied by JS adapter scenarios."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
import oracle
import m2_language as runner
import m2_manifest as manifest

output = ROOT / "target/m2/stage9-platform-java-01"
output.mkdir(parents=True, exist_ok=False)
metadata = oracle.ensure_oracle(ROOT, fetch=False)
(output / "oracle.json").write_bytes(manifest.encoded(metadata))
helper = output / "M2BoundaryProbe.java"
helper.write_text("""import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.pkl.core.EvaluatorBuilder;
import org.pkl.core.ModuleSource;
import org.pkl.core.PklException;
public final class M2BoundaryProbe {
  public static void main(String[] args) throws Exception {
    try (var evaluator = EvaluatorBuilder.preconfigured().setModuleCacheDir(null)
        .setPowerAssertionsEnabled(Boolean.parseBoolean(args[2])).setColor(false)
        .setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()) {
      try {
        var module = ModuleSource.create(URI.create(args[1]), Files.readString(Path.of(args[0])));
        var result = evaluator.evaluateExpressionString(module, "result");
        Files.writeString(Path.of(args[3]), "success\\n", StandardCharsets.UTF_8);\n        System.out.write(result.getBytes(StandardCharsets.UTF_8));
      } catch (PklException error) {
        Files.writeString(Path.of(args[3]), "pkl-exception\\t" + error.getClass().getName() + "\\n", StandardCharsets.UTF_8);\n        System.err.write(error.getMessage().getBytes(StandardCharsets.UTF_8));
        System.exit(1);
      }
    }
  }
}
""")
classes = output / "classes"
classes.mkdir()
compiled = runner.capture([
    str(Path(metadata["java"]).with_name("javac")), "-encoding", "UTF-8",
    "-cp", metadata["artifact"], "-d", str(classes), str(helper)
], output, "javac", metadata["environment"])
assert compiled["exit_code"] == 0
cases = [('listing-local-cache-forward', 'left=new Listing {local x=1+0;x};right=new Listing {1};result=left==right\n', False), ('listing-local-cache-reverse', 'left=new Listing {local x=1+0;x};right=new Listing {1};result=right==left\n', False), ('mapping-local-cache-forward', 'left=new Mapping {local x=1+0;["a"]=x};right=new Mapping {["a"]=1};result=left==right\n', False), ('mapping-local-cache-reverse', 'left=new Mapping {local x=1+0;["a"]=x};right=new Mapping {["a"]=1};result=right==left\n', False), ('dynamic-local-cache-forward', 'left=new Dynamic {local x=1+0;a=x};right=new Dynamic {a=1};result=left==right\n', False), ('mapping-listing-cache-four-control', 'key=new Listing {throw("cache hash")};p=new Mapping {[key]=9};c=(p) {["a"]=1;["b"]=2;["c"]=3;["d"]=4};result=List(c[key],c["a"],c["b"],c["c"])[3]\n', False), ('mapping-listing-cache-fifth-position2', 'key=new Listing {throw("cache hash")};p=new Mapping {[key]=9};c=(p) {["a"]=1;["b"]=2;["c"]=3;["d"]=4};result=List(c["a"],c["b"],c[key],c["c"],c["d"])[4]\n', False), ('stable-keys-float-scalar', 'm=new Mapping {[0.0]=0;[-0.0]=1;[NaN]=2;[Infinity]=3;[-Infinity]=4;[1.0]=5;};result=m[0.0]==0 && m[-0.0]==1 && m[NaN]==2 && m[Infinity]==3 && m[-Infinity]==4 && m[1.0]==5\n', False), ('strict-list-bucket-keys-23', 'result=new Mapping {[List(0)]=0;[List(32)]=1;[List(64)]=2;[List(96)]=3;[List(128)]=4;[List(160)]=5;[List(192)]=6;[List(224)]=7;[List(256)]=8;[List(288)]=9;[List(320)]=10;[List(352)]=11;[List(384)]=12;[List(416)]=13;[List(448)]=14;[List(480)]=15;[List(512)]=16;[List(544)]=17;[List(576)]=18;[List(608)]=19;[List(640)]=20;[List(672)]=21;[List(704)]=22;}[List(704)]\n', False), ('listing-hash-bucket-1-17-left', 'left=new Listing {1;17};right=new Listing {1;17};result=let(w=left[1]) new Mapping {[left]=10;["a"]=1;["b"]=2;["c"]=3;["d"]=4}[right]\n', False), ('listing-hash-bucket-1-2-left', 'left=new Listing {1;2};right=new Listing {1;2};result=let(w=left[1]) new Mapping {[left]=10;["a"]=1;["b"]=2;["c"]=3;["d"]=4}[right]\n', False), ('listing-hash-bucket-1-minus15-duplicate', 'left=new Listing {1;-15};right=new Listing {1;-15};result=let(w=left[1]) let(m=new Mapping {[left]=10;["a"]=1;["b"]=2;["c"]=3;["d"]=4;[right]=20}) m[right]\n', False), ('let-inner-member-body', 'result=let(x=1) new Dynamic { y=let(z=2) throw("member") }.y\n', False), ('let-initializer-throw', 'result=let(x=throw("initializer")) x\n', False), ('let-declared-unicode-multiline', 'module demo.lets\nresult = let (message = "😀")\n  throw(message)\n', False)]

prefix = metadata["command"][:metadata["command"].index("-cp")]
rows = []
for name, source, power in cases:
    directory = output / name
    directory.mkdir()
    path = directory / "input.pkl"
    path.write_bytes(source.encode())
    command = [*prefix, "-cp", str(classes) + ":" + metadata["artifact"],
               "M2BoundaryProbe", str(path), "file:///m2-platform.pkl", str(power).lower(), str(directory / "java.outcome.bin")]
    capture = runner.capture(command, directory, "java", metadata["environment"])
    rows.append({
        "id": name, "source": source, "source_sha256": oracle.sha256(path),
        "power_assertions": power, "capture": capture,
        "outcome_sha256": oracle.sha256(directory / "java.outcome.bin"),
        "stdout": (directory / "java.stdout.bin").read_text(),
        "stderr": (directory / "java.stderr.bin").read_text(),
    })
    print(name, capture["exit_code"], flush=True)
(output / "report.json").write_bytes(manifest.encoded({
    "scope": "Pinned Java-only observations for exact JS adapter source URI; Rust platform verification separate.",
    "helper_sha256": oracle.sha256(helper), "uri": "file:///m2-platform.pkl", "results": rows
}))

paths=['target/m2/stage9_platform_java.py','references.lock','oracle.lock.json','tools/m2_language.py']
(output/'source-identities.json').write_bytes(manifest.encoded({p:oracle.sha256(ROOT/p) for p in paths}))
for p in paths:
 q=output/'sources'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes((ROOT/p).read_bytes())
(output/'evidence-sha256.json').write_bytes(manifest.encoded({str(p.relative_to(output)):oracle.sha256(p) for p in sorted(output.rglob('*')) if p.is_file()}))
