import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.function.Function;
import org.pkl.core.*;
import org.pkl.core.runtime.*;
public final class M2Stage9ClassProbe {
 static Object field(Object object,String name)throws Exception{Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
 public static void main(String[]args)throws Exception{
  Path output=Path.of(args[1]);Files.createDirectories(output);Path input=output.resolve(args[0].equals("unnamed")?"input.pkl":"named.pkl");Files.writeString(input,(args[0].equals("unnamed")?"":"module stage9.hashes\n")+"class C {}; class D {}\n");ModuleSource source=ModuleSource.path(input);
  try(Evaluator evaluator=EvaluatorBuilder.preconfigured().setColor(false).setModuleCacheDir(null).setEnvironmentVariables(Map.of()).setExternalProperties(Map.of()).build()){
   var security=(org.pkl.core.SecurityManager)field(evaluator,"securityManager");var resolver=(ModuleResolver)field(evaluator,"moduleResolver");Method eval=EvaluatorImpl.class.getDeclaredMethod("doEvaluate",ModuleSource.class,Function.class);eval.setAccessible(true);
   eval.invoke(evaluator,source,(Function<VmTyped,Object>)(module->{for(String expr:List.of("C","D","Int","Float","String","Dynamic","Listing","Mapping","List","Map","Set","Class","this.getClass()")){
    try{var value=(VmClass)VmUtils.evaluateExpression(module,expr,security,resolver);var info=value.getPClassInfo();System.out.println("class\t"+expr+"\t"+info.getQualifiedName()+"\t"+info.getModuleUri()+"\t"+value.hashCode()+"\t"+info.getQualifiedName().hashCode());}catch(Throwable e){System.out.println("error\t"+expr+"\t"+e.getClass().getName()+"\t"+e.getMessage());}}
    Object c=VmUtils.evaluateExpression(module,"C",security,resolver),d=VmUtils.evaluateExpression(module,"D",security,resolver);System.out.println("equality C-C="+c.equals(c)+" C-D="+c.equals(d));return null;}));
  }
 }
}
