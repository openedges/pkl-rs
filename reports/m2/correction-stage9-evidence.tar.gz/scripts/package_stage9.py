"""Retain the final post-review acquisition separately from the earlier checkpoint."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path.cwd()
base = root / "target/m2"
reports = root / "reports/m2"
suffix = "-stage9-final"


def load(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def archive(source, name):
    subprocess.run([sys.executable, "tools/evidence.py", "create", str(source),
                    str(reports / name)], check=True)


language = load(base / ("language" + suffix) / "report.json")
platforms = load(base / ("platforms" + suffix) / "report.json")
frontend = load(base / ("frontend" + suffix) / "report.json")
runtime = load(base / ("runtime" + suffix) / "report.json")
lifecycle = load(base / ("lifecycle" + suffix) / "report.json")
validation_dir = base / ("validation" + suffix)
validation = load(validation_dir / "report.json")
assert all(row["exit_code"] == 0 for row in validation["checks"])
assert language["source_stability"] and language["artifact_stability"]
assert platforms["source_stability"] and frontend["source_stability"]
assert lifecycle["source_stability_before_execution"] and lifecycle["source_stability_after_execution"]
assert language["selected_count"] == len(load(root / "tests/fixtures/m2/cases.json")["cases"])
assert {row["id"] for row in language["results"] if row["status"] != "pass"} == {
    "error-cycle", "error-remainder-zero"
}
assert len(language["metamorphic_results"]) == len({tuple(row["metamorphic_relation"]["case_ids"]) for row in load(root / "compatibility/m2-language.json")["cases"] if "metamorphic_relation" in row})
assert all(row["status"] == "pass" for row in language["metamorphic_results"])
assert platforms["experiment_contract_status"] == "pass"
assert len(platforms["execution"]["nodeChecks"]) == 39
assert len(platforms["execution"]["browserChecks"]) == 39
prior = load(base / ("prior-selection" + suffix) / "report.json")
assert len(prior["results"]) == 907
assert {row["id"] for row in prior["results"] if row["status"] != "pass"} == {
    "error-cycle", "error-remainder-zero"
}
for name, expected in language["source_sha256"].items():
    assert digest(root / name) == expected, name
validation["rust_passed"] = sum(map(int, re.findall(
    r"test result: ok\. (\d+) passed", (validation_dir / "3.stdout.bin").read_text())))
validation["rust_intentionally_ignored"] = sum(map(int, re.findall(
    r"\d+ failed; (\d+) ignored", (validation_dir / "3.stdout.bin").read_text())))
validation["python_passed"] = int(re.search(
    r"Ran (\d+) tests", (validation_dir / "5.stderr.bin").read_text())[1])
validation["evidence_sha256"] = {
    str(p.relative_to(validation_dir)): digest(p)
    for p in sorted(validation_dir.rglob("*")) if p.is_file()
}
gates_dir = base / ("gates" + suffix)
gates_dir.mkdir(exist_ok=False)
gate_rows = []
for name, expected in [("report", 0), ("development", 0), ("subset", 1), ("full", 1)]:
    command = [sys.executable, "tools/m2_language.py", "--verify-" + name,
               str(base / ("language" + suffix))]
    result = subprocess.run(command, capture_output=True)
    row = {"command": command, "exit_code": result.returncode}
    for channel in ["stdout", "stderr"]:
        path = gates_dir / (name + "." + channel + ".bin")
        path.write_bytes(getattr(result, channel))
        row[channel + "_sha256"] = digest(path)
    gate_rows.append(row)
    assert result.returncode == expected, (name, result.returncode, result.stderr)
gates = {"scope": "Integrity/development checks and strict selected/full compatibility gates; failures retained.",
         "rows": gate_rows}
write(gates_dir / "report.json", gates)
summary = load(reports / "stage8-final-summary.json")
summary.pop("implementation_commit", None)
summary.pop("implementation_source_verification", None)
summary["scope"] = "M2 stage 9 stable Java hashes, map bucket and partial-cache publication behavior, local/duplicate cache comparisons, and let diagnostic scopes, including GC and Host lifecycle verification. Full language milestone remains incomplete."
summary["language"].update({
    key: language[key] for key in
    ["selected_count", "status_counts", "source_stability", "artifact_stability", "candidate", "inventory_counts"]
})
summary["language"]["source_snapshot_count"] = len(language["source_sha256"])
summary["language"]["metamorphic_relations"] = len(language["metamorphic_results"])
summary["language"]["metamorphic_statuses"] = [row["status"] for row in language["metamorphic_results"]]
summary["language"]["full_gate_failure_reasons"] = len(language["full_gate_failures"])
summary["language"]["known_failures"] = [
    {"id": row["id"], "status": row["status"]}
    for row in language["results"] if row["status"] != "pass"
]
summary["language"]["power_assertion_profiles"] = sum(
    row.get("power_assertions", False) for row in load(root / "tests/fixtures/m2/cases.json")["cases"])
summary["platforms"] = {key: platforms[key] for key in [
    "total", "oracle_passed", "shared_engine_passed", "compatibility_status",
    "known_gaps", "experiment_contract_status", "source_stability"
]}
summary["platforms"].update({
    "node_scenarios": len(platforms["execution"]["nodeChecks"]),
    "browser_scenarios": len(platforms["execution"]["browserChecks"])
})
summary["regressions"] = {
    "frontend_raw_matches": sum(row["passed"] for row in frontend["results"]),
    "runtime_value_matches": sum(row["status"] == "bounded-value-bytes-match" for row in runtime["cases"]),
    "runtime_diagnostic_matches": sum(row["status"] == "diagnostic-bytes-match" for row in runtime["cases"]),
    "runtime_diagnostic_mismatches": sum(row["status"] == "diagnostic-byte-mismatch" for row in runtime["cases"]),
    "lifecycle_protocol_matches": sum(row["observations"]["protocol_raw_equal"] for row in lifecycle["cases"]),
    "lifecycle_full_diagnostic_mismatches": sum(
        not item["raw_equal"] for row in lifecycle["cases"] for item in row["observations"]["diagnostics"])
}
summary["validation"] = {key: validation[key] for key in ["rust_passed", "rust_intentionally_ignored", "python_passed"]}
summary["prior_selection_replay"] = {
    "count": len(prior["results"]),
    "status_counts": prior["status_counts"],
    "scope": "Unchanged prior inputs against preserved stage 8 Java bytes; fresh full Java acquisition is recorded separately."
}
summary["gates"] = gates
write(reports / "stage9-final-summary.json", summary)
write(reports / "validation-stage9-final.json", validation)
for name in ["language", "validation", "platforms", "gates"]:
    archive(base / (name + suffix), name + "-stage9-final-evidence.tar.gz")
regressions = base / ("regressions" + suffix)
regressions.mkdir(exist_ok=False)
for name in ["frontend", "runtime", "lifecycle", "prior-selection"]:
    shutil.copytree(base / (name + suffix), regressions / name,
                    ignore=shutil.ignore_patterns("build", "__pycache__"))
shutil.copytree(base / "new-selection-stage9-prepush", regressions / "new-selection-prepush")
summary["new_selection_prepush"] = {"count": len(load(base / "new-selection-stage9-prepush/report.json")["results"]), "scope": "Fresh Java and frozen recorded candidate at actual fixture URIs before implementation push; full acquisition recorded separately.", "report": "regressions-stage9-final-evidence.tar.gz/new-selection-prepush/report.json"}
write(reports / "stage9-final-summary.json", summary)
archive(regressions, "regressions-stage9-final-evidence.tar.gz")
print(json.dumps({"language": summary["language"]["status_counts"],
                  "validation": summary["validation"], "regressions": summary["regressions"]}))
