"""Seal the complete Stage 9 exploration without rerunning or rewriting evidence."""
from pathlib import Path
from collections import Counter
import argparse,json,re,shutil,sys
sys.path.insert(0,'tools')
import evidence,m2_manifest as contract,oracle
ROOT=contract.ROOT
TARGET=ROOT/'target/m2'
DIRECTORY=re.compile(r'^(?:stage9-(?:exploration|let-java|let-replay|map-java|runtime-java|class-java|platform-java|runtime-replay|selection-baseline)-\d+|prior-selection-stage9-provisional-\d+)$')

def load(path):return json.loads(path.read_bytes())
def source_plan():
 directories=sorted(p for p in TARGET.iterdir() if p.is_dir() and DIRECTORY.fullmatch(p.name))
 scripts=sorted(p for p in TARGET.iterdir() if p.is_file() and ('stage9' in p.name.lower()) and p.suffix in ['.py','.java'])
 sidecars=sorted(p for p in TARGET.iterdir() if p.is_file() and 'stage9' in p.name.lower() and p.suffix=='.json' and not p.name.startswith('stage9-package-'))
 artifacts=sorted(TARGET.glob('stage9-economic-map-unit-*'))
 rows=[]
 for directory in directories:
  for p in sorted(directory.rglob('*')):
   if p.is_file():rows.append(dict(source=str(p.relative_to(ROOT)),destination=str(p.relative_to(TARGET)),sha256=oracle.sha256(p)))
 for category,paths in [('scripts',scripts),('sidecars',sidecars),('supplementary-artifacts',artifacts)]:
  for p in paths:rows.append(dict(source=str(p.relative_to(ROOT)),destination=f'{category}/{p.name}',sha256=oracle.sha256(p)))
 return dict(directories=[p.name for p in directories],scripts=[p.name for p in scripts],sidecars=[p.name for p in sidecars],supplementary_artifacts=[p.name for p in artifacts],files=rows)

def verify_original_selection(output):
 baseline=load(output/'stage9-selection-baseline-01/selection.json');current=load(ROOT/contract.SELECTION)
 assert len(baseline['cases'])==907 and current['cases'][:907]==baseline['cases']
 for case in baseline['cases']:
  assert (ROOT/case['input']).read_bytes()==(output/'stage9-selection-baseline-01/inputs'/case['input']).read_bytes(),case['id']
 return baseline,current

def verify_retained_inventories(output,directories):
 summaries=[]
 for name in directories:
  directory=output/name;inventory=directory/'evidence-sha256.json'
  if inventory.exists():
   rows=load(inventory)
   for path,digest in rows.items():assert oracle.sha256(directory/path)==digest,(name,path)
   summaries.append(dict(directory=name,files=len(rows),status='all-original-checksums-match'))
 return summaries

def collect_index(output,plan,final_name):
 baseline,current=verify_original_selection(output)
 promotion=load(output/'promotion.json' if (output/'promotion.json').exists() else output/'stage9-promotion.json');final=load(output/final_name/'results.json')
 by_case={(Path(row['baseline']).name,row['id']):row for row in final}
 selected={(Path(row['exploration']).name,row['case_id']) for row in promotion['provenance']}
 assert len(selected)==promotion['selected_count']
 excluded_keys={(Path(row['exploration']).name,row['case_id'])for row in promotion['excluded']}
 assert set(by_case)==selected|excluded_keys and not selected&excluded_keys
 assert len(final)==len(selected)+len(excluded_keys)
 assert all(by_case[key]['status']=='pass' for key in selected)
 assert len(current['cases'])==907+len(selected)
 acquisition=[];original=[];java_only=[];replays=[];platform=[];prior=[]
 for name in plan['directories']:
  directory=output/name
  if name.startswith(('stage9-exploration-','stage9-let-java-')):
   rows=load(directory/'observations.json');original.extend(dict(**row,directory=name)for row in rows)
   acquisition.append(dict(directory=name,rows=len(rows),distinct_input_sha256=len({row['input_sha256']for row in rows}),initial_status_counts=dict(Counter(row['status']for row in rows)),candidate=load(directory/'candidate.json')))
  elif name.startswith(('stage9-map-java-','stage9-runtime-java-','stage9-class-java-')):
   rows=load(directory/'observations.json');java_only.append(dict(directory=name,captures=len(rows),process_exit_counts=dict(Counter(str(row['process']['exit_code'])for row in rows)),scope='Pinned-JAR internal observations; successful process exit is not Rust compatibility or success of every inner evaluation. Inner result/error/trace sidecars remain authoritative.'))
  elif name.startswith('stage9-runtime-replay-'):
   rows=load(directory/'results.json');replays.append(dict(directory=name,rows=len(rows),status_counts=dict(Counter(row['status']for row in rows)),candidate=load(directory/'candidate.json')))
  elif name.startswith('stage9-let-replay-'):
   rows=load(directory/'observations.json');replays.append(dict(directory=name,rows=len(rows),status_counts=dict(Counter(row['status']for row in rows)),candidate=load(directory/'candidate.json')))
  elif name.startswith('stage9-platform-java-'):
   report=load(directory/'report.json');platform.append(dict(directory=name,captures=len(report['results']),uri=report['uri'],helper_sha256=report['helper_sha256'],scope=report['scope']))
  elif name.startswith('prior-selection-stage9-provisional-'):
   report=load(directory/'report.json');prior.append(dict(directory=name,rows=len(report['results']),status_counts=dict(Counter(row['status']for row in report['results'])),candidate=load(directory/'candidate.json'),scope='Provisional replay of the unchanged original 907 selected definitions; final build-bound selected report is separate.'))
 held=[]
 for row in final:
  if row['status']=='pass':continue
  name=Path(row['baseline']).name;folder=output/name/'cases'/row['id'];rust=output/final_name/name/row['id']
  assert (name,row['id']) not in selected
  held.append(dict(directory=name,id=row['id'],status=row['status'],selected=False,source_uri=Path(row['baseline']).joinpath('cases',row['id'],'input.pkl').as_uri(),java_process=load(folder/'java.process.json'),rust_process=row['rust'],java_outcome=(folder/'java.outcome.bin').read_text(),java_stdout=(folder/'java.stdout.bin').read_text(),java_stderr=(folder/'java.stderr.bin').read_text(),rust_stdout=(rust/'rust.stdout.bin').read_text(),rust_stderr=(rust/'rust.stderr.bin').read_text()))
 exclusions=[]
 for row in promotion['excluded']:
  key=(Path(row['exploration']).name,row['case_id']);exclusions.append(dict(**row,final_status=by_case[key]['status']))
 java_captures=sum(1 for name in plan['directories']for _ in (output/name).rglob('java.process.json'))
 rust_captures=sum(1 for name in plan['directories']for _ in (output/name).rglob('rust.process.json'))
 return dict(packaging=dict(command=[sys.executable,*sys.argv],cwd=str(ROOT),retained_scripts_scope='The scripts directory is the current acquisition-time snapshot. Its presence does not assert that every retained script was executed or that this snapshot matches every historical invocation. Per-acquisition source copies and raw process commands preserve the executed helper versions where recorded.'),scope='Bounded Stage 9 exploratory Java acquisition and identified provisional Rust replay. This archive does not replace the formal build-bound selected report, close the whole-language gate, or measure performance.',count_contract='Process captures, observation rows, and distinct input-byte hashes are separate counts. Reruns and equivalent sources remain preserved and are not distinct language requirements. Every original channel, outcome, command, URI and error sidecar is copied without normalization.',original_selection=dict(cases=907,definitions_unchanged=True,input_bytes_unchanged=True,frozen_candidate_sha256=oracle.sha256(output/'stage9-selection-baseline-01/language_probe')),selection=dict(new_cases=len(selected),total_cases=len(current['cases']),new_metamorphic_relations=promotion['metamorphic_relations'],promotion='promotion.json'),acquisition=dict(groups=len(acquisition),observation_rows=len(original),distinct_input_sha256=len({row['input_sha256']for row in original}),initial_status_counts=dict(Counter(row['status']for row in original)),per_group=acquisition),java_only_internal_observations=java_only,platform_captures=platform,provisional_original_selection=prior,replays=replays,final_replay=dict(directory=final_name,rows=len(final),status_counts=dict(Counter(row['status']for row in final)),selected_pass=len(selected),unselected_status_counts=dict(Counter(row['final_status']for row in exclusions))),retained_process_captures=dict(java=java_captures,rust=rust_captures,compilers_and_build_logs_counted_separately=True),exclusions=exclusions,held_mismatches=held,wrong_draft_captures=dict(directories=['stage9-exploration-05','stage9-exploration-06','stage9-exploration-07'],rows=12,scope='All initial default type/method/direct-call diagnostic captures and candidate mismatches are retained; valid default.apply cases are separately observed and selected. These do not become passes or development exceptions.'),identity_hash_correction='VmClass hashCode delegates to PClassInfo qualifiedName String hash (moduleName#className), despite identity equality. The earlier provisional-index class identity-hash statement is superseded by stage9-class-java-01 actual observations and pinned source evidence.',known_unverified=['The complete language inventory and full gate remain open, including all unmapped requirements and the two unchanged selected failures.','Identifier, ObjectMember and function JVM identity hash integers and cyclic-key behavior remain explicit limits; arbitrary Rust identity hashes are not byte-compatibility evidence.','Recursive depth-two diagnostics retain the preexisting repeated-frame compression difference; selected depth-one and wildcard controls do not close that gap.','Unsupported compound builtins, complete hidden-default type validation, expression-count limits and parser/missing-method diagnostic differences remain preserved nonselected observations.'],inventory_integrity=verify_retained_inventories(output,plan['directories']))

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--list',action='store_true');parser.add_argument('--check',action='store_true');parser.add_argument('--inventory',type=Path);parser.add_argument('--output',type=Path);parser.add_argument('--final-replay');parser.add_argument('--archive',type=Path);args=parser.parse_args()
 plan=source_plan()
 if args.inventory:args.inventory.write_bytes(contract.encoded(plan))
 if args.check:
  assert args.final_replay in plan['directories'];index=collect_index(TARGET,plan,args.final_replay);print(json.dumps(dict(selection=index['selection'],acquisition=index['acquisition'],final_replay=index['final_replay'],retained_process_captures=index['retained_process_captures'],java_only=index['java_only_internal_observations'],platform=index['platform_captures'],integrity_groups=len(index['inventory_integrity'])),indent=2));return
 if args.list or not args.output:
  print(json.dumps(dict(directories=plan['directories'],scripts=plan['scripts'],sidecars=plan['sidecars'],supplementary_artifacts=plan['supplementary_artifacts'],files=len(plan['files'])),indent=2));return
 assert args.final_replay in plan['directories'],'--final-replay must name an included completed replay directory'
 output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
 for row in plan['files']:
  source=ROOT/row['source'];assert oracle.sha256(source)==row['sha256'],row['source'];destination=output/row['destination'];destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,destination);assert oracle.sha256(destination)==row['sha256']
 for row in plan['files']:assert oracle.sha256(ROOT/row['source'])==row['sha256'],'Source changed while copying: '+row['source']
 shutil.copy2(TARGET/'stage9-promotion.json',output/'promotion.json');(output/'CONTENT_SOURCES.json').write_bytes(contract.encoded(plan))
 index=collect_index(output,plan,args.final_replay);(output/'INDEX.json').write_bytes(contract.encoded(index))
 result=dict(output=str(output),files=len(plan['files']),selected=index['selection'],final_replay=index['final_replay'],process_captures=index['retained_process_captures'])
 if args.archive:
  assert not args.archive.exists();evidence.create(output,args.archive,[]);result.update(archive=str(args.archive),archive_sha256=oracle.sha256(args.archive))
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
