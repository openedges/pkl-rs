from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import sys,json,shutil
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
candidate=Path('target/m2/stage9-selection-baseline-01/language_probe');shutil.copy2(candidate,art/'language_probe')
(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(candidate.resolve()),sha256=oracle.sha256(candidate),binding='Frozen original Stage8 final candidate; exploratory comparisons, not Stage9 final build evidence.')))
r=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert r['exit_code']==0
cases=[]
def add(id,source,family):cases.append(dict(id=id,source=source if source.endswith('\n') else source+'\n',family=family,expression='result'))
idx=Path('target/m2/stage8-exploration-evidence-01');held=json.loads((idx/'INDEX.json').read_bytes())['held_mismatches']
for h in held:add('held-'+h['id'],(idx/h['exploration']/'cases'/h['id']/'input.pkl').read_text(),'held-stage8')
for kind in ['Listing','Mapping','Dynamic']:
 value='x' if kind=='Listing' else '["a"]=x' if kind=='Mapping' else 'a=x';regular='1' if kind=='Listing' else '["a"]=1' if kind=='Mapping' else 'a=1'
 prefix='left=new '+kind+' {local x=1+0;'+value+'};right=new '+kind+' {'+regular+'};'
 for id,expr in [('forward','left==right'),('reverse','right==left'),('identity','left==left')]:add(kind.lower()+'-local-cache-'+id,prefix+'result='+expr,'local-cache')
 add(kind.lower()+'-local-constant',prefix.replace('1+0','1')+'result=left==right','local-cache')
 add(kind.lower()+'-local-both',prefix.replace('right=new '+kind+' {'+regular+'}','right=new '+kind+' {local x=1+0;'+value+'}')+'result=left==right','local-cache')
for n in [0,1,2]:
 for warm in ['left','right','both']:
  pre=''.join('let(w'+side+'='+side+'['+str(n)+']) ' for side in (['left','right'] if warm=='both' else [warm]))
  prefix='left=new Listing {1;2;3};right=new Listing {1;2;3};result='+pre
  add('listing-'+warm+'-warm'+str(n)+'-fifth',prefix+'new Mapping {[left]=10;["a"]=1;["b"]=2;["c"]=3;["d"]=4}[right]','listing-warm-hash')
for id,keys in [('int-bucket','0,32,64,96,128,160'),('int-fold','0,4294967297,4294967296,-9223372036854775808,9223372036854775807,1'),('strings','"Aa","BB","😀","a😀z","AaAa","BBBB"'),('float','0.0,-0.0,NaN,Infinity,-Infinity,1.0'),('nullbool','null,true,false,0,1,2')]:
 keylist=keys.split(','); body='m=new Mapping {'+''.join('['+k+']='+str(i)+';' for i,k in enumerate(keylist))+'};result=List('+','.join('m['+k+']' for k in keylist)+')'
 add('stable-keys-'+id,body,'stable-primitive-hashes')
for id,k in [('list','List(1,2)'),('listing','new Listing {1;2}'),('mapping','new Mapping {[1]=2}'),('dynamic','new Dynamic {[1]=2}'),('pair','Pair(1,2)'),('set','Set(1,2)'),('map','Map(1,2)'),('regex','Regex("Aa")'),('duration','1.s'),('datasize','1.kb'),('intseq','IntSeq(1,5)')]:
 add('stable-key-'+id,'key='+k+';result=new Mapping {[0]=0;[32]=1;[64]=2;[96]=3;[128]=4;[key]=10}['+k+']','stable-compound-hashes')
for n in [4,5,6,22,23,32]:
 add('numeric-collisions-'+str(n),'result=new Mapping {'+''.join('['+str(i*32)+']='+str(i)+';'for i in range(n))+'}['+str((n-1)*32)+']','bucket-growth')
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','target/m2/stage9_explore.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{k}.java' for k in ['Object','Dynamic','Listing','Mapping','Typed','List','Class']]
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 d=out/'cases'/c['id'];d.mkdir(parents=True);source=d/'input.pkl';source.write_bytes(c['source'].encode())
 java=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],d)
 rust=lang.capture([str(art/'language_probe'),*lang.expression_arguments(source,c['expression'])],d,'rust',meta['environment'])
 expected='success' if (d/'java.outcome.bin').read_bytes()==b'success\n' else 'error'
 status=lang.status(dict(expected_outcome=expected),java,rust,*[(d/f'{runtime}.{channel}.bin').read_bytes() for runtime in ['java','rust'] for channel in ['stdout','stderr']],(d/'java.outcome.bin').read_bytes())
 row=dict(id=c['id'],family=c['family'],source_uri=source.as_uri(),input_sha256=oracle.sha256(source),java=java,rust=rust,status=status,java_stdout=(d/'java.stdout.bin').read_text(),rust_stdout=(d/'rust.stdout.bin').read_text(),java_stderr=(d/'java.stderr.bin').read_text(),rust_stderr=(d/'rust.stderr.bin').read_text())
 print(c['id'],status,java['exit_code'],repr(row['java_stdout']),rust['exit_code'],repr(row['rust_stdout']),flush=True)
 return row
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
