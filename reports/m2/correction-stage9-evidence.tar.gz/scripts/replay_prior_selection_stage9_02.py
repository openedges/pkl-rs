"""Replay the unchanged prior selection before pushing the new implementation."""
from pathlib import Path
import concurrent.futures,json,sys
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
baseline=Path('target/m2/language-stage8-final').resolve()
current=Path('target/m2/language-stage9-final-02').resolve()
out=Path('target/m2/prior-selection-stage9-final-02').resolve();out.mkdir(exist_ok=False)
report=json.loads((baseline/'report.json').read_bytes())
metadata=json.loads((baseline/'oracle.json').read_bytes())
newcases={c['id']:c for c in json.loads(Path('tests/fixtures/m2/cases.json').read_bytes())['cases']}
frozen=current/'artifacts/language_probe'
assert frozen.is_file()
(out/'candidate.json').write_bytes(contract.encoded({'path':str(frozen),'sha256':oracle.sha256(frozen),'source_binding':'Recorded current language acquisition build; full fresh Java acquisition remains separate.'}))
(out/'baseline.json').write_bytes(contract.encoded({'path':str(baseline),'report_sha256':oracle.sha256(baseline/'report.json'),'oracle':metadata,'scope':'Prior Java captures reused only for the unchanged 907 inputs; no normalization or new exceptions.'}))
def run(prior):
 c=newcases[prior['id']];b=baseline/'cases'/c['id'];d=out/'cases'/c['id'];d.mkdir(parents=True)
 source=contract.ROOT/c['input'];assert source.read_bytes()==(b/'input.pkl').read_bytes()
 row=lang.capture([str(frozen),*lang.expression_arguments(source,c['expression'],c.get('power_assertions',False))],d,'rust',metadata['environment'])
 status=lang.status(c,prior['java'],row,*[(b/f'java.{ch}.bin').read_bytes() for ch in ('stdout','stderr')],*[(d/f'rust.{ch}.bin').read_bytes() for ch in ('stdout','stderr')],(b/'java.outcome.bin').read_bytes())
 return {'id':c['id'],'status':status,'rust':row}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,report['results']))
from collections import Counter
summary={'results':results,'status_counts':dict(Counter(r['status'] for r in results))}
(out/'report.json').write_bytes(contract.encoded(summary))
print(summary['status_counts'])
for r in results:
 if r['status']!='pass':print(r['id'],r['status'])
