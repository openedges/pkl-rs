from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import json,sys,shutil
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
root=contract.ROOT;base=root/'target/m2/language-stage9-final';out=root/'target/m2/new-selection-stage9-prepush';out.mkdir(exist_ok=False)
promotion=json.loads((root/'target/m2/stage9-promotion.json').read_bytes());ids={r['id'] for r in promotion['provenance']};assert len(ids)==137
manifest=contract.current_manifest();cases=[c for c in manifest['cases'] if c['id'] in ids];assert len(cases)==137
metadata=json.loads((base/'oracle.json').read_bytes());(out/'oracle.json').write_bytes(contract.encoded(metadata))
art=out/'artifacts';art.mkdir();shutil.copytree(base/'artifacts/java',art/'java');shutil.copy2(base/'artifacts/language_probe',art/'language_probe')
formal_sources={str(p.relative_to(base/'sources')):oracle.sha256(p) for p in sorted((base/'sources').rglob('*')) if p.is_file()}
assert all((root/p).is_file() and oracle.sha256(root/p)==v for p,v in formal_sources.items())
(out/'source-identities-before.json').write_bytes(contract.encoded(formal_sources))
for name in ['build.process.json','build.stdout.bin','build.stderr.bin','rustc.process.json','rustc.stdout.bin','rustc.stderr.bin','javac.process.json','javac.stdout.bin','javac.stderr.bin']:
 shutil.copy2(base/name,out/name)
binding=dict(formal_acquisition=str(base),formal_candidate=str(base/'artifacts/language_probe'),formal_candidate_sha256=oracle.sha256(base/'artifacts/language_probe'),frozen_candidate_sha256=oracle.sha256(art/'language_probe'),helper_class_sha256=oracle.sha256(art/'java/M2LanguageProbe.class'),build_process_sha256=oracle.sha256(base/'build.process.json'),oracle_metadata_sha256=oracle.sha256(base/'oracle.json'),source_snapshot_sha256=formal_sources,scope='New 137 cases at their actual repository fixture URIs using byte-identical frozen candidate/helper from the in-progress recorded build. This separate bounded capture does not replace the full 1044-case acquisition.')
(out/'candidate-binding.json').write_bytes(contract.encoded(binding));(out/'cases.json').write_bytes(contract.encoded(cases))
for p in ['target/m2/stage9_pre_push_new_selection.py','tools/m2_language.py','tools/m2_manifest.py','tools/oracle.py','tools/java/M2LanguageProbe.java','oracle.lock.json','references.lock']:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((root/p).read_bytes())
def run(c):
 d=out/'cases'/c['id'];d.mkdir(parents=True);source=root/c['input'];assert oracle.sha256(source)==c['input_sha256'];(d/'input.pkl').write_bytes(source.read_bytes())
 j=lang.capture_java(metadata,art/'language_probe',c['id'],source,c['expression'],d,c.get('power_assertions',False))
 r=lang.capture([str(art/'language_probe'),*lang.expression_arguments(source,c['expression'],c.get('power_assertions',False))],d,'rust',metadata['environment'])
 status=lang.status(c,j,r,*[(d/f'{runtime}.{channel}.bin').read_bytes() for runtime in ['java','rust'] for channel in ['stdout','stderr']],(d/'java.outcome.bin').read_bytes())
 row=dict(id=c['id'],status=status,java=j,rust=r,input_sha256=oracle.sha256(source),source_uri=source.as_uri());print(c['id'],status,flush=True);return row
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
after={p:oracle.sha256(root/p) for p in formal_sources};(out/'source-identities-after.json').write_bytes(contract.encoded(after));assert after==formal_sources
relations=lang.check_relations(dict(cases=cases),out)
report=dict(scope=binding['scope'],selected_count=len(cases),status_counts=dict(Counter(r['status'] for r in results)),results=results,metamorphic_results=relations,candidate_binding=binding,source_stability=True,candidate_stability=oracle.sha256(base/'artifacts/language_probe')==oracle.sha256(art/'language_probe'),evidence_sha256={str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()})
(out/'report.json').write_bytes(contract.encoded(report));print(json.dumps(dict(status_counts=report['status_counts'],relations=len(relations),relation_status_counts=dict(Counter(r['status'] for r in relations)),source_stability=True,candidate_sha256=binding['frozen_candidate_sha256']),indent=2))
assert all(r['status']=='pass' for r in results) and all(r['status']=='pass' for r in relations)
