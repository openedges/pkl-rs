"""Append Java-observed inherited Mapping.length controls after a fixed replay."""
from pathlib import Path
import json,sys
sys.path.insert(0,'tools')
import m2_manifest as c,m2_language as l,oracle
replay=Path(sys.argv[1]).resolve();baseline=Path('target/m2/stage9-length-selection-baseline-01');original=json.loads((baseline/'selection.json').read_bytes());selection=c.ROOT/c.SELECTION;current=json.loads(selection.read_bytes());assert current==original and len(current['cases'])==1044
for case in original['cases']:assert (c.ROOT/case['input']).read_bytes()==(baseline/'inputs'/case['input']).read_bytes(),case['id']
oldpromotion=json.loads((baseline/'first-promotion.json').read_bytes());promotionpath=Path('target/m2/stage9-promotion.json');assert json.loads(promotionpath.read_bytes())==oldpromotion and oldpromotion['selected_count']==137
passed={(Path(row['baseline']).name,row['id'])for row in json.loads((replay/'results.json').read_bytes())if row['status']=='pass'}
directory=Path('target/m2/stage9-exploration-10');cases=json.loads((directory/'matrix.json').read_bytes());assert len(cases)==15
promoted=[]
for case in cases:
 assert (directory.name,case['id'])in passed,case['id'];folder=directory/'cases'/case['id'];process=json.loads((folder/'java.process.json').read_bytes());assert process['exit_code']==0 and not process['timed_out'] and (folder/'java.outcome.bin').read_bytes()==b'success\n';assert not (folder/'java.stderr.bin').read_bytes()
 identifier='equality-stage9-'+case['id'];path=Path('tests/fixtures/m2')/(identifier+'.pkl');assert not path.exists();path.write_bytes((folder/'input.pkl').read_bytes());requirements=['semantic:operators','semantic:objects','semantic:collections','semantic:amendment','semantic:lazy-evaluation','semantic:diagnostics']
 if 'local 'in case['source']:requirements.append('semantic:modifiers')
 current['cases'].append(dict(id=identifier,input=str(path),expression=case['expression'],requirements=requirements,expected_outcome='success'))
 promoted.append(dict(id=identifier,exploration=str(directory),case_id=case['id'],source_uri=(folder/'input.pkl').resolve().as_uri(),input_sha256=oracle.sha256(path)))
assert len(current['cases'])==1059 and current['cases'][:1044]==original['cases']
for case in original['cases']:assert (c.ROOT/case['input']).read_bytes()==(baseline/'inputs'/case['input']).read_bytes()
selection.write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
promotion=json.loads(promotionpath.read_bytes());promotion['selected_count']=152;promotion['total_selected']=1059;promotion['selected'].extend({k:v for k,v in row.items()if k!='id'}for row in promoted);promotion['provenance'].extend(promoted);promotion['replay']=str(replay)
promotion['length_correction']=dict(new_cases=15,metamorphic_relations_added=0,original_1044_definitions_and_bytes_preserved=True,first_137_additions_unchanged=True,selection_baseline=str(baseline.resolve()),first_promotion_sha256=oracle.sha256(baseline/'first-promotion.json'),first_archive_sha256='13c8689f1d6fe51e772757cc428f71a584bf2cf130b291f03259022f1c7f9d15',first_actual_uri_regression_checkpoint='target/m2/stage9-original-length-checkpoint-01',first_replay=oldpromotion['replay'],fixed_replay=str(replay),provenance=promoted)
promotionpath.write_bytes(c.encoded(promotion));Path('target/m2/stage9-length-promotion.json').write_bytes(c.encoded(promotion['length_correction']));print('Promoted15 inheritedlength cases;1059selected;existing1044unchanged;41relations retained.')
