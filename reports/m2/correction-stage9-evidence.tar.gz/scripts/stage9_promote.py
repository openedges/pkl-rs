from pathlib import Path
import json,sys
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as c,oracle
base=Path('target/m2/stage9-selection-baseline-01');original=json.loads((base/'selection.json').read_bytes())
current=json.loads((c.ROOT/c.SELECTION).read_bytes());assert current['cases'][:907]==original['cases'] and len(original['cases'])==907
for case in original['cases']:assert (c.ROOT/case['input']).read_bytes()==(base/'inputs'/case['input']).read_bytes()
selected=[];excluded=[]
for number in range(1,10):
 directory=Path(f'target/m2/stage9-exploration-{number:02d}')
 for case in json.loads((directory/'matrix.json').read_bytes()):
  ident=case['id'];choose=False;reason=''
  if number==1:
   choose=(case['family']=='held-stage8' or case['family']=='local-cache' and not ident in ['listing-local-cache-forward','mapping-local-cache-forward','dynamic-local-cache-reverse','dynamic-local-cache-identity'] or case['family']=='listing-warm-hash' or ident in ['stable-key-list','stable-key-listing','stable-key-mapping','stable-key-dynamic'] or case['family']=='bucket-growth')
   if not choose:reason='Duplicate source/behavior already represented by the unchanged held Stage 8 local-cache case.' if ident in ['listing-local-cache-forward','mapping-local-cache-forward','dynamic-local-cache-reverse','dynamic-local-cache-identity'] else 'The probe adapter cannot stringify the compound List result; scalar replacements are separately observed and selected from exploration 02.' if case['family']=='stable-primitive-hashes' else 'Pair, Set, Map, Regex, Duration, DataSize and IntSeq builtins remain unimplemented in the bounded runtime; Java observations and candidate failures are preserved outside this selection.'
   if ident in ['dynamic-local-cache-reverse','dynamic-local-cache-identity']:reason='Redundant Dynamic local equality orientation/identity controls: selected forward, constant-local, and distinct-local controls already preserve true. The original successful observations are retained.'
  elif number==2:
   choose=ident!='strict-list-bucket-keys-226'
   if not choose:reason='The authored 226-entry source exceeds the existing M1 expression-count limit; its Java success and candidate failure remain nonselected. Direct pinned-JAR map and focused model checks separately observe the 225-to-226 capacity transition.'
  elif number==3:
   choose=ident.startswith('listing-hash-bucket-1-17-') or ident in ['listing-hash-bucket-1-33-left','listing-hash-bucket-1-33-duplicate','listing-hash-bucket-1-minus15-left','listing-hash-bucket-1-minus15-duplicate','listing-hash-bucket-0-16-left','listing-hash-bucket-0-16-duplicate','listing-hash-bucket-0-0-left','listing-hash-bucket-0-0-duplicate']
   if not choose:reason='Redundant numeric-bucket orientation/control: the same bucket distinction is represented by the selected 1/17 family, signed-hash control, zero-hash control, or unchanged held 1/2 family. Original raw outcomes are retained.'
  elif number==4 or number in [8,9]:
   choose=True
  elif number==5:
   reason='Initial zero-hash probe assigned an Int to hidden Listing.default instead of Function1. Java captures the complete hidden-default type error; the candidate difference remains preserved outside the bounded cache/hash selection and general default validation remains unverified.'
  elif number==6:
   reason='Initial zero-hash probe invoked the function-valued default property as a method. Java captures the complete missing-method diagnostic; the candidate difference is retained outside the selected cache/hash cases. The valid apply invocation is separately observed and selected from exploration 08.'
  else:
   reason='Initial zero-hash probe used unsupported direct-call syntax on a parenthesized expression. Java and candidate parser diagnostics are retained without normalization; the valid apply invocation is separately observed and selected from exploration 08.'
  row=dict(exploration=str(directory),case_id=ident,source_uri=(directory/'cases'/ident/'input.pkl').resolve().as_uri(),input_sha256=oracle.sha256(directory/'cases'/ident/'input.pkl'))
  if choose:selected.append(row)
  else:excluded.append(dict(**row,reason=reason))
assert len(selected)==89,len(selected)
assert len(excluded)==46,len(excluded)
for number in range(1,6):
 directory=Path(f'target/m2/stage9-let-java-{number:02d}')
 for case in json.loads((directory/'matrix.json').read_bytes()):
  ident=case['id'];row=dict(exploration=str(directory),case_id=ident,source_uri=(directory/'cases'/ident/'input.pkl').resolve().as_uri(),input_sha256=oracle.sha256(directory/'cases'/ident/'input.pkl'))
  if ident in ['let-recursive-scope','let-recursive-outer-scope']:excluded.append(dict(**row,reason='Depth-two recursive diagnostics retain the preexisting repeated-frame compression difference. Both complete Java diagnostics and candidate failures remain visible; depth-one controls are separately observed and selected.'))
  else:selected.append(row)
assert len(selected)==137,len(selected)
assert len(excluded)==48,len(excluded)
proposal=dict(selected_count=len(selected),excluded_count=len(excluded),original_907_definitions_and_input_bytes_preserved=True,selected=selected,excluded=excluded)
Path('target/m2/stage9-promotion-proposal.json').write_bytes(c.encoded(proposal))
if len(sys.argv)==1:
 print('Proposed',len(selected),'selected;',len(excluded),'explicit exclusions; no selection edits');sys.exit()
replay=Path(sys.argv[1]);results=json.loads((replay/'results.json').read_bytes());passed={(Path(r['baseline']).name,r['id']) for r in results if r['status']=='pass'}
for row in selected:assert (Path(row['exploration']).name,row['case_id']) in passed,row
assert len(current['cases'])==907,'Coordinate manifest editing: expected unmodified 907-case selection.'
provenance=[]
for row in selected:
 directory=Path(row['exploration']);byid={x['id']:x for x in json.loads((directory/'matrix.json').read_bytes())};case=byid[row['case_id']];folder=directory/'cases'/case['id'];process=json.loads((folder/'java.process.json').read_bytes());outcome=(folder/'java.outcome.bin').read_bytes()
 assert not process['timed_out'];expected='success' if process['exit_code']==0 else 'failure';assert outcome==b'success\n' if expected=='success' else process['exit_code']==1 and lang.valid_exception_outcome(outcome)
 identifier=('diagnostics-stage9-' if case['family']=='let-diagnostics' else 'equality-stage9-')+case['id'];path=Path('tests/fixtures/m2')/(identifier+'.pkl');assert not path.exists();path.write_bytes((folder/'input.pkl').read_bytes())
 requirements=['semantic:operators','semantic:objects','semantic:collections','semantic:lazy-evaluation','semantic:diagnostics'] if case['family']!='let-diagnostics' else ['semantic:operators','semantic:lazy-evaluation','semantic:diagnostics']
 if case['family']=='let-diagnostics':
  if any(token in case['source'] for token in ['class ',': Int',':Int','typealias ']):requirements.append('semantic:types')
  if 'class ' in case['source']:requirements.append('semantic:classes')
  if 'typealias ' in case['source']:requirements.append('semantic:type-aliases')
 for token,features in [('class ',['classes','types']),('module ',['modules']),('local ',['modifiers']),('function ',['functions']),('->',['functions','closures']),('Int(',['constraints','types']),('Mapping<',['generics','types']),(' as ',['type-tests-casts','types']),(' is ',['type-tests-casts','types'])]:
  if token in case['source']:
   for feature in features:
    if 'semantic:'+feature not in requirements:requirements.append('semantic:'+feature)
 if 'inherited' in identifier or case['family'] in ['cached-fifth-hash','cached-four-control'] or identifier.startswith(('equality-stage9-held-mapping-cache','equality-stage9-held-dynamic-cache')):requirements.append('semantic:amendment')
 current['cases'].append(dict(id=identifier,input=str(path),expression=case['expression'],requirements=requirements,expected_outcome=expected))
 provenance.append(dict(id=identifier,**row))
groups=[]
for count in [4,5,6,22,23,32]:groups.append(([f'numeric-collisions-{count}',f'strict-list-bucket-keys-{count}'],f'Replacing each integral key with a strict one-element List preserves lookup of the final assigned value across {count} colliding keys.'))
groups.append(([kind+'-'+key+'-cache-four-control' for kind in ['mapping','dynamic'] for key in ['listing','dynamic']],'Changing the Mapping/Dynamic receiver and structural key kind preserves the successful fourth cached read before the fifth-insertion hash transition.'))
groups.append((['held-listing-local-cache-regular-equality','listing-local-both','held-mapping-local-cache-regular-equality','mapping-local-both'],'A regular local declaration contributes an ObjectMember cache key in Listing/Mapping equality; comparing the left local cache to an absent or distinct right local declaration remains false.'))
groups.append((['listing-zero-hash-constant-local-warm','listing-nonzero-hash-constant-local-warm','listing-nonzero-hash-regular-local-warm'],'An absent regular-local cache entry or a nonzero memoized Listing hash preserves lookup after calling the hidden default function; only the zero hash with a newly warmed regular-local entry recomputes.'))
byid={case['id']:case for case in current['cases']}
for names,domain in groups:
 ids=['equality-stage9-'+name for name in names];relation=dict(kind='equal-stdout',case_ids=ids,domain=domain)
 for ident in ids:byid[ident]['metamorphic_relation']=relation;byid[ident]['requirements'].append('semantic:generated-verification')
(c.ROOT/c.SELECTION).write_bytes((json.dumps(current,ensure_ascii=False,indent=2)+'\n').encode())
assert current['cases'][:907]==original['cases']
for case in original['cases']:assert (c.ROOT/case['input']).read_bytes()==(base/'inputs'/case['input']).read_bytes()
Path('target/m2/stage9-promotion.json').write_bytes(c.encoded(dict(**proposal,total_selected=len(current['cases']),provenance=provenance,metamorphic_relations=len(groups),replay=str(replay.resolve()))))
print('Promoted',len(selected),'total',len(current['cases']),'relations',len(groups))
