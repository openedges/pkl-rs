from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import sys,json,shutil
sys.path.insert(0,'tools')
import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
meta=oracle.ensure_oracle(contract.ROOT,fetch=False);(out/'oracle.json').write_bytes(contract.encoded(meta))
art=out/'artifacts';(art/'java').mkdir(parents=True)
candidate=Path('target/m2/stage9-selection-baseline-01/language_probe');shutil.copy2(candidate,art/'language_probe')
(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(candidate.resolve()),sha256=oracle.sha256(candidate),binding='Frozen Stage8 final candidate; exploratory raw comparisons, not Stage9 final build evidence.')))
r=lang.capture([str(Path(meta['java']).with_name('javac')),'-encoding','UTF-8','-cp',meta['artifact'],'-d',str(art/'java'),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',meta['environment']);assert r['exit_code']==0
cases=[]
cases.append({'id': 'let-body-throw', 'source': 'result=let(x=1) throw("body")\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-initializer-throw', 'source': 'result=let(x=throw("initializer")) x\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-binding-type', 'source': 'result=let(x:Int="bad") x\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-nested-body', 'source': 'result=let(x=1) let(y=2) throw("body")\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-inner-initializer', 'source': 'result=let(x=1) let(y=throw("initializer")) y\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-body-binary', 'source': 'result=let(x=1) 2 + throw("body")\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-under-binary', 'source': 'result=2 + (let(x=1) throw("body"))\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-nested-under-binary', 'source': 'result=let(x=1) 2 + (let(y=2) throw("body"))\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-parenthesized-nesting', 'source': 'result=let(x=1) (let(y=2) throw("body"))\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-object-body', 'source': 'result=let(x=1) new Dynamic { y=throw("member") }.y\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-returned-object', 'source': 'obj=let(x=1) new Dynamic { y=throw("member") }; result=obj.y\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-inner-member-body', 'source': 'result=let(x=1) new Dynamic { y=let(z=2) throw("member") }.y\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-function-body', 'source': 'function f(x)=let(y=x) throw("function"); result=f(1)\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-calls-function', 'source': 'function f(x)=throw("function"); result=let(y=1) f(y)\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-calls-let-function', 'source': 'function f(x)=let(z=x) throw("function"); result=let(y=1) f(y)\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-lambda-capture', 'source': 'f=let(x=1) (y)->throw("lambda"); result=f.apply(2)\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-calls-lambda', 'source': 'result=let(x=1) ((y)->throw("lambda")).apply(x)\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-constraint', 'source': 'result: Int(let(x=this) x>1)=0\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-type-test-control', 'source': 'result=0 is Int(let(x=this) x>1)\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-initializer-nested', 'source': 'result=let(x=let(y=1) throw("inner initializer")) x\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-property-read', 'source': 'fail=throw("property"); result=let(x=1) fail\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-equality-hidden-call', 'source': 'left=new Dynamic {x=throw("left")}; right=new Dynamic {x=1}; result=let(x=1) left==right\n', 'family': 'let-diagnostics', 'expression': 'result'})
cases.append({'id': 'let-success-locals', 'source': 'result=let(x=20) let(y=x+1) y*2\n', 'family': 'let-diagnostics', 'expression': 'result'})
(out/'matrix.json').write_bytes(contract.encoded(cases))
paths=['external/pkl/pkl-core/src/main/java/org/pkl/core/ast/expression/binary/LetExprNode.java','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/StackTraceGenerator.java','references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py','target/m2/stage9_let_explore.py']+[f'external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/Vm{k}.java' for k in ['Object','Dynamic','Listing','Mapping','Typed','List','Class']]
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in paths}))
for p in paths:
 d=out/'sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes((contract.ROOT/p).read_bytes())
def run(c):
 d=out/'cases'/c['id'];d.mkdir(parents=True);source=d/'input.pkl';source.write_bytes(c['source'].encode())
 java=lang.capture_java(meta,art/'language_probe',c['id'],source,c['expression'],d)
 rust=lang.capture([str(art/'language_probe'),*lang.expression_arguments(source,c['expression'])],d,'rust',meta['environment'])
 expected='success' if (d/'java.outcome.bin').read_bytes()==b'success\n' else 'error'
 status=lang.status(dict(expected_outcome=expected),java,rust,*[(d/f'{runtime}.{channel}.bin').read_bytes() for runtime in ['java','rust'] for channel in ['stdout','stderr']],(d/'java.outcome.bin').read_bytes())
 row=dict(id=c['id'],family=c['family'],source_uri=source.as_uri(),input_sha256=oracle.sha256(source),java=java,rust=rust,status=status,java_stdout=(d/'java.stdout.bin').read_text(),rust_stdout=(d/'rust.stdout.bin').read_text(),java_stderr=(d/'java.stderr.bin').read_text(),rust_stderr=(d/'rust.stderr.bin').read_text())
 print(c['id'],status,java['exit_code'],repr(row['java_stdout']),rust['exit_code'],repr(row['rust_stdout']),flush=True)
 return row
with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
(out/'evidence-sha256.json').write_bytes(contract.encoded({str(p.relative_to(out)):oracle.sha256(p) for p in sorted(out.rglob('*')) if p.is_file()}))
