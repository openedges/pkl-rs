"""Bind the final local language acquisition to the committed implementation."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

commit = subprocess.check_output(["git", "rev-parse", sys.argv[1]], text=True).strip()
report = json.loads(Path("target/m2/language-stage9-final-02/report.json").read_bytes())
for name, expected in report["source_sha256"].items():
    data = subprocess.check_output(["git", "show", f"{commit}:{name}"])
    assert hashlib.sha256(data).hexdigest() == expected, name
summary_path = Path("reports/m2/stage9-final-summary.json")
summary = json.loads(summary_path.read_bytes())
summary["implementation_commit"] = commit
summary["implementation_source_verification"] = {
    "source_snapshots_verified": len(report["source_sha256"]),
    "matched_exact_git_commit": True,
    "method": "SHA-256 of git show <implementation-commit>:<recorded-source-path> equals every language source_sha256 entry.",
}
summary_path.write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary["implementation_source_verification"]))
