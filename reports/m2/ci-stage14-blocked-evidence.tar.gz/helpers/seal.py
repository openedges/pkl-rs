"""Package verified CI evidence, replay it twice offline, and seal file identities."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(directory):
    return {str(path.relative_to(directory)): dict(bytes=path.stat().st_size, sha256=sha(path))
            for path in sorted(directory.rglob('*')) if path.is_file()}


def capture(directory, command):
    directory.mkdir(parents=True, exist_ok=False)
    started = time.monotonic_ns()
    timed_out = False
    with (directory/'stdout.bin').open('xb') as stdout, (directory/'stderr.bin').open('xb') as stderr:
        try:
            result = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=1800)
            exit_code = result.returncode
        except subprocess.TimeoutExpired:
            exit_code = None
            timed_out = True
    row = dict(command=command, exit_code=exit_code,
        elapsed_ns=time.monotonic_ns()-started, timed_out=timed_out,
        stdout_sha256=sha(directory/'stdout.bin'), stderr_sha256=sha(directory/'stderr.bin'))
    (directory/'process.json').write_text(json.dumps(row, indent=2, sort_keys=True)+'\n')
    if timed_out or exit_code != 0:
        raise ValueError('CI packaging/offline verification failed; retained capture: ' + str(directory))
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository-root', type=Path, required=True)
    parser.add_argument('--acquired', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--process-output', type=Path, required=True)
    parser.add_argument('--offline-prefix', type=Path, required=True)
    args = parser.parse_args()
    acquired, package = args.acquired.resolve(), args.output.resolve()
    process = args.process_output.resolve()
    process.mkdir(parents=True, exist_ok=False)
    records = []
    records.append(capture(process/'package', [sys.executable, str(HERE/'package.py'),
        '--acquired', str(acquired), '--output', str(package)]))
    before = inventory(package)
    for repetition in [1, 2]:
        output = Path(str(args.offline_prefix.resolve())+f'-{repetition:02}')
        records.append(capture(process/f'offline-{repetition:02}', [sys.executable,
            str(package/'verification/unpack_and_verify.py'), '--repository-root',
            str(args.repository_root.resolve()), '--output', str(output)]))
        if inventory(package) != before:
            raise ValueError('Offline verification mutated the packaged evidence')
    row = dict(scope='Original CI ZIP evidence sealed after two independent offline checks; captured binaries never executed.',
        package=str(package), file_count=len(before), package_files=before,
        package_manifest_sha256=sha(package/'package-manifest.json'),
        helper_sha256=sha(Path(__file__)), checks=records, offline_repetitions=2,
        package_unchanged=True, captured_binaries_executed=False)
    (process/'seal.json').write_text(json.dumps(row, indent=2, sort_keys=True)+'\n')
    print(json.dumps({key:row[key] for key in ['package','file_count','package_manifest_sha256',
        'offline_repetitions','package_unchanged','captured_binaries_executed']}, sort_keys=True))
    return 0


if __name__ == '__main__':
    sys.exit(main())
