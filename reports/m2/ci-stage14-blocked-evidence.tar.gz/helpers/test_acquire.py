"""Target-only acquisition contracts; no network or captured program execution."""
import importlib.util
import json
import subprocess
import tempfile
from unittest.mock import patch
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('stage14_acquisition', HERE/'acquire.py')
acquire = importlib.util.module_from_spec(spec)
spec.loader.exec_module(acquire)


class AcquisitionTests(unittest.TestCase):
    def test_sanitized_transport_never_retains_signed_urls(self):
        secret = 'https://example.invalid/blob?sig=SECRET&token=PRIVATE'
        data = ('curl: request failed '+secret+'\nredirect https://other.invalid/?token=HIDDEN').encode()
        result = acquire.sanitized(data, secret)
        for forbidden in [b'https://', b'SECRET', b'PRIVATE', b'HIDDEN']:
            self.assertNotIn(forbidden, result)
        self.assertIn(b'curl: request failed', result)

    def test_ranges_cover_the_original_zip_once_in_original_order(self):
        for size in [8, 9, 105, 100000003]:
            pieces = acquire.ranges(size, 8)
            self.assertEqual(pieces[0][0], 0)
            self.assertEqual(pieces[-1][1], size-1)
            self.assertEqual(sum(last-first+1 for first,last in pieces), size)
            self.assertTrue(all(left[1]+1 == right[0] for left,right in zip(pieces,pieces[1:])))
        for size,count in [(0,8), (7,8), (8,0)]:
            with self.assertRaises(ValueError): acquire.ranges(size,count)

    def test_seal_timeout_retains_process_outcome_and_raw_streams(self):
        spec = importlib.util.spec_from_file_location('stage14_sealing', HERE/'seal.py')
        seal = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(seal)
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)/'capture'
            with patch.object(seal.subprocess, 'run', side_effect=subprocess.TimeoutExpired(['check'], 1800)):
                with self.assertRaises(ValueError): seal.capture(output, ['check'])
            row = json.loads((output/'process.json').read_bytes())
            self.assertTrue(row['timed_out'])
            self.assertIsNone(row['exit_code'])
            self.assertEqual((output/'stdout.bin').read_bytes(), b'')
            self.assertEqual((output/'stderr.bin').read_bytes(), b'')

    def test_exact_six_successful_jobs_commit_and_complete_artifacts_are_required(self):
        commit='a'*40
        run=dict(id=1, head_sha=commit, status='completed', conclusion='success')
        rows=[dict(name=name,conclusion='success') for name in sorted(acquire.EXPECTED_JOBS)]
        jobs=dict(total_count=6,jobs=rows)
        artifacts=dict(total_count=2,artifacts=[{},{}])
        acquire.check_metadata(run,jobs,artifacts,commit,1)
        broken_jobs=[dict(total_count=5,jobs=rows[:-1]),dict(total_count=6,jobs=rows[:-1]),
            dict(total_count=6,jobs=rows[:-1]+[rows[0]]),
            dict(total_count=6,jobs=[dict(row,conclusion='failure') for row in rows])]
        for broken in broken_jobs:
            with self.assertRaises(ValueError): acquire.check_metadata(run,broken,artifacts,commit,1)
        for broken in [dict(run,head_sha='b'*40),dict(run,id=2),dict(run,status='in_progress')]:
            with self.assertRaises(ValueError): acquire.check_metadata(broken,jobs,artifacts,commit,1)
        with self.assertRaises(ValueError):
            acquire.check_metadata(run,jobs,dict(total_count=3,artifacts=[{},{}]),commit,1)


if __name__=='__main__': unittest.main()
