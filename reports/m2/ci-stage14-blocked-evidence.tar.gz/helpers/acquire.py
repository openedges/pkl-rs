"""Acquire original exact-commit CI ZIPs with bounded, sanitized range transfers."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
EXPECTED_JOBS = {
    'Compatibility tooling and Java replay',
    'M1 architecture experiments (known gaps recorded)',
    'M2 language development (full gate incomplete)',
    'Workspace (ubuntu-latest)', 'Workspace (macos-latest)',
    'Workspace (windows-latest)',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def sanitized(data, secret):
    text = data.decode('utf-8', errors='replace').replace(secret, '[omitted signed URL]')
    return re.sub(r'https?://[^\s<>\"\']+', '[omitted URL]', text).encode('utf-8')


def ranges(size, count):
    if size < count or count < 1:
        raise ValueError('Invalid artifact/range count')
    return [(size * i // count, size * (i + 1) // count - 1) for i in range(count)]


def check_metadata(run, jobs, artifacts, commit, run_id):
    rows = jobs['jobs']
    if (run['id'] != run_id or run['head_sha'] != commit
            or run['status'] != 'completed' or run['conclusion'] != 'success'):
        raise ValueError('Exact-commit workflow did not complete successfully')
    if (len(rows) != jobs['total_count'] or len(rows) != len(EXPECTED_JOBS)
            or {row['name'] for row in rows} != EXPECTED_JOBS
            or any(row['conclusion'] != 'success' for row in rows)):
        raise ValueError('Exactly the six required successful jobs must be retained')
    if len(artifacts['artifacts']) != artifacts['total_count']:
        raise ValueError('Artifact metadata is paginated/incomplete')


def api(args, endpoint, path):
    started = time.monotonic_ns()
    result = subprocess.run(['gh', 'api', endpoint], cwd=args.repository_root,
                            capture_output=True, timeout=60)
    # JSON API responses contain only public GitHub workflow/artifact metadata.
    if result.returncode:
        write(path.with_suffix('.failure.json'), dict(endpoint=endpoint,
            exit_code=result.returncode, stderr_sha256=hashlib.sha256(result.stderr).hexdigest()))
        raise ValueError('GitHub metadata request failed: ' + endpoint)
    payload = json.loads(result.stdout)
    with path.open('xb') as stream:
        stream.write(result.stdout)
    write(path.with_suffix('.process.json'), dict(command=['gh', 'api', endpoint],
        exit_code=0, elapsed_ns=time.monotonic_ns() - started,
        stdout_sha256=sha(path), stderr_sha256=hashlib.sha256(result.stderr).hexdigest()))
    return payload


def redirect(endpoint):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, fp, code, message, headers, newurl):
            return None
    authentication = subprocess.run(['gh', 'auth', 'token'], capture_output=True, timeout=30)
    if authentication.returncode:
        raise ValueError('GitHub authentication unavailable; token output omitted')
    token = authentication.stdout.decode().strip()
    request = urllib.request.Request(endpoint, headers={
        'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json'})
    opener = urllib.request.build_opener(NoRedirect())
    try:
        response = opener.open(request, timeout=45)
    except urllib.error.HTTPError as failure:
        if failure.code not in [301, 302, 303, 307, 308]:
            raise ValueError('GitHub artifact redirect failed, HTTP ' + str(failure.code)) from None
        response = failure
    location = response.headers.get('Location')
    if not location or urllib.parse.urlsplit(location).scheme != 'https':
        raise ValueError('Missing HTTPS artifact redirect')
    return location, dict(endpoint=endpoint, status=response.code,
        redirect_url_sha256=hashlib.sha256(location.encode()).hexdigest(),
        redirect_host=urllib.parse.urlsplit(location).hostname,
        signed_url_omitted=True, authorization_omitted=True)


def download(args, artifact, directory, transport):
    endpoint = f"https://api.github.com/repos/{args.repo}/actions/artifacts/{artifact['id']}/zip"
    location, record = redirect(endpoint)
    transport.mkdir(parents=True, exist_ok=False)
    write(transport/'redirect.json', record)
    expected = artifact['size_in_bytes']
    pieces = ranges(expected, args.ranges)
    print(json.dumps(dict(phase='download', artifact=artifact['name'],
        expected_bytes=expected, ranges=len(pieces))), flush=True)
    # The signed redirect lives only in memory and an owner-only OS temporary
    # config outside the evidence tree. No redirect header/config is retained.
    with tempfile.TemporaryDirectory(prefix='pkl-ci-private-') as private:
        config = Path(private)/'curl.conf'
        fd = os.open(config, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as stream:
            stream.write('url = ' + json.dumps(location) + '\n')
        def transfer(index):
            first, last = pieces[index]
            for attempt in range(args.attempts):
                base = transport/f'range-{index:02}-attempt-{attempt:02}'
                base.mkdir()
                destination = base/'payload.bin'
                command = ['curl', '--config', str(config), '--ipv4', '--silent', '--show-error',
                    '--fail', '--location', '--connect-timeout', '30', '--max-time', '180',
                    '--range', f'{first}-{last}', '--output', str(destination), '--write-out', '%{http_code}']
                started = time.monotonic_ns()
                timed_out = False
                try:
                    result = subprocess.run(command, cwd=args.repository_root,
                        capture_output=True, timeout=190)
                    code, stdout, stderr = result.returncode, result.stdout, result.stderr
                except subprocess.TimeoutExpired as failure:
                    code, stdout, stderr = None, failure.stdout or b'', failure.stderr or b''
                    timed_out = True
                safe_stdout, safe_stderr = sanitized(stdout, location), sanitized(stderr, location)
                (base/'stdout.bin').write_bytes(safe_stdout)
                (base/'stderr.bin').write_bytes(safe_stderr)
                observed = destination.stat().st_size if destination.exists() else 0
                success = not timed_out and code == 0 and stdout == b'206' and observed == last-first+1
                public_command = command.copy()
                public_command[2] = '[owner-only temporary config; signed URL omitted]'
                row = dict(index=index, attempt=attempt, range=[first, last], command=public_command,
                    exit_code=code, timed_out=timed_out, elapsed_ns=time.monotonic_ns()-started,
                    status='pass' if success else 'failed', http_status=safe_stdout.decode(),
                    bytes=observed, payload_sha256=sha(destination) if destination.exists() else None,
                    stdout_sha256=sha(base/'stdout.bin'), stderr_sha256=sha(base/'stderr.bin'),
                    stderr_sanitized=True, signed_url_omitted=True)
                write(base/'process.json', row)
                print(json.dumps(dict(phase='range', artifact=artifact['name'], index=index,
                    attempt=attempt, status=row['status'], bytes=observed)), flush=True)
                if success:
                    return destination, row
                # Failed response bodies are not archived: a remote error page
                # could echo a signed request URL. Its size/hash remain recorded.
                if destination.exists():
                    destination.unlink()
            raise ValueError('Bounded artifact range attempts exhausted: ' + str(index))
        with ThreadPoolExecutor(max_workers=args.ranges) as pool:
            complete = list(pool.map(transfer, range(args.ranges)))
    archive = directory/'artifact.zip'
    with archive.open('xb') as stream:
        for path, _ in complete:
            with path.open('rb') as part:
                shutil.copyfileobj(part, stream)
    observed = sha(archive)
    if archive.stat().st_size != expected or artifact['digest'] != 'sha256:' + observed:
        raise ValueError('Original GitHub ZIP size/digest differs: ' + artifact['name'])
    write(transport/'download.json', dict(artifact=artifact['name'], bytes=expected,
        sha256=observed, github_digest_verified=True,
        transport='bounded parallel IPv4 curl ranges concatenated in original order',
        successful_attempts=[row for _, row in complete], failed_attempt_logs_preserved=True, failed_payload_bytes_omitted=True))
    (directory/'artifact.zip.stderr.bin').write_bytes(b'')
    # Successful chunks are reconstructible from the retained original ZIP.
    # Preserve failed chunk size/digest records and all sanitized per-attempt logs.
    for path, _ in complete:
        path.unlink()
    return archive


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository-root', type=Path, default=Path.cwd())
    parser.add_argument('--repo', default='luuvish/pkl-rs')
    parser.add_argument('--commit', required=True)
    parser.add_argument('--run', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--ranges', type=int, default=8)
    parser.add_argument('--attempts', type=int, default=3)
    parser.add_argument('--wait', action='store_true')
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.commit) or not 1 <= args.ranges <= 16 or not 1 <= args.attempts <= 5:
        parser.error('exact full commit and bounded ranges/attempts required')
    args.repository_root = args.repository_root.resolve()
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    spec = importlib.util.spec_from_file_location('stage14_ci_verifier', HERE/'verify.py')
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    write(args.output/'acquisition.json', dict(commit=args.commit, run_id=args.run,
        repository=args.repo, helper_sha256=sha(Path(__file__)), verifier_sha256=sha(HERE/'verify.py'),
        ranges=args.ranges, attempts=args.attempts, signed_urls_retained=False))
    index = 0
    while True:
        prefix = f'repos/{args.repo}/actions/runs/{args.run}'
        endpoints = dict(run=prefix, jobs=prefix+'/jobs?per_page=100', artifacts=prefix+'/artifacts?per_page=100')
        records = {}
        for label, endpoint in endpoints.items():
            records[label] = api(args, endpoint, args.output/f'poll-{index:03}-{label}.json')
        run = records['run']
        if run['id'] != args.run or run['head_sha'] != args.commit:
            raise ValueError('Workflow identity differs from requested exact commit/run')
        print(json.dumps(dict(phase='workflow', status=run['status'], conclusion=run['conclusion'])), flush=True)
        if run['status'] == 'completed':
            break
        if not args.wait:
            return 3
        time.sleep(30)
        index += 1
    check_metadata(records['run'], records['jobs'], records['artifacts'], args.commit, args.run)
    for kind, name in verifier.NAMES.items():
        directory = args.output/kind
        directory.mkdir()
        for label in records:
            shutil.copyfile(args.output/f'poll-{index:03}-{label}.json', directory/(label+'.json'))
        candidates = [row for row in records['artifacts']['artifacts'] if row['name'] == name]
        if len(candidates) != 1:
            raise ValueError('Missing/duplicate artifact: ' + name)
        artifact = candidates[0]
        if artifact['expired'] or artifact['workflow_run']['id'] != args.run or artifact['workflow_run']['head_sha'] != args.commit:
            raise ValueError('GitHub artifact provenance differs')
        archive = download(args, artifact, directory, args.output/'transport'/kind)
        verifier.safe_extract(archive, directory/'artifact')
    verifier.verify(args, args.output/'m1', args.output/'m2', args.output/'verification')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as failure:
        # Avoid printing third-party transport exception strings that may carry
        # signed redirect URLs. Sanitized attempt records retain diagnostics.
        print('Stage14 acquisition failed: ' + type(failure).__name__, file=sys.stderr)
        sys.exit(2)
