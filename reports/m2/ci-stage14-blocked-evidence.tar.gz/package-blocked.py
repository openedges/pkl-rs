"""Preserve exact-commit CI billing-block evidence without claiming test execution."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys

root=Path.cwd()
base=root/'target/m2'
package=base/'ci-stage14-blocked-package'
archive=root/'reports/m2/ci-stage14-blocked-evidence.tar.gz'
summary_path=root/'reports/m2/ci-stage14-summary.json'
if package.exists() or archive.exists() or summary_path.exists():
    raise ValueError('Blocked evidence outputs must be new')
source=json.loads((base/'ci-stage14-failure-summary.json').read_bytes())
for name,row in source['retained_files'].items():
    data=(root/name).read_bytes()
    if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
        raise ValueError('Retained failure evidence changed: '+name)
    # These transport captures precede any redirect/download and must contain no
    # private signed redirect URL. Helper self-tests below use synthetic URLs.
    if re.search(rb'https?://[^\s"<>]*[?&](?:sig|token|jwt)=',data,re.I):
        raise ValueError('Private-looking redirect found in failure evidence')
package.mkdir()
for name in ['ci-stage14-discovery','ci-stage14-acquired','ci-stage14-acquire-process','ci-stage14-failure-diagnosis']:
    shutil.copytree(base/name,package/name)
helpers=package/'helpers'
helpers.mkdir()
for path in sorted((base/'ci-stage14').glob('*.py')):
    shutil.copyfile(path,helpers/path.name)
for path in sorted((base/'ci-stage14').glob('preparation*.json')):
    shutil.copyfile(path,helpers/path.name)
for name in ['self-test.stdout.bin','self-test.stderr.bin']:
    shutil.copyfile(base/'ci-stage14'/name,helpers/name)
for name in ['acquisition-self-test','acquisition-self-test-02']:
    shutil.copytree(base/'ci-stage14'/name,helpers/name)
shutil.copyfile(base/'ci-stage14-failure-summary.json',package/'blocked-summary.json')
shutil.copyfile(Path(__file__),package/'package-blocked.py')
readme=f'''# Stage14 CI blocked before execution

Implementation commit: `{source['commit']}`
Run: {source['run_url']} (attempt {source['run_attempt']})

All six jobs failed before any runner step started. GitHub reported failed
account payments or a spending limit requiring adjustment in Billing & plans.
There are zero CI artifacts and zero executed CI checks in this record.
No GitHub ZIP digest, captured source snapshot, or offline CI replay was checked.
Local preparation self-tests are distinct: the final helper suite passed nine
tests. They are not CI test passes or language compatibility evidence.

The package retains exact discovery, workflow/jobs/artifacts metadata, every
check and annotation response, acquisition failure process captures, and helper
preparations with their self-test captures. No real credentials, signed artifact
redirects, or private download configs were acquired or retained. Helper tests
contain explicitly synthetic URL strings used to exercise sanitization.

The failed run must remain visible if a fresh attempt follows account repair.
This archive uses the blocked-evidence name and does not occupy the successful
CI evidence/offline replay filenames. `EVIDENCE.json` inventories every file.
'''
(package/'README.md').write_text(readme)
command=[sys.executable,'tools/evidence.py','create',str(package),str(archive)]
result=subprocess.run(command,capture_output=True,check=False)
process=base/'ci-stage14-blocked-package-process'
process.mkdir()
for label,data in [('stdout',result.stdout),('stderr',result.stderr)]:
    (process/(label+'.bin')).write_bytes(data)
if result.returncode:raise ValueError('Blocked evidence archive packaging failed')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
row=dict(source)
row.update(status='blocked',all_six_jobs_succeeded=False,ci_test_passes=0,
    block_reason='GitHub account billing/payment or spending limit prevented every job from starting.',
    local_helper_preparation_tests={'passed':9,'scope':'Local target-only verifier/acquisition preparation; not CI test execution.',
        'capture_directory':'target/m2/ci-stage14/acquisition-self-test-02'},
    evidence_archive={'path':str(archive.relative_to(root)),'sha256':sha(archive),
        'bytes':archive.stat().st_size,'inventory_verified':True},
    evidence_scope='Failed CI startup metadata only; no successful CI evidence, artifact download, source snapshot binding, or offline replay.')
summary_path.write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')
record=dict(command=command,exit_code=result.returncode,stdout_sha256=sha(process/'stdout.bin'),
    stderr_sha256=sha(process/'stderr.bin'),summary_sha256=sha(summary_path),archive_sha256=sha(archive))
(process/'process.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(result.stdout.decode(),end='')
print(json.dumps({'summary':str(summary_path.relative_to(root)),'summary_sha256':sha(summary_path),
    'archive':str(archive.relative_to(root)),'archive_sha256':sha(archive)}))
