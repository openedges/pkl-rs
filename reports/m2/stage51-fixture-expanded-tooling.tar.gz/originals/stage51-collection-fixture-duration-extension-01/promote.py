from pathlib import Path
import hashlib,json,shutil,os,datetime
O=Path(__file__).resolve().parent;R=O.parents[2];src=O/'fixture';dst=R/'tests/fixtures/m2-collection-transforms';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((O/'before/manifest.json').read_bytes());new=json.loads((src/'manifest.json').read_bytes());olddata=json.loads((O/'before/fixtures.json').read_bytes());newdata=json.loads((src/'fixtures.json').read_bytes())
assert newdata['fixtures'][:len(olddata['fixtures'])]==olddata['fixtures']
assert len(olddata['fixtures'])==96 and len(newdata['fixtures'])==152
assert newdata['javaApiCalls']==2108 and newdata['scopeLedger']=={'ordinary':2000,'intent-not-reached':96,'public-api-boundary':12}
changed=[]
for rel,row in old['files'].items():
 assert sha(dst/rel)==row['sha256']
 if rel not in ['fixtures.json','provenance-map.json']:
  assert new['files'][rel]==row and sha(src/rel)==row['sha256']
 else:changed.append(rel)
added=[]
for rel,row in new['files'].items():
 assert sha(src/rel)==row['sha256']
 if rel not in old['files']:
  p=dst/rel;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src/rel,p);added.append(rel)
for n in ['fixtures.json','provenance-map.json','manifest.json']:shutil.copyfile(src/n,dst/n)
for rel,row in new['files'].items():assert sha(dst/rel)==row['sha256']
report={'status':'additive-only-installed-copy','oldSessionsUnchanged':96,'oldCallsUnchanged':1272,'oldRawSourceHashChanges':[],'derivedFilesUpdated':changed+['manifest.json'],'addedFiles':len(added),'newFiles':len(new['files'])+1,'manifestSha256':sha(dst/'manifest.json'),'javaApiCalls':2108,'scopeLedger':newdata['scopeLedger'],'orderedJavaEvents':newdata['orderedJavaEvents'],'actualExportToolSession':11603,'exportExitCode':0,'noJavaOrNativeExecution':True,'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'promotion-report.json').write_text(json.dumps(report,indent=2)+'\n');(O/'added-paths.json').write_text(json.dumps(added,indent=2)+'\n')
for n in ['collection_transform_fixtures.py']:
 shutil.copyfile(R/'tools'/n,O/n)
shutil.copyfile(R/'tools/tests/test_collection_transform_fixtures.py',O/'test_collection_transform_fixtures.py')
print(json.dumps(report),flush=True)
