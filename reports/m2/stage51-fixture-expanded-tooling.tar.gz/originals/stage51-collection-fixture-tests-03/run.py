from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
R=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage51');O=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[R/'tools/collection_transform_fixtures.py',R/'tools/tests/test_collection_transform_fixtures.py',R/'tests/fixtures/m2-collection-transforms/manifest.json'];before={str(p):sha(p)for p in sources};(O/'sources-before.json').write_text(json.dumps(before,indent=2)+'\n')
commands=[[sys.executable,'-B','-m','unittest','discover','-s','tools/tests','-p','test_collection_transform_fixtures.py','-v'],[sys.executable,'-B','tools/collection_transform_fixtures.py','--fixtures','tests/fixtures/m2-collection-transforms']]+[[sys.executable,'-B','tools/'+name+'.py','--check']for name in ['inventory','discover','regression_manifest','smoke_manifest']]
rows=[]
for i,cmd in enumerate(commands):
 row={'command':cmd,'cwd':str(R),'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentPid':os.getpid()}
 with (O/f'command-{i}.stdout.bin').open('wb') as out,(O/f'command-{i}.stderr.bin').open('wb') as err:
  p=subprocess.Popen(cmd,cwd=R,stdout=out,stderr=err);row['pid']=p.pid;(O/'active.json').write_text(json.dumps(row,indent=2)+'\n');code=p.wait()
 row.update(exitCode=code,finishedUtc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(O/'progress.json').write_text(json.dumps(rows,indent=2)+'\n')
after={str(p):sha(p)for p in sources};(O/'sources-after.json').write_text(json.dumps(after,indent=2)+'\n');changes=[p for p in before if before[p]!=after[p]]
report={'commands':rows,'changedInputs':changes,'allExit0':all(r['exitCode']== 0 for r in rows),'testPrivateExactPrewalkPrune':str(R/'target/m2/stage51-collection-fixture-tests-private'),'newJavaOrEngineExecutions':0};(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True);sys.exit(0 if report['allExit0'] and not changes else 1)
