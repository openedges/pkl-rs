from pathlib import Path
import datetime,hashlib,json,sys,time
sys.dont_write_bytecode=True
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46')
OUT=Path(__file__).resolve().parent
JAVA=ROOT/'target/m2/stage46-original-read-java-01'
RELEASE=ROOT/'target/m2/stage46-implementation-01/resource-candidate-build-04/release.json'
r=json.loads(RELEASE.read_text());SOURCE=Path(r['source_snapshot']);BINARY=Path(r['artifacts']['module_eval_probe']['path'])
sys.path.insert(0,str(SOURCE/'tools'))
import compat,m2_module_eval as module
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data):(OUT/name).write_bytes(compat.encoded(data))
def main():
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
 java=json.loads((JAVA/'report.json').read_text());assert java['source_stable'] and java['workspace_restored'] and java['counts']=={'success':2}
 workspace=Path(java['workspace']);baseline=json.loads((JAVA/'workspace-baseline.json').read_text());assert compat.snapshot(workspace)==baseline
 assert sha(BINARY)==r['artifacts']['module_eval_probe']['sha256']
 source_map=json.loads(Path(r['source_map']).read_text());assert sha(Path(r['source_map']))==r['source_map_sha256']
 for name,digest in source_map.items():assert sha(SOURCE/name)==digest,name
 cases=json.loads((JAVA/'cases.json').read_text());profile=json.loads((JAVA/'profile.json').read_text());records=[]
 save('inputs.json',dict(release=str(RELEASE),release_sha256=sha(RELEASE),java_report=str(JAVA/'report.json'),java_report_sha256=sha(JAVA/'report.json'),source_map=r['source_map'],source_map_sha256=r['source_map_sha256'],artifact=str(BINARY),artifact_sha256=sha(BINARY),case_contracts=cases,workspace=str(workspace)))
 for rep in range(2):
  case=cases[0];j=next(x for x in java['records'] if x['repetition']==rep)
  expected=compat.load_capture(JAVA/j['directory']);process,actual=module.capture_process(SOURCE,workspace,case,[str(BINARY)],profile['environment'],OUT/'calls'/str(rep))
  status=module.status(j['process'],process,expected,actual,case['upstream_case']['expected_exit'])
  records.append(dict(repetition=rep,status=status,differences=compat.differences(expected,actual),java_directory=j['directory'],process=process));print(rep,status,flush=True)
 after=sha(BINARY);assert after==r['artifacts']['module_eval_probe']['sha256'];assert compat.snapshot(workspace)==baseline
 result=dict(scope='Untouched original basic/read.pkl CLI contract compared twice against sealed Java bytes at the identical physical workspace. Does not close separate deferred AST error-order, capability or portable obligations.',started_utc=start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,records=records,all_pass=all(x['status']=='pass' for x in records),workspace_stable=True,artifact_stable=True,source_snapshot_count=len(source_map),source_snapshot_verified=True)
 save('report.json',result);print(json.dumps(result,indent=2));return 0 if result['all_pass'] else 1
if __name__=='__main__':sys.exit(main())
