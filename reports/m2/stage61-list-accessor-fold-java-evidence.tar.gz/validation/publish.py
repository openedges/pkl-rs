"""Publish one fully read-back Stage 61 List accessor/fold Java evidence archive."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
VALIDATION = Path(__file__).resolve().parent
REPORTS = ROOT / "reports/m2"
FIXTURE = ROOT / "tests/fixtures/m2-int-seq-list-accessor-fold"
CAPTURE = ROOT / "target/m2/stage61-intseq-list-accessor-fold-04"
HISTORY = [ROOT / f"target/m2/stage61-intseq-list-accessor-fold-{n:02}" for n in (1, 2, 3)]
PREFIX = "capture-04"
JAR_SHA256 = "c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059"
JDK_SHA256 = (
    "51ec0764f7225b40d5b286b01401aa6b3990d0d171b446d7dc81ca7542b45552",
    "40fcf7a32bada7e299e3513939a4472d27f8f61eb81cdd1675ea00648de7e7cf",
    "ab66b8afeea98b25f1869fbe7c0dde368d448e7cc0f7bab0359b322ade134fe1",
)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}

def need(ok, reason):
    if not ok:
        raise ValueError(reason)

def paths_under(root, prefix):
    need(root.is_dir() and not root.is_symlink(), "publication source directory missing or symlinked")
    result = {}
    for path in root.rglob("*"):
        need(not path.is_symlink(), "publication source symlink")
        if path.is_file():
            result[prefix + path.relative_to(root).as_posix()] = path
        else:
            need(path.is_dir(), "publication source nonregular path")
    return result

def emit_archive(path, files):
    need(not path.exists(), "fresh evidence archive required")
    entries = {name: source.read_bytes() for name, source in files.items()}
    before = {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in entries.items()}
    manifest = {"schema": 1, "scope": "Stage 61 List accessor/fold Java validation and superseded source-closure captures",
                "members": dict(sorted(before.items()))}
    entries["archive-manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with path.open("wb") as out:
        with gzip.GzipFile(fileobj=out, mode="wb", filename="", mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, raw in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(raw))
    after = {name: identity(source) for name, source in files.items()}
    need(before == after, "evidence source changed while archived")
    observed = {}
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            need(member.isfile() and member.name not in observed and not member.name.startswith("/")
                 and ".." not in Path(member.name).parts, "unsafe or duplicate evidence member")
            raw = archive.extractfile(member).read()
            need(len(raw) == member.size, "evidence member size differs")
            observed[member.name] = raw
    need(observed == entries and json.loads(observed["archive-manifest.json"]) == manifest,
         "full evidence archive byte/hash readback differs")
    return {"archive": path.relative_to(ROOT).as_posix(), "identity": identity(path),
            "members": len(observed), "member_hash_readback": True,
            "source_before_after_equal": before == after,
            "embedded_manifest_sha256": sha(observed["archive-manifest.json"])}

def check_capture(root):
    p = json.loads((root / "provenance.json").read_bytes())
    a = json.loads((root / "audit.json").read_bytes())
    rows = json.loads((root / "cases.json").read_bytes())["rows"]
    need(a["rows"] == len(rows) == 65 and a["statuses"] == {"success": 37, "error": 28},
         "historical row/status vector differs")
    need(p["complete"] is True and p["stable"] is True and p["raw_equal"] is True
         and p["raw_differences"] == [] and p["raw_files"] == 1367
         and p["input_before"] == p["input_after"]
         and p["source_before"] == p["source_after"]
         and p["artifact_sha256"] == p["artifact_after_sha256"] == JAR_SHA256,
         "historical source/runtime stability differs")
    need((p["jdk"]["executable_sha256"], p["jdk"]["modules_sha256"],
          p["jdk"]["release_sha256"]) == JDK_SHA256,
         "historical JDK pin differs")
    for name, expected in p["input_before"].items():
        need(identity(root / name)["sha256"] == expected, "historical executed input differs")
    for name, expected in p["source_before"].items():
        need(identity(root / "sources" / name)["sha256"] == expected,
             "historical copied source differs")
    sessions = p["sessions"]
    need(len(sessions) == 2 and [s["repeat"] for s in sessions] == [0, 1]
         and len({s["pid"] for s in sessions}) == 2
         and sessions[0]["finished_epoch"] <= sessions[1]["started_epoch"],
         "historical fresh ordered JVM coverage differs")
    raw_sets = []
    for session in sessions:
        repeat = session["repeat"]
        folder = root / f"repeat-{repeat}"
        need(session["exit_code"] == 0 and session["query_directories"] == 65,
             "historical session incomplete")
        need(identity(folder / "process.stdout.bin")["sha256"] == session["stdout_sha256"]
             and identity(folder / "process.stderr.bin")["sha256"] == session["stderr_sha256"]
             and (folder / "process.stderr.bin").read_bytes() == b"",
             "historical process channel differs")
        counts = Counter()
        protocol = ["session-open mode=string rows=65"]
        for index, row in enumerate(rows):
            case = folder / f"{index:03d}-{row['id']}"
            need(case.is_dir() and row["mode"] == "string", "historical ordered row missing")
            status = (case / "result.status.bin").read_text().strip()
            need(status in ("success", "error"), "historical ordinary status differs")
            counts[status] += 1
            call = f"string-{index}-{row['id']}"
            protocol.extend((f"call-enter={call}", f"call-exit={call} status={status}"))
        protocol.append(f"session-closed mode=string rows=65 public-calls=65 success={counts['success']} errors={counts['error']}")
        need((folder / "process.stdout.bin").read_bytes() == ("\n".join(protocol) + "\n").encode()
             and dict(counts) == a["statuses"], "historical full protocol/status differs")
        raw_set = {path.relative_to(folder).as_posix(): identity(path)["sha256"]
                   for path in folder.rglob("*") if path.is_file()}
        need(len(raw_set) == 1367, "historical raw channel count differs")
        raw_sets.append(raw_set)
    need(raw_sets[0] == raw_sets[1], "historical raw repetitions differ")
    return {"capture": root.relative_to(ROOT).as_posix(), "rows": 65,
            "statuses_per_session": a["statuses"], "pids": [s["pid"] for s in sessions],
            "source_files": len(p["source_before"]), "raw_files_per_repetition": 1367,
            "source_stable": p["stable"], "raw_repetitions_equal": p["raw_equal"]}

def main():
    validation = json.loads((VALIDATION / "validation.json").read_bytes())
    need(validation["complete"] is True and validation["source_stable"] is True
         and validation["snapshot_matches"] is True and len(validation["checks"]) == 5
         and all(check["exit_code"] == 0 for check in validation["checks"]),
         "fresh Java validation incomplete")
    for name, expected in validation["source_before"].items():
        need(identity(VALIDATION / "sources" / name)["sha256"] == expected,
             "validation copied source differs")
    final = check_capture(CAPTURE)
    need(final["source_files"] == 12, "canonical source closure differs")
    fixture_identity = json.loads((FIXTURE / "archive-identity.json").read_bytes())
    need(fixture_identity["capture"] == CAPTURE.name and fixture_identity["prefix"] == PREFIX
         and fixture_identity["members"] == 2755, "canonical fixture link differs")
    archive = FIXTURE / "oracle-evidence.tar.gz"
    need(identity(archive)["sha256"] == fixture_identity["archive_sha256"],
         "canonical archive identity differs")
    history = {}
    files = paths_under(VALIDATION, "validation/")
    for root in HISTORY:
        details = check_capture(root)
        need(details["source_files"] < final["source_files"],
             "historical source closure was not smaller")
        details["reason_superseded"] = {
            8: "Missing pinned fold callback dispatch, inherited empty check and null implementation sources.",
            10: "Missing pinned inherited empty check and null implementation sources.",
            11: "Missing pinned null implementation source.",
        }[details["source_files"]]
        history[root.name] = details
        files.update(paths_under(root, f"history/{root.name}/"))
    for name in ("provenance.json", "audit.json"):
        files[f"canonical/{CAPTURE.name}/{name}"] = CAPTURE / name
    files[f"canonical/{CAPTURE.name}/archive-identity.json"] = FIXTURE / "archive-identity.json"
    evidence = emit_archive(REPORTS / "stage61-list-accessor-fold-java-evidence.tar.gz", files)
    checkpoint = {"schema": 1, "kind": "stage61-list-accessor-fold-java-authority-checkpoint",
                  "baseline": "Pkl 0.32.0", "candidate_compatibility_passes_claimed": 0,
                  "canonical": {**final, "fixture": FIXTURE.relative_to(ROOT).as_posix(),
                                "module_uri": "file:///stage61/list-accessor-fold.pkl",
                                "archive_prefix": PREFIX,
                                "fixture_archive": identity(archive),
                                "fixture_archive_members": fixture_identity["members"],
                                "fixture_fileset_sha256": fixture_identity["fileset_sha256"]},
                  "history": history,
                  "java_runtime": {"artifact_sha256": JAR_SHA256,
                                   "jdk_executable_sha256": JDK_SHA256[0],
                                   "jdk_modules_sha256": JDK_SHA256[1],
                                   "jdk_release_sha256": JDK_SHA256[2],
                                   "reference_revision": "e51fb2f91774265666f94980ec630db794a4db2d"},
                  "validation": {"directory": VALIDATION.relative_to(ROOT).as_posix(),
                                 "record": (VALIDATION / "validation.json").relative_to(ROOT).as_posix(),
                                 "record_identity": identity(VALIDATION / "validation.json"),
                                 "checks": validation["checks"],
                                 "source_stable": validation["source_stable"],
                                 "copied_sources": len(validation["source_before"])},
                  "evidence": evidence,
                  "limits": ["Java public API string observations only; no Rust candidate pass is claimed.",
                             "Object and accumulator rows show Pkl values, not Java reference identity.",
                             "Original upstream snippet replay, browser, Node, full M2 and performance remain separate."]}
    dest = REPORTS / "stage61-list-accessor-fold-java-checkpoint.json"
    need(not dest.exists(), "fresh checkpoint publication required")
    dest.write_text(json.dumps(checkpoint, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"checkpoint": identity(dest), "evidence": evidence}, sort_keys=True))

if __name__ == "__main__":
    main()
