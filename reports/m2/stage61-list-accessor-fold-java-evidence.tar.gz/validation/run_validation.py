"""Record fresh Java-only List accessor/fold authority validation."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent
PYTHON_SOURCES = [
    "target/m2/stage61-list-accessor-fold-java-validation-01/run_validation.py",
    "target/m2/stage61-list-accessor-fold-java-validation-01/publish.py",
    "tools/int_seq_list_accessor_fold_oracle.py",
    "tools/int_seq_list_accessor_fold_fixtures.py",
    "tools/tests/test_int_seq_list_accessor_fold_fixtures.py",
    "tools/int_seq_values_fixtures.py", "tools/int_seq_values_oracle.py",
    "tools/inventory.py",
]
UPSTREAM_SOURCES = [
    "external/pkl/stdlib/base.pkl",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmList.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmCollection.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmNull.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmFunction.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/ast/lambda/ApplyVmFunction2Node.java",
    "external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/ListNodes.java",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/basic/list.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/list.pkl",
    "external/pkl/pkl-core/src/test/files/LanguageSnippetTests/input/api/intseq.pkl",
]
FIXTURE = ROOT / "tests/fixtures/m2-int-seq-list-accessor-fold"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def identity(path):
    path = Path(path)
    return {"bytes": path.stat().st_size, "sha256": sha(path)}

def save(data):
    (OUTPUT / "validation.json").write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")

def source_names():
    names = set(PYTHON_SOURCES + UPSTREAM_SOURCES + [
        "tools/java/IntSeqValuesOracle.java", "oracle.lock.json", "references.lock",
        "compatibility/inventory.json",
    ])
    names.update(path.relative_to(ROOT).as_posix() for path in FIXTURE.iterdir() if path.is_file())
    return sorted(names)

def run(name, argv, env):
    folder = OUTPUT / "checks" / name
    folder.mkdir(parents=True)
    started = time.time()
    process = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=300)
    ended = time.time()
    for channel, raw in (("stdout", process.stdout), ("stderr", process.stderr)):
        (folder / (channel + ".bin")).write_bytes(raw)
    result = {"name": name, "argv": argv, "cwd": str(ROOT), "environment": env,
              "started_epoch": started, "finished_epoch": ended, "exit_code": process.returncode,
              "stdout": identity(folder / "stdout.bin"), "stderr": identity(folder / "stderr.bin")}
    (folder / "process.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(f"{name}: {process.returncode}", flush=True)
    return result

def main():
    if (OUTPUT / "sources").exists() or (OUTPUT / "validation.json").exists():
        raise ValueError("fresh List accessor/fold Java validation required")
    names = source_names()
    before = {name: sha(ROOT / name) for name in names}
    for name in names:
        dest = OUTPUT / "sources" / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, dest)
    python = sys.executable
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC",
           "TERM": "dumb", "NO_COLOR": "1", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}
    report = {"schema": 1, "kind": "stage61-list-accessor-fold-java-validation",
              "scope": "Independent Java authority and inventory only; no Rust candidate pass",
              "host": platform.uname()._asdict(),
              "python": {"executable": python, "executable_identity": identity(python), "version": sys.version},
              "python_source_closure": PYTHON_SOURCES, "source_before": before,
              "checks": [], "complete": False}
    save(report)
    commands = [
        ("fixture-verifier", [python, "tools/int_seq_list_accessor_fold_fixtures.py"]),
        ("fixture-verifier-O", [python, "-O", "tools/int_seq_list_accessor_fold_fixtures.py"]),
        ("fixture-tests", [python, "-m", "unittest", "tools.tests.test_int_seq_list_accessor_fold_fixtures", "-v"]),
        ("fixture-tests-O", [python, "-O", "-m", "unittest", "tools.tests.test_int_seq_list_accessor_fold_fixtures", "-v"]),
        ("source-inventory", [python, "tools/inventory.py", "--check"]),
    ]
    for name, argv in commands:
        report["checks"].append(run(name, argv, env))
        save(report)
    after = {name: sha(ROOT / name) for name in names}
    report["source_after"] = after
    report["source_stable"] = before == after
    report["snapshot_matches"] = before == {name: sha(OUTPUT / "sources" / name) for name in names}
    report["complete"] = (report["source_stable"] and report["snapshot_matches"]
                          and len(report["checks"]) == 5
                          and all(check["exit_code"] == 0 for check in report["checks"]))
    save(report)
    if not report["complete"]:
        raise ValueError("List accessor/fold Java-only validation incomplete; raw attempts retained")

if __name__ == "__main__":
    main()
