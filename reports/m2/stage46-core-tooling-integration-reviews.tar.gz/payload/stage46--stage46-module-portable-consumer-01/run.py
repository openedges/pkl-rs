from pathlib import Path
import hashlib
import json
import platform
import shutil
import subprocess
import sys

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[2]
WORK = OUTPUT / 'workspace'
BASELINE = ROOT / 'target/m2/stage46-platform-baseline-01'
FIXTURES = ROOT / 'target/m2/stage46-module-portable-fixtures-01/workspace/tests/fixtures/m2-module-portable'
CAPTURE = ROOT / 'target/m2/stage46-module-platform-exploration-01'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
sources = [p for p in WORK.rglob('*') if p.is_file()]
hashes = {str(p.relative_to(WORK)): sha(p) for p in sources}
assert not CAPTURE.exists()
build = json.loads((BASELINE / 'report.json').read_bytes())
for name, digest in build['artifacts'].items():
    assert sha(BASELINE / name) == digest, name
record = {'scope': 'Exploratory module Host consumer against frozen C05 artifacts. Live Rust sources may now differ; no C06 or final-source claim.',
          'host': platform.platform(), 'python': sys.version, 'cwd': str(ROOT),
          'baselineReportSha256': sha(BASELINE / 'report.json'),
          'fixtureManifestSha256': sha(FIXTURES / 'manifest.json'),
          'sourcesBefore': hashes, 'commands': []}
commands = [
    ('unit', ['node', '--test', str(WORK / 'tools/platform/resource-session.test.mjs'),
              str(WORK / 'tools/platform/module-preparation-session.test.mjs')]),
    ('platform', ['node', str(WORK / 'tools/platform/compare-module-preparation.mjs'), str(CAPTURE),
                  str(BASELINE / 'wasm'), str(BASELINE / 'pkl_napi.node'), str(FIXTURES),
                  str(ROOT / 'tools/platform/package.json')]),
]
for name, argv in commands:
    with (OUTPUT / (name + '.stdout.bin')).open('wb') as stdout, (OUTPUT / (name + '.stderr.bin')).open('wb') as stderr:
        process = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    record['commands'].append({'name': name, 'argv': argv, 'exitCode': process.returncode,
                              'stdoutSha256': sha(OUTPUT / (name + '.stdout.bin')),
                              'stderrSha256': sha(OUTPUT / (name + '.stderr.bin'))})
    (OUTPUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
record['sourceChanges'] = [name for name, digest in hashes.items() if sha(WORK / name) != digest]
(OUTPUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'commands': record['commands'], 'sourceChanges': record['sourceChanges']}))
sys.exit(0 if all(c['exitCode'] == 0 for c in record['commands']) and not record['sourceChanges'] else 1)
