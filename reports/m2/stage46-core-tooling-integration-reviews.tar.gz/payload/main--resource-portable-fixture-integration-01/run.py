"""Record verification of the promoted Java Resource fixtures without evaluator execution."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + "\n")


promotion = json.loads((OUTPUT / "promotion.json").read_bytes())
source_before = {name: sha(ROOT / name) for name in promotion["promotedHashes"]}
assert source_before == promotion["promotedHashes"]
for name in ["tools/export_resource_portable.py", "tools/resource_fixtures.py",
             "tools/tests/test_resource_portable_fixtures.py"]:
    path = OUTPUT / "sources" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, path)
environment = os.environ.copy()
environment.pop("RESOURCE_PORTABLE_GOLDEN", None)
commands = [
    ("tests", [sys.executable, "-W", "error::ResourceWarning", "-m", "unittest",
               "discover", "-s", "tools/tests", "-p", "test_resource_portable_fixtures.py", "-v"]),
    ("fixture", [sys.executable, "tools/resource_fixtures.py", "--fixtures",
                 "tests/fixtures/m2-resource-portable"]),
    ("inventory", [sys.executable, "tools/m2_manifest.py", "--check"]),
]
report = {
    "schema": 1,
    "scope": "Promoted Java fixture/tool verification; no new evaluator, platform or performance execution.",
    "host": platform.platform(),
    "python": sys.version,
    "pythonExecutable": sys.executable,
    "pythonExecutableSha256": sha(Path(sys.executable).resolve()),
    "pid": os.getpid(),
    "cwd": str(ROOT),
    "fixtureRoot": str(ROOT / "tests/fixtures/m2-resource-portable"),
    "environmentOverride": {"RESOURCE_PORTABLE_GOLDEN": "unset; use repository fixture"},
    "startedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "sourceBefore": source_before,
    "commands": [],
}
write("report.json", report)
for name, argv in commands:
    with (OUTPUT / (name + ".stdout.bin")).open("wb") as stdout, \
         (OUTPUT / (name + ".stderr.bin")).open("wb") as stderr:
        result = subprocess.run(argv, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
    report["commands"].append({"name": name, "argv": argv, "exitCode": result.returncode,
        "stdoutSha256": sha(OUTPUT / (name + ".stdout.bin")),
        "stderrSha256": sha(OUTPUT / (name + ".stderr.bin"))})
    write("report.json", report)
source_after = {name: sha(ROOT / name) for name in source_before}
report["sourceChanges"] = [name for name in source_before if source_before[name] != source_after[name]]
report["finishedUtc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report["passed"] = not report["sourceChanges"] and all(row["exitCode"] == 0 for row in report["commands"])
write("report.json", report)
print(json.dumps({"passed": report["passed"], "commands": report["commands"],
                  "sourceChanges": report["sourceChanges"]}))
sys.exit(0 if report["passed"] else 1)
