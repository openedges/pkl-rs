"""Bind the independent source review to immutable candidate01 only."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
CANDIDATE = OUT.parent / "stage46-implementation-01/resource-candidate-build-01"
sha = lambda data: hashlib.sha256(data).hexdigest()
release = json.loads((CANDIDATE / "release.json").read_bytes())
assert release["artifact_sha256"] == "04d8bb4d4d2ece6f0a8003b82b2426165230d5cf5bc46fe83530aa31e5b5939e"
assert release["source_map_sha256"] == "795783205ac536d9d95e26c68ddb7837288b5ad6aa24d6f4b91f4e4291f61250"
assert sha(Path(release["artifact"]).read_bytes()) == release["artifact_sha256"]
assert sha(Path(release["build_report"]).read_bytes()) == release["build_report_sha256"]
map_path = Path(release["source_map"])
assert sha(map_path.read_bytes()) == release["source_map_sha256"]
source_map = json.loads(map_path.read_bytes())
assert len(source_map) == release["source_count"] == 20848
assert json.loads((CANDIDATE / "source-before.json").read_bytes()) == source_map
snapshot = Path(release["source_snapshot"])
for name, expected in source_map.items():
    path = snapshot / name
    assert path.is_file() and sha(path.read_bytes()) == expected, name
names = ["resources.rs", "vm/resources.rs", "lib.rs", "heap.rs", "host.rs", "host/resources.rs", "host/errors.rs",
         "vm.rs", "vm/builtins.rs", "vm/primitives.rs", "resolver.rs", "evaluation/session.rs", "probe.rs"]
reviewed = {"crates/pkl-runtime/src/" + name: source_map["crates/pkl-runtime/src/" + name] for name in names}
reviewed.update({name: source_map[name] for name in ["crates/pkl-runtime/tests/m2_resources.rs", "crates/pkl-runtime/examples/stage46_resource_probe.rs"]})
report = {"schema": 1, "scope": "Immutable initial Resource/cache candidate01 only; live read*/triple-dot implementation is excluded. No tests/builds/Java/Git/production writes.",
          "candidate": str(CANDIDATE), "release_sha256": sha((CANDIDATE / "release.json").read_bytes()),
          "artifact_sha256": release["artifact_sha256"], "source_map_sha256": release["source_map_sha256"],
          "verified_explicit_snapshot_paths": len(source_map), "all_snapshot_files_match": True,
          "source_before_after_maps_identical": True, "reviewed_source_sha256": reviewed,
          "semantic_review_status": "In progress; URI cache equivalence findings await pinned oracle controls.",
          "full_resource_or_m2_complete": False}
(OUT / "snapshot-audit.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"verified_paths": len(source_map), "report_sha256": sha((OUT / "snapshot-audit.json").read_bytes())}))
