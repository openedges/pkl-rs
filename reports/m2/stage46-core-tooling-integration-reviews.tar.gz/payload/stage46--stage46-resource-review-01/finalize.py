"""Finish scoped semantic findings from frozen source and existing raw evidence."""
from pathlib import Path
import hashlib
import json
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
CANDIDATE = OUT.parent / "stage46-implementation-01/resource-candidate-build-01"
SNAPSHOT = CANDIDATE / "sources"
sha = lambda data: hashlib.sha256(data).hexdigest()
audit = json.loads((OUT / "snapshot-audit.json").read_bytes())
for name, expected in audit["reviewed_source_sha256"].items():
    assert sha((SNAPSHOT / name).read_bytes()) == expected
assert sha((CANDIDATE / "source-after.json").read_bytes()) == audit["source_map_sha256"]
assert sha((CANDIDATE / "artifacts/stage46_resource_probe").read_bytes()) == audit["artifact_sha256"]
references = {}
pin = "e51fb2f91774265666f94980ec630db794a4db2d"
for name in ["pkl-core/src/main/java/org/pkl/core/runtime/ResourceManager.java",
             "pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ReadNode.java",
             "pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ReadOrNullNode.java",
             "pkl-core/src/main/java/org/pkl/core/ast/expression/unary/AbstractReadNode.java",
             "pkl-core/src/main/java/org/pkl/core/resource/Resource.java",
             "pkl-core/src/main/java/org/pkl/core/SecurityManagers.java",
             "pkl-core/src/main/java/org/pkl/core/util/IoUtils.java", "stdlib/base.pkl"]:
    raw = subprocess.check_output(["git", "show", pin + ":" + name], cwd=ROOT / "external/pkl")
    assert raw == (ROOT / "external/pkl" / name).read_bytes()
    references[name] = sha(raw)

base64_root = OUT.parent / "stage46-base64-oracle-01"
base64_path = base64_root / "report.json"
assert sha(base64_path.read_bytes()) == "a297a1277f58a675a0780f8b5f0fd0893a48400b7bcc7c8c96f394e63e1474b0"
base64 = json.loads(base64_path.read_bytes())
property_calls = []
for observation in base64["observations"]:
    for call in observation["calls"]:
        if call["expression"] not in ["propValue", "propNullable", "stable"]:
            continue
        prefix = base64_root / call["rawPrefix"]
        raw = Path(str(prefix) + ".stdout.bin").read_bytes()
        units = Path(str(prefix) + ".stdout.code-units.bin").read_bytes()
        assert sha(raw) == call["utf8Sha256"] and sha(units) == call["utf16BESha256"]
        assert raw == (b"stable" if call["expression"] == "stable" else b"configured-ok")
        assert Path(str(prefix) + ".status.bin").read_bytes() == b"success\n"
        assert (prefix.parent / "configured-key-ssp.code-units.bin").read_bytes() == bytes.fromhex("fffd")
        assert (prefix.parent / "configured-key-ssp.bin").read_bytes() == bytes.fromhex("efbfbd")
        property_calls.append({"raw_prefix": call["rawPrefix"], "expression": call["expression"], "utf8_sha256": sha(raw), "utf16be_sha256": sha(units)})
assert len(property_calls) == 12

native_root = OUT.parent / "stage46-resource-native-01"
native_path = native_root / "report.json"
assert sha(native_path.read_bytes()) == "4e02967005fc4b8de0d036834c4e9a45abe015cd1935578294ff597b0b75d1a5"
native = json.loads(native_path.read_bytes())
assert native["counts"] == {"pass": 508, "candidate-unsupported": 4, "mismatch": 4}
assert native["artifactSha256"] == audit["artifact_sha256"] and native["sourceMapSha256"] == audit["source_map_sha256"]
diagnostics = []
for row in native["comparisons"]:
    if row["status"] != "mismatch":
        continue
    assert row["expression"] == "badUri" and row["differences"] == ["stderr", "stderrUnits"]
    common = f"cases/{row['case']}/{row['repeat']}/calls/session-{row['session']}/"
    java_prefix = OUT.parent / "stage46-resource-oracle-01" / (common + row["javaPrefix"])
    rust_prefix = native_root / (common + row["nativePrefix"])
    java = Path(str(java_prefix) + ".stderr.bin").read_bytes()
    rust = Path(str(rust_prefix) + ".stderr.bin").read_bytes()
    assert java != rust and b"1694 | typealias Uri = String" in java and b"677 | uri: Uri" in rust
    diagnostics.append({"java_raw_prefix": str(java_prefix), "rust_raw_prefix": str(rust_prefix),
                        "java_stderr_sha256": sha(java), "rust_stderr_sha256": sha(rust)})
assert len(diagnostics) == 4

frozen_host = str(SNAPSHOT / "crates/pkl-runtime/src/host/resources.rs")
frozen_resource = str(SNAPSHOT / "crates/pkl-runtime/src/vm/resources.rs")
findings = [
    {"id": "resource-cache-numeric-port-equivalence", "priority": "P2", "path": frozen_host, "line": 116,
     "problem": "Cache key retains raw port spelling, although Java URI equality uses parsed numeric ports and the absent/empty-colon -1 port.",
     "java_observed": "mem://HOST:080/item, mem://host:80/item and mem://HOST:00080/item reuse one reader result and first080 Resource.uri; :0/:00 and absent/emptycolon likewise share cached values.",
     "rust_source_inference": "Only hostname range is replaced, so these port spellings create different String keys and additional reads/policy calls/values. No native run of these new authority controls is claimed.",
     "fix": "Use a structured Java-equivalent URI key with numeric server-authority port, preserving normalized first-reader spelling independently. Recompare complete raw URI/value/read/policy traces using an explicitly matching mem Resource-reader development profile."},
    {"id": "resource-cache-registry-authority-distinction", "priority": "P2", "path": frozen_host, "line": 119,
     "problem": "Filtering empty hostname labels and accepting a final numeric hostname segment incorrectly treats registry authorities as server authorities and folds their case.",
     "java_observed": "mem://A.1/item versus mem://a.1/item and mem://A..B/item versus mem://a..b/item have null Java getHost and distinct reads/cached Resource.uri values.",
     "rust_source_inference": "Both pairs pass the current label predicate and collapse after hostname lowercasing, skipping a distinct reader/policy invocation and returning the wrong cached value.",
     "fix": "Validate complete server authority grammar, including userinfo/hostname/port; preserve registry-authority case except escaped hex case. Keep unsupported URI forms explicit. Multiple@/leading-dot concerns are additional source observations, not acquired oracle assertions."},
    {"id": "resource-uri-alias-check-provenance", "priority": "P2", "path": frozen_resource, "line": 29,
     "problem": "Resource.uri lowers the Uri alias directly to a String check with the class property's Uri reference span, losing the alias body diagnostic location.",
     "java_observed": "bad=new Resource{uri=7;...}; bad.uri reports the String span of base.pkl:1694 typealias Uri=String. Candidate01 reports base.pkl:677 uri:Uri. Four native raw stderr/UTF16 mismatches are retained.",
     "fix": "Preserve shared source-backed alias checking/provenance rather than patching diagnostic text or expected bytes. Retain the original4mismatches and verify the corrective candidate separately."},
    {"id": "configured-reader-java-utf8-percent-decoding", "priority": "P2", "path": frozen_host, "line": 84,
     "classification": "Pre-existing configured prop/env reader gap, not a regression introduced by candidate01 Resource.text.",
     "problem": "String::from_utf8_lossy differs from Java UTF8 replacement for malformed surrogate encodings while decoding the percent-encoded property/environment key.",
     "java_observed": "URI.getSchemeSpecificPart for prop:%ED%A0%80 is oneFFFD; with external property U+FFFD=configured-ok, ordinary read and read? both return configured-ok across4evaluators.",
     "rust_source_inference": "Rust lossy decoding yields three replacements, so lookup misses that key; ordinary read throws and nullable read returns null. No native execution of this new configured-property control is claimed.",
     "fix": "Reuse a source-bound Java-compatible UTF8 replacement primitive for Resource.text and configured URI key decoding, then check the actual configured-reader profile separately."},
]
result = {"schema": 1, "status": "Changes required: two URI-cache equivalence findings, one observed alias-frame mismatch, and one separately classified pre-existing configured-reader gap.",
          "scope": "Independent read-only semantic review of immutable Resource/cache candidate01 only. Live read*/triple-dot work is excluded. No tests, native/Java executions, production or Git writes by this reviewer.",
          "snapshot_audit_sha256": sha((OUT / "snapshot-audit.json").read_bytes()),
          "authority_audit_sha256": sha((OUT / "authority-audit.json").read_bytes()),
          "source_snapshot_stable_after_review": True, "artifact_sha256": audit["artifact_sha256"], "source_map_sha256": audit["source_map_sha256"],
          "pinned_reference_commit": pin, "pinned_reference_sources_sha256": references,
          "findings": findings, "alias_diagnostic_raw_bindings": diagnostics,
          "configured_property_raw_bindings": property_calls,
          "configured_oracle_report_sha256": sha(base64_path.read_bytes()),
          "configured_oracle_provenance_qualification": "Actual Base64Probe.java:45 and cases.json set U+FFFD=configured-ok; generic profile prose saying emptyprops is inaccurate and is being preserved/qualified by the producer. This review relies on actual helper/cases/raw calls, not that prose.",
          "separate_native_acquisition": {"report_sha256": sha(native_path.read_bytes()), "counts": native["counts"],
                                           "unexecuted_api_count": 224, "scope": "Selected primary-root516 of740 Java API calls. ReaderURI traces/counts match in that selected acquisition; no new authority/configured-property native parity claim."},
          "source_observations_without_additional_blockers": [
              "Successful Text/Resource and Missing enter the evaluator cache; typed errors return through fail without publication. Missing stores no exception, allowing authored read diagnostics and read? null behavior per call.",
              "Reader-facing normalized URI spelling and returned Resource.uri payload remain separate from the cache key; the first cached factory object retains the reader's returned URI.",
              "Resource cache values are GC roots; Resource payload Arc contains no heap IDs; class/factory owners remain in shared VM/heap. close clears cache before heap release and pending-token admission precedes typed cache publication.",
              "Legacy raw resume does not insert typed Resource cache entries or turn arbitrary Host/logger/terminal failures into guest errors. ReadFailure remains a bounded IOException mapping, not all Java ResourceManager exception families/security policy.",
              "Resource.text's new decoder handles Java malformed-surrogate replacement and preserves raw CRLF/NUL; the separate configured URI decoder still has the reported pre-existing gap.",
              "Source-backed Resource identity and factory uri/text/bytes/base64 are bounded. Ordinary default bytes/base64DecodedBytes and hash bindings retain explicit Unsupported; general Resource API, relative nonfile/module capabilities and read* are not signed off."
          ],
          "remaining": ["A corrective source freeze and review", "Actual native authority/property controls with matched Host contracts", "Retained unsupported/error diagnostics and224unexecuted API boundaries", "Whole original read/read*/module input and full M2/platform/performance obligations"],
          "full_resource_complete": False, "full_m2_complete": False}
(OUT / "report.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"findings": len(findings), "report_sha256": sha((OUT / "report.json").read_bytes())}))
