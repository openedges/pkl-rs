"""Validate existing authority oracle raw channels; never execute Java/native."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
ORACLE = OUT.parent / "stage46-uri-authority-oracle-01"
sha = lambda data: hashlib.sha256(data).hexdigest()
report_path = ORACLE / "report.json"
report = json.loads(report_path.read_bytes())
assert sha(report_path.read_bytes()) == "6847d1a4e94dbae770da0e4bcb8f2ed9bd40ba8725cf5448f5966018dc5ffc2f"
assert report["freshJvmCount"] == 2 and report["evaluatorSessions"] == 4 and report["apiCalls"] == 196
assert not report["inputChanges"] and report["jarStable"] and report["workspacesUnchanged"]
assert all(not row["rawPathDifferences"] for row in report["repeatDifferences"])
for name, expected in report["inputHashes"].items():
    assert sha(Path(name).read_bytes()) == expected, name
count = 0
for observation in report["observations"]:
    for call in observation["calls"]:
        prefix = ORACLE / call["rawPrefix"]
        utf8 = Path(str(prefix) + ".stdout.bin").read_bytes()
        utf16 = Path(str(prefix) + ".stdout.code-units.bin").read_bytes()
        assert sha(utf8) == call["utf8Sha256"] and utf8.hex() == call["utf8Hex"]
        assert sha(utf16) == call["utf16BESha256"] and utf16.hex() == call["utf16BEHex"]
        assert Path(str(prefix) + ".status.bin").read_bytes() == call["status"].encode()
        assert Path(str(prefix) + ".counters-before.bin").read_bytes() == call["countersBefore"].encode()
        assert Path(str(prefix) + ".counters-after.bin").read_bytes() == call["countersAfter"].encode()
        assert Path(str(prefix) + ".stderr.bin").read_bytes() == b""
        assert Path(str(prefix) + ".stderr.code-units.bin").read_bytes() == b""
        count += 1
assert count == 196
cases = json.loads((ORACLE / "cases.json").read_bytes())
uris = cases[0]["uris"]
selected = []
for observation in report["observations"]:
    for session in [0, 1]:
        calls = {call["expression"]: call for call in observation["calls"] if call["session"] == session}
        for a, b in [(0, 1), (0, 21), (2, 3), (4, 5), (6, 7), (8, 9)]:
            x, y = calls[f"u{a}"], calls[f"u{b}"]
            same = a < 6
            assert (x["utf8Hex"] == y["utf8Hex"]) == same
            # Plain decimal counters are presentation only; complete original
            # channels above are compared unchanged before extracting values.
            def reads(call, channel="countersAfter"):
                return int(next(line for line in call[channel].splitlines() if line.startswith("read=")).split("=", 1)[1])
            assert reads(y) - reads(y, "countersBefore") == (0 if same else 1)
            selected.append({"repeat": observation["repeat"], "session": session, "input_a": uris[a], "input_b": uris[b],
                             "returned_uri_a_utf8_hex": x["utf8Hex"], "returned_uri_b_utf8_hex": y["utf8Hex"],
                             "read_count_a": reads(x), "read_count_b_before": reads(y, "countersBefore"), "read_count_b": reads(y), "expected_same_key": same,
                             "raw_a": x["rawPrefix"], "raw_b": y["rawPrefix"]})
result = {"schema": 1, "scope": "Existing pinned Java authority acquisition integrity and selected cache observations only; no new Java/native executions or claimed native comparison.",
          "oracle_report_sha256": sha(report_path.read_bytes()), "raw_api_calls_verified": count,
          "producer_input_hashes_verified": len(report["inputHashes"]), "selected_observations": selected,
          "source_snapshot": "target/m2/stage46-implementation-01/resource-candidate-build-01", "native_predictions_are_source_inferences": True}
(OUT / "authority-audit.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"raw_calls_verified": count, "report_sha256": sha((OUT / "authority-audit.json").read_bytes())}))
