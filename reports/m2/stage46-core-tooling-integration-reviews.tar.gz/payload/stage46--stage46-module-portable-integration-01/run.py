from pathlib import Path
import hashlib
import json
import platform
import subprocess
import sys

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[2]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
promotion = json.loads((OUTPUT / 'promotion.json').read_bytes())
sources = dict(promotion['promotedHashes'])
for name in ['compatibility/m2-language.json', 'tools/m2_manifest.py',
             'tools/platform/resource-session.mjs', 'tools/platform/resource-session.test.mjs']:
    sources[name] = sha(ROOT / name)
assert all(sha(ROOT / name) == value for name, value in sources.items())
record = {'scope': 'Verification of integrated fixture/consumer tools and source-only inventory refresh before C06 freeze. No new evaluator acquisition.',
          'host': platform.platform(), 'python': sys.version, 'cwd': str(ROOT),
          'sourceBefore': sources, 'commands': []}
commands = [
    ('python-module', [sys.executable, '-W', 'error::ResourceWarning', '-m', 'unittest', 'discover',
                       '-s', 'tools/tests', '-p', 'test_module_portable_fixtures.py', '-v']),
    ('python-resource-oracle', [sys.executable, '-W', 'error::ResourceWarning', '-m', 'unittest', 'discover',
                                '-s', 'tools/tests', '-p', 'test_resource_oracle_fixtures.py', '-v']),
    ('python-logical', [sys.executable, '-W', 'error::ResourceWarning', '-m', 'unittest', 'discover',
                        '-s', 'tools/tests', '-p', 'test_logical_capability_fixtures.py', '-v']),
    ('module-fixture', [sys.executable, 'tools/module_portable_fixtures.py', '--fixtures', 'tests/fixtures/m2-module-portable']),
    ('js', ['node', '--test', 'tools/platform/resource-session.test.mjs', 'tools/platform/module-preparation-session.test.mjs']),
    ('inventory', [sys.executable, 'tools/m2_manifest.py', '--check']),
]
for name, argv in commands:
    with (OUTPUT / (name + '.stdout.bin')).open('wb') as stdout, (OUTPUT / (name + '.stderr.bin')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    record['commands'].append({'name': name, 'argv': argv, 'exitCode': result.returncode,
                               'stdoutSha256': sha(OUTPUT / (name + '.stdout.bin')),
                               'stderrSha256': sha(OUTPUT / (name + '.stderr.bin'))})
    (OUTPUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
record['sourceChanges'] = [name for name, value in sources.items() if sha(ROOT / name) != value]
record['passed'] = not record['sourceChanges'] and all(c['exitCode'] == 0 for c in record['commands'])
(OUTPUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'commands': record['commands'], 'sourceChanges': record['sourceChanges'], 'passed': record['passed']}))
sys.exit(0 if record['passed'] else 1)
