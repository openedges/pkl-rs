"""Acquire actual native/Node/Chromium comparisons against the frozen C06 sources."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent
CANDIDATE = ROOT / "target/m2/stage46-implementation-01/resource-candidate-build-06"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2) + "\n")


release = json.loads((CANDIDATE / "release.json").read_bytes())
source_map = Path(release["source_map"])
assert sha(source_map) == release["source_map_sha256"]
sources = json.loads(source_map.read_bytes())
# The candidate's explicit source map excludes caches before traversal.
assert isinstance(sources, dict) and ".cargo/config.toml" in sources
changed = [name for name, digest in sources.items() if sha(ROOT / name) != digest]
assert not changed, changed
for path, name in [(CANDIDATE / "release.json", "candidate-release.json"),
                   (source_map, "candidate-sources.json"),
                   (ROOT / ".cargo/config.toml", "cargo-config.toml"),
                   (ROOT / "tools/m1_platforms.py", "m1_platforms.py")]:
    shutil.copyfile(path, OUTPUT / name)
environment = os.environ.copy()
environment["CARGO_TARGET_DIR"] = str(ROOT / "target")
node = Path(shutil.which("node")).resolve()
python_command = Path(shutil.which("python3")).resolve()
bindgen = ROOT.parent / "pkl-rs/.cache/m1-tools/bin/wasm-bindgen"
report = {
    "schema": 1,
    "scope": "Actual C06 M1 architecture, typed Resource and module preparation platform acquisition with explicit browser executable paths. Unselected API, complete physical I/O and whole M2 remain separate obligations.",
    "startedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "host": platform.platform(), "pid": os.getpid(), "cwd": str(ROOT),
    "candidateReleaseSha256": sha(CANDIDATE / "release.json"),
    "candidateSourceMapSha256": sha(source_map), "sourceCount": len(sources),
    "candidateSourceChangesBefore": changed,
    "python": sys.version, "pythonExecutable": sys.executable,
    "pythonExecutableSha256": sha(Path(sys.executable).resolve()),
    "driverPythonCommand": str(python_command), "driverPythonSha256": sha(python_command),
    "nodeExecutable": str(node), "nodeExecutableSha256": sha(node),
    "wasmBindgen": str(bindgen), "wasmBindgenSha256": sha(bindgen),
    "environmentOverrides": {"CARGO_TARGET_DIR": environment["CARGO_TARGET_DIR"]},
    "commands": [],
}
write("report.json", report)


def execute(name, argv):
    with (OUTPUT / (name + ".stdout.bin")).open("wb") as stdout, \
         (OUTPUT / (name + ".stderr.bin")).open("wb") as stderr:
        result = subprocess.run(argv, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
    report["commands"].append({"name": name, "argv": [str(a) for a in argv],
        "exitCode": result.returncode,
        "stdoutSha256": sha(OUTPUT / (name + ".stdout.bin")),
        "stderrSha256": sha(OUTPUT / (name + ".stderr.bin"))})
    write("report.json", report)
    return result.returncode


baseline = ROOT / "target/m2/stage46-platform-baseline-02"
resource = ROOT / "target/m2/stage46-resource-platform-02"
module = ROOT / 'target/m2/stage46-module-platform-02'
assert not baseline.exists() and not resource.exists() and not module.exists()
baseline_exit = execute("baseline", [sys.executable, "tools/m1_platforms.py", "--output",
    str(baseline), "--wasm-bindgen", str(bindgen), "--verify-contract"])
if baseline_exit == 0:
    execute("resource", [str(node), "tools/platform/compare-resource.mjs", str(resource),
        str(baseline / "wasm"), str(baseline / "pkl_napi.node"),
        str(ROOT / "tests/fixtures/m2-resource-portable"),
        str(ROOT / "tools/platform/package.json")])
    execute("module-preparation", [str(node), "tools/platform/compare-module-preparation.mjs", str(module),
        str(baseline / "wasm"), str(baseline / "pkl_napi.node"),
        str(ROOT / "tests/fixtures/m2-module-portable"),
        str(ROOT / "tools/platform/package.json")])
report["sourceChangesAfter"] = [name for name, digest in sources.items() if sha(ROOT / name) != digest]
report["finishedUtc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report["selectedAcquisitionPassed"] = len(report["commands"]) == 3 and not report["sourceChangesAfter"] \
    and all(row["exitCode"] == 0 for row in report["commands"])
report["fullCompatibilityPassed"] = False
write("report.json", report)
print(json.dumps({"commands": report["commands"],
    "sourceChangesAfter": report["sourceChangesAfter"],
    "selectedAcquisitionPassed": report["selectedAcquisitionPassed"],
    "fullCompatibilityPassed": False}))
sys.exit(0 if report["selectedAcquisitionPassed"] else 1)
