"""Exploratory binding compilation; concurrent core work is not a final freeze."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
assert not (OUT / 'report.json').exists()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():
    paths = [ROOT / name for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo/config.toml']]
    for crate in ['pkl-runtime', 'pkl-napi', 'pkl-wasm']:
        paths.extend(path for path in (ROOT / 'crates' / crate).rglob('*') if path.is_file())
    return {str(path.relative_to(ROOT)): digest(path) for path in sorted(set(paths))}
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
report = {'scope': 'Exploratory binding compile checks only, with concurrent runtime edits permitted and recorded. Not a final source freeze, actual portable execution, compatibility or performance evidence.',
          'startedUtc': now(), 'cwd': str(ROOT), 'platform': platform.platform(),
          'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
          'sourceBefore': sources(), 'commands': [], 'complete': False}
env = dict(os.environ, CARGO_TARGET_DIR=str(ROOT / 'target/stage46-binding-cargo'))
report['cargoTargetDir'] = env['CARGO_TARGET_DIR']
def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
save()
for label, argv in [
    ('napi-check', ['cargo', 'check', '-p', 'pkl-napi', '--locked']),
    ('wasm-check', ['cargo', 'check', '-p', 'pkl-wasm', '--target', 'wasm32-unknown-unknown', '--locked']),
]:
    start = time.monotonic()
    row = {'label': label, 'argv': argv, 'startedUtc': now()}
    print('START', label, flush=True)
    with (OUT / (label + '.stdout.bin')).open('wb') as stdout, (OUT / (label + '.stderr.bin')).open('wb') as stderr:
        child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
        row['pid'] = child.pid
        row['returncode'] = child.wait()
    row.update(finishedUtc=now(), seconds=time.monotonic() - start,
               stdoutSha256=digest(OUT / (label + '.stdout.bin')), stderrSha256=digest(OUT / (label + '.stderr.bin')))
    report['commands'].append(row)
    save()
    print('FINISH', label, row['returncode'], flush=True)
report['sourceAfter'] = sources()
report['changedSourcePaths'] = sorted(path for path in report['sourceBefore'].keys() | report['sourceAfter'].keys()
                                     if report['sourceBefore'].get(path) != report['sourceAfter'].get(path))
report.update(complete=True, finishedUtc=now())
save()
raise SystemExit(0 if all(row['returncode'] == 0 for row in report['commands']) else 1)
