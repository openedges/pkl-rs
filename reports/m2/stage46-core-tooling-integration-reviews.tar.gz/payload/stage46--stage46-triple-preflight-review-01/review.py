"""Draft preflight timing review from frozen proposal and existing Java records."""
from pathlib import Path
import hashlib
import json
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
M2 = OUT.parent
PROPOSAL = M2 / "stage46-implementation-01/triple-proposal-01"
sha = lambda data: hashlib.sha256(data).hexdigest()
raw = (PROPOSAL / "report.json").read_bytes()
assert sha(raw) == "46a69f9d3cd5481bade049e345d07272df12e1f8c300d3da536a68190f243000"
proposal = json.loads(raw)
assert len(proposal["sources"]) == 13
for name, expected in proposal["sources"].items():
    assert sha((PROPOSAL / "sources" / name).read_bytes()) == expected
references = {}
pin = "e51fb2f91774265666f94980ec630db794a4db2d"
for name in ["pkl-core/src/main/java/org/pkl/core/ast/builder/AstBuilder.java",
             "pkl-core/src/main/java/org/pkl/core/util/IoUtils.java",
             "pkl-core/src/main/java/org/pkl/core/module/ModuleKeys.java"]:
    data = subprocess.check_output(["git", "show", pin + ":" + name], cwd=ROOT / "external/pkl")
    destination = OUT / "references" / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    references[name] = sha(data)

oracles = {}
for label in ["stage46-triple-import-oracle-01", "stage46-module-capability-oracle-02", "stage46-module-capability-oracle-03"]:
    source = M2 / label
    raw = (source / "report.json").read_bytes()
    data = json.loads(raw)
    calls = 0
    for observation in data["observations"]:
        for call in observation["calls"]:
            channel = "stdout" if call["status"] == "success\n" else "stderr"
            prefix = source / call["rawPrefix"]
            content = Path(str(prefix) + "." + channel + ".bin").read_bytes()
            units = Path(str(prefix) + "." + channel + ".code-units.bin").read_bytes()
            assert sha(content) == call["utf8Sha256"] and sha(units) == call["utf16BESha256"]
            assert Path(str(prefix) + ".status.bin").read_bytes() == call["status"].encode()
            for channel_name, field in [("counters-before", "countersBefore"), ("counters-after", "countersAfter")]:
                assert Path(str(prefix) + "." + channel_name + ".bin").read_bytes() == call[field].encode()
            calls += 1
    assert calls == data["apiCalls"]
    oracles[label] = {"path": str(source / "report.json"), "sha256": sha(raw), "raw_api_calls_verified": calls, "counts": data["counts"]}

uri_source = PROPOSAL / "sources/crates/pkl-runtime/src/vm/uri_resolution.rs"
report = {
    "schema": 1, "status": "Draft not signed off: unresolved compiler-error/effect interleaving and nested AST visitation mismatches.",
    "scope": "Pinned-source and existing Java raw-evidence review of exact13file draft only. Not a release/build freeze; no live source, new tests/native/Java/oracle runs or production/Git mutations.",
    "proposal": {"path": str(PROPOSAL / "report.json"), "sha256": sha((PROPOSAL / "report.json").read_bytes()), "source_files_verified": 13, "source_hashes": proposal["sources"]},
    "pinned_reference_commit": pin, "pinned_source_sha256": references,
    "existing_oracle_raw_bindings": oracles,
    "pinned_ast_timing": [
        "AstBuilder.doVisitImport657 invokes resolveImport3012 while constructing AST; IoUtils352-392 performs ancestor/selfskip hasElement search there. Module source loading remains lazy.",
        "visitModule1456+ validates module modifiers before imports, then imports1481,annotations1490,parent1495,classes/typealiases1510,properties1519,methods1535. Global authored-span sorting does not preserve this sequence.",
        "Read resolution stays runtime in AbstractReadNode before ResourceManager lookup; import search is AST-construction time, so unused/nested module imports can fail before an unrelated first query."
    ],
    "verified_proposal_improvements": [
        "Per-unit AST-category order replaces initial global-span ordering; class properties precede methods.",
        "Query units have separate repl:text sources and entry usizeMAX; query PrepareModuleImports is attached to selected query admission, leaving future query effects untouched.",
        "Typed Capabilities/HasElement effects separate ancestor search from lazy module Source loading; every triple read resolves before Resource cache lookup.",
        "The draft copies child error source provenance before adjusting caller-owned diagnostic identity; initial import resolution failure is retained by existing module error-cache paths. Exact child cached frames remain an acquired Java requirement, not newly proven native parity."
    ],
    "findings": [
        {"id": "compile-error-effect-phase-interleaving", "priority": "P2", "status": "Author explicitly acknowledges unresolved draft boundary.",
         "problem": "The whole Rust compile can fail before first runtime PrepareModuleImports. Java interleaves AST-node validation and triple search, so a later semantic compile error can mask an earlier missing import or suppress earlier required hasElement effects.",
         "qualification": "Pure syntax parsing remains before AST visits; this finding concerns later AST/semantic checks. No new mixed-error oracle was acquired here.",
         "required": "Preserve ordered AST validation/effect phases or record exact unsupported boundaries; do not claim global first-error parity from focused success."},
        {"id": "let-type-before-binding-order", "priority": "P2", "path": str(uri_source),
         "problem": "Draft E::Let visits bindingvalue→type→body, but pinned AstBuilder1117–1134 visits typeannotation→bindingvalue→body.",
         "effect": "Triple imports in a let typeconstraint versus binding value can produce different first missing URI and Host effects. Source-proven traversal mismatch; not an observed new native run."},
        {"id": "when-body-before-predicate-order", "priority": "P2", "path": str(uri_source),
         "problem": "Draft O::When visits predicate→then→else; pinned AstBuilder1354–1366 builds then→else→predicate.",
         "effect": "A missing import in a branch must be searched before a missing predicate import during AST construction, even though runtime predicate evaluation is earlier. These are separate ordering contracts."},
        {"id": "for-binding-type-import-omission", "priority": "P2", "path": str(uri_source),
         "problem": "Draft O::For discards parameters and visits iterable/members only. Existing syntax.parameters carry typeannotations; Java1391–1431 visits key/value typeannotations before iterable and body.",
         "effect": "Imports in binding typeconstraints are omitted from plan or lead to the leftover-emitted-import Host failure, rather than the required ordered search."}
    ],
    "additional_unacquired_source_observations": [
        "AstBuilder.doVisitObjectBody2230–2296 first visits ordinary members, then restarts the whole object in generator mode upon encountering a generator. A successful triple import before that generator can be visited twice; current span-map dedup/remove models once. ModuleKeys.File325 calls policy/FileResolver each time. No new callback-count oracle control was acquired, so this remains a separate source observation.",
        "Gathering emitted bytecode imports must cover every AST import that Java visits, including constraints/otherwise lazy code; an absent lowering must not silently skip AST preparation. This broader compiler-lowering coverage was not exhaustively established by this review."
    ],
    "existing_controls_interpretation": [
        "Unused missing import direct case: stable, stable retry and lazyRead all fail on the import operand, read0; later calls retain cached failure without renewed resolution/securepath counters. This proves eager AST failure and cache timing for that case.",
        "Caught child case: catch/catchOrNull succeed with message-only text, ordinary call errors, main stable succeeds and caught retry succeeds. Independent child stable retains original main#caught.<function#1> owner at childURI and the prior ordinary repl frame; preserve complete diagnostics, not just headline.",
        "Capability02 contains an unused failing import and all32queries are masked by AST preflight. Capability03 removes that import and records16read/read? errors plus8stable successes. These scopes cannot be substituted for each other.",
        "Initial genericfactory setup failures and independent-root limitations remain their original outcomes; no new suite is treated as a pass merely because import preflight correctly masks a query."
    ],
    "candidate02_relation": "The13file draft includes a live-successor malformed-userinfo correction, but it is separate from immutable candidate02 and has not been relabeled as candidate02 evidence.",
    "source_stability": "All13 frozen proposal hashes rechecked after review.",
    "full_triple_dot_complete": False, "full_resource_complete": False, "full_m2_complete": False,
}
for name, expected in proposal["sources"].items():
    assert sha((PROPOSAL / "sources" / name).read_bytes()) == expected
(OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"proposal_files": 13, "raw_api_calls_verified": sum(row["raw_api_calls_verified"] for row in oracles.values()), "report_sha256": sha((OUT / "report.json").read_bytes())}))
