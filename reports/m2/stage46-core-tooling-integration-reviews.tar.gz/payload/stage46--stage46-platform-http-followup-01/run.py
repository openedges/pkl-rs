from pathlib import Path
import datetime
import hashlib
import json
import platform
import shutil
import subprocess
import sys

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[2]
BASELINE = ROOT / 'target/m2/stage46-platform-baseline-02'
CANDIDATE = ROOT / 'target/m2/stage46-implementation-01/resource-candidate-build-06'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
release = json.loads((CANDIDATE / 'release.json').read_bytes())
source_map = Path(release['source_map'])
assert sha(source_map) == release['source_map_sha256']
sources = json.loads(source_map.read_bytes())
fix_path = ROOT / 'target/m2/stage46-http-server-correction-01/final-application.json'
fix = json.loads(fix_path.read_bytes())
allowed = {row['path']: row for row in fix['files']}
changed = []
for name, digest in sources.items():
    actual = sha(ROOT / name)
    if actual != digest:
        row = allowed[name]
        assert row['before'] == digest and row['after'] == actual
        changed.append(name)
        sources[name] = actual
assert set(changed) == set(allowed)
for name in changed:
    destination = OUTPUT / 'sources' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / name, destination)
build = json.loads((BASELINE / 'report.json').read_bytes())
for name, digest in build['artifacts'].items():
    assert sha(BASELINE / name) == digest
record = {'scope': 'Fresh actual Resource/module comparisons using immutable C06 bindings after HTTP verification-tool corrections only. Baseline acquisition02 remains successful; its failed supplemental acquisitions remain preserved.',
          'host': platform.platform(), 'python': sys.version, 'cwd': str(ROOT),
          'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'candidateReleaseSha256': sha(CANDIDATE / 'release.json'),
          'candidateSourceMapSha256': sha(source_map), 'sourceCount': len(sources),
          'baselineReportSha256': sha(BASELINE / 'report.json'),
          'postBuildToolingCorrectionSha256': sha(fix_path),
          'postBuildToolingChanges': changed, 'runtimeOrBuildConfigurationChanges': [], 'commands': []}
(OUTPUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
for name, driver, fixtures in [
    ('resource', 'compare-resource.mjs', 'm2-resource-portable'),
    ('module', 'compare-module-preparation.mjs', 'm2-module-portable')]:
    capture = ROOT / f'target/m2/stage46-{name}-platform-03'
    assert not capture.exists()
    argv = ['node', 'tools/platform/' + driver, str(capture), str(BASELINE / 'wasm'),
            str(BASELINE / 'pkl_napi.node'), str(ROOT / 'tests/fixtures' / fixtures),
            str(ROOT / 'tools/platform/package.json')]
    with (OUTPUT / (name + '.stdout.bin')).open('wb') as stdout, (OUTPUT / (name + '.stderr.bin')).open('wb') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    record['commands'].append({'name': name, 'argv': argv, 'exitCode': result.returncode,
                              'stdoutSha256': sha(OUTPUT / (name + '.stdout.bin')),
                              'stderrSha256': sha(OUTPUT / (name + '.stderr.bin'))})
    (OUTPUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
record['sourceChangesDuringAcquisition'] = [name for name, digest in sources.items() if sha(ROOT / name) != digest]
record['finishedUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
record['selectedAcquisitionPassed'] = not record['sourceChangesDuringAcquisition'] and all(c['exitCode'] == 0 for c in record['commands'])
record['fullCompatibilityPassed'] = False
(OUTPUT / 'report.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'commands': record['commands'], 'sourceChangesDuringAcquisition': record['sourceChangesDuringAcquisition'],
                  'selectedAcquisitionPassed': record['selectedAcquisitionPassed'], 'fullCompatibilityPassed': False}))
sys.exit(0 if record['selectedAcquisitionPassed'] else 1)
