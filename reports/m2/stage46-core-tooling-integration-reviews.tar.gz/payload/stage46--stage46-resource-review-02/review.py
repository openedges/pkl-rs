"""Read-only corrective review and existing raw-result join for candidate02."""
from pathlib import Path
import hashlib
import json
import zipfile

OUT = Path(__file__).resolve().parent
M2 = OUT.parent
C01 = M2 / "stage46-implementation-01/resource-candidate-build-01"
C02 = M2 / "stage46-implementation-01/resource-candidate-build-02"
sha = lambda data: hashlib.sha256(data).hexdigest()
release_bytes = (C02 / "release.json").read_bytes()
assert sha(release_bytes) == "d2bfb56b9fbd52c507225306417c6db34a9fb7fad292d52bce9b38c303918cb4"
release = json.loads(release_bytes)
assert sha(Path(release["artifact"]).read_bytes()) == release["artifact_sha256"] == "bb1a75a8e073a11d08942647f673756e7d83f73b220ca7e94b496a18a6c44c21"
assert sha(Path(release["build_report"]).read_bytes()) == release["build_report_sha256"]
map_bytes = Path(release["source_map"]).read_bytes()
assert sha(map_bytes) == release["source_map_sha256"] == "9474003138aafa4ccdef5e9984f0592864815510d5fb6c451079a82fc68e20de"
source_map = json.loads(map_bytes)
assert len(source_map) == 20899 and source_map == json.loads((C02 / "source-before.json").read_bytes())
snapshot = Path(release["source_snapshot"])
for name, expected in source_map.items():
    assert sha((snapshot / name).read_bytes()) == expected, name
old_map = json.loads((C01 / "source-after.json").read_bytes())
rust_delta = sorted(name for name in old_map.keys() | source_map.keys() if name.startswith("crates/") and old_map.get(name) != source_map.get(name))
suites = [
    ("resource", "stage46-resource-native-03", "stage46-resource-oracle-01", "ad335de7fe96208398550b73facd5fa678fd52f907a34baff25493fb0a7afd28", 516, 224),
    ("authority", "stage46-uri-authority-native-02", "stage46-uri-authority-oracle-01", "4bbe6f232f615dfdc1c9356aa52cc28c21b785ad8b6d0e3ae72cd6a08326ae29", 196, 0),
    ("base64", "stage46-base64-native-02", "stage46-base64-oracle-01", "799ed30fd8bc536f16a0c833d9e8b5afede0ae14210b84a94bb5eebc6954593a", 268, 8),
    ("missing-retry", "stage46-resource-extra-native-02", "stage46-resource-extra-oracle-01", "4174b5f3ec7eb96b1bbe94bed47ceff9a07f74b1469a6593ad2603599061e75c", 28, 32),
]
verified_suites = {}
channels = ["status.bin", "stdout.bin", "stderr.bin", "stdout.code-units.bin", "stderr.code-units.bin"]
for label, native_name, java_name, expected_report, calls, unexecuted in suites:
    native_root = M2 / native_name
    raw = (native_root / "report.json").read_bytes()
    assert sha(raw) == expected_report
    report = json.loads(raw)
    assert report["counts"] == {"pass": calls}
    assert report["selectedExpectedApiCalls"] == calls and len(report["comparisons"]) == calls
    assert report["unexecutedApiCount"] == unexecuted and report["strictSelectedCompatibilityPassed"]
    assert report["artifactSha256"] == release["artifact_sha256"] and report["sourceMapSha256"] == release["source_map_sha256"]
    for row in report["comparisons"]:
        assert row["status"] == "pass" and not row["differences"]
        common = f"cases/{row['case']}/{row['repeat']}/calls/session-{row['session']}/"
        native_prefix = native_root / (common + row["nativePrefix"])
        java_prefix = M2 / java_name / (common + row["javaPrefix"])
        for channel in channels:
            assert Path(str(native_prefix) + "." + channel).read_bytes() == Path(str(java_prefix) + "." + channel).read_bytes(), (label, row, channel)
        for counter in ["reads-before.bin", "reads-after.bin"]:
            assert Path(str(native_prefix) + "." + counter).read_bytes() == Path(str(java_prefix) + "." + counter).read_bytes()
    verified_suites[label] = {"report": str(native_root / "report.json"), "report_sha256": expected_report,
                              "raw_calls_independently_joined": calls, "unexecuted_calls": unexecuted,
                              "artifact_and_source_binding_match": True,
                              "reader_trace_counts_as_recorded": report["readerTraceCounts"]}

jdk = Path("/Library/Java/JavaVirtualMachines/temurin-21.jdk/Contents/Home")
with zipfile.ZipFile(jdk / "lib/src.zip") as archive:
    uri_source = archive.read("java.base/java/net/URI.java")
(OUT / "URI.java").write_bytes(uri_source)
host = snapshot / "crates/pkl-runtime/src/host/resources.rs"
resource = snapshot / "crates/pkl-runtime/src/vm/resources.rs"
reviewed_names = [name for name in rust_delta if "/src/" in name] + ["crates/pkl-runtime/src/resources.rs", "crates/pkl-runtime/examples/stage46_resource_probe.rs", "crates/pkl-runtime/tests/m2_resources.rs"]
report = {
    "schema": 1, "status": "Four original finding sources corrected, but candidate02 has a newly identified malformed-userinfo panic path and is not signed off.",
    "scope": "Immutable candidate02 source only; live correction/triple proposal is excluded. Existing four native comparison suites are audited as separate bounded scopes. No tests/builds/Java/native/Git/production writes by reviewer.",
    "prior_review": str(M2 / "stage46-resource-review-01/report.json"),
    "prior_review_sha256": sha((M2 / "stage46-resource-review-01/report.json").read_bytes()),
    "release_sha256": sha(release_bytes), "artifact_sha256": release["artifact_sha256"], "source_map_sha256": release["source_map_sha256"],
    "explicit_frozen_paths_verified": len(source_map), "source_before_after_maps_identical": True,
    "rust_source_delta": rust_delta, "reviewed_source_hashes": {name: source_map[name] for name in sorted(set(reviewed_names))},
    "finding_resolutions": [
        {"id": "resource-cache-numeric-port-equivalence", "source": "Structured Server authority carries parsed Option<i32> port while reader spelling remains separate.", "raw_support": "authority196calls pass, including numericport/absentcolon aliases and original first returnedURI/readcounts."},
        {"id": "resource-cache-registry-authority-distinction", "source": "Registry/String and Server/userinfo/host/port are distinct; emptylabels, numeric finalhostname and multiple@ no longer silently fold as validserver.", "raw_support": "authority196calls pass for acquired cases only; newly malformeduserinfo is a separate finding."},
        {"id": "resource-uri-alias-check-provenance", "source": "Resource.uri String check metadata derives its span from the pinned Uri alias target.", "raw_support": "All4former badUri rawstderr/UTF16 mismatches now pass within resource516. C01 failures remain unchanged."},
        {"id": "configured-reader-java-utf8-percent-decoding", "source": "Configured prop/env percent decoding now reuses the same Java-style UTF8 primitive as Resource.text.", "raw_support": "Resource24UTF8vectors remain in resource516; the8configured-property JavaAPI controls are still explicitly unexecuted natively. Source correction is not reported as native configured-reader parity."}
    ],
    "default_resource_bytes": {"previous": "C01 customBytes4calls explicitUnsupported.", "current": "Default bytes delegates through base64.base64DecodedBytes; those4calls now pass inside resource516. Separate Stringdecoder268calls pass; invalid Resource-default-byte diagnostic contexts are not established by these positive customBytes calls."},
    "new_findings": [{
        "id": "malformed-ipv6-userinfo-panic", "priority": "P1", "path": str(host),
        "input": "read(\"mem://%@[::1]/x\")", "basis": "Source-proven bounds failure; this input was not executed by reviewer and is outside acquired authority196 controls.",
        "trace": "from_authored accepts URI-like form; parse authority%@[::1]; validate_authority seesbrackets and calls server_authority before userinfo validation; split_once('@') gives user% and host[::1]; fold_escapes(user) indexes bytes[1]/bytes[2] when length1.",
        "introduced_since_candidate01": "C01 rejected IPv6 as Unsupported before this branch. C02 unvalidateduserinfo can reach folding during parsing.",
        "adjacent_gap": "The bracket branch validates only text before first[, so literal brackets within userinfo can also be admitted without the required userinfo grammar check.",
        "jdk_source": {"archive": str(jdk / "lib/src.zip"), "URI_java_sha256": sha(uri_source), "lines": "2744-2749 userinfo mask,3269-3342 authority fallback,3360-3365 userinfo check before host."},
        "required_action": "Validate userinfo syntax/escapes before cache canonicalization and reject malformed inputs as language URI errors or explicit unsupported forms; preserve C02 and verify a fresh corrective freeze."}],
    "existing_raw_suites": verified_suites, "selected_raw_calls_verified": 1008,
    "scope_qualifications": [
        "1008 is a sum of separate selected API observations; it is not whole Resource/M2 coverage.",
        "Resource224other-root/URI-policy,base648configured-property and extra32initialcapability-setup calls remain unexecuted in these native acquisitions.",
        "Four first consumer02 attempts failed before native invocation due selector-name shadowing; later consumer03 CLI regression13tests and fresh comparisons are distinct recorded producer work, not reviewer test runs.",
        "Read* AST/plumbing is present in C02 but emits explicit Unsupported for expansion; its language/error ordering is outside corrective Resource signoff.",
        "Hash bindings, scopedIPv6, malformedURI grammar, generic security/reader exception families, arbitraryResource/default-error contexts,platforms and performance remain bounded/unverified."
    ],
    "full_resource_complete": False, "full_m2_complete": False,
}
for name in set(reviewed_names):
    assert sha((snapshot / name).read_bytes()) == source_map[name]
(OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"verified_frozen_paths": len(source_map), "existing_raw_calls_verified": 1008, "new_p1": 1, "report_sha256": sha((OUT / "report.json").read_bytes())}))
