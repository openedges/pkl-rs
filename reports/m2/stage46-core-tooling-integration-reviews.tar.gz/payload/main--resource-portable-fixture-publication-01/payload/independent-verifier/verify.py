"""Read-only independent inspection of sealed Java Resource fixture tooling."""
import ast,hashlib,json,os,re,stat,struct,time
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46')
B=ROOT/'target/m2/stage46-resource-portable-verifier-02'
S=ROOT/'target/m2/stage46-resource-portable-verifier-audit-01'
OUT=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage46-resource-portable-verifier-review-01')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def safe(n):
 p=Path(n);assert str(p)==n and not p.is_absolute() and '..' not in p.parts,n
 return p
start=time.time();report=load(B/'report.json');closure=load(B/'closure.json');supplement=load(S/'report.json')
assert sha(B/'report.json')=='22a1a22dcc5c8020402a98965ff79cb1576087ef1befa864f9fc0a92440257cd'
assert sha(B/'closure.json')=='79bfb8094ffdb97a77615cc46fcf16762b5e8a58ccf81ac38f68fe597e087767'
assert sha(S/'report.json')=='41f1f58b90f2586f33e7669b6aa950689a0b45230cd713c792871a0856bfb562'
assert closure['closed'] and closure['reportSha256']==sha(B/'report.json') and sha(B/'inventory.json')==closure['inventorySha256']
inv=load(B/'inventory.json')['files'];assert len(inv)==closure['files']==27
for row in inv:
 p=B/safe(row['path']);assert p.is_file() and not p.is_symlink() and sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
source=load(B/'source-after.json');assert source==load(B/'source-before-tests-03.json')==report['sources'] and sha(B/'source-after.json')==report['sourceMapSha256']=='b79141b6e0fac205a62c0630f8341f39e01229d235b886de1076401068bd120a'
for n,h in source.items():
 p=B/'workspace'/safe(n);assert sha(p)==h
 t=OUT/'sources'/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
module=ast.parse((B/'workspace/tools/resource_fixtures.py').read_bytes());pins=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SEALED_PINS' for t in n.targets));assert pins==report['independentSealedJavaPins']
for group,p in pins.items():
 original=Path(p['root'])
 for n,k in [('inventory.json','inventorySha256'),('closure.json','closureSha256'),('report.json','reportSha256')]:assert sha(original/n)==p[k]
launch=load(B/'tests-03.launch.json');terminal=load(B/'tests-03.terminal.json');assert launch['pid']==terminal['pid']==report['tests']['pid']==21055 and terminal['exitCode']==report['tests']['exitCode']==0
assert launch['command'][0:3]==['python3','-W','error::ResourceWarning']
for ch in ['stdout','stderr']:assert sha(B/('tests-03.'+ch+'.bin'))==report['tests'][ch+'Sha256']
raw=(B/'tests-03.stderr.bin').read_bytes();assert re.search(rb'Ran 27 tests in [0-9.]+s\n\nOK\n\Z',raw) and b'ResourceWarning' not in raw
assert report['tests']['realReblessedFixtureForgeries']==14 and report['tests']['fullGoldenCliTestIncluded']
golden=Path(report['golden']['root']);assert str(golden)==supplement['testsActualEnvironment']['RESOURCE_PORTABLE_GOLDEN'] and supplement['testsActualEnvironment']['PYTHONDONTWRITEBYTECODE']=='1'
manifest=load(golden/'manifest.json');assert sha(golden/'manifest.json')==report['golden']['manifestSha256']==supplement['goldenManifestSha256']=='df35f5b49f28ecd1b9e70111862001ddbd3052978026a9b67fa143573a62f369'
expected=set(manifest['files'])|{'manifest.json'};dirs={'.'}
for n in expected:dirs.update(str(p) for p in safe(n).parents)
found=set();pending=[golden]
while pending:
 p=pending.pop()
 with os.scandir(p) as entries:
  for entry in entries:
   n=Path(entry.path).relative_to(golden).as_posix();mode=entry.stat(follow_symlinks=False).st_mode
   if stat.S_ISDIR(mode):assert n in dirs,n;pending.append(Path(entry.path))
   else:assert stat.S_ISREG(mode),n;found.add(n)
assert found==expected and len(manifest['files'])==11507 and len(found)==11508
for n,row in manifest['files'].items():
 p=golden/n;assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],n
post=load(Path(supplement['postTestPathHashes']));assert sha(Path(supplement['postTestPathHashes']))==supplement['postTestPathHashesSha256']
print('Golden actual files',len(found),'payloads',len(manifest['files']),flush=True)
data=load(golden/'fixtures.json');prov=load(golden/'provenance.json');bindings=prov['originalPaths'];assert set(manifest['files'])=={'fixtures.json','provenance.json'}|{r['path'] for r in bindings.values()}
reports={}
for g,p in pins.items():
 local=golden/'provenance'/g
 for n,k in [('inventory.json','inventorySha256'),('closure.json','closureSha256'),('report.json','reportSha256')]:assert sha(local/n)==p[k]
 reports[g]=load(local/'report.json');inventory={r['path']:r for r in load(local/'inventory.json')['files']}
 for original,row in bindings.items():
  orig=Path(original)
  if not orig.is_relative_to(Path(p['root'])):continue
  rel=orig.relative_to(Path(p['root'])).as_posix()
  if rel in ['inventory.json','closure.json']:assert row['sha256']==p['inventorySha256' if rel=='inventory.json' else 'closureSha256']
  else:assert row['sha256']==inventory[rel]['sha256'] and row['bytes']==inventory[rel]['bytes']
assert len(data['fixtures'])==20 and data['javaApiCalls']==1272 and len(data['unexecutedApiBoundaries'])==264
calls=0
for fixture in data['fixtures']:
 group,case=fixture['id'].split('/',1);ob=next(x for x in reports[group]['observations'] if x['case']==case and x['repeat']==fixture['repeat'])
 chosen=[c for c in ob['calls'] if c['session']==fixture['session'] and c['source']=='main.pkl' and not(case=='base64-decoder' and c['expression'] in {'propValue','propNullable'})]
 assert fixture['expressions']==[c['expression'] for c in chosen] and len(fixture['expected'])==len(chosen)
 for expect,c in zip(fixture['expected'],chosen):
  prefix=golden/'raw'/group/c['rawPrefix'];read=lambda suffix:Path(str(prefix)+'.'+suffix).read_bytes()
  assert read('status.bin')==c['status'].encode();assert expect['status']=={'success\n':'success','error\n':'error'}[c['status']]
  for phase,key in [('before','countersBefore'),('after','countersAfter')]:
   counter=read('counters-'+phase+'.bin');assert counter==c[key].encode();values=dict(line.split('=',1) for line in counter.decode().splitlines())
   assert read('reads-'+phase+'.bin')==values['read'].encode() and expect['reads'+phase.title()]==int(values['read'])
  for ch in ['stdout','stderr']:
   raw=read(ch+'.bin');units=read(ch+'.code-units.bin');assert len(units)%2==0
   assert expect[ch+'Units']==list(struct.unpack('>'+'H'*(len(units)//2),units)) and expect[ch+'Hex']==raw.hex()
   assert units.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==raw
  active='stdout' if expect['status']=='success' else 'stderr';assert read(active+'.bin').hex()==c['utf8Hex'] and read(active+'.code-units.bin').hex()==c['utf16BEHex'];calls+=1
assert calls==1008
assert all(sha(B/'workspace'/p)==h for p,h in source.items()) and sha(golden/'manifest.json')==report['golden']['manifestSha256']
result={'schema':1,'scope':'Read-only independent review of corrected portable Resource verifier03 and existing terminal/closure. No Java/native/platform acquisition or new unit rerun. Only new review artifacts written.','verifierReport':{'path':str(B/'report.json'),'sha256':sha(B/'report.json')},'verifierClosure':{'path':str(B/'closure.json'),'sha256':sha(B/'closure.json')},'supplementalAudit':{'path':str(S/'report.json'),'sha256':sha(S/'report.json')},'sourceMapSha256':sha(B/'source-after.json'),'sources':source,'sealedVerifierPayloadsVerified':len(inv),'goldenManifestSha256':sha(golden/'manifest.json'),'goldenPayloadFiles':len(manifest['files']),'goldenActualRegularFilesIncludingManifest':len(found),'goldenActualPathSetExact':True,'goldenPayloadHashesVerified':11507,'rawSelectedApiCallsIndependentlyJoinedToPinnedReports':calls,'sessions':20,'javaApiCalls':1272,'unexecutedJavaApiBoundaries':264,'existingFinalTests':{'count':27,'terminalExit':0,'pid':21055,'resourceWarnings':0,'realReblessedForgeries':14},'findings':[],'sourceReview':['Pinned report countersBefore/After directly bind both copied counter bytes and raw read count files, then expected per-call read counts.','Independently fixed inventory/closure digests authenticate original raw and source bindings; reblessing outer manifest/provenance cannot redefine the trusted original inventory.','Canonical original/local mappings authenticate traversal allowlist before directory scanning; unexpected directories and nonregular entries are rejected before descent.','Actual regular-file set equals manifest plus its own file, and manifest payload keys equal semantic provenance bindings. Required raw suffixes/call/event bindings must be present and every binding used.','14 reblessed forgeries cover count/raw/report/inventory/call/event removal/substitution and missing/extra files; forged cargo-target path has a scandir-before-rejection spy.'],'qualifications':['11507 means payloads; total regular files are11508 including manifest. Treating11507 as total is a counting error, not a change in original bytes.','The actual test environment is supplementary authored-wrapper provenance, explicitly labeled; it is not retroactively a direct environment capture by the old process launcher.','Actual Node/browser execution remains pending; this verifies Java-derived fixture/tooling integrity only.','C04 semantic/runtime source and its retained failures are a separate scope; fixture success does not complete Resource or M2.'],'seconds':time.time()-start}
(OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'report':str(OUT/'report.json'),'sha256':sha(OUT/'report.json'),'seconds':result['seconds']}),flush=True)
