#!/usr/bin/env python3
"""Compare every new fixture with raw, unchanged Java captures and the final artifact."""
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import m2_language as language

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

origins = [ROOT / 'target/m2' / name for name in ['stage35-selected-oracle-01',
           'stage35-review-selected-oracle-01', 'stage35-builtin-selected-oracle-01/recovered',
           'stage35-builtin-selected-oracle-01/direct']]
origin = ROOT / 'target/m2/language-stage35-final-01/artifacts/language_probe'
output = ROOT / 'target/m2/focused-stage35-final-01'
output.mkdir(exist_ok=False)
binary = output / 'language_probe'
shutil.copy2(origin, binary)
shutil.copyfile(__file__, output / 'compare_focus.py')
results = []
sources = {}
reports = {}
for baseline in origins:
    previous = json.loads((baseline / 'report.json').read_bytes())
    reports[str((baseline / 'report.json').relative_to(ROOT))] = sha(baseline / 'report.json')
    for old in previous['results']:
        identifier = old['id']
        source = ROOT / old['input']
        assert sha(source) == old['input_sha256']
        sources[old['input']] = sha(source)
        directory = output / 'cases' / identifier
        directory.mkdir(parents=True)
        shutil.copyfile(source, directory / 'input.pkl')
        for name in ['java.process.json', 'java.stdout.bin', 'java.stderr.bin', 'java.outcome.bin']:
            file = baseline / 'cases' / identifier / name
            assert sha(file) == previous['files'][f'cases/{identifier}/{name}']
            shutil.copyfile(file, directory / name)
        rust = language.capture([str(binary), str(source), old['expression']], directory, 'rust', previous['oracle']['environment'])
        match = not rust['timed_out'] and rust['exit_code'] == old['java']['exit_code']
        match = match and all((directory / f'java.{channel}.bin').read_bytes() ==
                              (directory / f'rust.{channel}.bin').read_bytes()
                              for channel in ['stdout', 'stderr'])
        results.append({'id': identifier, 'raw_equal': match, 'rust': rust,
                        'java_origin': str((baseline / 'cases' / identifier).relative_to(ROOT)),
                        'baseline_raw_equal': old['status'] == 'pass'})
report = {'scope': 'All Stage 35 selected cases; full raw status/stdout/stderr comparison without exceptions.',
          'candidate_origin': str(origin.relative_to(ROOT)), 'candidate_sha256': sha(binary),
          'java_reports': reports, 'sources': sources, 'results': results,
          'source_stability': all(sha(ROOT / p) == value for p, value in sources.items()),
          'artifact_stability': sha(origin) == sha(binary)}
assert len(results) == len({row['id'] for row in results}) == 105
(output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(f"Focused comparisons: {sum(row['raw_equal'] for row in results)}/{len(results)} exact")
sys.exit(0 if all(row['raw_equal'] for row in results) else 1)
