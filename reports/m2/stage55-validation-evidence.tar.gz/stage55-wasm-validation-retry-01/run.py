from pathlib import Path
import subprocess,os,json,hashlib,datetime
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage55-wasm-validation-retry-01';PRIOR=ROOT/'target/m2/stage55-rust-validation-01'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=json.loads((PRIOR/'sources.json').read_bytes())
before=[name for name,row in manifest.items() if sha(ROOT/name)!=row['sha256']];assert not before,before
original=json.loads((PRIOR/'report.json').read_bytes());assert original['complete'] and original['changed_sources']==[]
assert [row['exit_code'] for row in original['commands']]==[0,0,0,0,101]
env=os.environ.copy();env['CARGO_INCREMENTAL']='0';env['PYTHONDONTWRITEBYTECODE']='1'
command=['cargo','check','-p','pkl-runtime','--target','wasm32-unknown-unknown','--locked']
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT/'stdout.bin').open('xb') as stdout,(OUT/'stderr.bin').open('xb') as stderr:r=subprocess.run(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
after=[name for name,row in manifest.items() if sha(ROOT/name)!=row['sha256']]
report={'scope':'Retry only the required Wasm check after documented local disk exhaustion. Four passed prior checks are retained, not rerun or relabelled.','command':command,'exit_code':r.returncode,'started_at':start,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'original_report_sha256':sha(PRIOR/'report.json'),'original_source_manifest_sha256':sha(PRIOR/'sources.json'),'source_count':len(manifest),'changed_before':before,'changed_after':after,'reused_passed_checks':[row['name'] for row in original['commands'][:4]],'original_failed_check_preserved':True}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
raise SystemExit(r.returncode or bool(after))
