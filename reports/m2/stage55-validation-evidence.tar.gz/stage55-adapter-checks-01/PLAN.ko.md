# Stage55 frame transformer adapter 구현·확인

공통 engine의 별도 transform-frame continuation을 native probe·N-API·Wasm development transport로 전달합니다. `SourceFrame`은 원래 URI·nullable member·sourceLines·네 위치를 모두 가지며 문자열은 owned UTF-16 units입니다. `completeFrameTransform(token, frame|null, failureUnits|null, now)`는 결과 또는 실패 하나만 받아 공통 session에 전달하고, logger의 `acknowledgeLog`는 별도 단계입니다. `setFrameTransformer`는 default/identity/host를 선택하며 기존 constructor bool mapping은 유지합니다.

새 `frame-transformer-session.mjs`는 실제 module evaluator·실제 stage별 callback·reentry·실패 acknowledgment를 실행하는 transport입니다. Java status/exception class나 expected 결과를 합성하지 않습니다. default/builtin-identity는 실제 engine policy, observed identity/full/numbered는 Host callback을 사용합니다. 각 stage callback은 reentry 전 used를 게시하고 throw-once는 Java source처럼 callback 후 남은 consumed 상태를 검사하므로 nested callback이 먼저 실패를 소비할 수 있습니다.

새 capture driver는 case/repetition마다 새 Node child 또는 새 browser context/page/Wasm instance를 사용합니다. fixture/runtime/artifact/source의 before/after hash와 파일 집합·실제 process 상태·원시 채널을 보존합니다. Java 주 fixture의 operation expression만 실행하며 별도 Java TestResults buffer 관찰을 가짜 expression으로 대체하지 않습니다.

26개 JS transport/acquisition 회귀가 통과했습니다. 원시 stdout/stderr·명령·7개 소스의 전후 해시는 `js.json`에 있습니다. 이는 mock 기반 transport 검증이며 Java 차등 호환성 결과가 아닙니다. `CARGO_INCREMENTAL=0 cargo check -p pkl-napi -p pkl-wasm -p pkl-runtime --lib --example frame_transformer_fixture_probe --locked`가 exit0으로 bindings·공통 runtime·root native example을 compile했습니다. 최종 source에서 같은 JS 26개 회귀도 다시 통과했고 `js-final02.json`에 별도 보존했습니다. owned Rust fmt/check·diff check와 capture driver syntax check가 통과합니다. heavy platform build나 실제 candidate capture는 아직 실행하지 않았습니다.

기존 development 위치 transport와 같이 좌표는 u32 범위로 검증합니다. 이는 전체 frame 필드·UTF-16을 보존하는 bounded experiment이며 임의 signed Java StackFrame 인자 전체·제품 API 완료를 주장하지 않습니다.
