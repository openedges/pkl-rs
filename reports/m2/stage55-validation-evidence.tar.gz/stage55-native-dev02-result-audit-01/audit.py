from pathlib import Path
import sys,json,hashlib,re,tarfile,collections,datetime
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;BASE=ROOT/'target/m2/stage55-native-dev-02'
sys.path.insert(0,str(ROOT/'tools'))
# An evidence audit must not execute any guest or helper process.
def prohibit(event,args):
 if event=='subprocess.Popen':raise RuntimeError('Guest/process execution forbidden during read-only audit')
sys.addaudithook(prohibit)
import frame_transformer_compare as compare
import frame_transformer_fixtures as fixtures
sha=lambda b:hashlib.sha256(b).hexdigest()
report_bytes=(BASE/'report.json').read_bytes();report=json.loads(report_bytes)
verified=compare.verify_report(BASE);assert verified==report
assert report['requested_targets']==['native'] and report['status']=='failed' and report['strict_main_comparison_passed'] is False
assert not report['source_changes'] and not report['artifact_changes'] and not report['infrastructure_errors'] and not report['portable_issues'] and not report['layout_issues']
manifest=json.loads((BASE/'fixture/cases.json').read_bytes());assert len(manifest['cases'])==48 and manifest['repetitions']==2
archive=BASE/'fixture/oracle-evidence.tar.gz';assert sha(archive.read_bytes())==fixtures.AUTHORITY_SHA256=='53efa9f779095d54fb2fa3345bab0d01e4bc4ddfa707f45c2b3223c63b6606dc'
expected_by_pair={}
with tarfile.open(archive) as stream:
 for m in stream:
  parts=m.name.split('/')
  if len(parts)>=5 and parts[:2]==['main','cases']:
   pair=(parts[2],int(parts[3]));relative='/'.join(parts[4:])
   if relative=='process/stdout.bin':expected_by_pair.setdefault(pair,{})['protocol.bin']=stream.extractfile(m).read()
   elif len(parts)==5 and relative.endswith('.bin'):expected_by_pair.setdefault(pair,{})[relative]=stream.extractfile(m).read()
rows=[];nonpasses=[];statuses=collections.Counter();frame_channel_count=0;call_count=0
call=re.compile(r'(?:outer-\d+|transform-callback-\d+|log-callback-\d+)')
allowed_difference=re.compile(call.pattern+r'\.(?:status|stderr|stderr\.code-units)\.bin\Z')
for case in manifest['cases']:
 for repeat in [0,1]:
  pair=(case['id'],repeat);directory=BASE/'native'/case['id']/str(repeat);raw=expected_by_pair[pair]
  java_provenance={n:b for n,b in raw.items() if n.endswith('.error-class.bin')};expected={n:b for n,b in raw.items() if not n.endswith('.error-class.bin')}
  candidate_all={p.name:p.read_bytes() for p in directory.glob('*.bin')};metadata={n:b for n,b in candidate_all.items() if compare.META.fullmatch(n)};actual={n:b for n,b in candidate_all.items() if n not in metadata}
  expected_status={n[:-len('.status.bin')]:b for n,b in expected.items() if n.endswith('.status.bin')};actual_status={n[:-len('.status.bin')]:b for n,b in actual.items() if n.endswith('.status.bin')};call_count+=len(actual_status)
  for name in metadata:
   prefix=name.rsplit('.',2)[0];assert prefix in expected_status and prefix in actual_status
  expected_frames={n:b for n,b in expected.items() if n.startswith(('transform-','log-')) and not call.match(n.split('.')[0])}
  actual_frames={n:b for n,b in actual.items() if n.startswith(('transform-','log-')) and not call.match(n.split('.')[0])}
  assert set(expected_frames)==set(actual_frames),(pair,'frame filename coverage')
  assert expected_frames==actual_frames,(pair,'frame/logger bytes differ');frame_channel_count+=len(actual_frames)
  comparison_names=sorted(expected.keys()|actual.keys());differences=[n for n in comparison_names if expected.get(n)!=actual.get(n)]
  row=next(r for r in report['targets']['native']['rows'] if r['id']==case['id'] and r['repeat']==repeat);statuses[row['status']]+=1
  if row['status']=='pass':assert expected==actual,(pair,'ordinary session differs')
  else:
   assert row['status'] in {'oracle-error','api-exception'}
   assert differences and all(n=='protocol.bin' or allowed_difference.fullmatch(n) for n in differences),(pair,differences)
   nonpasses.append({'id':case['id'],'repeat':repeat,'status':row['status'],'nonpass_reasons':row['nonpass_reasons'],'different_public_channels':differences,'expected_statuses':{n:b.decode() for n,b in expected_status.items()},'actual_statuses':{n:b.decode() for n,b in actual_status.items()},'java_error_classes':{n:b.decode() for n,b in java_provenance.items()}})
  assert (directory/'protocol.bin').read_bytes()==(directory/'process/stdout.bin').read_bytes()
  rows.append({'id':case['id'],'repeat':repeat,'status':row['status'],'transform_logger_exact_filename_coverage':True,'transform_logger_raw_equal':True,'transform_logger_channel_count':len(actual_frames),'all_public_channel_count_java':len(expected),'all_public_channel_count_candidate':len(actual),'different_public_channels':differences,'channels':{n:{'java_sha256':None if n not in expected else sha(expected[n]),'candidate_sha256':None if n not in actual else sha(actual[n]),'java_bytes':None if n not in expected else len(expected[n]),'candidate_bytes':None if n not in actual else len(actual[n]),'raw_equal':expected.get(n)==actual.get(n)} for n in comparison_names}})
assert len(rows)==96 and dict(statuses)=={'api-exception':4,'pass':82,'oracle-error':10}
assert len(nonpasses)==14 and all(r['transform_logger_raw_equal'] for r in rows)
source_count=len(report['sources_before']);assert report['sources_before']==report['sources_after']
for name,h in report['sources_before'].items():assert sha((BASE/'sources'/name).read_bytes())==h
artifact=report['artifacts']['native'];assert len({artifact[k] for k in ['origin_before','origin_after','frozen_before','frozen_after']})==1
frozen=BASE/'artifacts/frame_transformer_fixture_probe';assert sha(frozen.read_bytes())==artifact['frozen_before']
build_root=ROOT/'target/m2/stage55-native-build-02';build=json.loads((build_root/'report.json').read_bytes());source_bytes=(build_root/'sources.json').read_bytes();build_sources=json.loads(source_bytes);assert len(build_sources)==241 and sha(source_bytes)==build['source_manifest_sha256'];assert build['exit_code']==0 and build['changed_sources']==[] and build['artifact']['sha256']==sha(frozen.read_bytes()) and build['artifact']['bytes']==frozen.stat().st_size
for name,h in build_sources.items():assert sha((build_root/'sources'/name).read_bytes())==h and report['sources_before'][name]==h
core=json.loads((ROOT/'target/m2/stage55-core-checks-02/core-freeze.json').read_bytes());assert all(report['sources_before'][name]==h for name,h in core['files'].items())
record={'schema':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent raw-file and pinned-authority audit of existing native dev02 captures. No guest/test evaluations or child processes executed. Frame/logger equality is a partial observation and is not whole-session compatibility.','candidate_report':{'path':str((BASE/'report.json').relative_to(ROOT)),'sha256':sha(report_bytes)},'java_archive_sha256':sha(archive.read_bytes()),'native_rows':len(rows),'case_count':48,'repetitions':2,'statuses':dict(statuses),'strict_main_comparison_passed':False,'full_ordinary_session_pass_rows':82,'preserved_nonpasses':nonpasses,'all96_transform_logger_channel_sets_and_bytes_equal':True,'transform_logger_channel_comparisons':frame_channel_count,'actual_public_calls':call_count,'only_nonpass_public_difference_kinds':['per-call status','per-call stderr UTF8','per-call stderr UTF16','complete protocol'],'source_snapshot_files_verified':source_count,'source_artifact_infrastructure_layout_issues':[],'native_artifact_sha256':sha(frozen.read_bytes()),'recorded_build':{'path':str((build_root/'report.json').relative_to(ROOT)),'sha256':sha((build_root/'report.json').read_bytes()),'source_files_verified':241,'source_manifest_sha256':sha(source_bytes),'exit_code':0,'profile':'debug','scope':'Existing recorded build and immutable source snapshot tied to captured native artifact; audit adds no build.'},'corrected_core_source_files_bound':50,'unrequested_targets':['napi','chromium'],'buffer_supplement':report['buffer_supplement'],'limitations':['Java internal/API exception status, complete error bytes and protocol still differ on14 rows; no normalization or status relabeling applied.','This audit does not establish NAPI/browser execution, Java TestResults buffer API parity, full M2 or performance completion.'],'rows':rows}
architecture_checks=[]
for row in rows:
 path=BASE/'native'/row['id']/str(row['repeat'])/'candidate-trace.tsv';fields={}
 for line in path.read_text().splitlines():
  key,value=line.split('\t',1);fields.setdefault(key,[]).append(value)
 for name in ['terminal-heap-slots','terminal-context-depth','polls','collections']:assert len(fields[name])==1
 assert fields['terminal-heap-slots']==['0'] and fields['terminal-context-depth']==['0']
 polls=int(fields['polls'][0]);collections=int(fields['collections'][0]);assert collections==polls+1
 architecture_checks.append({'id':row['id'],'repeat':row['repeat'],'polls':polls,'collections':collections,'terminal_heap_slots':0,'terminal_context_depth':0})
record['actual_architecture_records']=architecture_checks
record['all96_terminal_zero_and_collections_equal_polls_plus_one']=True
record['initial_core_frame_findings_resolved_in_this_selected_raw_matrix']=['Callback failures now expose enclosing member header source sections.','Trace callback failure now retains the real enclosing root; subsequent transform indices and complete frames match.']
(OUT/'audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['native_rows','statuses','strict_main_comparison_passed','transform_logger_channel_comparisons','actual_public_calls','source_snapshot_files_verified','native_artifact_sha256']}),flush=True)
