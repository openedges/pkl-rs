# Stage55 native dev02 원시 결과 독립 감사

기존 `stage55-native-dev-02`의 48개 사례 × 두 반복, 총 96개 native session을 독립 Java authority archive와 읽기 전용으로 비교했습니다. Python 감사 과정에서 모든 child process 실행을 금지했고 Java·Rust·Node·browser 평가나 build·test를 추가 실행하지 않았습니다. 원본 결과나 생산 소스는 수정하지 않았습니다.

## 확인 결과

- 고정 Java archive SHA-256 `53efa9f779095d54fb2fa3345bab0d01e4bc4ddfa707f45c2b3223c63b6606dc`와 fixture authority, report inventory·source/artifact·실제 process 계약 검증이 통과했습니다.
- 96개 session 모두 transform input/output과 logger의 전체 filename 집합·모든 `.bin` bytes가 일치합니다. message·UTF-16 code units·nullable member·source lines·위치 등을 포함한 총 4,136개 채널 비교입니다. callback이 없는 경우도 원래 빈 집합 그대로 확인했습니다.
- ordinary 82행은 이 부분 검사뿐 아니라 public stdout·stderr·status·전체 ordered protocol의 모든 bytes가 일치합니다.
- 나머지 14행은 oracle-error 10행과 API-exception 4행으로 그대로 남습니다. 이들의 차이는 실제 call의 status, stderr UTF-8/UTF-16, 전체 protocol에만 있습니다. Java class metadata는 별도로 보존하며 후보가 합성하지 않았습니다. 차이를 정규화하거나 protocol의 status를 치환하지 않았습니다.
- 따라서 strict main verdict는 **실패**입니다. 모든 frame/logger 채널이 같다는 결과는 부분 관찰이며 전체 session 호환성 통과가 아닙니다.

기존 core 검토에서 발견한 member header 위치와 trace root 누락은 이 선택된 matrix의 실제 원시 frame bytes에서 해결된 것을 확인했습니다. 첫 취득의 결함·실패와 첫 review 기록은 그대로 보존합니다.

## provenance와 수명 관찰

source snapshot 4,503개와 전후 source identity가 맞고, correction core 50개가 해당 snapshot에 결합됩니다. native debug artifact SHA-256은 `05a3293eaf05ab815724d99a6046733ea71081b55e5f498d9ad9ceb7dbe336d0`입니다. 기록된 build02의 source 241개 bytes와 source manifest, exit0 및 artifact를 별도로 확인했습니다. 이는 이미 실행된 build의 감사이며 새 build가 아닙니다.

각 session의 실제 trace는 terminal heap slots와 context depth가 모두 0이고 collections가 polls보다 정확히 1 많습니다. 총 public call은 nested callback을 포함해 180개이며 session 96개와 구별합니다. source·artifact·infrastructure·layout 문제는 없습니다.

N-API와 Chromium은 이 취득에서 요청되지 않았습니다. Java-only evaluateTest buffer supplement도 후보에서 미실행 상태를 유지합니다. 남은 exception object/class·API 전달, 전체 M2, 성능·장기 메모리와 릴리스 플랫폼 의무는 이 부분 raw 일치로 닫히지 않습니다.
