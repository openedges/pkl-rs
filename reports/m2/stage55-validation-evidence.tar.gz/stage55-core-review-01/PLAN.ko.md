# Stage55 공통 frame transformer 구현 독립 검토

공통 core의 첫 고정본 50개 파일과 수정 고정본을 pinned Java 0.32.0 소스에 맞춰 읽기 전용으로 검토했습니다. 생산 소스는 수정하지 않았고 Java·Rust·Node·browser 평가나 검사를 추가 실행하지 않았습니다. 실제 root가 만든 native dev01 결과의 nonpass 14행은 Java archive의 전체 transform input/output 채널과 별도로 읽어 비교했습니다.

## 실제 확인한 초기 결함과 수정

첫 고정본은 `f794e25b8290d66a9e6fd51c83f07c6c25b6c7ad7486df1290fdb8b00646c199`입니다. 검토 시작 시 현재 50개 소스가 일치했고, 이후 불변 native dev01 source snapshot의 동일한 50개 bytes도 확인했습니다.

첫 결함은 transformer/logger가 던진 외부 예외의 위치였습니다. Java `PklRootNode.execute`는 virtual `exceptionBuilder()`를 호출하고, `MemberNode`는 `getHeaderSection()`을 지정합니다. 그래서 Java `retained`의 진단 위치는 `4:1:4:20`인 반면 후보는 `old(x)`의 `4:24:4:29`였습니다. 두 번째 결함은 trace의 `deep_force` 상태가 실제 호출자 frame에 있는데 `hides_callsite()`가 그 frame 전체를 숨겨 `traceThenFail` header가 빠진 문제였습니다. Java internal-error 표시는 이 공개 frame 차이를 무시할 근거가 아닙니다.

모든 nonpass 14행의 transform input/output 전체 `.bin`을 읽은 결과, oracle-error 10행 모두 frame 차이가 있었습니다. API-exception 4행은 transform 채널이 같았지만 status·error·protocol 차이는 그대로 남았습니다. 원시 hash·byte 수·hex와 원래 report/archive 결합은 `native-dev01-frame-differences.json`에 보존했습니다. frame 부분 일치를 전체 호환성 통과로 계산하지 않았습니다.

수정 고정본은 `e7d8e375875d5a6ce4900c80152a49f81632cf1897e5af9d84a900735dd0a9c7`입니다. 50개 소스가 모두 일치했고 첫 고정본과 다른 파일은 `vm.rs`, `vm/session_expressions.rs`, `vm/frame_transformation/tests.rs` 세 개뿐입니다. typed `LogTransformer`/`LogDelegate` 실패에 한정하여 실제 root의 declaration 위치를 쓰고, root 위 helper frame을 제외하며, trace root는 유지하는 변경입니다. 외부 예외가 root에서 bug 예외로 변환되기 전 root-local let frame을 만들지 않는 동작도 Java와 맞습니다. 기존 guest error와 suspended caller 필터는 그대로입니다. query root와 pinned `Reference.toString`의 declaration 위치도 실제 소스에서 가져옵니다. 새 정적 blocker를 찾지 못했으며, 수정의 실제 bytes 확인은 root의 새 native 취득이 필요합니다.

## 나머지 core 검토

- raw 표준 모듈 URI와 default 표시 URI를 구별하고, 변환은 각 공개 사용 시점에 적용합니다. raw 압축은 URI·UTF-16 member·전체 source lines·위치를 비교한 뒤 수행합니다.
- logger buffer append, transformer, delegate, 성공한 warning target publish 순서를 유지합니다. noop sink도 custom transformer를 호출하며, 실패한 바깥 callback이 중첩 호출의 성공한 cache publication을 되돌리지 않습니다.
- 변환된 진단 frame은 source line 없음과 음수 반복 수를 다음 callback 전에 확인합니다. 진단 문자열·member·URI의 UTF-16 units를 보존합니다.
- pending warning의 owner·target·saved chain roots는 active/suspended frame에 남고, diagnostic continuation은 heap 값이 아닌 분리된 text/위치를 보유합니다. token은 context·request·단계에 속하며 stale/wrong-stage completion을 거절합니다.
- callback close는 새 호출을 거절하고 이미 발급된 continuation을 마치게 합니다. cancel·deadline의 terminal 정리와 completion 거절 경로를 소스로 확인했습니다. 실제 Java close/API 예외 동등성은 별도 미완료 범위입니다.
- typed callback origin은 실제 producer를 표시하며 Java class나 expected 결과를 만들지 않습니다. 외부 예외 object/class·API 전달이 완성된 것으로 주장하지 않습니다.

기존 test 변경에서도 terminal zero, root, cache-count 또는 ordinary error assertion을 약화한 부분은 찾지 못했습니다. 대부분 source field 제거와 enum의 새 fail-closed match입니다. noop transformer가 더 이상 combined LogEvent가 아니므로 message/level assertion 두 곳이 사라졌지만 frame snapshot·terminal 정리는 유지되며 새 단계별 buffer/delegate/publication 회귀가 이를 구별하여 검사합니다.

## 남은 회귀 경계

현재 관찰된 결함의 새 raw 취득을 우선 확인해야 합니다. 그 뒤 transformer 단계의 서로 다른 class·포화/ABA reentry와, cached module 실패를 Default/Identity/Host 사이에서 다시 표시하는 회귀가 필요합니다. diagnostic transformer 재진입에서 pending read와 close/cancel/timeout을 결합한 경계도 log-transform 경로만큼 직접 다루지 않았습니다. eager constructor 진단, package/service-provider default 변환, 외부 예외 API, shared runtime domain과 기존 full M2 미완료 요구사항은 유지합니다.
