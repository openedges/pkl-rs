from pathlib import Path
import datetime
import hashlib
import json
import os
import platform
import subprocess
import sys

ROOT = Path.cwd()
OUT = ROOT / 'target/m2/stage55-rust-validation-01'
sys.path.insert(0, str(ROOT / 'tools'))
import m2_source_inputs

def sha(data):
    return hashlib.sha256(data).hexdigest()

def put(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

def git(*args, cwd=ROOT):
    return subprocess.check_output(['git', *args], cwd=cwd)

def tree(directory, commit):
    result = {}
    for entry in git('ls-tree', '-rz', commit, cwd=directory).split(b'\0'):
        if entry:
            head, path = entry.split(b'\t', 1)
            mode, kind, oid = head.decode().split()
            result[path.decode()] = (mode, kind, oid)
    return result

def paths():
    names = set(m2_source_inputs.source_paths(ROOT))
    names.update(['AGENTS.md', 'README.md', 'TESTING.md', 'PLAN.md', '.gitmodules'])
    names.update(path.relative_to(ROOT).as_posix() for path in (ROOT / 'tests/fixtures').rglob('*') if path.is_file())
    names.update(path.relative_to(ROOT).as_posix() for path in (ROOT / 'docs').rglob('*.md') if path.is_file())
    return sorted(names)

assert not (OUT / 'report.json').exists()
assert git('rev-parse', '--show-object-format').decode().strip() == 'sha1'
base = git('rev-parse', 'HEAD').decode().strip()
project_tree = tree(ROOT, base)
references = {}
for name in ['external/pkl', 'external/pkl-pantry']:
    mode, kind, oid = project_tree[name]
    assert mode == '160000' and kind == 'commit'
    references[name] = (oid, tree(ROOT / name, oid))
sources = {}
copied = 0
for name in paths():
    source = ROOT / name
    assert source.is_file() and not source.is_symlink(), name
    data = source.read_bytes()
    oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    repository, revision, git_path, entries = '.', base, name, project_tree
    for prefix, (commit, ref_tree) in references.items():
        if name.startswith(prefix + '/'):
            repository, revision, git_path, entries = prefix, commit, name[len(prefix) + 1:], ref_tree
            break
    entry = entries.get(git_path)
    if entry is not None and entry[1:] == ('blob', oid):
        origin = dict(kind='git-blob', repository=repository, commit=revision, path=git_path, oid=oid)
    else:
        destination = OUT / 'sources' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        copied += 1
        origin = dict(kind='captured-file', path='sources/' + name)
    sources[name] = dict(sha256=sha(data), bytes=len(data), origin=origin)
put('sources.json', sources)
report = dict(scope='Required local Rust checks with exact reconstructible input identities; no compatibility or performance claim.',
    host=dict(platform=platform.platform(), uname=dict(platform.uname()._asdict())), cwd=str(ROOT),
    base_commit=base, gitlinks={name: value[0] for name, value in references.items()},
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_count=len(sources), copied_source_files=copied,
    git_referenced_source_files=len(sources) - copied,
    source_manifest_sha256=sha((OUT / 'sources.json').read_bytes()),
    input_policy='Every input was read and SHA-256 hashed. Unchanged bytes were independently matched to Git blob framing and actual committed tree OIDs; changed/untracked bytes are copied. Reconstruct Git-backed inputs from the recorded reachable base/gitlink commits, then verify their SHA-256. No original evidence is deleted.',
    environment_overrides={'CARGO_INCREMENTAL': '0', 'PYTHONDONTWRITEBYTECODE': '1'},
    commands=[], complete=False)
put('report.json', report)
environment = os.environ.copy()
environment.update(report['environment_overrides'])
commands = [
    ('references', ['cargo', 'xtask', 'verify']),
    ('format', ['cargo', 'fmt', '--all', '--', '--check']),
    ('clippy', ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings']),
    ('workspace-tests', ['cargo', 'test', '--workspace', '--locked']),
    ('wasm-runtime', ['cargo', 'check', '-p', 'pkl-runtime', '--target', 'wasm32-unknown-unknown', '--locked']),
]
for name, command in commands:
    entry = dict(name=name, command=command, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
    print('START', name, flush=True)
    with (OUT / (name + '.stdout.bin')).open('xb') as stdout, (OUT / (name + '.stderr.bin')).open('xb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
        put('active.json', dict(name=name, command=command, pid=process.pid))
        entry['exit_code'] = process.wait()
    entry['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    entry['stdout_sha256'] = sha((OUT / (name + '.stdout.bin')).read_bytes())
    entry['stderr_sha256'] = sha((OUT / (name + '.stderr.bin')).read_bytes())
    report['commands'].append(entry)
    put('report.json', report)
    print('FINISH', name, entry['exit_code'], flush=True)
after = set(paths())
changed = []
for name in sorted(set(sources) | set(after)):
    if name not in sources or name not in after or sha((ROOT / name).read_bytes()) != sources[name]['sha256']:
        changed.append(name)
report.update(complete=True, changed_sources=changed, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
put('report.json', report)
print(json.dumps(dict(complete=True, exits=[row['exit_code'] for row in report['commands']], changed_sources=changed,
    source_count=len(sources), copied_source_files=copied)), flush=True)
raise SystemExit(bool(changed) or any(row['exit_code'] for row in report['commands']))
