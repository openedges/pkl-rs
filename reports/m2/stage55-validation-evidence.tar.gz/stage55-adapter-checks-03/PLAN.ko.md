# Stage55 callback origin adapter 후속 확인

공통 RuntimeError의 typed provenance getter를 SourceEvent.callback_origin와 JS callbackOrigin으로 전달합니다. 값은 log-transformer/log-delegate/diagnostic-transformer/diagnostic-renderer 네 가지 또는 없음입니다. 기존 event kind·disposition·원시 메시지·UTF-16 frame은 바꾸지 않았습니다. 새 frame helper는 실제 call의 callback-origin.bin candidate metadata만 추가하며 Java class를 만들지 않습니다.

첫 후속 compile02는 N-API 새 field가 앞선 다른 struct에 들어간 편집 오류를 검출해 exit101이었고 원본을 보존했습니다. SourceEvent에 field를 옮긴 새 compile03은 exit0, runtime/NAPI/Wasm/root native example 여섯 소스가 전후 동일했습니다. 최종 28개 JS transport·acquisition mock test도 exit0이며 네 typed origin과 surrogate 오류 메시지 보존·성공 호출에서 origin 없음·알 수 없는 origin 거절 회귀를 포함합니다. owned Rust fmt·diff check와 JS syntax를 확인합니다.

이는 bounded transport 검증이며 Java raw 비교·실제 browser/Node 취득·전체 API 예외 전달 완료를 주장하지 않습니다. 기존 freeze01과 실패02는 수정하지 않았습니다.
