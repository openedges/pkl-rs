from pathlib import Path
import json,hashlib,tarfile,re,collections,sys,datetime
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent;BASE=ROOT/'target/m2/stage55-frame-final-01'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def record(p):return {'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
sys.path.insert(0,str(ROOT/'tools'));import frame_transformer_compare as compare;import frame_transformer_fixtures as fixtures
report=read(BASE/'report.json');manifest=read(BASE/'fixture/cases.json');assert len(manifest['cases'])==48 and manifest['repetitions']==2 and report['requested_targets']==['native','napi','chromium']
assert report['status']=='failed' and report['strict_main_comparison_passed'] is False
for key in ['source_changes','artifact_changes','infrastructure_errors','portable_issues','layout_issues']:assert report[key]==[]
archive=BASE/'fixture/oracle-evidence.tar.gz';assert sha(archive.read_bytes())==fixtures.AUTHORITY_SHA256=='53efa9f779095d54fb2fa3345bab0d01e4bc4ddfa707f45c2b3223c63b6606dc'
expected={}
with tarfile.open(archive) as stream:
 for m in stream:
  p=m.name.split('/')
  if len(p)>=5 and p[:2]==['main','cases']:
   key=(p[2],int(p[3]));name='/'.join(p[4:])
   if name=='process/stdout.bin':expected.setdefault(key,{})['protocol.bin']=stream.extractfile(m).read()
   elif len(p)==5 and name.endswith('.bin'):expected.setdefault(key,{})[name]=stream.extractfile(m).read()
call=re.compile(r'(?:outer-\d+|transform-callback-\d+|log-callback-\d+)\Z');allowed_diff=re.compile(r'(?:outer-\d+|transform-callback-\d+|log-callback-\d+)\.(?:status|stderr|stderr\.code-units)\.bin\Z')
rows=[];nonpasses=[];targets={};counts=collections.Counter();frame_count=0;public_calls=0
for target in ['native','napi','chromium']:
 target_counts=collections.Counter();calls=0;channels=0
 for case in manifest['cases']:
  for repeat in [0,1]:
   directory=BASE/('native' if target=='native' else 'portable/'+target)/case['id']/str(repeat)
   java_all=expected[(case['id'],repeat)];java={n:b for n,b in java_all.items() if not n.endswith('.error-class.bin')};java_meta={n:b for n,b in java_all.items() if n.endswith('.error-class.bin')}
   candidate_all={p.name:p.read_bytes() for p in directory.glob('*.bin')};meta={n:b for n,b in candidate_all.items() if compare.META.fullmatch(n) or target=='napi' and n in {'process.stdout.bin','process.stderr.bin'}};actual={n:b for n,b in candidate_all.items() if n not in meta}
   js={n.removesuffix('.status.bin'):b for n,b in java.items() if n.endswith('.status.bin')};cs={n.removesuffix('.status.bin'):b for n,b in actual.items() if n.endswith('.status.bin')};calls+=len(cs)
   for name in meta:
    if compare.META.fullmatch(name):assert name.rsplit('.',2)[0] in cs and name.rsplit('.',2)[0] in js
   jf={n:b for n,b in java.items() if n.startswith(('transform-','log-')) and not call.fullmatch(n.split('.')[0])};cf={n:b for n,b in actual.items() if n.startswith(('transform-','log-')) and not call.fullmatch(n.split('.')[0])}
   assert set(jf)==set(cf) and jf==cf,(target,case['id'],repeat,'frame/logger mismatch');channels+=len(cf)
   differences=[n for n in sorted(java.keys()|actual.keys()) if java.get(n)!=actual.get(n)]
   row=next(r for r in report['targets'][target]['rows'] if r['id']==case['id'] and r['repeat']==repeat);target_counts[row['status']]+=1
   if row['status']=='pass':assert java==actual
   else:
    assert row['status'] in {'oracle-error','api-exception'} and differences and all(n=='protocol.bin' or allowed_diff.fullmatch(n) for n in differences)
    nonpasses.append({'target':target,'id':case['id'],'repeat':repeat,'status':row['status'],'nonpass_reasons':row['nonpass_reasons'],'different_public_channels':differences,'java_statuses':{n:b.decode() for n,b in js.items()},'candidate_statuses':{n:b.decode() for n,b in cs.items()},'java_exception_classes':{n:b.decode() for n,b in java_meta.items()}})
   if target=='native':
    assert (directory/'protocol.bin').read_bytes()==(directory/'process/stdout.bin').read_bytes();fields={}
    for line in (directory/'candidate-trace.tsv').read_text().splitlines():
     key,value=line.split('\t',1);fields.setdefault(key,[]).append(value)
    for name in ['polls','collections','terminal-heap-slots','terminal-context-depth']:assert len(fields[name])==1
    polls=int(fields['polls'][0]);collection_count=int(fields['collections'][0]);assert fields['terminal-heap-slots']==fields['terminal-context-depth']==['0']
    architecture={'polls':polls,'collections':collection_count,'terminalSlots':0,'terminalDepth':0}
   else:
    trace=read(directory/'candidate-trace.json');architecture=trace['architecture'];assert trace['acquisitionError'] is None and architecture['retainedPayloadsStable'] is True and architecture['terminalSlots']==architecture['terminalDepth']==0
   assert architecture['collections']==architecture['polls']+1
   rows.append({'target':target,'id':case['id'],'repeat':repeat,'status':row['status'],'transform_logger_exact_coverage_and_raw_equal':True,'transform_logger_channels':len(cf),'different_public_channels':differences,'architecture':architecture,'channels':{n:{'java_sha256':None if n not in java else sha(java[n]),'candidate_sha256':None if n not in actual else sha(actual[n]),'java_bytes':None if n not in java else len(java[n]),'candidate_bytes':None if n not in actual else len(actual[n]),'raw_equal':java.get(n)==actual.get(n)} for n in sorted(java.keys()|actual.keys())}})
 assert target_counts=={'pass':82,'oracle-error':10,'api-exception':4};counts.update(target_counts);frame_count+=channels;public_calls+=calls;targets[target]={'rows':96,'statuses':dict(target_counts),'public_calls':calls,'frame_logger_channel_comparisons':channels}
assert len(rows)==288 and len(nonpasses)==42 and counts=={'pass':246,'oracle-error':30,'api-exception':12}
assert report['sources_before']==report['sources_after']
for name,h in report['sources_before'].items():assert sha((BASE/'sources'/name).read_bytes())==h
platform_base=ROOT/'target/m2/stage55-platform-run-02';platform=read(platform_base/'report.json');platform_sources=read(platform_base/'sources.json');m1_base=ROOT/'target/m2/stage55-platforms-02';m1=read(m1_base/'report.json')
for name,h in platform_sources.items():
 if name in report['sources_before']:assert report['sources_before'][name]==h
 else:assert name=='tools/m1_platforms.py' and m1['source_hashes'][name]==h and sha((m1_base/'sources'/name).read_bytes())==h
artifact_rows={}
for name,r in report['artifacts'].items():
 assert len({r[k] for k in ['origin_before','frozen_before','origin_after','frozen_after']})==1 and r['admission_error'] is None
 relative=Path(r['frozen']).relative_to(report['output_directory']);frozen=BASE/relative;assert sha(frozen.read_bytes())==r['frozen_after']
 expected_hash=platform['native_artifact']['sha256'] if name=='native' else m1['artifacts']['pkl_napi.node' if name=='napi' else name]
 assert r['frozen_after']==expected_hash
 artifact_rows[name]={'sha256':expected_hash,'bytes':frozen.stat().st_size,'recorded_origin':r['origin'],'frozen_relative':str(relative)}
assert set(artifact_rows)=={'native','napi','wasm/pkl_wasm.js','wasm/pkl_wasm.d.ts','wasm/pkl_wasm_bg.wasm','wasm/pkl_wasm_bg.wasm.d.ts'}
core=read(ROOT/'target/m2/stage55-core-checks-02/core-freeze.json');assert all(report['sources_before'][n]==h for n,h in core['files'].items())
validation=read(OUT/'validation-audit.json');rust_manifest=read(ROOT/'target/m2/stage55-rust-validation-01/sources.json');shared={n for n in report['sources_before'] if n in rust_manifest};assert all(report['sources_before'][n]==rust_manifest[n]['sha256'] for n in shared)
portable=read(BASE/'portable/report.json');assert portable['complete'] is True
result={'schema':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Independent direct raw-file comparison of completed root-owned captures against pinned Java authority. No evaluator/test runs, no source edits, no large closure copies. Frame/logger equality is partial and is not whole-session compatibility.','report_sha256':sha((BASE/'report.json').read_bytes()),'java_archive_sha256':sha(archive.read_bytes()),'targets':targets,'rows_total':288,'aggregate_statuses':dict(counts),'strict_main_comparison_passed':False,'full_ordinary_session_raw_pass_rows':246,'preserved_nonpasses':nonpasses,'all288_frame_logger_filename_sets_and_bytes_equal':True,'frame_logger_channel_comparisons':frame_count,'public_calls':public_calls,'remaining_public_difference_scope':['per-call status','per-call stderr UTF8','per-call stderr UTF16','complete ordered protocol'],'all_terminal_zero_and_poll_collection_cadence_verified':True,'portable_owned_payloads_stable_sessions':192,'source_files_verified':len(report['sources_before']),'corrected_core_files_bound':50,'required_rust_manifest_common_paths_bound':len(shared),'platform_wrapper_inputs_bound':242,'artifacts':artifact_rows,'isolation':{'native':'96 separate recorded native process invocations','napi':'96 fresh Node child invocations; child argv/runtime identity admitted by offline verifier; OS PIDs not recorded','chromium':'96 new contexts/pages/Wasm instances within one headless browser launch, not 96 browser OS processes'},'portable_report_sha256':sha((BASE/'portable/report.json').read_bytes()),'node_runtime':portable['node'],'browser_runtime':portable['browser'],'buffer_supplement':report['buffer_supplement'],'source_artifact_infrastructure_layout_issues':[],'rows':rows,'blockers':[]}
(OUT/'raw-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['rows_total','aggregate_statuses','strict_main_comparison_passed','frame_logger_channel_comparisons','public_calls','source_files_verified','required_rust_manifest_common_paths_bound']}),flush=True)
