from pathlib import Path
import json,hashlib,subprocess,collections,threading,re,sys,datetime
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def file(p):return {'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def tree(repo,commit):
 data=subprocess.check_output(['git','ls-tree','-rz',commit],cwd=ROOT/repo if repo!='.' else ROOT);result={}
 for item in data.split(b'\0'):
  if item:
   head,path=item.split(b'\t',1);mode,kind,oid=head.decode().split();result[path.decode()]=(mode,kind,oid)
 return result
base=ROOT/'target/m2/stage55-rust-validation-01';report=read(base/'report.json');manifest_data=(base/'sources.json').read_bytes();manifest=json.loads(manifest_data)
assert sha(manifest_data)==report['source_manifest_sha256'] and len(manifest)==report['source_count']==163100
assert report['complete'] is True and report['changed_sources']==[]
project=tree('.',report['base_commit']);trees={'.':project};commits={'.':report['base_commit']}
for repo,commit in report['gitlinks'].items():assert project[repo]==('160000','commit',commit);trees[repo]=tree(repo,commit);commits[repo]=commit
by_repo=collections.defaultdict(dict);copied=[];source_sha={};source_bytes={}
for path,row in manifest.items():
 assert not Path(path).is_absolute() and '..' not in Path(path).parts
 assert type(row['bytes']) is int and row['bytes']>=0 and re.fullmatch('[0-9a-f]{64}',row['sha256'])
 source_sha[path]=row['sha256'];source_bytes[path]=row['bytes'];origin=row['origin']
 if origin['kind']=='captured-file':
  assert origin['path']=='sources/'+path;p=base/origin['path'];assert file(p)=={'sha256':row['sha256'],'bytes':row['bytes']};copied.append(path)
 else:
  assert origin['kind']=='git-blob';repo=next((r for r in report['gitlinks'] if path.startswith(r+'/')),'.');git_path=path if repo=='.' else path[len(repo)+1:]
  assert origin['repository']==repo and origin['commit']==commits[repo] and origin['path']==git_path
  entry=trees[repo][git_path];assert entry[1]=='blob' and entry[2]==origin['oid'] and re.fullmatch('[0-9a-f]{40}',origin['oid'])
  previous=by_repo[repo].setdefault(origin['oid'],(row['sha256'],row['bytes']));assert previous==(row['sha256'],row['bytes'])
assert len(copied)==report['copied_source_files']==63 and len(manifest)-len(copied)==report['git_referenced_source_files']==163037
assert {p.relative_to(base/'sources').as_posix() for p in (base/'sources').rglob('*') if p.is_file()}==set(copied)
# Read Git blob objects once per identity and hash their actual bytes in a stream.
object_records={}
for repo,objects in by_repo.items():
 command=['git','cat-file','--batch'];proc=subprocess.Popen(command,cwd=ROOT if repo=='.' else ROOT/repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 ids=sorted(objects);writer_errors=[]
 def send():
  try:
   for oid in ids:proc.stdin.write((oid+'\n').encode())
   proc.stdin.close()
  except Exception as error:writer_errors.append(str(error))
 writer=threading.Thread(target=send);writer.start();total=0
 for oid in ids:
  head=proc.stdout.readline().decode().strip().split();assert len(head)==3 and head[0]==oid and head[1]=='blob',head
  size=int(head[2]);expected_sha,expected_size=objects[oid];assert size==expected_size
  h=hashlib.sha256();g=hashlib.sha1(b'blob '+str(size).encode()+b'\0');remaining=size
  while remaining:
   chunk=proc.stdout.read(min(1048576,remaining));assert chunk;remaining-=len(chunk);h.update(chunk);g.update(chunk)
  assert proc.stdout.read(1)==b'\n' and h.hexdigest()==expected_sha and g.hexdigest()==oid
  total+=size
 writer.join();stderr=proc.stderr.read();assert proc.wait()==0 and not stderr and not writer_errors
 object_records[repo]={'unique_blob_objects_verified':len(ids),'unique_blob_bytes_streamed':total,'commit':commits[repo]}
 print('Git byte verification complete',repo,len(ids),flush=True)
sys.path.insert(0,str(ROOT/'tools'));import m2_source_inputs
expected_names=set(m2_source_inputs.source_paths(ROOT))|{'AGENTS.md','README.md','TESTING.md','PLAN.md','.gitmodules'}
expected_names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'tests/fixtures').rglob('*') if p.is_file());expected_names.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'docs').rglob('*.md') if p.is_file());assert set(manifest)==expected_names
checks=[]
for row in report['commands']:
 for name in ['stdout','stderr']:assert sha((base/f"{row['name']}.{name}.bin").read_bytes())==row[name+'_sha256']
 checks.append({'name':row['name'],'argv':row['command'],'exit_code':row['exit_code'],'stdout':file(base/(row['name']+'.stdout.bin')),'stderr':file(base/(row['name']+'.stderr.bin'))})
assert [r['exit_code'] for r in checks]==[0,0,0,0,101]
failed=(base/'wasm-runtime.stderr.bin').read_bytes();assert b'No space left on device' in failed
text=(base/'workspace-tests.stdout.bin').read_text();summaries=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text);counts={'passed':sum(int(p) for p,_,_ in summaries),'failed':sum(int(f) for _,f,_ in summaries),'ignored':sum(int(i) for _,_,i in summaries),'harness_summaries':len(summaries)};assert counts==read(base/'harness-summary.json')=={'passed':895,'failed':0,'ignored':1,'harness_summaries':125}
retry_base=ROOT/'target/m2/stage55-wasm-validation-retry-01';retry=read(retry_base/'report.json');assert retry['original_report_sha256']==sha((base/'report.json').read_bytes()) and retry['original_source_manifest_sha256']==sha(manifest_data) and retry['source_count']==len(manifest) and retry['changed_before']==retry['changed_after']==[] and retry['exit_code']==0 and retry['original_failed_check_preserved'] is True
assert retry['command']==checks[-1]['argv'] and retry['reused_passed_checks']==[r['name'] for r in checks[:4]]
assert b'Finished' in (retry_base/'stderr.bin').read_bytes()
tooling_base=ROOT/'target/m2/stage55-tooling-validation-01';tooling=read(tooling_base/'report.json');tooling_sources=read(tooling_base/'sources.json');assert tooling['complete'] is True and tooling['changed_sources']==[] and len(tooling_sources)==tooling['source_count']==4504 and sha((tooling_base/'sources.json').read_bytes())==tooling['source_manifest_sha256']
for name,h in tooling_sources.items():assert source_sha[name]==h
for row in tooling['commands']:
 assert row['exit_code']==0
 for name in ['stdout','stderr']:assert sha((tooling_base/f"{row['name']}.{name}.bin").read_bytes())==row[name+'_sha256']
assert len(tooling['commands'])==7
platform_base=ROOT/'target/m2/stage55-platform-run-02';platform=read(platform_base/'report.json');platform_sources=read(platform_base/'sources.json');assert platform['complete'] is True and platform['changed_sources']==[] and [r['exit_code'] for r in platform['commands']]==[0,0] and sha((platform_base/'sources.json').read_bytes())==platform['source_manifest_sha256'] and len(platform_sources)==242
m1_base=ROOT/'target/m2/stage55-platforms-02';m1=read(m1_base/'report.json');assert m1['source_stability'] is True and m1['total']==m1['shared_engine_passed']==6078 and m1['oracle_passed']=={'rust':6076,'node':6076,'browser':6076} and m1['compatibility_status']=='fail' and m1['experiment_contract_status']=='pass' and m1['known_gaps']==['regex-unicode-15-vs-16','regex-zero-width-supplementary']
for name,h in m1['source_hashes'].items():assert sha((m1_base/'sources'/name).read_bytes())==h
for name,h in platform_sources.items():
 if name in source_sha:assert source_sha[name]==h
 else:assert name=='tools/m1_platforms.py' and m1['source_hashes'][name]==h
for name,h in m1['artifacts'].items():assert sha((m1_base/name).read_bytes())==h
native=Path(platform['native_artifact']['path']);assert native.is_file() and file(native)=={'sha256':platform['native_artifact']['sha256'],'bytes':platform['native_artifact']['bytes']}
result={'schema':1,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only validation/build provenance audit. Git metadata/blob byte reads only; no Cargo, test, Java, Node or browser evaluations and no large payload copies.','required_rust':{'report_sha256':sha((base/'report.json').read_bytes()),'manifest_sha256':sha(manifest_data),'input_files_verified':163100,'captured_files_verified':63,'git_backed_files_verified':163037,'git_object_byte_verification':object_records,'complete_input_name_closure_recomputed':True,'checks':checks,'original_wasm_failure':'Exit101, actual No space left on device messages preserved.','workspace_harness':counts,'limits':'Full inherited environment is not enumerated; recorded overrides, host, pinned toolchain input and original command/log provenance remain distinct.'},'wasm_retry':{'report_sha256':sha((retry_base/'report.json').read_bytes()),'exit_code':0,'stdout':file(retry_base/'stdout.bin'),'stderr':file(retry_base/'stderr.bin'),'original_failure_and_four_passes_retained':True,'unchanged_original_input_manifest':True},'tooling_validation':{'report_sha256':sha((tooling_base/'report.json').read_bytes()),'commands':7,'all_exit_zero':True,'input_files_bound_to_required_rust_manifest':4504,'source_manifest_sha256':sha((tooling_base/'sources.json').read_bytes()),'raw_logs':{r['name']:{n:file(tooling_base/f"{r['name']}.{n}.bin") for n in ['stdout','stderr']} for r in tooling['commands']}},'platform_and_native_release':{'wrapper_report_sha256':sha((platform_base/'report.json').read_bytes()),'source_manifest_sha256':sha((platform_base/'sources.json').read_bytes()),'inputs_bound':242,'commands':platform['commands'],'raw_logs':{r['name']:{n:file(platform_base/f"{r['name']}.{n}.bin") for n in ['stdout','stderr']} for r in platform['commands']},'m1_report_sha256':sha((m1_base/'report.json').read_bytes()),'m1_source_snapshot_files_verified':len(m1['source_hashes']),'m1_artifacts':m1['artifacts'],'native_artifact':platform['native_artifact'],'m1_compatibility_status':'fail','m1_experiment_contract_status':'pass','known_regex_nonpasses':m1['known_gaps'],'common_outcomes':6078,'oracle_matches_per_target':6076,'scope':'Original M1 regression artifacts and recorded native release build; strict regex failures are retained.'},'source_hash_catalogs':{'rust_manifest':str((base/'sources.json').relative_to(ROOT)),'tooling_manifest':str((tooling_base/'sources.json').relative_to(ROOT)),'platform_manifest':str((platform_base/'sources.json').relative_to(ROOT))},'blockers':[]}
unit_counts={}
for name in ['m2-python','frame-python']:
 matches=re.findall(r'Ran (\d+) tests? in',(tooling_base/(name+'.stderr.bin')).read_text());assert len(matches)==1;unit_counts[name]=int(matches[0])
js_matches=re.findall(r'(?:ℹ |# )tests (\d+)',(tooling_base/'js-transport.stdout.bin').read_text());assert len(js_matches)==1;unit_counts['js-transport']=int(js_matches[0]);unit_counts['python-total']=unit_counts['m2-python']+unit_counts['frame-python'];assert unit_counts['python-total']==220 and unit_counts['js-transport']==34
result['tooling_validation']['actual_unit_test_counts']=unit_counts
assert all(not (base/manifest[name]['origin']['path']).is_symlink() for name in copied)
result['required_rust']['captured_payloads_are_regular_files']=True
(OUT/'validation-audit.json').write_text(json.dumps(result,indent=2)+'\n');print('Validation audit complete',flush=True)
