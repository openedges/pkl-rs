# Stage55 최종 원시 비교·검증 evidence 독립 감사

기존 최종 capture와 validation 기록을 읽기 전용으로 감사했습니다. 생산 소스와 원본 결과를 수정하지 않았고, Java·Rust·Node·browser 평가나 Cargo/test 실행을 추가하지 않았습니다. root의 실행 session을 poll하거나 재시작하지 않았습니다. 큰 payload 복사·archive 전체 추출 없이 원시 파일, 기존 source snapshot, identity manifest와 Git blob을 사용했습니다.

## 최종 세 target 비교

`stage55-frame-final-01`은 48개 사례 × 두 반복 × native/N-API/Chromium 세 target, 총 288행입니다. 각 target은 ordinary pass 82행, oracle-error 10행, API-exception 4행입니다. 총 **246행 pass와 42행 nonpass**이며 strict main verdict는 **실패** 그대로입니다.

288행의 transform input/output과 logger의 전체 filename 집합·모든 raw `.bin` bytes를 pinned Java archive에 직접 비교했습니다. UTF-8·UTF-16 units, message, nullable member, source lines와 위치를 포함한 총 12,408개 채널이 일치합니다. ordinary 246행은 이 부분 검사뿐 아니라 모든 public payload와 전체 ordered protocol도 같습니다.

nonpass 42행의 차이는 실제 call status, stderr UTF-8/UTF-16, 전체 protocol에만 있습니다. Java exception class는 별도 provenance이고 후보가 합성하지 않았습니다. 원래 상태·오류·protocol을 정규화하거나 고쳐서 통과시키지 않았습니다. **모든 frame/logger 채널의 일치는 부분 관찰이며 전체 session 호환성 통과가 아닙니다.**

public call은 nested callback을 포함해 총 540개입니다. native는 별도 process invocation 96개, N-API는 새 Node child invocation 96개이며 실제 argv/runtime metadata를 확인했습니다. Node child의 OS PID는 기록되어 있지 않습니다. Chromium은 하나의 headless browser launch 안에서 새 context/page/Wasm instance 96개이며 browser OS process 96개로 보고하지 않습니다. 모든 session의 terminal slots/depth가 0이고 collections = polls + 1입니다. portable session 192개의 retained owned payload도 안정적입니다.

## source·artifact·build 결합

최종 source snapshot 4,503개와 전후 identity가 맞고 수정 core 50개를 결합했습니다. native release artifact는 `stage55-platform-run-02`의 실제 기록 build에, N-API와 Wasm 네 파일은 같은 실행의 `stage55-platforms-02` artifact에 정확히 결합됩니다. source·artifact·infrastructure·layout 문제가 없습니다.

platform wrapper의 입력 242개도 결합했습니다. 최종 frame source catalog에 없는 `tools/m1_platforms.py`는 M1의 별도 source snapshot으로 확인했으며 없었던 파일을 frame snapshot에 있었다고 하지 않았습니다. M1 source 215개와 artifact 여섯 항목의 hash를 확인했습니다. 공통 결과 6,078개, Java 일치 환경별 6,076개, 기존 regex 실패 두 개와 compatibility fail / experiment contract pass를 유지합니다.

## required Rust와 retry

thin required-Rust manifest의 163,100개 입력 전체를 확인했습니다. 바뀐 파일 63개의 실제 snapshot과, Git-backed 파일 163,037개의 실제 commit tree/blob OID·길이·SHA-256·Git blob framing을 검증했습니다. 중복 identity는 한 번만 읽어 13,414개 고유 Git blob의 약 202 MB를 streaming으로 확인했고 큰 source closure를 복사하지 않았습니다. 전체 입력 이름 closure도 recorded collector 계약과 맞습니다.

원본 required Rust 기록은 references/fmt/clippy/workspace test 네 검사 exit0, Wasm 검사 exit101입니다. Wasm 실패의 실제 `No space left on device` 오류와 원시 로그는 그대로 남아 있습니다. 별도 retry는 같은 163,100개 입력이 전후 동일한 조건에서 Wasm check만 exit0으로 완료했으며 먼저 통과한 네 검사를 재실행하거나 원본 실패를 통과로 바꾸지 않았습니다. workspace 결과는 895 passed, 0 failed, 1 ignored와 125개 harness summary입니다. ignored는 통과로 계산하지 않았습니다.

tooling validation의 일곱 command는 모두 exit0이고 입력 4,504개가 required-Rust manifest와 결합됩니다. 실제 로그에서 Python 220개와 JS 34개 test를 확인했습니다. 이는 tooling/unit 검증이며 guest 호환성 통과 수가 아닙니다. 전체 inherited environment는 원본 기록에 열거되어 있지 않으므로 기록된 override·host·pinned toolchain input·command/log provenance와 구별합니다.

## offline admission과 감사 오류 보존

요청한 offline `--verify-report` CLI를 한 번 실행해 exit0, 빈 stderr, `integrity=verified`를 확인했습니다. 출력은 strict failed와 모든 nonpass를 그대로 보존합니다. 명령·원시 stdout/stderr·도구 전후 hash는 `offline-verifier.json`에 있습니다. root가 같은 검증을 중복 실행할 필요는 없습니다.

첫 raw 감사 script는 local 정수 `collections`가 Python module 이름을 가려 N-API loop를 시작할 때 실패했습니다. 이는 감사 도구 오류이고 원본 capture나 생산 소스 결함이 아닙니다. 초기 script와 오류 기록·원 tool 결과에서 옮긴 traceback을 보존했고 변수명만 고친 읽기 전용 감사가 288행 전체를 완료했습니다. guest 평가를 반복하지 않았습니다.

Java-only evaluateTest buffer supplement, 실제 foreign exception object/class/API 전달, 전체 M2·성능·장기 메모리·다른 OS/릴리스 플랫폼 의무는 미완료로 남습니다. 별도 legacy packet은 이 감사의 새 실행 결과로 포함하지 않습니다. 확인 범위에서 commit B를 막는 blocker는 찾지 못했습니다.
