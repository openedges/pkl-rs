from pathlib import Path
import subprocess,sys,os,json,hashlib,datetime
ROOT=Path.cwd();OUT=ROOT/'target/m2/stage55-tooling-validation-01'
sys.path.insert(0,str(ROOT/'tools'));import m2_source_inputs
names=set(m2_source_inputs.source_paths(ROOT))|{'PLAN.md','TESTING.md','docs/m2-frame-transformers.md'}
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
before={}
for name in sorted(names):
 data=(ROOT/name).read_bytes();before[name]=hashlib.sha256(data).hexdigest();p=OUT/'sources'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
(OUT/'sources.json').write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';env['CARGO_INCREMENTAL']='0'
commands=[('m2-freshness',[sys.executable,'tools/m2_manifest.py','--check']),('source-inventory',[sys.executable,'tools/inventory.py','--check']),('module-registry',[sys.executable,'tools/m2_module_eval.py','--check']),('frame-fixture',[sys.executable,'tools/frame_transformer_fixtures.py']),('m2-python',[sys.executable,'-m','unittest','discover','-s','tools/tests','-p','test_m2_*.py','-v']),('frame-python',[sys.executable,'-m','unittest','discover','-s','tools/tests','-p','test_frame_transformer_*.py','-v']),('js-transport',['node','--test','tools/platform/frame-transformer-session.test.mjs','tools/platform/capture-frame-transformer.test.mjs','tools/platform/deprecation-session.test.mjs','tools/platform/capture-deprecation.test.mjs','tools/platform/trace-session.test.mjs'])]
report={'scope':'Local tooling/freshness and transport regression; no guest compatibility or performance claim from unit-test counts.','source_count':len(before),'source_manifest_sha256':sha(OUT/'sources.json'),'commands':[],'complete':False}
for name,command in commands:
 print('START',name,flush=True);entry={'name':name,'command':command,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (OUT/(name+'.stdout.bin')).open('xb') as stdout,(OUT/(name+'.stderr.bin')).open('xb') as stderr:result=subprocess.run(command,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
 entry.update(exit_code=result.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdout_sha256=sha(OUT/(name+'.stdout.bin')),stderr_sha256=sha(OUT/(name+'.stderr.bin')));report['commands'].append(entry);(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print('FINISH',name,result.returncode,flush=True)
changed=[name for name,digest in before.items() if sha(ROOT/name)!=digest]
report.update(complete=True,changed_sources=changed);(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'complete':True,'exits':[row['exit_code'] for row in report['commands']],'changed_sources':changed}),flush=True)
raise SystemExit(bool(changed) or any(row['exit_code'] for row in report['commands']))
