# Stage55 native driver·comparator 독립 검토

root 소스는 수정하지 않고 Java 공개 driver와 새 schema에 맞춰 native example·Python comparator·39개 test를 검토했습니다. native CLI 인자 순서·source/query/replacement 전체 입력·UTF-16BE surrogate/null/empty 구분·독립 transform/logger 단계와 callback/throw 순서에서 blocker를 찾지 못했습니다. callback used는 reentry 전, throw-once consumed는 callback 후 검사하므로 같은 stage의 nested callback이 먼저 실패를 소비하는 Java source와 같습니다.

comparator는 transform callback metadata를 실제 Java/후보 public call에 결합하며 전체 .bin filename/bytes·ordered protocol을 비교합니다. Java class provenance는 별도이고 후보가 합성할 수 없습니다. 원본 Java internal/API 오류와 후보 internal/unsupported/limit/API·timeout·launch·누락 실패는 pass로 바뀌지 않습니다. source snapshot·artifact·실제 argv/cwd/env·status·필수 target/case/repeat·replacement input closure와 새 portable tracked source 8개를 확인합니다. Java evaluateTest buffer supplement는 미실행 상태를 강제하고 expression으로 대체하지 않습니다.

실제 verifier module이 생성된 뒤 독립 실행한 39개 synthetic/tamper test가 exit0으로 통과했습니다. Python comparator/test 및 import 두 파일은 실행 전후 동일합니다. native 파일은 root의 clippy 수정 `chunks_exact(2)` → `as_chunks::<2>().0.iter()`로 변했으며 기존 odd-byte rejection 뒤의 동일 UTF-16BE pair 처리를 직접 확인했습니다. Python test는 해당 native example을 실행하지 않으므로 이를 native 실행 결과로 확대하지 않습니다. 원시 결과·전후 hash는 `tests01.json`에 있습니다.

기존 portable helper들과 trace native driver는 모두 host frame transformer 인자를 false로 줍니다. true로 보이는 다른 인자는 hostLogger나 powerAssertions입니다. 새 observed frame helper만 Host transformer를 사용하므로 기존 helper를 무조건 auto-ack하도록 변경할 필요가 없습니다. 다만 기본 URI 정책·진단 경로가 바뀌었으므로 실제 M1/platform·legacy trace·deprecation 회귀는 필요합니다.

검토 시점 fixture verifier의 archive/file-set pin은 실제 취득 대기 중입니다. verifier interface의 buffer_supplement 결합은 맞지만 Java authority가 검증되었다고 하지 않습니다. 실제 47×2 main 취득, 별도 buffer 관찰, 세 target raw 비교·build/source/artifact 결합은 후속 root evidence입니다. 전체 M2/API 완료 주장은 없습니다.
