# Stage48 heap accounting 독립 검토

고정 packet `4199cf58…` / inventory `058a0d4c…`의 84개 파일 및 별도 source addendum `75e992ed…`의 36개 파일을 명시 경로로 확인했다. addendum 소스는 workspace01 source-before 맵과 SHA가 같다. 원본 및 기대값 변경, 새 Java/Rust/플랫폼 실행, Git 명령, tree/cache 전체 탐색은 없었다.

## 다섯 exact assertion의 분리

| 테스트 | 기록된 실패 | 소스가 뒷받침하는 좁은 변경 | 유지할 의무 |
|---|---|---|---|
| fixed value | executable 5 대 4 | 추가 executable 0→1 | 아직 미도달 value 12 유지 |
| fixed hidden reference rendering | executable 6 대 5 | 추가 executable 1→2 | 아직 미도달 value 12 유지, render parameter descriptor 별도 |
| ref rendering | value 5 대 9 | 초기 ref 강제의 네 객체 phase 이동으로 9→5 설명 | executable +1 그대로, 새 실제 결과 필요 |
| ref constraint | value 4 대 8 | 같은 phase 이동으로 8→4 설명 | executable +4 그대로, 새 실제 결과 필요 |
| ref equality | executable 5 대 4 | 추가 executable 0→1 | 아직 미도달 value 15 유지 |

세 executable 실패는 `vm/modules.rs:136` begin_import가 `current_executable()`을 호출하는 변경과 연결된다. `vm.rs:3229`의 root map은 같은 block당 descriptor 하나를 만들고 `collect:1601`에서 유지한다. 각 source의 ref import block이 baseline 뒤 처음 실행되면 정확히 이 한 root가 추가된다. 기존 rendering의 parameter descriptor와 합치거나 사용자 값으로 세지 않는다.

두 Ref value 실패의 공통 SOURCE에는 module-level `checked: ref.Reference<...>`가 있다. `initialize_member_types:6712`는 모듈 초기화 중 이 타입을 초기화하고, import-only guard가 import member를 강제한다. 따라서 이 SOURCE에서는 baseline 전에 ref가 완성된다. fixed 및 equality source에는 이 module-level qualified property 타입이 없으며, class D superclass의 qualified Ref 처리는 lazy class 초기화에 속한다. 이 차이가 세 late executable 실패와 두 early baseline 실패를 나눈다.

## 네 값의 구성과 증거 한계

source closure의 유력하고 구체적인 구성은 **ref module receiver, ref ModuleInfo annotation instance, ref Since annotation instance, Access class**다. 원 제안의 네 번째 `Since class` 추정은 그대로 채택하지 않는다.

`ref.pkl:28`의 두 annotation은 일반 객체로 생성되고 `annotations.rs:315`가 module.annotations에 보관한다. bundled initializer는 일반 module receiver를 만들고 URI cache가 이를 root로 유지한다. `stdlib_modules.rs:288`의 bootstrap은 module 및 annotation을 force한다. `forcing.rs:359`는 abstract/external/hidden/local/method를 제외하며, 정상 Access class는 force 대상이다. Domain은 abstract이고 Reference class는 external이다. 반면 Since는 base의 지원되는 일반 class이고, `base_binding`→`builtins::id` 및 같은 forcing 조건에 따라 기존 base bootstrap에서 이미 force되는 경로다. `builtin_class`는 살아 있는 같은 builtin 타입을 재사용한다.

위 내용은 고정 소스로부터 구성한 그래프 해석이다. **원 packet에는 object ID·종류·root 경로의 실제 dump가 없다.** 네 값의 실측 개별 확인을 주장하지 않는다. raw가 보여 준 두 -4 차이와 소스상 phase 이동은 일치하지만, 수정 후 새 실행에서 exact bounds와 이전 미도달 value assertions까지 통과했는지는 별도로 확인해야 한다.

## 사용자 객체 잔류와 import site

실제 `admission-host-consumers-02`는 전체 exit 101(별도 lossless consumer 실패)이며 admission 14건은 통과했다. 그중 `successful_import_site_does_not_retain_temporary_importing_receivers:597`은 12회 factory-created receiver를 만들고 import 후 외부 root 없는 GC에서 stale가 됨을 확인한다. imported json receiver는 같은 identity로 살아 있고 live/executable 총량은 첫 반복 뒤 정확히 plateau를 이룬다. 성공 site + bundled Resolve 두 요청만 발생하며 close 후 slots=0이다.

이는 site cache가 **임시 importing receiver**를 붙잡지 않는다는 근거다. 명시적으로 등록된 primary module은 `MakeObject`의 URI cache publication과 `collect`의 cache roots 때문에 계속 유지된다. 이 정상적인 main module cache retention을 임시 객체 수거로 표현해서는 안 된다. 새 테스트가 모든 user module 그래프, per-node ref closure, 서로 다른 executable owner 12개, custom key/isCached/cycle를 검증했다고도 주장하지 않는다. 현재 `member_state(...).is_err()`는 함수 내부에서 heap.get 실패로만 나므로 stale 경계에 연결되지만, 후속 테스트에서 StaleHandle kind를 명시하면 더 명료하다.

원래 50,000 poll guard, poll budget1, now/deadline, GC, Host reentry/retry, raw 오류, old token 거부, cancel 목록, context depth, close live/slots=0 의무는 유지해야 한다. 수치를 양수·최소치·plateau로 대체할 근거는 없다. 이것은 source accounting 검토이며 Java 호환성 판정이 아니다.
