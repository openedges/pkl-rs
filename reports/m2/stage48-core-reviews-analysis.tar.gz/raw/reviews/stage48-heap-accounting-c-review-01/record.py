from pathlib import Path
import hashlib,json,stat,re
O=Path(__file__).resolve().parent
P=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-implementation-01/admission-heap-accounting-review-01')
A=P.parent/'admission-heap-accounting-sources-addendum-01'
h=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def copy(p,n,expected=None):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode),str(p)
 b=p.read_bytes();sha=h(b)
 if expected:assert sha==expected,(str(p),sha,expected)
 d=O/'evidence'/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 rows.append({'original':str(p),'snapshot':'evidence/'+n,'sha256':sha,'bytes':len(b),'mode':stat.S_IMODE(s.st_mode)})
 return b
inv=json.loads(copy(P/'inventory.json','packet/inventory.json','058a0d4cd457ad36d5ed59523eead238ad127e3f37bc433297d34df9baaa3e92'))
assert len(inv)==84
for n,sha in inv.items():copy(P/n,'packet/'+n,sha)
assert h((P/'report.json').read_bytes())=='4199cf58de252cb255ef8a6ddbca51e99e63c94313478e592b50b5d1ead57ee0'
sm=json.loads(copy(A/'source-map.json','source-addendum/source-map.json','75e992ed85eaea26fb227c7075c0cfc83cd425ba4747e16916b920b094b74cc9'))
copy(A/'report.json','source-addendum/report.json')
source=json.loads((P/'captures/admission-workspace-tests-01/source-before.json').read_bytes())
for n,sha in sm.items():
 assert source[n]==sha
 copy(A/'sources'/n,'source-addendum/sources/'+n,sha)
checks=[]
for n in ['admission-workspace-tests-01','admission-host-consumers-02','admission-tests-09']:
 root=P/'captures'/n;d=json.loads((root/'report.json').read_bytes())
 assert d['exit_code']==101 and d['source_stable']
 assert (root/'source-before.json').read_bytes()==(root/'source-after.json').read_bytes()
 for channel in ['stdout','stderr']:assert h((root/(channel+'.bin')).read_bytes())==d[channel+'_sha256']
 checks.append({'name':n,'exitCode':101,'sourceStable':True})
raw=(P/'captures/admission-host-consumers-02/stdout.bin').read_text()
assert 'successful_import_site_does_not_retain_temporary_importing_receivers ... ok' in raw
assert re.search(r'test result: ok\. 14 passed; 0 failed;',raw)
for r in rows:assert h(Path(r['original']).read_bytes())==r['sha256']
ledger=[
 {'test':'fixed/inherited_fixed_values_keep_the_amended_receiver_across_gc_reentry_and_retry','recordedFailure':'executable actual5 expected4','sourceSupportedAdjustment':'added_executables 0 -> 1','valueExpectation':'Keep12; assertion not reached in original run','basis':'No eager module-level qualified property type; lazy Domain/class or is expression first forces authored import block after baseline. begin_import now materializes current_executable for that shared block.'},
 {'test':'fixed/inherited_hidden_fixed_reference_metadata_stays_deferred_during_render_retry','recordedFailure':'executable actual6 expected5','sourceSupportedAdjustment':'added_executables 1 -> 2','valueExpectation':'Keep12; assertion not reached in original run','basis':'Same late authored import block root; existing renderReference parameter descriptor remains separately counted.'},
 {'test':'ref/suspended_rendering_preserves_reference_metadata_during_reentry_gc_and_retry','recordedFailure':'added_values actual5 expected9','sourceSupportedAdjustment':'value expectation9 -> 5, conditioned on source closure below and fresh result','valueExpectation':'Source-derived four-object phase shift; no per-object IDs were captured','basis':'checked: ref.Reference qualified property type forces the import guard before Baseline::new. Ref module, two annotations and Access class move before baseline; existing render parameter descriptor delta1 remains unchanged.'},
 {'test':'ref/domain_constraint_continuations_keep_reference_and_custom_this_through_gc','recordedFailure':'added_values actual4 expected8','sourceSupportedAdjustment':'value expectation8 -> 4, conditioned on source closure below and fresh result','valueExpectation':'Source-derived four-object phase shift; no per-object IDs were captured','basis':'Same module-level checked Ref guard; pre-existing constraint/type executable delta4 passed and must remain unchanged.'},
 {'test':'ref/equality_retains_pending_domain_and_data_comparisons_and_retries_only_failed_reads','recordedFailure':'executable actual5 expected4','sourceSupportedAdjustment':'added_executables 0 -> 1','valueExpectation':'Keep15; assertion not reached in original run','basis':'This source lacks checked qualified module property type, so lazy Domain initializer first forces authored import block after baseline.'}]
report={'schema':1,'scope':'Read-only frozen heap-accounting source review. No expectation edits, runtime/oracle/build/test/Git reruns or mutable core reads.','packetReportSha256':h((P/'report.json').read_bytes()),'packetInventorySha256':h((P/'inventory.json').read_bytes()),'sourceAddendumMapSha256':h((A/'source-map.json').read_bytes()),'recordedChecks':checks,'ledger':ledger,'fourObjectClosure':{'classification':'Static source-derived accounting, not a captured object-ID/root dump','values':['ref module receiver','ref ModuleInfo annotation instance','ref Since annotation instance','ref Access builtin class'],'excluded':['Since class: supported base class forced during earlier base bootstrap','Domain class: abstract declaration skipped by stdlib forcing','Reference class: external declaration skipped by stdlib forcing'],'rootPaths':['modules_original/resolved -> ref receiver -> annotations -> their class parents','ref receiver cached Access member -> Access class'],'caveat':'No per-object dump exists. ModuleInfo/Since/Access classification is source-derived and must not be presented as instrumented provenance. Fresh corrected checks must retain exact bounds and verify the previously unreached values.'},'retentionProof':{'actualTest':'successful_import_site_does_not_retain_temporary_importing_receivers','iterations':12,'recordedPass':True,'proved':['temporary importing receiver becomes stale after no-external-root collection','imported json receiver stays valid and identical','live and executable counts plateau after first iteration','only successful shared AST site and bundled resolve requests occur','close clears all slots'],'notProved':['all user module graphs become unreachable: explicit primary module cache intentionally remains a root','per-node ref lifecycle closure','12 distinct executable owners, fresh query sites, arbitrary custom key/isCached/cycle behavior'],'suggestion':'An exact StaleHandle kind assertion can make the existing member_state.is_err check more explicit, although the current member_state implementation only fails via heap.get for stale handles.'},'requiredPreservation':['Keep original polling budgets, now/deadline values, per-poll collect, Host callbacks and exact returned raw errors','Keep retry token inequality, stale old token rejection, pending cancellation lists, context depth and terminal live/slots zero','Do not replace exact user value bounds with positive/plateau or current total','Do not credit primary-module URI-cache retention as temporary importer reclamation'],'compatibilityPassClaimed':False,'originalChanges':[],'recursiveTraversal':False}
(O/'report.json').write_text(json.dumps(report,indent=2)+'\n')
(O/'inputs.json').write_text(json.dumps({'files':rows,'changes':[],'recursiveTraversal':False},indent=2)+'\n')
print(json.dumps({'records':len(rows),'packetFiles':len(inv),'additionalSources':len(sm),'originalChanges':[]}))
