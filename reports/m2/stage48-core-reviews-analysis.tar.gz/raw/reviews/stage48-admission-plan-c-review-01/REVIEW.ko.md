# Stage48 admission 계획의 독립 소스 검토

검토 대상은 Stage47의 고정 계획 `stage48-stdlib-admission-design-01/PLAN.ko.md`와 `0e13a589d43c4cb1d83f41dd1ec416cac1770fc1`의 공유 엔진, 고정 Pkl `e51fb2f91774265666f94980ec630db794a4db2d`다. Stage48의 편집 중 소스는 읽지 않았다. 새 Java·Rust·플랫폼 실행은 없다. 아래 내용은 소스 계약과 앞으로 필요한 대조군이며 실제 새 호환 결과가 아니다.

## 구현 전에 바로 고칠 두 표현

1. **런타임 factory 선택과 import 선언의 AST factory 선택을 분리한다.** `ImportNode.java:50–65`의 site 성공 cache → edge 검사 → factory → ModuleCache 순서는 맞다. 그러나 `AstBuilder.java:1648–1654`는 `visitImportClause`에서 `doVisitImport` 후 `moduleResolver.resolve(importNode.getImportUri())`를 무조건 호출한다. `as` alias가 있어도 호출되며 unused 선언도 factory 실패로 모듈 준비가 실패할 수 있다. `ImportExpr`의 `doVisitImport:650–661`에는 이 추가 선택이 없다. 따라서 '모든 factory 효과는 CheckImport 뒤'로 구현하면 첫 오류·방문 순서가 바뀐다. 기존 ordered preparation에 clause의 SelectKey/이름 추론 효과를 별도 단계로 기록하거나 명시적인 미완료 의무로 남겨야 한다. 이것을 edge 검사나 ModuleKey.resolve/allowlist로 대체하지 않는다. AST 단계에 추가한 factory 효과는 아래 실행 시점의 factory 호출도 제거하지 않는다.
2. **기존 HasElement의 typed security provenance를 유지한다.** 계획 4절의 'CheckImport/Resolve typed SecurityManagerException만'은 새 edge 계약의 범위로 한정해야 한다. `ModuleKeys.File.hasElement:325–328`은 실제 `checkResolveModule`을 호출하고, `IoUtils.resolve:432–454`의 triple 탐색 및 `AstBuilder.resolveImport:3051–3052`가 typed SecurityManagerException을 원래 operand 위치의 guest 오류로 전파한다. 현재 Rust `vm/modules.rs:196–216`은 Source/Capabilities만 해당 completion을 거절하며 HasElement는 허용한다. `vm/uri_resolution.rs:319–335`와 `probe.rs:819–835` 경로를 유지해야 한다. Source/Capabilities에 대한 금지를 느슨하게 바꿀 이유는 없다.

## 캐시 전이를 더 정확히 고정할 의무

- **resolved alias hit는 original cache를 새로 채우지 않는다.** `ModuleCache.java:153–160`은 resolved hit의 값/실패를 즉시 반환한다. 따라서 아직 성공하지 않은 다른 AST site에서 같은 alias를 쓰면 매번 edge·factory·key resolve를 거치며, 그 site가 성공한 뒤에만 site cache로 생략한다. 현재 Rust `vm/modules.rs:243–248`도 original alias를 삽입하지 않는다. admission 추가 시 alias를 앞당겨 게시하는 '최적화'를 넣지 않는다.
- **isCached=false는 lookup만 건너뛴다.** `ModuleCache.java:133–141`은 resolve 후 `doLoad`를 호출하며 `doLoad:181–192`의 original/resolved put은 성공·실패 모두 조건 없이 실행된다. 'uncached이면 캐시를 전혀 읽거나 쓰지 않는다'로 일반화하지 않는다. first bundled checkpoint가 uncached SPI를 구현하지 않는다면 정확한 후속 의무로 유지한다. Java 문서 설명보다 고정된 실제 producer와 새 raw control을 기준으로 판정한다.
- **source 성공 전 receiver는 비공개이고 source 실패도 오류 cache를 만든다.** `ModuleCache.java:175–193`은 빈 receiver를 먼저 만들지만 loadSource 성공 후 receiver를 게시한다. source/초기화 예외는 양쪽 URI에 실패로 게시하며, key resolve 실패는 이 try 바깥이다. Rust `resolved_module:250–255`, `loaded_module:271–280`, `Vm::fail:2005–2048`의 구분을 새 bundled 경로에서도 보존한다.
- **site 성공은 loadModule 반환 시점이다.** 순환 중 반환된 부분 receiver를 site가 저장할 수 있다. 이후 outer initializer 실패가 URI cache를 Failed로 바꿔도 이미 성공한 site 값까지 삭제하면 안 된다. 현재 RuntimeError stack replay/guest catch 경계를 재사용하되 site 실패를 만들지 않는다. key resolve·edge 실패를 module 실패 cache로 추가하지 않는다.
- **singleton은 URI 문자열이 아니라 key 종류로 선택한다.** `ModuleKeys.isStdLibModule:56–57`은 `instanceof StandardLibrary`다. `ModuleCache:82–130`의 정확한 singleton switch와 catalog 검사 뒤에야 일반 isCached/URI lookup이 온다. `ModuleResolver:76–100`의 normalize·factory 순서와 factory가 반환한 종류를 분리한다. 제공 text를 감싼 `CachedModuleKey`는 StandardLibrary가 아니며, 그 `resolve:184–185`는 delegate security를 실행하지 않고 자신을 반환한다. supplied-text/public query lifecycle의 후속 구현이 모든 `pkl:` URI를 singleton으로 분류하면 안 된다.

## owner·URI·오류·GC 체크리스트

- edge importer는 `ImportNode.currentModule.getUri()` 즉 resolved importer다. URI 준비 기준·진단 source·original cache key와 분리한다. edge 대상은 factory normalize **전** import URI다. 현 `prepare_module_uri:377–378`의 `(absolute, normalized original)` 구분을 보존하며 CheckImport에 normalized original만 넘기지 않는다.
- site 키는 URI나 expression 문자열이 아니다. 실제 executable owner와 instruction 위치를 함께 사용한다. `FunctionLiteralNode:45–59`는 같은 literal의 functionNode를 재사용하므로 서로 다른 closure 값이라고 자동으로 별도 site가 되는 것도 아니다. 반대로 새 query AST의 동일 문자열 import는 별도 site다. alias/type/member clone의 owner 정책은 actual Java control로 판정한다.
- `current_executable:3236–3247`과 `ExecutableState`를 이용하되, 대기 전 확정한 site owner를 continuation에 보존한다. initializer·재진입·generator가 바뀐 뒤의 current frame에서 새 owner를 추측하지 않는다. site 값에는 결과 receiver만 보관하고 최초 importer/activation을 보관하지 않는다.
- `Entry::Executable` tracer(`heap.rs:638–640`)는 현재 children만 추적한다. 새 site 결과도 추적해야 한다. 특히 URI cache가 Failed로 교체된 부분 receiver가 site를 통해서만 살아 있는 경우를 포함한다. active/suspended `ModuleRun`의 owner/result도 `Vm::collect:1609–1650`에서 보존하며 close에서 기존 roots와 함께 제거한다.
- 잘못된 id/variant/phase/위조 bundled identity는 `complete_module`의 실행·fail·cache 게시 전에 검증한다. 현재 wrong-phase source Security/Capabilities Security의 early-return token 보존 계약을 유지한다. CheckImport의 NotFound/Io는 Java edge API의 throws 계약에 없으므로 새 completion 계약에서 잘못된 phase로 거절하는 편이 타당하며, 이를 guest 오류로 만들기 전에 별도 근거가 필요하다.
- raw Denied·callback rejection·Unsupported·logger 실패·종료를 typed SecurityManagerException으로 재분류하지 않는다. absent/empty/surrogate cause와 full frames를 보존한다.
- 저수준 `Vm::cancel`의 재시작 가능 경로와 공개 `HostSession::cancel`의 영구 종료(`host.rs:380–385`)를 구분한다. 성공 site/URI cache 보존과 미완성 site 미게시, 요청 id 비재사용을 각각 검사한다. public cancel/timeout/close는 terminal slots 0과 stale token/user handle 거절을 유지한다.

## 최소 검증 매핑

| 구분 | 필요한 원시 관찰/검사 | 현재 판정 |
| --- | --- | --- |
| AST clause vs expr | unused unknown-loader/factory-throw, alias 있음/없음, 앞뒤 static 오류; factory·edge 이벤트 순서와 첫 진단 | B에 source-backed 의무 전달, 새 결과 없음 |
| site 성공/실패 | 같은 함수 site 반복, 별도 site, fresh query 동일 문자열, lambda/alias clone, denial 후 재시도 | 새 Java control 필요 |
| resolved alias | A/B original → 같은 resolved URI, 여러 fresh site 반복; resolver 호출 수, 값 identity, 오류 replay | 고정 Java source 의무 |
| cached/uncached | factory/key 정책을 같은 URI에서 구분; uncached load 뒤 cached lookup, source/초기화 실패 뒤 lookup | 일반 key 후속 의무, 구현 완료 아님 |
| singleton 종류 | base/ref/test의 edge 거부/resolve 생략, json의 일반 resolve/cache; custom factory가 pkl URI를 다른 key로 제공 | 기존 Java06 84개 + 새 kind controls |
| 순환 부분 반환 | site가 부분 receiver를 반환한 뒤 outer init 실패, site 재사용 vs 새 site의 실패, catch·GC·후속 stable | 새 실제 control 필요 |
| phase 무결성 | wrong id/variant, edge NotFound/Io, source/capabilities Security, forged bundled original/resolved/source; 올바른 completion으로 재개 가능 | Rust/바인딩 meaningful regression 필요 |
| Host/GC/종료 | edge/resolve/source 각각 GC·reentry·nonterminal cancel, public close/timeout, stale handles, terminal 0 | 실제 final candidate 검사 필요 |
| 공개 API parity | supplied-text, primary URI, fresh repl query의 factory/resolve 차이; events 합성 금지 | 기존 계획의 별도 lifecycle 미완료 유지 |

기존 계획의 핵심 방향인 bundled source와 admission 분리, singleton/general cache 구분, 기존 typed Host 경유, 사용자 Host 앞의 자동 fallback 금지, 기존 raw fixture 보존은 타당하다. 이 검토는 Stage48 코드 승인이나 호환 통과가 아니며, frozen core 후보가 나오면 위 전이·tracing·token 계약을 별도로 검토해야 한다.
