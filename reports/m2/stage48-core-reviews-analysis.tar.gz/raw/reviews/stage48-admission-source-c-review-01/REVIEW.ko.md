# Stage48 focused admission proposal01 독립 소스 검토

대상은 Stage48 `admission-review-proposal-01`의 report `9b1963ad…`, map `764057ed…` 및 14개 명시 경로다. 구현 중 live core는 읽지 않았다. baseline은 `0e13a589d43c4cb1d83f41dd1ec416cac1770fc1`, Java는 Pkl 0.32.0의 고정 소스다. architecture 검사 9개 결과는 producer의 기존 원시 기록이며 이 검토에서 Rust/Java/Node/Chromium을 재실행하지 않았다.

## 수정이 필요한 새 소스 차이

### 1. singleton 분류는 decoded scheme-specific-part와 canonical identity를 사용해야 한다

`modules.rs:161–192`의 raw `strip_prefix("pkl:")` switch는 Java `ModuleCache.java:82–87`와 다르다. Java의 `URI.getSchemeSpecificPart()`는 percent escape를 디코드하고 fragment를 제외한다. 따라서 `pkl:base#tag`, `pkl:%62ase`와 ref/test의 같은 형태는 singleton switch를 통과하지만 현재 Rust는 Missing으로 분류한다. raw edge URI는 그대로 두어야 한다.

이름 분류만 바꾸어도 충분하지 않다. `vm/modules.rs:189–198`은 raw original URI로 module cache/stdlib_entry를 찾으므로 alias가 implicit canonical `pkl:base` receiver/source를 재사용하지 못한다. Java singleton getter는 raw alias와 무관하게 같은 canonical 모듈을 반환한다. descriptor에 authored edge/key URI와 canonical singleton/source identity를 분리해야 한다. 반면 일반 catalog는 전체 URI를 사용하므로 `pkl:json#tag` 및 percent-escaped json 이름을 똑같이 canonicalize하여 허용하면 안 된다.

A가 이 finding을 수신했고 새 후속 snapshot에서 교정하기로 했다. 새 Java/실행 관찰은 아직 없으며 B에 최소 URI controls를 전달했다.

### 2. jar nested trust 판정은 decoded SSP 접두사를 사용한다

고정 Java `SecurityManagers.java:84–90`은 decoded `uri.getSchemeSpecificPart().startsWith("nested:")`를 검사한다. proposal01 `host/resources.rs:163–168`은 raw substring에 starts_with를 적용한다. 예를 들어 유효 URI `jar:nest%65d:foo`는 Java 소스상 trust 20이지만 현재 Rust는 raw substring의 다음 scheme을 파싱하다 Unsupported가 된다.

nested 여부만 decoded SSP로 검사하고, non-nested recursion은 Java처럼 raw URI 문자열의 substring(4)를 유지해야 한다. 잘못된 해결책으로 전체 URI를 먼저 디코드하면 raw nested URI의 뒤쪽 parse/정책 의미도 달라진다. 이 역시 새 실제 Java 결과가 아닌 source-specific finding이며 별도 control이 필요하다.

## 계획대로 반영된 경계

- `begin_import:136–168`: executable-owner/site cache 성공 hit가 edge보다 앞선다. 새 site는 `CheckImport`를 먼저 요청하며 resolved importer와 pre-normalized edge URI를 보존한다.
- `checked_import:171–221`: edge 거부는 site 성공/URI 실패 cache를 만들지 않는다. singleton은 Resolve를 생략하고 일반 cached key는 original URI hit 뒤 Resolve로 간다. custom key-kind 선택은 아직 별도 미완료다.
- `resolved_module:370–376`: resolved alias hit는 original alias를 새로 seed하지 않고 공통 finish_import에서 site만 게시한다. 계획의 alias finding을 보존했다.
- `complete_module:272–342`: id/variant, edge NotFound/Io, bundled identity 위조, Source/Capabilities typed Security의 검증이 처리/fail보다 앞선다. 기존 HasElement typed Security는 계속 허용된다. bundled 위조의 token 유지 architecture 회귀도 있다.
- `loaded_module:400–410` 및 기존 fail 경로: source 실패는 resolve 실패와 구분되어 cache되며, source 성공 후 partial receiver를 게시한다.
- `finish_import:224–235`, `step_module:504–522`: 반환이 성공했을 때만 site receiver를 게시한다. source-less 실패 site를 성공으로 cache하지 않는다.
- `Heap::collect`의 Executable branch는 imported_modules 값도 추적한다. site에는 imported receiver만 저장하며 최초 importer/activation은 저장하지 않는다. 현재 owner는 VM executable root 또는 caller frame environment를 통해 rooted되고 기존 suspended-frame 경로도 유지된다.
- 기본 adapter는 명시적으로 default helper를 선택하고 사용자 `with_host` callback 앞에 VM fallback을 삽입하지 않는다. pure helper의 URI 등록 누락을 보완했다. native development file profile도 shared 기본 policy를 명시적으로 호출한다.
- NAPI/Wasm의 reject message는 기존 lossless PklString 경로와 optional cause를 재사용한다. 이번 기록은 source 검토이며 실제 binding compile/transport 통과가 아니다.
- public SourceProbe cancel과 low-level Vm.cancel을 분리했다. 기존 public cancel을 재시작 가능하게 바꾸지 않았고 wrong-token/close-zero 검사가 유지된다.

## 여전히 필요한 범위와 검증

| 의무 | 현재 범위 |
| --- | --- |
| import clause의 AST factory 선택 | proposal의 open에 명시. runtime edge 전후 factory와 별개이며 미구현 |
| factory/key 종류·isCached=false·cached text wrapper | URI 문자열 분류가 일반 SPI key 종류를 대체하지 못함. 첫 default bundled checkpoint 이후 필수 |
| 캐시의 URI 등가성 | 문자열 original/resolved map은 Java URI equality 전체가 아님. 사후 문자열 정규화로 결과를 숨기지 않음 |
| 순환 partial 반환 후 outer 초기화 실패 | source 경로상 site 값은 fail에서 지우지 않지만, URI cache가 Failed인 상태에서 site만 partial receiver를 보유하는 실제 cycle/GC 대조군은 없음 |
| owner/clone/fresh query | function literal/alias clone·fresh query AST의 site 구분은 실제 Java control과 새 native 비교 필요 |
| 공개 primary/repl lifecycle | supplied text 및 fresh repl의 factory/resolve/security 이벤트 전체 parity는 여전히 미완료 |
| import* | per-entry edge와 forced glob은 별도 미지원 |
| 실제 정책·raw 진단 | 기존 Java06 policy84 및 새 site/trust/URI controls를 소비하기 전에는 9 architecture tests를 Java 호환 통과로 환산하지 않음 |
| 전체 검사와 기존 소비자 | binding compile, exhaustive old Host match·native/modulepath provider migration, Rust5·동일 한도의 small-stack/heap·실제 플랫폼·full selected 회귀 미실행 범위 유지 |

특히 singleton source/canonical identity와 public supplied-text ModuleKey를 섞지 않아야 한다. Java CachedModuleKey는 StandardLibrary 종류가 아니며 singleton은 일반 URI cache보다 앞서 선택된다. 임의 primary URI와 custom factory가 canonical pkl URI와 겹치는 경우는 key 종류/공개 lifecycle 후속 의무로 명시해야 한다.

현재 focused plain canonical URI 경로의 cache·phase·기존 HasElement/취소 구분에 추가 소스 차단 문제는 찾지 못했다. 위 두 URI 의미 차이는 교정 검토가 필요하며, proposal01 또는 architecture tests를 최종 semantic pass로 표시하지 않는다.
