from pathlib import Path
import json,hashlib,stat,re
OUT=Path(__file__).resolve().parent;P=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-implementation-01/admission-review-proposal-01');sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def copy(path,relative,expected=None):
 path=Path(path);b=path.read_bytes();h=sha(b)
 if expected:assert h==expected,(path,h,expected)
 d=OUT/'evidence'/relative;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);rows.append({'path':str(path),'snapshot':'evidence/'+relative,'sha256':h,'bytes':len(b),'mode':stat.S_IMODE(path.lstat().st_mode)});return b
report=json.loads(copy(P/'report.json','report.json','9b1963ad51d6e62fdadea9a314addf1b0b923a4bb52562354abe67c0498a653e'));sm=json.loads(copy(P/'source-map.json','source-map.json','764057eda21680e67aada28795e9b36447f32bfab445e4ffefc0febe85b521d7'));listing=json.loads(copy(P/'sources.json','sources.json'));copy(P/'tracked.diff','tracked.diff');assert len(sm)==len(listing)==14
for r in listing:
 copy(P/r['snapshot'],r['snapshot'],sm[r['path']]);base=P/'base'/r['path']
 if r['base_sha256'] is not None:copy(base,'base/'+r['path'],r['base_sha256'])
for check in report['checks']:
 root=P/'checks'/check['name'];d=json.loads(copy(root/'report.json','checks/'+check['name']+'/report.json',check['report_sha256']));assert d['exit_code']==check['exit_code']
 for n in ['source-before.json','source-after.json','stdout.bin','stderr.bin']:
  expected=d.get(n.split('.')[0]+'_sha256') if n in ['stdout.bin','stderr.bin'] else None
  copy(root/n,'checks/'+check['name']+'/'+n,expected)
tested=json.loads((P/'checks/admission-tests-03/source-before.json').read_bytes());assert sha((P/'checks/admission-tests-03/source-before.json').read_bytes())==report['tested_map_sha256'];assert (P/'checks/admission-tests-03/source-before.json').read_bytes()==(P/'checks/admission-tests-03/source-after.json').read_bytes();assert all(tested[n]==h for n,h in sm.items())
text=(P/'checks/admission-tests-03/stdout.bin').read_text();assert re.search(r'test result: ok\. 9 passed; 0 failed;',text)
for r in rows:assert sha(Path(r['path']).read_bytes())==r['sha256']
summary={'schema':1,'scope':'Frozenfocusedsource review only; no livecore snapshot, runtime/oracle/tests/build/Git execution or production changes.','producerReportSha256':sha((P/'report.json').read_bytes()),'sourceMapSha256':sha((P/'source-map.json').read_bytes()),'changedPaths':14,'testedArchitectureCases':9,'recordedArchitectureExit':0,'actual55153Attribution':'A/root reported actualterminal0; copied producer report/raw+217entry source maps are bound here. No new evaluator execution by C.','findings':[{'id':'SINGLETON-DECODED-SSP','source':'crates/pkl-runtime/src/modules.rs:161','required':'Separate decodedSSP singletonname/canonicalreceiver from rawedge and fullURIgenericcatalog; source-only pkl:base#tag/pkl:%62ase controls.'},{'id':'JAR-NESTED-DECODED-SSP','source':'crates/pkl-runtime/src/host/resources.rs:163','required':'Use decodedSSP nested-prefix check while preserving raw substring recursion for otherjarURIs; source-only jar:nest%65d:foo control.'}],'preserved':['Sitecache beforeCheckImport','Resolved importer and prenormalizededgeURI','Alias resolvedhit doesnotseed originalcache','Wrongphase/bundledidentity validationbeforeconsumption','HasElement typedsecurity provenance','Executable importedreceiver tracing','Publicterminalcancel vs lowlevelnonterminalcancel','No implicitfallback beforeuserHost'],'openScope':report['open'],'sourceChanges':[],'newCompatibilityPassClaimed':False}
(OUT/'report.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'inputs.json').write_text(json.dumps({'files':rows,'changes':[],'recursiveTraversal':False},indent=2)+'\n');print(json.dumps({'sourcePaths':14,'copiedRecords':len(rows),'architectureTests':9,'sourceFindings':2,'changes':[]}))
