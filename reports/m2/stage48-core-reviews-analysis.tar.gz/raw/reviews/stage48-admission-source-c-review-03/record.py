from pathlib import Path
import hashlib,json,stat,re,difflib
O=Path(__file__).resolve().parent;P=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-implementation-01/admission-review-proposal-03');OLD=P.parent/'admission-review-proposal-02'
h=lambda b:hashlib.sha256(b).hexdigest();rows=[]
def copy(p,n,expected=None):
 p=Path(p);s=p.lstat();assert stat.S_ISREG(s.st_mode)
 b=p.read_bytes();sha=h(b)
 if expected:assert sha==expected,(str(p),sha,expected)
 d=O/'evidence'/n;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 rows.append({'original':str(p),'snapshot':'evidence/'+n,'sha256':sha,'bytes':len(b),'mode':stat.S_IMODE(s.st_mode)});return b
report=json.loads(copy(P/'report.json','proposal/report.json','548744b8626adb51da0bc10da3951ad64fe0f33424bab337371ed8420901b58a'))
sm=json.loads(copy(P/'source-map.json','proposal/source-map.json','26e9c0a57d596be3c1d3fae8f9294c9018635c965f10dbfee3fc2551afc2e6ba'));assert len(sm)==49
copy(P/'tracked.diff','proposal/tracked.diff')
old=json.loads(copy(OLD/'source-map.json','predecessor/source-map.json','0666e9311b1abeca0354f846451f976c9360e25141fa22a3a21ed650cb93993e'))
delta=[]
for n,sha in sm.items():
 b=copy(P/'sources'/n,'proposal/sources/'+n,sha)
 base=P/'base'/n
 if base.exists():copy(base,'proposal/base/'+n)
 if n in old and old[n]!=sha:
  before=copy(OLD/'sources'/n,'predecessor/sources/'+n,old[n]);d=''.join(difflib.unified_diff(before.decode().splitlines(True),b.decode().splitlines(True),fromfile='proposal02/'+n,tofile='proposal03/'+n))
  delta.append({'path':n,'before':old[n],'after':sha,'kind':'changed'})
  out=O/'delta'/Path(n+'.diff');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(d)
 elif n not in old:delta.append({'path':n,'before':None,'after':sha,'kind':'added-to-review-packet'})
checks=[]
for item in report['checks']:
 n=item['name'];root=P/'checks'/n;d=json.loads(copy(root/'report.json','proposal/checks/'+n+'/report.json'));assert d['exit_code']==item['exit_code'] and d['source_stable']
 before=copy(root/'source-before.json','proposal/checks/'+n+'/source-before.json');after=copy(root/'source-after.json','proposal/checks/'+n+'/source-after.json');assert before==after
 copy(root/'launch.json','proposal/checks/'+n+'/launch.json')
 for channel in ['stdout','stderr']:copy(root/(channel+'.bin'),'proposal/checks/'+n+'/'+channel+'.bin',d[channel+'_sha256'])
 raw=(root/'stdout.bin').read_text();summaries=[list(map(int,p)) for p in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',raw)]
 checks.append({'name':n,'exitCode':d['exit_code'],'sourceStable':True,'rawSummaries':summaries})
testmap=json.loads((P/'checks/admission-cycle-lifecycle-tests-02/source-before.json').read_bytes());unmatched=[n for n,sha in sm.items() if testmap.get(n)!=sha]
assert unmatched==['crates/pkl-runtime/examples/stage48_policy_probe.rs','crates/pkl-runtime/examples/stage48_policy_probe/file_host.rs'],unmatched
assert checks[-1]['rawSummaries']==[[6,0],[3,0],[15,0],[4,0]]
for n in ['stage48-admission-source-c-review-02','stage48-heap-accounting-c-review-01']:
 root=O.parent/n
 for file in ['report.json','closure.json']:copy(root/file,'prior-reviews/'+n+'/'+file)
for row in rows:assert h(Path(row['original']).read_bytes())==row['sha256']
(O/'source-delta.json').write_text(json.dumps({'changed':[r for r in delta if r['kind']=='changed'],'addedToPacket':[r for r in delta if r['kind']!='changed'],'deleted':[]},indent=2)+'\n')
result={'schema':1,'scope':'Frozen proposal03 source review only. Prior reviews reused; no live core snapshot, evaluator/oracle/build/test reruns or Git/source/reference mutation.','proposalReportSha256':h((P/'report.json').read_bytes()),'sourceMapSha256':h((P/'source-map.json').read_bytes()),'sourcePaths':49,'changedVsProposal02':9,'addedToReviewPacket':24,'recordedChecks':checks,'latestRecordedPassed':28,'sourceMatchesLatestCheck':47,'latestCheckUncompiledNewAdapterPaths':unmatched,'closedPriorSourceFindings':['All three qualified Ref type/guard decisions use canonical singleton descriptor while raw CheckImport URI remains authored','Five exact heap adjustments match independent ledger; previously unreachable value12/12/15 assertions passed without broadening bounds'],'observations':[{'id':'PARTIAL-CYCLE-SCOPE','status':'preserved','detail':'Saved successful partial import site returns Good after URI-cache failure; fresh site errors, source loaded only once per a/b, strict request count11 and GC/close retained. String label equality is not ObjectId identity.'},{'id':'DIAGNOSTIC-CLASS-OWNER','status':'narrow-correction','detail':'Class diagnostic renderer now uses stored declaration module with original fallback, preserving builtin handling. Actual prior main#Good failure retained before corrected a#Good result.'},{'id':'PURE-PROBE-BUDGET','status':'preserved','detail':'finish snapshots starting instruction count and subtracts cumulative count across default completions, preserving each pre-existing one-million-instruction finish budget; Pending/Log/unsupported Resolve stay explicit failures.'},{'id':'EXECUTABLE-ROOT-COMMENT','status':'source-comment-qualification','detail':'Fixed value comment attributes static import executable retention to module cache; actual direct root is VM executable_roots. A acknowledged later comment-only correction, outside proposal03.'}],'openObligations':report['open']+['Qualified Ref aliases architecture tests do not replace separately acquired Java alias-header controls','Custom policy example is uncompiled in attached latest check; later compile inference correction is outside this snapshot','Eager clause factory preflight, custom key kind/singleton switches, original/resolved/isCached, primary/repl and import* remain unfinished','Exact source-derived four-object heap closure has no instrumented per-object dump'],'compatibilityPassClaimed':False,'newBlockingSourceFinding':False,'recursiveTraversal':False,'originalChanges':[]}
(O/'report.json').write_text(json.dumps(result,indent=2)+'\n');(O/'inputs.json').write_text(json.dumps({'files':rows,'changes':[]},indent=2)+'\n')
print(json.dumps({'copiedRecords':len(rows),'sourcePaths':49,'coreSourceMatchesLatestCheck':47,'latestRawSummaries':checks[-1]['rawSummaries'],'originalChanges':[]}))
