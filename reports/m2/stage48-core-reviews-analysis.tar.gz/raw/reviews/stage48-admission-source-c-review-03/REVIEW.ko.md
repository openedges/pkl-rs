# Stage48 admission proposal03 독립 소스 검토

고정 report `548744b8…`, 49개 소스 맵 `26e9c0a5…`를 검토했다. 제안02와 공통 25개 중 9개가 바뀌었고 검토 packet에 24개 경로가 추가됐다. 이전 singleton/jar/heap 검토는 재사용했다. 새 실행·oracle·빌드·테스트·Git 명령 없이 명시 경로 143개를 복사하고 원본 SHA를 재확인했다. mutable core와 진행 중 전체 회귀는 결과로 사용하지 않았다.

## 결과와 범위

검토한 좁은 런타임 교정에서 새 blocking source finding은 찾지 못했다. 이것은 candidate release나 Java 전체 호환성 판정이 아니다. packet의 마지막 cycle-lifecycle-tests02 raw는 diagnostics 6, fixed 3, admission 15, Ref lifecycle 4건 통과이며 exit0이다. 이전 workspace 실패와 cycle class 이름 실패를 그대로 보존했다.

마지막 검사 source-before 맵과 제안03의 49개 중 47개가 일치한다. 새 `stage48_policy_probe.rs`와 그 `file_host.rs`는 이 검사 뒤 추가돼 당시 compile 결과가 없다. 이후 clippy annotation 수정과 새 workspace 성공에 관한 A의 메시지는 이 고정 packet에 귀속하지 않는다.

## Ref와 site/cache 경계

`vm.rs:6776,7208,7227`의 세 분기는 이제 동일 `StdlibKind::Singleton("pkl:ref")` descriptor를 선택한다. 따라서 canonical/fragment/percent-escaped ref가 기존 specialized Ref check와 import-only guard를 공유하고, 요청에는 authored URI를 유지한다. 새 architecture 회귀는 nullable Reference, Domain 상속/is, 정확히 한 authored edge 및 close0을 검사한다. 별칭 header의 Java 실제 비교까지 완료한 것으로 세지 않는다.

성공 site cache→CheckImport→singleton/URI cache→Resolve의 기존 검토 순서와 wrong-phase token 검증, resolved alias hit의 미등록, HasElement typed security 및 executable/continuation tracing 코드는 제안02와 같다.

새 cycle architecture 회귀는 a/b를 실제 source 완료로 한 번씩 넣고, a 초기화 실패 뒤 b의 saved import site는 partial Good를 계속 반환하며 fresh import site는 실패하는 순서를 확인한다. 반복 GC, 요청 수11, stable7 및 close slots0도 보존한다. B의 이미 봉인된 Java02 handoff `98da9940…`와 main/a/b 원문을 연결했다. Java 쿼리는 `Good.toString()`이고 Rust 회귀는 class의 diagnostic display를 검사하므로, 이 회귀만으로 API raw 동등성을 주장하지 않는다. `partial_class` 변수도 String label 비교이므로 ObjectId identity 검사라고 표현하지 않는다. full raw differential은 실제 candidate 비교의 별도 의무다.

class diagnostic의 `main#Good` 실패는 shared renderer의 Class branch가 저장된 `class.module`을 사용하고 기존 module fallback을 유지하도록 좁게 교정됐다. builtin 처리는 앞선 branch를 유지한다.

## Heap와 Host 소비자

fixed executable deltas 0→1, 1→2 및 equality 0→1, Ref values 9→5, 8→4가 이전 독립 ledger와 정확히 일치한다. value12/12/15는 그대로 두었고 새 실제 기록에서 도달·통과했다. poll/deadline/Host 오류·reentry/retry·old token 거부·close-zero를 broad bound로 바꾸지 않았다. 네 value 구성은 이전과 마찬가지로 source-derived이며 개별 object dump는 없다.

단일 주석은 ownership을 과장한다: fixed value 테스트의 executable을 'module cache'가 유지한다는 표현 대신 static block의 `Vm.executable_roots`와 URI cache의 receiver roots를 분리해야 한다. A는 후속 comment-only 교정을 수락했다. 제안03 원본에는 그 정정이 없으며 동작 blocker로 세지 않는다.

legacy `probe::finish`는 default completion마다 budget을 새로 주지 않는다. 시작 instruction count로부터 누적 소비량을 빼서 기존 finish당 1,000,000 한도를 유지한다. CheckImport와 지원되는 bundled Resolve만 명시적 shared default로 완료하고 Pending/Log/미지원 Resolve는 이전과 같이 실패한다. 초기 module과 후속 member의 각각 finish 호출 경계는 기존대로다. native adapters는 custom policy denial을 default보다 먼저 처리하며 실제 요청에만 events를 남긴다. adapter 두 파일은 미컴파일 범위를 유지한다.

## 남은 필수 의무

AST import clause factory preflight, custom factory/key kind 및 singleton 분리, isCached와 URI cache 저장 차이, primary/repl admission, import*, 더 넓은 lifecycle 정책과 실제 Java raw/native/Node/browser 검증은 열려 있다. 이번 source review나 집중 28건을 이 의무의 완료로 확대하지 않는다. Stage47 full regression도 아직 실행 중이므로 final 감사/마감 판정을 하지 않았다.
