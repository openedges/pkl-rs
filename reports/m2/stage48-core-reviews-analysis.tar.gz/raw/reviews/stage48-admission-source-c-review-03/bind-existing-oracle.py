from pathlib import Path
import hashlib,json,stat
O=Path(__file__).resolve().parent
P=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-module-admission-audit-02')
sha=lambda b:hashlib.sha256(b).hexdigest();inputs=json.loads((O/'inputs.json').read_bytes())
def copy(p,n,expected):
 b=p.read_bytes();assert stat.S_ISREG(p.lstat().st_mode) and sha(b)==expected
 dest=O/'evidence'/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 inputs['files'].append({'original':str(p),'snapshot':'evidence/'+n,'sha256':expected,'bytes':len(b),'mode':stat.S_IMODE(p.lstat().st_mode)})
 return b
handoff=json.loads(copy(P/'handoff.json','existing-java02/handoff.json','98da994057d2a15e4b6d2006b96a6435ad572a5866168f3fc8dd1786f8cdd073'))
root=Path(handoff['oracle']);report=json.loads(copy(root/'report.json','existing-java02/report.json',handoff['reportSha256']))
copy(root/'inventory.json','existing-java02/inventory.json',handoff['inventorySha256']);copy(root/'closure.json','existing-java02/closure.json',handoff['closureSha256'])
cycle=next(r for r in report['records'] if r['case']=='cycle-eager-types-partial-return-init-failure' and r['repeat']==0)
for n in ['main.pkl','a.pkl','b.pkl','operations.tsv']:copy(root/'workspace'/cycle['case']/n,'existing-java02/cycle-inputs/'+n,cycle['workspaceBefore'][n]['sha256'])
r=json.loads((O/'report.json').read_bytes());r['existingJavaControlBinding']={'handoffSha256':sha((P/'handoff.json').read_bytes()),'reportSha256':handoff['reportSha256'],'scope':handoff['apiScope'],'cycleInputs':'Exact Java main/a/b source bytes bound. Rust architecture test uses same module source text and nine queries with class diagnostic display, whereas Java queries call Good.toString; no raw API-equivalence or ObjectId identity claim from that test. No new Java/native execution.'}
(O/'report.json').write_text(json.dumps(r,indent=2)+'\n');(O/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
for row in inputs['files']:assert sha(Path(row['original']).read_bytes())==row['sha256']
print(json.dumps({'records':len(inputs['files']),'originalChanges':[]}))
