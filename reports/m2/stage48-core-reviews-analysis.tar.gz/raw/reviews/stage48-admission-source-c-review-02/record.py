from pathlib import Path
import hashlib,json,stat,re
OUT=Path(__file__).resolve().parent
P=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage48/target/m2/stage48-implementation-01/admission-review-proposal-02')
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
def copy(path,rel,expected=None):
 path=Path(path);s=path.lstat();assert stat.S_ISREG(s.st_mode),str(path)
 b=path.read_bytes();h=sha(b)
 if expected:assert h==expected,(str(path),h,expected)
 dest=OUT/'evidence'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 rows.append({'path':str(path),'snapshot':'evidence/'+rel,'sha256':h,'bytes':len(b),'mode':stat.S_IMODE(s.st_mode)})
 return b
report=json.loads(copy(P/'report.json','report.json','d61ab080052bfaea3d7e598648a68a70427cc5c0fdcb4e352f086327b70b8319'))
sm=json.loads(copy(P/'source-map.json','source-map.json','0666e9311b1abeca0354f846451f976c9360e25141fa22a3a21ed650cb93993e'))
assert len(sm)==25
copy(P/'tracked.diff','tracked.diff')
for n,h in sm.items():
 copy(P/'sources'/n,'sources/'+n,h)
 base=P/'base'/n
 if base.exists():copy(base,'base/'+n)
checks=[]
for check in report['checks']:
 root=P/'checks'/check['name'];d=json.loads(copy(root/'report.json','checks/'+check['name']+'/report.json',check['report_sha256']))
 assert d['exit_code']==check['exit_code'] and d['source_stable']
 before=copy(root/'source-before.json','checks/'+check['name']+'/source-before.json')
 after=copy(root/'source-after.json','checks/'+check['name']+'/source-after.json');assert before==after
 for n in ['stdout.bin','stderr.bin']:copy(root/n,'checks/'+check['name']+'/'+n,d[n.split('.')[0]+'_sha256'])
 checks.append({'name':check['name'],'exitCode':d['exit_code'],'sourceStable':True})
testmap=(P/'checks/admission-tests-09/source-before.json').read_bytes();assert sha(testmap)==report['tested_map_sha256'];tested=json.loads(testmap)
assert all(tested[n]==h for n,h in sm.items())
raw=(P/'checks/admission-tests-09/stdout.bin').read_text()
counts=[tuple(map(int,p)) for p in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',raw)]
assert counts==[(12,0),(4,0),(10,0),(1,3)],counts
prior=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage48-admission-plan-c-review-01')
for n in ['report.json','inputs.json','closure.json']:
 if (prior/n).exists():copy(prior/n,'prior-plan-review/'+n)
# This is an explicit path list; no directory walk or cache enumeration.
for r in rows:assert sha(Path(r['path']).read_bytes())==r['sha256'],r['path']
summary={'schema':1,'scope':'Frozen proposal02 source review, not a release/compatibility pass. No runtime, oracle, test, build, acquisition or Git command executed by reviewer. No live core read.','producerReportSha256':sha((P/'report.json').read_bytes()),'sourceMapSha256':sha((P/'source-map.json').read_bytes()),'sourcePaths':len(sm),'recordedChecks':checks,'latestRecordedResult':{'exitCode':101,'admissionPassed':12,'moduleTypesPassed':4,'referenceFrontendPassed':10,'referenceLifecyclePassed':1,'referenceLifecycleFailed':3},'priorFindingsSourceCorrected':['Decoded SSP canonical singleton receiver with untouched raw edge URI','Decoded nested jar trust marker while preserving raw nonnested recursion'],'findings':[{'id':'REF-SINGLETON-ALIAS-TYPE-PATH','source':'crates/pkl-runtime/src/vm.rs:6776,7208,7227','observation':'The import-only guard and specialized Ref type checks still select only exact authored pkl:ref. Singleton aliases pkl:ref#tag and pkl:%72ef have the same canonical receiver but select generic Declared type handling.','basis':'Pinned ModuleCache singleton switch uses decoded SSP; proposal02 canonicalizes these aliases. The preserved tests08 record already demonstrates semantic differences from replacing specialized Ref checks with generic Declared.','required':'Classify with the same canonical singleton descriptor while preserving raw admission edge/site; add URI-only alias variants for qualified Reference/Domain, generic diagnostics, inheritance and denial ordering.','actualRawReproduction':False,'coordination':'A acknowledged and reports live successor correction plus tests pending; not included in reviewed proposal02.'}],'preservedSourceProperties':['Successful site cache before CheckImport','Resolved importer and untouched edge URI','Resolved URI cache hit does not seed original alias','Wrong-phase / forged bundled identity completion rejection before state consumption','HasElement typed security provenance; raw Host errors remain separate','Executable imported receiver tracing and DeclaredRun owner/module roots','Authored Ref import now uses common ImportModule; implicit bootstrap remains separate','Specialized Ref checks retained behind an import-only lazy guard; no direct runtime type substitution'],'openObligations':report['open']+['New qualified Ref alias correction must be frozen and reviewed separately','Latest qualified guard has no completed bindings/platform/Java pass in this snapshot','Ordinary and singleton site success surviving later cycle initialization failure need actual controls','No relaxation of three failing lifecycle exact graph assertions; accounting remains open'],'compatibilityPassClaimed':False,'recursiveTraversal':False,'originalChanges':[]}
(OUT/'report.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'inputs.json').write_text(json.dumps({'files':rows,'changes':[],'recursiveTraversal':False},indent=2)+'\n')
print(json.dumps({'sourcePaths':len(sm),'records':len(rows),'recordedLatestCounts':counts,'originalChanges':[]}))
