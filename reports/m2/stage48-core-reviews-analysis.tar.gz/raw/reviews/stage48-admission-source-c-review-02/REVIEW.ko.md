# Stage48 admission proposal02 독립 소스 검토

고정 제안 `d61ab080…`와 25개 소스 맵 `0666e931…`만 검토했다. 프로덕션·Git·원본 기록 변경, Java/Rust/플랫폼 실행은 없었다. 명시 경로 94개를 복사하고 원본 SHA를 재확인했으며, cache 또는 source tree 전체 탐색은 하지 않았다.

## 구체 지적

`crates/pkl-runtime/src/vm.rs:6776,7208,7227`은 `uri == "pkl:ref"`인 경우만 qualified Ref import guard 및 기존 specialized 타입 검사를 선택한다. 반면 같은 제안의 `modules.rs:169`와 `vm/modules.rs:181`은 `pkl:ref#tag` 및 `pkl:%72ef`를 canonical ref singleton으로 연결한다. 따라서 별칭 URI의 `r.Domain`, `r.Reference`가 generic Declared 타입 경로로 갈 수 있다. 보존된 tests08은 specialized Ref를 generic Declared로 바꿨을 때 진단·generic·상속 차이가 있었음을 보여 준다. 별칭 사례 자체는 새 실행하지 않았으므로 실제 raw 불일치로 세지 않는다.

A에게 동일 singleton descriptor로 guard와 specialized 분기를 선택하되 raw edge URI와 site를 보존하도록 전달했다. A는 후속 live 소스에서 수정 및 별칭 회귀를 추가했다고 답했지만, 그 소스와 실행 결과는 이 검토에 포함하지 않았다. canonical 프로그램의 URI만 fragment/escape 별칭으로 바꾸어 Domain 상속/is, nullable Reference, 잘못된 generic 인자·진단 및 정책 거부 순서를 대조해야 한다.

## 확인한 수정과 보존 경계

이전 singleton 지적은 decoded SSP와 canonical receiver를 분리하여 수정됐다. nested jar trust marker도 decoded SSP로 판정하며 nonnested jar의 재귀 대상 raw substring은 보존한다. 일반 catalog lookup은 full raw URI를 사용한다. pinned Java `ModuleCache`의 singleton 분기와 generic catalog 구분에 맞는 방향이다.

성공한 ImportNode site cache가 새 edge check보다 우선하고, importer는 resolved identity를 쓰며 요청에는 원래 edge URI를 유지한다. resolved cache hit의 original alias 미등록, 잘못된 완료 phase와 forged bundled identity의 token 소비 전 거부, HasElement의 typed security provenance, raw Host 오류 분리, executable의 imported receiver tracing 및 DeclaredRun의 owner/module roots를 유지한다. authored `pkl:ref` expression은 공통 ImportModule로 들어가며 implicit bootstrap과 구분된다. qualified canonical Ref는 import-only guard를 먼저 force한 뒤 기존 specialized check·generic 진단·타입 recipe를 유지한다.

## 실제 기록과 미완료

tests09 raw summary는 admission 12, module-types 4, reference-frontend 10, reference-lifecycle 1건 통과와 lifecycle 3건 실패이며 전체 exit 101이다. 세 실패의 exact graph bound는 완화되지 않았다. 이전 tests04–08 및 첫 workspace check 실패를 함께 보존했다. workspace check02 성공은 tests05 당시 소스이며, 새 qualified guard의 binding compile 성공으로 확대하지 않는다.

factory preflight, primary/repl와 custom ModuleKey 종류, isCached, import*, cycle의 partial site 성공 뒤 init 실패, 기존 native Host 소비자 이행, 정밀 lifecycle 그래프 accounting 및 실제 Java/플랫폼 비교는 열려 있다. 새 임시 importer 수거 회귀도 후속 snapshot에서 확인해야 한다. 이것은 집중 소스 검토이며 Stage48 전체 semantic pass가 아니다.
