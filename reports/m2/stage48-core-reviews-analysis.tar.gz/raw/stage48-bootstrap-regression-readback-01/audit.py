from pathlib import Path
import collections,datetime,hashlib,json
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[2]
OLD=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage45/target/m2/stage45-bootstrap-platform-01')
NEW=ROOT/'target/m2/stage48-c01-bootstrap-control-01/execution'
JAVA=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42/target/m2/stage45-bootstrap-oracle-02')
inputs={}
def read(p):
 b=p.read_bytes();h=hashlib.sha256(b).hexdigest();assert str(p) not in inputs or inputs[str(p)]==h
 inputs[str(p)]=h;return b
def load(p):return json.loads(read(p))
def key(r):return (r['id'],r['repeat'],r['session'],r['prefix'])
def bytes16(u):return b''.join(x.to_bytes(2,'big')for x in u)
def bytes8(u):return bytes16(u).decode('utf-16-be','surrogatepass').encode('utf-8','replace')
old=load(OLD/'execution.json');new=load(NEW/'execution.json');fixture=load(NEW/'fixture-data.json');assert read(OLD/'fixture-data.json')==read(NEW/'fixture-data.json')
assert hashlib.sha256(read(JAVA/'report.json')).hexdigest()=='1bc3b8d085ec266196e92f6957b06b153b1aa70d0e53543878fc6c5fa74221c5'
expected={};expressions={};readers={}
for f in fixture:
 for e in f['expected']:
  k=(f['id'],f['repeat'],e['session'],e['prefix']);assert k not in expected;expected[k]=e;readers[k]=f['reader'];expressions[k]=e['expression']
  channel='stdout'if e['kind']=='value'else'stderr'
  assert read(JAVA/(e['rawPrefix']+'.'+channel+'.bin'))==bytes.fromhex(e['utf8Hex'])
  assert read(JAVA/(e['rawPrefix']+'.'+channel+'.code-units.bin'))==bytes.fromhex(e['utf16BEHex'])
assert len(expected)==600
allrows={};findings={}
for label,root,execution in [('old',OLD,old),('new',NEW,new)]:
 for target in ['node','browser']:
  rows={};recorded={key(r):r for r in execution['targets'][target]['results']};classes={}
  for group in load(root/(target+'.raw.json')):
   for s in group['sessions']:
    assert s['constructorError'] is None and s['acquisitionError'] is None and s['architecture']['terminalSlots']==0 and s['architecture']['ownedResultsStable']
    for c in s['calls']:
     k=(group['id'],group['repeat'],s['index'],c['prefix']);assert k not in rows;rows[k]=c;e=expected[k]
     directory=root/target/group['id']/str(group['repeat'])/('session-'+str(s['index']))
     assert read(directory/(c['prefix']+'.actual.utf16be.bin'))==bytes16(c['units'])
     assert read(directory/(c['prefix']+'.actual.utf8.bin'))==bytes8(c['units'])
     checks={'architecture':True,'prefix':c['prefix']==e['prefix'],'status':c['kind']==e['kind'],'units':bytes16(c['units'])==bytes.fromhex(e['utf16BEHex']),'javaUtf8':bytes8(c['units'])==bytes.fromhex(e['utf8Hex']),'disposition':c['kind']!='error'or c['disposition']=='language-error'}
     if readers[k]=='counted':checks.update(readsBefore=c['readsBefore']==e['readsBefore'],readsAfter=c['readsAfter']==e['readsAfter'])
     status='unsupported'if c['disposition']=='unsupported'else'pass'if all(checks.values())else'mismatch'
     assert checks==recorded[k]['checks'] and status==recorded[k]['status'],(label,target,k)
     classes[k]=status
  assert rows.keys()==expected.keys()==recorded.keys();allrows[label,target]=rows;findings[label,target]=classes
for label in ['old','new']:
 for k in expected:
  for field in ['prefix','kind','units','phase','disposition','reason','readsBefore','readsAfter']:
   assert allrows[label,'node'][k][field]==allrows[label,'browser'][k][field],(label,k,field)
transitions=collections.Counter();regressions=[];remaining=collections.Counter();details=[]
for k,e in expected.items():
 a=findings['old','node'][k];b=findings['new','node'][k];transitions[a+' -> '+b]+=1
 if a=='pass'and b!='pass':regressions.append(k)
 c=allrows['new','node'][k]
 raw=(c['kind']==e['kind']and bytes16(c['units'])==bytes.fromhex(e['utf16BEHex'])and bytes8(c['units'])==bytes.fromhex(e['utf8Hex']))
 counts=readers[k]!='counted'or(c['readsBefore'],c['readsAfter'])==(e['readsBefore'],e['readsAfter'])
 if b!='pass':
  if b=='unsupported':category='reflect unsupported'
  elif not raw and not counts:category='test output cross-evaluator value + counted Host mismatch'
  elif not raw:category='test output cross-evaluator value mismatch'
  else:category='counted Host mismatch only'
  if not raw and b!='unsupported':assert expressions[k] in ['t.output.renderer.getClass()','t.output.text']
  remaining[category]+=1
  details.append({'key':list(k),'expression':expressions[k],'old':a,'new':b,'category':category,'rawEqualsJava':raw,'countedReaderEqualsJava':counts,'actualReads':[c['readsBefore'],c['readsAfter']],'javaReads':[e['readsBefore'],e['readsAfter']]})
helper=ROOT/'tools/platform/bootstrap-session.mjs';probe=ROOT/'crates/pkl-runtime/src/probe.rs';resources=ROOT/'crates/pkl-runtime/src/vm/resources.rs'
for p in [helper,probe,resources]:read(p)
report={'scope':'Read-only raw readback of existing Stage45 and Stage48 C01 executions; no Java/native/browser evaluation or source edits. Same600Java API rows per target. Historical source/artifact provenance stays with original execution manifests.','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'old':str(OLD),'new':str(NEW),'fixtureIdentity':inputs[str(NEW/'fixture-data.json')],'apiRowsPerTarget':600,'targets':['node','browser'],'allCapturedRawUtf16AndJavaUtf8Verified':True,'allExpectedBytesJoinedPinnedJavaRaw':True,'allStatusesRecomputed':True,'nodeBrowserCallsEqualForBothReleases':True,'statusTransitionsPerTarget':dict(transitions),'priorPassRegressions':regressions,'remainingPerTarget':dict(remaining),'remainingDetails':details,'qualifications':['No previous194passingrow regressed in this corpus.80additionalrows nowpass;20formerlyunsupportedrows nowreach ordinary mismatch. This is corpus-specific, not absence of all possible regressions.','All144unsupportedrows are6reflect expressions across24sessions. All current value/status mismatches are test output renderer/text across evaluator sessions, consistent with previously observed JVM-global singleton cache gap.','Current bootstrap helper nonabsent replies use legacy respondString -> raw SourceProbe.respond/resume. This deliberately does not publish typed ResourceManager success cache. Counter mismatches are not evidence that Stage46typed completeReadText cache remains broken; a fresh explicitlytyped observer is required to test that contract. Absent uses respondConfigured.','Both acquisition generations remain preserved; no golden/source/event normalization or output rewrite. Full bootstrap strict gate remainsfailed.']}
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n');(OUT/'input-hashes.json').write_text(json.dumps(inputs,indent=2)+'\n')
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in inputs.items())
print(json.dumps({'statusTransitions':dict(transitions),'remaining':dict(remaining),'regressions':len(regressions),'inputs':len(inputs),'reportSha256':hashlib.sha256((OUT/'report.json').read_bytes()).hexdigest()}))
