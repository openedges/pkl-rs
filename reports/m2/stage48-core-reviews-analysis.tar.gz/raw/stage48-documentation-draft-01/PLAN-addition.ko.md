### Stage48 — 표준 모듈 admission과 import-site cache (C01 검증 진행 중)

Stage47 구현 기준 `0e13a589d43c4cb1d83f41dd1ec416cac1770fc1` 위에서 공통
엔진의 authored import에 `CheckImport`를 추가했습니다. 요청은 importer의
original/resolved URI와 prepared target URI를 보존합니다. 성공한 실행 site는
receiver를 실행 코드 상태에 저장하여 같은 site 재호출에서는 admission보다 먼저
반환하고, 다른 site는 URI cache hit여도 edge 검사를 수행합니다. 실패한 요청은
site 성공 cache를 만들지 않습니다. 순환 중 반환된 partial receiver를 저장한 site와
나중에 초기화 실패를 저장한 전역 URI cache는 별도로 유지합니다.

- `pkl:base/ref/test` 등을 포함한 pinned singleton 목록은 key resolution만 우회합니다.
  authored import-edge 검사는 유지하며 decoded SSP의 이름은 canonical receiver를
  선택하고 원래 edge URI는 바꾸지 않습니다. `pkl:json` 같은 일반 bundled module은
  original cache → Resolve → resolved cache → 내부 pinned source 초기화 순서를
  따릅니다. resolved alias hit가 original alias를 새로 seed하지 않습니다.
- qualified Ref 타입은 실제 import alias를 먼저 강제하고 기존 specialized type의
  generic·constraint·진단 정보를 보존합니다. implicit base bootstrap과 authored
  import는 분리하며, primary module identity는 표시용 source URI와 별도입니다.
- N-API/Wasm은 `completeModuleImportCheck`, `rejectModuleImportCheck`,
  `completeDefaultModule`을 공통 SourceSession에 연결합니다. default helper는
  명시적으로 호출하며 custom provider의 응답을 우회하지 않습니다. 처리 범위 밖의
  유효 요청은 `false`와 미소비 token으로 남고 stale/timeout은 오류입니다.
  CheckImport/Resolve/HasElement의 typed SecurityManagerException과 raw Host
  rejection을 구분하며 Source/Capabilities의 잘못된 typed 완료는 token을 유지합니다.

C01은 source 53,236개와 별도 symlink 11개, mode, 여섯 native artifact를 동결했습니다.
`cargo xtask verify`, fmt, workspace/all-targets Clippy, 전체 workspace test,
runtime Wasm check는 실제 종료 0입니다. workspace는 `--no-fail-fast`로 전체 target을
호출했으며 source 안정성은 각 캡처 범위와 C01 전체 map을 구분합니다. Clippy와
workspace 후의 변경은 고정 lifecycle test 주석 한 곳뿐입니다. 초기 workspace01의
9개 실패 target 및 Clippy/consumer/cycle의 실패 원본은 그대로 보존합니다.

Heap 단언 다섯 곳은 독립 소스 검토 후 정확한 값만 조정했습니다. eager Ref guard가
baseline 전에 옮긴 네 값(module·ModuleInfo annotation·Since annotation·Access
class)과 늦은 import가 추가한 실행 descriptor 한 개를 구분했습니다. 네 값의 이름은
source-derived이며 실제 object-ID dump를 취득한 것은 아닙니다. 후속 실제 회귀에서
처음 두 Ref delta 5/4, 기존 미도달 value 12/12/15, executable delta, reentry/retry,
기존 poll·deadline·stack 한도, stale token 및 close zero를 확인했습니다. 별도 임시
importer 12회 회귀는 사용자 receiver가 stale이 되는 것과 imported module 유지,
정확한 plateau를 확인합니다. cycle의 출력 label 일치를 ObjectId 실측으로 부풀리지
않습니다.

C01 native 정책 비교 440 API 및 실제 플랫폼 검증은 진행 중입니다. Java 원본 총
652 API/6,300 ordered events 중 custom SPI 212 API는 미실행으로 남고, supplied
primary profile은 Java primary/repl factory·policy event 전체와 동등하지 않습니다.
API 결과가 일치해도 full event/counter gate의 누락이나 실패를 성공으로 집계하지
않습니다. 실제 Node/Chromium 및 전체 selected 회귀 결과는 종료·원시 대조 후 별도
기록하며, 이 문안은 최종 호환성/성능 판정이 아닙니다.

다음 필수 순서는 (1) C01의 원시 오류·event 차이를 원인별로 보존·교정,
(2) URI 문자열과 독립된 ModuleKey factory/key-kind 선택 및 import-clause AST의
사전 factory 선택, (3) cached/uncached lookup과 양 cache write 계약, (4) 실제 primary
및 query/repl lifecycle·정책·공개 cancellation, (5) import* 및 완전한 URI 등가 key
의무입니다. 같은 Java 원문·실행 순서·환경·기대 채널을 유지하며, 누락된 경로를
생성 event나 default-allow fallback으로 대체하지 않습니다. 전체 M2 gate와 나머지
언어·API·성능 의무는 계속 열려 있습니다.
