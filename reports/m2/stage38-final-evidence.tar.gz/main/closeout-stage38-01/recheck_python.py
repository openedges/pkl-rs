"""Retry the unchanged Python suite while retaining the original failed check."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / 'target/m2/stage38-python-recheck-01'
OUT.mkdir(exist_ok=False)
original_path = ROOT / 'target/m2/stage38-checks-final-02/report.json'
original = json.loads(original_path.read_text())
def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def changed():
    return [name for name, expected in original['sources'].items()
            if sha(ROOT / name) != expected]
before = changed()
assert not before, before
command = [sys.executable, '-m', 'unittest', 'discover', '-s', 'tools/tests', '-v']
report = dict(schema=1, scope='Unchanged full Python discovery after final02 timeout-fixture failure; original failure retained.',
              original_report=str(original_path), original_report_sha256=sha(original_path),
              source_snapshot_report=str(original_path), source_changes_before=before,
              host=platform.platform(), python=sys.version, command=command, cwd=str(ROOT),
              helper_sha256=sha(Path(__file__)), started_epoch=time.time())
(OUT / 'started.json').write_text(json.dumps(report, indent=2) + '\n')
with (OUT / 'stdout.bin').open('wb') as stdout, (OUT / 'stderr.bin').open('wb') as stderr:
    process = subprocess.run(command, cwd=ROOT, env=dict(os.environ), stdout=stdout, stderr=stderr)
report.update(exit_code=process.returncode, elapsed_seconds=time.time() - report['started_epoch'],
              source_changes_after=changed())
for channel in ('stdout', 'stderr'):
    path = OUT / (channel + '.bin')
    report[channel] = dict(bytes=path.stat().st_size, sha256=sha(path))
report['passed'] = report['exit_code'] == 0 and not report['source_changes_after']
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
sys.exit(0 if report['passed'] else 1)
