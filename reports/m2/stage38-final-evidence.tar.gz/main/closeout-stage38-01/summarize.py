"""Summarize closed Stage 38 evidence without changing any recorded outcome."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT.parent / 'pkl-rs.stage38'
def read(path):
    return json.loads(path.read_text())
def identity(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())
def main(suffix, name='report.json'):
    return ROOT / 'target/m2' / ('stage38-' + suffix) / name
def work(suffix, name='report.json'):
    return WORK / 'target/m2' / ('stage38-' + suffix) / name

checks = read(main('checks-final-02'))
retry = read(main('python-recheck-01'))
assert checks['source_stability'] and retry['passed']
assert all(x['exit_code'] == 0 for x in checks['checks'] if x['name'] != 'python-tests')
assert retry['original_report_sha256'] == identity(main('checks-final-02'))['sha256']
language = read(main('language-final-03'))
audit = read(work('final-language-audit-01'))
assert audit['status'] == 'closed' and not audit['source_drift']
assert audit['final_report']['sha256'] == identity(main('language-final-03'))['sha256']
assert language['source_stability'] and language['artifact_stability']
independent = read(work('closeout-review-01', 'summary.json'))
assert not independent['blockers_found'] and independent['final_runtime_sources_match_MAIN']
platforms = read(work('platform-review-final-03'))
assert platforms['passed']
binding_path = ROOT / 'target/m2/closeout-stage38-01/precommit-02/report.json'
binding = read(binding_path)
assert binding['source_binding_passed']
sealed = read(main('final-seal-01'))
assert sealed['exact_membership_verified'] and sealed['extracted_bytes_verified']
assert sealed['original_bytes_unchanged']
rust_log = main('checks-final-02', 'rust-tests.stdout.bin').read_text()
rust_counts = [tuple(map(int, row)) for row in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', rust_log)]
python_log = main('python-recheck-01', 'stderr.bin').read_text()
python_count = re.search(r'Ran (\d+) tests in ', python_log)
assert python_count and python_log.rstrip().endswith('OK')
helper_gates = {}
for name in ('persistent-report', 'persistent-contract', 'trace-report', 'trace-contract'):
    path = ROOT / 'target/m2/closeout-stage38-01/processes' / name / 'process.json'
    helper_gates[name] = dict(report=identity(path), exit_code=read(path)['exit_code'])
result = dict(
    schema=1,
    scope='Stage 38 dedicated resource reads, bounded default scalar resource policy, generic method diagnostics and explicit portable string comparison. This checkpoint is closed; complete M2 remains unproven.',
    compatibility_complete=False, performance_target_claimed=False,
    base_commit='40425ed8b6d01d88038ee3f226556533cd46ae2d',
    validation=dict(
        report=identity(main('checks-final-02')), host=checks['host'],
        checks=checks['checks'], initial_full_check_passed=checks['passed'],
        python_retry_report=identity(main('python-recheck-01')), python_retry=retry,
        required_checks_passed_after_unchanged_python_retry=True,
        source_stability=True, source_files=len(checks['sources']),
        python_tests=int(python_count.group(1)), portable_driver_tests=7,
        rust_harness_pass_invocations=sum(x[0] for x in rust_counts),
        rust_ignored_invocations=sum(x[2] for x in rust_counts),
        rust_count_is_distinct_test_count=False,
        failure_note='The original 235-test run failed one 200ms child-startup timeout fixture with empty stdout. The unchanged single test passed; the unchanged full discovery passed later. Exact original child progress was not retained, so a scheduling cause is not proven. Original failure and retry are separate evidence.',
        diagnosis=identity(work('timeout-check-review-01'))),
    full_language=dict(
        report=identity(main('language-final-03')), selected=language['selected_count'],
        status_counts=language['status_counts'],
        failures=[dict(id=x['id'], status=x['status']) for x in language['results'] if x['status'] != 'pass'],
        metamorphic_relations=len(language['metamorphic_results']),
        metamorphic_counts=audit['metamorphic_counts'],
        full_gate_failure_reasons=len(language['full_gate_failures']),
        inventory=language['inventory_counts'], source_stability=True, artifact_stability=True,
        candidate=language['candidate'], regression_audit=identity(work('final-language-audit-01')),
        regression_summary=audit['regression_summary'], gates=audit['gates'],
        new100_outcomes=audit['new100_outcomes'],
        exactly_two_power_cases=audit['two_power_cases'],
        original_Java_cycle_variation_preserved=True,
        legacy_classification=audit['legacy_sourcepath_internal_error_classification']),
    persistent=independent['persistent'], native_trace=independent['native_trace'],
    standard_platforms=independent['standard_platform'],
    additional_platforms=independent['additional_platform_sets'],
    denominator_note=independent['denominators_must_not_be_summed'],
    offline_gates=helper_gates,
    source_binding=dict(report=identity(binding_path), distinct_source_paths=binding['distinct_source_paths'],
                        current_and_snapshots_match=True, committed_binding='reports/m2/stage38-source-binding.json'),
    archive=sealed,
    origin_captures=read(ROOT / 'reports/m2/stage38-origin-captures.json'),
    candidate_captures=dict(report=identity(ROOT / 'reports/m2/stage38-candidate-captures.json'),
                           archive=identity(ROOT / 'reports/m2/stage38-candidate-evidence.tar.gz')),
    independent_audits=[identity(work('final-language-audit-01')), identity(work('closeout-review-01')),
                        identity(work('platform-review-final-03')), identity(work('main-integration-audit-01'))],
    next_scope_design=identity(work('upstream-error-adapter-design-01')),
    remaining=[
        'All nine M2 workstreams retain unmet completion conditions; selected pass rates do not measure overall progress.',
        'Original cycle error, remainder-zero, mapped-list SourceCode and legacy String.repeat failures remain. D800 URI and three HTTP Java internal-error inputs remain failures.',
        'The source-path harness retains three HTTP PklBugException cases as mismatches; the portable harness explicitly classifies them as oracle errors. Neither is a pass.',
        'Allowed resource file/network/package I/O, complete URI parsing and lone UTF16 surrogate URI transport, module loading/cache and general optional Host absence remain open.',
        'Persistent unexecuted groups, full syntax/type/reflection/collection/diagnostic semantics and original upstream corpus mapping remain open.',
        'The 960 unimplemented and 40 unmapped accounting rows are unchanged. The next scope connects 72 original upstream frontend error eval contracts.',
        'Local macOS and actual Node/Chromium evidence does not establish Linux/Windows/release platform or speed/peak-RSS goals.',
    ])
destination = ROOT / 'reports/m2/stage38-final-summary.json'
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(summary=identity(destination), selected=language['selected_count'],
                     counts=language['status_counts'], python_tests=int(python_count.group(1)),
                     rust_harness_pass_invocations=result['validation']['rust_harness_pass_invocations'],
                     bound_source_paths=binding['distinct_source_paths'])), flush=True)
