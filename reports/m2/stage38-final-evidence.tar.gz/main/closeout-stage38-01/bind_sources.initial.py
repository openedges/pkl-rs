"""Bind all final Stage38 acquisition source maps to current bytes and a Git commit."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT.parent / 'pkl-rs.stage38'
parser = argparse.ArgumentParser()
parser.add_argument('--commit')
parser.add_argument('--output', required=True)
args = parser.parse_args()
out = ROOT / args.output
out.mkdir(parents=True, exist_ok=False)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

specs = {
    'checks': ('stage38-checks-final-02/report.json', 'sources'),
    'language': ('stage38-language-final-03/report.json', 'source_sha256'),
    'persistent': ('stage38-persistent-final-02/report.json', 'sources'),
    'trace': ('stage38-trace-final-02/report.json', 'sources'),
    'standard_platforms': ('stage38-platforms-final-03/report.json', 'source_hashes'),
}
sources = {}
helpers = {}
suites = {}

def add(name, expected, suite, snapshot=None):
    path = ROOT / name
    assert path.is_file() and sha(path) == expected, (suite, name, 'current source')
    if snapshot is not None:
        assert snapshot.is_file() and sha(snapshot) == expected, (suite, name, 'snapshot')
    if name == 'target/m2/stage38-runner-tools-01/checks.py':
        helpers[name] = expected
        return
    assert not name.startswith(('target/', '/')), name
    if name in sources:
        assert sources[name]['sha256'] == expected, (suite, name, 'cross-suite drift')
    else:
        sources[name] = {'sha256': expected, 'suites': []}
    if suite not in sources[name]['suites']:
        sources[name]['suites'].append(suite)

for suite, (relative, field) in specs.items():
    base = WORK if suite == 'standard_platforms' else ROOT
    path = base / 'target/m2' / relative
    report = read(path)
    records = report[field]
    if isinstance(records, dict):
        records = [{'path': k, 'sha256': v, 'snapshot': 'sources/' + k}
                   for k, v in records.items()]
    for record in records:
        add(record['path'], record['sha256'], suite, path.parent / record['snapshot'])
    suites[suite] = {'report': str(path), 'sha256': sha(path),
                     'recorded_sources': len(records)}

fixtures = {x['id']: x['input'] for x in read(ROOT / 'tests/fixtures/m2/cases.json')['cases']}
for suite, folder in [('reads_platforms', 'stage38-read91-platform-final-03'),
                      ('method_order_platforms', 'stage38-method-order9-platform-final-03'),
                      ('scalar_trace_platforms', 'stage38-trace18-platform-final-03'),
                      ('repeat_platforms', 'stage38-repeat20-platform-final-03')]:
    path = WORK / 'target/m2' / folder / 'execution.json'
    report = read(path)
    for key, expected in report['sourceHashes'].items():
        name = fixtures[key]
        add(name, expected, suite, ROOT / 'target/m2/stage38-language-final-03/sources' / name)
    for name, expected in report['artifactHashes'].items():
        assert sha(WORK / name) == expected, name
        if not name.startswith('target/'):
            add(name, expected, suite)
    suites[suite] = {'report': str(path), 'sha256': sha(path),
                     'recorded_source_inputs': len(report['sourceHashes']),
                     'verified_artifact_and_driver_bindings': len(report['artifactHashes'])}

path = WORK / 'target/m2/stage38-trace42-platform-final-03/execution.json'
report = read(path)
for absolute, expected in report['artifactAndInputHashes'].items():
    source = Path(absolute)
    assert source.is_file() and sha(source) == expected, absolute
    name = str(source.relative_to(WORK))
    if not name.startswith('target/'):
        add(name, expected, 'trace_platforms')
suites['trace_platforms'] = {'report': str(path), 'sha256': sha(path),
                            'verified_artifact_and_input_bindings': len(report['artifactAndInputHashes'])}

if args.commit:
    commit = subprocess.check_output(['git', 'rev-parse', args.commit + '^{commit}'], cwd=ROOT).decode().strip()
    tree = subprocess.check_output(['git', 'ls-tree', '-r', '-z', commit], cwd=ROOT)
    blobs = {}
    for entry in tree.split(b'\0'):
        if not entry:
            continue
        metadata, name = entry.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        if kind == 'blob':
            blobs[name.decode()] = oid
    cat = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=ROOT,
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for name, record in sorted(sources.items()):
        assert name in blobs, ('uncommitted source', name)
        oid = blobs[name]
        cat.stdin.write((oid + '\n').encode())
        cat.stdin.flush()
        returned, kind, size = cat.stdout.readline().decode().split()
        assert returned == oid and kind == 'blob'
        content = cat.stdout.read(int(size))
        assert cat.stdout.read(1) == b'\n'
        assert hashlib.sha256(content).hexdigest() == record['sha256'], name
        record['git_blob'] = oid
    cat.stdin.close()
    assert cat.wait() == 0
else:
    commit = None

result = {
    'scope': 'Exact source identity for all Stage38 final checks and native/Node/Chromium acquisitions. Intermediate failed sources remain separate historical evidence.',
    'implementation_commit': commit,
    'source_binding_passed': True,
    'git_binding_performed': commit is not None,
    'compatibility_complete': False,
    'distinct_source_paths': len(sources),
    'suites': suites,
    'files': dict(sorted(sources.items())),
    'ignored_captured_helpers': helpers,
    'references_lock_sha256': sha(ROOT / 'references.lock'),
    'helper_sha256': sha(Path(__file__)),
}
(out / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
if commit:
    destination = ROOT / 'reports/m2/stage38-source-binding.json'
    assert not destination.exists()
    destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('files', 'suites')}), flush=True)
