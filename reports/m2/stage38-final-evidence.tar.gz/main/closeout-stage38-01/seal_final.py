"""Preserve explicitly selected closed Stage 38 acquisitions and closeout inputs."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT.parent / 'pkl-rs.stage38'
OUT = ROOT / 'target/m2/stage38-final-seal-01'
OUT.mkdir(exist_ok=False)
SUFFIXES = [
    'checks-final-01', 'checks-final-02', 'handoff-01', 'integration-01',
    'language-command-final-01', 'language-command-final-02', 'language-command-final-03',
    'language-final-02', 'language-final-03', 'origins-seal-01',
    'persistent-command-final-01', 'persistent-command-final-02',
    'persistent-final-01', 'persistent-final-02', 'runner-tools-01', 'python-recheck-01',
    'trace-command-final-01', 'trace-command-final-02', 'trace-final-01', 'trace-final-02',
]
WORK_SUFFIXES = ['final-language-audit-01', 'upstream-error-adapter-design-01', 'closeout-review-01',
                 'timeout-check-review-01']
EXCLUDED = {ROOT / 'target/m2' / ('stage38-' + suffix) / 'build'
            for suffix in ['persistent-final-01', 'persistent-final-02', 'trace-final-01', 'trace-final-02']}
selected = [(ROOT, ROOT / 'target/m2' / ('stage38-' + s), 'main') for s in SUFFIXES]
selected += [(WORK, WORK / 'target/m2' / ('stage38-' + s), 'worktree') for s in WORK_SUFFIXES]
# The closeout directory is a point-in-time snapshot. Later commit/push receipts
# are intentionally recorded in the separate tracked completion record.
selected.append((ROOT, Path(__file__).parent, 'main'))
files = {}

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def add(base, path, label):
    assert path.is_file() and not path.is_symlink(), path
    key = label + '/' + path.relative_to(base / 'target/m2').as_posix()
    assert key not in files, key
    files[key] = dict(origin=str(path), bytes=path.stat().st_size, sha256=sha(path))

for base, folder, label in selected:
    assert folder.is_dir(), folder
    for directory, directories, names in os.walk(folder, followlinks=False):
        directories[:] = sorted(d for d in directories
                                if Path(directory) / d not in EXCLUDED and d != '__pycache__')
        for name in sorted(names):
            add(base, Path(directory) / name, label)
    for path in sorted(folder.parent.glob(folder.name + '.*.log')):
        add(base, path, label)

# The candidate archive contains its creation inputs. Retain the subsequent
# independent verification and closure without duplicating its archive bytes.
candidate_seal = WORK / 'target/m2/stage38-candidate-seal-01'
for name in ['report.json', 'verification.json', 'verify_extracted.py', 'closure.json',
             'create.stdout.log', 'create.stderr.log', 'verify.stdout.log', 'verify.stderr.log',
             'REPORT.md', 'creation.json', 'previous-unarchived-files.json']:
    add(WORK, candidate_seal / name, 'worktree')

inventory = dict(schema=1, scope='Closed Stage 38 MAIN final and prior acquisitions, independent audits, and closeout helper snapshot.',
                 roots=[str(p) for _, p, _ in selected], files=files,
                 excluded_before_traversal=sorted(map(str, EXCLUDED)),
                 closeout_snapshot_excludes_future_commit_receipts=True,
                 helper_sha256=sha(Path(__file__)))
encoded = (json.dumps(inventory, indent=2, sort_keys=True) + '\n').encode()
(OUT / 'inventory.json').write_bytes(encoded)
destination = ROOT / 'reports/m2/stage38-final-evidence.tar.gz'
with destination.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as archive:
    for name, row in sorted(files.items()):
        path = Path(row['origin'])
        assert sha(path) == row['sha256'], path
        info = archive.gettarinfo(str(path), arcname=name)
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        with path.open('rb') as stream:
            archive.addfile(info, stream)
    info = tarfile.TarInfo('inventory.json')
    info.size = len(encoded)
    archive.addfile(info, io.BytesIO(encoded))
seen = set()
with tarfile.open(destination, 'r:gz') as archive:
    for member in archive:
        assert member.name not in seen, member.name
        seen.add(member.name)
        data = archive.extractfile(member).read()
        if member.name == 'inventory.json':
            assert data == encoded
        else:
            row = files[member.name]
            assert len(data) == row['bytes']
            assert hashlib.sha256(data).hexdigest() == row['sha256']
            assert sha(Path(row['origin'])) == row['sha256']
assert seen == set(files) | {'inventory.json'}
result = dict(path=str(destination.relative_to(ROOT)), bytes=destination.stat().st_size,
              sha256=sha(destination), original_files=len(files), inventory_files=len(seen),
              inventory_sha256=hashlib.sha256(encoded).hexdigest(), exact_membership_verified=True,
              extracted_bytes_verified=True, original_bytes_unchanged=True,
              excluded_before_traversal=sorted(map(str, EXCLUDED)))
assert result['bytes'] < 100 * 1024 * 1024, result['bytes']
(OUT / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result), flush=True)
