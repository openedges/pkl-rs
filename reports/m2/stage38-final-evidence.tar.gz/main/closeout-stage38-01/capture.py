"""Capture one Stage 38 closeout command, including its unmodified output and exit code."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
out = Path(__file__).parent / 'processes' / sys.argv[1]
out.mkdir(parents=True, exist_ok=False)
command = sys.argv[2:]
start = time.time()
with (out / 'stdout.bin').open('wb') as stdout, (out / 'stderr.bin').open('wb') as stderr:
    result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
report = {'command': command, 'cwd': str(ROOT), 'started_epoch': start,
          'elapsed_seconds': time.time() - start, 'exit_code': result.returncode}
for name in ['stdout.bin', 'stderr.bin']:
    data = (out / name).read_bytes()
    report[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
(out / 'process.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
sys.exit(result.returncode)
