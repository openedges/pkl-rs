from pathlib import Path
import json,hashlib,os,stat,concurrent.futures,time,collections
OUT=Path(__file__).parent;BASE=OUT.parent;REPO=BASE.parents[1]
COMMIT='a3eb3634558cef6f36189320498fe7e013296c48';TREE='b559dbaf8895408503e4ed14d994766d71f6e833'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
rows=json.loads((OUT/'selection-before-hash.json').read_bytes())['entries'];statuses=json.loads((OUT/'root-status-before-hash.json').read_bytes())['roots'];issues=[]
def verify(row):
 p=Path(row['source']);info=p.lstat();data=os.fsencode(os.readlink(p))if row['kind']=='symlink'else(p.read_bytes()if info.st_size else b'');h=hashlib.sha256(data).hexdigest();result=dict(row,sha256=h,verifiedBytes=len(data));errors=[]
 if len(data)!=row['bytes']:errors.append('size changed since enumeration')
 if row['expectedSha256']is not None and h!=row['expectedSha256']:errors.append('original inventory/baseline SHA differs')
 if row['expectedBytes']is not None and len(data)!=row['expectedBytes']:errors.append('original inventory byte length differs')
 if row['kind']=='symlink'and not stat.S_ISLNK(info.st_mode):errors.append('symlink kind changed')
 if row['kind']=='file'and not stat.S_ISREG(info.st_mode):errors.append('regular kind changed')
 result['identityIssues']=errors;return result
with concurrent.futures.ThreadPoolExecutor(max_workers=8)as pool:verified=list(pool.map(verify,rows))
for row in verified:
 if row['identityIssues']:issues.append({'source':row['source'],'issues':row['identityIssues']})
# Preserve original historical seals exactly; snapshots of unsealed roots are not retroactively sealed.
for status in statuses:
 root=Path(status['root'])
 if status['historicalSeal']=='present':
  if sha(root/'inventory.json')!=status['originalInventorySha256']or sha(root/'closure.json')!=status['originalClosureSha256']:issues.append({'source':str(root),'issues':['original seal metadata changed during selection']})
  if not status['inventorySealMatches']:issues.append({'source':str(root),'issues':['historical inventory/closure SHA mismatch']})
index_path=REPO/'target/m2/stage46-index-binding-03/file-bindings.json';index=json.loads(index_path.read_bytes());proof=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage46-core-publication-selection-01/git-source-binding.json')
if sha(index_path)!='d2b6ea6369af0f6345e068b58983fe53f1503522b9a65a813056b271317a13b4':raise ValueError('index03 binding map differs')
if sha(proof)!='4a7b142fd8c383938e904e49bd484bec5397006c7192be1d7e1d34867a662862':raise ValueError('independent Git proof differs')
links=[];kept_transforms=[];link_by_source={}
def target(row):
 relative=row['path']
 if row['root']=='stage46-original-read-workspace-01'and relative.startswith('workspace/'):return relative[len('workspace/'):],'managed reference/input workspace source copy'
 if relative.startswith('workspace/tests/fixtures/'):
  value=relative[len('workspace/'):];value=value.replace('tests/fixtures/m2-resource-portable-final/','tests/fixtures/m2-resource-portable/');return value,'copied Git golden fixture'
 if relative.startswith('workspace/tools/')or relative.startswith('workspace/crates/'):return relative[len('workspace/'):],'copied helper/test/example source'
 if relative.startswith('upstream/'):return 'external/pkl/'+relative[len('upstream/'):],'captured pinned reference source copy'
 if relative.startswith('tool-sources/'):return relative[len('tool-sources/'):],'captured verifier/reference-lock source copy'
 if relative=='consumer.rs':return 'crates/pkl-runtime/examples/stage46_resource_probe.rs','captured Resource consumer source copy'
 if relative=='comparator.py':return('tools/m2_file_triple_compare.py'if 'file-'in row['root']else'tools/m2_resource_compare.py'),'captured comparator source copy'
 return None,None
for row in verified:
 name,reason=target(row)
 if name is None:continue
 binding=index.get(name)
 if binding is None:continue
 if binding['gitBlobSha256']!=row['sha256']or binding['blobSize']!=row['bytes']:
  if binding.get('declaredGitCheckoutTransform'):kept_transforms.append({'source':row['source'],'repositoryPath':name,'originalSha256':row['sha256'],'gitBlobSha256':binding['gitBlobSha256'],'reason':'Actual checkout bytes differ from Git blob; original raw bytes retained, no transform/normalization applied'})
  continue
 expected_kind='symlink'if binding['gitMode']=='120000'else'file'
 if row['kind']!=expected_kind:continue
 if not binding['blobObjectSha1Verified']:raise ValueError('unverified Git blob offered')
 repository=binding['repository'];link={'originalSource':row['source'],'originalRoot':row['root'],'originalPath':row['path'],'kind':row['kind'],'bytes':row['bytes'],'sha256':row['sha256'],'originalMode':row['mode'],'repositoryPath':name,'repository':repository,'commit':COMMIT if repository=='.'else binding['pin'],'mainCommit':COMMIT,'mainTree':TREE,'gitMode':binding['gitMode'],'gitBlob':binding['gitBlob'],'gitBlobSha256':binding['gitBlobSha256'],'gitBlobSize':binding['blobSize'],'byteIdentical':True,'role':reason,'independentGitVerificationReport':str(proof),'independentGitVerificationReportSha256':sha(proof)};links.append(link);link_by_source[row['source']]=link
# Canonical acquisition and comparison raw channels remain payload regardless of content equality elsewhere.
minimal=[row for row in verified if row['source']not in link_by_source];groups=collections.defaultdict(lambda:{'fullRegularFiles':0,'fullRegularBytes':0,'symlinks':0,'gitLinkedFiles':0,'gitLinkedBytes':0,'archivePayloadRegularFiles':0,'archivePayloadRegularBytes':0})
for row in verified:
 g=groups[row['logicalGroup']]
 if row['kind']=='file':g['fullRegularFiles']+=1;g['fullRegularBytes']+=row['bytes']
 else:g['symlinks']+=1
 if row['source']in link_by_source:g['gitLinkedFiles']+=1;g['gitLinkedBytes']+=row['bytes']
 elif row['kind']=='file':g['archivePayloadRegularFiles']+=1;g['archivePayloadRegularBytes']+=row['bytes']
# Record process/terminal coverage without inventing old absent outer terminals.
terminal_rows=[]
for row in verified:
 name=Path(row['path']).name
 if row['kind']!='file'or not(name.endswith('.terminal.json')or name in {'terminal.json','outer-terminal.json','tool-session.json','process.json'}or name.endswith('.process.json')):continue
 try:value=json.loads(Path(row['source']).read_bytes())
 except(ValueError,UnicodeDecodeError):continue
 code=value.get('exitCode',value.get('exit_code',value.get('observedFinalExitCode',value.get('observedExitCode'))));nested=value.get('result',{})
 if code is None and isinstance(nested,dict):code=nested.get('exit_code')
 terminal_rows.append({'root':row['root'],'path':row['path'],'source':row['source'],'sha256':row['sha256'],'recordedPid':value.get('pid'),'recordedExitCode':code,'recordedTimedOut':value.get('timedOut',value.get('timed_out',nested.get('timed_out')if isinstance(nested,dict)else None)),'recordedToolHandle':value.get('handle',value.get('toolHandle')),'scope':'Raw recorded process/tool terminal only; an absent outer terminal is not synthesized'})
by_terminal=collections.defaultdict(list)
for item in terminal_rows:by_terminal[item['root']].append(item)
for status in statuses:
 status['recordedTerminalProcessFiles']=len(by_terminal[status['name']]);status['outerTerminalRecorded']=any(Path(v['path']).name in {'outer-terminal.json','terminal.json'}and'/'not in v['path']for v in by_terminal[status['name']]);status['recordedProcessExitCounts']=dict(collections.Counter(str(v['recordedExitCode'])for v in by_terminal[status['name']]if v['recordedExitCode']is not None));status['terminalQualification']='Actual stored terminal/process metadata listed; no live-process inference from old/reused PIDs. Missing metadata remains unconfirmed.'
put(OUT/'archive-selection-full.json',{'schema':1,'entries':verified,'sourcePathsExplicit':True,'noOriginalMutation':True});put(OUT/'archive-selection-minimal.json',{'schema':1,'entries':minimal,'requiresGitBlobLinks':'git-blob-links.json','selectionMeaning':'Optional archive payload view: exclude only exact byte-identical committed/pinned source and copied golden reconstruction links; canonical raw observations and different bytes retained','noOriginalDeletion':True});put(OUT/'git-blob-links.json',{'schema':1,'mainCommit':COMMIT,'mainTree':TREE,'indexBindingPath':str(index_path),'indexBindingSha256':sha(index_path),'independentGitVerificationReport':str(proof),'independentGitVerificationReportSha256':sha(proof),'entries':links,'declaredTransformOriginalsKept':kept_transforms,'noGitProcessInvokedByThisSelection':True});put(OUT/'root-status.json',{'roots':statuses});put(OUT/'terminal-process-coverage.json',{'records':terminal_rows,'qualification':'Historical null seals, missing outer terminals, and not-reached initial failures remain distinct from recorded childprocess results'});put(OUT/'identity-issues.json',{'issues':issues});put(OUT/'logical-group-counts.json',{'groups':dict(groups)});report={'roots':len(statuses),'historicallySealedRoots':sum(s['historicalSeal']=='present'for s in statuses),'historicallyUnsealedRoots':sum(s['historicalSeal']is None for s in statuses),'fullRegularFiles':sum(v['kind']=='file'for v in verified),'fullSymlinks':sum(v['kind']=='symlink'for v in verified),'fullRegularBytes':sum(v['bytes']for v in verified if v['kind']=='file'),'gitLinkedEntries':len(links),'gitLinkedBytes':sum(v['bytes']for v in links),'minimalRegularFiles':sum(v['kind']=='file'for v in minimal),'minimalRegularBytes':sum(v['bytes']for v in minimal if v['kind']=='file'),'minimalSymlinks':sum(v['kind']=='symlink'for v in minimal),'rawTransformDifferencesKept':len(kept_transforms),'identityIssues':len(issues),'missingInventoryBaselinePaths':sum(len(s['missingOriginalPaths'])for s in statuses),'storedTerminalProcessRecords':len(terminal_rows),'originalRootsModified':0,'archivesCreated':0,'gitOperations':0};put(OUT/'verification-summary.json',report);print(json.dumps(report,indent=2),flush=True)
if issues:raise SystemExit(1)
