from pathlib import Path
import json,hashlib,os,stat,time
BASE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46/target/m2');OUT=Path(__file__).parent
owners=json.loads((OUT/'selected-roots.json').read_bytes())['roots'];prunes=json.loads((OUT/'prewalk-prunes.json').read_bytes())
def indexed(rows):
 values={v['path']for v in rows};return values,tuple(v+'/'for v in values)
PAYLOAD=indexed(prunes['excludePayloadAndTraversal']);TRAVERSAL=indexed(prunes['skipTraversalButKeepExplicitInventoryArtifacts'])
def under(path,index):
 value=os.fspath(path);return value in index[0]or value.startswith(index[1])
def put(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
entries={};statuses=[];unknown=[];directories=[];issues=[]
def add(root,path,basis,pin=None):
 info=path.lstat();mode=info.st_mode;relative=path.relative_to(root).as_posix()
 if stat.S_ISDIR(mode):directories.append({'root':str(root),'path':relative,'source':str(path),'kind':'directory'});return
 if stat.S_ISLNK(mode):target=os.readlink(path);kind='symlink';size=len(os.fsencode(target))
 elif stat.S_ISREG(mode):target=None;kind='file';size=info.st_size
 else:issues.append({'source':str(path),'reason':'unsupported nonregular entry'});return
 row={'root':root.name,'path':relative,'source':str(path),'kind':kind,'bytes':size,'mode':stat.S_IMODE(mode),'sha256':None,'expectedSha256':pin.get('sha256')if pin else None,'expectedBytes':pin.get('bytes')if pin else None,'selectionBasis':basis,'archivePath':root.name+'/'+relative}
 if target is not None:row['linkTarget']=target
 if str(path)not in entries:entries[str(path)]=row

def producer_dirs(value,root,known):
 if isinstance(value,dict):
  for key,item in value.items():
   if key in {'HOME','TMP','TEMP','TMPDIR'}and isinstance(item,str)and item.startswith(str(root)+'/'):
    path=Path(item);known.add(path)
    for parent in path.parents:
     if parent==root.parent:break
     known.add(parent)
   elif isinstance(item,(dict,list)):producer_dirs(item,root,known)
 elif isinstance(value,list):
  for item in value:producer_dirs(item,root,known)

for index,owner in enumerate(owners):
 root=Path(owner['root']);inventory=root/'inventory.json';closure=root/'closure.json';sealed=inventory.exists()and closure.exists();known={root};original_files=set();status={'name':root.name,'root':str(root),'logicalGroup':owner['logicalGroup'],'originalInventorySha256':digest(inventory)if inventory.exists()else None,'originalClosureSha256':digest(closure)if closure.exists()else None,'historicalSeal':'present'if sealed else None,'missingOriginalPaths':[],'unlistedPaths':[]}
 if sealed:
  inv=json.loads(inventory.read_bytes());closed=json.loads(closure.read_bytes());status['originalClosure']=closed;status['inventorySealMatches']=status['originalInventorySha256']==closed.get('inventorySha256')
  rows=inv['files']if isinstance(inv,dict)else inv
  for item in rows:
   relative=Path(item['path'])
   if relative.is_absolute()or'..'in relative.parts:raise ValueError('unsafe inventory path')
   path=root/relative
   if under(path,PAYLOAD):status.setdefault('prunedInventoryPaths',[]).append(str(path));continue
   if not path.exists()and not path.is_symlink():status['missingOriginalPaths'].append(item['path']);continue
   add(root,path,'sealed-inventory',item);original_files.add(path)
   for parent in path.parents:
    if parent==root.parent:break
    known.add(parent)
  for path in [inventory,closure]:add(root,path,'original-seal-metadata');original_files.add(path)
  for path in [root/'report.json',root/'profile.json']:
   if path.exists():producer_dirs(json.loads(path.read_bytes()),root,known)
  pending=[root]
  while pending:
   directory=pending.pop()
   if under(directory,PAYLOAD)or under(directory,TRAVERSAL):continue
   with os.scandir(directory)as scanned:
    for entry in scanned:
     path=Path(entry.path)
     if under(path,PAYLOAD)or under(path,TRAVERSAL):continue
     mode=entry.stat(follow_symlinks=False).st_mode
     if stat.S_ISDIR(mode):
      if path in known:pending.append(path)
      else:
       item={'root':root.name,'source':str(path),'reason':'Directory absent from sealed payload/known producer directories; not descended'};unknown.append(item);status['unlistedPaths'].append({'path':path.relative_to(root).as_posix(),'kind':'directory','notDescended':True})
     elif path not in original_files:add(root,path,'unlisted-after-historical-seal');status['unlistedPaths'].append({'path':path.relative_to(root).as_posix(),'kind':'unlisted-file'})
  status['selectionMode']='direct sealed inventory plus guarded known-directory extra check'
 elif root.name=='stage46-original-read-workspace-01':
  work=root/'workspace';baseline=BASE/'stage46-original-read-java-01/workspace-baseline.json';rows=json.loads(baseline.read_bytes())
  for relative,item in rows.items():
   path=work/relative
   if not path.exists()and not path.is_symlink():status['missingOriginalPaths'].append('workspace/'+relative);continue
   add(root,path,'pinned-managed-workspace-baseline',item)
  add(root,work/'.pkl-rs-compat-workspace.json','managed-workspace-marker');status.update(baseline=str(baseline),baselineSha256=digest(baseline),selectionMode='exact frozen input baseline paths; private/generated scratch explicitly excluded')
 else:
  pending=[root]
  while pending:
   directory=pending.pop()
   if under(directory,PAYLOAD)or under(directory,TRAVERSAL):continue
   with os.scandir(directory)as scanned:
    for entry in scanned:
     path=Path(entry.path)
     if under(path,PAYLOAD)or under(path,TRAVERSAL):continue
     if entry.is_dir(follow_symlinks=False):pending.append(path);directories.append({'root':str(root),'path':path.relative_to(root).as_posix(),'source':str(path),'kind':'directory'})
     else:add(root,path,'unsealed-current-readonly-snapshot')
  if root.name in {'stage46-triple-dot-oracle-01','stage46-triple-order-oracle-01'}:
   report=json.loads((root/'report.json').read_bytes())
   for process in report['records']:
    cache=Path(process['environment']['HOME'])/'Library/Caches'
    for suffix,pin in prunes['knownJvmRuntimeArtifactSuffixes'].items():
     path=cache/suffix
     if path.is_file():add(root,path,'direct-known-pinned-jvm-cache-artifact',pin)
  status['selectionMode']='unsealed current snapshot with exact prewalk pruning; historical seal remains null'
 statuses.append(status);print(json.dumps({'completedRoots':index+1,'lastRoot':root.name,'selectedPaths':len(entries)}),flush=True)
rows=sorted(entries.values(),key=lambda v:(v['root'],v['path']));groups={o['name']:o['logicalGroup']for o in owners}
for row in rows:row['logicalGroup']=groups[row['root']]
put(OUT/'selection-before-hash.json',{'schema':1,'entries':rows});put(OUT/'root-status-before-hash.json',{'roots':statuses});put(OUT/'unlisted-subtrees.json',{'directoriesNotDescended':unknown,'otherIssues':issues});put(OUT/'directory-metadata.json',{'directories':directories});counts={'roots':len(statuses),'sealed':sum(v['historicalSeal']=='present'for v in statuses),'unsealed':sum(v['historicalSeal']is None for v in statuses),'regularFiles':sum(v['kind']=='file'for v in rows),'symlinks':sum(v['kind']=='symlink'for v in rows),'rawRegularBytes':sum(v['bytes']for v in rows if v['kind']=='file'),'symlinkTargetBytes':sum(v['bytes']for v in rows if v['kind']=='symlink'),'unlistedDirectoriesNotDescended':len(unknown),'missingOriginalInventoryBaselinePaths':sum(len(v['missingOriginalPaths'])for v in statuses),'hashVerification':'pending; no archive created'};put(OUT/'counts-before-hash.json',counts);print(json.dumps(counts,indent=2),flush=True)
