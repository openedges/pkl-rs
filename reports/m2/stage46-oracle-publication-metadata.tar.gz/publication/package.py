"""Package explicitly selected Stage46 B evidence; no original, evaluator, build or Git writes."""
from pathlib import Path
import collections,concurrent.futures,hashlib,json,os,shutil,subprocess,sys,tarfile,time
OUT=Path(__file__).parent;BASE=OUT.parent;SELECTION=BASE/'stage46-oracle-native-publication-selection-01';EVIDENCE=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46/tools/evidence.py')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def safe(root,name):
 part=Path(name)
 if part.is_absolute()or'..'in part.parts:raise ValueError('unsafe gathered path')
 return root/part

def command(name,args):
 start=time.time_ns();stdout=OUT/'processes'/(name+'.stdout.bin');stderr=OUT/'processes'/(name+'.stderr.bin');stdout.parent.mkdir(exist_ok=True)
 with stdout.open('wb')as out,stderr.open('wb')as err:
  proc=subprocess.Popen(args,stdout=out,stderr=err,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'));put(OUT/'processes'/(name+'.launch.json'),{'pid':proc.pid,'command':args,'launchStartedUnixNs':start,'launchRecordedUnixNs':time.time_ns()});code=proc.wait()
 row={'pid':proc.pid,'exitCode':code,'finishedUnixNs':time.time_ns(),'stdoutSha256':sha(stdout),'stderrSha256':sha(stderr)};put(OUT/'processes'/(name+'.terminal.json'),row)
 if code:raise ValueError('evidence command failed: '+name)
 return row

full=json.loads((SELECTION/'archive-selection-full.json').read_bytes())['entries'];selected=json.loads((SELECTION/'archive-selection-minimal.json').read_bytes())['entries'];links=json.loads((SELECTION/'git-blob-links.json').read_bytes());status=json.loads((SELECTION/'root-status-final.json').read_bytes());directories=json.loads((SELECTION/'directory-metadata.json').read_bytes())['directories'];owner_group={v['name']:v['logicalGroup']for v in status['roots']};groups=collections.defaultdict(list)
for row in selected:groups[row['logicalGroup']].append(row)
put(OUT/'exclusions.json',{'declaredBeforeAnyGatherWalk':True,'sourcePaths':'Explicit immutable selection only; no original directory traversal','cachePrunes':str(SELECTION/'prewalk-prunes-final.json'),'cleanGather':'New gathered directory contains only explicitly copied regular files and literal-symlink metadata; retained JVM runtime artifact path names are archive data, not live caches','genericDirectoryExclusions':[],'archiveLimitBytes':100000000,'noArbitrary48MiBRegeneration':True})
put(OUT/'selection-binding.json',{'handoff':str(SELECTION/'handoff.json'),'handoffSha256':sha(SELECTION/'handoff.json'),'minimalSelectionSha256':sha(SELECTION/'archive-selection-minimal.json'),'fullSelectionSha256':sha(SELECTION/'archive-selection-full.json'),'gitLinksSha256':sha(SELECTION/'git-blob-links.json'),'evidenceTool':str(EVIDENCE),'evidenceToolSha256':sha(EVIDENCE),'sourceRoots':83,'sourcePaths':len(full)})

def pack(item):
 group,rows=item;gather=OUT/'gathered'/group;gather.mkdir(parents=True,exist_ok=False);captured=[];symlinks=[]
 for row in rows:
  original=Path(row['source'])
  if row['kind']=='symlink':
   payload=os.fsencode(os.readlink(original));relative='symlink-targets/'+row['root']+'/'+hashlib.sha256(row['path'].encode()).hexdigest()+'.bin';destination=safe(gather,relative);destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(payload);symlinks.append({'originalSource':row['source'],'originalPath':row['path'],'literalTarget':row['linkTarget'],'targetBytesHex':payload.hex(),'targetSha256':row['sha256'],'archivePayloadPath':relative,'representation':'Regular literal target-byte payload plus metadata; no symlink is created in gathered source or archive'})
  else:
   relative='payload/'+row['archivePath'];destination=safe(gather,relative);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,destination)
  if sha(destination)!=row['sha256']or destination.stat().st_size!=row['bytes']:raise ValueError('gathered source identity differs: '+row['source'])
  captured.append({'originalSource':row['source'],'originalRoot':row['root'],'originalPath':row['path'],'originalKind':row['kind'],'originalMode':row['mode'],'bytes':row['bytes'],'sha256':row['sha256'],'archivePayloadPath':relative,'selectionBasis':row['selectionBasis']})
 group_links=[v for v in links['entries']if owner_group[v['originalRoot']]==group];group_roots=[v for v in status['roots']if v['logicalGroup']==group]
 put(gather/'CAPTURE_SELECTION.json',{'schema':1,'logicalGroup':group,'originalRoots':group_roots,'payload':captured,'gitReconstructionLinks':group_links,'gitMainCommit':links['mainCommit'],'gitMainTree':links['mainTree'],'gitIdentityQualification':'Only exact raw blob bytes linked; different checkout transforms remain raw payload. No canonical acquisition/comparison raw channel is discarded on content equality.','selectionHandoffSha256':sha(SELECTION/'handoff.json'),'historicalNullSealsPreserved':True})
 put(gather/'SYMLINKS.json',{'symlinks':symlinks});put(gather/'DIRECTORIES.json',{'directories':[v for v in directories if owner_group.get(Path(v['root']).name)==group],'qualification':'Original directory metadata supplements regular-file archives; no directory content hash is claimed'})
 for name in ['failures-limitations-ledger.json','unlisted-resolution.json','prewalk-prunes-final.json','ownership-boundary.json']:
  shutil.copyfile(SELECTION/name,gather/name)
 proof=Path(links['independentGitVerificationReport']);shutil.copyfile(proof,gather/'GIT_SOURCE_VERIFICATION.json')
 archive=OUT/'archives'/('stage46-'+group+'.tar.gz');create=command(group+'-create',[sys.executable,'-B',str(EVIDENCE),'create',str(gather),str(archive)]);verify=command(group+'-verify',[sys.executable,'-B',str(EVIDENCE),'verify',str(archive)])
 if archive.stat().st_size>=100000000:raise ValueError('archive exceeds the authorized100MB bound: '+group)
 # Independently read every archive member and join source payload identities, beyond evidence.py verify.
 with tarfile.open(archive,'r:gz')as stream:
  members={m.name:m for m in stream.getmembers()};manifest=json.load(stream.extractfile(members['EVIDENCE.json']));assert set(members)=={r['path']for r in manifest['files']}|{'EVIDENCE.json'}
  for row in manifest['files']:
   data=stream.extractfile(members[row['path']]).read()
   if len(data)!=row['bytes']or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('independent archive readback mismatch')
  captured_manifest=json.load(stream.extractfile(members['CAPTURE_SELECTION.json']))
  if captured_manifest['payload']!=captured or captured_manifest['gitReconstructionLinks']!=group_links:raise ValueError('archive/source selection join mismatch')
  for row in captured:
   data=stream.extractfile(members[row['archivePayloadPath']]).read()
   if len(data)!=row['bytes']or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('archive/source payload SHA mismatch')
 row={'group':group,'archive':str(archive),'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'archiveFilesWithoutEvidence':len(manifest['files']),'sourcePayloadEntries':len(captured),'sourceRegularBytes':sum(v['bytes']for v in rows if v['kind']=='file'),'sourceSymlinksAsRegularTargetPayload':len(symlinks),'gitReconstructionEntries':len(group_links),'gitReconstructionBytes':sum(v['bytes']for v in group_links),'historicallyUnsealedRoots':[v['name']for v in group_roots if v['historicalSeal']is None],'createProcess':create,'verifyProcess':verify,'independentEveryMemberReadback':True,'sourceSelectionJoined':True};put(OUT/'group-reports'/(group+'.json'),row);print(json.dumps({k:row[k]for k in ['group','compressedBytes','archiveFilesWithoutEvidence','sha256']}),flush=True);return row

with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:archives=list(pool.map(pack,sorted(groups.items())))
# Rehash every original selection path, including Git-reconstructed copies, after packaging.
def check(row):
 path=Path(row['source']);payload=os.fsencode(os.readlink(path))if row['kind']=='symlink'else(path.read_bytes()if row['bytes']else b'');return None if len(payload)==row['bytes']and hashlib.sha256(payload).hexdigest()==row['sha256']else row['source']
with concurrent.futures.ThreadPoolExecutor(max_workers=8)as pool:changes=[p for p in pool.map(check,full)if p]
if changes:raise ValueError('original evidence changed during packaging: '+str(changes[:5]))
put(OUT/'index.json',{'schema':1,'archives':archives,'selectionHandoffSha256':sha(SELECTION/'handoff.json'),'gitMainCommit':links['mainCommit'],'gitMainTree':links['mainTree'],'allOriginalSelectedEntries':len(full),'rawArchivePayloadRegularFiles':sum(v['kind']=='file'for v in selected),'gitReconstructionEntries':len(links['entries']),'originalChanges':changes,'sourceScope':'B83 oracle/native/tool/fixture roots only; core/root/C review artifacts and later fullregression remain separate'});put(OUT/'report.json',{'archives':len(archives),'compressedBytes':sum(v['compressedBytes']for v in archives),'largestCompressedBytes':max(v['compressedBytes']for v in archives),'allBelow100MB':all(v['compressedBytes']<100000000 for v in archives),'allCreateAndVerifyExitZero':True,'allMembersIndependentlyReadBack':True,'allSourcePayloadsJoined':True,'originalSelectedEntriesRehashed':len(full),'originalChanges':changes,'rawArchivePayloadRegularFiles':sum(v['kind']=='file'for v in selected),'rawArchivePayloadRegularBytes':sum(v['bytes']for v in selected if v['kind']=='file'),'symlinksAsLiteralRegularPayload':sum(v['kind']=='symlink'for v in selected),'gitReconstructionEntries':len(links['entries']),'gitReconstructionBytes':sum(v['bytes']for v in links['entries']),'historicallyUnsealedRoots':16,'indexSha256':sha(OUT/'index.json'),'selectionHandoffSha256':sha(SELECTION/'handoff.json'),'GitOperations':0,'evaluatorExecutions':0,'originalRootsModified':0,'liveHandles':[]});print(json.dumps({'done':True,'reportSha256':sha(OUT/'report.json'),'indexSha256':sha(OUT/'index.json')}),flush=True)
