"""Preserve oracle selection, packaging and terminal records outside payload archives."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys

ROOT = Path.cwd()
OUT = ROOT / "target/m2/stage46-oracle-publication-metadata-01"
CAP = ROOT.parent / "pkl-rs.stage46/target/m2"
SELECTION = CAP / "stage46-oracle-native-publication-selection-01"
PUBLICATION = CAP / "stage46-oracle-native-publication-01"
GATHER = OUT / "gathered"
GATHER.mkdir(exist_ok=False)
EXCLUDED = {PUBLICATION / "archives", PUBLICATION / "gathered"}
assert all(p.is_dir() for p in EXCLUDED)
records = []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for label, source in [("selection", SELECTION), ("publication", PUBLICATION)]:
    for directory, children, files in os.walk(source, topdown=True, followlinks=False):
        children[:] = sorted(name for name in children if Path(directory) / name not in EXCLUDED)
        for name in children:
            assert not (Path(directory) / name).is_symlink()
        for name in sorted(files):
            original = Path(directory) / name
            assert stat.S_ISREG(original.lstat().st_mode)
            relative = Path(label) / original.relative_to(source)
            destination = GATHER / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            before = sha(original)
            shutil.copy2(original, destination)
            assert sha(destination) == before
            records.append({"original": str(original), "path": relative.as_posix(), "bytes": original.stat().st_size, "sha256": before})
shutil.copy2(Path(__file__), GATHER / "publication-metadata-producer.py")
provenance = {"scope": "Oracle/native publication selection and packaging receipts. The ten already verified payload archives and their duplicate gathered trees are excluded before traversal; all other selected metadata and process records are preserved.", "excludedBeforeTraversal": sorted(map(str, EXCLUDED)), "files": records}
(GATHER / "metadata-selection.json").write_text(json.dumps(provenance, indent=2) + "\n")
archive = OUT / "stage46-oracle-publication-metadata.tar.gz"
commands = []
for label, args in [("create", [str(GATHER), str(archive)]), ("verify", [str(archive)])]:
    argv = [sys.executable, "tools/evidence.py", label, *args]
    with (OUT / (label + ".stdout.bin")).open("wb") as stdout, (OUT / (label + ".stderr.bin")).open("wb") as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    commands.append({"argv": argv, "exitCode": result.returncode})
    (OUT / "commands.json").write_text(json.dumps(commands, indent=2) + "\n")
    assert result.returncode == 0
for entry in records:
    assert sha(Path(entry["original"])) == entry["sha256"]
assert archive.stat().st_size < 100_000_000
report = {"archive": str(archive), "sha256": sha(archive), "bytes": archive.stat().st_size, "originalMetadataFiles": len(records), "allOriginalBytesUnchanged": True, "commands": commands}
(OUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report), flush=True)
