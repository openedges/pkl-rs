import ast
from pathlib import Path
path=Path('tools/data_size_oracle.py')
source=path.read_text()
class ExplicitChecks(ast.NodeTransformer):
 def visit_Assert(self,node):
  self.generic_visit(node)
  expression=ast.get_source_segment(source,node.test) or 'unknown condition'
  failure=ast.Raise(exc=ast.Call(func=ast.Name(id='ValueError',ctx=ast.Load()),args=[ast.Constant(value=f'Java DataSize audit check {node.lineno} failed: {expression[:100]}')],keywords=[]),cause=None)
  return ast.copy_location(ast.If(test=ast.UnaryOp(op=ast.Not(),operand=node.test),body=[failure],orelse=[]),node)
tree=ExplicitChecks().visit(ast.parse(source));ast.fix_missing_locations(tree)
path.write_text(ast.unparse(tree)+'\n')
