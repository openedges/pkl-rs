from pathlib import Path
import tarfile, hashlib, gzip, io, json
s56=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage56')
s57=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage57')
root=s57/'tests/fixtures/m2-data-size'
source_names=['external/pkl/stdlib/base.pkl','external/pkl/pkl-core/src/main/java/org/pkl/core/runtime/VmDataSize.java','external/pkl/pkl-core/src/main/java/org/pkl/core/stdlib/base/DataSizeNodes.java','external/pkl/pkl-core/src/main/java/org/pkl/core/DataSizeUnit.java','external/pkl/pkl-core/src/main/java/org/pkl/core/DataSize.java','oracle.lock.json','references.lock']
entries=[]
for n in ('01','02','03'):
 p=s56/'target/m2'/f'stage57-datasize-oracle-{n}'
 entries.extend((f'capture-{n}/{f.relative_to(p).as_posix()}', f) for f in p.rglob('*') if f.is_file())
entries.extend((f'sources/{name}',s56/name) for name in source_names)
entries.sort(key=lambda x:x[0]);assert len(entries)==len({name for name,_ in entries})
archive=root/'oracle-evidence.tar.gz'
with archive.open('wb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',filename='',mtime=0,compresslevel=6) as gz:
  with tarfile.open(fileobj=gz,mode='w|') as tar:
   for name,path in entries:
    info=tarfile.TarInfo(name);info.size=path.stat().st_size;info.mode=0o644;info.mtime=0
    with path.open('rb') as data:tar.addfile(info,data)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
identity=hashlib.sha256()
for name,path in entries:
 identity.update(name.encode()+b'\0'+sha(path).encode()+b'\n')
summary={'archive_sha256':sha(archive),'fileset_sha256':identity.hexdigest(),'archive_members':len(entries),'captures':{n:sum(name.startswith(f'capture-{n}/') for name,_ in entries) for n in ('01','02','03')},'sources':{name:sha(s56/name) for name in source_names},'bytes':archive.stat().st_size}
(root/'archive-identity.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,sort_keys=True))
