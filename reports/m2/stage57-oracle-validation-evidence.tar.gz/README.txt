Stage57 DataSize Java authority validation evidence

This archive contains frozen local validation logs, the fresh four-process Java
reproduction, source snapshots except the already published canonical fixture
archive, and two independent reviews. It is Java authority evidence only.

The canonical plus historical Java raw fixture is separately stored at
tests/fixtures/m2-data-size/oracle-evidence.tar.gz, SHA-256
51e14a2c80836141c61a9bbb18aaa708e6a963c238132854e55e7bf6493c6b8e,
with 56,870 members and file-set digest
001ef10a6ee71f746179757c008dc46ce04d378b0d6d93814124016c06c1f2a6.
The manifest lists each member here with original source path, size and SHA-256.
The original split03 acquisition runner differs from the later production auditor.
Additive04/05 are separate pending authority and are outside this packet.
Java A Git commit binding remains pending.
