"""Independent read-only review of the canonical split DataSize Java packet."""
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parents[3]
PACKET = ROOT / "target/m2/stage57-datasize-oracle-03"
SUPPLEMENT = ROOT / "target/m2/stage57-datasize-oracle-02/hash-threshold"
OUT = Path(__file__).resolve().parent
FACTORS = {"b": 1, "kb": 1000, "kib": 1024, "mb": 1000**2, "mib": 1024**2,
           "gb": 1000**3, "gib": 1024**3, "tb": 1000**4, "tib": 1024**4,
           "pb": 1000**5, "pib": 1024**5}


def digest(path):
    raw = path.read_bytes()
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def sha(path):
    return digest(path)["sha256"]


def raw(folder, stem):
    return (folder / (stem + ".bin")).read_bytes()


def value(folder, stem):
    return raw(folder, stem).decode("utf-8")


def check_text(folder, stem):
    utf8 = raw(folder, stem)
    units = raw(folder, stem + ".code-units")
    assert len(units) % 2 == 0
    assert units.decode("utf-16-be", errors="surrogatepass").encode("utf-8", errors="replace") == utf8


def file_map(folder):
    return {p.relative_to(folder).as_posix(): sha(p) for p in folder.rglob("*") if p.is_file()}


def java_hash(value):
    bits = 0x7ff8000000000000 if math.isnan(value) else struct.unpack(">Q", struct.pack(">d", value))[0]
    raw_hash = ((bits >> 32) ^ bits) & 0xffffffff
    return raw_hash - 0x100000000 if raw_hash >= 0x80000000 else raw_hash


cases = json.loads((PACKET / "cases.json").read_bytes())
provenance = json.loads((PACKET / "provenance.json").read_bytes())
audit = json.loads((PACKET / "audit.json").read_bytes())
rows = cases["rows"]
assert cases["schema"] == 2 and cases["baseline"] == "Pkl 0.32.0"
assert cases["boundaries"] == ["string", "export"] and cases["repetitions"] == 2
assert len(rows) == 255 and len({r["id"] for r in rows}) == 255
assert (PACKET / "queries.tsv").read_text() == "".join(r["id"] + "\t" + r["expression"] + "\n" for r in rows)
assert provenance["complete"] and provenance["stable"] and provenance["string_raw_equal"] and provenance["export_raw_equal"]
assert provenance["reference_revision"] == "e51fb2f91774265666f94980ec630db794a4db2d"
assert provenance["artifact_sha256"] == "c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059"
assert provenance["input_before"] == provenance["input_after"]
assert provenance["source_before"] == provenance["source_after"]
assert provenance["artifact_sha256"] == provenance["artifact_after_sha256"] == sha(Path(provenance["artifact"]))
for name, expected in provenance["input_before"].items():
    assert sha(PACKET / name) == expected
for name, expected in provenance["source_before"].items():
    assert sha(ROOT / name) == expected
assert sha(ROOT / "oracle.lock.json") == provenance["oracle_lock_sha256"]
assert sha(ROOT / "references.lock") == provenance["references_lock_sha256"]
jdk = provenance["jdk"]
assert sha(Path(jdk["executable"])) == jdk["executable_sha256"]
home = Path(jdk["properties"]["java.home"])
assert sha(home / "lib/modules") == jdk["modules_sha256"]
assert sha(home / "release") == jdk["release_sha256"]
assert jdk["properties"]["java.version"] == "21.0.12.1"
assert len(provenance["sessions"]) == 4
assert [(s["mode"], s["repeat"]) for s in provenance["sessions"]] == [("string", 0), ("string", 1), ("export", 0), ("export", 1)]
assert len({s["pid"] for s in provenance["sessions"]}) == 4

string_text = ["expression", "result.stdout", "result.stderr", "result.error-class"]
string_files = {"result.status.bin"} | {stem + suffix for stem in string_text for suffix in (".bin", ".code-units.bin")}
export_fields = ["error", "error-class", "java-type", "payload-error", "text", "raw-bits-hex", "unit", "hash"]
compare_fields = ["error", "reference", "equals", "hash-equal"]
base_export = {"repeat-invoked.bin", "call-0.status.bin", "call-0.payload-status.bin"}
base_export |= {stem + suffix for stem in ["expression"] + ["call-0." + f for f in export_fields]
                for suffix in (".bin", ".code-units.bin")}
repeat_export = {"call-1.status.bin", "call-1.payload-status.bin", "comparison.status.bin"}
repeat_export |= {stem + suffix for stem in ["call-1." + f for f in export_fields] + ["comparison." + f for f in compare_fields]
                  for suffix in (".bin", ".code-units.bin")}
assert (len(string_files), len(base_export), len(repeat_export)) == (9, 21, 27)

raw_maps = {}
for mode, expected_files in (("string", 2297), ("export", 8975)):
    first = file_map(PACKET / mode / "repeat-0")
    second = file_map(PACKET / mode / "repeat-1")
    assert first == second and len(first) == expected_files
    assert provenance[mode + "_files"] == expected_files
    assert provenance[mode + "_raw_differences"] == []
    raw_maps[mode] = first

group_status = defaultdict(Counter)
error_rows = []
export_rows = []
session_results = []
for session in provenance["sessions"]:
    mode, repeat = session["mode"], session["repeat"]
    folder = PACKET / mode / f"repeat-{repeat}"
    assert session["exit_code"] == 0 and session["query_directories"] == 255
    assert session["cwd"] == str(PACKET) and session["command"][-4:] == [mode, str(folder), str(PACKET), cases["module_uri"]]
    assert session["command"][0] == jdk["executable"]
    assert sha(folder / "process.stdout.bin") == session["stdout_sha256"]
    assert sha(folder / "process.stderr.bin") == session["stderr_sha256"]
    assert (folder / "process.stderr.bin").read_bytes() == b""
    trace = [f"session-open mode={mode} rows=255"]
    calls = successes = errors = datasize_rows = repeats = 0
    for index, row in enumerate(rows):
        directory = folder / f"{index:03d}-{row['id']}"
        assert directory.is_dir()
        assert raw(directory, "expression") == row["expression"].encode("utf-8")
        check_text(directory, "expression")
        intended = row["intended_outcome"]
        if mode == "string":
            assert {p.name for p in directory.iterdir()} == string_files
            for stem in string_text:
                check_text(directory, stem)
            status = value(directory, "result.status")
            assert status == ("success\n" if intended == "ordinary-value" else "error\n")
            if status == "success\n":
                assert raw(directory, "result.stdout") and raw(directory, "result.stderr") == b""
                assert raw(directory, "result.error-class") == b""
            else:
                message = value(directory, "result.stderr")
                assert not raw(directory, "result.stdout") and message.startswith("–– Pkl Error ––\n")
                assert value(directory, "result.error-class") == "org.pkl.core.PklException"
                if intended == "type-error":
                    assert "Expected value of type" in message
                elif intended == "truncation-error":
                    assert "Cannot convert" in message and "Float" in message
                elif intended == "renderer-error":
                    assert "Cannot render" in message or "top-level value of a Pcf document" in message
                elif intended == "undefined-member":
                    assert "value is undefined" in message
                else:
                    assert intended == "invalid-operator-or-call" and ("Operator `" in message or "function arguments" in message)
                if repeat == 0:
                    error_rows.append({"id": row["id"], "group": row["group"], "intended": intended,
                                       "error_sha256": sha(directory / "result.stderr.bin")})
            call = f"string-{index}-{row['id']}"
            trace += [f"call-enter={call}", f"call-exit={call} status={status.strip()}"]
            calls += 1
            successes += status == "success\n"
            errors += status == "error\n"
            if repeat == 0:
                group_status[row["group"]][status.strip()] += 1
        else:
            for stem in ["expression"] + ["call-0." + f for f in export_fields]:
                check_text(directory, stem)
            status = value(directory, "call-0.status")
            payload_status = value(directory, "call-0.payload-status")
            assert status == ("success\n" if intended == "ordinary-value" else "error\n")
            assert payload_status == ("success\n" if status == "success\n" else "not-applicable\n")
            java_type = value(directory, "call-0.java-type")
            repeat_flag = value(directory, "repeat-invoked")
            assert repeat_flag == ("true" if java_type == "org.pkl.core.DataSize" else "false")
            assert {p.name for p in directory.iterdir()} == (base_export | repeat_export if repeat_flag == "true" else base_export)
            if status == "success\n":
                assert not raw(directory, "call-0.error") and not raw(directory, "call-0.error-class")
            else:
                assert not java_type and value(directory, "call-0.error-class") == "org.pkl.core.PklException"
            call = f"export-{index}-{row['id']}-0"
            trace += [f"call-enter={call}", f"call-exit={call} status={status.strip()}"]
            calls += 1
            successes += status == "success\n"
            errors += status == "error\n"
            if status == "success\n":
                trace += [f"payload-enter={call}", f"payload-exit={call} status=success"]
            if repeat_flag == "true":
                datasize_rows += 1
                repeats += 1
                bits_hex = value(directory, "call-0.raw-bits-hex")
                unit = value(directory, "call-0.unit")
                observed_hash = int(value(directory, "call-0.hash"))
                assert re.fullmatch(r"[0-9a-f]{16}", bits_hex) and unit in FACTORS
                bits = int(bits_hex, 16)
                number = struct.unpack(">d", bits.to_bytes(8, "big"))[0]
                assert observed_hash == java_hash(number * float(FACTORS[unit]) / 1.0)
                for stem in ["call-1." + f for f in export_fields] + ["comparison." + f for f in compare_fields]:
                    check_text(directory, stem)
                assert value(directory, "call-1.status") == "success\n"
                assert value(directory, "call-1.payload-status") == "success\n"
                assert value(directory, "comparison.status") == "success\n"
                assert value(directory, "call-1.java-type") == "org.pkl.core.DataSize"
                assert value(directory, "call-1.raw-bits-hex") == bits_hex
                assert value(directory, "call-1.unit") == unit
                assert value(directory, "call-1.hash") == str(observed_hash)
                reference = value(directory, "comparison.reference")
                equals = value(directory, "comparison.equals")
                hash_equal = value(directory, "comparison.hash-equal")
                assert reference == "false" and hash_equal == "true"
                assert equals == ("false" if math.isnan(number) else "true")
                call1 = f"export-{index}-{row['id']}-1"
                comparison = f"export-{index}-{row['id']}-comparison"
                trace += [f"call-enter={call1}", "call-exit=" + call1 + " status=success",
                          f"payload-enter={call1}", f"payload-exit={call1} status=success",
                          f"comparison-enter={comparison}", f"comparison-exit={comparison} status=success"]
                calls += 1
                successes += 1
                if repeat == 0:
                    export_rows.append({"id": row["id"], "raw_bits_hex": bits_hex, "unit": unit,
                                        "hash": observed_hash, "repeat_equals": equals})
            else:
                assert all(not raw(directory, "call-0." + stem) for stem in ("raw-bits-hex", "unit", "hash"))
    trace.append(f"session-closed mode={mode} rows=255 public-calls={calls} success={successes} errors={errors} datasize-rows={datasize_rows} repeated-export-calls={repeats}")
    assert (folder / "process.stdout.bin").read_bytes() == ("\n".join(trace) + "\n").encode("utf-8")
    session_results.append({"mode": mode, "repeat": repeat, "pid": session["pid"], "public_evaluator_calls": calls,
                            "successes": successes, "errors": errors, "exported_datasize_rows": datasize_rows,
                            "repeated_export_calls": repeats, "raw_files": len(raw_maps[mode])})

assert [(s["public_evaluator_calls"], s["successes"], s["errors"], s["exported_datasize_rows"], s["repeated_export_calls"])
        for s in session_results] == [(255, 233, 22, 0, 0), (255, 233, 22, 0, 0), (389, 367, 22, 134, 134), (389, 367, 22, 134, 134)]
assert len(error_rows) == 22 and len(export_rows) == 134
assert {key: dict(value) for key, value in group_status.items()} == audit["groups"]

# The older hash-threshold supplement is separate from canonical split sessions.
supplement_report = json.loads((SUPPLEMENT / "report.json").read_bytes())
assert supplement_report["complete"] and supplement_report["comparison"] == {"differences": [], "files": 398, "raw_equal": True}
assert supplement_report["input_before"] == supplement_report["input_after"]
for name, expected in supplement_report["input_before"].items():
    assert sha(SUPPLEMENT.parent / name) == expected
assert file_map(SUPPLEMENT / "repeat-0") == file_map(SUPPLEMENT / "repeat-1")
threshold_values = {}
for index, line in enumerate((SUPPLEMENT / "input/queries.tsv").read_text().splitlines()):
    case_id, expression = line.split("\t")
    folder = SUPPLEMENT / "repeat-0" / f"{index:03d}-{case_id}"
    assert raw(folder, "expression") == expression.encode()
    assert value(folder, "string.status") == "success\n"
    assert value(folder, "value.status") == "success\n"
    threshold_values[case_id] = value(folder, "string.stdout")
assert threshold_values == {"set-zero-small": "1", "set-zero-fifth": "5", "set-zero-sixth": "6",
                            "set-zero-sixth-reverse": "6", "set-nan-same-fifth": "5",
                            "set-nan-distinct-fifth": "6", "set-cross-unit": "3",
                            "map-zero-sixth": "6", "map-zero-sixth-reverse": "6",
                            "map-nan-same-sixth": "5", "map-nan-distinct-sixth": "6",
                            "map-cross-unit": "3"}

duplicate_expressions = defaultdict(list)
for row in rows:
    duplicate_expressions[row["expression"]].append(row["id"])
duplicate_expressions = {expression: ids for expression, ids in duplicate_expressions.items() if len(ids) > 1}
assert duplicate_expressions == {'1.b.toUnit("b")': ["unit-b-to-b", "b-to-unit-b"]}
bytes_size = PACKET / "export/repeat-0/232-bytes-size"
assert value(bytes_size, "call-0.java-type") == "org.pkl.core.DataSize"
assert value(bytes_size, "call-0.raw-bits-hex") == "4008000000000000"
assert value(bytes_size, "call-0.unit") == "b"
assert value(PACKET / "string/repeat-0/232-bytes-size", "result.stdout") == "3.b"

report = {"schema": 1,
          "verdict": "Canonical Oracle03 acquisition integrity passed; no accidental syntax/type failures in intended ordinary rows. Scope gaps below remain explicit.",
          "scope": "Independent offline read-only review; no Java/Rust guests, tests, builds, candidate comparison or source edits.",
          "canonical_identity": {name: digest(PACKET / name) for name in ("cases.json", "queries.tsv", "module.pkl", "DataSizeSplitOracle.java", "run.py", "provenance.json", "audit.json")},
          "authority": {"reference_revision": provenance["reference_revision"], "jar_sha256": provenance["artifact_sha256"],
                        "jdk_executable_sha256": jdk["executable_sha256"], "jdk_modules_sha256": jdk["modules_sha256"],
                        "jdk_release_sha256": jdk["release_sha256"], "module_uri": cases["module_uri"]},
          "sessions": session_results, "total_actual_public_evaluator_calls": sum(s["public_evaluator_calls"] for s in session_results),
          "unique_authored_rows": len(rows), "distinct_expressions": len(rows) - len(duplicate_expressions),
          "duplicate_expression_ids": duplicate_expressions,
          "raw_file_sets_per_repeat": {mode: len(files) for mode, files in raw_maps.items()},
          "raw_repetition_equal": {"string": True, "export": True},
          "group_statuses": {key: dict(value) for key, value in group_status.items()},
          "intentional_error_rows": error_rows, "exported_datasize_rows_per_export_session": len(export_rows),
          "export_hash_formula_checks": len(export_rows), "export_hash_formula_mismatches": 0,
          "small_vs_hashed_collection_observation": {"canonical03_small_set_signed_zero_length": 1,
              "separate_additive02_threshold_packet_identity": digest(SUPPLEMENT / "report.json"),
              "additive02_raw_repeat_equal": True, "additive02_values": threshold_values,
              "provenance_limit": "Additive02 uses the earlier mixed string/export evaluator probe. Retain it as a separately bound language hash-threshold observation, not a canonical03 split-session producer channel."},
          "bytes_size_scope": "Canonical row 232 genuinely executes Bytes(1,2,3).size and returns/export 3.b; this one bounded producer observation does not cover broader Bytes.size, large-Bytes diagnostics or Bytes API parity.",
          "numeric_semantics": ["Pinned DataSize and VmDataSize convertValueTo multiply by unit bytes before dividing by target bytes; all 134 captured public export hashes match Double.hashCode(converted bytes).",
                                "Pinned public and Vm equality use identity then double == on converted bytes; distinct NaNs compare false, while same object NaN compares true. Signed zeros compare equal, but exported hashes differ (-2147483648 versus 0).",
                                "VmDataSize ordering uses Double.compare: canonical03 observes negative zero < positive zero and NaN > ordinary DataSize. String rendering can saturate mathematically integral large doubles to Long.MAX_VALUE while public getValue retains IEEE 754 bits.",
                                "The two export calls compare the same expression only; cross-expression public DataSize equals/hash parity is inferred from pinned source, with language Set/Map cases observed separately."],
          "remaining_scope": ["Full Bytes.size producer and large-Bytes diagnostics beyond the bounded three-byte row.",
                              "Pkl Binary public codec API and malformed unit/length cases.",
                              "Yaml/Properties/PList/Jsonnet/Protobuf/XML DataSize renderer boundaries.",
                              "Candidate native/Node/browser execution, API parity, lifecycle, other OS and performance gates.",
                              "Canonical03 has only small Set/Map equality cases; the separately preserved additive02 threshold packet must remain linked to core hashed-path regressions."],
          "acquisition_blockers": []}
path = OUT / "report.json"
assert not path.exists()
path.write_text(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=True) + "\n")
print(json.dumps({"report": {"path": str(path), **digest(path)},
                  "sessions": session_results, "errors": len(error_rows), "exported_datasize_rows": len(export_rows)}, indent=2))
