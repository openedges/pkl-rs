from pathlib import Path
import json,subprocess,sys,time,datetime,os
O=Path(__file__).parent;start=time.time_ns();seen={}
with(O/'outer.stdout.bin').open('wb')as out,(O/'outer.stderr.bin').open('wb')as err:
 proc=subprocess.Popen([sys.executable,str(O/'run.py')],stdout=out,stderr=err)
 (O/'outer-launch.json').write_text(json.dumps({'pid':proc.pid,'monitorPid':os.getpid(),'command':[sys.executable,str(O/'run.py')],'startedUnixNs':start},indent=2)+'\n')
 known={proc.pid}
 while proc.poll()is None:
  listing=subprocess.run(['ps','-axo','pid=,ppid=,command='],capture_output=True,text=True,check=True).stdout
  rows=[]
  for line in listing.splitlines():
   fields=line.strip().split(None,2)
   if len(fields)==3:rows.append((int(fields[0]),int(fields[1]),fields[2]))
  for _ in range(3):
   for pid,parent,command in rows:
    if parent in known:known.add(pid)
  now=time.time_ns()
  for pid,parent,command in rows:
   if pid in known:
    key=str(pid);seen.setdefault(key,{'pid':pid,'parentPid':parent,'command':command,'firstObservedUnixNs':now});seen[key]['lastObservedUnixNs']=now
  (O/'observed-pids.json').write_text(json.dumps({'ownerPid':proc.pid,'processes':list(seen.values()),'sampling':'ps descendants every~50ms;notclaimed exhaustive for shorter-lived children'},indent=2)+'\n');time.sleep(.05)
 code=proc.wait()
(O/'outer-terminal.json').write_text(json.dumps({'pid':proc.pid,'exitCode':code,'startedUnixNs':start,'finishedUnixNs':time.time_ns(),'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'liveHandles':[]},indent=2)+'\n');print(json.dumps({'pid':proc.pid,'exitCode':code,'observedProcesses':len(seen)}));sys.exit(code)
