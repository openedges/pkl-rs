# Stage47 연속 renderer API 관찰 계획

원본 `api/moduleOutput2.pkl`·`api/pcfRenderer9.pkl` 전체 CLI baseline은 root 소유로 유지하고 다시 취득하지 않는다. 이 root는 pinned Java 0.32.0 evaluator의 연속 API만 새로 관찰한다.

첫 묶음은 JSON scalar/empty/indent/newline·nonfinite/key/mixed-object, 옵션 getter와 mapping entry 강제 순서, document/value conversion hint·동일값 identity 경계, RenderDirective text/bytes/undefined·다른 receiver 경계를 분리한다. UTF16 reader 입력은 원본 BE units 파일과 실제 reader 반환 units/UTF8를 함께 보존한다.

별도 후속 root에서 annotation/상속/path/class/mixin·nested renderValue, List/Set join·Reference callback, JSON 실제 정책 denial과 singleton 경계, Host retry/close/API 경계를 추가한다. 모든 실패·미도달을 유지하고 Rust에서 기대값을 만들지 않는다. `System.gc()` 요청은 실제 수집이 입증됐다는 뜻이 아니며 native poll별 GC와 구분한다.

각 case는 2 fresh JVM × JVM당 2 evaluator이고 API 순서·read/policy counters·status·UTF16BE·원본 Java UTF8·오류 class/stack을 그대로 기록한다. Source URI/입력/profile/JAR·도구와 실제 PID/terminal을 함께 봉인한다.
