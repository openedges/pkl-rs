# Pinned renderer API observations

This checkpoint publishes Java Pkl 0.32.0 observations and verification tooling. It does not establish native, browser, or Node compatibility, complete renderer support, full M2 completion, or performance results. Actual native and platform comparisons are separate evidence.

The self-contained fixture is intended for `tests/fixtures/m2-renderer-portable`. Keep `manifest.json`, `fixtures.json`, and the `provenance/` payload byte-identical. Place this document outside the fixture directory, for example at `docs/m2-renderer-oracle.md`.

The bundle contains 860 API calls in 44 persistent evaluator sessions. Each authored case has two fresh JVM repeats, each containing two fresh evaluators. Expressions within a session share the evaluator and its lazy module/resource state. These are actual `Evaluator.evaluateExpressionString` observations; the original whole CLI inputs are separately captured and remain unchanged.

| Selected controls | APIs |
| --- | ---: |
| Fresh scalar conversion hint identity | 40 |
| JSON scalars, layout, unsupported values and errors | 116 |
| Renderer option getter/value forcing and typed reader retry | 36 |
| JSON UTF-16 escaping | 328 |
| Corrected document/value converter errors and hints | 72 |
| Corrected RenderDirective text, lazy bytes and undefined paths | 56 |
| Persistent primitive converter function history | 44 |
| Parent/child annotation order and null omission | 24 |
| Reference join callback and typed I/O retry | 24 |
| JSON Property, original path priority, transformers and nested renderValue | 40 |
| Collection join order, object forcing, errors and UTF-16 separator | 80 |

`tools/renderer_fixtures.py --fixtures tests/fixtures/m2-renderer-portable` verifies the bundle. The verifier pins the original producer report, inventory and closure SHA-256 values independently of the outer fixture manifest. It checks source/helper identities, every copied raw payload against the pinned inventory, both stdout/stderr channels as original Java UTF-8 and UTF-16BE, exact status bytes, and reader counts against both raw files and the pinned report counters. Reader plans are reconstructed from the actual Java reader trace and authored input table. No Rust result supplies an expected value.

The Java UTF-8 encoding of an unpaired UTF-16 surrogate is `?`; it must be compared independently of the preserved UTF-16 units. Trimming errors, sorting events, replacing diagnostic frames or normalizing strings would invalidate this comparison.

Java records explicit `System.gc()` requests. They do not prove that a value was collected. The native observer requests collection after each poll; each platform must record its own collection behavior and retained roots. The initial portable fixture does not represent evaluator-after-close operations, callback reentry, logger callbacks or cross-evaluator JVM static identity.

The original evidence preserves authored mistakes and corrective acquisitions. Oracle01 failed javac before any of its 648 planned APIs. Oracle02 includes 72 parser rejections from an invalid Dynamic declaration and 16 nested query lexical errors; its valid Directive calls were superseded for fixture selection by a complete corrected group. Oracle03 includes 44 `Any` converter observations that do not dispatch primitive type converters. Oracle05 preserves 120 reserved-identifier parser rejections, 48 direct query import-alias lookup failures and 36 associated policy sentinels. None of these is relabeled as intended renderer coverage.

Oracle06 also contains 84 actual stdlib security-policy APIs outside the default-policy fixture. Denying `pkl:json` produces an ordinary import error; the pinned base/ref/test singleton path succeeds under an allowlist excluding those singleton URIs. These policy profiles require a corresponding Host contract and remain unexecuted in the initial default-policy portable comparison.

Supplementary Oracle07/08 observations remain separate. They cover PCF Long cache boundaries, fresh equal-content String references, shared resource byte-array versus distinct Resource.bytes wrapper identity, captured primitive frames, and explicit evaluator closure. Oracle07's 16 mistaken bare function-property calls are preserved; Oracle08 uses `.apply` correctly. Post-close Java `PolyglotException` cancellation is an API boundary, not a guest-language error.

The native C03 comparison of this unchanged 860-call bundle recorded 788 byte matches and 72 mismatches. Of these, 68 are explicit reference identity Unsupported outcomes, and four are JSON non-string Dynamic key diagnostic alignment differences. Every reader plan matched, all 44 sessions closed with zero retained slots, and all 32,901 frozen source hashes remained unchanged. These failures are not fixture exclusions. Later corrective candidates require fresh comparisons against the same Java bytes.

The installed unit-test location is `tools/tests/test_renderer_fixtures.py`. The captured staging test accepts the `RENDERER_PORTABLE_GOLDEN` environment variable. Integration may add a repository-relative default while retaining that override; record the installed test source hash and its actual checks separately. Source changes made during promotion must not be claimed byte-identical to the captured staging tools.

The captured staging verifier03 still accepts undeclared empty directories and detects unknown regular payload only after walking. Promotion must add rejection of undeclared directories before descent, using the authenticated required paths and their exact ancestors, with a scan-spy regression. This source limitation is separate from the verified normal golden payload and must remain traceable when the installed tool is corrected.
