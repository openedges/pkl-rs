from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
sys.dont_write_bytecode = True
O = Path(__file__).parent
F = O.parent / 'stage47-renderer-portable-fixtures-02'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, value): p.write_text(json.dumps(value, indent=2) + '\n')
sources = {str(O / n): sha(O / n) for n in ['renderer_fixtures.py', 'test_renderer_fixtures.py', 'check.py']}
env = {**os.environ, 'RENDERER_PORTABLE_GOLDEN': str(F), 'PYTHONDONTWRITEBYTECODE': '1'}
records = []
for name, command in [('tests', [sys.executable, '-m', 'unittest', '-v', 'test_renderer_fixtures']), ('verify', [sys.executable, str(O / 'renderer_fixtures.py'), '--fixtures', str(F)])]:
 start = time.time_ns()
 with (O / (name + '.stdout.bin')).open('wb') as out, (O / (name + '.stderr.bin')).open('wb') as err:
  proc = subprocess.Popen(command, cwd=O, env=env, stdout=out, stderr=err)
  launch = {'pid': proc.pid, 'parentPid': os.getpid(), 'command': command, 'cwd': str(O), 'startedUnixNs': start, 'environment': {'RENDERER_PORTABLE_GOLDEN': str(F), 'PYTHONDONTWRITEBYTECODE': '1'}, 'goldenManifestSha256': sha(F / 'manifest.json')}
  write(O / (name + '.launch.json'), launch)
  code = proc.wait()
 row = {**launch, 'exitCode': code, 'finishedUnixNs': time.time_ns(), 'stdoutSha256': sha(O / (name + '.stdout.bin')), 'stderrSha256': sha(O / (name + '.stderr.bin'))}
 write(O / (name + '.terminal.json'), row); records.append(row)
 print(json.dumps({'phase': name, 'pid': proc.pid, 'exitCode': code}), flush=True)
 if code: break
write(O / 'checks-report.json', {'records': records, 'allExitCodesZero': len(records)==2 and all(r['exitCode']==0 for r in records), 'sourceBefore': sources, 'sourceAfter': {p: sha(Path(p)) for p in sources}, 'fixtureRoot': str(F), 'fixtureManifestSha256': sha(F / 'manifest.json'), 'finishedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'liveHandles': []})
sys.exit(0 if len(records)==2 and all(r['exitCode']==0 for r in records) else 1)
