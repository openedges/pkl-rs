# Renderer portable fixture

Java 봉인 원문으로만 860 API/44 session을 수출한다. report/inventory/closure literal SHA와 실제 status/UTF16/UTF8/counter 및 reader 반환을 각각 검증한다. 제외한 authored 실패와 실제 정책84 API, 미실행 lifecycle 경계는 보존한다. Rust 결과로 예상값을 만들지 않는다.
