"""Real reblessed fixture tampering checks; never modifies the golden inputs."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import copy
import hashlib
import json
import os
import shutil
import tempfile
import unittest
import renderer_fixtures as tool

GOLDEN = Path(os.environ['RENDERER_PORTABLE_GOLDEN'])

class FixtureVerificationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.golden_files = {rel: hashlib.sha256((GOLDEN / rel).read_bytes()).hexdigest() for rel in tool.file_set(GOLDEN)}

 @classmethod
 def tearDownClass(cls):
  after = {rel: hashlib.sha256((GOLDEN / rel).read_bytes()).hexdigest() for rel in tool.file_set(GOLDEN)}
  if after != cls.golden_files:
   raise AssertionError('golden pathset or payload changed')

 def setUp(self):
  self.temporary = tempfile.TemporaryDirectory(prefix='renderer-negative-', dir=Path(__file__).parent)
  self.root = Path(self.temporary.name) / 'fixture'
  shutil.copytree(GOLDEN, self.root, copy_function=os.link)

 def tearDown(self):
  self.temporary.cleanup()

 def put(self, relative, data):
  path = self.root / relative
  if path.exists() or path.is_symlink():
   path.unlink()
  path.parent.mkdir(parents=True, exist_ok=True)
  path.write_bytes(data)

 def obj(self, relative):
  return json.loads((self.root / relative).read_bytes())

 def put_json(self, relative, value):
  self.put(relative, (json.dumps(value, indent=2) + '\n').encode())

 def bless(self):
  manifest = self.obj('manifest.json')
  manifest['files'] = {rel: {'sha256': tool.sha((self.root / rel).read_bytes()), 'bytes': (self.root / rel).stat().st_size} for rel in tool.file_set(self.root) if rel != 'manifest.json'}
  self.put_json('manifest.json', manifest)

 def reject(self):
  self.bless()
  with self.assertRaises((ValueError, KeyError, FileNotFoundError)):
   tool.verify(self.root)

 def fixture_mutation(self, mutate):
  bundle = self.obj('fixtures.json')
  mutate(bundle)
  self.put_json('fixtures.json', bundle)
  self.reject()

 def raw_path(self, suffix):
  return next(rel for rel in tool.file_set(self.root) if '/calls/session-' in rel and rel.endswith(suffix))

 def test_valid_full_fixture(self):
  self.assertEqual(tool.verify(self.root)['javaApiCalls'], 860)

 def test_reblessed_expected_counter(self):
  self.fixture_mutation(lambda b: b['fixtures'][0]['expected'][0].update(readsAfter=999))

 def test_reblessed_raw_counter_and_expected(self):
  rel = self.raw_path('.reads-after.bin')
  self.put(rel, b'999')
  bundle = self.obj('fixtures.json')
  bundle['fixtures'][0]['expected'][0]['readsAfter'] = 999
  self.put_json('fixtures.json', bundle)
  self.reject()

 def test_reblessed_pinned_report_counters(self):
  rel = 'provenance/stage47-renderer-api-oracle-02/report.json'
  report = self.obj(rel)
  report['observations'][0]['calls'][0]['countersAfter'] = 'read=999\n'
  self.put_json(rel, report)
  self.reject()

 def test_reblessed_inventory_and_closure(self):
  base = 'provenance/stage47-renderer-api-oracle-02/'
  inv = self.obj(base + 'inventory.json')
  inv['files'][0]['sha256'] = '0' * 64
  self.put_json(base + 'inventory.json', inv)
  closure = self.obj(base + 'closure.json')
  closure['inventorySha256'] = tool.sha((self.root / (base + 'inventory.json')).read_bytes())
  self.put_json(base + 'closure.json', closure)
  self.reject()

 def test_reblessed_raw_utf16(self):
  rel = self.raw_path('.stdout.code-units.bin')
  self.put(rel, b'\x00X')
  self.reject()

 def test_reblessed_raw_utf8(self):
  rel = self.raw_path('.stdout.bin')
  self.put(rel, b'changed')
  self.reject()

 def test_status_whitespace_is_not_normalized(self):
  rel = self.raw_path('.status.bin')
  self.put(rel, b'success \n')
  self.reject()

 def test_reblessed_helper_source(self):
  rel = 'provenance/stage47-renderer-api-oracle-02/RendererProbe.java'
  self.put(rel, (self.root / rel).read_bytes() + b'\n// changed producer\n')
  self.reject()

 def test_reblessed_input_source(self):
  rel = next(rel for rel in tool.file_set(self.root) if rel.endswith('/main.pkl'))
  self.put(rel, b'stable = 999\n')
  self.reject()

 def test_reblessed_reader_return(self):
  rel = self.raw_path('.value.code-units.bin')
  self.put(rel, b'\x00Z')
  self.reject()

 def test_reblessed_reader_plan(self):
  def mutate(bundle):
   fixture = next(row for row in bundle['fixtures'] if row['readerPlan'])
   fixture['readerPlan'][0]['uri'] = 'res:/forged'
  self.fixture_mutation(mutate)

 def test_reblessed_expected_java_utf8(self):
  self.fixture_mutation(lambda b: b['fixtures'][0]['expected'][0].update(stdoutHex='ff'))

 def test_reblessed_expected_utf16(self):
  self.fixture_mutation(lambda b: b['fixtures'][0]['expected'][0].update(stdoutUnits=[65533]))

 def test_reblessed_expression_order(self):
  self.fixture_mutation(lambda b: b['fixtures'][0]['expressions'].reverse())

 def test_actual_extra_even_when_outer_manifest_updated(self):
  self.put('surprise.bin', b'not selected')
  self.reject()

 def test_actual_missing_even_when_outer_manifest_updated(self):
  rel = self.raw_path('.expression.bin')
  (self.root / rel).unlink()
  self.reject()

 def test_manifest_omitted_existing_file(self):
  manifest = self.obj('manifest.json')
  del manifest['files'][self.raw_path('.expression.bin')]
  self.put_json('manifest.json', manifest)
  with self.assertRaises(ValueError):
   tool.verify(self.root)

 def test_provenance_original_path_rewrite(self):
  manifest = self.obj('manifest.json')
  next(iter(manifest['sourceProvenance'].values()))['originalRelativePath'] = 'forged'
  self.put_json('manifest.json', manifest)
  with self.assertRaises(ValueError):
   tool.verify(self.root)

 def test_symlink_rejected(self):
  rel = self.raw_path('.expression.bin')
  (self.root / rel).unlink()
  (self.root / rel).symlink_to('/dev/null')
  with self.assertRaises(ValueError):
   tool.verify(self.root)

if __name__ == '__main__':
 unittest.main()
