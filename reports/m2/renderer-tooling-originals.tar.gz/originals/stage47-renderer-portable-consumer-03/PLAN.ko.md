# Renderer verifier 최종 보정

원본 fixture02를 변경하지 않는다. 고정 report/inventory/closure SHA 인증을 실제 파일 순회 전에 수행하고 tools/tests 승격 뒤 import 경로를 지원한다. negative 실제 clone 하나를 각 시험 후 원문으로 복원하여 같은 위조검사를 반복한다. 기존02 실행은 보존한다.
