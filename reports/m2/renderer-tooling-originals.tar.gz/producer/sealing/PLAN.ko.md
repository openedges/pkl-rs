# Renderer Java 봉인

완료한 프로세스의 raw 원문과 정정 경계를 봉인한다. 새 출력인 inventory/closure만 제외하며 캐시 이름으로 일반 제외하지 않는다. 각 root 아래만 순회한다.
