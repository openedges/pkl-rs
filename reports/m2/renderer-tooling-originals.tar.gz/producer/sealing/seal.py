from pathlib import Path
import json,hashlib,os
B=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47/target/m2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
for number,handle in [(1,38363),(2,82130),(3,95189),(4,34658)]:
 root=B/f'stage47-renderer-api-oracle-{number:02}'
 assert not (root/'closure.json').exists()
 terminal=json.loads((root/'outer-terminal.json').read_bytes());assert terminal['exitCode']==(1 if number==1 else 0)
 if number==1:
  write(root/'report.json',{'scope':'Initial Java helper compile failed before evaluator construction; all planned API calls unexecuted. Original helper/error preserved.', 'apiCalls':0,'plannedApiCalls':648,'unexecutedApiCalls':648,'outcome':'javac-failure','javacExitCode':json.loads((root/'javac.process.json').read_bytes())['result']['exit_code']})
 report=json.loads((root/'report.json').read_bytes())
 interpretation={'apiCallsAcquired':report['apiCalls'],'compatibilityClaim':False,'rawOriginalsPreserved':True}
 if number==2:interpretation.update(authoredParserRejections=72,nestedDirectiveQueryLexicalRejections=16,selectedForInitialPortableExport=520,unselectedOtherDirectiveAcquisitions=40,remainingSelectedFromCorrectiveRoots=True)
 if number==3:interpretation.update(correctedDocumentCalls=72,correctedDirectiveCalls=56,primitiveAnyNoopDispatchCalls=44,selectedForInitialPortableExport=128)
 if number==4:interpretation.update(exactPrimitiveClosureHistoryCalls=44,selectedForInitialPortableExport=44)
 write(root/'interpretation.json',interpretation)
 write(root/'tool-session.json',{'handle':handle,'actualToolTerminalObserved':True,'toolExitCode':terminal['exitCode'],'producerPid':terminal['pid'],'liveHandles':[]})
 write(root/'closure-exclusions.json',{'declaredBeforeTraversal':True,'exactCachePrunePaths':[],'excludedOutputPaths':['inventory.json','closure.json'],'scope':'Only this completed owned output root; no repository/Cargo/source or cache parent walks. All raw captured private files included, no generic build/cache-name exclusion.'})
 rows=[]
 for current,dirs,files in os.walk(root,followlinks=False):
  for name in files:
   p=Path(current)/name;rel=str(p.relative_to(root))
   if rel in ['inventory.json','closure.json']:continue
   assert not p.is_symlink(),str(p)
   rows.append({'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)})
 rows.sort(key=lambda r:r['path']);write(root/'inventory.json',{'files':rows})
 for row in rows:
  p=root/row['path'];assert p.stat().st_size==row['bytes'] and sha(p)==row['sha256']
 write(root/'closure.json',{'closed':True,'reportSha256':sha(root/'report.json'),'inventorySha256':sha(root/'inventory.json'),'files':len(rows),'allPayloadHashesVerified':True,'liveHandles':[]})
 print(json.dumps({'root':str(root),'reportSha256':sha(root/'report.json'),'inventorySha256':sha(root/'inventory.json'),'closureSha256':sha(root/'closure.json'),'files':len(rows)}),flush=True)
