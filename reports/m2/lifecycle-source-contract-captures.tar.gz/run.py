"""Record schema-2 lifecycle source-identity tooling checks."""
import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
assert not (OUT / 'report.json').exists()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
paths = ['tools/m2_class_lifecycle.py', 'tools/tests/test_m2_class_lifecycle.py', 'TESTING.md', '.cargo/config.toml']
before = {name: sha(ROOT / name) for name in paths}
for name in paths:
    destination = OUT / 'sources' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((ROOT / name).read_bytes())
report = {'scope': 'Lifecycle schema/source-capture tooling; no new language/platform/performance claim.',
          'startedUtc': utc(), 'cwd': str(ROOT), 'host': platform.platform(), 'python': sys.version,
          'sourcesBefore': before, 'commands': [], 'complete': False}
def save(): (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
save()
for label, arguments in [
    ('lifecycle-tests', ['-m', 'unittest', 'discover', '-s', 'tools/tests', '-p', 'test_m2_class_lifecycle.py']),
    ('inventory-freshness', ['tools/m2_manifest.py', '--check']),
]:
    command = [sys.executable, *arguments]
    started = time.monotonic()
    print('START', label, flush=True)
    with (OUT / (label + '.stdout.bin')).open('wb') as stdout, (OUT / (label + '.stderr.bin')).open('wb') as stderr:
        child = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr)
        code = child.wait()
    report['commands'].append({'label': label, 'argv': command, 'pid': child.pid, 'exit_code': code,
                               'seconds': time.monotonic() - started, 'stdout_sha256': sha(OUT / (label + '.stdout.bin')),
                               'stderr_sha256': sha(OUT / (label + '.stderr.bin'))})
    save()
    print('FINISH', label, code, flush=True)
report.update(sourcesAfter={name: sha(ROOT / name) for name in paths}, complete=True, finishedUtc=utc())
save()
raise SystemExit(0 if all(row['exit_code'] == 0 for row in report['commands']) and report['sourcesBefore'] == report['sourcesAfter'] else 1)
