"""Package only the authenticated, closed selection into clean regular-file gathers."""
from pathlib import Path
import datetime,hashlib,json,os,platform,shutil,stat,subprocess,sys,tarfile
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def need(x,s):
 if not x:raise ValueError(s)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
selection=json.loads((O/'selection.json').read_bytes());summary=json.loads((O/'summary.json').read_bytes());need(summary['sourceIdentityIssues']==[],'selection issues');evidence=O/'tool-sources/tools/evidence.py';evidence.parent.mkdir(parents=True);shutil.copyfile(R/'tools/evidence.py',evidence)
inputs={str(p):{'sha256':sha(p),'bytes':p.stat().st_size}for p in [O/'selection.json',O/'summary.json',O/'prepare.py',Path(__file__).resolve(),evidence,Path(sys.executable).resolve()]};save(O/'archive-inputs-before.json',inputs)
commands=[]
def execute(label,args):
 row={'command':[str(x)for x in args],'cwd':str(R),'parentPid':os.getpid(),'startedUtc':now()}
 with(O/(label+'.stdout.bin')).open('wb')as out,(O/(label+'.stderr.bin')).open('wb')as err:
  p=subprocess.Popen(row['command'],cwd=R,stdout=out,stderr=err);row['pid']=p.pid;save(O/(label+'.launch.json'),row);row['exitCode']=p.wait()
 row.update(finishedUtc=now(),stdoutSha256=sha(O/(label+'.stdout.bin')),stderrSha256=sha(O/(label+'.stderr.bin')));save(O/(label+'.terminal.json'),row);commands.append(row);need(row['exitCode']==0,'evidence command failed '+label)
# Copy the source bytes only after checking against the frozen selection.
G=O/'gather';A=O/'archives';G.mkdir();A.mkdir();archives=[]
fixture=R/'tests/fixtures/m2-collection-transforms';manifest_pin=selection['fixtureManifestSha256'];need(sha(fixture/'manifest.json')==manifest_pin,'fixture manifest changed')
small_dependency_files=[]
for n in ['01','02']:
 root=O.parent/('stage51-native-policy-parser-tests-'+n)
 for name in ['report.json','stdout.bin','stderr.bin']:
  p=root/name;small_dependency_files.append({'sourcePath':str(p),'sha256':sha(p),'bytes':p.stat().st_size,'unit':'parser-reviews','captureRelative':'DEPENDENCY_INPUTS/parser-tests-'+n+'/'+name})
save(O/'dependency-inputs.json',small_dependency_files)
for unit in ['java-authorities','fixture-tooling','parser-reviews']:
 gather=G/unit;gather.mkdir();rows=[x for x in selection['rows']if x['unit']==unit]
 for row in rows:
  p=Path(row['sourcePath']);need(sha(p)==row['sha256']and p.stat().st_size==row['bytes']and stat.S_IMODE(p.stat().st_mode)==row['mode'],'selected original changed')
  if row['storage']=='archive-payload':
   dest=gather/'originals'/row['root']/row['relative'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);need(sha(dest)==row['sha256'],'gather copy changed')
  else:
   ref=row['fixtureReference'];need(sha(Path(ref['path']))==row['sha256'],'fixture reference changed')
 deps=[x for x in small_dependency_files if x['unit']==unit]
 for row in deps:
  p=Path(row['sourcePath']);need(sha(p)==row['sha256'],'dependency changed');d=gather/row['captureRelative'];d.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,d)
 save(gather/'CAPTURE_SELECTION.json',{'schema':1,'selectionSha256':sha(O/'selection.json'),'originalRows':rows,'extraClosedDependencyFiles':deps,'exactPrewalkPrunes':selection['exactPrewalkPrunes'],'excludedDuplicateSubtree':selection['explicitDuplicateSubtreeExcludedBeforeDescent'],'unselectedLiveRoots':'All candidate03/native/required checks/platform/live outputs are outside this explicit selection.'})
 save(gather/'DEPENDENCIES.json',{'schema':1,'repositoryRootAtCapture':str(R),'pendingRootGitBindingRequired':True,'installedFixtureManifest':{'repositoryRelative':'tests/fixtures/m2-collection-transforms/manifest.json','sha256':manifest_pin},'fixtureReferenceRule':'Every fixture-reference row records its exact future tracked path and bytes; these are byte references, not a claim of existing Git blob identity. Root must bind these paths to final commit before publication closeout.','duplicateExportRule':{'sourceRoot':selection['explicitDuplicateSubtreeExcludedBeforeDescent'],'targetRepositoryRelative':'tests/fixtures/m2-collection-transforms','rule':'same relative path for every declared installed manifest file plus manifest.json','manifestSha256':manifest_pin,'declaredFiles':summary['candidateExportAliasFiles'],'declaredBytes':summary['candidateExportAliasBytes'],'actualAliasFilesWereDirectlyHashed':True,'undeclaredSubtreeChildrenNotSelected':True},'toolReferences':[{'repositoryRelative':p.relative_to(R).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size}for p in [R/'tools/collection_transform_fixtures.py',R/'tools/tests/test_collection_transform_fixtures.py']],'runtimeQualification':'Original profile.json and copied oracle/reference locks bind pinned Java0.32.0 JAR/JDK files. Large external runtime files and caches are not archived. No evaluation is required for archive verification.','fullJavaAdministrativeLifecyclePassed':False,'newRustOrPortableCompatibilityClaim':False,'javaCapturedApiCalls':2108,'ordinaryObservationRows':2000,'intentNotReachedRows':96,'postClosePublicApiBoundaryRows':12,'originalSourceCodeAdapterRepeatsRemainSeparate':2})
 (gather/'README.md').write_text('''# Stage51 closed observation and verification evidence

This archive contains one logical unit of closed Java-oracle or verification-tool evidence. It does not contain current runtime candidates or assert new native, browser, Node, full-language, or full Java lifecycle compatibility.

`CAPTURE_SELECTION.json` binds every selected original path, file hash, size, and mode. `DEPENDENCIES.json` declares exact fixture references and pending repository commit binding. Java payload files marked `fixture-reference` are intentionally reused from the installed fixture provenance at byte-identical paths. They are not silently omitted and are not treated as existing Git blobs before root commit binding.

Original intent failures, post-close API boundaries, the parser's two accepted protocol counterexamples, and its failed historical seal guard remain distinct from the corrective observations. Repeated raw observations are not new compatibility features. Protocol mocks do not execute an evaluator.

The gather contains regular files only. Exact private Java cache paths were pruned before original traversal; no generic directory-name exclusion is used. `tools/evidence.py` creates and verifies this archive; a separate verification process and independent raw-member readback are recorded by the producer.
''')
 archive=A/('stage51-'+unit+'-prep.tar.gz');execute(unit+'-create',[sys.executable,'-B',evidence,'create',gather,archive]);need(archive.stat().st_size<100_000_000,'archive exceeds GitHub limit');execute(unit+'-verify',[sys.executable,'-B',evidence,'verify',archive])
 checked=0
 with tarfile.open(archive,'r:gz')as tar:
  members=tar.getmembers();need(len(members)==len({m.name for m in members}),'duplicate member');need(all(m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts for m in members),'unsafe archive member')
  actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in members}
  expected={p.relative_to(gather).as_posix():sha(p)for p in gather.rglob('*')if p.is_file()};need(set(actual)==set(expected)|{'EVIDENCE.json'},'member coverage differs')
  for name,h in expected.items():need(actual[name]==h,'raw member changed '+name);checked+=1
 row={'unit':unit,'path':str(archive),'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'payloadFiles':checked,'gatherBytes':sum(p.stat().st_size for p in gather.rglob('*')if p.is_file()),'createExitCode':0,'separateVerifyExitCode':0,'rawMemberReadback':True};archives.append(row);save(O/'archive-progress.json',archives)
# Post-archive guard: every original file and every reused fixture reference still matches the selected bytes/mode.
changes=[]
for row in selection['rows']:
 p=Path(row['sourcePath'])
 if not p.is_file()or p.is_symlink()or sha(p)!=row['sha256']or p.stat().st_size!=row['bytes']or stat.S_IMODE(p.stat().st_mode)!=row['mode']:changes.append(str(p))
 if row['storage']=='fixture-reference'and sha(Path(row['fixtureReference']['path']))!=row['sha256']:changes.append(row['fixtureReference']['path'])
for row in small_dependency_files:
 if sha(Path(row['sourcePath']))!=row['sha256']:changes.append(row['sourcePath'])
for p,row in inputs.items():need(sha(Path(p))==row['sha256'],'archive tool/input drift')
need(sha(fixture/'manifest.json')==manifest_pin,'fixture manifest changed after archive')
save(O/'original-guard.json',{'selectedFilesChecked':len(selection['rows']),'extraDependencyFilesChecked':len(small_dependency_files),'originalChanges':changes,'modesChecked':True,'reusedFixtureReferencesChecked':True,'largeDuplicateExportAliasGuard':'Every declared candidate alias was directly hashed at preparation; actual selection excludes that duplicate subtree. Installed fixture manifest remains pinned.'});need(not changes,'original source changed')
report={'status':'CLOSED-target-only-archive-preparation','archives':archives,'compressedBytes':sum(x['compressedBytes']for x in archives),'selectionSha256':sha(O/'selection.json'),'summarySha256':sha(O/'summary.json'),'originalGuardSha256':sha(O/'original-guard.json'),'originalChanges':changes,'processes':commands,'artifactInputsStable':True,'pendingRootGitBindingRequired':True,'repositoryMutation':False,'engineExecutions':0,'allArchivesBelow100000000':True,'finishedUtc':now()};save(O/'archive-report.json',report);print(json.dumps(report),flush=True)
