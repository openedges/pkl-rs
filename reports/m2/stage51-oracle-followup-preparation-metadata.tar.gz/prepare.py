"""Select only explicit closed producer roots, authenticate, and deduplicate by exact file bytes."""
from pathlib import Path
import collections,datetime,hashlib,json,os,platform,stat,sys
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=True,indent=2)+'\n')
def need(x,s):
 if not x:raise ValueError(s)
roots={n:O.parent/n for n in ['stage51-collection-oracle-06','stage51-collection-oracle-07','stage51-collection-oracle-08','stage51-collection-fixture-duration-extension-01','stage51-collection-fixture-handoff-03','stage51-collection-fixture-tests-03','stage51-native-policy-parser-b-review-01','stage51-native-policy-parser-b-review-02']}
anchors={'stage51-collection-oracle-06':('2c1991b424423b9141a79edab3e3ec94dcf6f48c1d83d280e9944b28cb4f1167','a8e793705a91cddd3b4ef4c30c739f14f829a374e9f8a36018f779a03b592aa1'),'stage51-collection-oracle-07':('a9be6ef3200685c5ee4814289ee3f02470789fbfeae8d2d55d633df74c3cf1ff','6f91136ae117ada78fead17c4297aee151494861a1d52d63f26c032ecf6d057d'),'stage51-collection-oracle-08':('0e87e342cc7200d54856ec25d59692eb2ef536027e7cc99ce5cc442a44306012','a8657bc797719cca1ff9ad84cd0c1d5ccdd79687233586d2958f4fc4a449cf36'),'stage51-collection-fixture-handoff-03':('d33e600c1cb33dd0fee1fe1bc0cf83d77cbb97f15427fe134e7a8b21d5456870','89019ca9343d36f530c9e31a80d25f6c3518860b5e546f7a5b6b1e75161651cf'),'stage51-native-policy-parser-b-review-01':('c4d9cd5ae571e2bf2e80d36bfec141e409c4a5e969dc5052662f71fe122d4e75','f1cad9c27488579a92e60133d232938fb7d25a9126e0ad3c840b8558c2538ea1'),'stage51-native-policy-parser-b-review-02':('b679e781cf82a27e317ca49de7b7fde6cfbab664f0e7ed38dc2cf5468b717ddd','cdd0ab5b1cce6d9b5995453ff022e0fc6fc823a37b47148b7b600eb4ab85dec1')}
# Authenticate root inventories before using any declared file paths or traversing.
sealed={}
for name,(h,c)in anchors.items():
 root=roots[name];need(sha(root/'handoff.json')==h and sha(root/'closure.json')==c,'root anchor differs '+name);closure=json.loads((root/'closure.json').read_bytes());need(closure['sealed'] is True and closure['handoffSha256']==h and sha(root/'inventory.json')==closure['inventorySha256'],'root closure link differs')
 inv=json.loads((root/'inventory.json').read_bytes());sealed[name]=inv['files']
 for rel,row in inv['files'].items():
  p=Path(rel);need(not p.is_absolute()and '..'not in p.parts,'unsafe declared original path');p=root/p;need(p.is_file()and not p.is_symlink()and sha(p)==row['sha256']and p.stat().st_size==row['bytes'],'sealed original payload changed '+str(p))
H=roots['stage51-collection-fixture-handoff-03'];h=json.loads((H/'handoff.json').read_bytes());tests=roots['stage51-collection-fixture-tests-03'];need(sha(tests/'report.json')==h['testsReportSha256'],'tests report anchor differs')
for p,row in h['testLogBindings'].items():need(Path(p).is_relative_to(tests)and sha(Path(p))==row['sha256'],'tests log binding differs')
ext=roots['stage51-collection-fixture-duration-extension-01']
for name in ['promotion-report.json','proposal.json']:need(sha(ext/name)==sha(H/('stage51-collection-fixture-duration-extension-01--'+name)),'extension receipt differs')
need(sha(ext/'before/manifest.json')=='1f1aecb803136b9c69bee71473d189e97bbb3d57cf379b24a4e52cb63e33bcf4','old fixture manifest differs')
old_manifest=json.loads((ext/'before/manifest.json').read_bytes())
for name in ['fixtures.json','provenance-map.json']:need(sha(ext/'before'/name)==old_manifest['files'][name]['sha256'],'old derived bytes differ')
need(sha(ext/'before/collection_transform_fixtures.py')=='2becf086b6369e8d7ff4cce25b4a7199b44a27c90a4236c310f88d88cbcca0eb','old tool differs');need(sha(ext/'before/test_collection_transform_fixtures.py')=='1dba032bead26221d7086feab2efd979dd003e6398c6aac88c2dd24ca6bcbf91','old tests differ')
fixture=R/'tests/fixtures/m2-collection-transforms';need(sha(fixture/'manifest.json')=='a90cc8d0c409b03c783192f39cf265052e3efa48e0d9bc5f7d64818e57a2558d','installed manifest differs');fm=json.loads((fixture/'manifest.json').read_bytes())
prunes=[]
for name,root in roots.items():
 if name.startswith('stage51-collection-oracle-'):
  for p in json.loads((root/'cache-prunes.json').read_bytes())['exactPaths']:
   need(Path(p).is_relative_to(root/'runtime-private')and Path(p).name=='org.graalvm.polyglot','unexpected cache prune');prunes.append(p)
need(len(prunes)==28 and len(set(prunes))==28,'private cache set differs')
# Duplicate export is intentionally excluded BEFORE descent and represented from its authenticated manifest.
duplicate=ext/'fixture';need(sha(duplicate/'manifest.json')==sha(fixture/'manifest.json'),'export/installed manifests differ')
alias_rows={}
for rel,row in fm['files'].items():
 p=duplicate/rel;q=fixture/rel;need(sha(p)==sha(q)==row['sha256'] and p.stat().st_size==q.stat().st_size==row['bytes'],'export/installed alias bytes differ '+rel);alias_rows[rel]=row
alias_rows['manifest.json']={'sha256':sha(fixture/'manifest.json'),'bytes':(fixture/'manifest.json').stat().st_size}
save(O/'duplicate-export-subtree.json',{'sourceRoot':str(duplicate),'targetRoot':str(fixture),'referenceType':'pending-tracked-repository-files-not-yet-Git-blobs','declaredFiles':alias_rows,'qualification':'All declared paths read and joined by byte hash/size. Subtree is intentionally not descended by selector; no claim about undeclared/empty children. Future root Git binding required.'})
exclude=set(prunes)|{str(duplicate)};rows=[];dirs=[]
for name,root in roots.items():
 todo=[root]
 while todo:
  p=todo.pop()
  if str(p)in exclude:continue
  need(not p.is_symlink(),'unexpected selected link '+str(p));s=p.stat()
  if stat.S_ISDIR(s.st_mode):
   dirs.append({'path':str(p),'mode':stat.S_IMODE(s.st_mode)})
   todo.extend(sorted((Path(e.path)for e in os.scandir(p)),reverse=True));continue
  need(stat.S_ISREG(s.st_mode),'unexpected selected nonregular file');rel=p.relative_to(root).as_posix();digest=sha(p);row={'sourcePath':str(p),'root':name,'relative':rel,'bytes':s.st_size,'sha256':digest,'mode':stat.S_IMODE(s.st_mode),'producerSealed':rel in sealed.get(name,{})or rel in ['inventory.json','closure.json']}
  if name.startswith('stage51-collection-oracle-'):
   group='java'+name.rsplit('-',1)[1];ref='provenance/'+group+'/'+rel
   if ref in fm['files']:
    target=fixture/ref;need(sha(target)==digest and fm['files'][ref]['sha256']==digest and fm['files'][ref]['bytes']==s.st_size,'oracle/installed join differs');row['fixtureReference']={'path':str(target),'repositoryRelative':'tests/fixtures/m2-collection-transforms/'+ref,'sha256':digest,'bytes':s.st_size,'status':'pending-root-Git-binding'}
  row['unit']='java-authorities'if name.startswith('stage51-collection-oracle-')else('fixture-tooling'if name.startswith('stage51-collection-fixture-')else'parser-reviews')
  # Retain small primary authority documents as raw, even when their fixture copies are also available.
  authority={'inventory.json','closure.json','handoff.json','readback-report.json','cases.json','profile.json','CollectionProbe.java','outer-launch.json','outer-terminal.json','actual-terminal.json','cache-prunes.json','inputs-before.json','inputs-after.json','prepare.py','run.py','launch.py','readback.py','seal.py','report.json'}
  row['storage']='fixture-reference'if 'fixtureReference'in row and rel not in authority else'archive-payload'
  rows.append(row)
counts=collections.Counter();sizes=collections.Counter()
for row in rows:counts[row['storage']]+=1;sizes[row['storage']]+=row['bytes']
selection={'schema':1,'scope':'Only eight explicit closed B producer roots; no candidate03, live outputs, core/native/platform captures.','roots':{k:str(v)for k,v in roots.items()},'rootAnchors':anchors,'exactPrewalkPrunes':prunes,'explicitDuplicateSubtreeExcludedBeforeDescent':str(duplicate),'testPrivateExcludedNotWalked':str(R/'target/m2/stage51-collection-fixture-tests-private'),'noGenericBuildCacheExclusions':True,'rows':rows,'directories':dirs,'fixtureManifestSha256':sha(fixture/'manifest.json'),'pendingRootGitBindingRequired':True,'fullJavaAdministrativeLifecyclePassed':False}
save(O/'selection.json',selection)
summary={'selectedRoots':len(roots),'selectedFiles':len(rows),'selectedBytes':sum(r['bytes']for r in rows),'counts':counts,'sizes':sizes,'candidateExportAliasFiles':len(alias_rows),'candidateExportAliasBytes':sum(x['bytes']for x in alias_rows.values()),'exactPrivateCachePrunes':len(prunes),'sourceIdentityIssues':[],'selectionSha256':sha(O/'selection.json'),'units':{u:{'payloadFiles':sum(r['unit']==u and r['storage']=='archive-payload'for r in rows),'payloadBytes':sum(r['bytes']for r in rows if r['unit']==u and r['storage']=='archive-payload')}for u in ['java-authorities','fixture-tooling','parser-reviews']},'currentCandidateOrCompatibilityClaims':False,'fixtureStatus':'Actual installed byte equality proven; commit/Git blob binding remains root responsibility.'}
save(O/'summary.json',summary);print(json.dumps(summary),flush=True)
