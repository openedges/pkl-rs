from pathlib import Path
import hashlib,json,os,stat
O=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();s=json.loads((O/'selection.json').read_bytes());expected={r['sourcePath']for r in s['rows']};expected_dirs={r['path']:r['mode']for r in s['directories']};exclude=set(s['exactPrewalkPrunes'])|{s['explicitDuplicateSubtreeExcludedBeforeDescent']};files=set();dirs={};bad=[]
for root in s['roots'].values():
 todo=[Path(root)]
 while todo:
  p=todo.pop()
  if str(p)in exclude:continue
  if p.is_symlink():bad.append(str(p));continue
  m=p.stat().st_mode
  if stat.S_ISDIR(m):dirs[str(p)]=stat.S_IMODE(m);todo.extend(Path(e.path)for e in os.scandir(p))
  elif stat.S_ISREG(m):files.add(str(p))
  else:bad.append(str(p))
report={'selectedRoots':len(s['roots']),'selectedFiles':len(expected),'filesAdded':sorted(files-expected),'filesMissing':sorted(expected-files),'directoriesAdded':sorted(set(dirs)-set(expected_dirs)),'directoriesMissing':sorted(set(expected_dirs)-set(dirs)),'directoryModesChanged':[p for p in dirs.keys()&expected_dirs.keys()if dirs[p]!=expected_dirs[p]],'nonregularEntries':bad,'exactPrewalkPrunes':sorted(exclude),'selectionSha256':sha(O/'selection.json'),'precedingAllFileHashSizeModeGuardSha256':sha(O/'original-guard.json')};(O/'post-pathset-guard.json').write_text(json.dumps(report,indent=2)+'\n');assert not any(report[k]for k in ['filesAdded','filesMissing','directoriesAdded','directoriesMissing','directoryModesChanged','nonregularEntries']);print(json.dumps(report),flush=True)
