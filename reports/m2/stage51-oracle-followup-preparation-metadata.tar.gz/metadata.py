from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,tarfile
O=Path(__file__).resolve().parent;R=O.parents[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=json.loads((O/'selection.json').read_bytes());a=json.loads((O/'archive-report.json').read_bytes());guard=json.loads((O/'post-pathset-guard.json').read_bytes());assert a['status'].startswith('CLOSED')and not a['originalChanges']and not any(guard[k]for k in ['filesAdded','filesMissing','directoriesAdded','directoriesMissing','directoryModesChanged','nonregularEntries'])
(O/'PLAN.ko.md').write_text('''# Stage51 닫힌 B 증거 게시 준비

선택은 selection.json의 정확한8개 root와 parser unit의 명시된6개 report/log 파일뿐이다. Java06/07/08, additive fixture export/handoff03/tests03, native policy parser 검토01/02를 포함한다. candidate03, 진행 중 build/required5/native/Node/browser/M1 및 후속 C 감사는 선택하지 않는다.

Java 원본의28개 runtime cache 경로는 inventory/closure 인증 후 하강 전에 정확히 제외했다. 테스트 private clone root도 선택하지 않는다. generic cache/build 이름 필터를 사용하지 않는다. 중복 export fixture는 하강 전에 제외하고 선언된75,863개 경로를 설치 fixture와 직접 SHA/size로 연결했다. 추가 자식이나 빈 디렉터리가 없다고 가정하지 않는다.

Java 원본24,050개 파일 중23,397개는 tests/fixtures/m2-collection-transforms/provenance/java06..08의 byte-identical 파일로 연결한다. 작은 원본 authority/report/source문서는 검토를 위해 archive에도 보존했다. fixture파일은 아직 이 게시 준비에서 Git blob으로 검증한 것이 아니다. Root가 최종 commit에 정확한 경로·SHA를 연결해야 게시 closeout이 완성된다. 같은 manifest와 상대경로 규칙으로 중복 export mapping을 재구성할 수 있다.

기존1,272개 API와 원시 파일은 변하지 않았다. 확장 corpus는152sessions/2,108API이며2,000ordinary/96intent-not-reached/12post-close로 구분한다. Java07 output.text4회는 resource policy에서 renderer 전에 거부된 실제 오류이고 이를 Duration rendering success로 세지 않는다. Java08의 명시 renderer 후속은 별도 원문이다. 반복 획득, GC요청, protocol mock은 신규 compatibility 기능 통과나 Java 행정 lifecycle 동등성으로 세지 않는다.

원본 parser가 수용한 두 protocol 반례와 수정 후 거절, historical seal guard 실패를 모두 보존한다. 각 semantic archive는 clean regular-file gather에서 tools/evidence.py create, 별도 verify 프로세스, 독립 전체 raw member SHA readback을 완료했다. 원본 hash/size/mode와 전체 선택 pathset도 후행 대조했다. 100,000,000B 제한보다 작다. 새 reports나 Git은 쓰지 않았다.
''')
M=O/'gather/preparation-metadata';M.mkdir();names=['prepare.py','prepare.stdout.bin','prepare.stderr.bin','summary.json','selection.json','archive.py','archive-inputs-before.json','archive-launch.json','archive-terminal.json','archive-report.json','archive.stdout.bin','archive.stderr.bin','archive-progress.json','dependency-inputs.json','launch-archives.py','post-guard.py','post-guard.stdout.bin','post-guard.stderr.bin','post-pathset-guard.json','original-guard.json','PLAN.ko.md','metadata.py']
for unit in ['java-authorities','fixture-tooling','parser-reviews']:
 for action in ['create','verify']:
  names.extend(unit+'-'+action+suffix for suffix in ['.stdout.bin','.stderr.bin','.launch.json','.terminal.json'])
for name in names:
 p=O/name;assert p.is_file();shutil.copyfile(p,M/name)
(M/'tool-sources/tools').mkdir(parents=True);shutil.copyfile(O/'tool-sources/tools/evidence.py',M/'tool-sources/tools/evidence.py')
excluded=O/'duplicate-export-subtree.json'
(M/'DUPLICATE_ALIAS_RULE.json').write_text(json.dumps({'fullAuditTableRetainedAt':str(excluded),'fullAuditTableSha256':sha(excluded),'excludedFromMetadataArchiveReason':'This table repeats all installed manifest entries. Exact sourceRoot/targetRoot + identical relative paths for all declared manifest files and manifest.json reproduces mapping. No original source/raw evidence is discarded.','manifestRepositoryRelative':'tests/fixtures/m2-collection-transforms/manifest.json','manifestSha256':s['fixtureManifestSha256'],'sourceRoot':s['explicitDuplicateSubtreeExcludedBeforeDescent'],'targetRepositoryRelative':'tests/fixtures/m2-collection-transforms','files':75863,'pendingRootGitBindingRequired':True},indent=2)+'\n')
(M/'METADATA_SOURCE_SELECTION.json').write_text(json.dumps({'files':{name:{'source':str(O/name),'sha256':sha(O/name),'bytes':(O/name).stat().st_size}for name in names},'semanticArchives':a['archives'],'qualification':'The metadata archive creation/verification receipts are finalized outside itself to avoid recursive self inclusion. Final handoff carries those receipts.'},indent=2)+'\n')
archive=O/'archives/stage51-preparation-metadata.tar.gz';rows=[]
for action in ['create','verify']:
 cmd=[sys.executable,'-B',str(O/'tool-sources/tools/evidence.py'),action]
 cmd += [str(M),str(archive)]if action=='create'else[str(archive)]
 with(O/('metadata-'+action+'.stdout.bin')).open('wb')as out,(O/('metadata-'+action+'.stderr.bin')).open('wb')as err:
  p=subprocess.Popen(cmd,cwd=R,stdout=out,stderr=err);code=p.wait()
 row={'command':cmd,'pid':p.pid,'exitCode':code,'stdoutSha256':sha(O/('metadata-'+action+'.stdout.bin')),'stderrSha256':sha(O/('metadata-'+action+'.stderr.bin'))};rows.append(row);assert code==0
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert all(m.isfile()and not Path(m.name).is_absolute()and '..'not in Path(m.name).parts for m in members);assert len(members)==len({m.name for m in members});actual={m.name:hashlib.sha256(tar.extractfile(m).read()).hexdigest()for m in members};expected={p.relative_to(M).as_posix():sha(p)for p in M.rglob('*')if p.is_file()};assert set(actual)==set(expected)|{'EVIDENCE.json'};assert all(actual[n]==h for n,h in expected.items())
report={'path':str(archive),'sha256':sha(archive),'compressedBytes':archive.stat().st_size,'payloadFiles':len(expected),'rawMemberReadback':True,'commands':rows};assert report['compressedBytes']<100000000;(O/'metadata-archive-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
