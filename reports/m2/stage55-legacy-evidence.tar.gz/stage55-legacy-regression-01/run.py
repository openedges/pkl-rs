#!/usr/bin/env python3
"""Execute authorized legacy contracts; preserve every raw result and failure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path.cwd().resolve()
OUT = ROOT / "target/m2/stage55-legacy-regression-01"
sys.path.insert(0, str(ROOT / "tools"))
import m2_source_inputs


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(path):
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


def put(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, indent=2) + "\n")


names = set(m2_source_inputs.source_paths(ROOT))
names.update(["tools/m2_trace.py", "tools/java/M2TraceProbe.java", "compatibility/m2-trace.json",
              "tools/platform/trace-session.mjs", "tools/platform/compare-trace-sessions.mjs",
              "tools/platform/package.json", "tools/platform/package-lock.json"])
names.update(p.relative_to(ROOT).as_posix() for p in (ROOT / "tests/fixtures/m2-trace").iterdir() if p.is_file())
before = {name: sha(ROOT / name) for name in sorted(names)}
put("sources-before.json", before)
env = dict(os.environ)
env.update(CARGO_INCREMENTAL="0", PYTHONDONTWRITEBYTECODE="1")
report = {"schema": 1, "scope": "Actual legacy deprecation and default trace regressions on frozen Stage55; strict nonpasses retained. No full M2 or performance claim.",
          "cwd": str(ROOT), "started_utc": now(), "complete": False,
          "host": platform.platform(), "python": {"version": sys.version, **identity(Path(sys.executable).resolve())},
          "environment": {name: env[name] for name in sorted(env) if name in {"PATH", "HOME", "TMPDIR", "TMP", "TEMP", "LANG", "LC_ALL", "TZ", "TERM", "PLAYWRIGHT_BROWSERS_PATH", "CARGO_INCREMENTAL", "PYTHONDONTWRITEBYTECODE", "RUSTUP_TOOLCHAIN", "CARGO_TARGET_DIR", "JAVA_HOME", "PKL_ORACLE_JAVA"}},
          "commands": [], "artifacts": {}, "source_count": len(before), "infrastructure_failures": [],
          "build_scope": "Only two requested pkl-runtime release examples; existing target/release cache reused for disk bound. No full workspace build. Build logs and frozen deliverables are below this packet."}
put("report.json", report)


def execute(label, command, timeout=1800):
    folder = OUT / "commands" / label
    folder.mkdir(parents=True, exist_ok=False)
    process = {"label": label, "command": command, "cwd": str(ROOT), "started_utc": now(), "timeout_seconds": timeout}
    started = time.monotonic()
    with (folder / "stdout.bin").open("xb") as stdout, (folder / "stderr.bin").open("xb") as stderr:
        try:
            child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
            process["pid"] = child.pid
            put("active.json", process)
            try:
                process.update(status="executed", exit_code=child.wait(timeout=timeout))
            except subprocess.TimeoutExpired:
                child.kill()
                process.update(status="timed-out", exit_code=child.wait())
        except OSError as error:
            process.update(status="launch-failed", exit_code=None, error=repr(error))
    process.update(finished_utc=now(), elapsed_seconds=time.monotonic() - started,
                   stdout=identity(folder / "stdout.bin"), stderr=identity(folder / "stderr.bin"))
    (folder / "process.json").write_text(json.dumps(process, indent=2) + "\n")
    report["commands"].append(process)
    if process["status"] != "executed":
        report["infrastructure_failures"].append(label + ": " + process["status"])
    put("report.json", report)
    print(label, process["status"], process["exit_code"], flush=True)
    return process


def freeze(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    assert source.read_bytes() == destination.read_bytes()
    report["artifacts"][str(destination.relative_to(OUT))] = {"origin": identity(source), "frozen": identity(destination)}
    put("report.json", report)


build = execute("build-examples", ["cargo", "build", "-p", "pkl-runtime", "--release", "--locked",
                                     "--example", "deprecation_fixture_probe", "--example", "trace_host_probe"])
if build["status"] == "executed" and build["exit_code"] == 0:
    for name in ["deprecation_fixture_probe", "trace_host_probe"]:
        freeze(ROOT / "target/release/examples" / name, OUT / "artifacts" / name)
    platforms = ROOT / "target/m2/stage55-platforms-02"
    freeze(platforms / "pkl_napi.node", OUT / "artifacts/pkl_napi.node")
    for path in sorted((platforms / "wasm").iterdir()):
        assert path.is_file() and not path.is_symlink()
        freeze(path, OUT / "artifacts/wasm" / path.name)
    python = sys.executable
    dep = OUT / "deprecation"
    execute("deprecation-capture", [python, "-B", "tools/deprecation_compare.py", "--output", str(dep),
        "--native", str(OUT / "artifacts/deprecation_fixture_probe"), "--wasm", str(OUT / "artifacts/wasm"),
        "--napi", str(OUT / "artifacts/pkl_napi.node"), "--record-only"], timeout=2400)
    if (dep / "report.json").is_file():
        execute("deprecation-verify-report", [python, "-B", "tools/deprecation_compare.py", "--verify-report", str(dep)])
        execute("deprecation-verify-full", [python, "-B", "tools/deprecation_compare.py", "--verify-full", str(dep)])
    trace = OUT / "trace"
    execute("trace-capture", [python, "-B", "tools/m2_trace.py", "--output", str(trace),
        "--candidate", str(OUT / "artifacts/trace_host_probe"), "--record-only"], timeout=2400)
    if (trace / "report.json").is_file():
        execute("trace-verify-report", [python, "-B", "tools/m2_trace.py", "--verify-report", str(trace)])
        execute("trace-verify-contract", [python, "-B", "tools/m2_trace.py", "--verify-contract", str(trace)])
        execute("trace-portable", [shutil.which("node") or "node", "tools/platform/compare-trace-sessions.mjs",
            str(OUT / "trace-portable"), str(OUT / "artifacts/wasm"), str(OUT / "artifacts/pkl_napi.node"), str(trace)], timeout=1200)
else:
    report["infrastructure_failures"].append("release example build failed; captures not executed")
after = {name: sha(ROOT / name) for name in sorted(names)}
put("sources-after.json", after)
report["source_changes"] = sorted(name for name in names if before[name] != after[name])
for item in report["artifacts"].values():
    item["origin_after_sha256"] = sha(Path(item["origin"]["path"]))
    item["frozen_after_sha256"] = sha(Path(item["frozen"]["path"]))
report.update(complete=True, finished_utc=now())
put("report.json", report)
print(json.dumps({"complete": True, "source_changes": report["source_changes"],
                  "infrastructure_failures": report["infrastructure_failures"]}), flush=True)
