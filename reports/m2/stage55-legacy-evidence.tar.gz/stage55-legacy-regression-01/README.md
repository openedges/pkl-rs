# Stage55 legacy regression evidence

This is local raw evidence for the frozen Stage55 implementation. The two requested release examples were built with `CARGO_INCREMENTAL=0` using the existing release dependency cache. Build commands, runtime records, source hashes and frozen deliverables are retained here. The actual parent implementation commit binding is pending.

Deprecation executed all 56 cases twice on native, N-API and Chromium: 306 pass and 30 Java oracle-error across 336 rows. Default trace executed all 45 cases twice on native, Node and Chromium: 174 pass and 96 Java oracle-error across 270 rows. No new non-oracle mismatch, unsupported case or acquisition failure was recorded. Known oracle-error channels are preserved in full and are never counted as compatibility passes.

The standalone integrity checks exited zero; strict deprecation and trace checks exited one. The trace runner accurately records a supplied artifact, with the actual enclosing release build retained separately. Portable trace architecture passed. All 4,553 recorded source files and frozen deliverables stayed unchanged; independent raw validation also checked 3,828 portable trace channel pairs.

`summary.json` links exact reports and hashes. `report.json` records the wrapper and every subprocess. `commands/` contains complete raw stdout/stderr. `deprecation/`, `trace/` and `trace-portable/` contain the actual matrices. `files.json` records each packet member before the terminal seal; `seal.json` authenticates that manifest. No production source, fixture, documentation or reference version was changed. No performance, whole M2, API-completion or hosted CI result is claimed.
