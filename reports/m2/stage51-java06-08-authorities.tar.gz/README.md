# Stage51 closed observation and verification evidence

This archive contains one logical unit of closed Java-oracle or verification-tool evidence. It does not contain current runtime candidates or assert new native, browser, Node, full-language, or full Java lifecycle compatibility.

`CAPTURE_SELECTION.json` binds every selected original path, file hash, size, and mode. `DEPENDENCIES.json` declares exact fixture references and pending repository commit binding. Java payload files marked `fixture-reference` are intentionally reused from the installed fixture provenance at byte-identical paths. They are not silently omitted and are not treated as existing Git blobs before root commit binding.

Original intent failures, post-close API boundaries, the parser's two accepted protocol counterexamples, and its failed historical seal guard remain distinct from the corrective observations. Repeated raw observations are not new compatibility features. Protocol mocks do not execute an evaluator.

The gather contains regular files only. Exact private Java cache paths were pruned before original traversal; no generic directory-name exclusion is used. `tools/evidence.py` creates and verifies this archive; a separate verification process and independent raw-member readback are recorded by the producer.
