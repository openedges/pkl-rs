from pathlib import Path
import hashlib,json,datetime,stat
R=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return json.loads((R/n).read_bytes())
def write(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
report=load('report.json');process=load('audit-process.json');assert process['exitCode']==0
assert report['declared_inputs_unchanged_during_audit'] and report['source_binding']['all_match_commit_blobs']
assert not report['lifecycle']['raw_mismatches']
write('outer-terminal.json',{'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification':'Late transcription of C-observed actual tool terminal, not a fabricated contemporaneous process-finish time. Child start/end times are separately recorded by audit-process.json.','session_id':95672,'exit_code':0,'terminal_chunk_id':'79d3ee','child_pid':process['pid'],'process_report_sha256':H(R/'audit-process.json'),'stdout_sha256':H(R/'audit.stdout.bin'),'stderr_sha256':H(R/'audit.stderr.bin'),'producer_terminal_receipt':report['wrapper_own_terminal']})
files={}
# This is a fresh bounded audit-output root, not an evidence/source/cache walk.
for p in R.iterdir():
 if p.name in ['closure.json','handoff.json']:continue
 if p.name=='baseline':
  expected={'stage47-final-regression-audit.json','stage47-final-summary.json','stage47-final-raw-changes.json','stage47-final-source-map.json','stage47-final-regression-captures.json'}
  assert {x.name for x in p.iterdir()}==expected
  for name in sorted(expected):
   q=p/name;assert stat.S_ISREG(q.lstat().st_mode);files['baseline/'+name]={'sha256':H(q),'bytes':q.stat().st_size}
 else:
  assert stat.S_ISREG(p.lstat().st_mode),str(p)
  files[p.name]={'sha256':H(p),'bytes':p.stat().st_size}
write('closure.json',{'schema':1,'scope':'Exact C audit files and five authenticated Stage47 baseline metadata copies. No producer/cache tree enumeration.','files':files,'payloadFiles':len(files)})
write('handoff.json',{'status':'CLOSED','scope':'Independent read-only Stage48 full selected and persistent data audit, frozen5e68c4b; not full M2 compatibility.','root':str(R),'reportSha256':H(R/'report.json'),'closureSha256':H(R/'closure.json'),'outerTerminalSha256':H(R/'outer-terminal.json'),'actualAuditSession':95672,'actualAuditExitCode':0,'actualTerminalChunk':'79d3ee','producerActualSession':68740,'producerExitCode':0,'producerTerminalReceiptSha256':process['receiptSha256'],'language':report['language'],'lifecycle':report['lifecycle'],'source_binding':report['source_binding'],'gates':report['gates'],'rawChangeQualification':'3524 language .bin changes retained exactly; two lifecycle .bin changes are cargo stdout/stderr only. No normalization, status regressions or lifecycle compared-channel differences.','originalEvidenceChanged':False,'evaluatorRuns':0,'fullM2Complete':False})
print(json.dumps({'root':str(R),'handoffSha256':H(R/'handoff.json'),'reportSha256':H(R/'report.json'),'closureSha256':H(R/'closure.json'),'outerTerminalSha256':H(R/'outer-terminal.json'),'payloadFiles':len(files)}))
