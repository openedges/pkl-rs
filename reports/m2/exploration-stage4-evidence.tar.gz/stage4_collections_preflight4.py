from pathlib import Path
import sys, json, concurrent.futures
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out = Path('target/m2/stage4-collections-java-04').resolve()
out.mkdir(exist_ok=False)
metadata = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts'; artifacts.mkdir(); classes=artifacts/'java'; classes.mkdir()
lang.capture([str(Path(metadata['java']).with_name('javac')), '-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment'])
cases=[]
def add(id, source, family, expectation='success', expression='result'):
    cases.append(dict(id=id, source=source+'\n', family=family, expected_outcome=expectation, expression=expression))
add('mapping-positive-negative-zero','o = new Mapping { [0.0] = 10; [-0.0] = 32 }\nresult = o[0.0] + o[-0.0]','keys')
add('mapping-positive-negative-zero-lookup','o = new Mapping { [0.0] = 42 }\nresult = o[-0.0]','keys','failure')
add('listing-power-index','o = new Listing { 1; 2 }\nresult: Int(o[0] > 3) = 42','power','failure')
add('mapping-power-index','o = new Mapping { ["a"] = 1 }\nresult: Int(o["a"] > 3) = 42','power','failure')
add('dynamic-power-cached','o = new Dynamic { a = 1; 2; ["k"] = 3 }\nforce = o[0] + o["k"]\nresult: Int(o["k"] > 4) = if (force == 5) 42 else 0','power','failure')
add('mapping-power-inherited','base = new Mapping { ["a"] = 1; ["b"] = 2 }\no = (base) { ["a"] = 3; ["c"] = 4 }\nforce = o["b"]\nresult: Int(o["a"] > 5) = if (force == 2) 42 else 0','power','failure')
add('listing-power-comment','o = new Listing { 1; 2 }\nresult: Int(o /* receiver */ [ /* key */ 0 ] > 3) = 42','power','failure')
add('listing-power-multiline','o = new Listing { 1; 2 }\nresult: Int(\n  o\n  [0] > 3\n) = 42','power','failure')
add('listing-power-nested','o = new Listing { new Listing { 1; 2 }; new Listing { 3 } }\nresult: Int(o[0][1] > 3) = 42','power','failure')
add('render-inherited-cached','base = new Dynamic { a = 1; 2; ["k"] = 3 }\no = (base) { a = 10; ["z"] = 30; 20 }\nforce = o[0] + o[1] + o["k"]\nresult: Dynamic(false) = if (force == 25) o else o','render','failure')
cases = [dict(case, id=case['id'] + ('-enabled' if enabled else '-disabled'), power_assertions=enabled) for case in cases for enabled in ([False, True] if case['family'] == 'power' else [False])]
(out/'matrix.json').write_bytes(contract.encoded(cases))
(out/'source-identities.json').write_bytes(contract.encoded({str(p):oracle.sha256(contract.ROOT/p) for p in ['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']}))
def run(case):
    folder=out/'cases'/case['id']; folder.mkdir(parents=True)
    source=folder/'input.pkl'; source.write_text(case['source'])
    row=lang.capture_java(metadata, artifacts/'language_probe',case['id'],source,case['expression'],folder,case.get('power_assertions',False))
    stdout=(folder/'java.stdout.bin').read_bytes(); stderr=(folder/'java.stderr.bin').read_bytes()
    return dict(id=case['id'],family=case['family'],expected_outcome=case['expected_outcome'],java=row,stdout=stdout.decode(),stderr=stderr.decode(),outcome=(folder/'java.outcome.bin').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
for row in results:
    print(row['id'], row['java']['exit_code'], repr(row['stdout']), repr(row['stderr'][:150]),flush=True)
