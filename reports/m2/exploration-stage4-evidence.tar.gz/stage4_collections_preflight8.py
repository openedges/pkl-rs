from pathlib import Path
import sys, json, concurrent.futures
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out = Path('target/m2/stage4-collections-java-08').resolve()
out.mkdir(exist_ok=False)
metadata = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts'; artifacts.mkdir(); classes=artifacts/'java'; classes.mkdir()
lang.capture([str(Path(metadata['java']).with_name('javac')), '-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment'])
cases=[]
def add(id, source, family, expectation='success', expression='result'):
    cases.append(dict(id=id, source=source+'\n', family=family, expected_outcome=expectation, expression=expression))
add('for-force-source-before-key','base = new Listing { 1; missingSource }\no = new Mapping { for (v in base) { [missingKey] = v } }\nresult = o.length','lazy','failure')
add('for-force-source-before-when','base = new Listing { 1; missingSource }\no = new Listing { for (v in base) { when (missingCondition) { v } } }\nresult = o.length','lazy','failure')
add('spread-force-source-before-duplicate','base = new Mapping { ["x"] = 1; ["y"] = missingSource }\no = new Mapping { ["x"] = 2; ...base }\nresult = o.length','lazy','failure')
add('spread-force-source-before-kind','base = new Dynamic { x = 1; y = missingSource }\no = new Listing { ...base }\nresult = o.length','lazy','failure')
add('for-force-child-before-parent','base = new Mapping { ["a"] = missingParent; ["b"] = 2 }\nchild = (base) { ["b"] = missingChild }\no = new Listing { for (v in child) { v } }\nresult = o.length','lazy','failure')
add('spread-force-child-before-parent','base = new Mapping { ["a"] = missingParent; ["b"] = 2 }\nchild = (base) { ["b"] = missingChild }\no = new Mapping { ...child }\nresult = o.length','lazy','failure')
add('for-source-force-shallow','base = new Listing { new Dynamic { bad = missing }; 42 }\no = new Listing { for (v in base) { 1 } }\nresult = o.length','lazy')
add('for-default-omitted','base = new Dynamic { default = missing; x = 42 }\no = new Listing { for (v in base) { v } }\nresult = o.length + o[0]','lazy')
add('spread-default-not-forced','base = new Dynamic { default = missing; x = 42 }\no = new Dynamic { ...base }\nresult = o.x','lazy')
add('nul-internal-collision','o = new Dynamic { [0] = 32; `\x000:0` = 1; `\x001:0` = 2; `\x002:0` = 3; `\x003:0` = 4; `\x004:0` = 5; `\x005:0` = 6; `\x006:0` = 7; `\x007:0` = 8; `\x008:0` = 9; `\x009:0` = 10; `\x0010:0` = 11; `\x0011:0` = 12; `\x0012:0` = 13; `\x0013:0` = 14; `\x0014:0` = 15; `\x0015:0` = 16 }\nresult = o[0] + o.`\x000:0` + o.`\x001:0` + o.`\x002:0` + o.`\x003:0` + o.`\x004:0` + o.`\x005:0` + o.`\x006:0` + o.`\x007:0` + o.`\x008:0` + o.`\x009:0` + o.`\x0010:0` + o.`\x0011:0` + o.`\x0012:0` + o.`\x0013:0` + o.`\x0014:0` + o.`\x0015:0`','keys')
(out/'matrix.json').write_bytes(contract.encoded(cases))
(out/'source-identities.json').write_bytes(contract.encoded({str(p):oracle.sha256(contract.ROOT/p) for p in ['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']}))
def run(case):
    folder=out/'cases'/case['id']; folder.mkdir(parents=True)
    source=folder/'input.pkl'; source.write_text(case['source'])
    row=lang.capture_java(metadata, artifacts/'language_probe',case['id'],source,case['expression'],folder)
    stdout=(folder/'java.stdout.bin').read_bytes(); stderr=(folder/'java.stderr.bin').read_bytes()
    return dict(id=case['id'],family=case['family'],expected_outcome=case['expected_outcome'],java=row,stdout=stdout.decode(),stderr=stderr.decode(),outcome=(folder/'java.outcome.bin').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
for row in results:
    print(row['id'], row['java']['exit_code'], repr(row['stdout']), repr(row['stderr'][:150]),flush=True)
