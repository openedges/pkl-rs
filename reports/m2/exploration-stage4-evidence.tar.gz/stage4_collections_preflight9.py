from pathlib import Path
import sys, json, concurrent.futures
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out = Path('target/m2/stage4-collections-java-09').resolve()
out.mkdir(exist_ok=False)
metadata = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts'; artifacts.mkdir(); classes=artifacts/'java'; classes.mkdir()
lang.capture([str(Path(metadata['java']).with_name('javac')), '-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment'])
cases=[]
def add(id, source, family, expectation='success', expression='result'):
    cases.append(dict(id=id, source=source+'\n', family=family, expected_outcome=expectation, expression=expression))
add('typed-class-for-source','class C { x: Int }\nc = new C { x = 42 }\no = new Listing { for (v in c) { v } }\nresult = o.length','classes','failure')
add('typed-class-spread-source','class C { x: Int }\nc = new C { x = 42 }\no = new Dynamic { ...c }\nresult = o.x','classes','failure')
add('for-force-source-before-param-type','base = new Listing { 1; missingSource }\no = new Listing { for (v: String in base) { v } }\nresult = o.length','lazy','failure')
add('for-empty-param-missingtype','o = new Listing { for (v: MissingType in List()) { v } }\nresult = o.length','types','failure')
add('for-empty-missingtype-skipped','o = new Listing { when (false) { for (v: MissingType in List()) { v } }; 42 }\nresult = o[0]','types')
(out/'matrix.json').write_bytes(contract.encoded(cases))
(out/'source-identities.json').write_bytes(contract.encoded({str(p):oracle.sha256(contract.ROOT/p) for p in ['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']}))
def run(case):
    folder=out/'cases'/case['id']; folder.mkdir(parents=True)
    source=folder/'input.pkl'; source.write_text(case['source'])
    row=lang.capture_java(metadata, artifacts/'language_probe',case['id'],source,case['expression'],folder)
    stdout=(folder/'java.stdout.bin').read_bytes(); stderr=(folder/'java.stderr.bin').read_bytes()
    return dict(id=case['id'],family=case['family'],expected_outcome=case['expected_outcome'],java=row,stdout=stdout.decode(),stderr=stderr.decode(),outcome=(folder/'java.outcome.bin').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
for row in results:
    print(row['id'], row['java']['exit_code'], repr(row['stdout']), repr(row['stderr'][:150]),flush=True)
