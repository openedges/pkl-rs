from pathlib import Path
import json,sys,concurrent.futures
sys.path.insert(0,'tools');import m2_language as lang,m2_manifest as contract,oracle
java_root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir(exist_ok=False)
metadata=json.loads((java_root/'oracle.json').read_bytes());(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts';artifacts.mkdir();candidate=Path(sys.argv[3]).resolve();frozen=artifacts/'language_probe';frozen.write_bytes(candidate.read_bytes());frozen.chmod(0o755)
if (java_root/'cases.json').exists():
    cases=json.loads((java_root/'cases.json').read_bytes());cases=cases['cases'] if isinstance(cases,dict) else cases
elif (java_root/'matrix.json').exists():
    cases=json.loads((java_root/'matrix.json').read_bytes())
else:
    historical=json.loads((java_root/'sources/compatibility/m2-language.json').read_bytes())
    cases=[r for r in historical['cases'] if r.get('adapter')=='language-api-string']
    current=contract.load(contract.SELECTION)['cases'][:len(cases)]
    assert all(all(r[k]==c[k] for k in c) for r,c in zip(cases,current,strict=True))
    report=json.loads((java_root/'report.json').read_bytes());lang.verify_oracle(java_root,report)
    assert oracle.sha256(contract.ROOT/'tools/java/M2LanguageProbe.java')==report['source_sha256']['tools/java/M2LanguageProbe.java']
java_rows=json.loads((java_root/('results.json' if (java_root/'results.json').exists() else 'observations.json' if (java_root/'observations.json').exists() else 'report.json')).read_bytes());java_rows=java_rows['results'] if isinstance(java_rows,dict) else java_rows;java_rows={r['id']:r for r in java_rows}
def run(case):
    folder=out/'cases'/case['id'];folder.mkdir(parents=True);reference=java_root/'cases'/case['id'];java=java_rows[case['id']]['java']
    source=Path(java['command'][-2])
    if java['command'][-1]=='--power-assertions':source=Path(java['command'][-3])
    assert source.read_bytes()==(reference/'input.pkl').read_bytes()
    (folder/'input.pkl').write_bytes(source.read_bytes())
    for channel in ('stdout','stderr','outcome'):
        original=reference/f'java.{channel}.bin';assert oracle.sha256(original)==java[channel+'_sha256'];(folder/original.name).write_bytes(original.read_bytes())
    (folder/'java.process.json').write_bytes(contract.encoded(java))
    rust=lang.capture([str(frozen),*lang.expression_arguments(source,case['expression'],case.get('power_assertions',False))],folder,'rust',metadata['environment'])
    hypothesis=dict(case,expected_outcome='success' if java['exit_code']==0 else 'failure')
    status=lang.status(hypothesis,java,rust,*((folder/f'{name}.{channel}.bin').read_bytes() for name in ('java','rust') for channel in ('stdout','stderr')),(folder/'java.outcome.bin').read_bytes())
    return dict(id=case['id'],status=status,java=java,rust=rust,java_original=str(reference))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(run,cases))
(out/'results.json').write_bytes(contract.encoded(results));(out/'candidate.json').write_bytes(contract.encoded(dict(path=str(candidate),sha256=oracle.sha256(frozen),source_binding='preflight-unbound',java_root=str(java_root))))
from collections import Counter
print(dict(Counter(r['status'] for r in results)))
import difflib
lines=[]
for row in results:
 if row['status']=='pass':continue
 p=out/'cases'/row['id'];lines.append(row['id']+'\n')
 for channel in ('stdout','stderr'):
  a=(p/f'java.{channel}.bin').read_text().splitlines(keepends=True);b=(p/f'rust.{channel}.bin').read_text().splitlines(keepends=True)
  lines.extend(difflib.unified_diff(a,b,fromfile='java.'+channel,tofile='rust.'+channel,n=1))
(out/'mismatches.diff').write_text(''.join(lines));print(''.join(lines))
