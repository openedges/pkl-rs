from pathlib import Path
import json,sys,shutil,hashlib
sys.path.insert(0,'tools');import m2_manifest,oracle,evidence
base=Path('target/m2');package=base/'stage4-exploration-package-01';package.mkdir(exist_ok=False)
names=[]
for prefix in ['stage4-collections-java-*','stage4-selected-java-*','stage4-adversarial-replay-*','stage4-selected-replay-*','stage4-regressions-replay-*','stage4-old294-replay-*','stage4-draft-differential-*','stage4-selected-draft-*','stage4-regressions-draft-*','stage4-independent-review-*','stage4-platform-java-*','stage4-exploration-sources']:
 names += [p for p in base.glob(prefix) if p.is_dir()]
names=sorted(set(names));runs=[]
for source in names:
 destination=package/source.name;shutil.copytree(source,destination)
 runs.append(dict(path=source.name,files={str(p.relative_to(destination)):oracle.sha256(p) for p in sorted(destination.rglob('*')) if p.is_file()}))
for p in [*base.glob('stage4_*.py'),base/'stage4-old-selection.json',base/'stage4-old-fixture-hashes.json']:
 if p.is_file():shutil.copyfile(p,package/p.name)
# Keep both historical and final selection snapshots keyed by bytes.
snapshots={}
for p in [Path('references.lock'),Path('oracle.lock.json'),Path('tools/java/M2LanguageProbe.java'),Path('tools/m2_language.py'),Path('tools/m2_manifest.py'),Path('tools/m1_platforms.py'),Path('tools/tests/test_m1_platforms.py'),Path('tests/fixtures/m2/cases.json'),Path('compatibility/m2-language.json')]:
 digest=oracle.sha256(p);dest=package/'final-sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes());snapshots[str(p)]=digest
notes=dict(scope='Exploration and candidate preflight evidence only. Candidate binaries are frozen per replay, without a stable source-build binding. This archive is not the final recorded-build report or a language-completion claim.',
 original_cases='The first 294 selected case definitions, their serialized bytes/order, and fixture bytes are unchanged; stage4-old-selection.json and stage4-old-fixture-hashes.json retain the before-state.',
 hypotheses='expected_outcome in initial Java study matrices is a pre-execution hypothesis. observations.json and raw process/outcome captures record actual results; several hypotheses were corrected before fixture selection.',
 independent_review='stage4-independent-review-01 preserves source and raw Java/Rust stdout/stderr only. Its original review capture has no pinned process/oracle identity metadata or outcome sidecars, so it is preliminary observation rather than formal compatibility evidence. stage4-selected-java-02 acquires all nine promoted independent-review regressions at actual fixture URIs using the pinned oracle and complete process/outcome metadata.',
 pending_scope=[
  dict(cases=['stage4-collections-java-03/mapping-object-structural','stage4-collections-java-03/mapping-listing-key-structural','stage4-collections-java-03/mapping-object-key-lazy'],state='Java observed; Rust object/function/class keys remain explicitly unsupported and outside this finite selected slice.'),
  dict(cases=['stage4-collections-java-01/listing-typed-success','stage4-collections-java-01/mapping-typed-success'],state='Java observed; collection generic wrappers remain outside this finite selected slice.'),
  dict(cases=['stage4-collections-java-02/listing-predicate-constant','stage4-collections-java-02/mapping-predicate-constant'],state='Java observed; member predicates remain explicitly unsupported and outside this finite selected slice.'),
  dict(cases=['stage4-collections-java-07/class-new-when-property','stage4-collections-java-07/class-new-when-false'],state='Java succeeds; recorded candidate explicitly rejects non-property typed constructor bodies. This known gap is retained in adversarial-replay-02.'),
  dict(cases=['stage4-collections-java-07/list-equality','stage4-collections-java-07/dynamic-equality'],state='Java succeeds; recorded candidate explicitly rejects structural object equality. This known gap is retained in adversarial-replay-02.'),
  dict(cases=['stage4-collections-java-06/spread-listing-default-read','stage4-collections-java-06/spread-dynamic-default'],state='Default function reads and custom default-entry execution remain outside the selected slice. Initial candidate mismatches are preserved. Default omission during spread/for is separately promoted and verified.'),
 ],
 final_selection=dict(cases=415,original=294,core_additions=80,review_regressions=41,metamorphic_relations=20),
 full_gate='Required incomplete/unmapped/unexecuted requirements and known failures remain full-gate failures; selected success never closes M2.')
(package/'NOTES.json').write_bytes(m2_manifest.encoded(notes));(package/'INDEX.json').write_bytes(m2_manifest.encoded(dict(runs=runs,final_source_sha256=snapshots,scripts={p.name:oracle.sha256(p) for p in package.glob('*.py')})))
archive=Path('reports/m2/exploration-stage4-evidence.tar.gz');assert not archive.exists();evidence.create(package,archive,[])
print('Archive sha256:',oracle.sha256(archive))
