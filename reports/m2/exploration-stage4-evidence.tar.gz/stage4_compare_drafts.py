from pathlib import Path
import sys,json,concurrent.futures,os
sys.path.insert(0,'tools');import m2_language as lang,m2_manifest as contract,oracle
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=False)
drafts=Path(sys.argv[2]).resolve()
metadata=oracle.ensure_oracle(contract.ROOT,fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts';artifacts.mkdir();classes=artifacts/'java';classes.mkdir()
candidate=Path(sys.argv[3]).resolve(); frozen=artifacts/'language_probe';frozen.write_bytes(candidate.read_bytes());frozen.chmod(0o755)
lang.capture([str(Path(metadata['java']).with_name('javac')),'-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment'])
cases=json.loads((drafts/'cases.json').read_bytes())['cases']
(out/'cases.json').write_bytes(contract.encoded(cases))
(out/'source-identities.json').write_bytes(contract.encoded({p:oracle.sha256(contract.ROOT/p) for p in lang.source_paths()}))
def run(case):
    folder=out/'cases'/case['id'];folder.mkdir(parents=True)
    source=drafts/(case['id']+'.pkl');(folder/'input.pkl').write_bytes(source.read_bytes())
    java=lang.capture_java(metadata,frozen,case['id'],source,case['expression'],folder,case.get('power_assertions',False))
    rust=lang.capture([str(frozen),*lang.expression_arguments(source,case['expression'],case.get('power_assertions',False))],folder,'rust',metadata['environment'])
    status=lang.status(case,java,rust,*((folder/f'{name}.{channel}.bin').read_bytes() for name in ('java','rust') for channel in ('stdout','stderr')),(folder/'java.outcome.bin').read_bytes())
    return dict(id=case['id'],status=status,java=java,rust=rust)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,cases))
(out/'results.json').write_bytes(contract.encoded(results))
(out/'metamorphic.json').write_bytes(contract.encoded(lang.check_relations(dict(cases=cases),out)))
from collections import Counter
print(dict(Counter(r['status'] for r in results)))
for r in results:
    if r['status']!='pass':
        folder=out/'cases'/r['id']
        print(r['id'],repr((folder/'java.stdout.bin').read_text()),repr((folder/'rust.stdout.bin').read_text()),repr((folder/'java.stderr.bin').read_text()[:100]),repr((folder/'rust.stderr.bin').read_text()[:150]))
