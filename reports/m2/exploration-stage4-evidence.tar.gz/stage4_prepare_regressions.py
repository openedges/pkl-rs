from pathlib import Path
import json,sys
sys.path.insert(0,'tools');import m2_manifest
root=Path('target/m2');output=root/'stage4-regressions-draft-01';output.mkdir(exist_ok=False)
selections={
'06':'''entry-body-inferred-new spread-listing-default spread-preserves-eager-value dynamic-static-computed-element dynamic-static-literal-element dynamic-generated-literal-element generator-typed-param-false listing-subscript-entry-super entry-body-amendment element-body-amendment'''.split(),
'07':'''class-is-dynamic class-annotated-dynamic contextual-class-is-dynamic class-amend-element class-amend-entry class-amend-for-entry class-amend-spread-entry'''.split(),
'08':'''for-force-source-before-key for-force-source-before-when spread-force-source-before-duplicate spread-force-source-before-kind for-force-child-before-parent spread-force-child-before-parent for-source-force-shallow for-default-omitted spread-default-not-forced nul-internal-collision'''.split(),
'09':'''typed-class-for-source typed-class-spread-source for-force-source-before-param-type for-empty-param-missingtype for-empty-missingtype-skipped'''.split(),
}
rows=[];provenance={}
for run,ids in selections.items():
 path=root/f'stage4-collections-java-{run}';matrix={r['id']:r for r in json.loads((path/'matrix.json').read_bytes())};observations={r['id']:r for r in json.loads((path/'observations.json').read_bytes())}
 for old_id in ids:
  case=matrix[old_id];observed=observations[old_id];identifier='collection-'+old_id
  requirements=['semantic:collections','semantic:objects'];family=case['family']
  if family=='types':requirements.append('semantic:types')
  if family=='classes':requirements.extend(['semantic:classes','semantic:types'])
  if family in ('spread','ordered','lazy') or any(t in old_id for t in ('for-','when-','spread-','generated-')):requirements.append('semantic:generators')
  if family in ('lazy','scope') or any(t in old_id for t in ('force-','cache','shallow','skipped','param-false')):requirements.append('semantic:lazy-evaluation')
  if family=='amendment' or any(t in old_id for t in ('amend','inferred-new','super','preserves','child-')):requirements.append('semantic:amendment')
  if 'nul' in old_id:requirements.extend(['semantic:lexing','semantic:name-resolution'])
  if observed['java']['exit_code']==1:requirements.append('semantic:diagnostics')
  row=dict(id=identifier,input=f'tests/fixtures/m2/{identifier}.pkl',expression=case['expression'],requirements=list(dict.fromkeys(requirements)),expected_outcome='success' if observed['java']['exit_code']==0 else 'failure')
  (output/(identifier+'.pkl')).write_text(case['source']);rows.append(row);provenance[identifier]=dict(java_directory=str(path/'cases'/old_id),input_sha256=m2_manifest.digest(case['source'].encode()),provenance='Pinned oracle metadata, complete raw process/outcome captures and input identity recorded in the Java study.')
independent=root/'stage4-independent-review-01'
for old_id in '''local-duplicate-generated local-method-duplicate-generated list-method-shadow list-property-shadow list-nested-method-shadow listing-implicit-length listing-implicit-isempty module-dynamic-classification module-iteration'''.split():
 source=(independent/old_id/'input.pkl').read_bytes();identifier='collection-'+old_id
 req=['semantic:collections','semantic:objects','semantic:name-resolution']
 if 'local' in old_id:req.extend(['semantic:modifiers','semantic:generators'])
 if 'method' in old_id:req.append('semantic:functions')
 if 'module-' in old_id:req.append('semantic:modules')
 if 'classification' in old_id:req.append('semantic:types')
 if 'iteration' in old_id:req.append('semantic:generators')
 failure=bool((independent/old_id/'java.stderr.bin').read_bytes())
 if failure:req.append('semantic:diagnostics')
 rows.append(dict(id=identifier,input=f'tests/fixtures/m2/{identifier}.pkl',expression='result',requirements=req,expected_outcome='failure' if failure else 'success'))
 (output/(identifier+'.pkl')).write_bytes(source)
 provenance[identifier]=dict(initial_directory=str(independent/old_id),input_sha256=m2_manifest.digest(source),provenance='Preliminary independent review preserves source and raw Java/Rust stdout/stderr only; it lacks process/oracle identity metadata and outcome sidecars. It is not formal compatibility evidence. A new pinned acquisition at the promoted fixture URI supplies formal provenance.')
assert len(rows)==41
(output/'cases.json').write_text(json.dumps(dict(cases=rows),ensure_ascii=False,indent=2)+'\n');(output/'provenance.json').write_bytes(m2_manifest.encoded(provenance));print(len(rows))
