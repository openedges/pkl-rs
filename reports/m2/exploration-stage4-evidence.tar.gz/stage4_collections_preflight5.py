from pathlib import Path
import sys, json, concurrent.futures
sys.path.insert(0, 'tools')
import m2_language as lang, m2_manifest as contract, oracle
out = Path('target/m2/stage4-collections-java-05').resolve()
out.mkdir(exist_ok=False)
metadata = oracle.ensure_oracle(contract.ROOT, fetch=False)
(out/'oracle.json').write_bytes(contract.encoded(metadata))
artifacts=out/'artifacts'; artifacts.mkdir(); classes=artifacts/'java'; classes.mkdir()
lang.capture([str(Path(metadata['java']).with_name('javac')), '-encoding','UTF-8','-cp',metadata['artifact'],'-d',str(classes),str(contract.ROOT/'tools/java/M2LanguageProbe.java')],out,'javac',metadata['environment'])
cases=[]
def add(id, source, family, expectation='success', expression='result'):
    cases.append(dict(id=id, source=source+'\n', family=family, expected_outcome=expectation, expression=expression))
add('dynamic-simple-order','o = new Dynamic { a = 1; 2; ["k"] = 3; b = 4; 5 }\nx = new Listing { for (k, v in o) { v } }\nresult = x[0] * 10000 + x[1] * 1000 + x[2] * 100 + x[3] * 10 + x[4]','ordered')
add('dynamic-generated-order','o = new Dynamic { when (true) { a = 1; 2; ["k"] = 3; b = 4; 5 } }\nx = new Listing { for (k, v in o) { v } }\nresult = x[0] * 10000 + x[1] * 1000 + x[2] * 100 + x[3] * 10 + x[4]','ordered')
add('dynamic-mixed-generated-order','o = new Dynamic { a = 1; 2; when (true) { ["k"] = 3; b = 4 }; 5 }\nx = new Listing { for (k, v in o) { v } }\nresult = x[0] * 10000 + x[1] * 1000 + x[2] * 100 + x[3] * 10 + x[4]','ordered')
add('render-dynamic-generated','o: Dynamic(false) = new Dynamic { when (true) { a = 1; 2; ["k"] = 3; b = 4; 5 } }\nresult = o','render','failure')
add('render-dynamic-mixed-generated','o: Dynamic(false) = new Dynamic { a = 1; 2; when (true) { ["k"] = 3; b = 4 }; 5 }\nresult = o','render','failure')
add('listing-lazy-key-capture','o = new Mapping { for (n in List(1, 2)) { [n] = () -> n } }\nresult = o[1].apply() * 10 + o[2].apply()','scope')
add('listing-nested-generator-closure','o = new Listing { for (n in List(1, 2)) { when (n > 0) { for (m in List(3, 4)) { () -> n * 10 + m } } } }\nresult = o[0].apply() * 100 + o[3].apply()','scope')
add('generator-first-key-error','o = new Mapping { [missingFirst] = missingBody; when (missingSecond) { ["x"] = 1 } }\nresult = o["x"]','lazy','failure')
add('generator-first-when-error','o = new Mapping { when (missingFirst) { ["x"] = missingBody }; [missingSecond] = 1 }\nresult = o["x"]','lazy','failure')
add('listing-power-legal-multiline','o = new Listing { 1; 2 }\nresult: Int(o[\n  0\n] > 3) = 42','power','failure')
add('meta-for-alpha-left','o = new Listing { for (n in List(1, 2)) { for (m in List(3, 4)) { () -> n * 10 + m } } }\nresult = o[0].apply() * 100 + o[3].apply()','metamorphic')
add('meta-for-alpha-right','o = new Listing { for (outerItem in List(1, 2)) { for (innerItem in List(3, 4)) { () -> outerItem * 10 + innerItem } } }\nresult = o[0].apply() * 100 + o[3].apply()','metamorphic')
add('meta-mapping-amend-left','base = new Mapping { [2] = 10; [1] = 20 }\no = (base) { [2] = 30; [3] = 40 }\nx = new Listing { for (k, v in o) { k * 100 + v } }\nresult = x[0] * 1000000 + x[1] * 1000 + x[2]','metamorphic')
add('meta-mapping-amend-right','o = new Mapping { [2] = 30; [1] = 20; [3] = 40 }\nx = new Listing { for (k, v in o) { k * 100 + v } }\nresult = x[0] * 1000000 + x[1] * 1000 + x[2]','metamorphic')
add('meta-null-spread-left','o = new Listing { 1; ...?null; 2; when (false) { missing } }\nresult = o[0] * 10 + o[1]','metamorphic')
add('meta-null-spread-right','o = new Listing { 1; 2 }\nresult = o[0] * 10 + o[1]','metamorphic')
(out/'matrix.json').write_bytes(contract.encoded(cases))
(out/'source-identities.json').write_bytes(contract.encoded({str(p):oracle.sha256(contract.ROOT/p) for p in ['references.lock','oracle.lock.json','tools/java/M2LanguageProbe.java','tools/m2_language.py']}))
def run(case):
    folder=out/'cases'/case['id']; folder.mkdir(parents=True)
    source=folder/'input.pkl'; source.write_text(case['source'])
    row=lang.capture_java(metadata, artifacts/'language_probe',case['id'],source,case['expression'],folder,case['family']=='power')
    stdout=(folder/'java.stdout.bin').read_bytes(); stderr=(folder/'java.stderr.bin').read_bytes()
    return dict(id=case['id'],family=case['family'],expected_outcome=case['expected_outcome'],java=row,stdout=stdout.decode(),stderr=stderr.decode(),outcome=(folder/'java.outcome.bin').read_text())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(run,cases))
(out/'observations.json').write_bytes(contract.encoded(results))
for row in results:
    print(row['id'], row['java']['exit_code'], repr(row['stdout']), repr(row['stderr'][:150]),flush=True)
