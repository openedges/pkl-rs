from pathlib import Path
import json,sys
sys.path.insert(0,'tools');import m2_manifest
root=Path('target/m2'); output=root/'stage4-selected-draft-02';output.mkdir(exist_ok=False)
selections={
'01': '''dynamic-mixed listing-elements mapping-entries dynamic-entry-property dynamic-lazy-body listing-lazy-body mapping-lazy-body mapping-eager-key mapping-unused-key listing-index-negative listing-index-upper listing-index-string mapping-missing dynamic-property-index listing-length-lazy mapping-length-lazy listing-amend-append listing-amend-replace mapping-amend-replace mapping-amend-late-this listing-this mapping-key-lexical listing-local listing-for-index listing-for-closure listing-when-false listing-when-else listing-when-eager listing-for-body-lazy listing-spread-list mapping-spread listing-spread-lazy listing-spread-nullable listing-spread-null listing-property-rejected listing-when-nonboolean'''.split(),
'02': '''listing-entry-new-index listing-amend-outside-parent mapping-element-forced listing-for-listing listing-for-unused-bad-value listing-for-outer mapping-spread-duplicate listing-spread-mapping-error mapping-spread-listing-error listing-spread-order'''.split(),
'03': '''property-nul mapping-int-float mapping-float-int mapping-int-float-duplicate mapping-nan mapping-nan-duplicate mapping-bool-null mapping-int-bool-distinct render-dynamic-mixed render-dynamic-inherited render-dynamic-cached'''.split(),
'04': '''mapping-positive-negative-zero-disabled mapping-positive-negative-zero-lookup-disabled listing-power-index-enabled mapping-power-index-enabled dynamic-power-cached-enabled mapping-power-inherited-enabled listing-power-comment-enabled'''.split(),
'05': '''dynamic-simple-order dynamic-generated-order dynamic-mixed-generated-order render-dynamic-generated render-dynamic-mixed-generated listing-lazy-key-capture listing-nested-generator-closure generator-first-key-error generator-first-when-error listing-power-legal-multiline meta-for-alpha-left meta-for-alpha-right meta-mapping-amend-left meta-mapping-amend-right meta-null-spread-left meta-null-spread-right'''.split(),
}
rows=[]; provenance={}
for run,ids in selections.items():
    path=root/f'stage4-collections-java-{run}'
    matrix={r['id']:r for r in json.loads((path/'matrix.json').read_bytes())}
    observations={r['id']:r for r in json.loads((path/'observations.json').read_bytes())}
    for old_id in ids:
        case=matrix[old_id]; observed=observations[old_id]
        identifier='collection-'+old_id.removesuffix('-disabled').removesuffix('-enabled')
        requirements=['semantic:collections','semantic:objects']
        family=case['family']
        if family in ('generator','spread','ordered','scope','metamorphic') or any(t in old_id for t in ('for-','when-','spread-')):requirements.append('semantic:generators')
        if family in ('lazy','scope') or 'lazy' in old_id or 'first-' in old_id:requirements.append('semantic:lazy-evaluation')
        if family=='scope':requirements.append('semantic:name-resolution')
        if family=='amendment' or 'amend' in old_id:requirements.append('semantic:amendment')
        if family in ('power','render'):requirements.extend(['semantic:constraints','semantic:diagnostics'])
        elif observed['java']['exit_code']==1:requirements.append('semantic:diagnostics')
        row=dict(id=identifier,input=f'tests/fixtures/m2/{identifier}.pkl',expression=case['expression'],requirements=requirements,expected_outcome='success' if observed['java']['exit_code']==0 else 'failure')
        if case.get('power_assertions') or family=='power' and run=='05':row['power_assertions']=True
        source=output/(identifier+'.pkl');source.write_text(case['source'])
        rows.append(row)
        provenance[identifier]=dict(java_directory=str(path/'cases'/old_id),input_sha256=m2_manifest.digest(source.read_bytes()),source_family=family,observed_exit_code=observed['java']['exit_code'])
relations=[('for-alpha','Capture-free renaming of two nested bounded Int generator variables preserves lazy closure capture'),('mapping-amend','Replacing an existing Mapping key preserves parent order; fresh Mapping with matching final order and values yields equal bounded scalar iteration'),('null-spread','A nullable spread of null and a false when branch emit no elements; bounded Listing elements and indexing remain unchanged')]
for family,domain in relations:
    ids=[f'collection-meta-{family}-{side}' for side in ('left','right')]
    relation=dict(kind='equal-stdout',case_ids=ids,domain=domain)
    for row in rows:
        if row['id'] in ids:
            row['metamorphic_relation']=relation
            row['requirements'].append('semantic:generated-verification')
(output/'cases.json').write_text(json.dumps(dict(schema_version=1,scope='Staged stage 4 cases; not promoted to selected contract yet.',cases=rows),ensure_ascii=False,indent=2)+'\n')
(output/'provenance.json').write_bytes(m2_manifest.encoded(provenance))
print(len(rows))
