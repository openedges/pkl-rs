#!/usr/bin/env python3
"""Package Java-only evidence; reference canonical final data without duplication."""
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tarfile

ROOT = Path.cwd().resolve()
OUT = ROOT / 'target/m2/stage55-oracle-checkpoint-publication-02'
ARCHIVE = ROOT / 'reports/m2/stage55-oracle-validation-evidence.tar.gz'
CHECKPOINT = ROOT / 'reports/m2/stage55-oracle-checkpoint.json'
FIXTURE = ROOT / 'tests/fixtures/m2-frame-transformers'
VALIDATION = ROOT / 'target/m2/stage55-oracle-checkpoint-validation-01'
HISTORY = ROOT / 'target/m2/stage55-frame-oracle-01'


def record(data):
    return dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))


def identity(path):
    return dict(path=str(path.relative_to(ROOT)), **record(path.read_bytes()))


def load(path):
    return json.loads(path.read_bytes())


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode()


def tree(root):
    assert root.is_dir() and not root.is_symlink()
    result = {}
    for directory, directories, names in os.walk(root, followlinks=False):
        for name in directories + names:
            assert not (Path(directory) / name).is_symlink()
        for name in names:
            path = Path(directory) / name
            assert path.is_file()
            result[path.relative_to(root).as_posix()] = record(path.read_bytes())
    return dict(sorted(result.items()))


def file_set(records):
    return hashlib.sha256(json.dumps(records, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


assert not ARCHIVE.exists() and not CHECKPOINT.exists() and not (OUT / 'manifest.json').exists()
sys.path.insert(0, str(ROOT / 'tools'))
import frame_transformer_oracle as oracle
import frame_transformer_fixtures as fixtures

verification = fixtures.verify(FIXTURE)
history = oracle.verify_report(HISTORY)
main = oracle.verify_report(ROOT / 'target/m2/stage55-frame-oracle-02')
buffer = oracle.verify_report(ROOT / 'target/m2/stage55-frame-buffer-oracle-01')
validation = load(VALIDATION / 'report.json')
assert validation['complete'] and validation['all_checks_passed'] and not validation['changed_sources']
assert all(row['status'] == 'executed' and row['exit_code'] == 0 for row in validation['commands'])
test_log = (VALIDATION / 'fixture-tests.stderr.bin').read_bytes()
assert re.search(rb'Ran 14 tests in [0-9.]+s\n\nOK\n', test_log)
assert verification['sessions'] == 48 and verification['java_processes'] == 96
assert verification['buffer_supplement']['sessions'] == 7 and verification['buffer_supplement']['java_processes'] == 14
canonical = FIXTURE / 'oracle-evidence.tar.gz'
canonical_before = record(canonical.read_bytes())
omissions = []
with tarfile.open(canonical, 'r:gz') as stream:
    entries = stream.getmembers()
    assert len(entries) == len({entry.name for entry in entries})
    for entry in entries:
        name = PurePosixPath(entry.name)
        assert not name.is_absolute() and '..' not in name.parts and (entry.isfile() or entry.isdir())
    for name, prefix in [('stage55-frame-oracle-02', 'main'), ('stage55-frame-buffer-oracle-01', 'buffer')]:
        path = ROOT / 'target/m2' / name
        records = tree(path)
        selected = {entry.name.removeprefix(prefix + '/'): entry for entry in entries if entry.isfile() and entry.name.startswith(prefix + '/')}
        assert set(selected) == set(records)
        for member, entry in selected.items():
            assert (path / member).read_bytes() == stream.extractfile(entry).read()
        omissions.append(dict(source='target/m2/' + name, archive_prefix=prefix, files=records,
                              file_set_sha256=file_set(records), every_file_raw_equal=True))

payloads, cohorts, before = {}, [], {}
for path, scope, java_runs in [
        (HISTORY, 'Unchanged original 47-session acquisition; historical observations, not additional independent feature coverage.', 94),
        (VALIDATION, 'Read-only authority/verifier validation and 14 actual Python tests; no guest evaluation.', 0)]:
    records = tree(path)
    source = path.relative_to(ROOT).as_posix()
    before[source] = records
    for name, value in records.items():
        assert not name.endswith(('.rs', '.wasm', '.node')) and 'candidate-trace' not in name
        payloads['evidence/' + source + '/' + name] = value
    cohorts.append(dict(source=source, scope=scope, files=len(records), file_set_sha256=file_set(records), java_runs=java_runs))
historical_files = len(payloads)
for name in ['publish.py', 'verify.py', 'README.md']:
    payloads[name] = record((OUT / name).read_bytes())
payloads = dict(sorted(payloads.items()))
manifest = dict(schema=1, scope='Java-only Stage55 acquisition history and exact authority/tooling validation. No candidate implementation result.',
    compatibility_passes_claimed=0, files=payloads, historical_payload_files=historical_files,
    payload_file_set_sha256=file_set(payloads), cohorts=cohorts,
    omitted_duplicate_authority=dict(path=identity(canonical)['path'], archive=canonical_before,
        cohorts=omissions, verification=verification,
        reason='Final main and buffer raw data are already fully retained by the exact canonical fixture archive. No originals were deleted or rewritten.'))
(OUT / 'manifest.json').write_bytes(encoded(manifest))
ARCHIVE.parent.mkdir(parents=True, exist_ok=True)
with ARCHIVE.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as stream:
            for name in ['manifest.json', *payloads]:
                source = OUT / name if not name.startswith('evidence/') else ROOT / name.removeprefix('evidence/')
                data = source.read_bytes()
                if name != 'manifest.json':
                    assert record(data) == payloads[name]
                info = tarfile.TarInfo(name)
                info.mode = 0o644
                info.size = len(data)
                stream.addfile(info, io.BytesIO(data))
for source, records in before.items():
    assert tree(ROOT / source) == records
for cohort in omissions:
    assert tree(ROOT / cohort['source']) == cohort['files']
assert record(canonical.read_bytes()) == canonical_before
specification = importlib.util.spec_from_file_location('stage55_java_archive_verifier', OUT / 'verify.py')
verifier = importlib.util.module_from_spec(specification)
specification.loader.exec_module(verifier)
publication = verifier.verify(ARCHIVE, canonical)
publication.update(original_sources_unchanged=True, canonical_final_payloads_not_duplicated=True)
(OUT / 'report.json').write_bytes(encoded(publication))

metadata = main['oracle']
assert metadata['version'] == '0.32.0' and metadata['source']['revision'] == 'e51fb2f91774265666f94980ec630db794a4db2d'
assert metadata['artifact_sha256'] == 'c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059'
assert '-Xms64m' in metadata['command'] and '-Xmx512m' in metadata['command']
owned_names = ['tools/java/M2FrameTransformerProbe.java', 'tools/frame_transformer_oracle.py',
               'tools/frame_transformer_fixtures.py', 'tools/tests/test_frame_transformer_fixtures.py']
checkpoint = dict(schema=1, stage=55, kind='Java-only-reference-observation-checkpoint',
    recorded_at=datetime.now(timezone.utc).isoformat(),
    scope='Actual pinned Java full-frame transformer observations and offline evidence/tooling checks; Rust implementation and actual candidate comparison remain separate in-progress work.',
    baseline='Pkl 0.32.0', base_commit='599f161ffd109b3b76de67cb5dc8dc36aff1b9a4',
    actual_step_commit=None, actual_commit_binding='pending until the authorized step commit exists; no staging or commit was performed here',
    local_provenance=dict(host=metadata['platform'], cwd=str(ROOT), execution='Local macOS; not hosted CI', python=validation['python']),
    reference_pins=dict(pkl_revision=metadata['source']['revision'], pantry_revision='904a68184e54da378b0a0e8a911a3fab3956f693',
        oracle_lock=identity(ROOT / 'oracle.lock.json'), references_lock=identity(ROOT / 'references.lock'),
        artifact_sha256=metadata['artifact_sha256'], artifact_url=metadata['artifact_url'],
        JDK={key: metadata['jdk'][key] for key in ['executable', 'executable_sha256', 'runtime_modules_sha256', 'release_sha256', 'properties']},
        exact_command_prefix=metadata['command'], environment=metadata['environment'], references_updated=False),
    fixture=dict(path=FIXTURE.relative_to(ROOT).as_posix(), canonical_archive=identity(canonical),
        manifest=identity(FIXTURE / 'manifest.json'), main_cases=identity(FIXTURE / 'cases.json'),
        buffer_cases=identity(FIXTURE / 'buffer-cases.json'), verification=verification),
    main=dict(report=identity(ROOT / 'target/m2/stage55-frame-oracle-02/report.json'), sessions=48, JVM_processes=96,
        public_calls=180, transformer_callbacks=164, logger_callbacks=82, warning_callbacks=68,
        public_call_status_counts=verification['call_status_counts'],
        repeated_pairs_raw_equal=48, compatibility_passes_claimed=0,
        boundary='All original/returned frame fields, nullable versus empty members, every source line, four inclusive positions, original Java UTF8 and exact UTF16BE code units, full error/status/class provenance and ordered callback/process protocol.',
        policies=['default', 'builtin-identity', 'observed identity callback', 'full replacement callback', 'numbered replacement callback'],
        actions=['real noop delegate', 'transformer/logger throw-once and retry', 'transformer/logger public evaluator reentry', 'nested reentry consuming throw-once', 'compressed original diagnostic frames transformed afterward'],
        nonpasses='Ten PklBugException calls and four actual API exception calls remain reference nonpasses, never compatible-error or tool-success passes. API exception classes/messages are not synthesized by candidates.'),
    buffer_supplement=dict(report=identity(ROOT / 'target/m2/stage55-frame-buffer-oracle-01/report.json'),
        sessions=7, JVM_processes=14, evaluateTest_outer_calls=28, expression_reentry_calls=4, public_calls=32,
        transformer_callbacks=50, logger_callbacks=14, repeated_pairs_raw_equal=7, nested_PklBugException_results=4,
        public_call_status_counts=verification['buffer_supplement']['call_status_counts'], compatibility_passes_claimed=0,
        observations=['Real TestResults.logs() exposes attempted message append before transformer/delegate failure.',
            'The noop delegate emits no logger callback while custom transformation and buffered messages remain observable.',
            'Repeated public evaluation clears the buffer; cached successful facts need not emit another trace.',
            'Transformer and logger public reentry can clear the buffer before the enclosing operation returns.'],
        scope='Java-only public API supplement. A returned TestResults object is not an assertion pass; four nested erroneous results remain preserved. Candidate test-tool/API parity was not executed here.'),
    preserved_history=dict(report=identity(HISTORY / 'report.json'), sessions=47, JVM_processes=94,
        repeated_pairs_raw_equal=47, bytes_preserved=True, included_in_archive=identity(ARCHIVE)['path'],
        reason='The final matrix added one diagnostic-empty-source-list control in a new directory; the initial complete acquisition is retained unchanged, not overwritten or counted as new independent feature coverage.'),
    validation=dict(report=identity(VALIDATION / 'report.json'), commands=validation['commands'],
        all_six_checks_exit_zero=True, fixture_tests=dict(count=14, status='passed', raw_stdout=identity(VALIDATION / 'fixture-tests.stdout.bin'), raw_stderr=identity(VALIDATION / 'fixture-tests.stderr.bin')),
        protected_source_identities_unchanged=True, protected_source_manifest=identity(VALIDATION / 'sources.json'),
        scope='Read-only offline fixture/report integrity, exact raw test logs and pinned source inventory freshness. No Java guest or Rust/Node/browser candidate is launched by these checks.'),
    packaging_preparation_failure=dict(path='target/m2/stage55-oracle-checkpoint-publication-01/failure.json', reason='Initial archive output open failed because reports/m2 was absent; script and manifest preserved, no source or acquisition failure.'),
    owned_sources={name: identity(ROOT / name) for name in owned_names},
    publication=dict(archive=identity(ARCHIVE), payload_members=publication['payload_members'],
        archive_members=publication['archive_members'], manifest_sha256=publication['manifest_sha256'],
        historical_and_validation_payload_files=publication['historical_payload_files'],
        canonical_final_files_deduplicated=publication['omitted_fixture_files'],
        re_read_verified=True, safe_paths_and_no_duplicates=True,
        publication_report=identity(OUT / 'report.json'),
        canonical_archive_not_duplicated=True, originals_modified_or_deleted=False),
    remaining_scope=['This checkpoint makes no Rust/native/Wasm/N-API compatibility or implementation-completion claim.',
        'The parent concurrent native acquisition is separate evidence and is not summarized as this checkpoint work.',
        'Java internal errors/API exceptions and the buffer supplement remain explicit nonpass/unexecuted candidate boundaries.',
        'Service-provider/package URL policies, malformed signed frame coordinates, cross-evaluator stdlib lifetime and full lifecycle/API behavior remain open.',
        'Whole M2, release-platform compatibility and speed/memory targets remain open. No performance measurement or claim is made.',
        'Actual new step commit/source binding remains pending.'],
    Rust_compatibility_passes_claimed=0, whole_M2_complete=False, full_language_or_API_compatibility=False,
    performance_or_memory_targets_achieved=False, hosted_CI_result_claimed=False)
assert verification['call_status_counts'] == {'api-exception': 4, 'success': 142, 'oracle-error': 10, 'error': 24}
assert verification['buffer_supplement']['nested_oracle_error_results'] == 4
with CHECKPOINT.open('xb') as stream:
    stream.write(encoded(checkpoint))
assert load(CHECKPOINT) == checkpoint
print(json.dumps(dict(checkpoint=identity(CHECKPOINT), publication=publication), indent=2))
