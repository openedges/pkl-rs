# Stage55 Java-only checkpoint evidence

This archive preserves the original 47-session Java acquisition, its complete
raw outputs, inputs, compiled Java driver and source provenance. It also contains
the new read-only validation record, exact verifier stdout/stderr, all 14 Python
fixture tests and the pinned source-inventory check. No Rust, Wasm, Node or browser
candidate evaluation is part of this checkpoint.

The final 48-session main acquisition and seven-session buffer supplement are
already fully preserved by
`tests/fixtures/m2-frame-transformers/oracle-evidence.tar.gz`. Their payloads are
not duplicated. Every local final file and complete file set was compared
directly with that exact canonical archive before publication. The manifest
lists their identities and the external fixture path/hash.

`manifest.json` lists each published payload's SHA-256 and size. The read-only
verifier rejects duplicate, unsafe or nonregular archive members and checks
all member bytes. Supplying the canonical fixture archive also verifies every
deduplicated final member without Java or the original acquisition directories:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 verify.py \
  stage55-oracle-validation-evidence.tar.gz \
  --fixture-archive tests/fixtures/m2-frame-transformers/oracle-evidence.tar.gz
```

The external checkpoint JSON records this archive's exact identity. Actual Git
commit binding remains pending until the authorized step commit exists. Java
internal errors, API exceptions and nested erroneous TestResults remain data;
neither repeated raw equality nor verifier success claims Rust compatibility or
whole-language/API/performance completion.
