import json,hashlib,subprocess,time,os
from pathlib import Path
root=Path('/Users/cody.ij.hwang/Projects/pkl-rs');out=Path(__file__).parent
before=json.loads((out/'inputs-before.json').read_text());cmd=['node','--test','tools/platform/module-policy-session.test.mjs','tools/platform/resource-session.test.mjs']
start=time.time()
(out/'launch.json').write_text(json.dumps({'argv':cmd,'cwd':str(root),'pid':os.getpid(),'startedUnix':start},indent=2)+'\n')
with (out/'stdout.bin').open('wb') as stdout,(out/'stderr.bin').open('wb') as stderr:r=subprocess.run(cmd,cwd=root,stdout=stdout,stderr=stderr)
after={'files':{f:{'length':(root/f).stat().st_size,'sha256':hashlib.sha256((root/f).read_bytes()).hexdigest()} for f in before['files']}}
(out/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
changed=[f for f in before['files'] if before['files'][f]!=after['files'][f]]
(out/'report.json').write_text(json.dumps({'scope':'Mocked portable Host transport/unit tests only; no Rust build or actual native/browser evaluator acquisition.','argv':cmd,'exitCode':r.returncode,'sourceChanges':changed,'elapsedSeconds':time.time()-start,'stdoutSha256':hashlib.sha256((out/'stdout.bin').read_bytes()).hexdigest(),'stderrSha256':hashlib.sha256((out/'stderr.bin').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'exitCode':r.returncode,'sourceChanges':changed,'output':str(out)}))
raise SystemExit(r.returncode or bool(changed))
