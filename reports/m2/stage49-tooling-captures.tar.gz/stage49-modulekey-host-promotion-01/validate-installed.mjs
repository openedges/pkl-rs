import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve, dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {PINS, validateHostFacts, validateFactoryFacts} from '../../../tools/platform/compare-modulekey.mjs';

const out = dirname(fileURLToPath(import.meta.url));
const root = resolve(out, '../../..');
const host = resolve(root, 'tests/fixtures/m2-modulekey-host');
const spi = resolve(root, 'tests/fixtures/m2-modulekey-spi');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const metadataBytes = await readFile(resolve(host, 'host-metadata.json'));
const manifestBytes = await readFile(resolve(spi, 'manifest.json'));
assert.equal(hash(metadataBytes), PINS.sidecar);
assert.equal(hash(manifestBytes), PINS.fixture);
const metadata = JSON.parse(metadataBytes);
const manifest = JSON.parse(manifestBytes);
const authenticated = async rel => {
  const bytes = await readFile(resolve(spi, rel));
  assert.equal(hash(bytes), manifest.files[rel].sha256);
  assert.equal(bytes.length, manifest.files[rel].bytes);
  return bytes;
};
for (const proof of Object.values(metadata.sourceProof)) {
  assert.equal(hash(await readFile(resolve(host, proof.copy))), proof.sha256);
}
const bundle = JSON.parse(await authenticated('fixtures.json'));
const authored = JSON.parse(await authenticated('original/cases.json'));
const helper = (await authenticated('original/AdmissionProbe.java')).toString('utf8');
validateFactoryFacts(bundle, metadata, helper);
const cohorts = {};
for (const cohort of ['spi132', 'factory80', 'all212']) {
  const result = validateHostFacts(bundle, authored, metadata, cohort);
  cohorts[cohort] = {selectedSessions: result.selected.length,
    selectedApis: result.selected.reduce((n, row) => n + row.expected.length, 0),
    unexecutedSessions: result.unexecuted.length};
}
console.log(JSON.stringify({installedSidecarSha256: hash(metadataBytes),
  installedSpiManifestSha256: hash(manifestBytes), factoryFactsPassed: true,
  hostFactsPassed: true, cohorts, actualEvaluatorRuns: 0, actualBrowserLaunches: 0}, null, 2));
