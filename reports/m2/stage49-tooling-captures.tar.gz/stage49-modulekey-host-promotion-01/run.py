from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
SOURCE = ROOT / 'target/m2/stage49-oracle-spi-host-profile-03'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value, indent=2) + '\n')
metadata = json.loads((SOURCE / 'host-metadata.json').read_bytes())
inputs = [SOURCE / 'host-metadata.json'] + [SOURCE / row['copy'] for row in metadata['sourceProof'].values()]
inputs += [ROOT / 'tools/platform' / name for name in ['compare-modulekey.mjs', 'modulekey-session.mjs', 'module-policy-session.mjs', 'resource-session.mjs']]
inputs += [ROOT / 'tests/fixtures/m2-modulekey-spi' / name for name in ['manifest.json', 'fixtures.json', 'original/cases.json', 'original/AdmissionProbe.java']]
inputs += [OUT / name for name in ['run.py', 'promote.py', 'validate-installed.mjs']]
before = {str(path): sha(path) for path in inputs}
write(OUT / 'inputs-before.json', before)
records = []
for index, command in enumerate([[sys.executable, '-I', '-B', str(OUT / 'promote.py')], ['node', str(OUT / 'validate-installed.mjs')]]):
    row = {'command': command, 'cwd': str(ROOT), 'parentPid': os.getpid(), 'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (OUT / f'{index}.stdout.bin').open('wb') as stdout, (OUT / f'{index}.stderr.bin').open('wb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, stdout=stdout, stderr=stderr)
        row['pid'] = process.pid
        write(OUT / f'{index}.launch.json', row)
        row['exitCode'] = process.wait()
    row['finishedUtc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    row['stdoutSha256'] = sha(OUT / f'{index}.stdout.bin')
    row['stderrSha256'] = sha(OUT / f'{index}.stderr.bin')
    write(OUT / f'{index}.terminal.json', row)
    records.append(row)
    if row['exitCode'] != 0:
        break
after = {str(path): sha(path) for path in inputs}
write(OUT / 'inputs-after.json', after)
changes = [path for path in before if before[path] != after[path]]
report = {'schema': 1, 'commands': records, 'allCommandsZero': len(records) == 2 and all(row['exitCode'] == 0 for row in records),
          'sourceChanges': changes, 'actualEvaluatorRuns': 0, 'gitWrites': 0,
          'scope': 'Exact fixture installation, pinned upstream Git blob/readback joins, and installed fixture direct exported driver validators. No engine/artifact/browser execution.'}
write(OUT / 'report.json', report)
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['allCommandsZero'] and not changes else 1)
