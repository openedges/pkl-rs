"""Summarize the final frozen checkpoint without changing producer reports."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/m2'
OUT = ROOT / 'reports/m2/stage49-implementation-checkpoint.json'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda name: json.loads((BASE / name).read_bytes())
pin = lambda name: {'path': str(BASE / name), 'sha256': sha(BASE / name)}
assert not OUT.exists()
checks = read('stage49-required-rust-02/report.json')
build = read('stage49-modulekey-build05/build.json')
assert checks['status'] == 'PASS' and checks['sourceStable']
assert build['status'] == 'CLOSED' and build['sourceStable']
extended = read('stage49-oracle-native-extended944-build05-01/report.json')
audit = read('stage49-oracle-native-extended-audit-03/report.json')
report = {
    'schema': 1, 'status': 'verified-local-implementation-checkpoint',
    'recordedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Selected ModuleKey, public ModuleSource evaluation, executable ownership and portable Host adapter behavior. Not complete language/API, lifecycle, platform or performance compatibility.',
    'parentHeadAtRecording': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'implementationCommitNotYetClaimed': True,
    'candidate': pin('stage49-modulekey-build05/build.json'),
    'candidateSources': pin('stage49-modulekey-build05/sources-before.json'),
    'candidateArtifactSha256': build['artifactSha256'],
    'requiredRust': {
        'report': pin('stage49-required-rust-02/report.json'),
        **{k: checks[k] for k in ['checks', 'sourceCount', 'sourceStable', 'host', 'rustc']},
        'qualification': 'Command exits are recorded. Preexisting ignored probes remain unexecuted.',
    },
    'original212Native': {},
    'extendedNative': {
        'report': pin('stage49-oracle-native-extended944-build05-01/report.json'),
        'independentAudit': pin('stage49-oracle-native-extended-audit-03/report.json'),
        'apiCalls': extended['acquiredJavaApiCalls'],
        'rawMatches': extended['rawBytesMatch'],
        'rawMismatchOrMissing': extended['rawMismatchOrMissing'],
        'intentLedger': audit['intentLedger'],
        **{k: extended[k] for k in ['processExitCounts', 'allTerminalSlotsZero', 'sourceArtifactStable', 'fullJavaEventCounterGatePassed']},
        'resolvedOrdinaryBuild04Mismatches': 32,
        'priorFailedCapture': pin('stage49-oracle-native-extended944-build04-01/report.json'),
        'portable944Unexecuted': True,
    },
    'portable': {},
    'fixtures': {
        'javaObservationManifestSha256': sha(ROOT / 'tests/fixtures/m2-modulekey-spi/manifest.json'),
        'hostMetadataSha256': sha(ROOT / 'tests/fixtures/m2-modulekey-host/host-metadata.json'),
        'installedVerifierSha256': sha(ROOT / 'tools/modulekey_fixtures.py'),
        'installationChecks': pin('stage49-modulekey-fixture-checks-01/report.json'),
        'hostPromotion': pin('stage49-modulekey-host-promotion-01/handoff.json'),
    },
    'remaining': [
        'All whole-language M2 workstreams and the strict full gate remain open.',
        'Full Java factory/primary/query event and counter parity is not established by raw API matches.',
        'Eight invalid-fragment Java internal-error boundaries remain unmatched; 100 earlier query-alias inputs only establish diagnostic equality.',
        'Non-tail retired code slots and nested vector capacities can accumulate; total evaluator memory is not yet bounded.',
        'The extended944 controls have native evidence only; they have not run on Node or browser.',
        'The virtual File provider covers raw hierarchical file URIs, not every Java File URI input.',
        'Existing ModuleInfo, bootstrap, security, guest-catch and regex limitations remain.',
        'No full selected regression has yet been acquired for this final candidate. Stage48 acquisition and Stage47 published results are separate.',
        'Complete products and time/RSS performance targets are unverified.',
    ],
    'fullM2Complete': False, 'performanceTargetClaimed': False, 'hostedCiClaimed': False,
}
for profile in ['provided', 'public']:
    name = f'stage49-oracle-native-{profile}212-build05-01/report.json'
    d = read(name)
    assert d['rawApiPass'] == 212 and d['rawApiMismatchOrMissing'] == 0
    report['original212Native'][profile] = {'report': pin(name), **{
        k: d[k] for k in ['evaluationProfile', 'rawApiPass', 'rawApiMismatchOrMissing',
                         'unexecutedApiCalls', 'fullLifecyclePassSessions', 'fullLifecycleFailSessions',
                         'inputsAndToolsStable', 'allProcessesTerminal']}}
for path in sorted((BASE / 'stage49-platform-integration-02').iterdir()):
    f = path / 'execution.json'
    if not f.is_file():
        continue
    d = json.loads(f.read_bytes())
    targets = {}
    for target, v in d['targets'].items():
        targets[target] = {k: value for k, value in v.items() if k not in ['sessions', 'results', 'executions']}
        if 'sessions' in v:
            targets[target]['sessionCount'] = len(v['sessions']) if isinstance(v['sessions'], list) else v['sessions']
    report['portable'][path.name] = {
        'report': pin(f.relative_to(BASE)), 'targets': targets,
        'gates': {k: d[k] for k in ['acquisitionIntegrityPassed', 'rawApiPassed', 'fullLifecyclePassed',
                                  'selectedContractPassed', 'selectedCompatibilityComplete',
                                  'transportContractPassed', 'strictJavaCompatibilityPassed',
                                  'remainingStrictGateReasons'] if k in d},
        **{k: d.get(k, []) for k in ['infrastructureErrors', 'browserErrors', 'changedInputs']},
    }
p = read('stage49-platform-control-02/report.json')
report['primitive'] = {
    'report': pin('stage49-platform-control-02/report.json'),
    'artifactPins': pin('stage49-platform-control-02/artifact-pins.json'),
    **p['primitiveGate'], 'acquisitionAndArchitecturePassed': p['acquisitionAndArchitecturePassed'],
}
manifest = read('stage49-manifest-freshness-02/report.json')
report['inventory'] = {
    'report': pin('stage49-manifest-freshness-02/report.json'),
    **{k: manifest[k] for k in ['counts', 'onlyImplementationSourceHashesChanged', 'afterSha256']},
}
report['providerFix'] = {
    'focusedMockTests': 33,
    'unitReport': pin('stage49-loader-provider-unit-01/report.json'),
    'originalFailedActualCapture': pin('stage49-platform-integration-01/report.json'),
    'sameBuild04Followup': pin('stage49-loader-provider-integration-01/report.json'),
    'independentBuild04Review': pin('stage49-platform04-c-review-01/report.json'),
    'qualification': 'Raw API/callback agreement does not remove full request-counter mismatches.',
}
OUT.write_text(json.dumps(report, indent=2) + '\n')
print(str(OUT), sha(OUT))
