import test from 'node:test';
import assert from 'node:assert/strict';
import {runModuleKeyCase, compareModuleKeyCase} from './modulekey-session.mjs';

const uri = 'pkl:base', owner = 'file:///main.pkl';
const modulePlan = {requestedUri: uri, selectedUri: uri, resolvedUri: 'memo:/shared', sourceUri: uri,
  sourceText: 'tag = 99', inferredName: 'base', fragmentPaths: false, cacheMode: 'dynamic'};
const profile = {id: 'fixture', customModules: [modulePlan], fileModules: []};
const expected = {status: 'success', stdoutUnits: [55], stderrUnits: [], stdoutHex: '37', stderrHex: ''};
const fixture = {id: 'fixture', cohort: 'spi132', repeat: 0, session: 0, initialPolicy: 'allow',
  source: 'value=7', uri: owner, moduleName: 'main', expressions: ['value', 'value'],
  operations: [{kind: 'evaluate', source: 'main.pkl', expression: 'value'}, {kind: 'cache', value: 'off'},
    {kind: 'evaluate', source: 'main.pkl', expression: 'value'}, {kind: 'gc'}], expected: [expected, expected]};
const keyFields = keyId => ({keyId, keyKind: 'host', keyHandle: `configured-key:${keyId}`});
function requests(keyId, target = uri) {
  const resolvedKeyId = `${keyId}0`, descriptor = keyFields(keyId);
  return [
    {kind: 'select-key', originalUri: target, keyId, selectionPhase: 'runtime-import'},
    {kind: 'query-cache-policy', originalUri: target, ...descriptor},
    {kind: 'resolve', originalUri: target, importUri: target, importerOriginalUri: owner,
      importerResolvedUri: owner, ...descriptor, resolvedKeyId},
    {kind: 'load-source', originalUri: target, resolvedUri: modulePlan.resolvedUri, sourceUri: target,
      ...descriptor, resolvedKeyId, resolvedKeyHandle: `configured-resolved:${resolvedKeyId}`},
    {kind: 'query-fragment-paths', originalUri: target, ...descriptor},
  ];
}
function setup(programs, options = {}) {
  const calls = [], payloads = [];
  class Session {
    static forExpressions() { return new Session(); }
    startPath(index) { this.pending = [...programs[index]]; this.index = index; }
    poll() {
      const module = this.pending.shift();
      if (module) return {kind: 'module-request', token: 'token', module: {id: '0', ...module}};
      const value = Uint16Array.of(55); payloads.push(value); return {kind: 'value', value};
    }
    completeDefaultModule() { assert.fail('configured custom key must precede the default pkl factory'); }
    collect() {} heapSlots() { return 0; } free() {}
    close() { if (options.invalidatePayload) for (const view of payloads) view[0] = 0; }
  }
  for (const name of ['completeModuleKey', 'completeModuleCachePolicy', 'completeModuleFragmentPaths',
    'completeModuleResolvedKey', 'completeModuleSource']) Session.prototype[name] = (...args) => {
    calls.push([name, ...args]); if (options.throwAt === name) throw Error('stale completion token');
  };
  return {api: {SourceSession: Session}, calls};
}

test('custom builtin-spelling keys keep separate factory snapshots and actual per-key source requests', () => {
  const {api, calls} = setup([requests('1'), requests('2')]);
  const actual = runModuleKeyCase(api, fixture, profile);
  assert.equal(actual.acquisitionError, null);
  assert.deepEqual(calls.filter(row => row[0] === 'completeModuleCachePolicy'), [
    ['completeModuleCachePolicy', 'token', '1', true, 0],
    ['completeModuleCachePolicy', 'token', '2', false, 0],
  ]);
  assert.equal(calls.filter(row => row[0] === 'completeModuleSource').length, 2);
  assert.equal(actual.requests.length, 10);
  assert.deepEqual(actual.hostEvents.filter(row => row.kind === 'factory-key').map(row => row.cachedSnapshot), [true, false]);
  assert.equal(actual.hostEvents.at(-1).kind, 'explicit-collect');
  assert.equal(actual.architecture.releasedHostKeys, true);
  const comparison = compareModuleKeyCase(fixture, actual);
  assert.equal(comparison.rawApiPassed, true);
  assert.equal(comparison.fullLifecyclePassed, false);
});

test('resolved-key ownership cannot be substituted by matching URI strings', () => {
  for (const changed of [{resolvedKeyHandle: 'foreign'}, {resolvedKeyId: '11'}]) {
    const first = requests('1'); first[3] = {...first[3], ...changed};
    const {api, calls} = setup([first, []]);
    const actual = runModuleKeyCase(api, fixture, profile);
    assert.match(actual.acquisitionError.message, /resolved-key descriptor ownership mismatch/);
    assert.equal(calls.some(row => row[0] === 'completeModuleSource'), false);
    assert.equal(actual.architecture.terminalSlots, 0);
  }
});

test('selection does not resolve or load a source until those requests actually arrive', () => {
  const {api, calls} = setup([[requests('1')[0]], [requests('2')[0]]]);
  const actual = runModuleKeyCase(api, fixture, profile);
  assert.equal(actual.acquisitionError, null);
  assert.deepEqual(calls.map(row => row[0]), ['completeModuleKey', 'completeModuleKey']);
});

test('unknown profiles and mismatched operation sequences cannot become compatibility passes', () => {
  for (const change of [{cohort: 'factory80'}, {initialPolicy: 'unknown'}, {expressions: ['different']}]) {
    const {api} = setup([[], []]);
    const actual = runModuleKeyCase(api, {...fixture, ...change}, profile);
    assert.notEqual(actual.acquisitionError, null);
    assert.equal(compareModuleKeyCase(fixture, actual).rawApiPassed, false);
  }
});

test('binding exceptions and invalidated result ownership remain failed acquisitions', () => {
  const stale = setup([requests('1'), []], {throwAt: 'completeModuleResolvedKey'});
  const actual = runModuleKeyCase(stale.api, fixture, profile);
  assert.match(actual.acquisitionError.message, /stale completion token/);
  assert.equal(stale.calls.some(row => row[0] === 'completeModuleSource'), false);
  const invalid = setup([[], []], {invalidatePayload: true});
  const changed = runModuleKeyCase(invalid.api, fixture, profile);
  assert.equal(changed.architecture.ownedResultsStable, false);
  assert.equal(compareModuleKeyCase(fixture, changed).rawApiPassed, false);
});

test('raw channel and missing-call differences survive comparison without normalization', () => {
  const {api} = setup([[], []]);
  const actual = runModuleKeyCase(api, fixture, profile);
  actual.calls[0].stdoutUnits.push(10);
  actual.calls.pop();
  assert.deepEqual(compareModuleKeyCase(fixture, actual).failures, ['call-count', 'raw-api-0', 'raw-api-1']);
});
