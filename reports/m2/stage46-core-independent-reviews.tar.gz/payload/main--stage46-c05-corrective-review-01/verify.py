"""Independent read-only source and existing raw fixture review of C05."""
import json,hashlib,re,struct,time,difflib
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46')
B=ROOT/'target/m2/stage46-implementation-01'
S=B/'resource-candidate-build-05';P=B/'c04-corrective-proposal-01'
OUT=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage46-c05-corrective-review-01')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
start=time.time();release=load(S/'release.json');assert sha(S/'release.json')=='267d3b502b6291e5b3b1c787790ada2813555150252aae0436f7b16779fc5c56'
source=load(S/'source-after.json');assert sha(S/'source-after.json')==release['source_map_sha256']=='eef46854ef218c373fa3a98361f7625dea569fe6a598016ee15762ac0409a4ca' and len(source)==release['source_count']==32518
for n,d in source.items():
 p=Path(n);assert not p.is_absolute() and '..' not in p.parts;f=S/'sources'/p;assert f.is_file() and not f.is_symlink() and sha(f)==d,n
build=load(S/'report.json');assert sha(S/'report.json')==release['build_report_sha256'] and build['exit_code']==0 and build['source_stable'];assert sha(S/'source-before.json')==sha(S/'source-after.json')==build['source_before_sha256']==build['source_after_sha256'];assert sha(S/'environment.json')==release['environment_sha256']
for ch in ['stdout','stderr']:assert sha(S/(ch+'.bin'))==build[ch+'_sha256']
for v in release['artifacts'].values():assert sha(Path(v['path']))==v['sha256']
proposal=load(P/'report.json');assert sha(P/'report.json')=='72ad0b3089efd76db1a0b854539a829b935fec57eac97b5fead24474bd781b55';assert all(sha(P/'sources'/n)==d for n,d in proposal['sources'].items())
old=load(B/'resource-candidate-build-04/source-after.json');changed=[n for n,d in source.items() if n.startswith('crates/pkl-runtime/src/') and old.get(n)!=d];assert set(changed)==set(proposal['sources'])
comment='crates/pkl-runtime/src/resolver/diagnostic_owner.rs';assert [n for n,d in proposal['sources'].items() if source[n]!=d]==[comment]
text_before=(P/'sources'/comment).read_text();text_after=(S/'sources'/comment).read_text();strip_doc=lambda s:'\n'.join(x for x in s.splitlines() if not x.lstrip().startswith('//!'))
assert strip_doc(text_before)==strip_doc(text_after)
records=[]
for name,exit_code in [('c04-corrective-runtime-tests-01',0),('c04-corrective-fixture-test-01',0),('c04-corrective-fixture-python-01',0),('c04-corrective-fixture-verify-01',2)]:
 p=B/name;d=load(p/'report.json');assert d['exit_code']==exit_code and d['source_stable'];m=load(p/'source-after.json');assert sha(p/'source-after.json')==d['source_after_sha256'] and sha(p/'source-before.json')==d['source_before_sha256']
 for ch in ['stdout','stderr']:assert sha(p/(ch+'.bin'))==d[ch+'_sha256']
 mismatch=[n for n in changed if m.get(n)!=source[n]];assert set(mismatch)<=set([comment])
 records.append({'path':str(p/'report.json'),'sha256':sha(p/'report.json'),'exitCode':exit_code,'sourceStable':True,'codeDifferenceFromC05':mismatch,'qualification':'Only diagnostic_owner module documentation differs' if mismatch else 'Corrective production hashes match C05'})
fixture=S/'sources/tests/fixtures/m2-logical-capability';manifest=load(fixture/'manifest.json');data=load(fixture/'fixtures.json');provenance=load(fixture/'provenance.json')
for n,v in manifest['files'].items():assert sha(fixture/n)==v['sha256'] and (fixture/n).stat().st_size==v['bytes']
assert data['selectedJavaApiCalls']==36 and data['allJavaApiCalls']==84 and data['unselectedJavaApiCalls']==48 and len(data['cases'])==3
reports={};inventories={}
for group,p in provenance['pins'].items():
 local=fixture/'provenance'/group
 for filename,key in [('report.json','reportSha256'),('inventory.json','inventorySha256'),('closure.json','closureSha256')]:assert sha(local/filename)==p[key] and sha(Path(p['root'])/filename)==p[key]
 reports[group]=load(local/'report.json');inventories[group]={x['path']:x for x in load(local/'inventory.json')['files']}
for original,v in provenance['originalPaths'].items():
 local=fixture/v['path'];assert sha(local)==v['sha256'] and local.stat().st_size==v['bytes']
 group=next(g for g,p in provenance['pins'].items() if Path(original).is_relative_to(Path(p['root'])));rel=Path(original).relative_to(Path(provenance['pins'][group]['root'])).as_posix()
 if rel in ['inventory.json','closure.json']:assert v['sha256']==provenance['pins'][group]['inventorySha256' if rel=='inventory.json' else 'closureSha256']
 else:assert v['sha256']==inventories[group][rel]['sha256'] and v['bytes']==inventories[group][rel]['bytes']
compared=0
for case in data['cases']:
 group=case['group'];report=reports[group]
 for observation in case['observations']:
  ob=next(o for o in report['observations'] if o['case']==case['id'] and o['repeat']==observation['repeat']);original_calls=[c for c in ob['calls'] if c['session']==observation['session']]
  assert len(original_calls)==len(observation['calls'])==len(case['expected'])==3
  for expected,rawref,c in zip(case['expected'],observation['calls'],original_calls):
   original=str(Path(provenance['pins'][group]['root'])/c['rawPrefix']);assert rawref['originalPrefix']==original and rawref['prefix']==c['prefix'];read=lambda suffix:(fixture/rawref['refs'][suffix]).read_bytes()
   assert read('status.bin')==c['status'].encode();assert expected['status']=={'success\n':'success','error\n':'error'}[c['status']]
   for suffix,local in rawref['refs'].items():assert provenance['originalPaths'][original+'.'+suffix]['path']==local
   for ch in ['stdout','stderr']:
    raw=read(ch+'.bin');words=read(ch+'.code-units.bin');assert expected[ch+'Hex']==raw.hex() and expected[ch+'Units']==list(struct.unpack('>'+'H'*(len(words)//2),words));assert words.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==raw
   active='stdout' if expected['status']=='success' else 'stderr';assert read(active+'.bin').hex()==c['utf8Hex'] and read(active+'.code-units.bin').hex()==c['utf16BEHex']
   for phase,key in [('before','countersBefore'),('after','countersAfter')]:
    counter=read('counters-'+phase+'.bin');assert counter==c[key].encode();count=dict(x.split('=',1) for x in counter.decode().splitlines())['read'];assert read('reads-'+phase+'.bin')==count.encode() and expected['reads'+phase.title()]==int(count)
   compared+=1
assert compared==36
native_test='crates/pkl-runtime/tests/m2_logical_capability_oracle.rs';focus=load(B/'c04-corrective-fixture-test-01/source-after.json');assert source[native_test]==focus[native_test]
assert all(source[n]==d for n,d in focus.items() if n.startswith('tests/fixtures/m2-logical-capability/'))
assert all(sha(S/'sources'/n)==source[n] for n in changed)
result={'schema':1,'scope':'Read-only narrow corrective source review and independent existing Java fixture linkage for immutable C05. No new tests/build/Java/native/platform acquisition.','release':{'path':str(S/'release.json'),'sha256':sha(S/'release.json')},'sourceMap':{'path':str(S/'source-after.json'),'sha256':sha(S/'source-after.json'),'filesVerified':len(source)},'artifacts':release['artifacts'],'correctiveProposal':{'path':str(P/'report.json'),'sha256':sha(P/'report.json')},'productionDeltaFromC04':changed,'proposalToC05Difference':{'path':comment,'documentationOnly':True},'existingCheckRecords':records,'compactJavaFixture':{'manifestSha256':sha(fixture/'manifest.json'),'payloadsVerified':len(manifest['files']),'cases':3,'rawCallsIndependentlyJoined':compared,'allJavaCallsInCopiedReports':84,'unselected':48,'nativeTestSourceSha256':source[native_test],'nativeEvidenceBoundary':'Existing focused Rust unit test asserts all36 status/UTF16/JavaUTF8 outcomes, retained/repeated failures and GC cleanup. Passed native API buffers are asserted inside the test, not separately archived per call by this test. Fresh external C05 comparison captures remain separate.'},'findings':[],'sourceConclusions':['Actual resolver AST function_owners are reused for runtime lambda metadata; runtime short-circuit bytecode visitation is preserved. Repeated AST visits replace only the final owner map while preparation occurrences retain distinct owners.','Module, annotation and repl query owner prefixes are adapted to existing RuntimeSource/member conventions; old standalone resolver/compiler path retains fallback name counters.','Logical operand diagnostics use the shared heap-aware nonforcing type/value renderer; Boolean side of right-operand failures remains tied to the logical operation.','Typed IoUtils capability failure preserves hint separately and marks its source origin unavailable. Import preparation clears the marker and restores the authored URI operand.','VM consumes unavailable_origin once while retaining caller unwind, inserted let/value frames and cache cleanup. New metadata contains no heap values requiring GC roots.'],'statusOfPriorRuntimeOwnerFinding':'Source correction confirmed and representative lambda#2 raw Java fixture is asserted by existing native36-call unit differential test; full logical/capability native C05 comparison remains pending.','remaining':['Fresh C05 external File/order/static/logical/capability raw captures, original read repetitions and required Rust5 were running at handoff; do not infer their results here.','C04 624pass/8diagnosticmismatch and16API-unexecuted outcomes remain unchanged historical evidence. Shared-renderer source change alone does not mark those8 external C04 mismatches closed.','Parameterized objects, forced read*, broader policy/module/resource dependencies, actual Node/browser Resource sessions and full M2/performance gates remain separate obligations.'],'reviewSourceAfterUnchanged':True,'seconds':time.time()-start}
(OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'report':str(OUT/'report.json'),'sha256':sha(OUT/'report.json'),'sources':len(source),'javaRawCalls':compared,'seconds':result['seconds']}),flush=True)
