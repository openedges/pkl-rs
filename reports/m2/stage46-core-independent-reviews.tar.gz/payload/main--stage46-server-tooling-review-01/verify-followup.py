"""Read-only independent verification of the completed C06 HTTP-tool followup."""
from pathlib import Path
import hashlib
import json
import struct

ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46')
B = ROOT / 'target/m2'
C = B / 'stage46-implementation-01/resource-candidate-build-06'
F = B / 'stage46-http-server-correction-01'
A = B / 'stage46-platform-http-followup-01'
BASE = B / 'stage46-platform-baseline-02'
OUT = Path(__file__).resolve().parent


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def unit_bytes(units):
    assert all(type(u) is int and 0 <= u < 65536 for u in units)
    return struct.pack('>' + 'H' * len(units), *units)


def java8(units):
    return unit_bytes(units).decode('utf-16-be', 'surrogatepass').encode('utf-8', 'replace')


assert sha(F / 'final-application.json') == '34d0b08a76a3e9fbee9b1c2ec1b9bd83ff179b6b4959d5793430498b9815b9be'
correction = read(F / 'final-application.json')
source = read(C / 'source-after.json')
assert len(source) == 32847
corrected = {r['path']: r for r in correction['files']}
assert len(corrected) == 6
for p, row in corrected.items():
    assert row['before'] == source[p] == sha(C / 'sources' / p)
    assert row['after'] == sha(ROOT / p) and row['syntaxExitCode'] == 0
    text = (ROOT / p).read_text()
    assert 'const assetBytes = await readFile(path)' in text
    assert 'end(assetBytes)' in text and '.headersSent)' in text and '.destroy()' in text
actual_changes = {p for p, h in source.items() if sha(ROOT / p) != h}
assert actual_changes == set(corrected)

top = read(A / 'report.json')
terminal = read(A / 'outer-terminal.json')
assert terminal['actualExitCode'] == 0 and terminal['reportSha256'] == sha(A / 'report.json')
assert top['selectedAcquisitionPassed'] and top['fullCompatibilityPassed'] is False
assert top['finishedUtc'] and top['runtimeOrBuildConfigurationChanges'] == []
assert top['sourceChangesDuringAcquisition'] == [] and set(top['postBuildToolingChanges']) == set(corrected)
assert top['candidateReleaseSha256'] == sha(C / 'release.json')
assert top['candidateSourceMapSha256'] == sha(C / 'source-after.json')
assert top['postBuildToolingCorrectionSha256'] == sha(F / 'final-application.json')
for command in top['commands']:
    assert command['exitCode'] == 0
    for channel in ['stdout', 'stderr']:
        assert sha(A / (command['name'] + '.' + channel + '.bin')) == command[channel + 'Sha256']
assert len(top['commands']) == 2
base = read(BASE / 'report.json')
assert top['baselineReportSha256'] == sha(BASE / 'report.json')
for p, h in base['artifacts'].items():
    assert sha(BASE / p) == h
for p, h in base['source_hashes'].items():
    assert sha(BASE / 'sources' / p) == h == source[p]

summary = {}
for name, count, session_count, fixture_name, driver, helper in [
    ('resource', 1008, 20, 'm2-resource-portable', 'compare-resource.mjs', 'resource-session.mjs'),
    ('module', 252, 24, 'm2-module-portable', 'compare-module-preparation.mjs', 'module-preparation-session.mjs'),
]:
    p = B / f'stage46-{name}-platform-03'
    report = read(p / 'execution.json')
    assert report['finishedAt'] and report['selectedContractPassed'] and report['fullCompatibilityPassed'] is False
    assert report['infrastructureErrors'] == report['browserErrors'] == report['changedInputs'] == []
    assert report['preflight'] == read(p / 'preflight.process.json') and report['preflight']['exitCode'] == 0
    assert report['serverMissingAssetProbe'] == {'path': '/__pkl_verification_missing_asset__.js', 'status': 404, 'bodyHex': ''}
    assert report['browserLaunchOptions'] == {'headless': True, 'executablePath': report['browserExecutable']}
    assert sha(Path(report['browserExecutable'])) == report['browserExecutableSha256']
    assert report['playwrightPin'] == '1.64.1'
    for artifact, digest in report['artifactAndInputHashes'].items():
        assert sha(Path(artifact)) == digest, artifact
    for artifact, digest in base['artifacts'].items():
        if artifact != 'semantics_probe':
            assert report['artifactAndInputHashes'][str(BASE / artifact)] == digest
    assert sha(p / driver) == corrected['tools/platform/' + driver]['after']
    assert sha(p / helper) == source['tools/platform/' + helper]
    fixture = read(p / 'fixtures.json')
    assert fixture == read(C / 'sources/tests/fixtures' / fixture_name / 'fixtures.json')
    assert len(fixture['fixtures']) == session_count
    targets = {}
    for target in ['node', 'browser']:
        raw = read(p / (target + '.raw.json'))
        assert len(raw) == session_count
        calls = readers = observed_events = requests = 0
        for index, (f, actual) in enumerate(zip(fixture['fixtures'], raw)):
            assert (actual['id'], actual['repeat'], actual['session']) == (f['id'], f['repeat'], f['session'])
            assert actual['constructorError'] is None and actual['acquisitionError'] is None
            assert len(actual['calls']) == len(f['expected']) == len(f['expressions'])
            assert actual['readerUris'] == [row['uri'] for row in f['readerPlan']]
            ar = actual['architecture']
            assert ar['terminalSlots'] == 0 and ar['ownedResultsStable'] and ar['consumedReaderPlan'] and ar['collections'] > 0
            directory = p / target / str(index)
            assert actual == read(directory / 'actual.json') and f['expected'] == read(directory / 'expected.json')
            for i, (call, expected) in enumerate(zip(actual['calls'], f['expected'])):
                assert call['index'] == i and call['expression'] == f['expressions'][i]
                assert call['status'] == expected['status']
                assert call['readsBefore'] == expected['readsBefore'] and call['readsAfter'] == expected['readsAfter']
                assert call['status'] == 'success' or call['disposition'] == 'language-error'
                for channel in ['stdout', 'stderr']:
                    units = call[channel + 'Units']
                    assert units == expected[channel + 'Units']
                    assert java8(units).hex() == expected[channel + 'Hex']
                    assert (directory / f'{i}.{channel}.utf16be.bin').read_bytes() == unit_bytes(units)
                    assert (directory / f'{i}.{channel}.java-utf8.bin').read_bytes() == bytes.fromhex(expected[channel + 'Hex'])
                if name == 'module':
                    assert call['observableEvents'] == expected['observableEvents'] == actual['observableEventsByCall'][i]
                    observed_events += len(call['observableEvents'])
                calls += 1
            comparison = read(directory / 'comparison.json')
            assert comparison['passed'] and all(comparison['checks'].values())
            assert all(row['status'] == 'pass' and all(row['checks'].values()) for row in comparison['comparisons'])
            readers += len(actual['readerUris'])
            requests += len(actual.get('moduleRequests', []))
        assert calls == count and report['targets'][target]['rawApiCounts'] == {'pass': count}
        assert report['targets'][target]['complete'] and report['targets'][target]['selectedContractPassed']
        targets[target] = {'calls': calls, 'sessions': session_count, 'readerCallbacks': readers,
                           'orderedProjectedObservableEvents': observed_events, 'capturedHostRequests': requests}
    summary[name] = {'executionSha256': sha(p / 'execution.json'), 'targets': targets,
                     'serverMissingAssetProbe': report['serverMissingAssetProbe'],
                     'browserExecutable': report['browserExecutable'], 'browserExecutableSha256': report['browserExecutableSha256'],
                     'browserLaunchOptions': report['browserLaunchOptions'],
                     'inputArtifactHashesVerified': len(report['artifactAndInputHashes'])}

result = {
    'scope': 'Independent read-only inspection of the six-driver correction and already acquired C06 HTTP followup. No new Java/native/Node/browser/build/test execution.',
    'sourceOnlyCorrection': {'applicationSha256': sha(F / 'final-application.json'), 'exactChangedTools': sorted(corrected), 'allOther32847InputsUnchanged': True, 'noRuntimeOrBuildConfigurationChanges': True},
    'actualFollowup': {'reportSha256': sha(A / 'report.json'), 'outerTerminalSha256': sha(A / 'outer-terminal.json'), 'outerExit': 0, 'baselineReportSha256': sha(BASE / 'report.json')},
    'results': summary,
    'findings': [],
    'qualifications': [
        'C06 acquisition02 Resource/module HTTP failures and the original candidate snapshot remain unchanged. These are fresh acquisitions using the same frozen C06 evaluator artifacts plus six explicitly bound post-build HTTP tools.',
        'The recorded Chromium executable is now explicitly passed in launch options and rehashed; historical default-headless C05 identities remain qualified separately.',
        'The two missing-asset probes have actual status404 and empty body. Four other corrected drivers have source/syntax evidence only; this followup does not execute them.',
        'Module capabilities/has-element provider facts are unordered input/source rules. Only the declared ordered Java-observable projection is compared, not complete Java SPI request order.',
        'Raw UTF16 and Java-equivalent UTF8 are checked independently; byte files encode observed API text, not byte-output API coverage. Node wrapper GC is not forced.',
        'Selected Resource1008 and module252 per target do not close remaining API/constructor/physical I/O/whole-language/platform/performance obligations. Baseline known regex failures remain failed.',
    ],
}
OUT.joinpath('followup-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'reportSha256': sha(OUT / 'followup-review.json'), 'results': summary}))
