import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46')
BUILD = ROOT / 'target/m2/stage46-implementation-01'
C05 = BUILD / 'resource-candidate-build-05'
C06 = BUILD / 'resource-candidate-build-06'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def differences(a, b, path=''):
    if type(a) is not type(b):
        return [(path, a, b)]
    if isinstance(a, dict):
        assert a.keys() == b.keys(), path
        return [d for k in a for d in differences(a[k], b[k], f'{path}/{k}')]
    if isinstance(a, list):
        assert len(a) == len(b), path
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in differences(x, y, f'{path}/{i}')]
    return [] if a == b else [(path, a, b)]


assert sha(C06 / 'release.json') == 'e9eb9341344a2db28f1b020cc8081bb3e8dfe67158c8eb932a00211832b3c807'
assert sha(C06 / 'source-after.json') == '8df1d6bb56a4467088d8e07a4e12ee39b651d6a91a1c0ab1a11c64ff95c93370'
before_map = read(C05 / 'source-after.json')
after_map = read(C06 / 'source-after.json')
assert len(after_map) == 32847
# Enumerate only the producer's exact frozen input map; never walk Cargo caches.
assert all(sha(C06 / 'sources' / p) == h for p, h in after_map.items())
delta = read(C06 / 'source-delta-c05.json')
assert len(delta['added']) == 329 and len(delta['changed']) == 17 and len(delta['removed']) == 0
assert set(delta['added']) == after_map.keys() - before_map.keys()
assert delta['changed'] == {p: {'before': before_map[p], 'after': after_map[p]}
                            for p in before_map.keys() & after_map.keys() if before_map[p] != after_map[p]}

integration = ROOT / 'target/m2/stage46-module-portable-integration-01'
promotion = read(integration / 'promotion.json')
assert sha(integration / 'promotion.json') == '67fbcf64e871d6e558d00ba8f12b9d1171f6b65a51cdde4cffae0987c2b757ff'
assert len(promotion['promotedHashes']) == 328
assert promotion['fixturePayloadFiles'] == 321 and promotion['fixtureTotalFiles'] == 322
assert all(after_map[p] == h == sha(ROOT / p) for p, h in promotion['promotedHashes'].items())
record = read(integration / 'report.json')
terminal = read(integration / 'outer-terminal.json')
assert terminal['actualExitCode'] == 0 and terminal['reportSha256'] == sha(integration / 'report.json')
assert record['passed'] and record['sourceChanges'] == []
for command in record['commands']:
    assert command['exitCode'] == 0
    for stream in ['stdout', 'stderr']:
        assert sha(integration / f"{command['name']}.{stream}.bin") == command[stream + 'Sha256']
js = (integration / 'js.stdout.bin').read_text()
assert re.search(r'tests 21\b', js) and re.search(r'pass 21\b', js) and re.search(r'fail 0\b', js)

old_inventory = read(C05 / 'sources/compatibility/m2-language.json')
inventory = read(C06 / 'sources/compatibility/m2-language.json')
inventory_diff = differences(old_inventory, inventory)
assert len(inventory_diff) == 117
assert all(re.fullmatch(r'/requirements/\d+/implementation/links/\d+/sha256', p) for p, _, _ in inventory_diff)
assert inventory['cases'] == old_inventory['cases']
assert inventory['counts'] == old_inventory['counts']
assert inventory['counts']['cases'] == 4527
assert inventory['counts']['cases_by_execution'] == {'ready': 3664, 'unimplemented': 823, 'unmapped': 40}
for path, _, digest in inventory_diff:
    _, _, index, _, _, link_index, _ = path.split('/')
    link = inventory['requirements'][int(index)]['implementation']['links'][int(link_index)]
    assert after_map[link['path']] == digest

browser = read(ROOT / 'target/m2/stage46-browser-identity-correction-01/application.json')
assert len(browser['files']) == 7
browser_paths = []
for row in browser['files']:
    p = row['path']
    if p.startswith('target/'):
        p = 'tools/platform/compare-module-preparation.mjs'
    assert after_map[p] == row['after']
    text = (C06 / 'sources' / p).read_text()
    assert 'executablePath:' in text and 'chromium.launch(' in text
    browser_paths.append(p)

review_paths = set(promotion['promotedHashes']) | set(delta['changed']) | {
    'docs/m2-module-preparation-platforms.md', 'docs/m2-resource-cache.md',
    'docs/m2-resource-portable-fixtures.md', 'tools/platform/resource-session.mjs',
}
reviewed_hashes = {p: after_map[p] for p in sorted(review_paths)}
assert all(sha(ROOT / p) == h for p, h in reviewed_hashes.items())
report = {
    'scope': 'Independent read-only source and existing-record review of the frozen C06 module provider integration, lint corrections, inventory refresh and explicit browser launch. No new evaluator, Java, Node, browser, build or test execution.',
    'candidate': {'releaseSha256': sha(C06 / 'release.json'), 'sourceMapSha256': sha(C06 / 'source-after.json'), 'explicitSnapshotInputsRehashed': len(after_map), 'added': 329, 'changed': 17, 'removed': 0},
    'promotion': {'sha256': sha(integration / 'promotion.json'), 'exactPromotedInputs': 328, 'fixturePayloadFiles': 321, 'fixtureTotalFiles': 322, 'matchFrozenAndLive': True},
    'inventory': {'exactDiffFields': [p for p, _, _ in inventory_diff], 'hashOnlyChanges': 117, 'caseDefinitionsAndOrderUnchanged': True, 'countsUnchanged': True, 'counts': inventory['counts']},
    'existingChecks': {'reportSha256': sha(integration / 'report.json'), 'outerTerminalSha256': sha(integration / 'outer-terminal.json'), 'actualOuterExit': 0, 'commandCount': len(record['commands']), 'allRawStreamHashesMatch': True, 'resourceAndModuleJsTests': 21, 'sourceChanges': []},
    'sourceReview': {
        'moduleConsumer': 'Exact reusable provider-key lookup; no fallback, URI search or shared cache implementation in JavaScript. Ordered Java-observable policy projection is compared separately from unordered input facts. Typed security-denied reads do not consume the counted-reader plan. Full UTF16/JavaUTF8/count/retained-result comparisons and pending-request GC are retained through the Resource runner.',
        'lintCorrections': 'Parser Done transfers the same Expr through the existing current slot and immediately takes it; let-chains preserve ordered conditions. Byte-pair iterator changes retain explicit even-length assertions; test Option comparison preserves the assertion. No semantic change identified in the 8 changed Rust paths.',
        'browserLaunch': 'All seven selected drivers explicitly pass the recorded executable path to launch. Historical C05 records remain qualified and do not prove the actual default-headless executable hash.',
        'documentation': '252 selected/24 sessions versus 300 original/48 unselected; unordered SPI input facts versus ordered Java-observable projection; historical unsealed records, C05 exploratory scope and C06 pending outcomes remain explicit.',
    },
    'browserDrivers': browser_paths,
    'findings': [],
    'qualification': 'This is scoped source review plus verification of already recorded tool checks. It makes no C06 runtime-test, native/oracle or platform-completion claim. C05 actual outcomes remain evidence for C05; complete module/resource/language/platform/performance compatibility remains open.',
    'reviewedFrozenAndLiveHashes': reviewed_hashes,
}
OUT.joinpath('report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'reportSha256': sha(OUT / 'report.json'), 'snapshotInputs': len(after_map), 'reviewedLiveInputs': len(reviewed_hashes), 'findings': []}))
