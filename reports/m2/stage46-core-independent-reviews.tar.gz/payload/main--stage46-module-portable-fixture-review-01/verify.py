"""Independent read-only audit of Java-derived portable ModuleKey fixtures."""
from pathlib import Path
import ast,hashlib,json,os,re,stat,struct,time
B=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage46/target/m2/stage46-module-portable-fixtures-01')
F=B/'workspace/tests/fixtures/m2-module-portable'
OUT=Path('/Users/cody.ij.hwang/Projects/pkl-rs/target/m2/stage46-module-portable-fixture-review-01')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_bytes())
def safe(n):
 p=Path(n);assert str(p)==n and not p.is_absolute() and '..' not in p.parts,n
 return p
start=time.time();report=load(B/'report.json');closure=load(B/'closure.json');handoff=load(B/'handoff.json');source=load(B/'source-after.json')
assert sha(B/'report.json')=='ab228b539de39f8e8caa352ab796980208c93a696388a36497598fdb3eb0306a' and sha(B/'closure.json')=='afa523b2b6b5e0f282da8f93a0c957df2a3c2f5d7eaba210e42793805887e19e' and sha(B/'handoff.json')=='45fb6acdf5a751c6b851d2d88f9a66cbfa4cede30c35dcb6f4fbfccc165848f4'
assert closure['closed'] and closure['reportSha256']==sha(B/'report.json') and closure['handoffSha256']==sha(B/'handoff.json') and sha(B/'inventory.json')==closure['inventorySha256']
inventory=load(B/'inventory.json')['files'];assert len(inventory)==closure['files']==338
for row in inventory:
 p=B/safe(row['path']);assert p.is_file() and not p.is_symlink() and sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
assert source==report['sources']==load(B/'source-before-tests.json') and sha(B/'source-after.json')==report['sourceMapSha256']=='69a65ddec11e6274df12d3e5efaff7b33e0921b241da9faf0a649975a21016b0'
for p,d in source.items():
 f=B/'workspace'/safe(p);assert sha(f)==d;t=OUT/'sources'/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(f.read_bytes())
module=ast.parse((B/'workspace/tools/module_portable_fixtures.py').read_bytes());const={}
for n in module.body:
 if isinstance(n,ast.Assign):
  for v in n.targets:
   if isinstance(v,ast.Name) and v.id in ['PINS','SELECTED','KEYS','SUFFIXES']:const[v.id]=ast.literal_eval(n.value)
pins=const['PINS'];selected=const['SELECTED'];keys=const['KEYS'];suffixes=const['SUFFIXES']
manifest=load(F/'manifest.json');data=load(F/'fixtures.json');prov=load(F/'provenance.json');assert sha(F/'manifest.json')==report['fixtureManifestSha256']=='7855fe7e98f1089a60f26467b9391d11724d968d7867adc0184148c830ab3913' and sha(F/'fixtures.json')==report['fixtureJsonSha256'] and prov['pins']==pins
files=set(manifest['files'])|{'manifest.json'};assert len(manifest['files'])==321 and len(files)==322;seen=set();pending=[F]
while pending:
 d=pending.pop()
 with os.scandir(d) as entries:
  for e in entries:
   n=Path(e.path).relative_to(F).as_posix();m=e.stat(follow_symlinks=False).st_mode
   if stat.S_ISDIR(m):assert n=='captured';pending.append(Path(e.path))
   else:assert stat.S_ISREG(m);seen.add(n)
assert seen==files
for n,r in manifest['files'].items():assert sha(F/safe(n))==r['sha256'] and (F/n).stat().st_size==r['bytes']
bindings=prov['originalPaths']
for original,r in bindings.items():
 assert r['path']=='captured/'+r['sha256']+'.bin';p=F/safe(r['path']);assert sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
 if r['independentlyPinnedSha256'] is not None:assert r['sha256']==r['independentlyPinnedSha256']
assert set(manifest['files'])=={'fixtures.json','provenance.json'}|{r['path']for r in bindings.values()}
def read(original):return (F/bindings[str(original)]['path']).read_bytes()
reports={};cases={};expected_ids=[];unselected=[]
for group,p in pins['groups'].items():
 root=Path(p['root']);assert hashlib.sha256(read(root/'report.json')).hexdigest()==p['reportSha256'];d=json.loads(read(root/'report.json'));reports[group]=d;cs=json.loads(read(root/'cases.json'));cases[group]={c['id']:c for c in cs}
 for name,key in [('inventory.json','inventorySha256'),('closure.json','closureSha256')]:
  if p[key] is not None:assert hashlib.sha256(read(root/name)).hexdigest()==p[key]
 for c in cs:
  observations=[o for o in d['observations']if o['case']==c['id']]
  if c['id'] in selected[group]:
   expected_ids.extend((group+'/'+c['id'],o['repeat'],session)for o in observations for session in [0,1])
  else:
   unselected.extend((group,c['id'],o['repeat'],x['session'],x['prefix'],x['source'],x['expression'],str(root/x['rawPrefix']))for o in observations for x in o['calls'])
assert [(f['id'],f['repeat'],f['session'])for f in data['fixtures']]==expected_ids and len(expected_ids)==24
assert [(x['group'],x['case'],x['repeat'],x['session'],x['prefix'],x['source'],x['expression'],x['rawOriginalPrefix'])for x in data['unexecutedApiBoundaries']]==unselected and len(unselected)==48
assert data['javaApiCalls']==sum(r['apiCalls']for r in reports.values())==300
assert data['historicalOracleSeals']['triple-dot']=={'inventorySha256':None,'closureSha256':None}
count=0;projected=0;providers=0;reconstructed={};denials=0
for f in data['fixtures']:
 group,case=f['id'].split('/',1);root=Path(pins['groups'][group]['root']);d=reports[group];c=cases[group][case];ob=next(o for o in d['observations']if o['case']==case and o['repeat']==f['repeat']);calls=[x for x in ob['calls']if x['session']==f['session']];assert f['expressions']==[x['expression']for x in calls] and len(f['expected'])==len(calls)
 physical=Path(c['workspace'])/c['operations'][0][0];assert f['source'].encode()==read(physical) and f['uri']==c['sourceUri'] and f['moduleName']=='main'
 events_for_process=reconstructed.setdefault((group,case,f['repeat']),bytearray())
 for expected,call in zip(f['expected'],calls):
  stem=root/call['rawPrefix'];raw={s:read(str(stem)+'.'+s)for s in suffixes};assert raw['status.bin']==call['status'].encode();status={'success\n':'success','error\n':'error'}[call['status']];assert expected['status']==status
  for ch in ['stdout','stderr']:
   units=raw[ch+'.code-units.bin'];assert len(units)%2==0 and expected[ch+'Units']==list(struct.unpack('>'+'H'*(len(units)//2),units)) and expected[ch+'Hex']==raw[ch+'.bin'].hex();assert units.decode('utf-16-be','surrogatepass').encode('utf-8','replace')==raw[ch+'.bin']
  target='stdout'if status=='success'else'stderr';other='stderr'if target=='stdout'else'stdout';assert raw[target+'.bin'].hex()==call['utf8Hex'] and raw[target+'.code-units.bin'].hex()==call['utf16BEHex'] and raw[other+'.bin']==raw[other+'.code-units.bin']==b''
  assert raw['expression.bin']==call['expression'].encode() and raw['error-class.bin']==call['errorClass'].encode()
  counters=[]
  for phase,key in [('before','countersBefore'),('after','countersAfter')]:
   assert raw['counters-'+phase+'.bin']==call[key].encode();values=dict(x.split('=',1)for x in call[key].splitlines());assert raw['reads-'+phase+'.bin']==values['read'].encode() and expected['reads'+phase.title()]==int(values['read']);counters.append(values)
  events=[read(stem.parent/('event-'+str(i)+'.bin')).decode()for i in range(int(counters[0]['event']),int(counters[1]['event']))];assert expected['javaEvents']==events;events_for_process.extend(b''.join(x.encode()+b'\n'for x in events))
  inside=[];outside=[]
  for event in events:
   admission=event in {'policy-resolve-module '+f['uri'],'policy-resolve-module repl:text','secure-path '+f['uri']+' resource=false'} or(group=='capability'and event in {'resolve '+f['uri'],'resolve repl:text'})
   api=bool(re.fullmatch(r'outer-\d+ (success|error org\.pkl\.core\.PklException)',event))
   if admission or api:outside.append(event)
   else:assert event.startswith(('policy-resolve-module ','policy-import ','policy-read-resource ','actual-file-reader ','actual-module-denied ','actual-resource-denied ','secure-path '));inside.append(event)
  assert expected['observableEvents']==inside and [x['event']for x in expected['outsideContract']]==outside;projected+=len(inside);count+=1
 seen_keys=set()
 for p in f['moduleProviders']:
  request=p['request'];assert set(request)==set(keys[request['kind']]);key=json.dumps(request,sort_keys=True);assert key not in seen_keys;seen_keys.add(key)
 providers+=len(f['moduleProviders'])
 for p in f['readProviders']:
  if p['result']['kind']=='security-manager-exception':assert p['countedReader'] is False and all(x['uri']!=p['uri']for x in f['readerPlan']);denials+=1
  else:assert p['countedReader'] is True
 assert len(f['readerPlan'])==int(calls[-1]['countersAfter'].split('read=')[1].split('\n',1)[0])
for (g,c,repeat),events in reconstructed.items():
 record=next(r for r in reports[g]['records']if r['case']==c and r['repeat']==repeat);assert hashlib.sha256(events).hexdigest()==record['result']['sha256']['stdout'] and record['result']['exit_code']==0
assert count==252 and projected==740 and providers==960 and denials==4
terminal=load(B/'tests-01.terminal.json');launch=load(B/'tests-01.launch.json');assert terminal['exitCode']==report['testsExitCode']==0 and terminal['pid']==launch['pid'];assert re.search(rb'Ran 11 tests in [0-9.]+s\n\nOK\n\Z',(B/'tests-01.stderr.bin').read_bytes())
assert all(sha(B/'workspace'/p)==d for p,d in source.items()) and sha(F/'manifest.json')==report['fixtureManifestSha256']
result={'schema':1,'scope':'Read-only independent review of sealed Java-only ModuleKey portable fixture/tooling; no new unit, oracle, Rust, Node or browser execution.','producer':{'reportSha256':sha(B/'report.json'),'closureSha256':sha(B/'closure.json'),'handoffSha256':sha(B/'handoff.json'),'sealedPayloadsVerified':338},'toolSources':source,'fixture':{'manifestSha256':sha(F/'manifest.json'),'payloadFiles':321,'actualRegularFilesIncludingManifest':322,'sessions':24,'apiRawCallsIndependentlyJoined':count,'allJavaApiCalls':300,'unselectedJavaApiCalls':48,'unorderedProviderFacts':providers,'orderedJavaObservableEvents':projected,'wholeJavaProcessEventStreamsReconstructed':len(reconstructed),'denyResourceProviderFactsCountedReaderFalse':denials},'existingUnitTests':{'count':11,'exitCode':0,'forgeryCases':9,'rawTerminalSha256':sha(B/'tests-01.terminal.json')},'findings':[],'sourceReview':['Provider capabilities/hasElement facts are explicitly source/input-derived reusable lookups, not observed Java SPI request ordering/counts; no full-consumption assertion is claimed.','Exact original Java policy/import/resource event strings are separately projected and retained with every excluded source-admission/API-status event and reason; all per-case two-session original stdout streams are reconstructed against independently pinned process stdout hashes.','Status and both complete output byte/code-unit channels, exact read counters and source/expression/error-class identity bind directly to fixed original Java reports; opposite output channel emptiness is checked.','Typed resource security denial precedes reader invocation: countedReader=false and no readerPlan consumption. Actual read requests remain a separate native/JS observation.','Denial-cause text is derived from pinned Java JAR error-message templates and deniedURI, with full Java diagnostic prefix confirmation; separate original bare exception message capture is explicitly not claimed.','Missing existence uses the captured File graph and observed search continuation; FileResolver source is pinned, but Files.exists calls themselves were not instrumented. Source .pkl symlinks require separate identity evidence and are rejected.','Historical triple-dot inventory/closure nulls are preserved; logical/capability seal hashes remain independently fixed.','Canonical authenticated content-hash blob paths and exact semantic/actual file coverage precede any directory descent; forged cache path regression spies on scandir.'],'qualifications':['321 is payload count; actual regular files are322 including manifest.','252 selected calls are not a full ModuleKey/File/SPI compatibility denominator. Other File/order432 APIs (including16 constructor-boundary calls) and logical48 remain separate.','Root reports actual C05 Node/browser252 exploratory results separately; this producer receipt establishes Java-derived fixture integrity and does not itself execute those targets.','Historical browser executable exact-binary provenance gap remains separately qualified; no fixture or raw outcome was rewritten to repair it.'],'originalSourceAndFixtureChanges':[],'seconds':time.time()-start}
(OUT/'report.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'report':str(OUT/'report.json'),'sha256':sha(OUT/'report.json'),'apiCalls':count,'observableEvents':projected,'seconds':result['seconds']}),flush=True)
