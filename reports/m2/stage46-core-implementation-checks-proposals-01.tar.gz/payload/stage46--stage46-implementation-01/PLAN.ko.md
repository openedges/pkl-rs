# Stage46 Resource·원본 read 구현 계획

이 문서는 구현 전 설계이다. 생산 소스·Git·고정 참조를 수정하지 않았고 새 Java/Rust 실행 결과를 만들지 않았다. Root가 Stage45를 커밋한 뒤 지정하는 새 실제 worktree에서 구현한다. 아래 소스 해석은 pinned Pkl 0.32.0의 구현 근거이며, 실행 호환성은 새 원시 비교로 판정한다. rev1은 구현 아이디어와 실패 위험을 찾는 참고 자료일 뿐 검증 근거가 아니다.

## 종료조건과 원본 계약

우선 종료조건은 `pkl:language-snippet:pkl-core/src/test/files/LanguageSnippetTests/input/basic/read.pkl` **전체 원본**의 실제 module output 비교 통과이다. 현재 inventory의 `language-module-eval`, `ready`, `required=true`, `expected_exit=[0]`를 유지한다. 입력 SHA256은 `9af0950aaaa9057093659b97105e69231dc3d55f09d3bc7710cbe2b7ab5fb001`이다. 원본 case·registry·repo resource-set은 함께 보존한 JSON에 있다.

- 원래 `eval --no-cache --no-project --settings pkl:settings`와 모든 `--property`, `--env-var`, 마지막 원본 입력 경로를 유지한다. `--no-cache`를 evaluator 내부 ResourceManager 캐시 제거 옵션으로 해석하지 않는다.
- 같은 준비된 physical workspace, `cwd="."`, 기록된 process 환경과 CLI override를 사용한다. env/property map을 합성 예제용 값으로 치환하지 않는다.
- `stdout`, `stderr`, `exit_code`, 생성 파일 경로·바이트 및 예상하지 않은 workspace 변경을 전부 비교한다. Java가 원래 성공 조건을 만족해야 한다. 같은 setup 오류로 끝난 두 실행을 통과로 세지 않는다.
- `output/basic/read.pcf`의 `$snippetsDir` 치환된 upstream golden은 provenance-only이다. 실제 pinned Java 출력과 원시 비교하며 경로 치환·trim·정렬·재직렬화를 하지 않는다.
- 독립한 fresh Java/native process 두 반복에서 실제 `output.bytes` 전체를 비교한다. focused 취득은 원본 case 1개이며 2개 case로 늘리지 않는다. 새 focused wrapper가 필요하면 기존 `m2_module_eval.acquire_case`/검증 함수를 사용하고, 원본 selection이나 기대값을 수정하지 않는다. 현재 CLI에 없는 `--case` 옵션을 사용 가능한 기능으로 문서화하지 않는다.
- native 통과 뒤 동일 공유 소스/artifact의 실제 Node와 Chromium에서 전체 원본 모듈·import graph·Resource payload를 VFS Host로 실행한다. 논리 URI를 Java에 쓴 URI와 맞추고 전체 출력 bytes를 비교한다. 이 경계는 POSIX process argv/cwd 검증을 대신하지 않는다.

`read.pkl`의 7개 examples 그룹은 env, prop, file, triple-dot file, 금지된 scheme, 동적 URI 함수, 같은 상대 URI를 쓰는 서로 다른 선언 모듈이다. 일부 그룹만 성공시키거나 `resource.text` 같은 축약된 표현식으로 전체 원본을 대체하지 않는다.

## 반드시 함께 여는 의존성

| 원본 경로/동작 | 필요한 실제 동작 | 현재 확인한 장벽 |
| --- | --- | --- |
| `input/snippetTest.pkl` → `pkl:test` | 실제 source-backed 상속·catch·PCF 출력 | Stage45 기반 유지 및 회귀 검증 |
| `input/basic/globtest/file1.txt`, `file2.txt` | 파일 bytes를 실제 `Resource`로 반환 | 기본 Host가 allowed file 읽기를 Unsupported로 반환 |
| `.../input-helper/basic/read/resource.txt` | 선언 ModuleKey 기준 상위 탐색 | URI 단계가 triple-dot을 거부 |
| `.../input-helper/basic/read/module1.pkl`, `child/module2.pkl` | triple-dot **import**와 공유 module cache | `prepare_module_uri`도 triple-dot을 거부 |
| 두 helper의 `normalRead = read("resource.txt")` | 각 helper 원래 ModuleKey URI 기준 resolve | canonical resolved file key와 선언 URI를 혼동하면 두 내용이 합쳐짐 |
| 두 helper의 `globbedRead = read*("*.txt")` | 원본의 미강제 선언을 파싱·보존 | 현재 parser는 `read` 다음 `(`를 요구한다. 원본에서 이 멤버는 강제하지 않지만 helper 전체 parse는 필요 |
| Resource의 PCF `uri`, `text`, `base64` | 같은 `pkl.base#Resource` 클래스, 일반 member/renderer 경로 | 현재 공유 runtime에 Resource 구성과 Bytes.base64 binding이 없음 |

helper의 `globbedRead` 줄을 지우거나 source rewrite로 우회하지 않는다. read*의 실제 syntax/AST·operand·source span을 보존하고 lazy declaration으로 컴파일한다. Stage46에서 아직 force를 구현하지 못한 glob은 강제 시 명시적 Unsupported로 남긴다. 이를 glob 구현 완료로 세지 않으며 원래 `basic/readGlob.pkl` 및 다른 glob 의무를 유지한다. 원본 read 성공을 위해 강제되지 않는 선언의 parse와 실제 glob expansion은 구분한다.

## pinned Java가 정하는 순서와 수명

`AbstractReadNode.doRead`는 operand 문자열을 `IoUtils.toUri`로 parse하고 **현재 선언의 ModuleKey**를 통해 `IoUtils.resolve`한 다음 `VmContext.getResourceManager().read`를 호출한다. resolve 이후에도 absolute가 아니면 오류이다. `read?`도 같은 resolve 단계의 오류를 통과시키며, 최종 reader가 `Optional.empty()`를 반환한 경우만 null이다.

`ResourceManager.read`의 cache는 `Map<URI, Optional<Object>>`이고 `resourceUri.normalize()`를 key로 쓴다. `computeIfAbsent` 안에서 reader 선택, 적용되는 security check, reader call, Resource→VmTyped 변환을 수행한다. String, Resource, absence는 보관하고 reader/resolve/security 예외는 보관하지 않는다. absence를 캐시한 뒤 ordinary read가 만드는 `Cannot find resource`는 각 호출의 authored URI·현재 frame을 사용해야 한다. 오류 객체 자체를 negative cache에 넣으면 다른 철자의 호출에 첫 오류 URI/frame이 새어 나온다.

cache hit에서 read security check나 reader call을 다시 하지 않는다. 반면 ModuleKey resolve/triple-dot 탐색은 ResourceManager보다 앞이므로 이를 resource cache와 합치면 안 된다. getResourceReader는 nullable이고 no-reader 오류보다 default security 거절이 먼저 관찰될 수 있다. HTTP(S)는 HttpClient에 check를 위임하는 별도 순서를 유지한다. 새로운 implementation이 모든 custom Host에 scalar default policy를 덮어씌우지 않도록 한다.

`EvaluatorImpl`은 자신의 VmContext 초기화 때 ResourceManager를 한 번 만든다. 같은 evaluator의 다른 expression, 실패 후 다음 call, 다른 ModuleSource root에서도 같은 cache를 사용하며, 새 evaluator는 별개이다. CLI `--no-cache`나 module compiled-code cache와 수명을 혼동하지 않는다. close/timeout 같은 terminal 종료 때 heap와 cache를 함께 해제한다. 정상 call 종료·guest catch·실패한 lazy member 재시도는 이미 게시된 resource cache를 지우지 않는다.

정확한 Java `URI.equals/hashCode`의 scheme/escape/authority 경계는 B 관찰로 확정한다. 파일 physical canonicalization, percent decoding 또는 authored 문자열을 임의로 cache key로 쓰지 않는다. `normalize`와 `resolve`도 분리한다. URI의 원래 표시 철자, 정규화 key, reader가 반환한 `Resource.uri`는 세 가지 역할이며 서로 치환하지 않는다.

## 공유 엔진 변경 설계

1. **typed resource 완료 모델.** `ReadRequest`의 authored URI·declaration ModuleKey·nullable을 유지한다. 명시적인 `Missing`, `Text(PklString)`, `Resource { uri, bytes }`와 typed 실패를 표현한다. legacy `resume(Value)`의 arbitrary Host completion을 absence나 Java ResourceReader 예외로 추정하지 않는다. `Null` 값을 반환한 raw callback을 자동으로 `Optional.empty`로 바꾸지 않는다. transport invalid stage/type/token은 state·cache를 소비하기 전에 거부한다.
2. **VM 소유 ResourceManager.** 공유 VM에 normalized URI key→Missing 또는 Value cache를 둔다. 값은 현재 evaluator heap에만 속한다. 성공/absence를 검증한 뒤 게시하고 오류는 게시하지 않는다. module source-error cache와 별개 타입으로 둔다. root 변경·callback reentry에서도 같은 owner를 쓰되 compiled Program/static OnceLock에 ObjectId를 넣지 않는다.
3. **root/evaluator 경계.** 현재 SourceSession은 한 primary module을 중심으로 VM을 유지한다. 그 session의 반복 call·imported module은 즉시 같은 cache를 검증할 수 있다. 같은 Java evaluator의 독립 ModuleSource 교체를 검증하려면 현재 VM/heap를 유지한 채 새 unit/root를 준비하는 명시적인 내부 진입점을 추가하거나 추후 evaluator facade로 분리해야 한다. 새 SourceProbe를 만드는 대조군을 같은-evaluator 검증으로 세지 않는다. 이 API 의무는 원본 read 통과와 별도 상태로 기록한다.
4. **GC와 terminal 정리.** cached Resource ObjectId를 traced root 집합에 포함한다. heap 제한 검사와 재진입 중 임시 payload/Resource construction roots도 포함한다. close는 cache·pending continuation·bytes 보관을 해제하고 stale completion을 거부한다. ordinary failure는 성공 값과 absence를 유지한다. 같은 VM의 suspended contexts 사이에도 cache를 공유한다.
5. **실제 Resource 클래스.** 기존 source-backed builtin/class registry에 pinned base Resource 선언을 연결한다. factory가 uri/text/bytes를 제공하며 base64와 hidden bytes는 일반 member·클래스 관계를 유지한다. PCF가 hidden bytes를 출력하지 않고 uri,text,base64를 원래 순서로 강제하도록 기존 renderer를 사용한다. `Resource`, `b.Resource`, reader 결과의 `getClass`/type check가 같은 canonical class를 가리켜야 한다. plain Dynamic 세 필드 또는 미리 만든 PCF 문자열로 대신하지 않는다.
6. **bytes/text 변환.** 원본 bytes를 불변 buffer로 보존하고 Bytes.base64를 공유 primitive로 구현한다. Resource.text는 Java `new String(bytes, UTF_8)`와 같은 replacement 경계를 검증한다. Rust `from_utf8_lossy`를 검증 없이 동등하다고 단정하지 않는다. Resource 직접 생성·amend·제약/undefined force도 기존 lazy semantics를 따른다. cryptographic 속성 등 아직 force하지 않은 별도 의무를 fake value로 채우지 않는다.
7. **Host I/O.** native 예제 Host는 file bytes와 존재 여부를 제공하고 공유 runtime이 URI·nullable·cache·Resource 구성·diagnostic을 소유한다. `evaluate_module_output_with_host`의 현재 module-only callback 외에 typed resource capability를 전달하는 경로가 필요하다. Node/Wasm에는 같은 request/completion을 연결하고 VFS가 파일 payload를 제공한다. production VM에 `std::fs`·process env·Java fallback을 추가하지 않는다.
8. **오류 provenance.** resource IOException은 기존 `ReadFailure`/canonical PklString을 재사용하고 `SecurityManagerException`, URI 오류 등 필요한 typed 원인을 명시적으로 확장한다. raw Denied/Host reject/logger failure/timeout/close는 기존 bypass를 유지한다. triple-dot module-existence 실패와 실제 reader 실패의 진단 producer/원래 문자열/frame 차이를 합치지 않는다.

## triple-dot와 ModuleKey capability

`IoUtils.resolveTripleDotImport`는 local+hierarchical ModuleKey만 허용하고 현재 모듈이 들어 있는 디렉터리의 **부모 디렉터리부터** 더 상위로 진행한다. 현재 module 자신의 경로는 제외하고 root 후보까지 확인한다. `...`는 현재 파일 이름을 검색하며 `.../` 또는 `...x` 같은 잘못된 문법은 별도 오류이다. fragment-path reader의 경로 규칙과 triple-slash URI 보존도 명시적인 의무이다.

실제 존재 확인은 **current ModuleKey.hasElement**를 사용한다. 기본 file ModuleKey는 `checkResolveModule`을 호출한다. ResourceReader.hasElement의 `checkResolveResource`로 바꾸면 security 오류 종류·순서가 달라진다. shared resolver가 후보 순서를 계산하고 Host는 해당 module capability의 존재 확인/정책 결과를 typed 완료로 제공하는 구조를 권고한다. file path만 하드코딩하여 일반 resolver 전체가 지원된 것처럼 표시하지 않는다.

ModuleIdentity에 현재 URI 두 개만 있으므로 local/hierarchical/fragment-path capability를 표현할 위치도 필요하다. module import와 resource read에서 같은 resolver state machine을 사용하고 목적별 오류 wrapping만 분리한다. 후보 탐색은 async Host suspension·cancel·stale-token·reentry를 따라야 한다. source preparation의 eager URI 문법검사와 실제 import/read를 강제할 때의 존재 탐색을 구분한다.

## rev1에서 참고할 것과 복사하지 않을 것

rev1의 `bytecode_read.rs`, `bytecode_uri.rs`, `eval_import.rs`는 파일/relative/triple-dot 처리와 Resource 조립 위치를 찾는 참고 자료이다. standalone bytecode와 treewalker에 구현이 나뉘며 fallback도 존재하므로 이번 shared VM 경계에 그대로 이식하지 않는다.

- `eval_import.rs`는 null을 cache에 넣지 않는다. pinned 0.32 ResourceManager의 absence cache와 다르다.
- rev1 resource key는 env/prop을 percent decode하고 file path를 canonicalize한다. Java normalized URI key와 동등하다고 가정할 수 없다.
- rev1 custom reader와 triple-dot 경로는 일부 오류를 read? null로 바꾸는 분기가 있다. Java의 resolve 실패와 Optional.empty 경계를 대신하지 못한다.
- rev1 Resource factory는 새 class를 만들고 text/base64/hash를 일찍 계산한다. 현재 source-backed class identity·lazy property 순서의 근거로 사용할 수 없다.
- rev1 `clear_user_module_cache`는 resource cache도 지운다. Java의 evaluator 수명 cache를 root/call마다 초기화하는 설계 근거가 아니다.
- rev1 passing test·golden·0.31 기준 설명은 이 프로젝트의 Pkl 0.32 결과가 아니다.

## 구현·검증 순서

1. 새 실제 Stage46 worktree와 exact source manifest를 고정한다. Stage45 원본 증거를 보존하고 기존 전체 read 입력의 baseline을 새 focused 출력에 취득한다. 첫 실패가 compile/triple-dot/Resource 중 무엇인지 실제 결과로 기록한다.
2. B의 P0 관찰로 cache key·absence·failure retry·Resource class/bytes·triple-dot ordering을 확정한다. 기존 Java 자료가 이미 같은 경계를 검증했다면 재취득 없이 exact provenance를 연결한다.
3. read* 원본문법 보존, shared typed resource 모델, Resource class/Bytes.base64를 구현한다. whole read가 요구하는 기능 단위 순서로 진행하며 합성 test 통과만으로 완료하지 않는다.
4. normalized URI cache와 typed String/Resource/Missing completion을 연결한다. 정상/guest error/Host error/terminal/GC/reentry 경계를 검증한다. Java ResourceManager의 callback computeIfAbsent 중 CME 같은 internal boundary는 ordinary compatibility로 바꾸지 않는다.
5. module/read 공용 triple-dot capability와 native file Host를 연결하고 untouched helper imports까지 실행한다. 기존 module original/resolved URI 및 source-error cache 회귀를 확인한다.
6. 전체 원본 read를 두 번 raw 비교하고 모든 실패와 수정 전 후보를 보존한다. Java env/prop/String, file Resource, imported relative resource 결과가 모두 같은 output.bytes 안에서 통과해야 한다.
7. 관련 원본 `errors/invalidTripleDotSyntax1.pkl`, `errors/invalidTripleDotSyntax2.pkl`, URI 오류 및 module cases와 기존 resource/guest-catch/typed-security/Host lifecycle fixture를 검증한다. 이 두 원본 syntax 사례는 현재 adapter가 없으므로 원래 전체 계약의 adapter를 연결하기 전에는 실행했다고 세지 않는다. 구체 case ID/state는 보존한 `related-obligations.json`에서 선택하고 기대값을 유지한다. `basic/readGlob.pkl`의 HTTP/TLS 등 기존 차단 조건과 forced glob 미지원도 그대로 남긴다.
8. 필수 Rust5, 관련 Python freshness/fixture tests, 새 출력의 실제 `tools/m1_platforms.py --verify-contract`, 실제 Node/Chromium typed resource 및 전체 원본 read를 실행한다. 기존 2 regex mismatch와 Java internal/unexecuted API 경계는 유지한다. 플랫폼 source collector는 `include_str!` payload `stdlib/modules.txt`도 포함해야 한다.
9. bootstrap 600 호출은 독립된 후속 회귀로 재비교한다. property resource read-count 개선을 측정하되 test module의 JVM 전역 cache 문제가 해결되었다고 가정하지 않는다. Stage45의 166 counter-only 차이 전부가 evaluator cache만으로 사라진다고 미리 약속하지 않는다.
10. source freeze 뒤 root 독립 검토·실제 source/artifact binding·증거 게시를 거친다. Stage46 종료는 이 구현 경계와 원본 read 의무의 종료이며 M2·전체 Resource API·전체 URI/HTTP/package/glob·성능 완료가 아니다.

## 별도로 유지할 미해결 경계

Java와 Rust의 unmatched-surrogate URI 입력, 전체 URI parser/authority/Windows file 규칙, rootDir·symlink 보안 정책, 모든 custom reader 설정, HTTP/package/modulepath/glob, 독립 root public evaluator API, cross-evaluator JVM stdlib cache, JSON/reflection, 성능은 각각 상태를 유지한다. 원본 read에 필요한 기능이 이 목록과 겹치면 원본을 줄이는 대신 필요한 의존성을 구현한다. 범위를 넓히기만 하는 selected fixture 추가보다 현재 원본 실패 감소를 먼저 측정한다.
