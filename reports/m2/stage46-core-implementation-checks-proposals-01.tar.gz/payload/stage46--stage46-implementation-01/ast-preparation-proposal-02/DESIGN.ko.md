# AST 구축 효과와 정적 실패의 공통 순서

실제 평가 resolver의 한 번의 Work 방문이 Import(원문 URI, span, owner)를 기록한다. parser syntax 오류는 전체 parse 장벽이고, deferred 숫자 오류는 해당 expression 방문에서 반환한다. resolver의 첫 오류가 반환되면 이전 Import 기록과 structured Diagnostic을 가진 실패 전용 initializer만 컴파일한다. 불완전한 binding으로 guest 멤버를 설치하거나 실행하지 않는다. 공유 VM은 각 occurrence의 URI 준비를 수행한 뒤 실패를 반환하며, 이전 ModuleKey 실패는 뒤 정적 오류보다 앞선다.

module modifier → import clauses → annotation → parent → import duplicate checks → class/typealias/property/method 순서를 사용한다. import clause owner는 비어 있다. class property/type와 method, let type/value/body, when branches/predicate, for type/iterable/body는 기존 resolver Work의 producer 단계다. specialized object는 member body 완료 후 duplicate check를 하고 generator를 만나면 prefix의 실제 방문을 보존한 채 전체 generator body를 다시 방문한다. owner 수집은 evaluation에서 항상 켜며 legacy diagnostic replay와 실행 계획을 합치지 않는다.

이동한 컴파일 경계: Map 홀수 인자 검증은 인자 AST 방문 이후 continuation으로 옮겼다. ImportSpec는 원문을 보존하고 URI 검증은 각 preparation occurrence에서 한다. AND/OR/?? AST 방문은 pinned AstBuilder의 right/left 순서이며 bytecode runtime short-circuit 순서는 바꾸지 않는다. API query AST의 deferred 오류도 해당 query entry에만 속하며 요청되지 않은 query는 효과를 수행하지 않는다.

유지한 경계: class/object property type의 initialization_error, alias/type resolution은 기존 runtime initialization에 둔다. compiler의 일반 Type 오류를 span만으로 AST failure로 hoist하지 않는다. generic methods/classes, builtin value 등의 Unsupported 및 내부 invariant는 기존 명시적 비지원/내부 실패다. 현재 모든 compiler producer의 실제 Java 경계를 닫았다는 주장은 하지 않는다. 알려진 실제 numeric/parse order96과 File216, 신규 duplicate/Map/modifier/generator/binary controls를 새 후보로 비교해야 한다.

아직 C04는 발행하지 않았다. runtime 전체 회귀가 진행 중이며 이 snapshot은 review용이다.
