"""Independently inspect the sealed Stage45 selected-regression publication."""
import hashlib,json,subprocess,tarfile,time
from collections import Counter,defaultdict
from pathlib import Path
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
BASE=ROOT.parent/'pkl-rs.stage45/target/m2'
OUT=ROOT/'target/m2/stage45-final-publication-review-01'
PUB=ROOT/'target/m2/stage45-final-publication-01'
COMMIT='01971d0c0a231132bcb30a7dae6ac244b7fed953'
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def load(p):return json.loads(p.read_bytes())
def safe(n):
 p=Path(n);assert n and not p.is_absolute() and '..' not in p.parts,n
 return p
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
start=time.time();summary_path=ROOT/'reports/m2/stage45-final-summary.json';summary=load(summary_path)
assert digest(summary_path)=='91c855ed5225e4139b754be6f849d560d57b93ae476a4857c6982ec503869b42'
index_path=ROOT/summary['captures']['path'];index=load(index_path);assert digest(index_path)==summary['captures']['sha256']
selection_path=PUB/'selection.json';assert digest(selection_path)==index['selection_sha256'];selection=load(selection_path)
rows={r['path']:r for r in selection['files']};assert len(rows)==len(selection['files'])
rows['publication/selection.json']={'source':str(selection_path),'path':'publication/selection.json','sha256':digest(selection_path),'bytes':selection_path.stat().st_size}
assert len(rows)==index['payload_files']==62130 and sum(r['bytes'] for r in rows.values())==index['payload_bytes']
for n,r in rows.items():
 safe(n);p=Path(r['source']);assert p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and digest(p)==r['sha256'],n
print('Verified original selection',len(rows),flush=True)
seen=set();archives=[]
for ar in index['archives']:
 p=ROOT/safe(ar['path']);assert digest(p)==ar['sha256'] and p.stat().st_size==ar['compressed_bytes']<48*1024*1024
 with tarfile.open(p,'r:gz') as t:
  members=t.getmembers();names=[m.name for m in members];assert len(names)==len(set(names))
  by={m.name:m for m in members};assert 'EVIDENCE.json' in by
  inv=json.load(t.extractfile(by['EVIDENCE.json']));assert inv['schema_version']==1 and inv['excluded_patterns']==[]
  entries={r['path']:r for r in inv['files']};assert len(entries)==len(inv['files']) and set(entries)==set(names)-{'EVIDENCE.json'}
  assert len(entries)==ar['payload_files'] and sum(r['bytes'] for r in entries.values())==ar['payload_bytes']
  for m in members:
   safe(m.name);assert m.isfile() and m.mode==0o644 and m.mtime==0,m.name
  for n,r in entries.items():
   assert n in rows and n not in seen,n;expected=rows[n]
   assert r['bytes']==expected['bytes'] and r['sha256']==expected['sha256'],n
   body=t.extractfile(by[n]).read();assert len(body)==r['bytes'] and hashlib.sha256(body).hexdigest()==r['sha256'],n
   seen.add(n)
 archives.append({'path':ar['path'],'sha256':ar['sha256'],'payloadFiles':len(entries),'rawBytes':ar['payload_bytes'],'compressedBytes':p.stat().st_size})
 print('Verified archive',ar['path'],len(entries),flush=True)
assert seen==set(rows)
audit_dir=BASE/'stage45-final-audit-01';audit=load(audit_dir/'report.json')
copy_names={'audit':'report.json','source_map':'source-map.json','case_changes':'case-changes.json','status_changes_record':'status-changes.json','raw_changes':'raw-changes.json'}
for k,n in copy_names.items():
 p=ROOT/summary[k]['path'];assert digest(p)==summary[k]['sha256']==digest(audit_dir/n)
lang_dir=BASE/'stage45-language-final-01';life_dir=BASE/'stage45-class-lifecycle-final-01';lang=load(lang_dir/'report.json');life=load(life_dir/'report.json')
assert summary['implementation_commit']==audit['implementation_commit']==COMMIT
assert all(not summary[k] for k in ['full_m2_complete','compatibility_complete','hosted_ci_claimed','performance_target_claimed'])
assert summary['selected']==lang['selected_count']==3664 and summary['status_counts']==lang['status_counts']=={'pass':3647,'candidate-unsupported':7,'mismatch':9,'oracle-error':1}
nonpass=[{'id':x['id'],'status':x['status']} for x in lang['results'] if x['status']!='pass'];assert summary['failures']==nonpass and summary['current_nonpass_cases']==len(nonpass)==17
changes=load(audit_dir/'status-changes.json');assert summary['historical_nonpass_comparison_union']==len(changes['all_old_or_new_nonpass'])==24 and 'union' in summary['audit_field_qualification']
assert summary['status_changes']==changes['transitions'] and len(changes['transitions'])==7 and all(x['after']=='pass' and x['before']!='pass' for x in changes['transitions'])
cases=load(audit_dir/'case-changes.json');assert len(cases)==1 and cases==summary['case_mapping_changes'] and cases[0]['fields']==['adapter','execution','execution_profile']
assert cases[0]['before']['upstream_case']==cases[0]['after']['upstream_case'] and cases[0]['before']['input_sha256']==cases[0]['after']['input_sha256']
assert summary['full_gate_failure_reasons']==len(lang['full_gate_failures'])==1830
assert summary['metamorphic_relations']==len(lang['metamorphic_results'])==88 and summary['metamorphic_matches']==88 and all(x['status']=='pass' for x in lang['metamorphic_results'])
assert summary['gates']==audit['gates'] and [summary['gates'][k] for k in ['language-verify-development','language-verify-subset','language-verify-full']]==[1,1,1]
assert summary['persistent']==audit['lifecycle'] and summary['persistent']['sequences']==334 and summary['persistent']['calls_each_language']==2782 and summary['persistent']['raw_mismatches']==[]
assert summary['persistent']['comparison_channels']==['status','stdout','stderr'] and summary['persistent']['error_class_differences_retained_excluded_from_equality']==928
assert summary['unexecuted_lifecycle_groups']==life['unexecuted_groups'] and summary['raw_reports']=={'language':digest(lang_dir/'report.json'),'lifecycle':digest(life_dir/'report.json')}
assert summary['source_binding']==audit['source_binding'] and summary['source_binding']['lifecycle_config_directly_captured'] is False
terminal=load(BASE/'stage45-full-regression-01/outer-terminal.json');execution=load(BASE/'stage45-final-audit-execution-01/report.json')
assert terminal['exit_code']==summary['wrapper_exit_code']==0 and execution['exit_code']==0 and execution['audit_source_sha256']==digest(audit_dir/'audit.py')
for ch in ['stdout','stderr']:assert digest(BASE/'stage45-final-audit-execution-01'/(ch+'.bin'))==execution[ch+'_sha256']
source_map=load(ROOT/summary['source_map']['path']);captured=defaultdict(dict)
for name,sha in lang['source_sha256'].items():captured[name]['language']=sha
for r in life['sources']:captured[r['path']]['lifecycle']=r['sha256']
assert set(captured)==set(source_map) and len(source_map)==4166 and sum(map(len,captured.values()))==4362
repos={str(ROOT):COMMIT}
for prefix,pin in summary['references'].items():repos[str(ROOT/prefix)]=pin
objects=defaultdict(dict);trees={}
for repo,pin in repos.items():
 out=subprocess.run(['git','-C',repo,'ls-tree','-rz',pin],check=True,stdout=subprocess.PIPE).stdout;tree={}
 for line in out.split(b'\0'):
  if not line:continue
  meta,path=line.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[path.decode()]=(mode,kind,oid)
 trees[repo]=tree
for name,r in source_map.items():
 prefix=next((x for x in summary['references'] if name.startswith(x+'/')),None)
 repo=str(ROOT/prefix) if prefix else str(ROOT);rel=name[len(prefix)+1:] if prefix else name
 assert trees[repo][rel]==(r['mode'],'blob',r['git_blob']) and r['commit']==repos[repo],name
 assert set(captured[name])==set(r['capture_scopes']) and set(captured[name].values())=={r['sha256']},name
 objects[repo][r['git_blob']]=r['sha256']
for repo,ids in objects.items():
 raw=subprocess.run(['git','-C',repo,'cat-file','--batch'],input=('\n'.join(ids)+'\n').encode(),check=True,stdout=subprocess.PIPE).stdout;cursor=0
 for oid,sha in ids.items():
  stop=raw.index(b'\n',cursor);got,kind,size=raw[cursor:stop].decode().split();size=int(size);cursor=stop+1
  assert got==oid and kind=='blob';body=raw[cursor:cursor+size];assert hashlib.sha256(body).hexdigest()==sha;cursor+=size+1
 assert cursor==len(raw)
print('Verified Git source blobs',len(source_map),flush=True)
docs={}
for n in ['README.md','PLAN.md','reports/m2/README.md']:
 p=ROOT/n;docs[n]={'sha256':digest(p),'bytes':p.stat().st_size}
 text=p.read_text();assert 'stage45-final-summary.json' in text and '01971d0' in text,n
 assert '3,647' in text and '3,664' in text,n
for n,r in rows.items():assert digest(Path(r['source']))==r['sha256'] and Path(r['source']).stat().st_size==r['bytes'],n
result={'schema':1,'scope':'Independent read-only archive/index/summary/source/document review of completed Stage45 regression at01971d0; no build, Java/native acquisition, source/report/Git mutation.','summary':{'path':str(summary_path),'sha256':digest(summary_path)},'captures':{'path':str(index_path),'sha256':digest(index_path)},'selection':{'path':str(selection_path),'sha256':digest(selection_path)},'archives':archives,'payloadFiles':len(rows),'payloadBytes':sum(r['bytes'] for r in rows.values()),'archiveInventoryFilesAdditional':len(archives),'originalPayloadsAfterUnchanged':True,'uniqueSourceGitBlobsVerified':len(source_map),'capturedSourceRecords':4362,'sourceCommit':COMMIT,'currentNonpass':17,'historicalNonpassUnion':24,'metamorphicRawMatches':88,'persistentCallsEachLanguage':2782,'persistentSequences':334,'fullGateFailureReasons':1830,'documents':docs,'findings':[],'qualifications':['Original audit language.nonpass_rows=24 is explicitly the old/new comparison union; current nonpass=17. Original audit was preserved.','Lifecycle schema1 did not directly capture root.cargo/config.toml. Published source qualification correctly binds it separately and does not relabel later schema2 as the regression source.','Current MAIN7d20842 tooling and Stage46 work do not change the regression implementation commit01971d0.','Successful acquisition wrapper and archive integrity do not close failed strict gates, broader bootstrap/platform or performance obligations.'],'seconds':time.time()-start}
save(OUT/'report.json',result);print(json.dumps({'report':str(OUT/'report.json'),'sha256':digest(OUT/'report.json'),'payloadFiles':len(rows),'gitPaths':len(source_map),'seconds':result['seconds']}),flush=True)
