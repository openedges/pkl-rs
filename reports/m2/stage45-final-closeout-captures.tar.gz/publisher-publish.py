"""Publish terminal, independently audited Stage45 native regression evidence."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'tools'))
import evidence

BASE = ROOT.parent / 'pkl-rs.stage45/target/m2'
OUT = Path(__file__).resolve().parent
AUDIT = BASE / 'stage45-final-audit-01'
LANG = BASE / 'stage45-language-final-01'
LIFE = BASE / 'stage45-class-lifecycle-final-01'
WRAPPER = BASE / 'stage45-full-regression-01'
AUDIT_EXECUTION = BASE / 'stage45-final-audit-execution-01'
REPORTS = ROOT / 'reports/m2'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
load = lambda path: json.loads(path.read_bytes())
def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')
def safe(name):
    relative = Path(name)
    assert not relative.is_absolute() and '..' not in relative.parts, name
    return relative
def pointer(path):
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path)}

assert not (OUT / 'report.json').exists(), 'Preserve prior publication.'
audit = load(AUDIT / 'report.json')
driver = load(WRAPPER / 'process-report.json')
terminal = load(WRAPPER / 'outer-terminal.json')
assert driver['complete'] and not driver['infrastructureFailures']
assert terminal['exit_code'] == 0 and terminal['session_id'] == 86815
assert audit['wrapper_own_terminal']['sha256'] == sha(WRAPPER / 'outer-terminal.json')
assert audit['wrapper_own_terminal']['exit_code'] == 0
assert audit['implementation_commit'] == '01971d0c0a231132bcb30a7dae6ac244b7fed953'
assert audit['source_binding']['all_match_commit_blobs']
assert load(AUDIT_EXECUTION / 'report.json')['exit_code'] == 0
for entry in audit['output_pointers'].values():
    assert sha(Path(entry['path'])) == entry['sha256']
language, lifecycle = load(LANG / 'report.json'), load(LIFE / 'report.json')
for label, folder in [('language', LANG), ('lifecycle', LIFE)]:
    assert sha(folder / 'report.json') == audit[label]['report_sha256']

# Enumerate producer-declared payloads, not acquisition trees or Cargo caches.
selected = []
for label, folder, report in [('language', LANG, language), ('lifecycle', LIFE, lifecycle)]:
    for name, digest in report['evidence_sha256'].items():
        path = folder / safe(name)
        assert path.is_file() and not path.is_symlink() and sha(path) == digest, path
        selected.append((label + '/' + name, path))
    selected.append((label + '/report.json', folder / 'report.json'))
for label, folder in [('wrapper', WRAPPER), ('audit', AUDIT), ('audit-execution', AUDIT_EXECUTION)]:
    for current, dirs, files in os.walk(folder, followlinks=False):
        current = Path(current)
        assert all(not (current / name).is_symlink() for name in dirs)
        for name in files:
            path = current / name
            assert path.is_file() and not path.is_symlink(), path
            selected.append((label + '/' + path.relative_to(folder).as_posix(), path))
selected += [('publication/publish.py', Path(__file__)), ('publication/evidence.py', ROOT / 'tools/evidence.py')]
assert len({name for name, _ in selected}) == len(selected)
rows = [{'path': name, 'source': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        for name, path in sorted(selected)]
save(OUT / 'selection.json', {'scope': 'Explicit producer maps and dedicated wrapper/audit roots; acquisition/build trees are never walked. This selection omits its own row to avoid a circular hash; archive EVIDENCE.json includes it.', 'files': rows})
selection_path = OUT / 'selection.json'
rows.append({'path': 'publication/selection.json', 'source': str(selection_path),
             'bytes': selection_path.stat().st_size, 'sha256': sha(selection_path)})
partitions, current, size = [], [], 0
for row in rows:
    if current and size + row['bytes'] > 40 * 1024 * 1024:
        partitions.append(current); current, size = [], 0
    assert row['bytes'] < 48 * 1024 * 1024, row['source']
    current.append(row); size += row['bytes']
if current:
    partitions.append(current)
archives = []
for index, partition in enumerate(partitions, 1):
    gathering = OUT / f'part-{index:02d}'
    gathering.mkdir()
    for row in partition:
        source = Path(row['source'])
        assert sha(source) == row['sha256']
        destination = gathering / safe(row['path'])
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())
    destination = REPORTS / f'stage45-final-regression-{index:02d}.tar.gz'
    assert not destination.exists()
    evidence.create(gathering, destination, [])
    assert destination.stat().st_size < 48 * 1024 * 1024
    archives.append({**pointer(destination), 'compressed_bytes': destination.stat().st_size,
                     'payload_files': len(partition), 'payload_bytes': sum(row['bytes'] for row in partition)})
for row in rows:
    assert sha(Path(row['source'])) == row['sha256'], row['source']
index = {'schema': 1, 'scope': 'Completed Stage45 plus JVM-profile selected native/lifecycle regression; all compatibility failures and original raw records preserved.',
         'archives': archives, 'payload_files': len(rows), 'payload_bytes': sum(row['bytes'] for row in rows),
         'selection_sha256': sha(OUT / 'selection.json'), 'originals_unchanged': True,
         'cache_traversal': False, 'wrapper_exit_code': terminal['exit_code'], 'full_m2_complete': False}
capture_path = REPORTS / 'stage45-final-regression-captures.json'
assert not capture_path.exists()
save(capture_path, index)
copies = {}
for source, destination in [('report.json', 'stage45-final-regression-audit.json'),
                            ('source-map.json', 'stage45-final-source-map.json'),
                            ('status-changes.json', 'stage45-final-status-changes.json'),
                            ('case-changes.json', 'stage45-final-case-changes.json'),
                            ('raw-changes.json', 'stage45-final-raw-changes.json')]:
    target = REPORTS / destination
    assert not target.exists()
    target.write_bytes((AUDIT / source).read_bytes())
    copies[source] = pointer(target)
adapters = {}
case_adapters = {row['id']: row.get('adapter') for row in load(LANG / 'sources/compatibility/m2-language.json')['cases']}
for row in language['results']:
    assert case_adapters[row['id']]
    adapters.setdefault(case_adapters[row['id']], Counter())[row['status']] += 1
summary = {
    'schema': 1, 'scope': 'Complete selected native/lifecycle acquisition of Stage45 plus JVM execution profile at01971d0. Full M2, broader bootstrap/platform and performance obligations remain open.',
    'implementation_commit': audit['implementation_commit'], 'references': audit['pinned_references'],
    'selected_regression_acquisition_complete': True, 'wrapper_exit_code': terminal['exit_code'],
    'gates': audit['gates'], 'selected': language['selected_count'], 'status_counts': language['status_counts'],
    'inventory_counts': load(LANG / 'sources/compatibility/m2-language.json')['counts'],
    'selected_adapters': adapters, 'case_ids_and_order_preserved': 4527,
    'case_mapping_changes': load(AUDIT / 'case-changes.json'),
    'status_changes': load(AUDIT / 'status-changes.json')['transitions'],
    'failures': [{'id': row['id'], 'status': row['status']} for row in language['results'] if row['status'] != 'pass'],
    'current_nonpass_cases': sum(row['status'] != 'pass' for row in language['results']),
    'historical_nonpass_comparison_union': audit['language']['nonpass_rows'],
    'audit_field_qualification': 'The preserved audit language.nonpass_rows counts the union of Stage44 and Stage45 nonpassing case IDs (24), not current Stage45 failures (17).',
    'full_gate_failure_reasons': len(language['full_gate_failures']),
    'metamorphic_relations': len(language['metamorphic_results']),
    'metamorphic_matches': sum(row['status'] == 'pass' for row in language['metamorphic_results']),
    'persistent': audit['lifecycle'], 'unexecuted_lifecycle_groups': lifecycle['unexecuted_groups'],
    'source_binding': audit['source_binding'],
    'source_stable': language['source_stability'], 'artifact_stable': language['artifact_stability'],
    'raw_reports': {label: audit[label]['report_sha256'] for label in ['language', 'lifecycle']},
    'audit': copies['report.json'], 'source_map': copies['source-map.json'],
    'case_changes': copies['case-changes.json'], 'status_changes_record': copies['status-changes.json'],
    'raw_changes': copies['raw-changes.json'], 'captures': pointer(capture_path),
    'implementation_checks_and_platforms': pointer(REPORTS / 'stage45-implementation-checkpoint.json'),
    'full_m2_complete': False, 'compatibility_complete': False, 'hosted_ci_claimed': False, 'performance_target_claimed': False,
    'remaining': ['All failed, unimplemented, unmapped and unexecuted required language cases.',
                  'Broader standard-library bootstrap failures and required original resource/glob/rendering/loading dependencies.',
                  'Stage46 implementation is a separate unmerged source and evidence scope.',
                  'Whole product, platform and execution-time/peak-memory targets remain open.']}
summary_path = REPORTS / 'stage45-final-summary.json'
assert not summary_path.exists()
save(summary_path, summary)
save(OUT / 'report.json', {'captures': pointer(capture_path), 'summary': pointer(summary_path),
                          'publication_completed': True, 'root_review_and_commit_pending': True})
print(json.dumps({'archives': len(archives), 'payload_files': len(rows), 'summary': pointer(summary_path)}, indent=2))
