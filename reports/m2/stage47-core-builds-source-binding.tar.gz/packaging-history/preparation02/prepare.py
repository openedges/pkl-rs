from pathlib import Path
from collections import Counter
import datetime, hashlib, json, os, shutil, stat, subprocess, sys
ROOT=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage47')
MAIN=Path('/Users/cody.ij.hwang/Projects/pkl-rs')
OUT=Path(__file__).resolve().parent
IMPL=ROOT/'target/m2/stage47-implementation-01'
BASE='4facad294bedc3393f7dfbccc2f82439fb0734af'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
def progress(phase,**kw):
 save('progress.json',dict(phase=phase,**kw));print(phase,kw,flush=True)
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
CORE_REVIEWS=['stage47-runtime-review-01','stage47-runtime-review-02','stage47-boxing-identity-design-01','stage47-float-property-identity-review-01','stage47-carrier-review-01','stage47-carrier-review-02','stage47-stack-correction-review-01','stage47-lifecycle-test-review-01','stage47-lifecycle-test-review-02','stage47-diagnostic-layout-review-01','stage47-stdlib-admission-plan-01']
roots=[(IMPL,'implementation')]+[(ROOT/'target/m2'/n,n) for n in ['stage47-rust5-01','stage47-original-output-java-01']+[f'stage47-original-output-native-{i:02}' for i in range(1,7)]]+[(MAIN/'target/m2'/n,'reviews/'+n) for n in CORE_REVIEWS]
# Exact exclusions are constructed before any recursive traversal. Source-map
# entries are read directly later; no source or Cargo cache tree is walked.
pruned=set()
for child in IMPL.iterdir():
 if child.is_dir():
  if (child/'source-delta').is_dir():pruned.add(child/'source-delta')
  if child.name.startswith('renderer-candidate-build-'):pruned.add(child/'sources')
cache_exclusions=[ROOT/'target/stage47-cargo',ROOT/'target/debug',ROOT/'target/wasm32-unknown-unknown',ROOT/'target/m2/stage47-c05-platform-workspace-01/target',ROOT/'target/m2/stage47-original-output-workspace-01/workspace']
for path in cache_exclusions:pruned.add(path)
save('selection-plan.json',dict(schema=1,started_utc=started,roots=[dict(path=str(p),label=n) for p,n in roots],exact_pre_traversal_exclusions=[str(p) for p in sorted(pruned)],exclusion_contract='Prune exact absolute paths before os.scandir recursion. Most cache paths are outside selected roots and never entered. Full source trees/source-delta trees are replaced by explicit map-driven content binding; no generic build or cache pattern.',archive_tool='tools/evidence.py',base_commit=BASE))
def group(label):
 if label.startswith('reviews/') or label.startswith('stage47-'):return 'originals-rust5-reviews'
 rel=label.removeprefix('implementation/');head=rel.split('/')[0]
 if head.startswith('renderer-candidate-build-'):return 'builds-source-binding'
 if head.startswith('identity-'):
  if any(x in head for x in ['heap','graph','workspace','clippy','diagnostic-layout','permanent','class-']):return 'lifecycle-layout-checks'
  return 'carrier-stack-checks'
 if head.startswith('final-'):return 'lifecycle-layout-checks'
 return 'renderer-checks-proposals'
selected=[]
def walk(path,label):
 if path in pruned:return
 st=path.lstat()
 if stat.S_ISLNK(st.st_mode):raise ValueError(('symlink in selected evidence',str(path)))
 if stat.S_ISREG(st.st_mode):
  selected.append(dict(original=str(path),archive_path='raw/'+label,group=group(label),bytes=st.st_size,sha256=sha(path),mode=stat.S_IMODE(st.st_mode)));return
 if not stat.S_ISDIR(st.st_mode):raise ValueError(('special selected evidence',str(path)))
 for entry in sorted(os.scandir(path),key=lambda e:e.name):
  child=Path(entry.path)
  if child not in pruned:walk(child,label+'/'+entry.name)
for p,n in roots:walk(p,n)
save('selected-files.json',selected)
progress('selected raw captures',files=len(selected),bytes=sum(x['bytes'] for x in selected))
# All source map payloads remain in the selected evidence exactly as recorded.
full_maps=[];pairs=set();locations={}
for row in selected:
 p=Path(row['original'])
 if p.parent.parent==IMPL and p.name in ('source-before.json','source-after.json'):
  data=json.loads(p.read_text())
  if data and all(isinstance(k,str) and isinstance(v,str) and len(v)==64 for k,v in data.items()):
   full_maps.append(dict(path=str(p),sha256=row['sha256'],entries=len(data)))
   pairs.update(data.items())
for i in range(1,7):
 p=IMPL/f'renderer-candidate-build-{i:02}'
 for name,digest in json.loads((p/'source-after.json').read_text()).items():locations.setdefault((name,digest),p/'sources'/name)
for child in sorted(IMPL.iterdir()):
 if not child.is_dir():continue
 d=child/'source-delta.json'
 if d.exists():
  for name,digest in json.loads(d.read_text()).get('changed',{}).items():
   path=child/'source-delta'/name
   if path.is_file():locations.setdefault((name,digest),path)
 # Authored source proposals and explicit retained source reconstructions are
 # small selected payloads, unlike the pruned full snapshots.
 for row in selected:
  p=Path(row['original'])
  if p.is_relative_to(child) and p.suffix in ('.rs','.md','.py','.mjs'):
   if '/sources/' in str(p):
    name=str(p).split('/sources/',1)[1];locations.setdefault((name,row['sha256']),p)
# A basename and digest are sufficient to locate a retained exact source, but
# never to invent missing bytes or assert contemporaneous capture.
by_basename={}
for row in selected:
 p=Path(row['original']);by_basename.setdefault((p.name,row['sha256']),p)
for name,digest in pairs:
 if (name,digest) not in locations and (Path(name).name,digest) in by_basename:locations[(name,digest)]=by_basename[(Path(name).name,digest)]
save('source-map-index.json',full_maps)
progress('source maps indexed',maps=len(full_maps),unique_path_versions=len(pairs))
# Pinned Git blob verification is streaming, without checking out or rewriting
# references. All objects are read as raw bytes, including CRLF distinctions.
commits=[BASE]
for i in reversed(range(1,7)):
 c=json.loads((IMPL/f'renderer-candidate-build-{i:02}/release.json').read_text())['base_commit']
 if c not in commits:commits.append(c)
repo_specs=[('project',ROOT,'',commits)]
for short,pin in [('pkl','e51fb2f91774265666f94980ec630db794a4db2d'),('pkl-pantry','904a68184e54da378b0a0e8a911a3fab3956f693')]:
 repo=ROOT/'external'/short
 actual=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert actual==pin
 repo_specs.append((short,repo,'external/'+short+'/',[pin]))
needed_paths={p for p,h in pairs};git_bindings={};git_objects=[]
for repo_name,repo,prefix,revisions in repo_specs:
 objects={}
 for rev in revisions:
  raw=subprocess.check_output(['git','ls-tree','-rz',rev],cwd=repo)
  for line in raw.split(b'\0'):
   if not line:continue
   meta,path=line.split(b'\t',1);mode,kind,oid=meta.decode().split();name=prefix+os.fsdecode(path)
   if kind=='blob' and name in needed_paths:objects.setdefault(oid,[]).append((name,rev,mode))
 cached_path=ROOT/'target/m2/stage47-core-publication-proposal-01/git-objects.json'
 cached_sha='6a0580492a7747b190a8e2f6f28181231278cd9035d73a05bd0f87c80b68ba56'
 assert sha(cached_path)==cached_sha
 cached={(r['repository'],r['object']):r for r in json.loads(cached_path.read_text())}
 for oid,uses in objects.items():
  item=cached[(repo_name,oid)];size=item['bytes'];digest=item['sha256']
  git_objects.append(item)
  for name,rev,mode in uses:
   if (name,digest) in pairs:git_bindings.setdefault((name,digest),dict(kind='pinned-git-blob',repository=repo_name,commit=rev,git_path=name[len(prefix):],object=oid,git_mode=mode,bytes=size))
 save('git-object-hash-reuse.json',dict(source=str(cached_path),sha256=cached_sha,producer=str(ROOT/'target/m2/stage47-core-publication-proposal-01/prepare.py'),reason='Prior preparation completed streaming raw Git object reads, then failed only on a duplicate dictionary keyword. Immutable object IDs and exact hash-table bytes reused; current Git trees and raw captures are read again.'))
 progress('git repository hashed',repository=repo_name,objects=len(objects),bound_versions=len(git_bindings))
save('git-objects.json',git_objects)
# Store each necessary non-Git source version once. Separately published report
# archives remain explicit pointers; archive bytes are not silently normalized.
blob_dir=OUT/'source-blobs';blob_dir.mkdir()
bindings=[];unresolved=[];external_archives=[]
for name,digest in sorted(pairs):
 binding=git_bindings.get((name,digest))
 if binding is None:
  src=locations.get((name,digest))
  if src is None:
   unresolved.append(dict(path=name,sha256=digest,reason='No retained source bytes or matching pinned Git blob located; historical map hash is preserved, not relabeled a source-complete pass.'))
   binding=dict(kind='unresolved-historical-source')
  else:
   assert src.is_file() and not src.is_symlink() and sha(src)==digest,(name,src)
   if name.startswith('reports/') and name.endswith(('.tar.gz','.tgz','.zip','.tar.zst')):
    binding=dict(kind='separately-published-report-archive',canonical_capture=str(src),bytes=src.stat().st_size,reason='Preserved source-map digest and verified captured bytes; prior report archive payload is intentionally not nested again.')
    external_archives.append(dict(path=name,sha256=digest,**binding))
   else:
    dest=blob_dir/digest
    if not dest.exists():shutil.copyfile(src,dest)
    assert sha(dest)==digest
    binding=dict(kind='archived-source-blob',blob='source-blobs/'+digest,bytes=dest.stat().st_size,canonical_capture=str(src),capture_qualification='Exact map-hash match; retained/reconstructed source provenance remains as recorded in its original producer metadata.')
 bindings.append(dict(path=name,sha256=digest,**binding))
save('source-bindings.json',bindings);save('unresolved-source-bindings.json',unresolved);save('external-report-archive-bindings.json',external_archives)
# Narrow end-of-line boundary, never a production/output normalization.
eol=[]
for name in ['external/pkl/gradlew.bat','external/pkl-pantry/gradlew.bat']:
 for b in bindings:
  if b['path']==name and b['kind']!='pinned-git-blob':eol.append(b)
save('git-checkout-byte-boundaries.json',dict(scope='Pinned Git raw blob bytes and captured checkout bytes are distinct. No reference files or comparison outputs changed.',entries=eol))
final=json.loads((IMPL/'renderer-candidate-build-06/source-after.json').read_text())
critical=[(p,h) for p,h in final.items() if p.startswith(('crates/','tools/')) or p in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','references.lock','.cargo/config.toml']]
missing={(r['path'],r['sha256']) for r in unresolved};assert not(set(critical)&missing)
progress('source bindings complete',bindings=len(bindings),archived_blobs=len(list(blob_dir.iterdir())),unresolved=len(unresolved),separate_archives=len(external_archives))
# Curated staging has no excluded directory: evidence.py can safely walk it.
for row in selected:
 src=Path(row['original']);assert sha(src)==row['sha256'];dst=OUT/'staging'/row['group']/row['archive_path'];dst.parent.mkdir(parents=True,exist_ok=True);os.link(src,dst)
source_group=OUT/'staging/builds-source-binding'
for p in sorted(blob_dir.iterdir()):
 d=source_group/'source-blobs'/p.name;d.parent.mkdir(parents=True,exist_ok=True);os.link(p,d)
for name in ['selection-plan.json','selected-files.json','source-map-index.json','git-objects.json','source-bindings.json','unresolved-source-bindings.json','external-report-archive-bindings.json','git-checkout-byte-boundaries.json','git-object-hash-reuse.json']:
 shutil.copyfile(OUT/name,source_group/name)
# Actual report exits are inventory data, not a manufactured success counter.
checks=[]
for child in sorted(IMPL.iterdir()):
 p=child/'report.json'
 if child.is_dir() and p.exists():
  d=json.loads(p.read_text())
  if 'exit_code' in d:checks.append(dict(label=child.name,exit_code=d['exit_code'],source_stable=d.get('source_stable'),report=str(p),report_sha256=sha(p),command=d.get('command')))
save('check-outcomes.json',checks)
summary=dict(schema=1,status='proposal-for-root-review-not-published',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_release=str(IMPL/'renderer-candidate-build-06/release.json'),candidate_release_sha256=sha(IMPL/'renderer-candidate-build-06/release.json'),base_commit=BASE,source_maps=len(full_maps),source_path_versions=len(pairs),git_bound_versions=len(git_bindings),archived_source_blobs=len(list(blob_dir.iterdir())),unresolved_historical_source_versions=len(unresolved),selected_raw_files=len(selected),selected_raw_bytes=sum(r['bytes'] for r in selected),check_exit_counts=dict(Counter(str(r['exit_code']) for r in checks)),final=dict(rust5_report_sha256=sha(ROOT/'target/m2/stage47-rust5-01/report.json'),rust5_binding_sha256=sha(ROOT/'target/m2/stage47-rust5-01/candidate-binding.json'),original_cli_report_sha256=sha(ROOT/'target/m2/stage47-original-output-native-06/report.json'),original_cli_comparisons=4),qualifications=['Recorded failures, SIGABRT/stack observations, compiler/setup mistakes and blocked debugger launch remain failed or qualified exactly as captured.','Historical source maps are complete; any source-version reconstruction or unresolved bytes are listed explicitly, never counted as exact build provenance.','Small-stack tests retain 256 KiB and original depth/workload limits. Two runtime and one constraints setup loop now poll 1 instruction up to 100000 with GC instead of a single 1000-instruction setup poll; subsequent callback/timeouts/workload budgets remain unchanged.','Initialized base graph is a shared semantic root. Lifecycle tests use exact source-specific value deltas and independent descriptor counts, preserve original positive/plateau checks where those were the original contract, stale-user-handle rejection and terminal slots zero. No node-by-node dump was acquired for fixed/reference closure counts.','Optional diagnostic fields moved into existing boxed details/provenance. A hint-only error can allocate a details carrier; no performance or exact-size measurement is claimed.','Permanent generator/constant fixture is one actual Java powerAssertions=true baseline: 240 original observations consumed under two distinct Rust instrumentation settings (480 comparisons), not two Java acquisitions.','C05 actual platform evidence is separately published and remains intermediate. C06 platform and B native/API acquisitions have independent owners/archives and are not folded into this core package.','Evaluator-owned stdlib admission remains required: singleton base/ref/test bypass ModuleKey resolution, not import-edge trust checks. Complete scalar/String/constant-collection identity, full selected regression, whole M2 and performance gates remain open.'],source_freeze='No source/Git edits and no new evaluation were performed by this publication preparation.')
save('summary.json',summary)
for name in ['check-outcomes.json','summary.json']:
 shutil.copyfile(OUT/name,source_group/name)
shutil.copyfile(__file__,source_group/'prepare.py')
shutil.copyfile(ROOT/'tools/evidence.py',source_group/'evidence.py')
# Exact file lists consumed by create are recorded after all staging is complete.
archive_inputs={}
for directory in sorted((OUT/'staging').iterdir()):
 rows=[]
 for path in sorted(directory.rglob('*')):
  if path.is_file():rows.append(dict(path=path.relative_to(directory).as_posix(),sha256=sha(path),bytes=path.stat().st_size))
 archive_inputs[directory.name]=rows
save('archive-inputs.json',archive_inputs)
# Recheck every raw source path after staging, without traversing cache trees.
for row in selected:assert sha(Path(row['original']))==row['sha256']
save('preparation-report.json',dict(exit_code=0,started_utc=started,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),raw_inputs_stable=True,archive_groups={k:dict(files=len(v),bytes=sum(x['bytes'] for x in v)) for k,v in archive_inputs.items()},source_binding_counts=dict(Counter(b['kind'] for b in bindings))))
progress('prepared',archive_groups=len(archive_inputs))
