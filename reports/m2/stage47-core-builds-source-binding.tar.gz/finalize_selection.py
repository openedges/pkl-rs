from pathlib import Path
from collections import Counter, defaultdict
import datetime, hashlib, json, os, shutil, subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
IMPL = ROOT / 'target/m2/stage47-implementation-01'
GROUP = OUT / 'staging/builds-source-binding'
def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()
def save(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')
def load(name):
    return json.loads((OUT / name).read_text())

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
bindings = load('source-bindings.json')
by_name_digest = defaultdict(list)
for row in bindings:
    if row['kind'] != 'unresolved-historical-source':
        by_name_digest[(Path(row['path']).name, row['sha256'])].append(row)
resolved_aliases = []
for index, row in enumerate(bindings):
    if row['kind'] != 'unresolved-historical-source' or '/' in row['path']:
        continue
    matches = by_name_digest[(row['path'], row['sha256'])]
    assert len(matches) == 1, row
    original = matches[0]
    assert original['path'] == 'crates/pkl-runtime/tests/' + row['path']
    assert original['kind'] == 'archived-source-blob'
    assert sha(OUT / original['blob']) == row['sha256']
    replacement = dict(original, path=row['path'], full_path_binding=original['path'])
    replacement['capture_qualification'] += ' Original producer used a basename key; exact full test path and SHA identify the retained bytes without changing its source map.'
    bindings[index] = replacement
    resolved_aliases.append(dict(original=row, replacement=replacement))
assert len(resolved_aliases) == 8
unresolved = [row for row in bindings if row['kind'] == 'unresolved-historical-source']
map_occurrences = defaultdict(list)
for recorded in load('source-map-index.json'):
    path = Path(recorded['path'])
    assert sha(path) == recorded['sha256']
    data = json.loads(path.read_text())
    for row in unresolved:
        if data.get(row['path']) == row['sha256']:
            map_occurrences[(row['path'], row['sha256'])].append(str(path))
for row in unresolved:
    row['recorded_maps'] = map_occurrences[(row['path'], row['sha256'])]
    row['qualification'] = 'Historical reconstruction incomplete: only recorded SHA and original outcomes are retained for this version. No bytes inferred; not a source-complete historical verification claim.'
assert len(unresolved) == 7
save('source-bindings-final.json', bindings)
save('basename-binding-addendum.json', resolved_aliases)
save('unresolved-source-bindings-final.json', unresolved)

final_map = json.loads((IMPL / 'renderer-candidate-build-06/source-after.json').read_text())
lookup = {(row['path'], row['sha256']): row for row in bindings}
final_binding = [lookup[(name, digest)] for name, digest in final_map.items()]
assert len(final_binding) == 51745
assert all(row['kind'] != 'unresolved-historical-source' for row in final_binding)
source_modes = json.loads((IMPL / 'renderer-candidate-build-06/source-modes.json').read_text())
assert set(source_modes) == set(final_map)
save('final-c06-binding.json', dict(
    release_sha256=sha(IMPL / 'renderer-candidate-build-06/release.json'),
    source_map_sha256=sha(IMPL / 'renderer-candidate-build-06/source-after.json'),
    source_modes_sha256=sha(IMPL / 'renderer-candidate-build-06/source-modes.json'),
    entries=len(final_binding), binding_counts=dict(Counter(row['kind'] for row in final_binding)),
    unresolved=0,
    catalog='source-bindings-final.json', catalog_sha256=sha(OUT / 'source-bindings-final.json'),
    mode_qualification='Captured executable/source modes remain separate metadata. evidence.py intentionally writes tar mode 0644; archive mode is not claimed as original filesystem mode.',
    separate_report_archives='Six C05 report archives remain separately published, with exact digest/size/source pointers. Their bytes are not recursively included again.'
))

# Narrow pinned-checkout EOL boundary. Both byte sequences stay distinct.
boundaries = []
for short, pin in [('pkl', 'e51fb2f91774265666f94980ec630db794a4db2d'), ('pkl-pantry', '904a68184e54da378b0a0e8a911a3fab3956f693')]:
    repo = ROOT / 'external' / short
    argv = ['git', 'show', pin + ':gradlew.bat']
    raw = subprocess.check_output(argv, cwd=repo)
    attributes = subprocess.check_output(['git', 'show', pin + ':.gitattributes'], cwd=repo)
    relative = 'external/' + short + '/gradlew.bat'
    captured = lookup[(relative, final_map[relative])]
    checkout = (OUT / captured['blob']).read_bytes()
    path = OUT / 'git-eol-source' / short
    path.mkdir(parents=True)
    (path / 'git-blob-gradlew.bat').write_bytes(raw)
    (path / 'pinned.gitattributes').write_bytes(attributes)
    boundaries.append(dict(path=relative, repository=str(repo), commit=pin, argv=argv,
        git_blob_sha256=hashlib.sha256(raw).hexdigest(), git_blob_bytes=len(raw),
        captured_sha256=hashlib.sha256(checkout).hexdigest(), captured_bytes=len(checkout),
        git_crlf_count=raw.count(b'\r\n'), checkout_crlf_count=checkout.count(b'\r\n'),
        git_lf_count=raw.count(b'\n'), checkout_lf_count=checkout.count(b'\n'),
        attributes_sha256=hashlib.sha256(attributes).hexdigest(),
        qualification='Pinned Git raw bytes and captured checkout bytes are both retained; checkout EOL conversion is a source-boundary fact, not runtime or output normalization.'))
save('git-checkout-eol-addendum.json', boundaries)

summary = load('summary.json')
summary['unresolved_historical_source_versions'] = len(unresolved)
summary['resolved_basename_metadata_versions'] = len(resolved_aliases)
summary['final']['source_entries_bound'] = len(final_binding)
summary['final']['source_unresolved'] = 0
summary['authoritative_source_catalog'] = 'source-bindings-final.json'
summary['historical_reconstruction_gaps'] = 'unresolved-source-bindings-final.json'
summary['qualifications'].append('Seven early intermediate source versions have hash-only reconstruction; exact affected checks are listed. All 51,745 C06 input entries are bound, with six separately published report archives referenced rather than nested.')
summary['qualifications'].append('The preparation02 body records completion at 2026-10-23T15:11:43.337280+00:00; its outer tool session identifier was unavailable after context handoff. This does not invent an outer process exit receipt. Archive create and separate verify receive new direct process receipts.')
save('summary-final.json', summary)
save('preparation-completion-observation.json', dict(
    producer_report='preparation-report.json', producer_report_sha256=sha(OUT / 'preparation-report.json'),
    producer_declared_exit_code=0, outer_tool_session=None,
    process_absent_observed=True, stdout_sha256=sha(OUT / 'prepare.stdout.bin'), stderr_sha256=sha(OUT / 'prepare.stderr.bin'),
    qualification='Recorded producer completion and process-absence readback; no invented outer-tool receipt or rerun.'
))

# Preserve failed packaging preparation and the successful producer's own raw output.
previous = ROOT / 'target/m2/stage47-core-publication-proposal-01'
for name in ['prepare.py', 'prepare.stdout.bin', 'prepare.stderr.bin', 'actual-terminal.json']:
    target = GROUP / 'packaging-history/preparation01' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(previous / name, target)
for name in ['prepare.py', 'prepare.stdout.bin', 'prepare.stderr.bin', 'preparation-report.json', 'previous-attempt.json', 'preparation-completion-observation.json']:
    target = GROUP / 'packaging-history/preparation02' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(OUT / name, target)
for name in ['source-bindings-final.json', 'basename-binding-addendum.json', 'unresolved-source-bindings-final.json', 'final-c06-binding.json', 'git-checkout-eol-addendum.json', 'summary-final.json']:
    shutil.copyfile(OUT / name, GROUP / name)
for short in ['pkl', 'pkl-pantry']:
    for name in ['git-blob-gradlew.bat', 'pinned.gitattributes']:
        source = OUT / 'git-eol-source' / short / name
        target = GROUP / 'git-eol-source' / short / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
shutil.copyfile(__file__, GROUP / 'finalize_selection.py')

readme = '''# Stage47 core implementation evidence proposal

This package proposes publication of the frozen C06 implementation and its core checks. It does not commit or publish repository changes. The shared JSON/PCF renderer, directives, source-backed JSON annotations, collection join, semantic reference carriers, descriptor/activation slot history and compact diagnostic metadata remain the C06 code under review.

`summary-final.json` and `final-c06-binding.json` are authoritative addenda to the preserved preparation metadata. All 51,745 C06 source-map entries are bound. `source-bindings-final.json` connects exact bytes to pinned project/reference Git blobs, content-addressed source payloads, or six separately published report archives. Complete before/after maps and source-mode maps are retained. Seven early source versions remain hash-only and are explicitly scoped in `unresolved-source-bindings-final.json`; they do not affect C06. No historical source bytes were inferred.

The five required Rust commands passed on C06. The untouched upstream moduleOutput2 and pcfRenderer9 programs each matched the original Java CLI twice across complete stdout, stderr, exit and file channels. Captured commands, host/toolchains, raw logs, artifacts and bindings are preserved. Earlier failed workspace, stack, compile, clippy and setup runs remain failed evidence. The failed packaging preparation is also preserved.

Small-stack tests retain 256 KiB and the original depth limits. Lifecycle checks distinguish the eagerly initialized base graph from user graphs, retain stale-user-handle and close-zero assertions, and separately bound executable nodes. Three initialization-only polling loops changed to permit eager base setup; subsequent callbacks, deadlines and workload limits retain their recorded contract. Fixed/reference closure counts have source analysis but no per-node heap dump. The permanent frame-identity test consumes one Java power-assertions-enabled baseline of 240 observations under two real Rust instrumentation configurations, yielding 480 comparisons; it is not a Java on/off experiment.

Hint-only errors can allocate optional boxed details. No exact size, speed or memory improvement is claimed. Full scalar/String/constant-collection identity and evaluator-owned standard-module admission remain mandatory work. Singleton base/ref/test skip ModuleKey resolution but still require import-edge trust checks. The new whole selected regression, whole M2 and performance gates remain open.

Native renderer/API and actual platform acquisitions are independently owned and published. The older six C05 platform archives are referenced without nesting. Archive integrity does not establish language compatibility. Tar mode 0644 is packaging metadata; original source and artifact modes remain in their captured maps/inventories. Pinned Windows launcher checkout bytes and raw Git blobs are recorded separately without normalizing production or output bytes.

Only curated evidence staging is passed to `tools/evidence.py`. Exact source/cache exclusions were applied before traversing original evidence, and source payloads were selected by explicit map entries. The packaging wrapper records `create` and a separate `verify` invocation for every archive.
'''
(OUT / 'README.md').write_text(readme)
shutil.copyfile(OUT / 'README.md', GROUP / 'README.md')
for row in load('selected-files.json'):
    assert sha(row['original']) == row['sha256'], row['original']
save('finalization-report.json', dict(started_utc=started,
    finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    resolved_basename_metadata=8, unresolved_historical_versions=7,
    final_c06_bound=51745, raw_selected_inputs_unchanged=True, exit_code=0))
print(json.dumps(load('finalization-report.json')), flush=True)
