from pathlib import Path
import base64, datetime, hashlib, json, os, platform, shutil, subprocess, sys, tarfile, time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
GROUP = OUT / 'staging/builds-source-binding'
def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

started = now()
assert json.loads((OUT / 'finalization-report.json').read_text())['exit_code'] == 0
save('finalization-actual-terminal.json', dict(tool_session=24292, actual_exit_code=0,
    qualification='Actual write_stdin terminal returned exit_code 0; raw stdout and stderr are retained.'))
for name in ['finalize.stdout.bin', 'finalize.stderr.bin', 'finalization-report.json', 'finalization-actual-terminal.json']:
    target = GROUP / 'packaging-history/finalization02' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(OUT / name, target)
shutil.copyfile(__file__, GROUP / 'package.py')
tool = GROUP / 'evidence.py'
assert sha(tool) == sha(ROOT / 'tools/evidence.py')
inputs = {}
# Only the already curated staging is traversed. No original source/cache tree
# is visited here; original exact pre-walk exclusions are in selection-plan.
for directory in sorted((OUT / 'staging').iterdir()):
    rows = []
    for path in sorted(directory.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            rows.append(dict(path=path.relative_to(directory).as_posix(), sha256=sha(path), bytes=path.stat().st_size))
    inputs[directory.name] = rows
save('archive-inputs-final.json', inputs)
save('packaging-environment.json', dict(started_utc=started, host=platform.platform(),
    machine=platform.machine(), python=sys.version, executable=sys.executable, cwd=str(ROOT),
    captured_evidence_tool=str(tool), evidence_tool_sha256=sha(tool),
    input_list_sha256=sha(OUT / 'archive-inputs-final.json'),
    no_new_evaluation=True, source_or_git_writes=False))
captures = OUT / 'packaging-captures'
captures.mkdir()
commands = []
def capture(label, argv):
    stdout = captures / (label + '.stdout.bin')
    stderr = captures / (label + '.stderr.bin')
    record = dict(label=label, argv=argv, cwd=str(ROOT), started_utc=now())
    tick = time.monotonic()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        process = subprocess.Popen(argv, cwd=ROOT, stdout=out, stderr=err)
        record['pid'] = process.pid
        save('packaging-progress.json', dict(phase='running', command=record))
        record['exit_code'] = process.wait()
    record.update(finished_utc=now(), elapsed_seconds=time.monotonic()-tick,
        stdout_sha256=sha(stdout), stderr_sha256=sha(stderr),
        stdout_bytes=stdout.stat().st_size, stderr_bytes=stderr.stat().st_size,
        stdout_base64=base64.b64encode(stdout.read_bytes()).decode(),
        stderr_base64=base64.b64encode(stderr.read_bytes()).decode())
    commands.append(record)
    save('packaging-commands.json', commands)
    print(label, record['exit_code'], flush=True)
    if record['exit_code'] != 0:
        save('packaging-report.json', dict(exit_code=1, started_utc=started,
            finished_utc=now(), failed_command=record, completed_commands=commands))
        raise SystemExit(1)
    return record

archives = []
for group, rows in inputs.items():
    source = OUT / 'staging' / group
    archive = OUT / ('stage47-core-' + group + '.tar.gz')
    assert not archive.exists(), archive
    created = capture(group + '-create', [sys.executable, str(tool), 'create', str(source), str(archive)])
    verified = capture(group + '-verify', [sys.executable, str(tool), 'verify', str(archive)])
    with tarfile.open(archive, 'r:gz') as tar:
        inventory = json.load(tar.extractfile('EVIDENCE.json'))
    assert inventory['files'] == rows, group
    for row in rows:
        path = source / row['path']
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], path
    archives.append(dict(name=archive.name, path=str(archive), sha256=sha(archive), bytes=archive.stat().st_size,
        files=len(rows), raw_bytes=sum(row['bytes'] for row in rows),
        create=created, separate_verify=verified, archive_inventory_equals_explicit_list=True,
        staged_inputs_unchanged=True))
    save('packaging-progress.json', dict(phase='archive-verified', completed=len(archives), archive=archive.name))

index = dict(schema=1, status='proposal-for-root-review-not-published', started_utc=started, finished_utc=now(),
    archives=archives, archive_count=len(archives), total_archive_bytes=sum(row['bytes'] for row in archives),
    input_list=dict(path='archive-inputs-final.json', sha256=sha(OUT / 'archive-inputs-final.json')),
    source_catalog=dict(archive='stage47-core-builds-source-binding.tar.gz', path='source-bindings-final.json', sha256=sha(OUT / 'source-bindings-final.json')),
    final_binding=dict(archive='stage47-core-builds-source-binding.tar.gz', path='final-c06-binding.json', sha256=sha(OUT / 'final-c06-binding.json')),
    summary=dict(archive='stage47-core-builds-source-binding.tar.gz', path='summary-final.json', sha256=sha(OUT / 'summary-final.json')),
    historical_source_gaps=dict(archive='stage47-core-builds-source-binding.tar.gz', path='unresolved-source-bindings-final.json', sha256=sha(OUT / 'unresolved-source-bindings-final.json'), count=7),
    qualifications=['This archive integrity result is not a new runtime/Java evaluation or full compatibility result.',
        'Actual source/artifact modes are captured separately; deterministic evidence tar headers use mode 0644.',
        'Raw create/separate-verify stdout and stderr are embedded without normalization as Base64 in this index as well as retained in packaging-captures.',
        'No source or Git edits. Seven historical source versions remain hash-only; all 51745 C06 map entries are bound.'])
save('archive-index.json', index)
save('packaging-report.json', dict(exit_code=0, started_utc=started, finished_utc=now(),
    archives=len(archives), create_commands=5, separate_verify_commands=5,
    total_archive_bytes=index['total_archive_bytes'], inventory_exact=True,
    archive_index_sha256=sha(OUT / 'archive-index.json'), source_writes=False, git_writes=False, new_evaluations=0))
save('packaging-progress.json', dict(phase='complete', archives=len(archives), exit_code=0))
print(json.dumps(json.loads((OUT / 'packaging-report.json').read_text())), flush=True)
