"""Record a fresh Stage 62 Java-only converted-object control validation."""
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "tools"))
from collection_conversion_controls_oracle import SOURCES  # noqa: E402

EXPECTED_HEAD = "e4e477713456ad1fc2976645524c0a0840c401a5"
OWN = (
    "target/m2/stage62-controls-java-validation-01/run_validation.py",
    "target/m2/stage62-controls-java-validation-01/publish.py",
    "tools/collection_conversion_controls_oracle.py",
    "tools/collection_conversion_controls_fixtures.py",
    "tools/java/CollectionConversionsOracle.java",
    "tools/tests/test_collection_conversion_controls_fixtures.py",
    "tools/inventory.py", "compatibility/inventory.json",
)
FIXTURE = ROOT / "tests/fixtures/m2-collection-conversion-controls"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def identity(path):
    path = Path(path)
    return {"bytes": path.stat().st_size, "sha256": sha(path)}

def save(data):
    (OUTPUT / "validation.json").write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")

def run(name, argv, env):
    folder = OUTPUT / "checks" / name
    folder.mkdir(parents=True)
    started = time.time()
    process = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=300)
    finished = time.time()
    for channel, raw in (("stdout", process.stdout), ("stderr", process.stderr)):
        (folder / (channel + ".bin")).write_bytes(raw)
    entry = {"name": name, "argv": argv, "cwd": str(ROOT), "environment": env,
             "started_epoch": started, "finished_epoch": finished,
             "exit_code": process.returncode,
             "stdout": identity(folder / "stdout.bin"), "stderr": identity(folder / "stderr.bin")}
    (folder / "process.json").write_text(json.dumps(entry, indent=2, sort_keys=True) + "\n")
    print(f"{name}: {process.returncode}", flush=True)
    return entry

def main():
    if (OUTPUT / "sources").exists() or (OUTPUT / "validation.json").exists():
        raise ValueError("fresh Stage 62 controls Java validation directory required")
    head = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True, check=True).stdout.decode().strip()
    if head != EXPECTED_HEAD:
        raise ValueError("Stage 62 Java authority baseline HEAD differs")
    names = sorted(set(SOURCES) | set(OWN) |
                   {path.relative_to(ROOT).as_posix() for path in FIXTURE.iterdir() if path.is_file()})
    before = {name: sha(ROOT / name) for name in names}
    for name in names:
        destination = OUTPUT / "sources" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, destination)
    python = sys.executable
    env = {"PATH": os.defpath, "HOME": str(ROOT / ".cache/oracle/home"),
           "TMPDIR": str(ROOT / ".cache/oracle/tmp"), "TMP": str(ROOT / ".cache/oracle/tmp"),
           "TEMP": str(ROOT / ".cache/oracle/tmp"), "LC_ALL": "C", "LANG": "C", "TZ": "UTC",
           "TERM": "dumb", "NO_COLOR": "1", "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}
    report = {"schema": 1, "kind": "stage62-converted-object-controls-java-validation",
              "scope": "Java authority integrity and pinned source inventory only; no Rust candidate pass",
              "baseline_head": head, "host": platform.uname()._asdict(),
              "python": {"executable": python, "executable_identity": identity(python),
                         "version": sys.version},
              "source_names": names, "source_before": before, "environment": env,
              "checks": [], "complete": False,
              "manifest_freshness_pass_claimed": False,
              "deferred_final_integration": ["M2 manifest regeneration and freshness after concurrent Rust/core source freeze"]}
    save(report)
    commands = (
        ("fixture-verifier", [python, "tools/collection_conversion_controls_fixtures.py"]),
        ("fixture-verifier-O", [python, "-O", "tools/collection_conversion_controls_fixtures.py"]),
        ("fixture-tests", [python, "-m", "unittest", "tools.tests.test_collection_conversion_controls_fixtures", "-v"]),
        ("fixture-tests-O", [python, "-O", "-m", "unittest", "tools.tests.test_collection_conversion_controls_fixtures", "-v"]),
        ("source-inventory", [python, "tools/inventory.py", "--check"]),
    )
    for name, argv in commands:
        report["checks"].append(run(name, argv, env))
        save(report)
    after = {name: sha(ROOT / name) for name in names}
    report["source_after"] = after
    report["source_stable"] = before == after
    report["snapshot_matches"] = before == {name: sha(OUTPUT / "sources" / name) for name in names}
    report["complete"] = (report["source_stable"] and report["snapshot_matches"]
                          and len(report["checks"]) == 5
                          and all(check["exit_code"] == 0 for check in report["checks"]))
    save(report)
    if not report["complete"]:
        raise ValueError("Stage 62 Java-only validation incomplete; raw attempts retained")

if __name__ == "__main__":
    main()
