# Candidate03 failure history

This is immutable historical Stage51 candidate03 evidence. Native and each Node/Chromium target acquired 2,108 calls with acquisition integrity, while the ordinary contract failed: 1,984 of 2,000 ordinary observations matched; 16 ordinary failures and 12 post-close raw boundaries remain. The 96 diagnostic observations remain separate. Original SourceCode adapter repeats and required local Rust checks passed within their recorded scope; neither closes compatibility.

All selected original files are preserved as regular archive payloads, including copied fixtures, frozen sources, original stdout/stderr, UTF-16 and Java-UTF8 channels, counters, effects, actual policy requests, tools, process receipts and failures. No duplicate source or fixture files have been silently removed. Every original file hash, size and mode is recorded in CAPTURE_SELECTION.json.

Frozen build snapshots, source maps, build proof and artifact hashes establish candidate03 identity. Current live crates are not compared. Candidate04 or later results cannot replace these historical failures. Only seven explicit root terminal receipts are selected; all additional receipt siblings are outside scope.

Archive creation, independent evidence.py verification and complete raw-member readback are recorded by the preparation producer. Java administrative lifecycle and whole-language compatibility gates remain false. No evaluator or Java acquisition was run during packaging.
