# Stage 17 설계 초안 — 실행 시 타입 사용 노드와 call target 소유권

이 문서는 **읽기 전용 소스 검토에 따른 후속 설계 제안**입니다. production·fixture·manifest를 수정하지 않았으며 새 Java/Rust 비교도 실행하지 않았습니다. 고정 Pkl 0.32.0 소스, 현재 Rust 구조, `target/m2/stage16-const-retry-gap.json`과 그 원본 acquisition을 근거로 작성했습니다. 아래 추가 입력과 종료 조건은 제안이며 통과 증거가 아닙니다. Stage 16의 최종 전체 acquisition·검사 결과는 루트의 별도 기록을 따릅니다.

## 결론과 제한 범위

다음 변경의 선행 조건은 **같은 bytecode를 실행하더라도 서로 다른 타입 사용 노드가 가질 수 있는 지속적인 해석 상태**를 표현하는 것입니다. 반대로 서로 다른 타입 인스턴스가 **동일한 let root call target의 본문 상태**를 공유하는 경계도 표현해야 합니다. 단일 `block`/`pc` cache나 별칭 이름별 플래그로는 두 조건을 함께 만족하지 못합니다.

Stage 16의 논리적 호출 프레임과 `CustomThisSlot`은 그대로 유지합니다. 이번에 필요한 identity는 호출 한 번의 mutable receiver가 아니라, 여러 호출과 실패·재시도를 거쳐 살아 있는 실행 노드의 소유권입니다. **call target identity와 call frame identity를 합치지 않습니다.** 같은 let root를 다시 실행하면 해석 cache는 공유하되 custom-this cell은 매번 새로 만들어야 합니다. 함수 호출도 같은 함수 본문 cache를 사용하면서 호출마다 독립 cell을 사용합니다.

권고 순서는 다음과 같습니다.

1. 타입 사용 위치와 실행 본문 소유권을 명시하는 최소 구조를 도입합니다.
2. non-generic 타입에 한정하여 보존된 local const 재시도 차이를 해결합니다. 독립 inline 사용 위치, let root 공유, lambda 복제, 재귀 깊이별 노드까지 포함해야 보존 control matrix를 충족합니다.
3. 그 구조에 실행 시 타입 인수 환경과 지연 타입 사용을 연결합니다. 동일 인수의 재귀부터 확인한 뒤 인수가 변하는 재귀로 확장합니다.

한 번의 체크포인트에 세 단계를 모두 넣을 필요는 없습니다. 첫 번째 구현 증분은 non-recursive const 재시도에 필요한 identity·cache를 제한적으로 연결할 수 있습니다. 다만 이 경우 재귀 control과 generic gap을 명시적으로 미완료로 유지하며, 전체 Stage 17 종료 또는 완전한 타입 해석으로 보고하지 않습니다.

## 확인한 Java 의미와 근거

모든 Java 경로는 `external/pkl/pkl-core/src/main/java/org/pkl/core/` 아래입니다. 소스 SHA-256과 보존 acquisition 식별자는 `target/m2/stage16-const-retry-gap.json`에 있습니다.

| 근거 | 확인한 동작 | 설계상 결과 |
| --- | --- | --- |
| `runtime/VmTypeAlias.java:180`, `instantiate` | alias 본문을 타입 사용마다 deep copy합니다. 일반 `TypeVariableNode`와 constraint 안의 미해석 `UnresolvedTypeNode.TypeVariable`도 인수 타입으로 치환합니다. | 선언 identity와 사용 인스턴스 identity를 분리해야 합니다. |
| `ast/type/TypeNode.java:2678`, `TypeAliasTypeNode` | 초기화 상태·인수 개수를 확인하고 인스턴스 본문을 생성한 뒤 해당 노드를 검증합니다. 실행 중 owner/receiver만 선언 환경으로 바꿉니다. | alias identity/부분 초기화/검증 순서를 보존하며 custom-this는 호출 프레임에 남깁니다. |
| `ast/type/TypeTestNode.java:47`, `TypeCastNode.java:41` | 해당 실행 노드가 처음 도달했을 때 타입을 해석한 뒤 operand를 평가합니다. 성공한 해석 노드는 이후 재사용합니다. | 타입 해석을 operand 뒤로 옮기거나 재시도마다 무조건 새 인스턴스를 만들면 안 됩니다. |
| `ast/type/UnresolvedTypeNode.java:204`, `Parameterized` | base를 먼저 해석합니다. builtin class는 인수 개수 확인 후 필요한 인수를 해석하고 `Class<T>`는 인수를 지웁니다. alias는 인수를 순서대로 해석한 뒤 `TypeAliasTypeNode`를 만듭니다. | class와 alias의 인수 검증·소거 순서를 하나의 공통 eager 단계로 합치면 안 됩니다. |
| `ast/expression/member/ReadLocalPropertyNode.java:73` | `property` 필드를 채운 뒤 const 여부를 확인합니다. 첫 실패에도 이 필드는 남고 동일 노드의 다음 실행은 const 확인을 우회합니다. | 실패 이전에 실제로 publish된 **local property 해석 결과**만 지속시켜야 합니다. |
| `ast/expression/member/ReadPropertyNode.java:164` | 일반 property의 `isConstChecked`는 성공 후에만 갱신됩니다. | local property의 재시도 특이 동작을 일반 property에 적용하면 안 됩니다. |
| `ast/expression/member/AbstractInvokeMethodLexicalNode.java:55` | const 검사를 argument 실행 전에 수행하며 성공 후에만 `isConstChecked`를 기록합니다. virtual method도 해석 결과를 반환하기 전에 검사합니다. | local/nonlocal method의 반복 실패와 첫 오류·call 전체 span을 유지해야 합니다. |
| `ast/expression/primary/ExecuteCustomThisWithRootNode.java:54` | let-writing constraint 본문은 미리 만든 `SimpleRootNode` call target 아래에 있습니다. wrapper가 복제되어도 그 root 본문은 공유됩니다. | alias 인스턴스마다 모든 block 상태를 복제하는 정책도 잘못입니다. |
| `ast/member/UnresolvedFunctionNode.java:34` | 함수 생성 전 body는 AST child입니다. inline alias 복제 시 lambda 본문도 독립적으로 복제됩니다. | lambda의 본문 해석 identity와 closure의 receiver/environment snapshot을 별도로 소유해야 합니다. |

`VmTypeAlias.instantiate`에는 alias root가 곧 타입 변수인 경우 인수 노드를 직접 반환하는 예외가 있습니다. 초기 구조를 설계할 때 이 예외를 버리지 않습니다. 타입 인수를 항상 동일 방식으로 deep copy하거나 항상 공유한다고 가정하지 말고, 해당 예외와 일반 치환을 별도의 clone 정책으로 표현합니다.

**확인하지 않은 경계:** generic 인수가 let root 내부의 type variable에 들어가는 경우와 이미 해석된 lambda/root를 다시 clone하는 경우의 전체 소유권은 이번 읽기와 기존 control만으로 확정하지 않습니다. non-generic let root의 공유 결과를 모든 generic 조합으로 일반화하지 말고, 아래 추가 Java matrix를 먼저 수집합니다.

## 보존 control matrix

다음 표는 `target/m2/stage16-const-retry-gap.json`의 관찰을 그대로 설계 요구사항으로 옮긴 것입니다. 독립 CLI 호출의 집합이 아니라 **같은 evaluator에서 지정 순서대로 수행한 호출**이므로, 중간 실패와 이후 결과를 모두 비교해야 합니다.

| 보존 acquisition / control | Java 관찰 | Rust 후속 수용 조건 |
| --- | --- | --- |
| `stage16-sequences-java-02`, `alias-const-retry` | 원본 call 3의 `localValue`는 const 오류, call 7의 같은 사용은 raw stdout `-1`로 성공합니다. | 원본 전체 호출 순서를 바꾸지 않고 두 결과를 모두 맞춥니다. |
| `stage16-const-retries-java-01`, 독립 inline alias 사용 | 서로 다른 property의 타입 사용은 각각 첫 실행에 실패하고 자기 사용의 재시도부터 성공합니다. | 같은 alias/span/block을 사용해도 독립 node cache를 갖습니다. |
| 같은 acquisition, 일반 property·local/nonlocal method | 반복 시도에도 계속 const 오류가 발생합니다. | local read 특이 동작이 다른 종류로 전파되지 않습니다. |
| 같은 acquisition, let-root alias 사용 | 첫 사용은 한 번 실패한 뒤 성공하며, 별도의 두 번째 사용은 처음부터 성공합니다. | wrapper 인스턴스와 별도로 공유 root 본문 cache를 유지합니다. |
| 같은 acquisition, lambda를 포함한 inline alias | 별도 타입 사용마다 lambda 내부 local read가 한 번씩 독립적으로 실패합니다. | inline clone의 함수 생성 노드·본문 identity를 분리합니다. |
| `stage16-const-recursive-java-01`, `const-local-recursive-cache` | `value: A = 2`를 여섯 번 읽으면 세 번 오류 후 세 번 raw stdout `2`입니다. 앞뒤 `stable`은 `42`입니다. | 재귀적으로 도달한 각 타입 사용 노드는 독립 상태를 갖고 같은 사용의 재시도는 이미 publish된 상태를 재사용합니다. |

마지막 재귀 입력은 다음 원본을 유지합니다.

```pkl
local threshold = 0
typealias A = Int(this < 0 || ((this - 1) is A && this < threshold))
value: A = 2
stable = 42
```

원본 read sequence는 `stable`, `value` 여섯 번, `stable`입니다. 세 오류를 한 오류로 줄이거나 항상 성공시키는 구현은 공유 범위가 잘못된 것입니다. 반대로 매 재시도마다 모든 노드를 새로 만들면 영원히 첫 오류에서 멈춥니다.

## 제안하는 identity와 소유권

이름은 설계용이며 최종 API 이름을 고정하지 않습니다.

| 식별자 | 소유자 / 수명 | 용도 |
| --- | --- | --- |
| `DeclarationId` | immutable `Program` | alias/class 선언의 정체성입니다. 기존 declaration index를 재사용할 수 있습니다. |
| `TypeUseTemplateId` | immutable `Program` | annotation, `is`, `as`, parameter/result 등 각 타입 사용 occurrence의 미해석 계획입니다. span은 진단 정보이며 identity 전체가 아닙니다. |
| `CodeTemplateId` | immutable `Program` | 기존 bytecode block과 명령별 cache-site ordinal입니다. block 자체에 mutable 상태를 넣지 않습니다. |
| `TypeNodeId` | evaluator-local 추적 arena | 한 resolved 타입 사용 인스턴스입니다. alias 인스턴스·타입 인수·자식 사용 노드·부분 해석 상태를 소유합니다. |
| `ExecutableOwnerId` | evaluator-local 추적 arena | property/method root, inline alias 복제 본문, shared constraint root, 함수 본문의 지속 cache를 소유합니다. |
| `CustomThisSlot` | 기존 evaluator heap | 호출 한 번의 mutable auxiliary receiver입니다. 위 노드/cache identity를 대신하지 않습니다. |

권고하는 cache 접근 키는 **`ExecutableOwnerId` + 선언된 site ordinal**입니다. 두 필드만 같으면 모든 동작을 합친다는 뜻이 아니라, `ExecutableOwnerId`를 Java clone/call target 경계에 맞춰 생성해야 한다는 뜻입니다.

- 일반 property/method root의 같은 타입 사용은 재실행 시 같은 `TypeNodeId`를 얻습니다.
- alias 타입 사용을 처음 해석할 때 그 사용 전용 alias 본문 인스턴스를 생성합니다. 같은 declaration과 같은 타입 인수라도 독립 사용 위치의 mutable 상태를 intern하지 않습니다.
- inline constraint block은 bytecode를 공유하되 alias 인스턴스의 `ExecutableOwnerId`로 실행합니다.
- 해당 inline 본문 안에서 재귀 `is A`에 처음 도달하면 그 본문 소유자의 하위 site에 새 `TypeNodeId`를 publish합니다. 그 하위 타입 인스턴스의 본문은 다시 독립 실행 소유자를 가집니다. 방문하지 않은 더 깊은 노드를 미리 만들지 않습니다.
- non-generic let-writing constraint는 wrapper 인스턴스가 달라도 확인된 shared root owner를 사용합니다. 실행마다 `CustomThisSlot`은 Stage 16 규칙대로 새로 만듭니다.
- lambda는 clone된 함수 생성 노드가 함수 본문 owner를 소유하고, 만들어진 함수 값이 그 owner를 참조합니다. 함수 값의 lexical environment와 생성 순간 receiver snapshot은 여전히 값마다 별도입니다. 호출 시 새 custom-this cell을 사용합니다.
- `Frame`에는 실행 cache owner, `TypeRun`에는 실행 중인 타입 노드와 환경을 둡니다. `Frame` 수, block 번호, 타입 노드 수가 같다고 가정하지 않습니다.

이 구조는 **정적 template를 공유하고 지속 실행 상태를 소유권에 따라 복제하는 모델**입니다. 타입 인수의 의미상 동등성만으로 mutable 노드를 공유하지 않습니다. `TypeCheck::equivalent`는 alias를 지우므로 이 용도의 key가 아니며, `Debug` 문자열도 key로 쓰지 않습니다.

## 현재 Rust 구조와의 연결

현재 `Instruction::CheckType` / `TestType`는 복제 가능한 `TypeCheck` 값을 들고 있고, `TypeCheck::Constrained`는 `ConstraintCode.block`을 참조합니다. compiler의 `active_constraints: BTreeMap<Span, (usize, bool)>`는 compile-time 재귀 확장을 끊는 장치입니다. 이것을 실행 시 해석 cache로 바꾸면 안 됩니다.

첫 증분에서는 다음 경계를 최소로 추가할 수 있습니다.

1. 각 실행 가능한 타입 사용과 local property lookup에 명시적인 site ordinal을 부여합니다. 기존 span, authored type text, alias origin, `Class<T>` 소거 규칙은 보존합니다.
2. `Program`에 clone 정책이 있는 immutable 실행 template를 저장하고 VM에 root owner를 만듭니다. `MakeFunction`과 constraint launch에서 어느 owner를 사용할지 전달합니다.
3. 기존 `TypeCheck` 표현을 유지하는 non-generic 경로에도 타입 사용 인스턴스 owner를 연결합니다. static semantic check와 mutable node state를 구분하여 한 번에 모든 타입을 다시 구현하지 않습니다.
4. `RequireConstProperty`와 실제 local lookup 사이에 전용 `LocalPropertyResolution` 상태를 연결합니다. Java와 같이 member 해석 결과를 먼저 publish하고 const 오류를 낸 뒤, 같은 노드의 다음 실행에서 그 결과를 사용합니다.
5. 정상 property/method는 기존 지속 실패 정책을 유지합니다. property 값의 성공 cache와 property 노드의 해석 cache를 합치지 않습니다. 첫 const 오류는 property body나 argument를 실행하지 않아야 합니다.
6. shared let root와 inline lambda의 owner 전환을 연결한 뒤 non-recursive control부터 비교합니다. 재귀 node 생성은 이 구조가 확인된 다음 별도 증분으로 연결합니다.

`LocalPropertyResolution`은 단순한 `failed_once: bool`이 아니라 실제 해석된 member identity를 보존해야 합니다. owner/receiver가 다른 상속·amendment 상황에서도 올바른 member를 선택해야 하며, lookup 자체가 실패한 경우를 성공한 해석으로 기록하지 않습니다. 일반 property·method에 같은 상태 기계를 적용하지 않습니다.

## recursive generic으로 확장할 때의 지연 계획

완성된 `TypeCheck` tree를 무한히 확장하는 대신 미해석 타입 사용 계획과 **해당 인스턴스의 타입 인수 환경**을 유지합니다.

- 타입 변수는 이름 문자열만으로 찾지 않고 선언 parameter identity/index와 인수 환경으로 해석합니다. bare `T`와 parameterized `T<...>`의 shadowing 정책을 현재 Java 증거에 맞춰 보존합니다.
- alias 초기화, base 이름 해석, 인수 순차 해석, 인수 개수 검증, alias 본문 검증의 순서는 `UnresolvedTypeNode` / `TypeAliasTypeNode`와 같아야 합니다. 인수를 먼저 정규화하는 공통 fast path를 만들지 않습니다.
- constraint의 `is`/`as`에 아직 도달하지 않았으면 그 내부 타입 사용도 해석하지 않습니다. `A<T>`가 `A<List<T>>`를 참조하더라도 실행하지 않은 분기는 compile-time에 유한해야 합니다.
- 동일 인수의 재귀에서도 각 실제 타입 사용 인스턴스는 local read cache 때문에 구분해야 합니다. immutable 타입 인수 표현을 공유하는 최적화와 mutable 실행 노드 공유는 별도입니다.
- `Class<Missing>` 인수 소거, alias identity와 `Reference`/함수 metadata의 authored 표현, 실패한 alias의 부분 publish를 유지합니다.
- 기존 unsupported를 제거하는 시점은 실제 실행 경로와 검증이 추가된 뒤입니다. 미해결 타입을 `Unknown`으로 대체하여 성공시키지 않습니다.

추가 oracle 후보는 동일 인수 재귀, 상호 재귀, `A<List<T>>`의 도달/미도달 분기, 두 개의 다른 인수 instantiation을 교대로 실행하는 sequence, generic let root와 lambda 안의 `T`, alias root가 타입 변수인 경우입니다. 이 후보들은 아직 수집하지 않았습니다. 특히 generic let root를 non-generic과 동일하게 공유할지는 이 결과를 읽은 뒤 결정합니다.

## Host·GC·부분 실패의 위험

- **GC 연결:** resolved node가 class/alias/member owner 또는 captured environment를 참조하면 모두 mark graph의 edge여야 합니다. 별도 `Rc<RefCell<...>>` cycle을 만들지 않습니다. 기존 heap의 typed entry로 추가하거나 별도 arena를 동일 traversal에 연결할 수 있지만 세대·evaluator 검사를 유지해야 합니다.
- **지속 root:** 실행 root에서 해석된 자식 노드는 Java AST가 보유하는 범위만큼 지속되어야 합니다. 단순히 active frame 종료 시 모두 지우면 재시도 동작이 깨집니다. 반대로 모든 동적 node를 VM-global map에 영구 보존하면 더 이상 reachable하지 않은 함수·객체·인수 환경을 누수시킬 수 있습니다.
- **증가 범위:** 처음 더 깊은 재귀를 실행하면 새로운 타입 사용 노드가 생길 수 있습니다. 같은 깊이를 반복 실행할 때는 이미 있는 prefix를 재사용해야 합니다. 새 깊이의 정상 성장과 retry마다의 누수를 구분하여 측정합니다.
- **Host 중단:** 타입 해석이나 member forcing이 Host에서 멈출 수 있습니다. `TypeRun`의 해석 진행 위치·소유자·인수 환경·publish된 부분 결과를 continuation에 보관합니다. 중단된 부모와 재진입 자식은 cache 공유 규칙을 따르면서 서로 다른 custom-this cell을 유지해야 합니다.
- **같은 site로 재진입:** 부모가 해석 도중 중단된 상태에서 자식이 같은 실행 노드에 도달하는 경우를 별도로 수집합니다. `Resolving` 상태만 보고 무조건 cycle 오류를 내거나 부모의 미완성 결과를 반환하지 않습니다. 재진입 허용·부분 publish·완료 충돌 정책은 Java 관찰과 실제 노드별 초기화 순서로 정해야 합니다.
- **실패/취소:** local member 해석처럼 오류 전에 publish된 상태와 미완료 value cache를 구분합니다. 실패나 nonterminal cancel 때 전부 rollback하거나 전부 성공 처리하지 않습니다. 이 경로의 Java 관찰이 없는 새 상황은 추가 oracle 대상으로 둡니다.
- **terminal 해제:** close/timeout/terminal cancel은 활성·중단 context와 evaluator-local node arena를 모두 해제합니다. `Program`을 공유하는 두 VM의 alias 초기화·node 해석·실패 후 cache가 섞이지 않아야 합니다.
- **진단:** 새 node identity를 error frame이나 authored source identity로 사용하지 않습니다. Stage 16 frame compression, power replay, boolean 실패의 현재 slot 값, predicate 실패의 호출 전 snapshot은 계속 유지합니다.

## 병렬 작업과 직렬 의존성

| 작업 | 독립적으로 진행 가능한 부분 | 직렬 의존성 |
| --- | --- | --- |
| Java oracle 확대 | 위 generic/let/lambda clone 후보와 취소·재시도 sequence 수집 | 공유 정책을 확정하기 전 결과를 읽어야 합니다. |
| 소유권 설계 | 현재 block/site/alias/function 연결과 GC root 목록 작성 | production 변경은 identity와 clone 정책 합의 뒤에 시작합니다. |
| 첫 identity 증분 | site ID와 root owner 도입, 기존 check 의미 보존 | 이후 local cache와 recursive node 생성이 이 API를 사용합니다. |
| local property cache | non-recursive inline/let/lambda control 구현·비교 | recursive control은 lazy child node identity 구현 뒤에 가능합니다. |
| generic 인수 계획 | immutable 계획·인수 환경의 표현 검토 | 실제 해석/치환은 owner 모델과 오류 순서 계약이 먼저 필요합니다. |
| 수명주기 검증 | 테스트 입력·Host scheduling 계획 작성 | 동작 테스트는 owner/arena API가 안정된 뒤 연결합니다. |
| 최종 회귀·플랫폼 | 기존 evidence 검사 도구 점검 | production freeze 이후 정확한 소스·artifact로 실행합니다. |

동일한 `vm.rs`/`vm/typecheck.rs`에 여러 구현자가 동시에 상태 기계를 넣는 병렬화는 피합니다. oracle·소스 검토·lifecycle 입력 설계는 병렬로 진행할 수 있지만, clone 규칙과 ownership API는 한 번 정하고 구현을 직렬로 연결하는 편이 안전합니다.

## 수용 조건과 최소 첫 증분의 경계

**최소 첫 증분:** non-recursive alias 사용의 실행 owner를 도입하고, 독립 inline 두 사용·공유 let root·독립 lambda·일반 property 및 method 반복 실패 control을 원본 persistent sequence 그대로 비교합니다. GC 후 같은 owner의 cache가 남으며 다른 VM에는 영향을 주지 않는 구조 검사도 수행합니다. 재귀 control과 generic은 아직 실패 또는 미구현으로 명시합니다. 이 증분만으로 다음 단계 전체가 끝났다고 보고하지 않습니다.

**non-generic 소유권 단계 종료:** 보존된 control matrix 전체, 특히 재귀 `value` 여섯 번의 세 오류/세 성공이 원시 바이트로 일치해야 합니다. 같은 recursive block에 글로벌 플래그를 추가한 구현은 독립 사용·let 공유·깊이 control을 동시에 통과하지 못하므로 수용하지 않습니다.

**generic 확장 종료:** 원래 `recursive-generic-shadow` 입력을 동일 source/URI에서 새로 비교하고, 도달하지 않은 변화하는 인수 재귀는 유한 compilation으로 남아야 합니다. 실행되는 새 instantiation에 대해서는 타입 인수·shadowing·오류 순서·metadata를 별도 비교합니다. 남은 generic 조합은 명시적으로 기록합니다.

각 수용 단계에서 다음 공통 조건을 적용합니다.

- Stage 16 최종 선택 1,597개와 persistent 502개 호출, 실제 플랫폼 사례를 기준으로 기존 결과를 보존합니다. 기존 두 언어 실패와 regex 등의 플랫폼 실패는 성공으로 바꾸거나 삭제하지 않습니다. 최종 기준 수치는 Stage 16 봉인 기록과 대조합니다.
- Java baseline·source/runtime/artifact identity를 유지하고 모든 호출의 stdout/stderr/outcome을 raw bytes로 비교합니다. 실패한 중간 호출을 제외하거나 transcript를 정규화하지 않습니다.
- 매 instruction yield의 GC, 중첩 Host 재진입, stale completion, nonterminal cancel 후 재시도, terminal 해제, shared `Program`의 두 VM 격리를 검증합니다.
- 같은 깊이의 반복 종료 후 live node/slot graph가 안정된 기준선으로 돌아가는지 확인합니다. static root가 정당하게 보유하는 resolved graph와 유실된 임시 graph를 구분합니다. heap 수치를 임의로 느슨하게 바꾸지 않습니다.
- production freeze 이후 저장소의 기본 Rust 검사, 관련 Python/inventory freshness, fresh output의 실제 Node/browser 실험을 수행합니다. 개발 계약과 strict full gate를 구분합니다.
- local const retry gap, 원래 recursive generic gap, 새로 발견된 실패를 각각 추적합니다. 선택 사례 통과는 전체 타입·const·언어/API 또는 성능·메모리 목표 달성이 아닙니다.
