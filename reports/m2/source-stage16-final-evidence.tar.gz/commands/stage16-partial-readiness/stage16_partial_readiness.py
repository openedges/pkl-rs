"""Read-only preseal audit of complete available suites while full Java acquisition runs."""
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, 'tools')
import m2_class_lifecycle as classes
import m1_platforms as platforms
import package_stage16_final as seal
import stage16_package_common as c

root = Path.cwd()
base = root / 'target/m2'
baseline = seal.verify_baseline()
selection = c.load(root / 'tests/fixtures/m2/cases.json')
inventory = c.load(root / 'compatibility/m2-language.json')
manifest = c.load(root / 'compatibility/m2-class-lifecycle/manifest.json')
relations = {tuple(row['metamorphic_relation']['case_ids']) for row in inventory['cases']
             if 'metamorphic_relation' in row}
class_report = classes.check_report(base / 'class-lifecycle-stage16-final')
c.require(classes.contract_passes(class_report), 'persistent contract failed')
calls = [call for row in class_report['cases'] for call in row['observations']['comparisons']]
data = dict(selection_counts=dict(selected=len(selection['cases']),
    original_selected=baseline['selected_cases'],
    added_selected=len(selection['cases']) - baseline['selected_cases'], relations=len(relations)),
    class_counts=dict(unique_sequences=len(manifest['sequences']),
        sequence_executions=len(class_report['cases']), call_comparisons=len(calls)))
seal.verify_exploration_gap(data)
c.DIRECTORIES['platforms'] = base / 'platforms-stage16-final'
platform_report = c.load(c.DIRECTORIES['platforms'] / 'report.json')
platform_audit = c.platform_claims(platform_report, platforms)
c.require(platform_report['source_stability'] and platforms.contract_matches(platform_report['comparisons']),
          'platform architecture contract failed')
validation = c.validation_report(base / 'validation-stage16-final')
result = dict(scope='Read-only partial readiness audit. Full language report and final source-to-commit sealing remain separate required steps.',
    implementation_commit='540d81818a0c5c18fab6d6354356621dfea9f962',
    full_language_report_present=(base / 'language-stage16-final/report.json').is_file(),
    captured_binaries_executed=False, baseline_inventory_and_repair_history_verified=True,
    selection=data['selection_counts'], classes=data['class_counts'],
    requirements=c.semantic_inventory_preservation(seal.baseline_json('compatibility/m2-language.json'), inventory),
    mappings=c.semantic_mapping_preservation(seal.baseline_json('compatibility/m2-mappings.json'),
                                            c.load(root / 'compatibility/m2-mappings.json')),
    exploratory_raw_discovery=data['exploration']['summary']['final_discovery_replay'],
    exploratory_persistent=data['exploration']['summary']['persistent_exploration'],
    exploration_archive=data['exploration']['archive'], platform_audit=platform_audit,
    validation={key: validation[key] for key in ['rust_passed', 'rust_intentionally_ignored', 'python_passed']},
    helper_sha256={name: c.sha(base / name) for name in
                   ['stage16_partial_readiness.py', 'package_stage16_final.py', 'stage16_package_common.py']})
c.write_new(base / 'stage16-partial-readiness.json', result)
print(json.dumps(result, sort_keys=True))
