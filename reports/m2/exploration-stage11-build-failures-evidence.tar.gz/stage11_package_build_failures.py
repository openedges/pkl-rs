"""Preserve the legacy lifecycle example compile failure and superseded runtime acquisition."""
from pathlib import Path
import sys,json,shutil
sys.path.insert(0,'tools')
import oracle,evidence
out=Path('target/m2/stage11-build-failures-review-01');out.mkdir(exist_ok=False)
for name in ['lifecycle-stage11-final','runtime-stage11-final']:
 shutil.copytree(Path('target/m2')/name,out/name)
summary=dict(schema_version=1,scope='Failed/superseded pre-final acquisition retained as exploration; not current passing validation.',failed_lifecycle=dict(directory='lifecycle-stage11-final',reason='The legacy lifecycle_probe.rs explicit Member literal omitted the newly required fixed:false field, so candidate compilation failed and no lifecycle modes executed.',excluded='lifecycle-stage11-final/build/* contains cargo build cache only; source snapshots, raw cargo/javac/rustc captures, oracle and report remain.'),superseded_runtime=dict(directory='runtime-stage11-final',reason='Acquisition captured the legacy lifecycle example source before its missing field was corrected; final runtime reacquisition uses runtime-stage11-final-02.'),final_reacquisitions=['lifecycle-stage11-final-02','runtime-stage11-final-02'],main_exploration_archive=dict(path='reports/m2/exploration-stage11-evidence.tar.gz',sha256=oracle.sha256(Path('reports/m2/exploration-stage11-evidence.tar.gz'))))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copy2('target/m2/stage11_package_build_failures.py',out/'stage11_package_build_failures.py');evidence.create(out,Path('reports/m2/exploration-stage11-build-failures-evidence.tar.gz'),['lifecycle-stage11-final/build/*']);print(json.dumps(summary,indent=2))
