"""Package already verified original CI ZIPs, metadata and repeatable checks."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

HERE=Path(__file__).resolve().parent
NAMES={'m1':'m1-experiment-evidence','m2':'m2-language-evidence'}


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--acquired',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    acquired,package=args.acquired.resolve(),args.output.resolve()
    checked=acquired/'verification/verification.json'
    result=json.loads(checked.read_bytes())
    for kind,name in NAMES.items():
        if sha(acquired/kind/'artifact.zip')!=result['artifacts'][kind]['sha256']:
            raise ValueError('Verified ZIP changed before packaging: '+name)
    for name,digest in result['verifiers'].items():
        if sha(HERE/name)!=digest:raise ValueError('Verifier changed after acquisition: '+name)
    package.mkdir(parents=True,exist_ok=False)
    for name in ['artifacts','metadata','verification']:(package/name).mkdir()
    payloads={}
    for kind,name in NAMES.items():
        archive=acquired/kind/'artifact.zip'
        shutil.copyfile(archive,package/'artifacts'/(name+'.zip'))
        with zipfile.ZipFile(archive)as zipped:
            files=[row for row in zipped.infolist()if not row.is_dir()]
            payloads[kind]=dict(zip_sha256=sha(archive),zip_bytes=archive.stat().st_size,
                               files=len(files),uncompressed_bytes=sum(row.file_size for row in files))
        stderr=acquired/kind/'artifact.zip.stderr.bin'
        if stderr.exists():shutil.copyfile(stderr,package/'metadata'/(kind+'-download.stderr.bin'))
    for name in ['run','jobs','artifacts']:
        shutil.copyfile(acquired/'m2'/(name+'.json'),package/'metadata'/(name+'.json'))
    polls=sorted(acquired.glob('poll-*'))
    if polls:
        (package/'metadata/polls').mkdir()
        for path in polls:
            if path.is_file():shutil.copyfile(path,package/'metadata/polls'/path.name)
    shutil.copyfile(checked,package/'verification/verification.json')
    for name in ['verify.py','m1_checks.py','test_verify.py','unpack_and_verify.py','package.py']:
        shutil.copyfile(HERE/name,package/'verification'/name)
    readme=f'''# Exact-commit CI evidence

Repository: `{result['repository']}`
Commit: `{result['commit']}`
Run: https://github.com/{result['repository']}/actions/runs/{result['run_id']}

The original GitHub artifact ZIPs are retained byte-for-byte. Their SHA-256 digests
match GitHub metadata. Raw language comparisons, identifier regeneration and M1
native/Node/browser, frontend, runtime and lifecycle evidence were independently
checked against exact committed source snapshots. Recorded failures and incomplete
full language/API/performance requirements remain failures and incomplete scope.
See `verification/verification.json` for all outcomes and source/file counts.

## Repeat the independent check

Use Python 3.12 or newer and Git. A repository with the exact commit object above
and its pinned `external/pkl` submodule commit is required. No Java, Rust, Node or
browser process is executed by the verifier. The working tree can be elsewhere;
recorded absolute CI source URIs are preserved for raw comparison.

From this package directory, choose a fresh output directory:

```sh
python3 verification/unpack_and_verify.py --repository-root /path/to/pkl-rs --output /tmp/pkl-ci-recheck
```

The helper checks the complete package inventory, GitHub ZIP digests and safe ZIP
paths, then imports only captured project verifier sources already checked against
the exact Git commit. Python bytecode writes are disabled. Source sets, case and
scenario counts, and identifier interval counts come from frozen contracts.

`package-manifest.json` hashes every package file except itself. Extracted payload,
the duplicate verified-source overlay and empty committed-path index are omitted;
the two original ZIPs retain all captured payload bytes.
'''
    (package/'README.md').write_text(readme)
    summary=dict(commit=result['commit'],run_id=result['run_id'],package=str(package),
                 artifact_payloads=payloads,exact_source_snapshot_copies=result['exact_source_snapshot_copies'],
                 unique_source_files=result['unique_source_files'],m2=result['m2'],m1=result['m1'])
    write(package/'package-summary.json',summary)
    files={str(path.relative_to(package)):dict(bytes=path.stat().st_size,sha256=sha(path))
           for path in sorted(package.rglob('*'))if path.is_file()}
    manifest=dict(schema_version=1,commit=result['commit'],run_id=result['run_id'],
                  file_count=len(files)+1,hashed_file_count=len(files),
                  scope='All package files except this manifest; original ZIPs retain all extracted artifact payloads.',files=files)
    write(package/'package-manifest.json',manifest)
    print(json.dumps(dict(package=str(package),file_count=len(files)+1,hashed_file_count=len(files),
                         artifact_payloads=payloads,package_manifest_sha256=sha(package/'package-manifest.json')),sort_keys=True))


if __name__=='__main__':main()
