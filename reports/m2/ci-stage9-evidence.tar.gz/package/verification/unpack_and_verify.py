"""Rerun the packaged raw-evidence check without executing captured binaries."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True,help='new directory for unpacking and verification')
    args=parser.parse_args()
    package=HERE.parent
    output=args.output.resolve()
    output.mkdir(parents=True,exist_ok=False)
    summary=json.loads((HERE/'verification.json').read_bytes())
    inventory=json.loads((package/'package-manifest.json').read_bytes())
    spec=importlib.util.spec_from_file_location('packaged_ci_verifier',HERE/'verify.py')
    verifier=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    observed={str(path.relative_to(package))for path in package.rglob('*')if path.is_file()and path.name!='package-manifest.json'}
    if observed!=set(inventory['files']):raise ValueError('Packaged file inventory incomplete')
    for name,row in inventory['files'].items():
        path=package/verifier.relative(name)
        if path.stat().st_size!=row['bytes']or verifier.sha(path)!=row['sha256']:
            raise ValueError('Packaged evidence changed: '+name)
    for kind,name in verifier.NAMES.items():
        base=output/kind
        base.mkdir()
        for label in ['run','jobs','artifacts']:
            shutil.copyfile(package/'metadata'/(label+'.json'),base/(label+'.json'))
        archive=package/'artifacts'/(name+'.zip')
        shutil.copyfile(archive,base/'artifact.zip')
        verifier.metadata(base,kind,summary['commit'],summary['run_id'])
        verifier.safe_extract(archive,base/'artifact')
    command=[sys.executable,str(HERE/'verify.py'),'verify','--commit',summary['commit'],
             '--run',str(summary['run_id']),'--repo',summary['repository'],
             '--repository-root',str(args.repository_root.resolve()),'--output',str(output/'verification'),
             '--m1-directory',str(output/'m1'),'--m2-directory',str(output/'m2')]
    return subprocess.run(command,check=False).returncode


if __name__=='__main__':sys.exit(main())
