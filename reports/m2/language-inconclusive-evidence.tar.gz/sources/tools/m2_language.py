#!/usr/bin/env python3
"""Raw Java/Rust M2 language evidence; selected probes never close the full gate."""
from __future__ import annotations

import argparse
from collections import Counter
import json
import os
from pathlib import Path
import subprocess
import sys

import m2_manifest as contract
import oracle

ROOT = contract.ROOT


def capture(command, directory, name, environment=None, timeout=120):
    try:
        process = subprocess.run(command, cwd=ROOT, env=environment, capture_output=True, timeout=timeout)
        row = dict(command=[str(x) for x in command], exit_code=process.returncode, timed_out=False)
        stdout, stderr = process.stdout, process.stderr
    except subprocess.TimeoutExpired as error:
        stdout, stderr = error.stdout or b'', error.stderr or b''
        row = dict(command=[str(x) for x in command], exit_code=None, timed_out=True)
    for channel, data in [('stdout', stdout), ('stderr', stderr)]:
        (directory / f'{name}.{channel}.bin').write_bytes(data)
        row[channel + '_sha256'] = contract.digest(data)
    (directory / f'{name}.process.json').write_bytes(contract.encoded(row))
    return row


def status(case, java, rust, java_stdout, java_stderr, rust_stdout, rust_stderr):
    expected = 0 if case['expected_outcome'] == 'success' else 1
    if java['timed_out'] or java['exit_code'] != expected:
        return 'oracle-error'
    if expected == 0 and java_stderr:
        return 'oracle-error'
    if expected == 1 and (java_stdout or not java_stderr.startswith('–– Pkl Error ––\n'.encode())):
        return 'oracle-error'
    if rust['timed_out']:
        return 'candidate-timeout'
    if (java['exit_code'], java_stdout, java_stderr) == (rust['exit_code'], rust_stdout, rust_stderr):
        return 'pass'
    return 'mismatch'


def source_paths():
    paths = set(contract.INPUTS) | {'tools/m2_manifest.py', 'tools/m2_language.py',
            'tools/m2_generate.py', 'tools/java/M2LanguageProbe.java', str(contract.MANIFEST), 'tools/oracle.py', 'oracle.lock.json',
            'Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml'}
    for directory, pattern in [('crates', '*.rs'), ('crates', 'Cargo.toml'), ('tests/fixtures/m2', '*')]:
        paths.update(str(p.relative_to(ROOT)) for p in (ROOT / directory).rglob(pattern) if p.is_file())
    return sorted(paths)


def execute(output: Path, candidate: Path | None):
    manifest = contract.current_manifest()
    metadata = oracle.ensure_oracle(ROOT, fetch=False)
    output.mkdir(parents=True, exist_ok=False)
    initial = {path: oracle.sha256(ROOT / path) for path in source_paths()}
    for path in initial:
        destination = output / 'sources' / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((ROOT / path).read_bytes())
    (output / 'oracle.json').write_bytes(contract.encoded(metadata))
    compiler = capture(['rustc', '--version', '--verbose'], output, 'rustc')
    if compiler['exit_code'] != 0:
        raise ValueError('cannot identify Rust compiler; raw evidence preserved')
    build = None
    if candidate is None:
        build = capture(['cargo', 'build', '-p', 'pkl-runtime', '--example', 'language_probe',
                         '--locked', '--release', '--target-dir', str(ROOT / 'target')],
                        output, 'build', timeout=300)
        if build['exit_code'] != 0:
            raise ValueError('candidate build failed; raw build evidence preserved')
        candidate = ROOT / 'target/release/examples/language_probe'
    if not candidate.is_file():
        raise ValueError('candidate artifact missing')
    artifacts = output / 'artifacts'
    artifacts.mkdir()
    frozen = artifacts / 'language_probe'
    frozen.write_bytes(candidate.read_bytes())
    frozen.chmod(0o755)
    candidate_hash = oracle.sha256(candidate)
    classes = artifacts / 'java'
    classes.mkdir()
    javac = Path(metadata['java']).with_name('javac')
    compile_row = capture([str(javac), '-encoding', 'UTF-8', '-cp', metadata['artifact'],
                           '-d', str(classes), str(ROOT / 'tools/java/M2LanguageProbe.java')],
                          output, 'javac', metadata['environment'])
    if compile_row['exit_code'] != 0:
        raise ValueError('Java oracle compile failed; raw evidence preserved')
    java_base = list(metadata['command'][:-1])
    java_base[-1] += os.pathsep + str(classes)
    results = []
    selected = [row for row in manifest['cases'] if row.get('adapter') == 'language-api-string']
    for case in selected:
        directory = output / 'cases' / case['id']
        directory.mkdir(parents=True)
        source = ROOT / case['input']
        (directory / 'input.pkl').write_bytes(source.read_bytes())
        arguments = [str(source), case['expression']]
        java = capture([*java_base, 'M2LanguageProbe', *arguments], directory, 'java', metadata['environment'])
        rust = capture([str(frozen), *arguments], directory, 'rust', metadata['environment'])
        outcome = status(case, java, rust, *( (directory / f'{name}.{channel}.bin').read_bytes()
                                             for name in ('java', 'rust') for channel in ('stdout', 'stderr')))
        results.append(dict(id=case['id'], status=outcome, java=java, rust=rust))
        print(f"{case['id']}: {outcome}", flush=True)
    relations = check_relations(manifest, output)
    report = dict(schema_version=1, scope=manifest['comparison_boundary'],
                  inventory_counts=manifest['counts'], selected_count=len(selected),
                  oracle=metadata, candidate=dict(path=str(candidate), sha256=candidate_hash,
                                 source_binding='recorded-build' if build else 'unbound-caller-supplied', build=build),
                  javac=dict(path=str(javac), sha256=oracle.sha256(javac)),
                  source_sha256=initial,
                  source_stability=all((ROOT / path).is_file() and oracle.sha256(ROOT / path) == value
                                       for path, value in initial.items()),
                  artifact_stability=candidate.is_file() and oracle.sha256(candidate) == candidate_hash,
                  results=results, metamorphic_results=relations,
                  status_counts=dict(Counter(row['status'] for row in results)),
                  full_gate_failures=contract.full_gate_failures(manifest, results))
    report['evidence_sha256'] = {str(path.relative_to(output)): oracle.sha256(path)
                                 for path in sorted(output.rglob('*')) if path.is_file()}
    (output / 'report.json').write_bytes(contract.encoded(report))
    check_report(output)
    return report


def check_relations(manifest, directory):
    relations = {}
    for row in manifest['cases']:
        if 'metamorphic_relation' in row:
            relation = row['metamorphic_relation']
            relations[tuple(relation['case_ids'])] = relation
    results = []
    for ids, relation in sorted(relations.items()):
        statuses = {}
        for runtime in ('java', 'rust'):
            captures = []
            for identifier in ids:
                case = directory / 'cases' / identifier
                process = json.loads((case / f'{runtime}.process.json').read_bytes())
                captures.append((process['exit_code'], process['timed_out'],
                                 (case / f'{runtime}.stdout.bin').read_bytes(),
                                 (case / f'{runtime}.stderr.bin').read_bytes()))
            statuses[runtime] = all(row[0:2] == (0, False) and row[3] == b'' for row in captures) and len(set(captures)) == 1
        results.append(dict(**relation, runtimes=statuses, status='pass' if all(statuses.values()) else 'mismatch'))
    return results


def verify_oracle(directory: Path, report):
    """Recheck immutable baseline, JVM options and environment from snapshots."""
    metadata = report['oracle']
    lock_path = directory / 'sources/oracle.lock.json'
    locked = json.loads(lock_path.read_bytes())
    refs = oracle.read_properties((directory / 'sources/references.lock').read_text())
    if json.loads((directory / 'oracle.json').read_bytes()) != metadata:
        raise ValueError('oracle metadata differs from raw record')
    if (metadata['profile'] != 'reference' or metadata['version'] != locked['version']
            or metadata['lock_sha256'] != oracle.sha256(lock_path)
            or metadata['artifact_sha256'] != locked['artifact']['sha256']
            or metadata['artifact_url'] != locked['artifact']['url']
            or metadata['source'] != locked['source']
            or refs['baseline.pkl'] != locked['version']
            or refs['pkl.revision'] != locked['source']['revision']):
        raise ValueError('oracle baseline provenance differs from pins')
    environment = metadata['environment']
    if (set(environment) != {'PATH', 'HOME', 'TMPDIR', 'TMP', 'TEMP', 'LC_ALL', 'LANG', 'TZ', 'TERM', 'NO_COLOR', 'COLUMNS'}
            or environment['LC_ALL'] != 'C' or environment['LANG'] != 'C'
            or environment['TZ'] != 'UTC' or environment['TERM'] != 'dumb'
            or environment['NO_COLOR'] != '1' or environment['COLUMNS'] != '80'
            or not environment['TMPDIR'] == environment['TMP'] == environment['TEMP']):
        raise ValueError('oracle environment differs from controlled contract')
    options = [*locked['jvm_options'], '-Duser.home=' + environment['HOME'],
               '-Djava.io.tmpdir=' + environment['TMPDIR']]
    if metadata['command'] != [metadata['java'], *options, '-cp', metadata['artifact'], 'org.pkl.cli.Main']:
        raise ValueError('oracle JVM options or classpath differ from pins')
    for key, value in locked['jdk']['properties'].items():
        if metadata['jdk']['properties'].get(key) != value:
            raise ValueError('oracle JDK runtime differs from pins')
    for key in ('executable_sha256', 'runtime_modules_sha256', 'release_sha256'):
        value = metadata['jdk'].get(key, '')
        if len(value) != 64 or any(ch not in '0123456789abcdef' for ch in value):
            raise ValueError('missing exact JDK identity hash')


def check_report(directory: Path):
    report = json.loads((directory / 'report.json').read_bytes())
    manifest = contract.current_manifest()
    verify_oracle(directory, report)
    if not report['source_stability'] or not report['artifact_stability']:
        raise ValueError('sources or artifact changed during evidence acquisition')
    inventory = report['evidence_sha256']
    observed = {str(p.relative_to(directory)) for p in directory.rglob('*')
                if p.is_file() and p != directory / 'report.json'}
    if not inventory or set(inventory) != observed:
        raise ValueError('evidence file coverage incomplete')
    for relative, expected in inventory.items():
        if oracle.sha256(directory / relative) != expected:
            raise ValueError('evidence bytes changed: ' + relative)
    if set(report['source_sha256']) != set(source_paths()):
        raise ValueError('source provenance coverage incomplete')
    for path, expected in report['source_sha256'].items():
        if oracle.sha256(directory / 'sources' / path) != expected:
            raise ValueError('source snapshot changed: ' + path)
    if (directory / 'sources' / contract.MANIFEST).read_bytes() != contract.encoded(manifest):
        raise ValueError('recorded M2 manifest differs from current required contract')
    if oracle.sha256(directory / 'artifacts/language_probe') != report['candidate']['sha256']:
        raise ValueError('candidate artifact identity differs')
    binding = report['candidate'].get('source_binding')
    if binding == 'recorded-build':
        build = json.loads((directory / 'build.process.json').read_bytes())
        if build != report['candidate']['build'] or build['exit_code'] != 0 or build['timed_out']:
            raise ValueError('candidate recorded build differs or failed')
    elif binding != 'unbound-caller-supplied' or report['candidate'].get('build') is not None:
        raise ValueError('invalid source/artifact binding claim')
    selected = {row['id']: row for row in manifest['cases'] if row.get('adapter') == 'language-api-string'}
    ids = [row['id'] for row in report['results']]
    if set(ids) != set(selected) or len(ids) != len(selected) or report['selected_count'] != len(selected):
        raise ValueError('selected execution coverage incomplete or duplicate')
    for row in report['results']:
        case = selected[row['id']]
        folder = directory / 'cases' / row['id']
        if oracle.sha256(folder / 'input.pkl') != case['input_sha256']:
            raise ValueError('case input differs: ' + row['id'])
        for runtime in ('java', 'rust'):
            process = json.loads((folder / f'{runtime}.process.json').read_bytes())
            if process != row[runtime]:
                raise ValueError('process metadata differs: ' + row['id'])
            if process['command'][-2:] != [str(ROOT / case['input']), case['expression']]:
                raise ValueError('oracle/candidate input URI or expression differs: ' + row['id'])
            for channel in ('stdout', 'stderr'):
                if oracle.sha256(folder / f'{runtime}.{channel}.bin') != process[channel + '_sha256']:
                    raise ValueError('process raw hash differs: ' + row['id'])
        java_base = list(report['oracle']['command'][:-1])
        java_base[-1] += os.pathsep + str(Path(row['rust']['command'][0]).parent / 'java')
        if row['java']['command'] != [*java_base, 'M2LanguageProbe', str(ROOT / case['input']), case['expression']]:
            raise ValueError('case Java command changes pinned oracle options/classpath')
        outcome = status(case, row['java'], row['rust'], *((folder / f'{name}.{channel}.bin').read_bytes()
                                    for name in ('java', 'rust') for channel in ('stdout', 'stderr')))
        if row['status'] != outcome:
            raise ValueError('raw comparison status differs: ' + row['id'])
    if report['metamorphic_results'] != check_relations(manifest, directory):
        raise ValueError('metamorphic results differ')
    if report['status_counts'] != dict(Counter(row['status'] for row in report['results'])):
        raise ValueError('comparison counts differ')
    if report['full_gate_failures'] != contract.full_gate_failures(manifest, report['results']):
        raise ValueError('full gate accounting differs')
    return report


def subset_passes(report):
    return all(row['status'] == 'pass' for row in report['results']) and all(
        row['status'] == 'pass' for row in report['metamorphic_results'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--output', type=Path)
    action.add_argument('--verify-report', type=Path, help='integrity only; preserves recorded compatibility failures')
    action.add_argument('--verify-subset', type=Path, help='integrity and every selected probe must pass')
    action.add_argument('--verify-full', type=Path, help='strict full M2 language completion')
    parser.add_argument('--candidate', type=Path, help='override the default recorded release build; caller-supplied artifact has no verified source binding')
    args = parser.parse_args()
    report = execute(args.output.resolve(), args.candidate.resolve() if args.candidate else None) if args.output else check_report(
        (args.verify_report or args.verify_subset or args.verify_full).resolve())
    print(json.dumps(dict(selected=report['status_counts'], full_gate_failures=len(report['full_gate_failures'])), sort_keys=True))
    if args.verify_report:
        return 0
    return int(not subset_passes(report) or bool(args.verify_full and (report['full_gate_failures']
                     or report['candidate']['source_binding'] != 'recorded-build')))


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        print(f'M2 language error: {error}', file=sys.stderr)
        sys.exit(1)
