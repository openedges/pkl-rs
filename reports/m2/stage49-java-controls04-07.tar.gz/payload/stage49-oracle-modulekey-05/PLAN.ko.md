# Stage49 custom resolveUri 실제 관찰

기존01–04 및 원래212개는 재실행하지 않는다. 새05는 ModuleSource.uri와 create(uri,contents)의 fresh evaluator 대조다. custom key는 factory request/selected/resolved URI를 구분하며 선언된 relative·absolute import operand에만 명시 override 결과를 돌려준다. getter는 실제 resolveUri 호출에서만 기록하고 입력·반환 URI를 독립 Java UTF16/UTF8로 보존한다.

contents wrapper가 delegate override를 호출하는지는 원본 CachedModuleKey와 실제 API로 관찰하며 예상 결과를 helper가 대신 만들지 않는다. child의 각 반환 tag는 사전 구성 Host source 입력으로 서로 다르다. main/primary 함수 호출은 원래 alias query 실패를 반복하지 않게 모듈에 작성한다. 예정48 API(2 profile×6×2 evaluator×2 fresh JVM), GC는 요청만 기록한다. Driver mock preflight 종료 뒤 Java를 실행한다.
