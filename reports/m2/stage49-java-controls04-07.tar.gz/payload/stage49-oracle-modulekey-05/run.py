from pathlib import Path
import collections,datetime,hashlib,json,os,platform,re,shutil,stat,subprocess,sys,time
sys.dont_write_bytecode=True
R=Path('/Users/cody.ij.hwang/Projects/pkl-rs');O=Path(__file__).parent.resolve();sys.path.insert(0,str(R/'tools'));import oracle
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:(p.parent.mkdir(parents=True,exist_ok=True),p.write_text(json.dumps(v,indent=2)+'\n'))
def capture(name,command,cwd,env,timeout=90):
 target=O/name;target.mkdir(parents=True,exist_ok=False);row={'command':command,'cwd':str(cwd),'environment':env,'parentPid':os.getpid(),'startedUnixNs':time.time_ns()}
 with(target/'stdout.bin').open('wb')as out,(target/'stderr.bin').open('wb')as err:
  proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=out,stderr=err);row['pid']=proc.pid;write(target/'launch.json',row)
  try:row['exitCode']=proc.wait(timeout=timeout);row['timedOut']=False
  except subprocess.TimeoutExpired:proc.kill();row['exitCode']=proc.wait();row['timedOut']=True
 row['finishedUnixNs']=time.time_ns();row['stdoutSha256']=sha(target/'stdout.bin');row['stderrSha256']=sha(target/'stderr.bin');write(target/'terminal.json',row);return row
lock=json.loads((R/'oracle.lock.json').read_bytes());jar=R/'.cache/oracle/pkl-tools-0.32.0.jar';release=oracle.verify_artifact(jar,lock);env=oracle.deterministic_environment(O/'identity')
identity=capture('jdk-identity',['/usr/bin/java','-XshowSettings:properties','-version'],R,env)
props=dict(re.findall(r'^\s+([\w.]+) = (.*)$',(O/'jdk-identity/stderr.bin').read_text(),re.MULTILINE));assert identity['exitCode']==0
for key,value in lock['jdk']['properties'].items():assert props.get(key)==value,(key,props.get(key),value)
jdkhome=Path(props['java.home']);jdk={'executable':'/usr/bin/java','executableSha256':sha(Path('/usr/bin/java')),'runtimeModulesSha256':sha(jdkhome/'lib/modules'),'releaseSha256':sha(jdkhome/'release'),'properties':{k:props[k]for k in ['java.vendor','java.version','java.runtime.version','java.vm.name','java.vm.version','java.home','os.name','os.arch','os.version']},'actualProcess':identity}
write(O/'profile.json',{'jar':str(jar),'jarSha256':sha(jar),'jdk':jdk,'release':release,'environment':env,'jvmOptions':lock['jvm_options'],'sourcePin':'e51fb2f91774265666f94980ec630db794a4db2d;rootinitializedverifiedreferences; copiedexplicitupstreamsourcehashes, noBgitcommand','worktreeHeadDeclaredByRoot':'5e68c4b (root declaration; no B Git command)','evaluatorProfile':'Original public Evaluator.evaluateExpressionString with path, uri, create(uri,contents), text(repl:text), and actual StandardSecurityManager; preconfigured/cache=null/colorfalse/emptyenvprops/powertrue. TwoevaluatorsequentialperJVM, twofreshJVMrepeatspercase. Defaultkeysreturnedunchanged byfactoryobserver; customkeyprofileexplicit.','trustProfile':'SeparatepublicSecurityManagers.defaultTrustLevels/checkImportModule calls;twofreshJVMs/twobatches, noevaluatorandnojar/networkIO.','eventEncodings':'Newhelper independentlycapturesJavaUTF16andJavaUTF8 forallevents; originalJava06separatelyUTF8only.'})
(O/'classes').mkdir(exist_ok=False)
compiled=capture('javac',['/usr/bin/javac','-cp',str(jar),'-d',str(O/'classes'),str(O/'AdmissionProbe.java'),str(O/'TrustProbe.java')],R,env)
if compiled['exitCode']!=0:write(O/'compile-failure.json',compiled);raise SystemExit(compiled['exitCode'])
upstream=['pkl-core/src/main/java/org/pkl/core/runtime/ReaderBase.java','pkl-core/src/main/java/org/pkl/core/ModuleSource.java','pkl-core/src/main/java/org/pkl/core/util/IoUtils.java','pkl-core/src/main/java/org/pkl/core/ast/expression/unary/ImportNode.java','pkl-core/src/main/java/org/pkl/core/ast/builder/AstBuilder.java','pkl-core/src/main/java/org/pkl/core/runtime/ModuleCache.java','pkl-core/src/main/java/org/pkl/core/runtime/ModuleResolver.java','pkl-core/src/main/java/org/pkl/core/runtime/VmUtils.java','pkl-core/src/main/java/org/pkl/core/runtime/VmLanguage.java','pkl-core/src/main/java/org/pkl/core/module/ModuleKeys.java','pkl-core/src/main/java/org/pkl/core/module/ModuleKeyFactories.java','pkl-core/src/main/java/org/pkl/core/module/ModuleKey.java','pkl-core/src/main/java/org/pkl/core/module/ModuleKeyFactory.java','pkl-core/src/main/java/org/pkl/core/module/ResolvedModuleKey.java','pkl-core/src/main/java/org/pkl/core/module/ResolvedModuleKeys.java','pkl-core/src/main/java/org/pkl/core/SecurityManagers.java','pkl-core/src/main/java/org/pkl/core/EvaluatorImpl.java','stdlib/ref.pkl','stdlib/base.pkl','stdlib/json.pkl']
for rel in upstream:
 p=O/'upstream'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/'external/pkl'/rel,p)
for rel in ['tools/oracle.py','oracle.lock.json','references.lock']:
 p=O/'tool-sources'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/rel,p)
cases=json.loads((O/'cases.json').read_bytes());inputs=[O/n for n in ['AdmissionProbe.java','TrustProbe.java','prepare.py','run.py','cases.json','input-paths.json','trust-uris.txt','profile.json']]+[p for p in(O/'classes').iterdir()if p.is_file()]+[O/'upstream'/rel for rel in upstream]+[O/'tool-sources'/rel for rel in ['tools/oracle.py','oracle.lock.json','references.lock']]+[jar]
def snapshot(case):
 work=Path(case['workspace']);result={}
 for rel in case['inputPaths']:
  p=work/rel
  if p.is_symlink():result[rel]={'kind':'symlink','target':os.readlink(p),'targetBytesSha256':sha(p),'mode':stat.S_IMODE(p.lstat().st_mode)}
  else:result[rel]={'kind':'regular','sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)}
 return result
for case in cases:inputs.extend(Path(case['workspace'])/rel for rel in case['inputPaths'])
before={str(p):sha(p)for p in inputs};work_before={c['id']:snapshot(c)for c in cases};write(O/'inputs-before.json',before);write(O/'workspaces-before.json',work_before)
records=[];observations=[];differences=[]
def units_raw(data):assert len(data)%2==0;return data.decode('utf-16-be','surrogatepass').encode('utf-8','replace')
for case in cases:
 repeats=[];work=Path(case['workspace'])
 for repeat in [0,1]:
  private=O/'runtime-private'/case['id']/str(repeat);(private/'home').mkdir(parents=True);(private/'tmp').mkdir();actualenv={**env,'HOME':str(private/'home'),'TMPDIR':str(private/'tmp'),'TMP':str(private/'tmp'),'TEMP':str(private/'tmp')};target=O/'cases'/case['id']/str(repeat)
  command=['/usr/bin/java',*lock['jvm_options'],'-Duser.home='+str(private/'home'),'-Djava.io.tmpdir='+str(private/'tmp'),'-cp',str(O/'classes')+':'+str(jar),'AdmissionProbe',str(work),str(target/'calls'),case['mode'],case['entry']]
  rec=capture(str(target.relative_to(O)),command,work,actualenv);rec.update(case=case['id'],repeat=repeat,workspaceBefore=work_before[case['id']],workspaceAfter=snapshot(case));write(target/'process.json',rec);records.append(rec);calls=[];session_events=[]
  for session in [0,1]:
   d=target/'calls'/('session-'+str(session));evals=[op for op in case['operations']if op['kind']=='evaluate']
   for index,op in enumerate(evals):
    prefix='outer-'+str(index);path=d/prefix;required=[suffix for suffix in ['status.bin','stdout.bin','stderr.bin','stdout.code-units.bin','stderr.code-units.bin','error-class.bin','message-null.bin','counters-before.bin','counters-after.bin']if not(path.with_name(prefix+'.'+suffix)).is_file()]
    row={'session':session,'index':index,'expression':op['expression'],'source':op['source'],'rawPrefix':str(path.relative_to(O)),'missingFields':required}
    if required:row['status']='unexecuted'
    else:
     status=(d/(prefix+'.status.bin')).read_bytes();assert status in[b'success\n',b'error\n'];row.update(status=status.decode(),errorClass=(d/(prefix+'.error-class.bin')).read_text(),messageNull=(d/(prefix+'.message-null.bin')).read_text(),countersBefore=(d/(prefix+'.counters-before.bin')).read_text(),countersAfter=(d/(prefix+'.counters-after.bin')).read_text())
     for channel in ['stdout','stderr']:
      raw=(d/(prefix+'.'+channel+'.bin')).read_bytes();u=(d/(prefix+'.'+channel+'.code-units.bin')).read_bytes();assert units_raw(u)==raw;row[channel+'Utf8Hex']=raw.hex();row[channel+'Utf16BEHex']=u.hex()
    calls.append(row)
   if(d/'counters.bin').is_file():
    counters=(d/'counters.bin').read_text();event_count=int(next(line.split('=')[1]for line in counters.splitlines()if line.startswith('event=')));eventrows=[]
    for index in range(event_count):
     raw=(d/f'event-{index}.bin').read_bytes();u=(d/f'event-{index}.code-units.bin').read_bytes();assert units_raw(u)==raw;eventrows.append({'index':index,'utf8Hex':raw.hex(),'utf16BEHex':u.hex(),'rawPrefix':str((d/f'event-{index}').relative_to(O))})
    session_events.append({'session':session,'counters':counters,'events':eventrows})
  observations.append({'case':case['id'],'repeat':repeat,'calls':calls,'sessions':session_events});repeats.append({str(p.relative_to(target/'calls')):sha(p)for p in(target/'calls').rglob('*.bin')}if(target/'calls').is_dir()else{})
  write(O/'progress.json',{'completedJvmProcesses':len(records),'lastCase':case['id'],'repeat':repeat,'counts':dict(collections.Counter(c['status']for c in calls))});print(json.dumps(json.loads((O/'progress.json').read_bytes())),flush=True)
 differences.append({'case':case['id'],'rawPathDifferences':[p for p in sorted(repeats[0].keys()|repeats[1].keys())if repeats[0].get(p)!=repeats[1].get(p)]})
# Separate public security-manager calls: not evaluator sessions and not language-result comparisons.
trust_records=[];trust_observations=[];trust_repeats=[]
for repeat in []:
 private=O/'runtime-private/trust'/str(repeat);(private/'home').mkdir(parents=True);(private/'tmp').mkdir();actualenv={**env,'HOME':str(private/'home'),'TMPDIR':str(private/'tmp'),'TMP':str(private/'tmp'),'TEMP':str(private/'tmp')};target=O/'trust'/str(repeat)
 command=['/usr/bin/java',*lock['jvm_options'],'-Duser.home='+str(private/'home'),'-Djava.io.tmpdir='+str(private/'tmp'),'-cp',str(O/'classes')+':'+str(jar),'TrustProbe',str(target/'calls'),str(O/'trust-uris.txt')]
 rec=capture(str(target.relative_to(O)),command,O,actualenv);trust_records.append(rec)
 for batch in [0,1]:
  d=target/'calls'/('batch-'+str(batch));count=int((d/'calls.bin').read_text())if(d/'calls.bin').is_file()else 0;rows=[]
  for i in range(count):
   prefix='outer-'+str(i);row={'index':i,'kind':(d/(prefix+'.kind.bin')).read_text(),'from':(d/(prefix+'.from.bin')).read_text(),'to':(d/(prefix+'.to.bin')).read_text(),'status':(d/(prefix+'.status.bin')).read_text(),'errorClass':(d/(prefix+'.error-class.bin')).read_text(),'rawPrefix':str((d/prefix).relative_to(O))}
   for channel in ['stdout','stderr']:
    raw=(d/(prefix+'.'+channel+'.bin')).read_bytes();u=(d/(prefix+'.'+channel+'.code-units.bin')).read_bytes();assert units_raw(u)==raw;row[channel+'Utf8Hex']=raw.hex();row[channel+'Utf16BEHex']=u.hex()
   rows.append(row)
  trust_observations.append({'repeat':repeat,'batch':batch,'calls':rows})
 trust_repeats.append({str(p.relative_to(target/'calls')):sha(p)for p in(target/'calls').rglob('*.bin')}if(target/'calls').is_dir()else{})
trust_diff=[] if not trust_repeats else [p for p in sorted(trust_repeats[0].keys()|trust_repeats[1].keys())if trust_repeats[0].get(p)!=trust_repeats[1].get(p)]
after={str(p):sha(p)for p in inputs};write(O/'inputs-after.json',after);work_after={c['id']:snapshot(c)for c in cases};write(O/'workspaces-after.json',work_after)
report={'scope':'Fresh pinned original Java API Stage49 key URI, cache failure and supplied-source controls only;notRust/nativecompatibility. PublicEvaluatorAPI anddirectSecurityManager calls areseparatelyaccounted; customfactory/uncached/publiclifecycle/import* obligations arenotclosedbybundledscope. IntentreachandInternalAPIerrors requirelaterrawaudit. No Java productionfallback.','profileSha256':sha(O/'profile.json'),'freshEvaluatorJvmProcesses':len(records),'evaluatorSessionsPlanned':len(records)*2,'evaluatorApiCalls':sum(len(x['calls'])for x in observations),'evaluatorStatusCounts':dict(collections.Counter(c['status']for x in observations for c in x['calls'])),'records':records,'observations':observations,'repeatDifferences':differences,'directSecurityManagerJvmProcesses':len(trust_records),'directSecurityManagerBatches':0,'directSecurityManagerApiCalls':sum(len(x['calls'])for x in trust_observations),'directStatusCounts':dict(collections.Counter(c['status']for x in trust_observations for c in x['calls'])),'trustRecords':trust_records,'trustObservations':trust_observations,'trustRepeatDifferences':trust_diff,'inputHashes':before,'inputChanges':[p for p in before if before[p]!=after[p]],'workspacesUnchanged':work_before==work_after,'jarStable':sha(jar)==before[str(jar)],'capturedEventEncodings':'IndependentactualJavaUTF16andJavaUTF8; no normalization','gcBoundary':'System.gc request only; no observedcollectionclaim','platform':platform.platform(),'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()};write(O/'report.json',report);print(json.dumps({'evaluatorApis':report['evaluatorApiCalls'],'statusCounts':report['evaluatorStatusCounts'],'directApis':report['directSecurityManagerApiCalls'],'directStatus':report['directStatusCounts'],'inputChanges':report['inputChanges'],'workspacesUnchanged':report['workspacesUnchanged']},indent=2),flush=True)
raise SystemExit(0 if not report['inputChanges']and report['workspacesUnchanged']and report['jarStable']and all(r['exitCode']==0 and not r['timedOut']for r in records+trust_records)else 1)
