from pathlib import Path
import hashlib,json,shutil
O=Path(__file__).resolve().parent;P=O.parent/'stage49-oracle-modulekey-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'AdmissionProbe.java')=='9829d62a2e3ad3e661dc9841cfb53b846cc027960916b0e1e3d82c5096ae9f1f'
helper=(P/'AdmissionProbe.java').read_text()
helper=helper.replace('static int keyInstances,keyUriGets,fragmentGets,originalGets;', 'static int keyInstances,keyUriGets,fragmentGets,originalGets,uriResolutions;')
helper=helper.replace('static final Map<String,String> texts=new LinkedHashMap<>();', 'static final Map<String,String> texts=new LinkedHashMap<>();\n static final Map<String,URI> uriOverrides=new LinkedHashMap<>();')
helper=helper.replace('\\nkeyGetUri=', '\\nresolveImportUri="+uriResolutions+"\\nkeyGetUri=')
needle='  public boolean hasFragmentPaths(){fragmentGets++;'
assert needle in helper
method='''  public URI resolveUri(URI operand)throws IOException,SecurityManagerException{
   int index=uriResolutions++;event("key-resolve-uri id="+id+" key="+plan.original+" operand="+operand+" call="+index);
   text("uri-call-"+index+".key-uri.bin",plan.original.toString());units("uri-call-"+index+".key-uri.code-units.bin",plan.original.toString());
   text("uri-call-"+index+".operand.bin",operand.toString());units("uri-call-"+index+".operand.code-units.bin",operand.toString());
   URI target=uriOverrides.get(plan.original+"\\t"+operand);
   if(target==null)target=ModuleKey.super.resolveUri(operand);
   event("key-uri-result id="+id+" target="+target+" call="+index);
   text("uri-call-"+index+".result.bin",target.toString());units("uri-call-"+index+".result.code-units.bin",target.toString());return target;
  }
'''
helper=helper.replace(needle,method+needle)
helper=helper.replace('for(String line:Files.readAllLines(work.resolve("module-plan.tsv")))', 'for(String line:Files.readAllLines(work.resolve("uri-overrides.tsv"))){if(line.isEmpty())continue;String[]f=line.split("\\t",-1);uriOverrides.put(f[0]+"\\t"+f[1],URI.create(f[2]));}\n  for(String line:Files.readAllLines(work.resolve("module-plan.tsv")))')
helper=helper.replace('keyInstances=keyUriGets=fragmentGets=originalGets=0;', 'keyInstances=keyUriGets=fragmentGets=originalGets=uriResolutions=0;')
(O/'AdmissionProbe.java').write_text(helper)
for n in ['TrustProbe.java','launch.py','trust-uris.txt']:shutil.copyfile(P/n,O/n)
run=(P/'run.py').read_text().replace("'pkl-core/src/main/java/org/pkl/core/ModuleSource.java'", "'pkl-core/src/main/java/org/pkl/core/runtime/ReaderBase.java','pkl-core/src/main/java/org/pkl/core/ModuleSource.java'")
(O/'run.py').write_text(run)
cases=[]
request='memo:/holder-request.pkl';selected='memo:/selected/holder.pkl';resolved='memo:/resolved/holder.pkl'
for kind in ['uri','contents']:
    name='resolve-uri-override-'+kind;w=O/'workspace'/name;w.mkdir(parents=True)
    body='function relative() = import("./child.pkl")\nfunction absolute() = import("memo:/authored-absolute.pkl")\nstable = 7\n'
    files={'main.pkl':'stable = 7\n','holder.pkl':body,'override-relative.pkl':'tag = "override-relative"\n','override-absolute.pkl':'tag = "override-absolute"\n','default-relative.pkl':'tag = "default-relative"\n','default-absolute.pkl':'tag = "default-absolute"\n','wrong-base-relative.pkl':'tag = "wrong-request-base"\n'}
    plans=[(request,selected,resolved,'holder.pkl','true','false')]
    for uri,source in [('memo:/override-relative.pkl','override-relative.pkl'),('memo:/override-absolute.pkl','override-absolute.pkl'),('memo:/selected/child.pkl','default-relative.pkl'),('memo:/authored-absolute.pkl','default-absolute.pkl'),('memo:/child.pkl','wrong-base-relative.pkl')]:plans.append((uri,uri,uri,source,'true','false'))
    files['module-plan.tsv']=''.join('\t'.join(p)+'\n'for p in plans)
    files['source-inputs.txt']=''.join(n+'\n'for n in files if n.endswith('.pkl'))
    files['source-profiles.tsv']='\t'.join(['primary',kind,request,'holder.pkl'if kind=='contents'else''])+'\n'
    files['uri-overrides.tsv']=selected+'\t./child.pkl\tmemo:/override-relative.pkl\n'+selected+'\tmemo:/authored-absolute.pkl\tmemo:/override-absolute.pkl\n'
    sequence=['stable','relative().tag','absolute().tag','relative().tag','GC','absolute().tag','stable']
    operations=[{'kind':'gc'}if e=='GC'else{'kind':'evaluate','source':'primary','expression':e}for e in sequence]
    files['operations.tsv']=''.join('GC\n'if e=='GC'else'primary\t'+e+'\n'for e in sequence)
    for n,b in files.items():(w/n).write_text(b)
    cases.append({'id':name,'workspace':str(w),'entry':'main.pkl','sourceUri':(w/'main.pkl').as_uri(),'mode':'allow','operations':operations,'inputPaths':list(files),'primarySourceKind':kind,'primarySourceUri':request,'primaryContentsRelativeFile':'holder.pkl'if kind=='contents'else None,'scope':'Actual custom ModuleKey.resolveUri override on relative and absolute authored import operands; selected key URI differs from factory request/resolved URI. '+('URI-only actual key should invoke configured override.'if kind=='uri'else'URI+contents CachedModuleKey wrapper contrast inherits its own default resolver; no delegated override assumption.')+' Authored module functions avoid query-local alias errors; no expected results are predicted.'})
(O/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');(O/'input-paths.json').write_text(json.dumps({c['id']:c['inputPaths']for c in cases},indent=2)+'\n')
(O/'predecessor.json').write_text(json.dumps({'root':str(P),'originalHelperSha256':sha(P/'AdmissionProbe.java'),'newHelperSha256':sha(O/'AdmissionProbe.java'),'additiveHelperCapability':'Observable real resolveUri(URI) override with explicit per-key+operand configuration; raw independent UTF16/UTF8 input/result; separate counter. No module cache or resolver added outside this actual SPI override.'},indent=2)+'\n')
(O/'PLAN.ko.md').write_text('# Stage49 custom resolveUri 실제 관찰\n\n기존01–04 및 원래212개는 재실행하지 않는다. 새05는 ModuleSource.uri와 create(uri,contents)의 fresh evaluator 대조다. custom key는 factory request/selected/resolved URI를 구분하며 선언된 relative·absolute import operand에만 명시 override 결과를 돌려준다. getter는 실제 resolveUri 호출에서만 기록하고 입력·반환 URI를 독립 Java UTF16/UTF8로 보존한다.\n\ncontents wrapper가 delegate override를 호출하는지는 원본 CachedModuleKey와 실제 API로 관찰하며 예상 결과를 helper가 대신 만들지 않는다. child의 각 반환 tag는 사전 구성 Host source 입력으로 서로 다르다. main/primary 함수 호출은 원래 alias query 실패를 반복하지 않게 모듈에 작성한다. 예정48 API(2 profile×6×2 evaluator×2 fresh JVM), GC는 요청만 기록한다. Driver mock preflight 종료 뒤 Java를 실행한다.\n')
print(json.dumps({'cases':2,'plannedApis':48,'newHelperSha256':sha(O/'AdmissionProbe.java')}))
