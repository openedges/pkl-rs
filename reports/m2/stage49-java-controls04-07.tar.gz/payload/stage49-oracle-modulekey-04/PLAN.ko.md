# Stage49 유효한 supplied-source key 대조

원래01의 hasFragmentPaths=true/fragment=null SPI 입력은 그대로 보존하고 ordinary 캐시 계약으로 세지 않는다. 새04는 false/fragment없음과 true/유효fragment를 구분한다. 같은 URI의 두 supplied contents, 실제 URI-only uncached key, 다시 cached wrapper, ModuleInfo class 이름과 output.text, 별도 repl:text contents를 실제 API로 관찰한다. 같은 helper와 JVM 설정, 새 source/URI/raw를 사용한다. 예정104 API(2 source×13×2 evaluator×2 fresh JVM). 기존212 및 다른 정상 관찰은 재실행하지 않는다.
