from pathlib import Path
import json,shutil,hashlib
O=Path(__file__).resolve().parent;P=O.parent/'stage49-oracle-modulekey-01'
assert json.loads((P/'outer-terminal.json').read_bytes())['exitCode']==0
for n in ['AdmissionProbe.java','TrustProbe.java','run.py','launch.py','trust-uris.txt']:shutil.copyfile(P/n,O/n)
cases=[]
for fragment in [False,True]:
    name='module-source-valid-'+('fragment-key' if fragment else 'plain-key');w=O/'workspace'/name;w.mkdir(parents=True)
    uri='memo:/supplied.pkl'+('#/chosen/fragmentName.pkl' if fragment else '')
    files={'main.pkl':'stable = 7\n','one.pkl':'class Marker {}\ntag = "one"\noutput { text = "ONE" }\n','two.pkl':'class Marker {}\ntag = "two"\noutput { text = "TWO" }\n','underlying.pkl':'class Marker {}\ntag = "underlying"\noutput { text = "UNDERLYING" }\n','module-plan.tsv':'\t'.join([uri,uri,'memo:/resolved/underlying.pkl','underlying.pkl','false',str(fragment).lower()])+'\n','source-profiles.tsv':'\n'.join(['\t'.join(['supplied1','contents',uri,'one.pkl']),'\t'.join(['supplied2','contents',uri,'two.pkl']),'\t'.join(['uri','uri',uri,'']),'repl1\trepl\trepl:text\tone.pkl','repl2\trepl\trepl:text\ttwo.pkl'])+'\n'}
    files['source-inputs.txt']=''.join(n+'\n'for n in files if n.endswith('.pkl'))
    pairs=[('supplied1','tag'),('supplied2','tag'),('supplied2','Marker.toString()'),('supplied2','output.text'),('uri','tag'),('uri','Marker.toString()'),('supplied1','tag'),('supplied1','Marker.toString()'),('repl1','tag'),('repl2','tag'),('repl1','output.text'),('repl2','output.text'),('supplied1','output.text')]
    operations=[{'kind':'evaluate','source':s,'expression':e}for s,e in pairs];files['operations.tsv']=''.join(s+'\t'+e+'\n'for s,e in pairs)
    for n,b in files.items():(w/n).write_text(b)
    cases.append({'id':name,'workspace':str(w),'entry':'main.pkl','sourceUri':(w/'main.pkl').as_uri(),'mode':'allow','operations':operations,'inputPaths':list(files),'scope':'Valid actual custom ModuleKey fragment capability: '+str(fragment)+'. Same-URI supplied contents wrappers versus uncached underlying key, module/class name and URI-cache overwrite; repl:text separate supplied contents; output.text direct path. No invalid null fragment and no Rust-derived expected output.'})
(O/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');(O/'input-paths.json').write_text(json.dumps({c['id']:c['inputPaths']for c in cases},indent=2)+'\n')
(O/'PLAN.ko.md').write_text('# Stage49 유효한 supplied-source key 대조\n\n원래01의 hasFragmentPaths=true/fragment=null SPI 입력은 그대로 보존하고 ordinary 캐시 계약으로 세지 않는다. 새04는 false/fragment없음과 true/유효fragment를 구분한다. 같은 URI의 두 supplied contents, 실제 URI-only uncached key, 다시 cached wrapper, ModuleInfo class 이름과 output.text, 별도 repl:text contents를 실제 API로 관찰한다. 같은 helper와 JVM 설정, 새 source/URI/raw를 사용한다. 예정104 API(2 source×13×2 evaluator×2 fresh JVM). 기존212 및 다른 정상 관찰은 재실행하지 않는다.\n')
(O/'predecessor.json').write_text(json.dumps({'root':str(P),'helperSha256':hashlib.sha256((O/'AdmissionProbe.java').read_bytes()).hexdigest(),'helperUnchanged':True,'reason':'Original01 null fragment withtruecapability caused Java internal NPE. Valid false/plain versus true/fragment profiles are separate necessary controls, originalerrors unchanged.'},indent=2)+'\n')
print(json.dumps({'cases':2,'plannedApis':104}))
