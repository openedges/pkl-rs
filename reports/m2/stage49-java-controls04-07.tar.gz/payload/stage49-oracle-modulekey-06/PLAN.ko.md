# Stage49 실제 factory Synthetic 관찰

새06는 Java ModuleKeys.synthetic를 직접 반환하는 두 cache 설정을 관찰한다. 반환 객체를 proxy로 감싸지 않으며 실제 class 이름과 factory 구성 source snapshot을 기록한다. getter/resolve/sourceLoad를 직접 계측할 수 없는 부분은 호출0으로 주장하지 않는다. 실제 factory와 security 이벤트, 전체 API raw UTF16/JavaUTF8, 카운터는 보존한다.

각 evaluator에서 non-repl 같은 URI의 두 supplied contents, URI-only underlying Synthetic, source-state 변경과 두 URI cache를 순차 실행한다. CachedModuleKey wrapper 여부와 cached true/false 차이는 실제 API 결과로만 판정한다. 예정80 API(2 case×10×2 evaluator×2 fresh JVM). 기존01–05/원래212 및 과거 실패 입력은 재실행하지 않는다.
