from pathlib import Path
import hashlib,json,shutil
O=Path(__file__).resolve().parent;P=O.parent/'stage49-oracle-modulekey-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'AdmissionProbe.java')=='9829d62a2e3ad3e661dc9841cfb53b846cc027960916b0e1e3d82c5096ae9f1f'
helper=(P/'AdmissionProbe.java').read_text()
helper=helper.replace('fragmentGets,originalGets;', 'fragmentGets,originalGets,syntheticFactories;')
helper=helper.replace('String source,String cache,boolean fragments){}', 'String source,String cache,boolean fragments,String kind){}')
helper=helper.replace('f[3],f[4],Boolean.parseBoolean(f[5]))', 'f[3],f[4],Boolean.parseBoolean(f[5]),f[6])')
helper=helper.replace('\\nkeyGetUri=', '\\nsyntheticFactoryReturns="+syntheticFactories+"\\nkeyGetUri=')
helper=helper.replace('keyInstances=keyUriGets=fragmentGets=originalGets=0;', 'keyInstances=keyUriGets=fragmentGets=originalGets=syntheticFactories=0;')
needle='factoryHits++;event("factory-custom-hit "+uri);return Optional.of(new PlannedKey(p));'
assert needle in helper
replacement='''factoryHits++;event("factory-custom-hit "+uri);
     if(p.kind.equals("synthetic")){
      boolean cached=p.cache.equals("dynamic")?cacheMode:p.cache.equals("true");
      String source=p.source.equals("$state")?"state-"+sourceState+".pkl":p.source;String value=texts.get(source);
      if(value==null)throw new IllegalStateException("undeclared synthetic source "+source);
      ModuleKey key=ModuleKeys.synthetic(p.original,p.original,p.resolved,value,cached);
      int index=syntheticFactories++;
      event("factory-synthetic-return requested="+uri+" selected-input="+p.original+" cached-config="+cached+" class="+key.getClass().getName()+" source-state="+sourceState+" capture="+index);
      text("synthetic-factory-"+index+".uri-input.bin",p.original.toString());units("synthetic-factory-"+index+".uri-input.code-units.bin",p.original.toString());
      text("synthetic-factory-"+index+".cached-config.bin",Boolean.toString(cached));text("synthetic-factory-"+index+".class.bin",key.getClass().getName());
      text("synthetic-factory-"+index+".source-config.bin",value);units("synthetic-factory-"+index+".source-config.code-units.bin",value);
      return Optional.of(key);
     }
     if(!p.kind.equals("host"))throw new IllegalStateException("unknown configured key kind");
     return Optional.of(new PlannedKey(p));'''
helper=helper.replace(needle,replacement)
(O/'AdmissionProbe.java').write_text(helper)
for n in ['TrustProbe.java','run.py','launch.py','trust-uris.txt']:shutil.copyfile(P/n,O/n)
cases=[]
for cached in [True,False]:
    name='actual-factory-synthetic-cached-'+str(cached).lower();w=O/'workspace'/name;w.mkdir(parents=True)
    uri='memo:/synthetic-uri.pkl';contents='memo:/synthetic-contents.pkl'
    files={'main.pkl':'stable = 7\n','state-one.pkl':'tag = "synthetic-one"\noutput { text = "SYNTHETIC-ONE" }\n','state-two.pkl':'tag = "synthetic-two"\noutput { text = "SYNTHETIC-TWO" }\n','supplied-one.pkl':'tag = "supplied-one"\noutput { text = "SUPPLIED-ONE" }\n','supplied-two.pkl':'tag = "supplied-two"\noutput { text = "SUPPLIED-TWO" }\n'}
    files['module-plan.tsv']=''.join('\t'.join([u,u,u,'$state',str(cached).lower(),'false','synthetic'])+'\n'for u in [uri,contents])
    files['source-inputs.txt']=''.join(n+'\n'for n in files if n.endswith('.pkl'))
    files['source-profiles.tsv']='\n'.join(['uri\turi\t'+uri+'\t','underlying\turi\t'+contents+'\t','supplied1\tcontents\t'+contents+'\tsupplied-one.pkl','supplied2\tcontents\t'+contents+'\tsupplied-two.pkl'])+'\n'
    ops=[('source','one'),('supplied1','tag'),('supplied2','tag'),('underlying','tag'),('supplied2','tag'),('uri','tag'),('source','two'),('uri','tag'),('underlying','tag'),('supplied1','tag'),('gc',''),('supplied2','output.text'),('uri','output.text')]
    operations=[];lines=[]
    for source,expression in ops:
        if source in ['source','gc']:
            operations.append({'kind':source,**({'value':expression}if source=='source'else{})});lines.append('GC'if source=='gc'else'SOURCE\t'+expression)
        else:operations.append({'kind':'evaluate','source':source,'expression':expression});lines.append(source+'\t'+expression)
    files['operations.tsv']='\n'.join(lines)+'\n'
    for n,b in files.items():(w/n).write_text(b)
    cases.append({'id':name,'workspace':str(w),'entry':'main.pkl','sourceUri':(w/'main.pkl').as_uri(),'mode':'allow','operations':operations,'inputPaths':list(files),'factoryKeyKind':'actual ModuleKeys.synthetic(uri,importBaseUri,resolvedUri,text,isCached), returned unwrapped','cacheConfiguration':cached,'sourceSnapshot':'Source text captured at each actual factory return; later state changes do not mutate that key.','scope':'Legitimate actual Synthetic returned by priority factory. URI-only and non-repl URI+contents same-URI cache/wrapper behavior with different supplied/factory texts. Real factory and security events recorded; Synthetic internal getter/resolve/loadSource callbacks are NOT intercepted, so observer key-is-cached/key-resolve/sourceLoad zero is NOT no-call evidence. No proxy changes the actual returned class.'})
(O/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');(O/'input-paths.json').write_text(json.dumps({c['id']:c['inputPaths']for c in cases},indent=2)+'\n')
(O/'predecessor.json').write_text(json.dumps({'root':str(P),'oldHelperSha256':sha(P/'AdmissionProbe.java'),'newHelperSha256':sha(O/'AdmissionProbe.java'),'newCapability':'Priority factory returns actual unwrapped ModuleKeys.synthetic object, configurabletrue/false, source snapshot at factory. Class and constructor input facts captured without calling synthetic getters or proxying key.','observationLimit':'Cannot intercept Synthetic getter/source method callbacks without replacing actual class. Record only actual factory returns/security/outcomes; no fabricated getter calls.'},indent=2)+'\n')
(O/'PLAN.ko.md').write_text('# Stage49 실제 factory Synthetic 관찰\n\n새06는 Java ModuleKeys.synthetic를 직접 반환하는 두 cache 설정을 관찰한다. 반환 객체를 proxy로 감싸지 않으며 실제 class 이름과 factory 구성 source snapshot을 기록한다. getter/resolve/sourceLoad를 직접 계측할 수 없는 부분은 호출0으로 주장하지 않는다. 실제 factory와 security 이벤트, 전체 API raw UTF16/JavaUTF8, 카운터는 보존한다.\n\n각 evaluator에서 non-repl 같은 URI의 두 supplied contents, URI-only underlying Synthetic, source-state 변경과 두 URI cache를 순차 실행한다. CachedModuleKey wrapper 여부와 cached true/false 차이는 실제 API 결과로만 판정한다. 예정80 API(2 case×10×2 evaluator×2 fresh JVM). 기존01–05/원래212 및 과거 실패 입력은 재실행하지 않는다.\n')
print(json.dumps({'cases':2,'plannedApis':80,'helperSha256':sha(O/'AdmissionProbe.java')}))
