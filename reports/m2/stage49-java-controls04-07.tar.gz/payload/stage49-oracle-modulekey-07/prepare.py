from pathlib import Path
import hashlib,json,shutil
O=Path(__file__).resolve().parent;P=O.parent/'stage49-oracle-modulekey-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P/'AdmissionProbe.java')=='9829d62a2e3ad3e661dc9841cfb53b846cc027960916b0e1e3d82c5096ae9f1f'
helper=(P/'AdmissionProbe.java').read_text()
helper=helper.replace('fragmentGets,originalGets;', 'fragmentGets,originalGets,localGets,hierarchyGets,elementQueries;')
helper=helper.replace('static final Map<String,String> texts=new LinkedHashMap<>();', 'static final Map<String,String> texts=new LinkedHashMap<>();\n static final Set<String> elements=new LinkedHashSet<>();')
helper=helper.replace('\\nkeyGetUri=', '\\nlocalGetter="+localGets+"\\nhierarchyGetter="+hierarchyGets+"\\nhasElement="+elementQueries+"\\nkeyGetUri=')
helper=helper.replace('public boolean hasHierarchicalUris(){event(', 'public boolean hasHierarchicalUris(){hierarchyGets++;event(')
helper=helper.replace('public boolean isLocal(){return true;}', 'public boolean isLocal(){localGets++;event("key-local id="+id+" true");return true;}')
needle='  public boolean isCached(){cacheQueries++;'
method='''  public boolean hasElement(org.pkl.core.SecurityManager security,URI candidate)throws IOException{
   int index=elementQueries++;event("key-has-element id="+id+" key="+plan.original+" candidate="+candidate+" query="+index);
   boolean exists=elements.contains(plan.original+"\\t"+candidate);
   text("element-"+index+".key-id.bin",Integer.toString(id));text("element-"+index+".key-uri.bin",plan.original.toString());units("element-"+index+".key-uri.code-units.bin",plan.original.toString());
   text("element-"+index+".candidate.bin",candidate.toString());units("element-"+index+".candidate.code-units.bin",candidate.toString());text("element-"+index+".exists.bin",Boolean.toString(exists));
   event("key-element-result id="+id+" candidate="+candidate+" exists="+exists+" query="+index);return exists;
  }
'''
assert needle in helper;helper=helper.replace(needle,method+needle)
helper=helper.replace('for(String line:Files.readAllLines(work.resolve("module-plan.tsv")))', 'for(String line:Files.readAllLines(work.resolve("element-inputs.tsv"))){if(!line.isEmpty())elements.add(line);}\n  for(String line:Files.readAllLines(work.resolve("module-plan.tsv")))')
helper=helper.replace('keyInstances=keyUriGets=fragmentGets=originalGets=0;', 'keyInstances=keyUriGets=fragmentGets=originalGets=localGets=hierarchyGets=elementQueries=0;')
(O/'AdmissionProbe.java').write_text(helper)
for n in ['TrustProbe.java','launch.py','trust-uris.txt']:shutil.copyfile(P/n,O/n)
run=(P/'run.py').read_text().replace("'pkl-core/src/main/java/org/pkl/core/ModuleSource.java'", "'pkl-core/src/main/java/org/pkl/core/runtime/ReaderBase.java','pkl-core/src/main/java/org/pkl/core/ModuleSource.java'")
(O/'run.py').write_text(run)
request='memo:/wrapper-request.pkl';selected='memo:/path/a/main.pkl#/fragment/a/module.pkl'
fragment_target='memo:/path/a/main.pkl#/target.pkl';path_target='memo:/target.pkl'
cases=[]
for kind in ['uri','contents']:
    name='wrapper-triple-fragment-'+kind;w=O/'workspace'/name;w.mkdir(parents=True)
    files={'main.pkl':'stable = 7\n','parent.pkl':'function found() = import(".../target.pkl")\nstable = 7\n','fragment-target.pkl':'tag = "fragment-search"\n','path-target.pkl':'tag = "path-search"\n'}
    plans=[(request,selected,'memo:/resolved/parent.pkl','parent.pkl','true','true'),(fragment_target,fragment_target,'memo:/resolved/fragment-target.pkl','fragment-target.pkl','true','true'),(path_target,path_target,'memo:/resolved/path-target.pkl','path-target.pkl','true','false')]
    files['module-plan.tsv']=''.join('\t'.join(p)+'\n'for p in plans)
    files['source-inputs.txt']=''.join(n+'\n'for n in files if n.endswith('.pkl'))
    files['source-profiles.tsv']='\t'.join(['primary',kind,request,'parent.pkl'if kind=='contents'else''])+'\n'
    files['element-inputs.tsv']=selected+'\t'+fragment_target+'\n'+selected+'\t'+path_target+'\n'
    expressions=['stable','found().tag','found().tag','GC','stable','found().tag']
    operations=[{'kind':'gc'}if e=='GC'else{'kind':'evaluate','source':'primary','expression':e}for e in expressions]
    files['operations.tsv']=''.join('GC\n'if e=='GC'else'primary\t'+e+'\n'for e in expressions)
    for n,b in files.items():(w/n).write_text(b)
    cases.append({'id':name,'workspace':str(w),'entry':'main.pkl','sourceUri':(w/'main.pkl').as_uri(),'mode':'allow','operations':operations,'inputPaths':list(files),'primarySourceKind':kind,'primarySourceUri':request,'primaryContentsRelativeFile':'parent.pkl'if kind=='contents'else None,'hasElementContract':'Actual delegate method uses declared positive URI set membership; absent candidates return false. No filesystem or Host search/URI algorithm. Exact actual candidate/key-id/result trace captured.','scope':'Real URI-only versusCachedModuleKey contents wrapper triple-dot search. Delegate haslocal=true/hierarchical=true/fragmentPaths=true; wrapperdelegateslocal/hierarchical/hasElementbutinheritsfragmentfalse. Member function triple resolution is AST preparation, not lazy runtime lookup. Actual result and candidates determinecoverage; source prediction notexpected.'})
(O/'cases.json').write_text(json.dumps(cases,indent=2)+'\n');(O/'input-paths.json').write_text(json.dumps({c['id']:c['inputPaths']for c in cases},indent=2)+'\n')
(O/'predecessor.json').write_text(json.dumps({'root':str(P),'oldHelperSha256':sha(P/'AdmissionProbe.java'),'newHelperSha256':sha(O/'AdmissionProbe.java'),'newCapability':'Actual hasElement set-membership provider and local/hierarchical getter observers; actual per-call delegate key id/candidate/result UTF16+UTF8. No custom search resolver.'},indent=2)+'\n')
(O/'PLAN.ko.md').write_text('# Stage49 wrapper triple-dot 실제 관찰\n\n새07은 원래04의 이름 추론 관찰로 대체하지 않는다. 같은 delegate가 local/hierarchical/fragment getter와 실제 hasElement를 제공할 때 URI-only와 URI+contents wrapper의 triple-dot 후보/검색 결과를 비교한다. positive candidate 집합만 Host 입력이며 후보 생성·검색 순서·정규화는 Java 엔진이 수행한다. 존재하지 않는 후보는 실제 hasElement가 false를 돌려준다.\n\n각 getter와 후보 URI/수신 key-id/result를 실제 호출에서 기록한다. function 안 import도 AST 준비에서 검색하므로 첫 stable API 시점부터 전체 순서를 보존한다. 예정40 API(2 case×5×2 evaluator×2 fresh JVM), 이전 자료 재실행·기댓값 수정·생산 변경은 없다.\n')
print(json.dumps({'cases':2,'plannedApis':40,'helperSha256':sha(O/'AdmissionProbe.java')}))
