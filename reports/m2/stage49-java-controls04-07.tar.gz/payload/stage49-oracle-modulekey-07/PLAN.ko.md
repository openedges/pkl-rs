# Stage49 wrapper triple-dot 실제 관찰

새07은 원래04의 이름 추론 관찰로 대체하지 않는다. 같은 delegate가 local/hierarchical/fragment getter와 실제 hasElement를 제공할 때 URI-only와 URI+contents wrapper의 triple-dot 후보/검색 결과를 비교한다. positive candidate 집합만 Host 입력이며 후보 생성·검색 순서·정규화는 Java 엔진이 수행한다. 존재하지 않는 후보는 실제 hasElement가 false를 돌려준다.

각 getter와 후보 URI/수신 key-id/result를 실제 호출에서 기록한다. function 안 import도 AST 준비에서 검색하므로 첫 stable API 시점부터 전체 순서를 보존한다. 예정40 API(2 case×5×2 evaluator×2 fresh JVM), 이전 자료 재실행·기댓값 수정·생산 변경은 없다.
