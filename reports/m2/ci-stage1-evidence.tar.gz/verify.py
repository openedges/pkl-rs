"""Independently rederive downloaded stage 1 evidence without executing artifacts."""
import collections
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ARTIFACT = HERE / "artifact"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


run = json.loads((HERE / "run.json").read_bytes())
jobs = json.loads((HERE / "jobs.json").read_bytes())["jobs"]
assert run["head_sha"] == "fb5a3488ec9c6045111c8240b9ac44240529ef67"
assert run["conclusion"] == "success"
assert len(jobs) == 6 and all(job["conclusion"] == "success" for job in jobs)
metadata = next(
    row
    for row in json.loads((HERE / "artifacts.json").read_bytes())["artifacts"]
    if row["name"] == "m2-language-evidence"
)
assert metadata["digest"] == "sha256:" + sha(HERE / "artifact.zip")
report = json.loads((ARTIFACT / "report.json").read_bytes())
assert report["source_stability"] and report["artifact_stability"]
files = {
    str(path.relative_to(ARTIFACT))
    for path in ARTIFACT.rglob("*")
    if path.is_file() and path != ARTIFACT / "report.json"
}
assert files == set(report["evidence_sha256"])
for relative, digest in report["evidence_sha256"].items():
    assert sha(ARTIFACT / relative) == digest, relative
for relative, digest in report["source_sha256"].items():
    assert sha(ARTIFACT / "sources" / relative) == digest
    committed = subprocess.run(
        ["git", "show", f'{run["head_sha"]}:{relative}'],
        check=True,
        capture_output=True,
    ).stdout
    assert hashlib.sha256(committed).hexdigest() == digest, relative
assert sha(ARTIFACT / "artifacts/language_probe") == report["candidate"]["sha256"]
sys.path.insert(0, str(ARTIFACT / "sources/tools"))
sys.dont_write_bytecode = True
import m2_language as frozen_verifier

frozen_verifier.verify_oracle(ARTIFACT, report)
build = json.loads((ARTIFACT / "build.process.json").read_bytes())
assert build == report["candidate"]["build"]
assert build["exit_code"] == 0 and not build["timed_out"]
assert report["candidate"]["source_binding"] == "recorded-build"
origin = Path(build["command"][-1]).parent
manifest = json.loads((ARTIFACT / "sources/compatibility/m2-language.json").read_bytes())
selected = {
    case["id"]: case
    for case in manifest["cases"]
    if case.get("adapter") == "language-api-string"
}
assert report["selected_count"] == len(selected) == 119
assert len(report["results"]) == len(selected)
assert {row["id"] for row in report["results"]} == set(selected)
counts = collections.Counter()
captures = {}
for row in report["results"]:
    case = selected[row["id"]]
    folder = ARTIFACT / "cases" / row["id"]
    assert sha(folder / "input.pkl") == case["input_sha256"]
    values = {}
    for runtime in ("java", "rust"):
        process = json.loads((folder / f"{runtime}.process.json").read_bytes())
        assert process == row[runtime]
        assert process["command"][-2:] == [
            str(origin / case["input"]),
            case["expression"],
        ]
        if runtime == "java":
            java_base = list(report["oracle"]["command"][:-1])
            acquisition = Path(row["rust"]["command"][0]).parent.parent
            java_base[-1] += ":" + str(acquisition / "artifacts/java")
            assert process["command"][:-2] == [*java_base, "M2LanguageProbe"]
        stdout, stderr = [
            (folder / f"{runtime}.{channel}.bin").read_bytes()
            for channel in ("stdout", "stderr")
        ]
        for channel, data in (("stdout", stdout), ("stderr", stderr)):
            assert hashlib.sha256(data).hexdigest() == process[channel + "_sha256"]
        values[runtime] = process["exit_code"], process["timed_out"], stdout, stderr
        captures[row["id"], runtime] = values[runtime]
    expected = 0 if case["expected_outcome"] == "success" else 1
    code, timed_out, stdout, stderr = values["java"]
    if timed_out or code != expected or (
        expected == 0 and stderr
    ) or (expected == 1 and (stdout or not stderr.startswith("–– Pkl Error ––\n".encode()))):
        status = "oracle-error"
    elif values["rust"][1]:
        status = "candidate-timeout"
    else:
        status = "pass" if values["java"] == values["rust"] else "mismatch"
    assert status == row["status"]
    counts[status] += 1
assert dict(counts) == report["status_counts"] == {"pass": 118, "oracle-error": 1}
assert [row["id"] for row in report["results"] if row["status"] != "pass"] == ["error-cycle"]
assert len(report["metamorphic_results"]) == 12
for relation in report["metamorphic_results"]:
    for runtime in ("java", "rust"):
        values = [captures[identifier, runtime] for identifier in relation["case_ids"]]
        passed = all(value[:2] == (0, False) and value[3] == b"" for value in values)
        passed = passed and len(set(values)) == 1
        assert passed == relation["runtimes"][runtime]
    assert relation["status"] == "pass"
summary = {
    "run_id": run["id"],
    "commit": run["head_sha"],
    "url": run["html_url"],
    "jobs": [{"name": job["name"], "conclusion": job["conclusion"]} for job in jobs],
    "artifact_id": metadata["id"],
    "artifact_sha256": sha(HERE / "artifact.zip"),
    "exact_committed_source_files_verified": len(report["source_sha256"]),
    "evidence_files_verified": len(files),
    "raw_comparisons": dict(counts),
    "metamorphic_relations": 12,
    "strict_subset_complete": False,
    "full_m2_complete": False,
    "scope": "Stage 1 CI and downloaded M2 evidence; cyclic diagnostics and remaining language requirements stay incomplete.",
}
(HERE / "verification.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, sort_keys=True))
