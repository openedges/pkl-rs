"""Fresh pinned Java API observations for actual standard modules/guest catch."""
from pathlib import Path
import collections,hashlib,json,platform,shutil,subprocess,sys,time
R=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage42');T=Path('/Users/cody.ij.hwang/Projects/pkl-rs.stage43');O=Path(__file__).resolve().parent
sys.path.insert(0,str(T/'tools'));import compat,oracle
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,o):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(o,indent=2,ensure_ascii=True)+'\n')
def capture(name,command,cwd,environment,timeout=45):
 start=time.time_ns()
 try:value=compat.capture(command,cwd,environment,timeout,O/'generated')
 except compat.CaptureTimeout as failure:value=failure.result
 saved=compat.store_capture(O/name,value)
 row={'command':command,'cwd':str(cwd),'environment':environment,'startedUnixNs':start,'finishedUnixNs':time.time_ns(),'result':saved}
 write(O/(name+'.process.json'),row);return row,value
lock=json.loads((R/'oracle.lock.json').read_text());oracle.verify_sources(R,lock)
jar=R/'.cache/oracle'/lock['artifact']['filename'];release=oracle.verify_artifact(jar,lock);env=oracle.deterministic_environment(O/'identity');jdk=oracle.verify_java(Path('/usr/bin/java'),lock,env)
profile={'jar':str(jar),'jarSha256':sha(jar),'lockSha256':sha(R/'oracle.lock.json'),'jdk':jdk,'release':release,'environment':env,'evaluator':'preconfigured; cache=null;color=false;emptyenv/props;powerAssertions=true;defaultframe transformer; actualLogger; defaultmodule/readers+catchSPI','guestCatchRenderer':'Pinned TestNodes renderer stack=null,color=false,powerAssertions=false; String.lines/skip1/join-space/strip. Returned API strings recorded as actual UTF16 + Java UTF8; no post-capture transformations.','timeoutSeconds':3,'hostDelayMilliseconds':4000,'hostIdentityBoundary':'ModuleKey original/resolved/source URIs are helper-source-backed, not independently observed identity table.'};write(O/'profile.json',profile)
row,result=capture('javac',['/usr/bin/javac','-cp',str(jar),'-d',str(O/'classes'),str(O/'GuestCatchProbe.java')],R,env);assert result['exit_code']==0
cases=json.loads((O/'cases.json').read_text());assert len(cases)==1
sources=['pkl-core/src/main/java/org/pkl/core/stdlib/test/TestNodes.java','stdlib/test.pkl','pkl-core/src/main/java/org/pkl/core/runtime/ModuleCache.java']
for name in sources:
 p=O/'upstream'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/'external/pkl'/name,p)
inputs=[O/'GuestCatchProbe.java',O/'run.py',O/'cases.json',O/'profile.json',jar,R/'references.lock',R/'oracle.lock.json',T/'tools/compat.py',T/'tools/oracle.py']+list((O/'classes').glob('*.class'))
inputs.extend(O/'upstream'/name for name in sources)
for c in cases:inputs.extend(sorted(Path(c['workspace']).iterdir()))
before={str(p):sha(p)for p in inputs};write(O/'inputs-before.json',before)
records=[];observations=[];differences=[]
for case in cases:
 work=Path(case['workspace']);workspaceBefore=compat.snapshot(work);payloads=[]
 for repeat in [0,1]:
  private=O/'runtime-private'/case['id']/str(repeat);(private/'home').mkdir(parents=True);(private/'tmp').mkdir(parents=True)
  actualEnv={**env,'HOME':str(private/'home'),'TMPDIR':str(private/'tmp'),'TMP':str(private/'tmp'),'TEMP':str(private/'tmp')}
  target=O/'cases'/case['id']/str(repeat)
  command=['/usr/bin/java',*lock['jvm_options'],'-Duser.home='+str(private/'home'),'-Djava.io.tmpdir='+str(private/'tmp'),'-cp',str(O/'classes')+':'+str(jar),'GuestCatchProbe',str(work),str(target/'calls'),case['mode']]
  process,value=capture(str(target.relative_to(O)),command,work,actualEnv,30)
  process.update(case=case['id'],repeat=repeat,moduleUri=case['moduleUri'],sourceSha256=case['sourceSha256'],workspaceBefore=workspaceBefore,workspaceAfter=compat.snapshot(work));write(target/'process.json',process);records.append(process)
  privateFiles=compat.output_files(private)
  for name,data in privateFiles.items():p=target/'private-state'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  write(target/'private-state.json',{'files':{name:hashlib.sha256(data).hexdigest()for name,data in privateFiles.items()},'scope':'Host-private runtime files retained as provenance; not API/public output equality.'})
  calls=[];directory=target/'calls'
  if directory.exists():
   for prefix in ['outer-'+str(i)for i in range(len(case['expressions']))]+['inner-'+str(i)for i in range(len(case['callbacks']))]:
    path=directory/(prefix+'.status.bin')
    if not path.exists():continue
    status=path.read_bytes().decode();channel='stdout'if status=='success\n'else'stderr';p=directory/(prefix+'.'+channel+'.bin');u=directory/(prefix+'.'+channel+'.code-units.bin')
    calls.append({'prefix':prefix,'expression':(directory/(prefix+'.expression.bin')).read_text(),'status':status,'errorClass':(directory/(prefix+'.error-class.bin')).read_text(),'rawPrefix':str((directory/prefix).relative_to(O)),'utf8Sha256':sha(p),'utf16BESha256':sha(u),'utf8Hex':p.read_bytes().hex(),'utf16BEHex':u.read_bytes().hex(),'oracleError':(directory/(prefix+'.error-class.bin')).read_text().endswith('PklBugException')})
  raw={str(p.relative_to(directory)):p.read_bytes()for p in directory.glob('*.bin')}if directory.exists()else{}
  payloads.append(raw);counter=(directory/'counters.bin').read_text()if(directory/'counters.bin').exists()else None
  observation={'case':case['id'],'repeat':repeat,'calls':calls,'counters':counter,'processExit':process['result']['exit_code'],'timedOut':process['result']['timed_out'],'expectedOuterCalls':len(case['expressions']),'executedOuterCalls':sum(c['prefix'].startswith('outer-')for c in calls),'configuredCallbackCalls':len(case['callbacks']),'executedCallbackCalls':sum(c['prefix'].startswith('inner-')for c in calls)};observations.append(observation)
  write(O/'progress.json',{'executedProcesses':len(records),'expectedProcesses':2,'last':observation});print(json.dumps({'case':case['id'],'repeat':repeat,'processExit':observation['processExit'],'outerCalls':observation['executedOuterCalls'],'callbacks':observation['executedCallbackCalls'],'counters':counter}),flush=True)
 if payloads[0]!=payloads[1]:differences.append({'case':case['id'],'paths':[name for name in sorted(payloads[0].keys()|payloads[1].keys())if payloads[0].get(name)!=payloads[1].get(name)]})
after={str(p):sha(p)for p in inputs};write(O/'inputs-after.json',after)
report={'schema':1,'scope':'One supplemental nearest guest function return/forcing boundary: lazy returned object stays unforced versus explicitly forced throw/undefined property, catch/catchOrNull and exact retries. All original14/additive4 preserved. Both repeats preserve complete raw API strings/errors/logs/events/counters; no Rust compatibility claim.','caseCount':len(cases),'freshJvmCount':len(records),'outerCallCount':sum(o['executedOuterCalls']for o in observations),'callbackCallCount':sum(o['executedCallbackCalls']for o in observations),'configuredOuterCallCount':sum(len(c['expressions'])for c in cases)*2,'records':records,'observations':observations,'counts':dict(collections.Counter(c['status']for o in observations for c in o['calls'])),'oracleErrorCalls':[{'case':o['case'],'repeat':o['repeat'],'prefix':c['prefix']}for o in observations for c in o['calls']if c['oracleError']],'repeatDifferences':differences,'inputHashes':before,'inputChanges':[p for p in before if before[p]!=after[p]],'jarStable':sha(jar)==profile['jarSha256'],'profileSha256':sha(O/'profile.json'),'platform':platform.platform(),'processesSequential':True,'knownBoundary':'Evaluator cancellation/Java bug outcomes retained. Successful guest-returned text alone is not classified by guessing an internal exception class; full result payload remains available.'};write(O/'report.json',report)
print(json.dumps({'reportSha256':sha(O/'report.json'),'processes':len(records),'outerCalls':report['outerCallCount'],'callbackCalls':report['callbackCallCount'],'repeatDifferences':differences,'inputChanges':report['inputChanges']}),flush=True)
assert not report['inputChanges']and report['jarStable']and all(p['workspaceBefore']==p['workspaceAfter']for p in records)
assert all(not p['result']['timed_out']and p['result']['exit_code']==0 for p in records)
assert report['outerCallCount']==report['configuredOuterCallCount']
