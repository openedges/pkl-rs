"""Publish read-back Stage 62 collection lookup Java A3 evidence."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[3]
VALIDATION = Path(__file__).resolve().parent
REPORTS = ROOT / "reports/m2"
FIXTURE = ROOT / "tests/fixtures/m2-collection-lookups"
CAPTURES = [ROOT / f"target/m2/stage62-collection-lookups-oracle-0{n}" for n in (1, 2, 3)]
EXPECTED_HEAD = "6a84b19997b09b690f5dcfe4da0917599d834102"
JAR_SHA256 = "c3b6f6215a08b31453b0fb0edd8c9da0aee31233f65abb8ab07f9c945151e059"
JDK_SHA256 = (
    "51ec0764f7225b40d5b286b01401aa6b3990d0d171b446d7dc81ca7542b45552",
    "40fcf7a32bada7e299e3513939a4472d27f8f61eb81cdd1675ea00648de7e7cf",
    "ab66b8afeea98b25f1869fbe7c0dde368d448e7cc0f7bab0359b322ade134fe1",
)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def identity(path):
    raw = Path(path).read_bytes()
    return {"bytes": len(raw), "sha256": sha(raw)}

def need(ok, message):
    if not ok:
        raise ValueError(message)

def paths_under(root, prefix):
    need(root.is_dir() and not root.is_symlink(), "publication input directory missing")
    result = {}
    for path in root.rglob("*"):
        need(not path.is_symlink(), "publication input symlink")
        if path.is_file():
            result[prefix + path.relative_to(root).as_posix()] = path
        else:
            need(path.is_dir(), "publication input nonregular path")
    return result

def emit_archive(path, files):
    need(not path.exists(), "fresh Java A3 evidence archive required")
    entries = {name: source.read_bytes() for name, source in files.items()}
    before = {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in entries.items()}
    manifest = {"schema": 1, "scope": "Stage 62 collection lookups Java A3 validation and all three authored raw captures",
                "members": dict(sorted(before.items()))}
    entries["archive-manifest.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with path.open("wb") as out:
        with gzip.GzipFile(fileobj=out, mode="wb", filename="", mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, raw in sorted(entries.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(raw))
    after = {name: identity(source) for name, source in files.items()}
    need(before == after, "evidence source changed while archived")
    observed = {}
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            need(member.isfile() and member.name not in observed and not member.name.startswith("/")
                 and ".." not in Path(member.name).parts, "unsafe or duplicate evidence member")
            raw = archive.extractfile(member).read()
            need(len(raw) == member.size, "evidence member size differs")
            observed[member.name] = raw
    need(observed == entries and json.loads(observed["archive-manifest.json"]) == manifest,
         "full evidence member byte/hash readback differs")
    return {"archive": path.relative_to(ROOT).as_posix(), "identity": identity(path),
            "members": len(observed), "member_hash_readback": True,
            "source_before_after_equal": before == after,
            "embedded_manifest_sha256": sha(observed["archive-manifest.json"])}

def check_capture(root, expected_rows, expected_statuses, expected_raw_files):
    p = json.loads((root / "provenance.json").read_bytes())
    a = json.loads((root / "audit.json").read_bytes())
    rows = json.loads((root / "cases.json").read_bytes())["rows"]
    need(a["rows"] == len(rows) == expected_rows and a["statuses"] == expected_statuses,
         "capture row/status vector differs")
    need(p["complete"] is True and p["stable"] is True and p["raw_equal"] is True
         and p["raw_differences"] == [] and p["raw_files"] == expected_raw_files
         and p["input_before"] == p["input_after"]
         and p["source_before"] == p["source_after"]
         and p["artifact_sha256"] == p["artifact_after_sha256"] == JAR_SHA256,
         "capture source/runtime stability differs")
    need((p["jdk"]["executable_sha256"], p["jdk"]["modules_sha256"],
          p["jdk"]["release_sha256"]) == JDK_SHA256, "capture JDK identity differs")
    for name, expected in p["input_before"].items():
        need(identity(root / name)["sha256"] == expected, "capture executed input differs")
    for name, expected in p["source_before"].items():
        need(identity(root / "sources" / name)["sha256"] == expected,
             "capture copied source differs")
    sessions = p["sessions"]
    need(len(sessions) == 2 and [s["repeat"] for s in sessions] == [0, 1]
         and len({s["pid"] for s in sessions}) == 2
         and sessions[0]["finished_epoch"] <= sessions[1]["started_epoch"],
         "capture fresh ordered JVM coverage differs")
    raw_sets = []
    for session in sessions:
        folder = root / f"repeat-{session['repeat']}"
        need(session["exit_code"] == 0 and session["query_directories"] == expected_rows,
             "capture session incomplete")
        need(identity(folder / "process.stdout.bin")["sha256"] == session["stdout_sha256"]
             and identity(folder / "process.stderr.bin")["sha256"] == session["stderr_sha256"]
             and (folder / "process.stderr.bin").read_bytes() == b"",
             "capture process channel differs")
        counts = Counter()
        protocol = [f"session-open mode=string rows={expected_rows}"]
        for index, row in enumerate(rows):
            case = folder / f"{index:03d}-{row['id']}"
            need(case.is_dir() and row["mode"] == "string"
                 and (case / "expression.bin").read_text() == row["expression"],
                 "capture ordered row/expression differs")
            status = (case / "result.status.bin").read_text().strip()
            need(status in ("success", "error"), "capture nonordinary row status")
            counts[status] += 1
            call = f"string-{index}-{row['id']}"
            protocol.extend((f"call-enter={call}", f"call-exit={call} status={status}"))
        protocol.append(f"session-closed mode=string rows={expected_rows} public-calls={expected_rows} success={counts['success']} errors={counts['error']}")
        need((folder / "process.stdout.bin").read_bytes() == ("\n".join(protocol) + "\n").encode()
             and dict(counts) == a["statuses"], "capture whole protocol/status differs")
        raw = {path.relative_to(folder).as_posix(): identity(path)["sha256"]
               for path in folder.rglob("*") if path.is_file()}
        need(len(raw) == expected_raw_files, "capture raw channel count differs")
        raw_sets.append(raw)
    need(raw_sets[0] == raw_sets[1], "capture raw repetitions differ")
    return {"path": root.relative_to(ROOT).as_posix(), "rows": expected_rows,
            "statuses_per_session": a["statuses"], "pids": [s["pid"] for s in sessions],
            "source_files": len(p["source_before"]), "raw_files_per_repetition": expected_raw_files,
            "source_stable": p["stable"], "raw_repetitions_equal": p["raw_equal"]}

def main():
    validation = json.loads((VALIDATION / "validation.json").read_bytes())
    need(validation["baseline_head"] == EXPECTED_HEAD and validation["complete"] is True
         and validation["source_stable"] is True and validation["snapshot_matches"] is True
         and len(validation["checks"]) == 5
         and all(check["exit_code"] == 0 for check in validation["checks"]),
         "fresh Java A3 validation incomplete")
    for name, expected in validation["source_before"].items():
        need(identity(VALIDATION / "sources" / name)["sha256"] == expected,
             "validation copied source differs")
    early = check_capture(CAPTURES[0], 127, {"success": 75, "error": 52}, 2669)
    middle = check_capture(CAPTURES[1], 129, {"success": 79, "error": 50}, 2711)
    canonical = check_capture(CAPTURES[2], 133, {"success": 82, "error": 51}, 2795)
    fixture_identity = json.loads((FIXTURE / "archive-identity.json").read_bytes())
    need(fixture_identity["captures"] == {"capture-03": CAPTURES[2].name}
         and fixture_identity["members"] == 5666
         and fixture_identity["archive_sha256"] == identity(FIXTURE / "oracle-evidence.tar.gz")["sha256"],
         "canonical fixture identity differs")
    for name in ("cases.json", "queries.tsv", "module.pkl"):
        need((FIXTURE / name).read_bytes() == (CAPTURES[2] / name).read_bytes(),
             "canonical authored input differs")
    files = paths_under(VALIDATION, "validation/")
    for root in CAPTURES:
        files.update(paths_under(root, f"captures/{root.name}/"))
    files.update(paths_under(ROOT / "target/m2/stage62-lookups-java-publication-attempt-01", "publication-attempt-01/"))
    evidence = emit_archive(REPORTS / "stage62-lookups-java-evidence.tar.gz", files)
    checkpoint = {
        "schema": 1, "kind": "stage62-collection-lookups-java-authority-checkpoint",
        "baseline": "Pkl 0.32.0", "baseline_head": EXPECTED_HEAD,
        "candidate_compatibility_passes_claimed": 0,
        "canonical": {**canonical, "fixture": FIXTURE.relative_to(ROOT).as_posix(),
                      "module_uri": "file:///stage62/collection-lookups.pkl",
                      "archive_prefix": "capture-03",
                      "fixture_archive": identity(FIXTURE / "oracle-evidence.tar.gz"),
                      "fixture_archive_members": fixture_identity["members"],
                      "fixture_fileset_sha256": fixture_identity["fileset_sha256"]},
        "publication_history": {"attempt_01": {"checkpoint": identity(ROOT / "target/m2/stage62-lookups-java-publication-attempt-01/stage62-lookups-java-checkpoint.json"), "evidence": identity(ROOT / "target/m2/stage62-lookups-java-publication-attempt-01/stage62-lookups-java-evidence.tar.gz"), "correction": "Capture 01 history prose understated five receiver corrections as four; original publication bytes are archived."}},
        "history": {
            CAPTURES[0].name: {**early,
                "reason_superseded": "Five inline Dynamic entry expressions used the wrong receiver for the module marker; capture 02 corrected those expressions, added two rows, and renamed one wrong-key row."},
            CAPTURES[1].name: {**middle,
                "reason_superseded": "Capture 03 added external method and hidden default controls to the corrected matrix."},
        },
        "java_runtime": {"artifact_sha256": JAR_SHA256,
                         "jdk_executable_sha256": JDK_SHA256[0],
                         "jdk_modules_sha256": JDK_SHA256[1],
                         "jdk_release_sha256": JDK_SHA256[2],
                         "reference_revision": "e51fb2f91774265666f94980ec630db794a4db2d"},
        "validation": {"directory": VALIDATION.relative_to(ROOT).as_posix(),
                       "record": (VALIDATION / "validation.json").relative_to(ROOT).as_posix(),
                       "record_identity": identity(VALIDATION / "validation.json"),
                       "checks": validation["checks"],
                       "source_stable": validation["source_stable"],
                       "copied_sources": len(validation["source_before"])},
        "evidence": evidence,
        "limits": ["Public Java string observations only; no Rust candidate pass is claimed.",
                   "Unpaired surrogate names require UTF-16 code unit channels; Java UTF-8 is lossy.",
                   "Typed Java export and wrapper reference identity remain unverified.",
                   "M2 manifest freshness is deferred until concurrent Rust source changes freeze.",
                   "Original upstream programs, browser, Node, full M2 and performance gates remain separate."],
    }
    dest = REPORTS / "stage62-lookups-java-checkpoint.json"
    need(not dest.exists(), "fresh Java A3 checkpoint required")
    dest.write_text(json.dumps(checkpoint, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"checkpoint": identity(dest), "evidence": evidence}, sort_keys=True))

if __name__ == "__main__":
    main()
