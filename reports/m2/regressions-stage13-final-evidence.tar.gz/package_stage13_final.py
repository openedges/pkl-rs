"""Package final Stage 13 local evidence only after all fresh captures finish.

This helper reads raw evidence and runs integrity gates; it never acquires a
corpus or executes retained candidate binaries. Exact implementation-commit
binding is a separate later operation. Existing outputs are never replaced.
"""
import argparse
import hashlib
import importlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
from collections import Counter

sys.dont_write_bytecode = True
ROOT = Path.cwd()
BASE = ROOT / 'target/m2'
REPORTS = ROOT / 'reports/m2'
DIRECTORIES = {name: BASE / (name + '-stage13-final')
               for name in ['language', 'validation', 'platforms', 'frontend', 'runtime', 'lifecycle']}
DIRECTORIES.update(classes=BASE / 'stage13-declaration-lifecycle-final',
                   prior=BASE / 'prior-selection-stage13-preflight-01')
KNOWN_LANGUAGE = {'error-cycle', 'error-remainder-zero'}
KNOWN_REGEX = {'regex-unicode-15-vs-16', 'regex-zero-width-supplementary'}
BASELINE = BASE / 'stage13-baseline'


def load(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def identity(path, expected, size=None):
    if sha(path) != expected or (size is not None and path.stat().st_size != size):
        raise ValueError('Evidence identity differs: ' + str(path))


def source_map(directory, mapping):
    for name, digest in mapping.items():
        identity(directory / 'sources' / name, digest)
        identity(ROOT / name, digest)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def exact_ids(rows, expected, label):
    actual = [row['id'] for row in rows]
    require(actual and len(actual) == len(set(actual)), label + ': empty or duplicate IDs')
    require(actual == expected, label + ': missing, unexpected, or reordered IDs')


def selected_contract(language):
    frozen_path = DIRECTORIES['language'] / 'sources/tests/fixtures/m2/cases.json'
    frozen = load(frozen_path)['cases']
    original = load(BASELINE / 'cases.json')['cases']
    baseline = load(BASELINE / 'baseline.json')
    identity(BASELINE / 'cases.json', baseline['case_manifest_sha256'])
    require(len(original) == baseline['case_count'], 'Frozen original case count differs')
    require(frozen[:len(original)] == original, 'Original selected definitions/order changed')
    require(frozen_path.read_bytes() == (ROOT / 'tests/fixtures/m2/cases.json').read_bytes(),
            'Current selection differs from final frozen selection')
    exact_ids(frozen, [row['id'] for row in frozen], 'Frozen selection')
    exact_ids(language['results'], [row['id'] for row in frozen], 'Final language results')
    require(language['selected_count'] == len(frozen), 'Selected count differs from frozen selection')
    relations = []
    for row in frozen:
        relation = row.get('metamorphic_relation')
        if relation is not None and relation not in relations:
            relations.append(relation)
    observed_relations = [{key: row[key] for key in ['case_ids', 'domain', 'kind']}
                          for row in language['metamorphic_results']]
    require(observed_relations == sorted(relations, key=lambda row: tuple(row['case_ids'])),
            'Final relation definitions/canonical order differ from selection')
    for name, record in baseline['inputs'].items():
        identity(ROOT / name, record['sha256'], record['bytes'])
        identity(DIRECTORIES['language'] / 'sources' / name, record['sha256'], record['bytes'])
    return dict(selected=len(frozen), original_selected=len(original),
                added_selected=len(frozen) - len(original), relations=len(relations),
                original_definitions_preserved=True, original_input_bytes_preserved=True,
                exact_result_order=True, frozen_selection_sha256=sha(frozen_path),
                baseline_metadata_sha256=sha(BASELINE / 'baseline.json'))


def platform_claims(platforms, platform_tool):
    directory = DIRECTORIES['platforms']
    execution = load(directory / 'execution/execution.json')
    node = load(directory / 'execution/node-checks.json')
    browser = load(directory / 'execution/browser-checks.json')
    require(platforms['execution'] == execution, 'Platform execution differs from retained execution.json')
    require(execution['nodeChecks'] == node, 'Node checks differ from retained scenario list')
    require(execution['browserChecks'] == browser, 'Browser checks differ from retained scenario list')
    platform_tool.check_scenarios(execution)
    captures = {name: (directory / relative).read_bytes() for name, relative in [
        ('java', 'oracle-native/java.stdout.bin'), ('rust', 'oracle-native/rust.stdout.bin'),
        ('node', 'execution/node.stdout.bin'), ('browser', 'execution/browser.stdout.bin')]}
    rows = platform_tool.compare(platform_tool.generate_cases()['cases'], captures)
    require(rows == platforms['comparisons'], 'Platform comparisons disagree with raw captures')
    counts = dict(total=len(rows), shared_engine_passed=sum(row['shared_engine_match'] for row in rows),
                  oracle_passed={target: sum(row['oracle_matches'][target] for row in rows)
                                 for target in ['rust', 'node', 'browser']})
    for key, value in counts.items():
        require(platforms[key] == value, 'Platform exported raw count differs: ' + key)
    require(execution['total'] == counts['total'], 'Platform execution denominator differs')
    require(set(platforms['known_gaps']) == KNOWN_REGEX, 'Platform known regex gaps changed')
    return dict(counts, node_scenarios=len(node), browser_scenarios=len(browser),
                report_execution_equals_retained=True, scenario_lists_equal_retained=True,
                comparisons_recomputed_from_raw=True,
                oracle_mismatch_ids={target: [row['id'] for row in rows if not row['oracle_matches'][target]]
                                     for target in ['rust', 'node', 'browser']})


def class_contract(classes):
    directory = DIRECTORIES['classes']
    relative = Path('compatibility/m2-class-lifecycle')
    original = load(BASELINE / 'class-manifest.json')
    current = load(directory / 'sources' / relative / 'manifest.json')
    metadata = load(BASELINE / 'baseline.json')['prior_class_sequences']
    identity(BASELINE / 'class-manifest.json', metadata['manifest_sha256'])
    require(current['sequences'][:len(original['sequences'])] == original['sequences'],
            'Original class sequence definitions/order changed')
    for key in ['uri', 'module_name', 'power_assertions']:
        require(current[key] == original[key], 'Original sequence context changed: ' + key)
    for name, digest in metadata['source_hashes'].items():
        identity(ROOT / name, digest)
        identity(directory / 'sources' / name, digest)
    repetitions = classes['repetitions']
    require(repetitions == metadata['repetitions'], 'Sequence repetition count changed')
    expected_rows = [(spec['id'], repetition) for spec in current['sequences']
                     for repetition in range(repetitions)]
    require([(row['id'], row['repetition']) for row in classes['cases']] == expected_rows,
            'Class sequence rows missing, duplicated, or reordered')
    expected_calls = sum(len((directory / 'sources' / relative / spec['expressions']).read_text().splitlines())
                         for spec in current['sequences']) * repetitions
    calls = [call for row in classes['cases'] for call in row['observations']['comparisons']]
    require(len(calls) == expected_calls and all(call['status'] == 'pass' for call in calls),
            'Class call denominator or outcome differs from frozen manifest')
    previous_summary = load(REPORTS / 'stage12-final-summary.json')
    previous_identity = previous_summary['source_report_identities']['classes']
    previous = Path(previous_identity['path']).parent
    identity(previous / 'report.json', previous_identity['sha256'])
    previous_report = load(previous / 'report.json')
    original_rows = classes['cases'][:len(original['sequences']) * repetitions]
    require([(row['id'], row['repetition']) for row in original_rows] ==
            [(row['id'], row['repetition']) for row in previous_report['cases']],
            'Original class sequence execution order changed')
    original_calls = 0
    for row, old in zip(original_rows, previous_report['cases']):
        require(row['observations']['comparisons'] == old['observations']['comparisons'],
                'Original class call rows differ')
        for engine in ['java', 'rust']:
            require(row['observations']['processes'][engine]['calls'] ==
                    old['observations']['processes'][engine]['calls'],
                    'Original class observation identities differ: ' + engine)
            for call in row['observations']['processes'][engine]['calls']:
                for channel in ['status', 'stdout', 'stderr', 'error-class']:
                    name = f"{call['index']}.{channel}.bin"
                    observed = directory / row['directory'] / engine / name
                    retained = previous / old['directory'] / engine / name
                    require(observed.read_bytes() == retained.read_bytes(),
                            'Original class raw bytes differ: ' + str(observed))
        original_calls += len(row['observations']['comparisons'])
    require(original_calls == metadata['call_comparisons'], 'Original class call count changed')
    return dict(unique_sequences=len(current['sequences']), sequence_executions=len(classes['cases']),
                call_comparisons=len(calls), passing_calls=len(calls),
                original_sequences=len(original['sequences']), original_call_comparisons=original_calls,
                added_sequences=len(current['sequences']) - len(original['sequences']),
                added_call_comparisons=len(calls) - original_calls,
                original_definitions_order_and_raw_bytes_preserved=True,
                frozen_manifest_sha256=sha(directory / 'sources' / relative / 'manifest.json'),
                previous_report_sha256=previous_identity['sha256'])


def raw_process(process):
    if process['status'] != 'executed':
        raise ValueError('Process was not executed: ' + repr(process['command']))
    values = []
    for name in ['stdout', 'stderr']:
        row = process[name]
        path = Path(row['path'])
        identity(path, row['sha256'], row['bytes'])
        values.append(path.read_bytes())
    return process['exit_code'], *values


def validation_report(directory):
    report = load(directory / 'report.json')
    required = [
        ['cargo', 'xtask', 'verify'], ['cargo', 'fmt', '--all', '--', '--check'],
        ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--', '-D', 'warnings'],
        ['cargo', 'test', '--workspace', '--locked'],
        ['cargo', 'check', '-p', 'pkl-runtime', '--target', 'wasm32-unknown-unknown', '--locked'],
    ]
    if [r['command'] for r in report['checks'][:5]] != required:
        raise ValueError('Required Rust verification command inventory differs')
    rust_output = python_output = None
    for index, row in enumerate(report['checks']):
        if row['exit_code'] != 0:
            raise ValueError('Required verification failed: ' + repr(row['command']))
        captures = {}
        for channel in ['stdout', 'stderr']:
            path = directory / f'{index}.{channel}.bin'
            identity(path, row[channel + '_sha256'])
            captures[channel] = path.read_bytes().decode()
        if row['command'] == required[3]:
            rust_output = captures['stdout'] + captures['stderr']
        if row['command'][1:] == ['-m', 'unittest', 'discover', '-s', 'tools/tests', '-v']:
            python_output = captures['stdout'] + captures['stderr']
    if len(report['checks']) != 7 or report['checks'][6]['command'][1:] != ['tools/m2_manifest.py', '--check']:
        raise ValueError('Python/inventory verification command inventory differs')
    rust_rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', rust_output or '')
    python_rows = re.findall(r'Ran (\d+) tests? in ', python_output or '')
    if not rust_rows or len(python_rows) != 1 or not re.search(r'\nOK\s*$', python_output or ''):
        raise ValueError('Missing successful raw Rust/Python test summaries')
    counts = dict(rust_passed=sum(int(row[0]) for row in rust_rows),
                  rust_intentionally_ignored=sum(int(row[2]) for row in rust_rows),
                  python_passed=int(python_rows[0]))
    if any(int(row[1]) for row in rust_rows) or not counts['rust_passed'] or not counts['python_passed']:
        raise ValueError('Failed or empty verification summaries')
    return dict(report, **counts, evidence_sha256={str(p.relative_to(directory)): sha(p)
                for p in sorted(directory.rglob('*')) if p.is_file()})


def inspect():
    sys.path.insert(0, str(ROOT / 'tools'))
    language_tool = importlib.import_module('m2_language')
    frontend_tool = importlib.import_module('m1_frontend')
    lifecycle_tool = importlib.import_module('m1_lifecycle')
    platform_tool = importlib.import_module('m1_platforms')
    class_tool = importlib.import_module('m2_class_lifecycle')
    runtime_tool = importlib.import_module('m1_runtime')
    language = language_tool.check_report(DIRECTORIES['language'])
    if not language_tool.development_passes(language, DIRECTORIES['language']):
        raise ValueError('Language selected development contract failed')
    if language_tool.subset_passes(language) or not language['full_gate_failures']:
        raise ValueError('Strict compatibility incompleteness unexpectedly changed')
    selection_counts = selected_contract(language)
    if {r['id'] for r in language['results'] if r['status'] != 'pass'} != KNOWN_LANGUAGE:
        raise ValueError('Existing selected failure inventory changed')
    if not all(r['status'] == 'pass' for r in language['metamorphic_results']):
        raise ValueError('Existing metamorphic contract changed')
    if not language['source_stability'] or not language['artifact_stability'] or language['candidate']['source_binding'] != 'recorded-build':
        raise ValueError('Fresh language build identity/stability failed')
    source_map(DIRECTORIES['language'], language['source_sha256'])
    frontend = frontend_tool.check_report(DIRECTORIES['frontend'])
    if not frontend['source_stability'] or not all(r['passed'] for r in frontend['results']):
        raise ValueError('Frontend comparison failed')
    source_map(DIRECTORIES['frontend'], frontend['source_sha256'])
    identity(Path(frontend['rust_artifact']['path']), frontend['rust_artifact']['sha256'])
    lifecycle = lifecycle_tool.check_report(DIRECTORIES['lifecycle'])
    if not lifecycle['source_stability_before_execution'] or not lifecycle['source_stability_after_execution']:
        raise ValueError('Lifecycle sources changed during capture')
    source_map(DIRECTORIES['lifecycle'], {r['path']: r['sha256'] for r in lifecycle['sources']})
    platforms = load(DIRECTORIES['platforms'] / 'report.json')
    platform_audit = platform_claims(platforms, platform_tool)
    rows = platforms['comparisons']
    if not platforms['source_stability'] or not platform_tool.contract_matches(rows):
        raise ValueError('Platform shared-engine or exact known-gap contract failed')
    if platforms['compatibility_status'] != 'fail' or platforms['experiment_contract_status'] != 'pass' or set(platforms['known_gaps']) != KNOWN_REGEX:
        raise ValueError('Platform compatibility/architecture outcomes changed')
    source_map(DIRECTORIES['platforms'], platforms['source_hashes'])
    for path, digest in platforms['artifacts'].items():
        identity(DIRECTORIES['platforms'] / path, digest)
    runtime = load(DIRECTORIES['runtime'] / 'report.json')
    if [r['id'] for r in runtime['cases']] != list(runtime_tool.SUCCESS_CASES + runtime_tool.ERROR_CASES):
        raise ValueError('Runtime case coverage changed')
    for item in runtime['identities']:
        path = Path(item.get('snapshot', item['path']))
        identity(path, item['sha256'], item.get('bytes'))
        if 'snapshot' in item:
            identity(Path(item['path']), item['sha256'], item.get('bytes'))
    mismatches = []
    for row in runtime['cases']:
        java, rust = raw_process(row['java']), raw_process(row['rust'])
        if row['raw_equal'] != (java == rust):
            raise ValueError('Runtime raw verdict changed')
        if row['id'] in runtime_tool.SUCCESS_CASES:
            if java != rust or java[0] != 0 or java[2]:
                raise ValueError('Runtime value mismatch')
        else:
            if java[0] != 1 or rust[0] != 1:
                raise ValueError('Runtime error outcome changed')
            if java != rust:
                mismatches.append(row['id'])
    if mismatches != ['forcing-cycle']:
        raise ValueError('Runtime full diagnostic known-gap inventory changed')
    classes = class_tool.check_report(DIRECTORIES['classes'])
    if not class_tool.contract_passes(classes):
        raise ValueError('Class sequence selected contract failed')
    class_counts = class_contract(classes)
    source_map(DIRECTORIES['classes'], {r['path']: r['sha256'] for r in classes['sources']})
    prior = load(DIRECTORIES['prior'] / 'report.json')
    prior_inventory = load(DIRECTORIES['prior'] / 'evidence-sha256.json')
    observed_prior = {str(p.relative_to(DIRECTORIES['prior'])) for p in DIRECTORIES['prior'].rglob('*')
                      if p.is_file() and p.name != 'evidence-sha256.json'}
    if set(prior_inventory) != observed_prior:
        raise ValueError('Prior selection evidence inventory incomplete')
    for name, digest in prior_inventory.items():
        identity(DIRECTORIES['prior'] / name, digest)
    candidate = load(DIRECTORIES['prior'] / 'candidate.json')
    identity(DIRECTORIES['prior'] / 'artifacts/language_probe', candidate['sha256'])
    baseline_metadata = load(DIRECTORIES['prior'] / 'baseline.json')
    baseline_dir = Path(baseline_metadata['path'])
    identity(baseline_dir / 'report.json', baseline_metadata['report_sha256'])
    original_baseline = load(BASELINE / 'baseline.json')
    require((baseline_dir / 'report.json').resolve() == Path(original_baseline['prior_language_report']).resolve(),
            'Prior replay does not use retained Stage 12 Java report')
    require(baseline_metadata['report_sha256'] == original_baseline['prior_language_report_sha256'],
            'Prior Java report differs from immutable Stage 13 baseline identity')
    baseline_report = load(baseline_dir / 'report.json')
    baseline_rows = {r['id']: r for r in baseline_report['results']}
    original_selection = load(DIRECTORIES['prior'] / 'original-selection.json')['cases']
    current_selection = load(ROOT / 'tests/fixtures/m2/cases.json')['cases']
    require(original_selection == load(BASELINE / 'cases.json')['cases'],
            'Prior replay original selection differs from immutable Stage 13 baseline')
    require(current_selection[:len(original_selection)] == original_selection,
            'Original independent selected prefix definitions changed')
    expected_prior_ids = [row['id'] for row in original_selection]
    exact_ids(prior['results'], expected_prior_ids, 'Prior replay')
    exact_ids(baseline_report['results'], expected_prior_ids, 'Retained prior Java report')
    definitions = {r['id']: r for r in original_selection}
    observed_statuses = []
    for row in prior['results']:
        folder = DIRECTORIES['prior'] / 'cases' / row['id']
        baseline_folder = baseline_dir / 'cases' / row['id']
        java = baseline_rows[row['id']]['java']
        if load(folder / 'rust.process.json') != row['rust']:
            raise ValueError('Prior replay process metadata differs from report')
        identity(folder / 'input.pkl', row['input_sha256'])
        if (folder / 'input.pkl').read_bytes() != (baseline_folder / 'input.pkl').read_bytes():
            raise ValueError('Original Java/Rust input bytes differ')
        for engine, process, capture_directory in [('java', java, baseline_folder), ('rust', row['rust'], folder)]:
            for channel in ['stdout', 'stderr']:
                identity(capture_directory / (engine + '.' + channel + '.bin'), process[channel + '_sha256'])
        identity(baseline_folder / 'java.outcome.bin', java['outcome_sha256'])
        observed_status = language_tool.status(definitions[row['id']], java, row['rust'],
            (baseline_folder / 'java.stdout.bin').read_bytes(), (baseline_folder / 'java.stderr.bin').read_bytes(),
            (folder / 'rust.stdout.bin').read_bytes(), (folder / 'rust.stderr.bin').read_bytes(),
            (baseline_folder / 'java.outcome.bin').read_bytes())
        if row['status'] != observed_status:
            raise ValueError('Prior selection verdict differs from original raw bytes')
        observed_statuses.append(observed_status)
    if dict(Counter(observed_statuses)) != prior['status_counts']:
        raise ValueError('Prior selection counts disagree with raw bytes')
    if {r['id'] for r in prior['results'] if r['status'] != 'pass'} != KNOWN_LANGUAGE:
        raise ValueError('Prior selection known outcomes changed')
    require(prior['status_counts'] == dict(Counter(row['status'] for row in language['results'][:len(original_selection)])),
            'Original selected prefix outcomes differ between replay and final fresh capture')
    return dict(language=language, platforms=platforms, frontend=frontend, runtime=runtime,
                lifecycle=lifecycle, classes=classes, class_counts=class_counts, prior=prior,
                selection_counts=selection_counts, platform_audit=platform_audit,
                validation=validation_report(DIRECTORIES['validation']))


def archive(source, destination):
    if destination.exists():
        raise ValueError('Refusing to replace prior archive: ' + str(destination))
    command = [sys.executable, str(ROOT / 'tools/evidence.py'), 'create', str(source), str(destination),
               '--exclude', 'build/*', '--exclude', '__pycache__/*', '--exclude', '*/__pycache__/*']
    subprocess.run(command, check=True)
    subprocess.run([sys.executable, str(ROOT / 'tools/evidence.py'), 'verify', str(destination)], check=True)
    with tarfile.open(destination, 'r:gz') as stream:
        files = len(stream.getmembers())
    return dict(path=str(destination.relative_to(ROOT)), sha256=sha(destination),
                bytes=destination.stat().st_size, files_including_inventory=files, inventory_verified=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-ready', action='store_true', help='verify final captures without packaging')
    args = parser.parse_args()
    data = inspect()
    if args.check_ready:
        print(json.dumps(dict(status='ready', selection=data['selection_counts'],
              class_counts=data['class_counts'], platforms=data['platform_audit'],
              validation={key: data['validation'][key] for key in
                          ['rust_passed', 'rust_intentionally_ignored', 'python_passed']}), sort_keys=True))
        return
    archive_names = ['language', 'validation', 'platforms', 'gates', 'regressions', 'class-lifecycle']
    outputs = [REPORTS / name for name in ['stage13-final-summary.json', 'validation-stage13-final.json']]
    outputs += [REPORTS / (name + '-stage13-final-evidence.tar.gz') for name in archive_names]
    gates_dir, regressions_dir = BASE / 'gates-stage13-final', BASE / 'regressions-stage13-final'
    require(not any(path.exists() for path in [*outputs, gates_dir, regressions_dir]),
            'Refusing to replace an existing Stage 13 final output')
    gates_dir.mkdir()
    gates = []
    for name, expected in [('report', 0), ('development', 0), ('subset', 1), ('full', 1)]:
        command = [sys.executable, 'tools/m2_language.py', '--verify-' + name, str(DIRECTORIES['language'])]
        result = subprocess.run(command, cwd=ROOT, capture_output=True)
        row = dict(gate=name, command=command, exit_code=result.returncode, expected_exit_code=expected)
        for channel in ['stdout', 'stderr']:
            capture_path = gates_dir / (name + '.' + channel + '.bin')
            capture_path.write_bytes(getattr(result, channel))
            row[channel + '_sha256'] = sha(capture_path)
        gates.append(row)
        require(result.returncode == expected,
                'Unexpected gate result; original failure capture retained: ' + name)
    write_new(gates_dir / 'report.json', dict(
        scope='Raw integrity and selected development gates; strict selected/full compatibility failures retained.',
        rows=gates))
    regressions_dir.mkdir()
    for name in ['frontend', 'runtime', 'lifecycle', 'prior']:
        shutil.copytree(DIRECTORIES[name], regressions_dir / name,
                        ignore=shutil.ignore_patterns('build', '__pycache__'))
    shutil.copytree(BASELINE, regressions_dir / 'immutable-stage13-baseline')
    for helper in ['package_stage13_final.py', 'verify_stage13_implementation_sources.py']:
        shutil.copyfile(BASE / helper, regressions_dir / helper)
    write_new(regressions_dir / 'raw-claims-audit.json', dict(
        scope='Read-only recomputation from retained payloads; no new compatibility cases or captured binary execution.',
        status='pass', captured_binaries_executed=False,
        selection=data['selection_counts'], class_sequences=data['class_counts'],
        platforms=data['platform_audit'],
        prior_replay=dict(result_count=len(data['prior']['results']),
                          unique_ids=len({row['id'] for row in data['prior']['results']}),
                          exact_original_order=True, current_selected_prefix_equals_original=True)))
    archive_sources = dict(DIRECTORIES, gates=gates_dir, regressions=regressions_dir,
                           **{'class-lifecycle': DIRECTORIES['classes']})
    archives = {name: archive(archive_sources[name], REPORTS / (name + '-stage13-final-evidence.tar.gz'))
                for name in archive_names}
    language, platforms, lifecycle = data['language'], data['platforms'], data['lifecycle']
    summary = dict(schema_version=1,
        scope='Stage 13 bounded evaluator-owned TypeAlias values, named alias metadata, function type metadata and arity checks. Full M2 language/API compatibility and performance targets remain incomplete.',
        full_m2_complete=False,
        source_to_commit_binding='Pending separate exact implementation-commit verification; source snapshots and recorded-build identities verified here.',
        language={key: language[key] for key in ['selected_count', 'status_counts', 'source_stability', 'artifact_stability', 'candidate', 'inventory_counts']},
        class_lifecycle=dict(data['class_counts'], compatibility_complete=False,
            evidence=archives['class-lifecycle'], unexecuted_groups=data['classes']['unexecuted_groups'],
            scope='Ordered calls share one evaluator/module, including failures and retries; separate from independent selected expressions.'),
        platforms={key: platforms[key] for key in ['total', 'oracle_passed', 'shared_engine_passed', 'compatibility_status', 'known_gaps', 'experiment_contract_status', 'source_stability']},
        regressions=dict(frontend_raw_matches=sum(row['passed'] for row in data['frontend']['results']),
            runtime_value_matches=sum(row['status'] == 'bounded-value-bytes-match' for row in data['runtime']['cases']),
            runtime_diagnostic_matches=sum(row['status'] == 'diagnostic-bytes-match' for row in data['runtime']['cases']),
            runtime_diagnostic_mismatches=sum(row['status'] == 'diagnostic-byte-mismatch' for row in data['runtime']['cases']),
            runtime_known_diagnostic_mismatch_ids=['forcing-cycle'],
            lifecycle_protocol_matches=sum(row['observations']['protocol_raw_equal'] for row in lifecycle['cases']),
            lifecycle_full_diagnostic_mismatches=sum(not item['raw_equal'] for row in lifecycle['cases'] for item in row['observations']['diagnostics'])),
        validation={key: data['validation'][key] for key in ['rust_passed', 'rust_intentionally_ignored', 'python_passed']},
        prior_selection_replay=dict(count=len(data['prior']['results']), status_counts=data['prior']['status_counts'],
            exact_original_ids_order_and_input_bytes=True,
            scope='Original selected prefix against retained Stage 12 complete Java bytes with the frozen preflight candidate; final fresh Java acquisition remains separate.'),
        final_claims_audit=dict(status='pass', captured_binaries_executed=False,
                               selection=data['selection_counts'], platforms=data['platform_audit']),
        gates=gates, archives=archives,
        exploration_evidence='Preserved separately by acquisition owner; not a dependency or passing compatibility count.',
        source_report_identities={name: dict(path=str(directory / 'report.json'), sha256=sha(directory / 'report.json'))
                                 for name, directory in DIRECTORIES.items()},
        reviewed_mappings=dict(count=len(load(ROOT / 'compatibility/m2-mappings.json')['requirements']),
                               scope='Partial reviewed mappings; strict full-gate failures remain open.'))
    summary['language'].update(data['selection_counts'], source_snapshot_count=len(language['source_sha256']),
        metamorphic_relations=len(language['metamorphic_results']),
        metamorphic_statuses=[row['status'] for row in language['metamorphic_results']],
        full_gate_failure_reasons=len(language['full_gate_failures']),
        known_failures=[dict(id=row['id'], status=row['status']) for row in language['results'] if row['status'] != 'pass'],
        power_assertion_profiles=sum(row.get('power_assertions', False)
                                     for row in load(DIRECTORIES['language'] / 'sources/tests/fixtures/m2/cases.json')['cases']))
    summary['platforms'].update(node_scenarios=len(platforms['execution']['nodeChecks']),
                                browser_scenarios=len(platforms['execution']['browserChecks']))
    write_new(REPORTS / 'validation-stage13-final.json', data['validation'])
    write_new(REPORTS / 'stage13-final-summary.json', summary)
    print(json.dumps(dict(summary='reports/m2/stage13-final-summary.json', validation=summary['validation'],
                         language=language['status_counts'], class_counts=data['class_counts'], archives=archives), sort_keys=True))


if __name__ == '__main__':
    main()
