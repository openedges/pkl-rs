extern crate pkl_runtime;
use pkl_runtime::{parser::parse_module,resolver::resolve_module,vm::{compile_module,Vm,VmPoll}};
fn main(){
 std::thread::Builder::new().stack_size(256*1024).spawn(||{
  eprintln!("phase parse");
  let source=format!("result = {}42{}\n", "\"\\(".repeat(31), ")\"".repeat(31));
  let parsed=parse_module(&source).unwrap();
  eprintln!("phase resolve");
  let resolved=resolve_module(&parsed).unwrap();
  eprintln!("phase compile");
  let program=compile_module(&resolved).unwrap();
  eprintln!("phase vm-new");
  let mut vm=Vm::new(program.clone());
  eprintln!("phase start");vm.start(program.entry,vec![]).unwrap();
  for i in 0..100000 {if i<10 {eprintln!("phase poll {i}");}match vm.poll(1){VmPoll::Yielded=>{},VmPoll::Ready(v)=>{eprintln!("phase ready {v:?}");break},other=>panic!("{other:?}")}}
  vm.close();eprintln!("phase close {:?}",vm.heap_stats());
 }).unwrap().join().unwrap();
}
