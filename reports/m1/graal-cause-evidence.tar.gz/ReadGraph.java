import java.nio.file.*;
import java.nio.channels.*;
import jdk.graal.compiler.graphio.parsing.*;
import jdk.graal.compiler.graphio.parsing.model.*;
public class ReadGraph {
 static void visit(Folder f) {
  for (FolderElement el : f.getElements()) {
   if(el instanceof Folder next) visit(next);
   if(el instanceof InputGraph g && g.getName().contains("After PE Tier")) {
    System.out.println("GRAPH " + g.getName());
    for(InputNode n:g.getNodes()) System.out.println("NODE " + n.getId()+" "+n.getProperties());
    for(InputEdge e:g.getEdges()) System.out.println("EDGE " + e.getFrom()+" -> "+e.getTo()+" "+e.getLabel()+" "+e.getType());
   }
  }
 }
 public static void main(String[]args)throws Exception {
  try(var channel=FileChannel.open(Path.of(args[0]))) {
   var doc=new GraphDocument();
   new BinaryReader(new BinarySource(args[0],channel),new ModelBuilder(doc,null)).parse();
   visit(doc);
  }
 }
}
