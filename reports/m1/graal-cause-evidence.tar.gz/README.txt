This folder is a compiler diagnostic graph capture, not a performance measurement.

findings.json records the concrete graph witness. commands.json contains exact
commands, raw-channel hashes, exit codes and capture metadata. oracle.json and
oracle.lock.json identify the unchanged official Pkl 0.32.0 JAR and GraalVM CE
25.0.1. Source identities are in source-identities.json. Compiler source excerpts
were extracted from the identified Maven source JAR and were not loaded at runtime.

ReadGraph.java uses only the compiler graph parser already shipped in the pinned
GraalVM distribution. The compile/run module exports are recorded in commands.json.
The .bgv file is the original binary graph. parse-graph/stdout.bin is the complete
parser output without filtering. The selected graph files and findings are derived
inspection aids; they do not replace the complete graph and raw log.

To recreate using the same locked repository and archived inputs:
  python3 <extracted-directory>/reproduce.py <repository-root> <fresh-output-dir>

The driver snapshots all input code, performs the normal pinned-oracle identity
checks, records all subprocess commands, and never overwrites a prior output tree.
reproduce-executed.py preserves the exact initial graph capture driver. The current
reproduce.py differs only by preferring archived input snapshots and checking that
the current oracle lock still matches the archived lock. Required repository tooling
is also copied under tools-snapshot for inspection.

The generated workload is exactly the original M1 arithmetic source bytes.
Every diagnostic evaluation checks result bytes. This graph explains forced frame
materialization at the invisible-scope loop. The separate main M1 Graal evidence
contains baseline and diagnostic override executions for original arithmetic,
original recursive Fibonacci, and positive unmodified-JAR workloads.
