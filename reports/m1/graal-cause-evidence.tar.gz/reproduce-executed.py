#!/usr/bin/env python3
"""Diagnostic graph capture only; pass repository root and a fresh output directory."""
import hashlib, json, shutil, sys
from pathlib import Path
root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(root/'tools'))
from oracle import ensure_oracle
from benchmark import capture
meta = ensure_oracle(root, profile='performance')
(out/'oracle.json').write_text(json.dumps(meta, indent=2)+'\n')
(out/'ReadGraph.java').write_bytes(Path(__file__).with_name('ReadGraph.java').read_bytes())
(out/'reproduce.py').write_bytes(Path(__file__).read_bytes())
(out/'M1RuntimeProbe.java').write_bytes((root/'tools/java/M1RuntimeProbe.java').read_bytes())
(out/'arithmetic.pkl').write_bytes((root/'tests/fixtures/m1/runtime/arithmetic-workload.pkl').read_bytes())
exports = ['--add-modules=jdk.graal.compiler', '--add-exports=jdk.graal.compiler/jdk.graal.compiler.graphio.parsing=ALL-UNNAMED','--add-exports=jdk.graal.compiler/jdk.graal.compiler.graphio.parsing.model=ALL-UNNAMED']
java = Path(meta['java'])
results={}
def run(name, command):
 result = capture(command, root, meta['environment'], out/name, timeout=120)
 results[name]=result
 (out/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
 if result['exit_code'] != 0: raise RuntimeError(name)
run('compile-parser',[str(java.with_name('javac')), *exports, '-d',str(out/'parser-classes'),str(out/'ReadGraph.java')])
run('compile-probe',[str(java.with_name('javac')), '-proc:none','-cp',meta['artifact'],'-d',str(out/'probe-classes'),str(out/'M1RuntimeProbe.java')])
run('graph-capture', [*meta['command'][:-3],'-Dpolyglot.engine.TraceCompilation=true','-Dpolyglot.engine.CompilationFailureAction=Print','-Djdk.graal.TrackNodeSourcePosition=true','-Djdk.graal.Dump=:2','-Djdk.graal.MethodFilter=OptimizedCallTarget.profiledPERoot','-Djdk.graal.PrintCanonicalGraphStrings=true','-Djdk.graal.PrintCanonicalGraphStringFlavor=1','-Djdk.graal.CanonicalGraphStringsExcludeVirtuals=false',f'-Djdk.graal.DumpPath={out}/dumps','-cp',str(out/'probe-classes')+':'+meta['artifact'],'M1RuntimeProbe','compilation',str(out/'arithmetic.pkl'),'5','integer'])
graphs=list((out/'dumps').glob('TruffleHotSpotCompilation-*.bgv'))
if len(graphs)!=1: raise RuntimeError(f'Unexpected graph count {len(graphs)}')
run('parse-graph',[str(java),*exports,'-cp',str(out/'parser-classes'),'ReadGraph',str(graphs[0])])
