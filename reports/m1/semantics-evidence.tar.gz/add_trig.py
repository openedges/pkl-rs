from pathlib import Path
import urllib.request,re
registry=next(Path.home().glob('.cargo/registry/src/*/libm-0.2.16'))
refs=Path('tests/fixtures/m1/semantics/references')
for name in ['k_sin.c','k_cos.c']:
 (refs/('fdlibm-'+name)).write_bytes(urllib.request.urlopen('https://netlib.org/fdlibm/'+name).read())
for name in ['rem_pio2.rs','rem_pio2_large.rs']:
 (refs/('libm-0.2.16-'+name)).write_bytes((registry/'src/math'/name).read_bytes())
(refs/'libm-0.2.16-LICENSE.txt').write_bytes((registry/'LICENSE.txt').read_bytes())
a=(registry/'src/math/rem_pio2.rs').read_text().split('#[cfg(test)]')[0]
a=a.replace('use super::rem_pio2_large;','use super::large::rem_pio2_large;')
a=re.sub(r'#\[cfg_attr\(assert_no_panic, no_panic::no_panic\)\]\n','',a)
a=a.replace('const EPS: f64 = 2.2204460492503131e-16;', 'const EPS: f64 = f64::EPSILON;')
a=a.replace('''        #[cfg(all(target_arch = "x86", not(target_feature = "sse2")))]
        let tmp = force_eval!(tmp);
''','')
b=(registry/'src/math/rem_pio2_large.rs').read_text()
b=b.replace('#![allow(unused_unsafe)]','').replace('use super::scalbn;','use libm::scalbn;')
b=re.sub(r'#\[cfg_attr\([^\n]+\)\]\n','',b)
b=b.replace('super::floor(x)','x.floor()')
b=b.replace('#[cfg(any(target_pointer_width = "32", target_pointer_width = "16"))]\n','')
b=re.sub(r'#\[cfg\(target_pointer_width = "64"\)\]\nconst IPIO2: \[i32; 690\] = \[.*?\];','',b,flags=re.S)
b=b.replace('div!(e0 - 3, 24)','(e0 - 3) / 24')
port='''
// Trigonometric kernels below preserve fdlibm's evaluation order. The reducers
// are adapted from libm 0.2.16, using checked indexing and only the binary64
// constant table. Original sources/notices are retained in the fixture references.
#[allow(clippy::excessive_precision, clippy::approx_constant, clippy::assign_op_pattern,
        clippy::needless_range_loop, clippy::explicit_counter_loop)]
mod fdlibm_trig {
    // Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
    // Developed at SunSoft, a Sun Microsystems, Inc. business.
    // Permission to use, copy, modify, and distribute this
    // software is freely granted, provided that this notice
    // is preserved.
    macro_rules! i {
        ($array:expr, $index:expr) => { $array[$index] };
        ($array:expr, $index:expr, =, $rhs:expr) => { $array[$index] = $rhs };
        ($array:expr, $index:expr, +=, $rhs:expr) => { $array[$index] += $rhs };
        ($array:expr, $index:expr, -=, $rhs:expr) => { $array[$index] -= $rhs };
        ($array:expr, $index:expr, &=, $rhs:expr) => { $array[$index] &= $rhs };
        ($array:expr, $index:expr, ==, $rhs:expr) => { $array[$index] == $rhs };
    }
    fn kernel_sin(x: f64, y: f64, tail: bool) -> f64 {
        if x.abs().to_bits() >> 32 < 0x3e400000 { return x; }
        let s1 = f64::from_bits(0xbfc5555555555549);
        let s2 = f64::from_bits(0x3f8111111110f8a6);
        let s3 = f64::from_bits(0xbf2a01a019c161d5);
        let s4 = f64::from_bits(0x3ec71de357b1fe7d);
        let s5 = f64::from_bits(0xbe5ae5e68a2b9ceb);
        let s6 = f64::from_bits(0x3de5d93a5acfd57c);
        let z = x*x;
        let v = z*x;
        let r = s2+z*(s3+z*(s4+z*(s5+z*s6)));
        if tail { x-((z*(0.5*y-v*r)-y)-v*s1) } else { x+v*(s1+z*r) }
    }
    fn kernel_cos(x: f64, y: f64) -> f64 {
        let high = (x.to_bits() >> 32) & 0x7fffffff;
        if high < 0x3e400000 { return 1.0; }
        let c1 = f64::from_bits(0x3fa555555555554c);
        let c2 = f64::from_bits(0xbf56c16c16c15177);
        let c3 = f64::from_bits(0x3efa01a019cb1590);
        let c4 = f64::from_bits(0xbe927e4f809c52ad);
        let c5 = f64::from_bits(0x3e21ee9ebdb4b1c4);
        let c6 = f64::from_bits(0xbda8fae9be8838d4);
        let z = x*x;
        let r = z*(c1+z*(c2+z*(c3+z*(c4+z*(c5+z*c6)))));
        if high < 0x3fd33333 { return 1.0-(0.5*z-(z*r-x*y)); }
        let qx = if high > 0x3fe90000 {0.28125} else {f64::from_bits((high-0x00200000)<<32)};
        let hz=0.5*z-qx;
        let a=1.0-qx;
        a-(hz-(z*r-x*y))
    }
    pub(super) fn sin(x: f64) -> f64 {
        if !x.is_finite() { return f64::NAN; }
        if (x.abs().to_bits()>>32) <= 0x3fe921fb {return kernel_sin(x,0.0,false);}
        let (n,a,b)=reduce::rem_pio2(x);
        match n&3 {0=>kernel_sin(a,b,true),1=>kernel_cos(a,b),2=>-kernel_sin(a,b,true),_=>-kernel_cos(a,b)}
    }
    pub(super) fn cos(x: f64) -> f64 {
        if !x.is_finite() { return f64::NAN; }
        if (x.abs().to_bits()>>32) <= 0x3fe921fb {return kernel_cos(x,0.0);}
        let (n,a,b)=reduce::rem_pio2(x);
        match n&3 {0=>kernel_cos(a,b),1=>-kernel_sin(a,b,true),2=>-kernel_cos(a,b),_=>kernel_sin(a,b,true)}
    }
'''
p=Path('crates/pkl-runtime/src/numeric.rs');s=p.read_text()
s=s.replace('"sin" => libm::sin(value),','"sin" => fdlibm_trig::sin(value),').replace('"cos" => libm::cos(value),','"cos" => fdlibm_trig::cos(value),')
s += port+'\nmod reduce {\n'+a+'\n}\nmod large {\n'+b+'\n}\n}\n'
p.write_text(s)
