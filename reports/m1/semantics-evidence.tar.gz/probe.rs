use std::io::{self, BufRead};
fn main() {
    for line in io::stdin().lock().lines() {
        let line=line.unwrap();
        let (family,input)=line.split_once('\t').unwrap();
        let output=match family {
            "numeric"=>pkl_runtime::numeric::probe(input),
            "regex"=>pkl_runtime::regex::probe(input),
            _=>panic!("bad family"),
        }.unwrap();
        for byte in output.bytes() {print!("{byte:02x}");}
        println!();
    }
}
