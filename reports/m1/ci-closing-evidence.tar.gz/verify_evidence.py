"""Read-only exact-head GitHub evidence acquisition and raw verification."""
from pathlib import Path, PurePosixPath, PureWindowsPath
import hashlib
import json
import stat
import subprocess
import sys
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
HEAD = "6a5e4b50f45de75c9ff79b341e658ada5cb0d21b"
REPO = "luuvish/pkl-rs"
RUN = 39374668362
sys.path.insert(0, str(ROOT / "tools"))
import m1_frontend
import m1_host
import m1_platforms
import m1_runtime
import m1_lifecycle


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def acquire(endpoint, filename):
    result = subprocess.run(["gh", "api", endpoint], cwd=ROOT, capture_output=True, timeout=180)
    path = BASE / filename
    with path.open("xb") as stream:
        stream.write(result.stdout)
    if result.stderr:
        path.with_suffix(path.suffix + ".stderr.bin").write_bytes(result.stderr)
    if result.returncode:
        raise ValueError(f"GitHub API failed: {endpoint}, exit {result.returncode}")
    return path


def safe_extract(path, destination):
    destination.mkdir()
    root = destination.resolve()
    with zipfile.ZipFile(path) as archive:
        names = set()
        total = 0
        for member in archive.infolist():
            name = member.filename
            posix = PurePosixPath(name)
            windows = PureWindowsPath(name)
            mode = member.external_attr >> 16
            if (name in names or not name or "\\" in name or posix.is_absolute()
                    or windows.drive or ".." in posix.parts or stat.S_ISLNK(mode)
                    or stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise ValueError(f"Unsafe or duplicate ZIP member: {name!r}")
            names.add(name)
            total += member.file_size
            if total > 1_073_741_824:
                raise ValueError("ZIP uncompressed size exceeds 1 GiB acquisition limit")
            target = destination / name
            if not target.resolve().is_relative_to(root):
                raise ValueError(f"ZIP member escapes destination: {name!r}")
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member) as stream, target.open("xb") as output:
                    while data := stream.read(1024 * 1024):
                        output.write(data)
        if not names:
            raise ValueError("Empty evidence ZIP")
    return len(names), total


def git_bytes(relative):
    return subprocess.run(["git", "show", f"{HEAD}:{relative}"], cwd=ROOT,
                          capture_output=True, check=True).stdout


def snapshot_identity(path, relative, expected):
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != expected or data != git_bytes(relative):
        raise ValueError(f"Snapshot differs from exact committed head: {relative}")


def relocated_path(artifact, original, suite):
    prefix = f"/target/m1/{suite}/"
    if prefix not in original:
        raise ValueError(f"Unexpected remote evidence path: {original}")
    relative = PurePosixPath(original.split(prefix, 1)[1])
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError(f"Unsafe relocated evidence metadata: {original}")
    return artifact / suite / relative


def verify_oracle(metadata):
    lock_bytes = git_bytes("oracle.lock.json")
    lock = json.loads(lock_bytes)
    if (metadata["profile"] != "reference" or metadata["version"] != "0.32.0"
            or metadata["lock_sha256"] != hashlib.sha256(lock_bytes).hexdigest()
            or metadata["artifact_sha256"] != lock["artifact"]["sha256"]
            or metadata["source"] != lock["source"]
            or any(metadata["jdk"]["properties"].get(key) != value
                   for key, value in lock["jdk"]["properties"].items())):
        raise ValueError("Remote Java oracle provenance differs from pinned contract")


def verify(artifact):
    frontend = artifact / "ci-frontend"
    front = m1_frontend.check_report(frontend)
    verify_oracle(front["oracle"])
    if len(front["results"]) != 15 or not all(row["passed"] for row in front["results"]):
        raise ValueError("Frontend15 required comparisons missing")
    for relative, expected in front["source_sha256"].items():
        snapshot_identity(frontend / "sources" / relative, relative, expected)

    host_dir = artifact / "ci-host-java"
    host = m1_host.check_report(host_dir)
    verify_oracle(host["oracle"])
    if len(host["results"]) != 5 or not all(all(row["checks"].values()) for row in host["results"]):
        raise ValueError("JavaHost5 required observation suites missing")
    for relative, expected in host["source_sha256"].items():
        snapshot_identity(host_dir / "sources" / relative, relative, expected)

    runtime_dir = artifact / "ci-runtime"
    runtime = json.loads((runtime_dir / "report.json").read_text())
    verify_oracle(runtime["oracle"])
    expected_cases = list(m1_runtime.SUCCESS_CASES + m1_runtime.ERROR_CASES)
    if [row["id"] for row in runtime["cases"]] != expected_cases:
        raise ValueError("Runtime case coverage differs")
    successes, mismatches = [], []
    for row in runtime["cases"]:
        captures = {}
        for language in ("java", "rust"):
            process = row[language]
            if process["status"] != "executed":
                raise ValueError(f"Runtime process not executed: {row['id']}/{language}")
            channels = []
            for channel in ("stdout", "stderr"):
                info = process[channel]
                data = relocated_path(artifact, info["path"], "ci-runtime").read_bytes()
                if len(data) != info["bytes"] or hashlib.sha256(data).hexdigest() != info["sha256"]:
                    raise ValueError(f"Runtime capture hash differs: {row['id']}/{language}/{channel}")
                channels.append(data)
            captures[language] = (process["exit_code"], *channels)
        equal = captures["java"] == captures["rust"]
        if row["raw_equal"] != equal:
            raise ValueError(f"Runtime recorded equality wrong: {row['id']}")
        if row["id"] in m1_runtime.SUCCESS_CASES:
            if not equal or captures["java"][0] != 0 or captures["java"][2] != b"":
                raise ValueError(f"Runtime success mismatch: {row['id']}")
            successes.append(row["id"])
        else:
            if equal or captures["java"][0] != 1 or captures["rust"][0] != 1:
                raise ValueError(f"Runtime known diagnostic outcome changed: {row['id']}")
            mismatches.append(row["id"])
    for identity in runtime["identities"]:
        if "snapshot" in identity:
            path = relocated_path(artifact, identity["snapshot"], "ci-runtime")
            relative = identity["snapshot"].split("/target/m1/ci-runtime/sources/", 1)[1]
            snapshot_identity(path, relative, identity["sha256"])
        else:
            path = relocated_path(artifact, identity["path"], "ci-runtime")
            if sha(path) != identity["sha256"]:
                raise ValueError("Runtime executable hash differs")

    lifecycle_dir = artifact / "ci-lifecycle"
    lifecycle = m1_lifecycle.check_report(lifecycle_dir)
    verify_oracle(lifecycle["oracle"])
    for row in lifecycle["sources"]:
        snapshot_identity(lifecycle_dir / row["snapshot"], row["path"], row["sha256"])
    lifecycle_outcomes = {
        "exact_protocol_comparisons": len(lifecycle["cases"]),
        "full_diagnostic_byte_mismatches": sum(not error["raw_equal"]
            for row in lifecycle["cases"] for error in row["observations"]["diagnostics"]),
        "java_negative_observation": lifecycle["java_negative_observation"]["observations"],
        "source_stability_before_execution": lifecycle["source_stability_before_execution"],
        "source_stability_after_execution": lifecycle["source_stability_after_execution"],
    }
    if lifecycle_outcomes["exact_protocol_comparisons"] != 2 or lifecycle_outcomes["full_diagnostic_byte_mismatches"] != 4:
        raise ValueError("Lifecycle closing protocol/diagnostic inventory differs")

    platform_dir = artifact / "ci-platforms"
    platform = json.loads((platform_dir / "report.json").read_text())
    if not platform["source_stability"]:
        raise ValueError("Platform sources changed during execution")
    cases_manifest = json.loads((platform_dir / "oracle-native/cases.json").read_text())
    expected_manifest = json.loads(git_bytes("tests/fixtures/m1/semantics/cases.json"))
    if cases_manifest != expected_manifest or len(cases_manifest["cases"]) != 6078:
        raise ValueError("Primitive case inventory changed")
    captures = {"java": (platform_dir / "oracle-native/java.stdout.bin").read_bytes(),
                "rust": (platform_dir / "oracle-native/rust.stdout.bin").read_bytes(),
                "node": (platform_dir / "execution/node.stdout.bin").read_bytes(),
                "browser": (platform_dir / "execution/browser.stdout.bin").read_bytes()}
    recomputed = m1_platforms.compare(cases_manifest["cases"], captures)
    if recomputed != platform["comparisons"] or not m1_platforms.contract_matches(recomputed):
        raise ValueError("Platform raw comparison/known-gap inventory differs")
    execution = json.loads((platform_dir / "execution/execution.json").read_text())
    m1_platforms.check_scenarios(execution)
    if execution != platform["execution"]:
        raise ValueError("Platform execution metadata differs")
    if (platform["total"] != 6078 or platform["shared_engine_passed"] != 6078
            or platform["oracle_passed"] != {target: 6076 for target in ("rust", "node", "browser")}
            or platform["compatibility_status"] != "fail" or platform["experiment_contract_status"] != "pass"):
        raise ValueError("Platform status falsely reports compatibility")
    for relative, expected in platform["source_hashes"].items():
        snapshot_identity(platform_dir / "sources" / relative, relative, expected)
    for relative, expected in platform["artifacts"].items():
        if sha(platform_dir / relative) != expected:
            raise ValueError(f"Platform artifact identity differs: {relative}")
    oracle_native = json.loads((platform_dir / "oracle-native/report.json").read_text())
    verify_oracle(oracle_native["oracle"])
    for language in ("java", "rust"):
        for channel in ("stdout", "stderr"):
            data = (platform_dir / "oracle-native" / f"{language}.{channel}.bin").read_bytes()
            if hashlib.sha256(data).hexdigest() != oracle_native["records"][language][f"{channel}_sha256"]:
                raise ValueError("Primitive process capture identity differs")
        if oracle_native["records"][language]["exit_code"] != 0:
            raise ValueError("Primitive process failed")
    commands = json.loads((platform_dir / "commands.json").read_text())
    for row in commands:
        if row["exit_code"] != (1 if row["name"] == "oracle-native" else 0):
            raise ValueError(f"Platform acquisition subprocess failed: {row['name']}")
    return {"lifecycle": lifecycle_outcomes, "frontend": {"exact_comparisons": 15, "source_stability": True},
            "java_host": {"observation_suites": 5, "rust_byte_comparisons": 0, "source_stability": True},
            "runtime": {"exact_value_cases": successes, "known_diagnostic_byte_mismatches": mismatches},
            "platform": {"total": 6078, "all_shared_engine_matches": 6078,
                         "java_matches_each_target": 6076, "known_gaps": sorted(m1_platforms.KNOWN_GAPS),
                         "scenarios_each_target": len(m1_platforms.REQUIRED_SCENARIOS),
                         "compatibility_status": "fail", "experiment_contract_status": "pass"}}


def main():
    run_path = acquire(f"repos/{REPO}/actions/runs/{RUN}", "run-final.json")
    run = json.loads(run_path.read_text())
    if run["head_sha"] != HEAD or run["status"] != "completed":
        raise ValueError("Wrong head or incomplete run")
    jobs_path = acquire(f"repos/{REPO}/actions/runs/{RUN}/jobs?per_page=100", "jobs-final.json")
    jobs = json.loads(jobs_path.read_text())["jobs"]
    if len(jobs) != 5 or any(row["conclusion"] != "success" for row in jobs) or run["conclusion"] != "success":
        raise ValueError("Exact-head CI did not complete5 successful jobs")
    artifacts_path = acquire(f"repos/{REPO}/actions/runs/{RUN}/artifacts", "artifacts.json")
    artifacts = json.loads(artifacts_path.read_text())["artifacts"]
    candidates = [row for row in artifacts if row["name"] == "m1-experiment-evidence"]
    if len(candidates) != 1:
        raise ValueError("Expected exactly one M1 artifact")
    artifact = candidates[0]
    if artifact["expired"] or artifact["workflow_run"]["head_sha"] != HEAD or artifact["workflow_run"]["id"] != RUN:
        raise ValueError("Artifact provenance differs")
    archive = acquire(f"repos/{REPO}/actions/artifacts/{artifact['id']}/zip", "m1-experiment-evidence.zip")
    expected_digest = artifact["digest"]
    if expected_digest != "sha256:" + sha(archive):
        raise ValueError("GitHub artifact SHA256 mismatch")
    members, uncompressed = safe_extract(archive, BASE / "artifact")
    logs = acquire(f"repos/{REPO}/actions/runs/{RUN}/logs", "workflow-logs.zip")
    log_members, _ = safe_extract(logs, BASE / "workflow-logs")
    verified = verify(BASE / "artifact")
    summary = {"schema_version": 1, "repository": REPO, "commit": HEAD,
               "run_id": RUN, "run_url": run["html_url"], "run_conclusion": run["conclusion"],
               "jobs": [{"name": row["name"], "id": row["id"], "conclusion": row["conclusion"]} for row in jobs],
               "github_artifact": {"id": artifact["id"], "name": artifact["name"],
                                   "sha256": sha(archive), "github_digest": expected_digest,
                                   "zip_bytes": archive.stat().st_size, "uncompressed_bytes": uncompressed,
                                   "zip_members": members, "digest_verified": True},
               "workflow_logs": {"zip_sha256": sha(logs), "members": log_members},
               "verified_outcomes": verified, "evidence_archive": "reports/m1/ci-closing-evidence.tar.gz",
               "scope": "Exact remote CI architecture contracts and raw evidence; known diagnostic/regex failures remain failures; no full language/API/performance compatibility claim"}
    (BASE / "verification.json").write_text(json.dumps(summary, indent=2) + "\n")
    (ROOT / "reports/m1/ci-closing-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(verified, indent=2))


if __name__ == "__main__":
    main()
