//! Portable numeric candidates for M1; not a complete Pkl numeric implementation.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NumericError {
    IntegerOverflow,
    DivisionByZero,
}

pub fn add(a: i64, b: i64) -> Result<i64, NumericError> {
    a.checked_add(b).ok_or(NumericError::IntegerOverflow)
}
pub fn subtract(a: i64, b: i64) -> Result<i64, NumericError> {
    a.checked_sub(b).ok_or(NumericError::IntegerOverflow)
}
pub fn multiply(a: i64, b: i64) -> Result<i64, NumericError> {
    a.checked_mul(b).ok_or(NumericError::IntegerOverflow)
}
pub fn divide(a: i64, b: i64) -> Result<i64, NumericError> {
    if b == 0 {
        Err(NumericError::DivisionByZero)
    } else {
        a.checked_div(b).ok_or(NumericError::IntegerOverflow)
    }
}
pub fn remainder(a: i64, b: i64) -> Result<i64, NumericError> {
    if b == 0 {
        Err(NumericError::DivisionByZero)
    } else {
        // Java's MIN_VALUE % -1 is zero, unlike Rust's overflowing `%`.
        Ok(a.wrapping_rem(b))
    }
}

/// Java 19+ decimal selection/layout candidate. Must remain differentially tested.
/// Rust's shortest formatter supplies digits; one-digit results are rounded to
/// two significant digits, as required by Double.toString's selection rule.
pub fn double_to_string(value: f64) -> String {
    if value.is_nan() {
        return "NaN".into();
    }
    if value == f64::INFINITY {
        return "Infinity".into();
    }
    if value == f64::NEG_INFINITY {
        return "-Infinity".into();
    }
    if value == 0.0 {
        return if value.is_sign_negative() {
            "-0.0"
        } else {
            "0.0"
        }
        .into();
    }
    let negative = value.is_sign_negative();
    let magnitude = value.abs();
    let mut scientific = format!("{magnitude:e}");
    let (coefficient, _) = scientific.split_once('e').expect("scientific format");
    // Shortest formatting may choose either equidistant decimal. Explicit
    // precision selects the even decimal required by Java (e.g. ...6382/6383).
    let precision = coefficient.bytes().filter(|b| *b != b'.').count().max(2) - 1;
    scientific = format!("{magnitude:.precision$e}");
    let (coefficient, exponent) = scientific.split_once('e').expect("scientific format");
    let exponent: i32 = exponent.parse().expect("scientific exponent");
    let digits: String = coefficient.chars().filter(|c| *c != '.').collect();
    let mut result = if negative {
        "-".to_owned()
    } else {
        String::new()
    };
    if !(-3..7).contains(&exponent) {
        result.push(digits.as_bytes()[0] as char);
        result.push('.');
        result.push_str(if digits.len() == 1 { "0" } else { &digits[1..] });
        result.push('E');
        result.push_str(&exponent.to_string());
    } else if exponent < 0 {
        result.push_str("0.");
        result.extend(std::iter::repeat_n('0', (-exponent - 1) as usize));
        result.push_str(&digits);
    } else {
        let point = (exponent + 1) as usize;
        if point >= digits.len() {
            result.push_str(&digits);
            result.extend(std::iter::repeat_n('0', point - digits.len()));
            result.push_str(".0");
        } else {
            result.push_str(&digits[..point]);
            result.push('.');
            result.push_str(&digits[point..]);
        }
    }
    // A second digit zero is needed for selection, but not for plain fractions.
    if (-3..0).contains(&exponent) && result.ends_with('0') {
        result.pop();
    }
    result
}

// The following cube-root algorithm is adapted from fdlibm s_cbrt.c 1.3
// https://netlib.org/fdlibm/s_cbrt.c (source hash in docs/m1-semantics.md).
// Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
// Developed at SunSoft, a Sun Microsystems, Inc. business.
// Permission to use, copy, modify, and distribute this
// software is freely granted, provided that this notice
// is preserved.
/// fdlibm cube root with explicit word operations and unchanged arithmetic order.
/// Unlike the newer musl approximation, this matches the sampled StrictMath bits.
pub fn strict_cbrt(value: f64) -> f64 {
    let bits = value.to_bits();
    let sign = bits & (1_u64 << 63);
    let magnitude = bits & !(1_u64 << 63);
    let high = (magnitude >> 32) as u32;
    if high >= 0x7ff00000 || magnitude == 0 {
        return value + value;
    }
    let x = f64::from_bits(magnitude);
    let mut t = if high < 0x00100000 {
        let scaled = f64::from_bits(0x4350000000000000) * x;
        let high = (scaled.to_bits() >> 32) as u32 / 3 + 696219795;
        f64::from_bits((u64::from(high) << 32) | (scaled.to_bits() & 0xffffffff))
    } else {
        f64::from_bits(u64::from(high / 3 + 715094163) << 32)
    };
    let c = f64::from_bits(0x3fe15f15f15f15f1);
    let d = f64::from_bits(0xbfe691de2532c834);
    let e = f64::from_bits(0x3ff6a0ea0ea0ea0f);
    let f = f64::from_bits(0x3ff9b6db6db6db6e);
    let g = f64::from_bits(0x3fd6db6db6db6db7);
    let r = t * t / x;
    let s = c + r * t;
    t *= g + f / (s + e + d / s);
    t = f64::from_bits((t.to_bits() & 0xffffffff00000000) + (1_u64 << 32));
    let s = t * t;
    let r = x / s;
    let w = t + t;
    let r = (r - t) / (w + r);
    t = t + t * r;
    f64::from_bits(t.to_bits() | sign)
}

/// Software libm is a portability candidate, not yet a StrictMath guarantee.
pub fn math(operation: &str, value: f64) -> Option<f64> {
    Some(match operation {
        "sqrt" => libm::sqrt(value),
        "sin" => libm::sin(value),
        "cos" => libm::cos(value),
        "tan" => libm::tan(value),
        "exp" => libm::exp(value),
        "log" => libm::log(value),
        "cbrt" => strict_cbrt(value),
        "rint" => value.round_ties_even(),
        "ceil" => value.ceil(),
        "floor" => value.floor(),
        _ => return None,
    })
}

/// Tab-separated M1 primitive probe. Float inputs/outputs use IEEE-754 hex bits.
/// This stable test protocol is not a Pkl evaluator or diagnostic renderer.
pub fn probe(input: &str) -> Result<String, String> {
    let fields: Vec<_> = input.split('\t').collect();
    let parse_error = || "invalid numeric probe input".to_owned();
    match fields.as_slice() {
        [op @ ("add" | "sub" | "mul" | "div" | "rem"), a, b] => {
            let a = a.parse().map_err(|_| parse_error())?;
            let b = b.parse().map_err(|_| parse_error())?;
            let result = match *op {
                "add" => add(a, b),
                "sub" => subtract(a, b),
                "mul" => multiply(a, b),
                "div" => divide(a, b),
                _ => remainder(a, b),
            };
            Ok(match result {
                Ok(value) => format!("{value}\n"),
                Err(NumericError::IntegerOverflow) => "error:integerOverflow\n".into(),
                Err(NumericError::DivisionByZero) => "error:divisionByZero\n".into(),
            })
        }
        [op, bits] => {
            let value = f64::from_bits(u64::from_str_radix(bits, 16).map_err(|_| parse_error())?);
            if *op == "format" {
                return Ok(format!("{}\n", double_to_string(value)));
            }
            let result = math(op, value).ok_or_else(parse_error)?;
            // Double.doubleToLongBits canonicalizes NaN as part of this protocol;
            // formatting and NaN classification are tested separately.
            let bits = if result.is_nan() {
                0x7ff8000000000000
            } else {
                result.to_bits()
            };
            Ok(format!("{bits:016x}\n"))
        }
        _ => Err(parse_error()),
    }
}
