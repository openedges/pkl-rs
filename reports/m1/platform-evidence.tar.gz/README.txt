platform-preflight-1: initial development run; old primitive modules, not final evidence.
platforms-final-1: failed acquisition; copied native executable lacked execute permission, no parity conclusion.
platforms-final-2: complete final comparison, source_stability=true; strict exit1 preserves two known Java regex differences. All6078 shared-engine outputs agree;12 required scenarios each target.
