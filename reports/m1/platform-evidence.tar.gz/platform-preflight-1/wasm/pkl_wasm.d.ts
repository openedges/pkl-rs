/* tslint:disable */
/* eslint-disable */

export class HostProbe {
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    close(): void;
    constructor(mode: string);
    poll(now: number, budget: number): string;
    reject(token: string, message: string, now: number): void;
    respondBytes(token: string, value: Uint8Array, now: number): void;
    respondInteger(token: string, value: any, now: number): void;
    start(now: number, timeout: number): void;
}

export function evaluate(source: string, member: string): string;

export function primitive(family: string, input: string): string;

export function roundtripBytes(input: Uint8Array): Uint8Array;

export function roundtripInteger(input: any): bigint;

export function roundtripString(input: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_hostprobe_free: (a: number, b: number) => void;
    readonly evaluate: (a: any, b: any) => [number, number, number, number];
    readonly hostprobe_cancel: (a: number) => void;
    readonly hostprobe_close: (a: number) => void;
    readonly hostprobe_new: (a: any) => [number, number, number];
    readonly hostprobe_poll: (a: number, b: number, c: number) => [number, number];
    readonly hostprobe_reject: (a: number, b: any, c: any, d: number) => [number, number];
    readonly hostprobe_respondBytes: (a: number, b: any, c: any, d: number) => [number, number];
    readonly hostprobe_respondInteger: (a: number, b: any, c: any, d: number) => [number, number];
    readonly hostprobe_start: (a: number, b: number, c: number) => [number, number];
    readonly primitive: (a: any, b: any) => [number, number, number, number];
    readonly roundtripBytes: (a: any) => [number, number, number];
    readonly roundtripInteger: (a: any) => [number, number, number];
    readonly roundtripString: (a: any) => [number, number, number, number];
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
