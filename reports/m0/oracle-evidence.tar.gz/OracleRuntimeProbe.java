import com.oracle.truffle.api.Truffle;
public class OracleRuntimeProbe {
 public static void main(String[] args) {System.out.println(Truffle.getRuntime().getName());}
}
